param(
    [string]$SdkRoot = $(if ($env:ANDROID_SDK_ROOT) { $env:ANDROID_SDK_ROOT } elseif ($env:ANDROID_HOME) { $env:ANDROID_HOME } else { Join-Path $env:LOCALAPPDATA "Android\Sdk" })
)

$ErrorActionPreference = "Stop"

function Add-UserPathEntry {
    param([string]$PathEntry)

    if (-not (Test-Path $PathEntry)) {
        return
    }

    $userPath = [Environment]::GetEnvironmentVariable("Path", "User")
    $parts = @()
    if ($userPath) {
        $parts = $userPath.Split(";", [System.StringSplitOptions]::RemoveEmptyEntries)
    }

    if ($parts -notcontains $PathEntry) {
        $updated = ($parts + $PathEntry) -join ";"
        [Environment]::SetEnvironmentVariable("Path", $updated, "User")
        Write-Host "Added to user PATH: $PathEntry"
    }
}

function Find-SdkManager {
    param([string]$Root)

    $candidates = @(
        (Join-Path $Root "cmdline-tools\latest\bin\sdkmanager.bat"),
        (Join-Path $Root "cmdline-tools\bin\sdkmanager.bat"),
        (Join-Path $env:LOCALAPPDATA "Android\Sdk\cmdline-tools\latest\bin\sdkmanager.bat"),
        (Join-Path $env:LOCALAPPDATA "Android\Sdk\cmdline-tools\bin\sdkmanager.bat")
    ) | Select-Object -Unique

    foreach ($candidate in $candidates) {
        if ($candidate -and (Test-Path $candidate)) {
            return $candidate
        }
    }

    return $null
}

$sdkManager = Find-SdkManager -Root $SdkRoot
if (-not $sdkManager) {
    throw @"
Unable to find sdkmanager.bat.

Expected one of these locations:
- $SdkRoot\cmdline-tools\latest\bin\sdkmanager.bat
- $SdkRoot\cmdline-tools\bin\sdkmanager.bat

Please install Android SDK Command-line Tools first, or rerun this script with:
  .\scripts\bootstrap-android-sdk.ps1 -SdkRoot 'C:\Path\To\Android\Sdk'
"@
}

$SdkRoot = Split-Path (Split-Path (Split-Path $sdkManager -Parent) -Parent) -Parent
$sdkRootNormalized = $SdkRoot -replace "\\", "/"
$cmdlineToolsBin = Split-Path $sdkManager -Parent
$platformTools = Join-Path $SdkRoot "platform-tools"

[Environment]::SetEnvironmentVariable("ANDROID_SDK_ROOT", $SdkRoot, "User")
[Environment]::SetEnvironmentVariable("ANDROID_HOME", $SdkRoot, "User")
Add-UserPathEntry -PathEntry $cmdlineToolsBin
Add-UserPathEntry -PathEntry $platformTools

Write-Host "Using Android SDK root: $SdkRoot"
Write-Host "Using sdkmanager: $sdkManager"

$licenseAnswers = 1..20 | ForEach-Object { "y" }
$licenseAnswers | & $sdkManager --sdk_root=$SdkRoot --licenses | Out-Host

& $sdkManager --sdk_root=$SdkRoot `
    "platform-tools" `
    "platforms;android-35" `
    "build-tools;35.0.0"

$localPropertiesPath = Join-Path $PSScriptRoot "..\local.properties"
"sdk.dir=$sdkRootNormalized" | Set-Content -Path $localPropertiesPath -Encoding ASCII

Write-Host ""
Write-Host "Android SDK bootstrap completed."
Write-Host "Generated local.properties at: $localPropertiesPath"
Write-Host "You may need to restart the terminal before PATH changes take effect."
