#!/usr/bin/env python3
"""
🧠 羲和AI模型训练和转换脚本
将训练好的模型转换为 TFLite 格式，供手机端使用

使用方法:
    python train_and_convert_model.py --data training_data.jsonl --output xihe_model.tflite

依赖:
    pip install tensorflow transformers datasets
"""

import argparse
import json
import tensorflow as tf
from transformers import TFAutoModelForCausalLM, AutoTokenizer, create_optimizer
from datasets import Dataset
import numpy as np

def load_training_data(file_path):
    """加载训练数据"""
    data = []
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                record = json.loads(line)
                messages = record.get('messages', [])
                
                # 提取用户输入和助手回复
                user_msg = next((m['content'] for m in messages if m['role'] == 'user'), '')
                assistant_msg = next((m['content'] for m in messages if m['role'] == 'assistant'), '')
                
                if user_msg and assistant_msg:
                    data.append({
                        'input': user_msg,
                        'output': assistant_msg
                    })
    
    print(f"✅ 加载了 {len(data)} 条训练数据")
    return data

def create_model(model_name='distilgpt2'):
    """创建基础模型"""
    print(f"📦 加载基础模型: {model_name}")
    
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = TFAutoModelForCausalLM.from_pretrained(model_name)
    
    # 设置 pad_token
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    
    return model, tokenizer

def prepare_dataset(data, tokenizer, max_length=128):
    """准备训练数据集"""
    print("📚 准备训练数据...")
    
    def tokenize_function(examples):
        inputs = [f"{inp} {tokenizer.eos_token} {out}" for inp, out in zip(examples['input'], examples['output'])]
        return tokenizer(inputs, padding='max_length', truncation=True, max_length=max_length)
    
    dataset = Dataset.from_list(data)
    tokenized = dataset.map(tokenize_function, batched=True, remove_columns=['input', 'output'])
    
    return tokenized

def train_model(model, dataset, tokenizer, epochs=3, batch_size=4):
    """训练模型"""
    print(f"🚀 开始训练 (epochs={epochs}, batch_size={batch_size})")
    
    # 准备训练数据
    train_dataset = dataset.to_tf_dataset(
        columns=['input_ids', 'attention_mask'],
        shuffle=True,
        batch_size=batch_size,
        collate_fn=lambda x: {
            'input_ids': tf.constant([item['input_ids'] for item in x]),
            'attention_mask': tf.constant([item['attention_mask'] for item in x]),
            'labels': tf.constant([item['input_ids'] for item in x])
        }
    )
    
    # 创建优化器
    steps = len(dataset) // batch_size * epochs
    optimizer, schedule = create_optimizer(
        init_lr=5e-5,
        num_warmup_steps=0,
        num_train_steps=steps
    )
    
    # 编译模型
    model.compile(optimizer=optimizer)
    
    # 训练
    history = model.fit(
        train_dataset,
        epochs=epochs,
        verbose=1
    )
    
    print("✅ 训练完成！")
    return history

def convert_to_tflite(model, tokenizer, output_path, quantize=True):
    """转换为 TFLite 格式"""
    print("🔄 转换为 TFLite 格式...")
    
    # 创建具体函数
    @tf.function(input_signature=[tf.TensorSpec(shape=[1, 128], dtype=tf.int32, name='input_ids')])
    def serving_fn(input_ids):
        return model(input_ids, training=False)
    
    # 转换
    converter = tf.lite.TFLiteConverter.from_concrete_functions([serving_fn.get_concrete_function()])
    
    # 优化选项
    if quantize:
        print("⚡ 启用量化优化...")
        converter.optimizations = [tf.lite.Optimize.DEFAULT]
        converter.target_spec.supported_types = [tf.float16]
    
    tflite_model = converter.convert()
    
    # 保存
    with open(output_path, 'wb') as f:
        f.write(tflite_model)
    
    print(f"✅ 模型已保存到: {output_path}")
    print(f"📊 模型大小: {len(tflite_model) / (1024 * 1024):.2f} MB")

def save_vocabulary(tokenizer, output_path):
    """保存词汇表"""
    vocab = tokenizer.get_vocab()
    sorted_vocab = sorted(vocab.items(), key=lambda x: x[1])
    
    with open(output_path, 'w', encoding='utf-8') as f:
        for word, _ in sorted_vocab:
            f.write(f"{word}\n")
    
    print(f"✅ 词汇表已保存到: {output_path}")

def main():
    parser = argparse.ArgumentParser(description='训练并转换羲和AI模型')
    parser.add_argument('--data', required=True, help='训练数据文件 (JSONL格式)')
    parser.add_argument('--output', default='xihe_model.tflite', help='输出模型文件')
    parser.add_argument('--model', default='distilgpt2', help='基础模型名称')
    parser.add_argument('--epochs', type=int, default=3, help='训练轮数')
    parser.add_argument('--batch-size', type=int, default=4, help='批次大小')
    parser.add_argument('--max-length', type=int, default=128, help='最大序列长度')
    parser.add_argument('--no-quantize', action='store_true', help='不使用量化')
    
    args = parser.parse_args()
    
    print("=" * 50)
    print("🧠 羲和AI模型训练系统")
    print("=" * 50)
    
    # 1. 加载数据
    data = load_training_data(args.data)
    
    if len(data) < 10:
        print("⚠️ 警告: 训练数据太少，建议至少100条")
    
    # 2. 创建模型
    model, tokenizer = create_model(args.model)
    
    # 3. 准备数据集
    dataset = prepare_dataset(data, tokenizer, args.max_length)
    
    # 4. 训练模型
    train_model(model, dataset, tokenizer, args.epochs, args.batch_size)
    
    # 5. 转换为 TFLite
    convert_to_tflite(model, tokenizer, args.output, quantize=not args.no_quantize)
    
    # 6. 保存词汇表
    vocab_path = args.output.replace('.tflite', '_vocab.txt')
    save_vocabulary(tokenizer, vocab_path)
    
    print("\n" + "=" * 50)
    print("🎉 完成！")
    print("=" * 50)
    print(f"\n📱 将以下文件复制到 Android 应用:")
    print(f"  - {args.output}")
    print(f"  - {vocab_path}")
    print(f"\n📍 放置位置: app/src/main/assets/")

if __name__ == '__main__':
    main()
