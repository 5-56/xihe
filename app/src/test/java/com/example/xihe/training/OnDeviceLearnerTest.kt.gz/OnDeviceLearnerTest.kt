package com.example.xihe.training

import org.junit.Test
import org.junit.Assert.*
import org.junit.Before

/**
 * 🧪 OnDeviceLearner 单元测试
 * 
 * 测试意图分类和相似度匹配功能
 */
class OnDeviceLearnerTest {
    
    /**
     * 测试意图分类 - 打开应用
     */
    @Test
    fun testIntentClassification_openApp() {
        // 测试"打开应用"意图
        val inputs = listOf(
            "打开微信",
            "启动支付宝",
            "运行抖音",
            "开启相机"
        )
        
        // 这里我们测试关键词识别逻辑
        val openKeywords = listOf("打开", "启动", "运行", "开启")
        
        for (input in inputs) {
            val hasOpenIntent = openKeywords.any { input.contains(it) }
            assertTrue("$input 应该被识别为打开应用意图", hasOpenIntent)
        }
    }
    
    /**
     * 测试意图分类 - 发送消息
     */
    @Test
    fun testIntentClassification_sendMessage() {
        val inputs = listOf(
            "发消息给张三",
            "给李四发信息",
            "告诉王五今天开会",
            "通知大家明天放假"
        )
        
        val sendKeywords = listOf("发消息", "发信息", "告诉", "通知")
        
        for (input in inputs) {
            val hasSendIntent = sendKeywords.any { input.contains(it) }
            assertTrue("$input 应该被识别为发送消息意图", hasSendIntent)
        }
    }
    
    /**
     * 测试意图分类 - 搜索
     */
    @Test
    fun testIntentClassification_search() {
        val inputs = listOf(
            "搜索今日新闻",
            "搜一下附近的餐厅",
            "查一下天气",
            "找一下快递单号"
        )
        
        val searchKeywords = listOf("搜索", "搜一下", "查一下", "查询", "找")
        
        for (input in inputs) {
            val hasSearchIntent = searchKeywords.any { input.contains(it) }
            assertTrue("$input 应该被识别为搜索意图", hasSearchIntent)
        }
    }
    
    /**
     * 测试分词功能
     */
    @Test
    fun testTokenize() {
        val text = "打开微信发消息"
        val expected = listOf("打", "开", "微", "信", "发", "消", "息")
        
        // 简单的中文分词（按字符）
        val tokens = text.map { it.toString() }
        
        assertEquals(expected, tokens)
    }
    
    /**
     * 测试余弦相似度计算
     */
    @Test
    fun testCosineSimilarity() {
        // 相同向量的余弦相似度应该为 1
        val v1 = mapOf("a" to 1.0f, "b" to 2.0f, "c" to 3.0f)
        val v2 = mapOf("a" to 1.0f, "b" to 2.0f, "c" to 3.0f)
        
        val similarity = cosineSimilarity(v1, v2)
        assertEquals(1.0f, similarity, 0.001f)
        
        // 完全不同的向量相似度应该为 0
        val v3 = mapOf("x" to 1.0f, "y" to 2.0f)
        val similarity2 = cosineSimilarity(v1, v3)
        assertEquals(0.0f, similarity2, 0.001f)
    }
    
    /**
     * 测试正交向量
     */
    @Test
    fun testOrthogonalVectors() {
        val v1 = mapOf("a" to 1.0f, "b" to 0.0f)
        val v2 = mapOf("a" to 0.0f, "b" to 1.0f)
        
        val similarity = cosineSimilarity(v1, v2)
        assertEquals(0.0f, similarity, 0.001f)
    }
    
    // 辅助函数：计算余弦相似度
    private fun cosineSimilarity(v1: Map<String, Float>, v2: Map<String, Float>): Float {
        val commonKeys = v1.keys.intersect(v2.keys)
        if (commonKeys.isEmpty()) return 0f
        
        var dotProduct = 0f
        var norm1 = 0f
        var norm2 = 0f
        
        for (key in commonKeys) {
            dotProduct += (v1[key] ?: 0f) * (v2[key] ?: 0f)
        }
        
        for (value in v1.values) {
            norm1 += value * value
        }
        
        for (value in v2.values) {
            norm2 += value * value
        }
        
        val denominator = kotlin.math.sqrt(norm1) * kotlin.math.sqrt(norm2)
        return if (denominator > 0) dotProduct / denominator else 0f
    }
}
