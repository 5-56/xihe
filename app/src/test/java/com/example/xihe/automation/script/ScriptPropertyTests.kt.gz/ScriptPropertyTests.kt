package com.example.xihe.automation.script

import io.kotest.core.spec.style.FunSpec
import io.kotest.matchers.shouldBe
import io.kotest.matchers.shouldNotBe
import io.kotest.matchers.collections.shouldContainAll
import io.kotest.matchers.ints.shouldBeGreaterThan
import io.kotest.matchers.floats.shouldBeBetween
import io.kotest.property.Arb
import io.kotest.property.arbitrary.*
import io.kotest.property.checkAll
import io.kotest.property.forAll
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * 🧪 脚本库属性测试
 * 
 * 使用 Kotest Property Testing 验证脚本管理的通用正确性属性
 */
class ScriptPropertyTests : FunSpec({
    
    val json = Json { 
        prettyPrint = true 
        ignoreUnknownKeys = true 
        encodeDefaults = true
    }
    
    // ==================== 自定义生成器 ====================
    
    // 生成有效的脚本 ID
    val scriptIdArb = Arb.string(8..32, Codepoint.alphanumeric())
        .map { "script_$it" }
    
    // 生成脚本名称
    val scriptNameArb = Arb.string(1..50)
        .filter { it.isNotBlank() }
        .map { it.trim() }
    
    // 生成关键词列表
    val keywordsArb = Arb.list(Arb.string(1..20), 0..5)
    
    // 生成步骤类型
    val stepTypeArb = Arb.enum<StepType>()
    
    // 生成动作类型
    val actionArb = Arb.of("CLICK", "INPUT", "SCROLL", "BACK", "HOME", "LONG_CLICK")
    
    // 生成单个步骤
    fun smartStepArb(index: Int): Arb<SmartStep> = arbitrary {
        val type = stepTypeArb.bind()
        SmartStep(
            id = "step_$index",
            type = type,
            action = if (type == StepType.ACTION) actionArb.bind() else null,
            target = if (type == StepType.ACTION) Arb.string(1..30).orNull().bind() else null,
            value = if (type == StepType.DELAY) Arb.int(100..5000).map { it.toString() }.bind() else null
        )
    }
    
    // 生成步骤列表（至少1个）
    val stepsArb = Arb.int(1..10).flatMap { count ->
        arbitrary {
            (0 until count).map { smartStepArb(it).bind() }
        }
    }
    
    // 生成完整脚本
    val smartScriptArb = arbitrary {
        SmartScript(
            id = scriptIdArb.bind(),
            metadata = ScriptMetadata(
                name = scriptNameArb.bind(),
                description = Arb.string(0..200).bind(),
                keywords = keywordsArb.bind(),
                intent = Arb.of("TEST", "AUTOMATION", "UTILITY").bind(),
                version = Arb.int(1..100).bind()
            ),
            flow = AdvancedAutomationFlow(
                steps = stepsArb.bind()
            ),
            variables = mutableMapOf()
        )
    }
    
    // ==================== Property 2: 脚本导入导出往返一致性 ====================
    
    context("Property 2: 脚本导入导出往返一致性") {
        
        test("序列化后反序列化应保持脚本内容不变") {
            checkAll(10, smartScriptArb) { script ->
                // 序列化
                val jsonString = json.encodeToString(script)
                
                // 反序列化
                val restored = json.decodeFromString<SmartScript>(jsonString)
                
                // 验证核心字段一致
                restored.id shouldBe script.id
                restored.metadata.name shouldBe script.metadata.name
                restored.metadata.version shouldBe script.metadata.version
                restored.flow.steps.size shouldBe script.flow.steps.size
            }
        }
        
        test("导出的 JSON 应该能通过格式验证") {
            checkAll(10, smartScriptArb) { script ->
                val jsonString = json.encodeToString(script)
                val validation = SmartScriptManager.validateScriptFormat(jsonString)
                
                validation.isValid shouldBe true
                validation.errors.size shouldBe 0
            }
        }
        
        test("步骤顺序在往返后应保持不变") {
            checkAll(10, smartScriptArb) { script ->
                val jsonString = json.encodeToString(script)
                val restored = json.decodeFromString<SmartScript>(jsonString)
                
                script.flow.steps.forEachIndexed { index, step ->
                    restored.flow.steps[index].id shouldBe step.id
                    restored.flow.steps[index].type shouldBe step.type
                }
            }
        }
    }
    
    // ==================== Property 3: 删除操作完整性 ====================
    
    context("Property 3: 删除操作完整性") {
        
        test("删除后脚本数量应减少") {
            // 模拟删除逻辑测试
            forAll(Arb.list(scriptIdArb, 1..20), Arb.list(Arb.int(0..19), 1..10)) { ids, indicesToDelete ->
                val uniqueIds = ids.distinct()
                val validIndices = indicesToDelete.filter { it < uniqueIds.size }.distinct()
                
                val remaining = uniqueIds.filterIndexed { index, _ -> index !in validIndices }
                
                remaining.size == uniqueIds.size - validIndices.size
            }
        }
        
        test("批量删除应返回正确的删除数量") {
            forAll(Arb.int(1..100), Arb.int(0..100)) { total, toDelete ->
                val actualDeleted = minOf(toDelete, total)
                val remaining = total - actualDeleted
                
                remaining >= 0 && actualDeleted <= total
            }
        }
    }
    
    // ==================== Property 4: 验证报告完整性 ====================
    
    context("Property 4: 验证报告完整性") {
        
        // 生成验证报告
        val validationReportArb = arbitrary {
            val total = Arb.int(1..50).bind()
            val success = Arb.int(0..total).bind()
            val failed = total - success
            
            ValidationReport(
                scriptId = scriptIdArb.bind(),
                scriptName = scriptNameArb.bind(),
                totalSteps = total,
                successSteps = success,
                failedSteps = failed,
                executionTimeMs = Arb.long(100L, 60000L).bind(),
                stepResults = emptyList()
            )
        }
        
        test("successSteps + failedSteps 应等于 totalSteps") {
            checkAll(10, validationReportArb) { report ->
                (report.successSteps + report.failedSteps) shouldBe report.totalSteps
            }
        }
        
        test("成功率应在 0 到 1 之间") {
            checkAll(10, validationReportArb) { report ->
                report.successRate.shouldBeBetween(0f, 1f, 0.001f)
            }
        }
        
        test("hasFailures 应与 failedSteps > 0 一致") {
            checkAll(10, validationReportArb) { report ->
                report.hasFailures shouldBe (report.failedSteps > 0)
            }
        }
        
        test("全部成功时成功率应为 1.0") {
            forAll(Arb.int(1..100)) { total ->
                val report = ValidationReport(
                    scriptId = "test",
                    scriptName = "测试",
                    totalSteps = total,
                    successSteps = total,
                    failedSteps = 0,
                    executionTimeMs = 1000,
                    stepResults = emptyList()
                )
                
                report.successRate == 1.0f && !report.hasFailures
            }
        }
        
        test("全部失败时成功率应为 0.0") {
            forAll(Arb.int(1..100)) { total ->
                val report = ValidationReport(
                    scriptId = "test",
                    scriptName = "测试",
                    totalSteps = total,
                    successSteps = 0,
                    failedSteps = total,
                    executionTimeMs = 1000,
                    stepResults = emptyList()
                )
                
                report.successRate == 0.0f && report.hasFailures
            }
        }
    }
    
    // ==================== Property 6: 脚本版本递增 ====================
    
    context("Property 6: 脚本版本递增") {
        
        test("版本号应始终为正整数") {
            forAll(Arb.int(1..1000)) { version ->
                version > 0
            }
        }
        
        test("递增后版本号应大于原版本") {
            forAll(Arb.int(1..Int.MAX_VALUE - 1)) { currentVersion ->
                val newVersion = currentVersion + 1
                newVersion > currentVersion
            }
        }
        
        test("多次递增应保持单调递增") {
            forAll(Arb.int(1..1000), Arb.int(1..100)) { startVersion, increments ->
                var version = startVersion
                var allIncreasing = true
                
                repeat(increments) {
                    val oldVersion = version
                    version++
                    if (version <= oldVersion) {
                        allIncreasing = false
                    }
                }
                
                allIncreasing && version == startVersion + increments
            }
        }
    }
    
    // ==================== 格式验证属性测试 ====================
    
    context("格式验证属性测试") {
        
        test("空字符串应始终无效") {
            val result = SmartScriptManager.validateScriptFormat("")
            result.isValid shouldBe false
        }
        
        test("随机非 JSON 字符串应无效") {
            checkAll(10, Arb.string(10..100).filter { !it.startsWith("{") }) { randomStr ->
                val result = SmartScriptManager.validateScriptFormat(randomStr)
                result.isValid shouldBe false
            }
        }
        
        test("有效脚本 JSON 应通过验证") {
            checkAll(10, smartScriptArb) { script ->
                val jsonString = json.encodeToString(script)
                val result = SmartScriptManager.validateScriptFormat(jsonString)
                
                result.isValid shouldBe true
            }
        }
    }
    
    // ==================== 优化建议属性测试 ====================
    
    context("优化建议属性测试") {
        
        // 生成优化建议
        val suggestionArb = arbitrary {
            OptimizationSuggestion(
                errorType = Arb.enum<ErrorType>().bind(),
                errorDescription = Arb.string(10..100).bind(),
                suggestedFix = Arb.of(
                    SuggestedFix.UpdateTarget("新目标"),
                    SuggestedFix.UpdateCoordinates(100, 200),
                    SuggestedFix.AddWaitStep(1000L),
                    SuggestedFix.AddScrollStep("DOWN"),
                    SuggestedFix.ChangeAction("LONG_CLICK"),
                    null
                ).bind(),
                confidence = Arb.float(0f..1f).bind(),
                reasoning = Arb.string(10..200).bind()
            )
        }
        
        test("置信度应在 0 到 1 之间") {
            checkAll(10, suggestionArb) { suggestion ->
                suggestion.confidence.shouldBeBetween(0f, 1f, 0.001f)
            }
        }
        
        test("OptimizedScriptResult.hasChanges 应与 appliedFixes 非空一致") {
            forAll(Arb.list(Arb.string(5..20), 0..10)) { fixes ->
                val appliedFixes = fixes.mapIndexed { i, _ ->
                    AppliedFix("step_$i", "old", "new", "UpdateTarget")
                }
                
                val result = OptimizedScriptResult(
                    originalScript = SmartScript(
                        id = "test",
                        metadata = ScriptMetadata("测试", "", emptyList(), "TEST", 1),
                        flow = AdvancedAutomationFlow(listOf(SmartStep("s1", StepType.ACTION, "CLICK")))
                    ),
                    optimizedScript = SmartScript(
                        id = "test",
                        metadata = ScriptMetadata("测试", "", emptyList(), "TEST", 1),
                        flow = AdvancedAutomationFlow(listOf(SmartStep("s1", StepType.ACTION, "CLICK")))
                    ),
                    appliedFixes = appliedFixes,
                    remainingIssues = emptyList()
                )
                
                result.hasChanges == appliedFixes.isNotEmpty()
            }
        }
        
        test("fixCount 应等于 appliedFixes 大小") {
            forAll(Arb.int(0..50)) { count ->
                val appliedFixes = (0 until count).map {
                    AppliedFix("step_$it", "old", "new", "UpdateTarget")
                }
                
                val result = OptimizedScriptResult(
                    originalScript = SmartScript(
                        id = "test",
                        metadata = ScriptMetadata("测试", "", emptyList(), "TEST", 1),
                        flow = AdvancedAutomationFlow(listOf(SmartStep("s1", StepType.ACTION, "CLICK")))
                    ),
                    optimizedScript = SmartScript(
                        id = "test",
                        metadata = ScriptMetadata("测试", "", emptyList(), "TEST", 1),
                        flow = AdvancedAutomationFlow(listOf(SmartStep("s1", StepType.ACTION, "CLICK")))
                    ),
                    appliedFixes = appliedFixes,
                    remainingIssues = emptyList()
                )
                
                result.fixCount == count
            }
        }
    }
})
