package com.example.xihe.automation.script

import org.junit.Test
import org.junit.Assert.*
import org.junit.Before

/**
 * 🧪 SmartScriptManager 单元测试
 * 
 * 测试脚本格式验证、导入导出和删除功能
 */
class SmartScriptManagerTest {
    
    // ==================== validateScriptFormat 测试 ====================
    
    @Test
    fun `validateScriptFormat - 空字符串应返回无效`() {
        val result = SmartScriptManager.validateScriptFormat("")
        
        assertFalse(result.isValid)
        assertTrue(result.errors.isNotEmpty())
        assertTrue(result.errors.any { it.contains("空") })
    }
    
    @Test
    fun `validateScriptFormat - 空白字符串应返回无效`() {
        val result = SmartScriptManager.validateScriptFormat("   \n\t  ")
        
        assertFalse(result.isValid)
        assertTrue(result.errors.isNotEmpty())
    }
    
    @Test
    fun `validateScriptFormat - 无效JSON应返回解析错误`() {
        val invalidJson = "{ this is not valid json }"
        val result = SmartScriptManager.validateScriptFormat(invalidJson)
        
        assertFalse(result.isValid)
        assertTrue(result.errors.any { it.contains("解析") || it.contains("JSON") })
    }
    
    @Test
    fun `validateScriptFormat - 缺少必需字段应返回具体错误`() {
        val jsonMissingId = """
            {
                "id": "",
                "metadata": {
                    "name": "测试脚本",
                    "description": "描述",
                    "keywords": [],
                    "intent": "TEST",
                    "version": 1
                },
                "flow": {
                    "steps": [
                        {"id": "step1", "type": "ACTION", "action": "CLICK"}
                    ]
                }
            }
        """.trimIndent()
        
        val result = SmartScriptManager.validateScriptFormat(jsonMissingId)
        
        assertFalse(result.isValid)
        assertTrue(result.errors.any { it.contains("ID") })
    }
    
    @Test
    fun `validateScriptFormat - 缺少脚本名称应返回错误`() {
        val jsonMissingName = """
            {
                "id": "test-script",
                "metadata": {
                    "name": "",
                    "description": "描述",
                    "keywords": [],
                    "intent": "TEST",
                    "version": 1
                },
                "flow": {
                    "steps": [
                        {"id": "step1", "type": "ACTION", "action": "CLICK"}
                    ]
                }
            }
        """.trimIndent()
        
        val result = SmartScriptManager.validateScriptFormat(jsonMissingName)
        
        assertFalse(result.isValid)
        assertTrue(result.errors.any { it.contains("名称") })
    }
    
    @Test
    fun `validateScriptFormat - 空步骤列表应返回错误`() {
        val jsonEmptySteps = """
            {
                "id": "test-script",
                "metadata": {
                    "name": "测试脚本",
                    "description": "描述",
                    "keywords": [],
                    "intent": "TEST",
                    "version": 1
                },
                "flow": {
                    "steps": []
                }
            }
        """.trimIndent()
        
        val result = SmartScriptManager.validateScriptFormat(jsonEmptySteps)
        
        assertFalse(result.isValid)
        assertTrue(result.errors.any { it.contains("步骤") && it.contains("空") })
    }
    
    @Test
    fun `validateScriptFormat - ACTION类型步骤缺少action字段应返回错误`() {
        val jsonMissingAction = """
            {
                "id": "test-script",
                "metadata": {
                    "name": "测试脚本",
                    "description": "描述",
                    "keywords": [],
                    "intent": "TEST",
                    "version": 1
                },
                "flow": {
                    "steps": [
                        {"id": "step1", "type": "ACTION"}
                    ]
                }
            }
        """.trimIndent()
        
        val result = SmartScriptManager.validateScriptFormat(jsonMissingAction)
        
        assertFalse(result.isValid)
        assertTrue(result.errors.any { it.contains("ACTION") && it.contains("action") })
    }
    
    @Test
    fun `validateScriptFormat - 有效脚本应返回成功`() {
        val validJson = """
            {
                "id": "test-script",
                "metadata": {
                    "name": "测试脚本",
                    "description": "这是一个测试脚本",
                    "keywords": ["测试", "示例"],
                    "intent": "TEST",
                    "version": 1
                },
                "flow": {
                    "steps": [
                        {"id": "step1", "type": "ACTION", "action": "CLICK", "target": "按钮"},
                        {"id": "step2", "type": "DELAY", "value": "1000"}
                    ]
                },
                "variables": {}
            }
        """.trimIndent()
        
        val result = SmartScriptManager.validateScriptFormat(validJson)
        
        assertTrue(result.isValid)
        assertTrue(result.errors.isEmpty())
    }
    
    @Test
    fun `validateScriptFormat - DELAY类型步骤不需要action字段`() {
        val validDelayStep = """
            {
                "id": "test-script",
                "metadata": {
                    "name": "测试脚本",
                    "description": "描述",
                    "keywords": [],
                    "intent": "TEST",
                    "version": 1
                },
                "flow": {
                    "steps": [
                        {"id": "step1", "type": "DELAY", "value": "1000"}
                    ]
                }
            }
        """.trimIndent()
        
        val result = SmartScriptManager.validateScriptFormat(validDelayStep)
        
        assertTrue(result.isValid)
    }
    
    @Test
    fun `validateScriptFormat - CONDITION类型步骤不需要action字段`() {
        val validConditionStep = """
            {
                "id": "test-script",
                "metadata": {
                    "name": "测试脚本",
                    "description": "描述",
                    "keywords": [],
                    "intent": "TEST",
                    "version": 1
                },
                "flow": {
                    "steps": [
                        {
                            "id": "step1", 
                            "type": "CONDITION",
                            "condition": {
                                "type": "ELEMENT_EXISTS",
                                "pattern": "确定"
                            }
                        }
                    ]
                }
            }
        """.trimIndent()
        
        val result = SmartScriptManager.validateScriptFormat(validConditionStep)
        
        assertTrue(result.isValid)
    }
    
    @Test
    fun `validateScriptFormat - 步骤缺少ID应返回错误`() {
        val jsonMissingStepId = """
            {
                "id": "test-script",
                "metadata": {
                    "name": "测试脚本",
                    "description": "描述",
                    "keywords": [],
                    "intent": "TEST",
                    "version": 1
                },
                "flow": {
                    "steps": [
                        {"id": "", "type": "ACTION", "action": "CLICK"}
                    ]
                }
            }
        """.trimIndent()
        
        val result = SmartScriptManager.validateScriptFormat(jsonMissingStepId)
        
        assertFalse(result.isValid)
        assertTrue(result.errors.any { it.contains("步骤") && it.contains("ID") })
    }
    
    // ==================== ValidationResult 测试 ====================
    
    @Test
    fun `ValidationResult - 有效结果应该没有错误`() {
        val result = SmartScriptManager.ValidationResult(isValid = true)
        
        assertTrue(result.isValid)
        assertTrue(result.errors.isEmpty())
    }
    
    @Test
    fun `ValidationResult - 无效结果应该包含错误列表`() {
        val errors = listOf("错误1", "错误2")
        val result = SmartScriptManager.ValidationResult(isValid = false, errors = errors)
        
        assertFalse(result.isValid)
        assertEquals(2, result.errors.size)
        assertEquals("错误1", result.errors[0])
    }
}
