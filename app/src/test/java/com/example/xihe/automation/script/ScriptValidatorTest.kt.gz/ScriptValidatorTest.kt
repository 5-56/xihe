package com.example.xihe.automation.script

import org.junit.Test
import org.junit.Assert.*

/**
 * 🧪 ScriptValidator 单元测试
 * 
 * 测试验证报告统计计算和状态转换
 */
class ScriptValidatorTest {
    
    // ==================== ValidationReport 测试 ====================
    
    @Test
    fun `ValidationReport - 成功率计算正确`() {
        val report = ValidationReport(
            scriptId = "test",
            scriptName = "测试脚本",
            totalSteps = 10,
            successSteps = 8,
            failedSteps = 2,
            executionTimeMs = 5000,
            stepResults = emptyList()
        )
        
        assertEquals(0.8f, report.successRate, 0.001f)
    }
    
    @Test
    fun `ValidationReport - 全部成功时成功率为1`() {
        val report = ValidationReport(
            scriptId = "test",
            scriptName = "测试脚本",
            totalSteps = 5,
            successSteps = 5,
            failedSteps = 0,
            executionTimeMs = 3000,
            stepResults = emptyList()
        )
        
        assertEquals(1.0f, report.successRate, 0.001f)
        assertFalse(report.hasFailures)
    }
    
    @Test
    fun `ValidationReport - 全部失败时成功率为0`() {
        val report = ValidationReport(
            scriptId = "test",
            scriptName = "测试脚本",
            totalSteps = 5,
            successSteps = 0,
            failedSteps = 5,
            executionTimeMs = 3000,
            stepResults = emptyList()
        )
        
        assertEquals(0.0f, report.successRate, 0.001f)
        assertTrue(report.hasFailures)
    }
    
    @Test
    fun `ValidationReport - 空步骤时成功率为0`() {
        val report = ValidationReport(
            scriptId = "test",
            scriptName = "测试脚本",
            totalSteps = 0,
            successSteps = 0,
            failedSteps = 0,
            executionTimeMs = 0,
            stepResults = emptyList()
        )
        
        assertEquals(0.0f, report.successRate, 0.001f)
    }
    
    @Test
    fun `ValidationReport - hasFailures正确判断`() {
        val reportWithFailures = ValidationReport(
            scriptId = "test",
            scriptName = "测试脚本",
            totalSteps = 10,
            successSteps = 9,
            failedSteps = 1,
            executionTimeMs = 5000,
            stepResults = emptyList()
        )
        
        val reportWithoutFailures = ValidationReport(
            scriptId = "test",
            scriptName = "测试脚本",
            totalSteps = 10,
            successSteps = 10,
            failedSteps = 0,
            executionTimeMs = 5000,
            stepResults = emptyList()
        )
        
        assertTrue(reportWithFailures.hasFailures)
        assertFalse(reportWithoutFailures.hasFailures)
    }
    
    @Test
    fun `ValidationReport - cancelled标志正确设置`() {
        val cancelledReport = ValidationReport(
            scriptId = "test",
            scriptName = "测试脚本",
            totalSteps = 10,
            successSteps = 5,
            failedSteps = 0,
            executionTimeMs = 2500,
            stepResults = emptyList(),
            cancelled = true
        )
        
        val normalReport = ValidationReport(
            scriptId = "test",
            scriptName = "测试脚本",
            totalSteps = 10,
            successSteps = 10,
            failedSteps = 0,
            executionTimeMs = 5000,
            stepResults = emptyList()
        )
        
        assertTrue(cancelledReport.cancelled)
        assertFalse(normalReport.cancelled)
    }
    
    // ==================== StepResult 测试 ====================
    
    @Test
    fun `StepResult - 成功步骤没有错误信息`() {
        val result = StepResult(
            stepId = "step1",
            stepDescription = "点击按钮",
            success = true,
            executionTimeMs = 100
        )
        
        assertTrue(result.success)
        assertNull(result.errorMessage)
        assertNull(result.screenshotPath)
        assertNull(result.optimizationSuggestion)
    }
    
    @Test
    fun `StepResult - 失败步骤包含错误信息`() {
        val result = StepResult(
            stepId = "step1",
            stepDescription = "点击按钮",
            success = false,
            errorMessage = "元素未找到",
            screenshotPath = "/path/to/screenshot.png",
            executionTimeMs = 5000
        )
        
        assertFalse(result.success)
        assertEquals("元素未找到", result.errorMessage)
        assertNotNull(result.screenshotPath)
    }
    
    @Test
    fun `StepResult - 可以包含优化建议`() {
        val suggestion = OptimizationSuggestion(
            errorType = ErrorType.ELEMENT_NOT_FOUND,
            errorDescription = "找不到目标元素",
            suggestedFix = SuggestedFix.UpdateTarget("新按钮"),
            confidence = 0.85f,
            reasoning = "屏幕上存在相似元素"
        )
        
        val result = StepResult(
            stepId = "step1",
            stepDescription = "点击按钮",
            success = false,
            errorMessage = "元素未找到",
            executionTimeMs = 5000,
            optimizationSuggestion = suggestion
        )
        
        assertNotNull(result.optimizationSuggestion)
        assertEquals(ErrorType.ELEMENT_NOT_FOUND, result.optimizationSuggestion?.errorType)
    }
    
    // ==================== ValidationState 测试 ====================
    
    @Test
    fun `ValidationState - Idle状态`() {
        val state = ValidationState.Idle
        
        assertTrue(state is ValidationState.Idle)
    }
    
    @Test
    fun `ValidationState - Running状态包含进度信息`() {
        val state = ValidationState.Running(currentStep = 3, totalSteps = 10)
        
        assertTrue(state is ValidationState.Running)
        assertEquals(3, state.currentStep)
        assertEquals(10, state.totalSteps)
    }
    
    @Test
    fun `ValidationState - Paused状态`() {
        val state = ValidationState.Paused
        
        assertTrue(state is ValidationState.Paused)
    }
    
    @Test
    fun `ValidationState - Completed状态包含报告`() {
        val report = ValidationReport(
            scriptId = "test",
            scriptName = "测试脚本",
            totalSteps = 5,
            successSteps = 5,
            failedSteps = 0,
            executionTimeMs = 3000,
            stepResults = emptyList()
        )
        
        val state = ValidationState.Completed(report)
        
        assertTrue(state is ValidationState.Completed)
        assertEquals("test", state.report.scriptId)
    }
    
    @Test
    fun `ValidationState - Failed状态包含错误信息`() {
        val state = ValidationState.Failed("无障碍服务未启动")
        
        assertTrue(state is ValidationState.Failed)
        assertEquals("无障碍服务未启动", state.error)
    }
    
    // ==================== 步骤结果统计测试 ====================
    
    @Test
    fun `stepResults数量应等于totalSteps`() {
        val stepResults = listOf(
            StepResult("s1", "步骤1", true, executionTimeMs = 100),
            StepResult("s2", "步骤2", true, executionTimeMs = 100),
            StepResult("s3", "步骤3", false, "错误", executionTimeMs = 100)
        )
        
        val report = ValidationReport(
            scriptId = "test",
            scriptName = "测试脚本",
            totalSteps = 3,
            successSteps = 2,
            failedSteps = 1,
            executionTimeMs = 300,
            stepResults = stepResults
        )
        
        assertEquals(report.totalSteps, report.stepResults.size)
        assertEquals(report.totalSteps, report.successSteps + report.failedSteps)
    }
    
    @Test
    fun `successSteps加failedSteps应等于totalSteps`() {
        val testCases = listOf(
            Triple(10, 7, 3),
            Triple(5, 5, 0),
            Triple(8, 0, 8),
            Triple(1, 1, 0)
        )
        
        testCases.forEach { (total, success, failed) ->
            val report = ValidationReport(
                scriptId = "test",
                scriptName = "测试脚本",
                totalSteps = total,
                successSteps = success,
                failedSteps = failed,
                executionTimeMs = 1000,
                stepResults = emptyList()
            )
            
            assertEquals(
                "total=$total, success=$success, failed=$failed",
                total,
                report.successSteps + report.failedSteps
            )
        }
    }
}
