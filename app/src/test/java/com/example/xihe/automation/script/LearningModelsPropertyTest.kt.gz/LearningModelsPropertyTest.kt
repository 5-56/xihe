package com.example.xihe.automation.script

import io.kotest.core.spec.style.FunSpec
import io.kotest.matchers.shouldBe
import io.kotest.matchers.shouldNotBe
import io.kotest.matchers.collections.shouldNotBeEmpty
import io.kotest.matchers.floats.shouldBeBetween
import io.kotest.property.Arb
import io.kotest.property.arbitrary.*
import io.kotest.property.checkAll
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * 🧪 学习模型属性测试
 * 
 * **Property 2: JSON 脚本解析 Round-Trip**
 * *For any* 有效的 ParsedScript 对象，序列化为 JSON 后再反序列化应产生等价的对象
 * **Validates: Requirements 2.1, 2.2, 2.4, 8.5**
 */
class LearningModelsPropertyTest : FunSpec({
    
    val json = Json { 
        prettyPrint = true 
        ignoreUnknownKeys = true 
        encodeDefaults = true
    }
    
    // ==================== 生成器定义 ====================
    
    // ActionType 生成器
    val actionTypeArb = Arb.enum<ActionType>()
    
    // FailureType 生成器
    val failureTypeArb = Arb.enum<FailureType>()
    
    // OptimizationType 生成器
    val optimizationTypeArb = Arb.enum<OptimizationType>()
    
    // SessionStatus 生成器
    val sessionStatusArb = Arb.enum<SessionStatus>()
    
    // ElementBounds 生成器
    val elementBoundsArb = Arb.bind(
        Arb.int(0, 1000),
        Arb.int(0, 2000),
        Arb.int(100, 1080),
        Arb.int(100, 2400)
    ) { left, top, right, bottom ->
        ElementBounds(
            left = minOf(left, right - 10),
            top = minOf(top, bottom - 10),
            right = maxOf(left + 10, right),
            bottom = maxOf(top + 10, bottom)
        )
    }
    
    // TargetElement 生成器
    val targetElementArb = Arb.bind(
        Arb.string(1..50),
        Arb.string(0..30).orNull(),
        Arb.string(0..30).orNull(),
        Arb.string(0..50).orNull(),
        elementBoundsArb.orNull()
    ) { desc, pos, text, resId, bounds ->
        TargetElement(
            description = desc,
            position = pos,
            text = text,
            resourceId = resId,
            bounds = bounds
        )
    }
    
    // ErrorHandling 生成器
    val errorHandlingArb = Arb.bind(
        Arb.enum<ErrorStrategy>(),
        Arb.int(0, 5),
        Arb.long(500, 5000),
        Arb.enum<FailureAction>()
    ) { strategy, retries, interval, action ->
        ErrorHandling(strategy, retries, interval, action)
    }
    
    // ParsedStep 生成器
    val parsedStepArb = Arb.bind(
        Arb.int(1, 100),
        Arb.string(1..20),
        actionTypeArb,
        Arb.string(5..100),
        targetElementArb.orNull(),
        Arb.string(0..50).orNull(),
        Arb.string(0..100),
        Arb.long(0, 5000),
        Arb.long(500, 10000),
        errorHandlingArb,
        Arb.boolean()
    ) { id, phase, action, desc, target, input, expected, waitBefore, waitAfter, errorHandling, canPause ->
        ParsedStep(
            id = id,
            phase = phase,
            actionType = action,
            description = desc,
            targetElement = target,
            inputValue = input,
            expectedResult = expected,
            waitBefore = waitBefore,
            waitAfter = waitAfter,
            errorHandling = errorHandling,
            canPause = canPause
        )
    }
    
    // ParsedScriptMetadata 生成器
    val metadataArb = Arb.bind(
        Arb.string(1..50),
        Arb.string(0..200),
        Arb.string(1..20),
        Arb.string(0..20),
        Arb.string(0..10),
        Arb.int(1, 100)
    ) { name, desc, platform, time, difficulty, version ->
        ParsedScriptMetadata(
            name = name,
            description = desc,
            targetPlatform = platform,
            estimatedTime = time,
            difficulty = difficulty,
            version = version
        )
    }
    
    // PotentialIssue 生成器
    val potentialIssueArb = Arb.bind(
        Arb.int(1, 100),
        Arb.string(5..100),
        Arb.enum<IssueCategory>(),
        Arb.enum<IssueSeverity>(),
        Arb.string(0..200),
        Arb.string(0..200)
    ) { id, desc, category, severity, solution, prevention ->
        PotentialIssue(id, desc, category, severity, solution, prevention)
    }
    
    // ParsedScript 生成器
    val parsedScriptArb = Arb.bind(
        metadataArb,
        Arb.list(parsedStepArb, 1..10),
        Arb.list(potentialIssueArb, 0..5),
        Arb.list(Arb.string(1..100), 0..5)
    ) { metadata, steps, issues, notes ->
        ParsedScript(metadata, steps, issues, notes)
    }
    
    // StepError 生成器
    val stepErrorArb = Arb.bind(
        failureTypeArb,
        Arb.string(5..100),
        Arb.string(0..200).orNull(),
        Arb.boolean()
    ) { type, msg, details, recoverable ->
        StepError(type, msg, details, recoverable)
    }
    
    // StepExecutionResult 生成器
    val stepExecutionResultArb = Arb.bind(
        Arb.int(1, 100),
        Arb.string(5..100),
        Arb.boolean(),
        stepErrorArb.orNull(),
        Arb.long(100, 30000),
        Arb.int(0, 5)
    ) { stepId, desc, success, error, duration, retryCount ->
        StepExecutionResult(
            stepId = stepId,
            stepDescription = desc,
            success = success,
            error = if (success) null else error,
            duration = duration,
            retryCount = retryCount
        )
    }
    
    // OptimizationSuggestion 生成器 (使用 ScriptOptimizationSuggestion)
    val optimizationSuggestionArb: Arb<ScriptOptimizationSuggestion> = Arb.bind(
        optimizationTypeArb,
        Arb.map(Arb.string(1..20), Arb.string(1..50), minSize = 1, maxSize = 5),
        Arb.string(5..100),
        Arb.float(0.1f, 1.0f),
        Arb.string(0..100)
    ) { type, changes, desc, confidence, reason ->
        ScriptOptimizationSuggestion(type, changes, desc, confidence, reason)
    }
    
    // OptimizationRecord 生成器
    val optimizationRecordArb: Arb<OptimizationRecord> = Arb.bind(
        Arb.long(1000000000000L, 2000000000000L),
        Arb.int(1, 100),
        optimizationTypeArb,
        Arb.map(Arb.string(1..20), Arb.string(1..50), minSize = 0, maxSize = 5),
        Arb.map(Arb.string(1..20), Arb.string(1..50), minSize = 0, maxSize = 5),
        Arb.string(5..100),
        Arb.boolean(),
        Arb.int(0, 5)
    ) { timestamp, stepId, type, original, optimized, reason, success, retry ->
        OptimizationRecord(timestamp, stepId, type, original, optimized, reason, success, retry)
    }
    
    // ExecutionLog 生成器
    val executionLogArb: Arb<ExecutionLog> = Arb.bind(
        Arb.long(1000000000000L, 2000000000000L),
        Arb.int(1, 100),
        Arb.string(1..50),
        Arb.string(1..100),
        Arb.string(0..100).orNull(),
        Arb.enum<LogLevel>()
    ) { timestamp, stepId, action, result, screenshot, level ->
        ExecutionLog(timestamp, stepId, action, result, screenshot, null, level)
    }
    
    // ==================== 属性测试 ====================
    
    context("Property 2: JSON 脚本解析 Round-Trip") {
        
        test("ParsedScript round-trip: 序列化后反序列化应产生等价对象") {
            checkAll(10, parsedScriptArb) { original ->
                val jsonString = json.encodeToString(original)
                val deserialized = json.decodeFromString<ParsedScript>(jsonString)
                
                deserialized.metadata.name shouldBe original.metadata.name
                deserialized.steps.size shouldBe original.steps.size
            }
        }
        
        test("ParsedStep round-trip: 步骤序列化后反序列化应保持一致") {
            checkAll(10, parsedStepArb) { original ->
                val jsonString = json.encodeToString(original)
                val deserialized = json.decodeFromString<ParsedStep>(jsonString)
                
                deserialized.id shouldBe original.id
                deserialized.actionType shouldBe original.actionType
            }
        }
        
        test("StepExecutionResult round-trip") {
            checkAll(10, stepExecutionResultArb) { original ->
                val jsonString = json.encodeToString(original)
                val deserialized = json.decodeFromString<StepExecutionResult>(jsonString)
                
                deserialized.stepId shouldBe original.stepId
                deserialized.success shouldBe original.success
            }
        }
        
        test("OptimizationSuggestion round-trip") {
            checkAll(10, optimizationSuggestionArb) { original ->
                val jsonString = json.encodeToString(original)
                val deserialized = json.decodeFromString<ScriptOptimizationSuggestion>(jsonString)
                
                deserialized.type shouldBe original.type
            }
        }
    }
    
    context("数据模型验证属性") {
        
        test("ParsedScript.isValid: 有效脚本应有非空名称和至少一个步骤") {
            checkAll(10, parsedScriptArb) { script ->
                val isValid = script.isValid()
                if (isValid) {
                    script.metadata.name.isNotBlank() shouldBe true
                    script.steps.shouldNotBeEmpty()
                }
            }
        }
        
        test("ExecutionResult.calculateSuccessRate: 成功率应在 0-1 之间") {
            checkAll(10, Arb.list(stepExecutionResultArb, 1..10)) { results ->
                val successRate = ExecutionResult.calculateSuccessRate(results)
                successRate.shouldBeBetween(0.0f, 1.0f, 0.0f)
            }
        }
        
        test("ElementBounds: 中心点计算应正确") {
            checkAll(10, elementBoundsArb) { bounds ->
                bounds.centerX shouldBe (bounds.left + bounds.right) / 2
                bounds.centerY shouldBe (bounds.top + bounds.bottom) / 2
            }
        }
    }
    
    context("LearningSession 属性") {
        
        test("LearningSession.getSuccessRate: 成功率计算应正确") {
            checkAll(10, Arb.int(0, 10), Arb.int(0, 10)) { successful, failed ->
                val session = LearningSession(
                    id = "test",
                    scriptName = "Test",
                    inputScript = "test",
                    startTime = System.currentTimeMillis()
                ).apply {
                    successfulSteps = successful
                    failedSteps = failed
                }
                
                val rate = session.getSuccessRate()
                if (successful + failed > 0) {
                    rate shouldBe successful.toFloat() / (successful + failed)
                } else {
                    rate shouldBe 0f
                }
            }
        }
    }
})
