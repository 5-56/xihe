package com.example.xihe.automation.script

import org.junit.Test
import org.junit.Assert.*

/**
 * 🧪 ScriptOptimizer 单元测试
 * 
 * 测试优化建议应用和错误类型分类
 */
class ScriptOptimizerTest {
    
    // ==================== ErrorType 测试 ====================
    
    @Test
    fun `ErrorType - 所有错误类型都已定义`() {
        val errorTypes = ErrorType.entries
        
        assertTrue(errorTypes.contains(ErrorType.ELEMENT_NOT_FOUND))
        assertTrue(errorTypes.contains(ErrorType.ELEMENT_MOVED))
        assertTrue(errorTypes.contains(ErrorType.APP_STATE_CHANGED))
        assertTrue(errorTypes.contains(ErrorType.PERMISSION_DENIED))
        assertTrue(errorTypes.contains(ErrorType.TIMEOUT))
        assertTrue(errorTypes.contains(ErrorType.UNKNOWN))
        assertEquals(6, errorTypes.size)
    }
    
    // ==================== SuggestedFix 测试 ====================
    
    @Test
    fun `SuggestedFix - UpdateTarget包含新目标`() {
        val fix = SuggestedFix.UpdateTarget("新按钮文本")
        
        assertTrue(fix is SuggestedFix.UpdateTarget)
        assertEquals("新按钮文本", fix.newTarget)
    }
    
    @Test
    fun `SuggestedFix - UpdateCoordinates包含坐标`() {
        val fix = SuggestedFix.UpdateCoordinates(100, 200)
        
        assertTrue(fix is SuggestedFix.UpdateCoordinates)
        assertEquals(100, fix.x)
        assertEquals(200, fix.y)
    }
    
    @Test
    fun `SuggestedFix - AddWaitStep包含等待时间`() {
        val fix = SuggestedFix.AddWaitStep(2000L)
        
        assertTrue(fix is SuggestedFix.AddWaitStep)
        assertEquals(2000L, fix.waitMs)
    }
    
    @Test
    fun `SuggestedFix - AddScrollStep包含方向`() {
        val fix = SuggestedFix.AddScrollStep("DOWN")
        
        assertTrue(fix is SuggestedFix.AddScrollStep)
        assertEquals("DOWN", fix.direction)
    }
    
    @Test
    fun `SuggestedFix - ChangeAction包含新动作`() {
        val fix = SuggestedFix.ChangeAction("LONG_CLICK")
        
        assertTrue(fix is SuggestedFix.ChangeAction)
        assertEquals("LONG_CLICK", fix.newAction)
    }
    
    @Test
    fun `SuggestedFix - UpdateValue包含新值`() {
        val fix = SuggestedFix.UpdateValue("新输入内容")
        
        assertTrue(fix is SuggestedFix.UpdateValue)
        assertEquals("新输入内容", fix.newValue)
    }
    
    // ==================== OptimizationSuggestion 测试 ====================
    
    @Test
    fun `OptimizationSuggestion - 包含所有必需字段`() {
        val suggestion = OptimizationSuggestion(
            errorType = ErrorType.ELEMENT_NOT_FOUND,
            errorDescription = "找不到目标元素",
            suggestedFix = SuggestedFix.UpdateTarget("确定按钮"),
            confidence = 0.85f,
            reasoning = "屏幕上存在相似的按钮"
        )
        
        assertEquals(ErrorType.ELEMENT_NOT_FOUND, suggestion.errorType)
        assertEquals("找不到目标元素", suggestion.errorDescription)
        assertNotNull(suggestion.suggestedFix)
        assertEquals(0.85f, suggestion.confidence, 0.001f)
        assertEquals("屏幕上存在相似的按钮", suggestion.reasoning)
    }
    
    @Test
    fun `OptimizationSuggestion - suggestedFix可以为null`() {
        val suggestion = OptimizationSuggestion(
            errorType = ErrorType.UNKNOWN,
            errorDescription = "未知错误",
            suggestedFix = null,
            confidence = 0.3f,
            reasoning = "无法确定错误原因"
        )
        
        assertNull(suggestion.suggestedFix)
    }
    
    @Test
    fun `OptimizationSuggestion - confidence应在0到1之间`() {
        val validConfidences = listOf(0.0f, 0.5f, 0.85f, 1.0f)
        
        validConfidences.forEach { conf ->
            val suggestion = OptimizationSuggestion(
                errorType = ErrorType.ELEMENT_NOT_FOUND,
                errorDescription = "测试",
                suggestedFix = null,
                confidence = conf,
                reasoning = "测试"
            )
            
            assertTrue("confidence=$conf 应该有效", suggestion.confidence in 0f..1f)
        }
    }
    
    // ==================== OptimizedScriptResult 测试 ====================
    
    @Test
    fun `OptimizedScriptResult - hasChanges正确判断`() {
        val originalScript = createTestScript("original")
        val optimizedScript = createTestScript("optimized")
        
        val resultWithChanges = OptimizedScriptResult(
            originalScript = originalScript,
            optimizedScript = optimizedScript,
            appliedFixes = listOf(
                AppliedFix("step1", "旧值", "新值", "UpdateTarget")
            ),
            remainingIssues = emptyList()
        )
        
        val resultWithoutChanges = OptimizedScriptResult(
            originalScript = originalScript,
            optimizedScript = originalScript,
            appliedFixes = emptyList(),
            remainingIssues = listOf("无法修复的问题")
        )
        
        assertTrue(resultWithChanges.hasChanges)
        assertFalse(resultWithoutChanges.hasChanges)
    }
    
    @Test
    fun `OptimizedScriptResult - fixCount正确计算`() {
        val script = createTestScript("test")
        
        val result = OptimizedScriptResult(
            originalScript = script,
            optimizedScript = script,
            appliedFixes = listOf(
                AppliedFix("step1", "旧值1", "新值1", "UpdateTarget"),
                AppliedFix("step2", "旧值2", "新值2", "AddWaitStep"),
                AppliedFix("step3", "旧值3", "新值3", "ChangeAction")
            ),
            remainingIssues = emptyList()
        )
        
        assertEquals(3, result.fixCount)
    }
    
    @Test
    fun `OptimizedScriptResult - 空修复列表时fixCount为0`() {
        val script = createTestScript("test")
        
        val result = OptimizedScriptResult(
            originalScript = script,
            optimizedScript = script,
            appliedFixes = emptyList(),
            remainingIssues = emptyList()
        )
        
        assertEquals(0, result.fixCount)
        assertFalse(result.hasChanges)
    }
    
    // ==================== AppliedFix 测试 ====================
    
    @Test
    fun `AppliedFix - 包含所有必需字段`() {
        val fix = AppliedFix(
            stepId = "step1",
            originalValue = "CLICK | 确定",
            newValue = "CLICK | 确认",
            fixType = "UpdateTarget"
        )
        
        assertEquals("step1", fix.stepId)
        assertEquals("CLICK | 确定", fix.originalValue)
        assertEquals("CLICK | 确认", fix.newValue)
        assertEquals("UpdateTarget", fix.fixType)
    }
    
    // ==================== 辅助函数 ====================
    
    private fun createTestScript(id: String): SmartScript {
        return SmartScript(
            id = id,
            metadata = ScriptMetadata(
                name = "测试脚本",
                description = "测试用",
                keywords = listOf("测试"),
                intent = "TEST",
                version = 1
            ),
            flow = AdvancedAutomationFlow(
                steps = listOf(
                    SmartStep(
                        id = "step1",
                        type = StepType.ACTION,
                        action = "CLICK",
                        target = "按钮"
                    )
                )
            )
        )
    }
    
    // ==================== 步骤更新测试 ====================
    
    @Test
    fun `applyFixToStep - UpdateTarget应更新target字段`() {
        val originalStep = SmartStep(
            id = "step1",
            type = StepType.ACTION,
            action = "CLICK",
            target = "旧按钮"
        )
        
        val fix = SuggestedFix.UpdateTarget("新按钮")
        val updatedStep = applyFixToStep(originalStep, fix)
        
        assertEquals("新按钮", updatedStep.target)
        assertEquals("CLICK", updatedStep.action)  // action 不变
        assertEquals("step1", updatedStep.id)  // id 不变
    }
    
    @Test
    fun `applyFixToStep - UpdateCoordinates应更新value字段`() {
        val originalStep = SmartStep(
            id = "step1",
            type = StepType.ACTION,
            action = "CLICK",
            target = "按钮"
        )
        
        val fix = SuggestedFix.UpdateCoordinates(100, 200)
        val updatedStep = applyFixToStep(originalStep, fix)
        
        assertEquals("100,200", updatedStep.value)
    }
    
    @Test
    fun `applyFixToStep - ChangeAction应更新action字段`() {
        val originalStep = SmartStep(
            id = "step1",
            type = StepType.ACTION,
            action = "CLICK",
            target = "按钮"
        )
        
        val fix = SuggestedFix.ChangeAction("LONG_CLICK")
        val updatedStep = applyFixToStep(originalStep, fix)
        
        assertEquals("LONG_CLICK", updatedStep.action)
        assertEquals("按钮", updatedStep.target)  // target 不变
    }
    
    @Test
    fun `applyFixToStep - AddScrollStep应更新action和value`() {
        val originalStep = SmartStep(
            id = "step1",
            type = StepType.ACTION,
            action = "CLICK",
            target = "按钮"
        )
        
        val fix = SuggestedFix.AddScrollStep("DOWN")
        val updatedStep = applyFixToStep(originalStep, fix)
        
        assertEquals("SCROLL", updatedStep.action)
        assertEquals("DOWN", updatedStep.value)
    }
    
    @Test
    fun `applyFixToStep - UpdateValue应更新value字段`() {
        val originalStep = SmartStep(
            id = "step1",
            type = StepType.ACTION,
            action = "INPUT",
            value = "旧内容"
        )
        
        val fix = SuggestedFix.UpdateValue("新内容")
        val updatedStep = applyFixToStep(originalStep, fix)
        
        assertEquals("新内容", updatedStep.value)
        assertEquals("INPUT", updatedStep.action)  // action 不变
    }
    
    // 模拟 applyFixToStep 函数（与 ScriptOptimizer 中的实现一致）
    private fun applyFixToStep(step: SmartStep, fix: SuggestedFix): SmartStep {
        return when (fix) {
            is SuggestedFix.UpdateTarget -> step.copy(target = fix.newTarget)
            is SuggestedFix.UpdateCoordinates -> step.copy(value = "${fix.x},${fix.y}")
            is SuggestedFix.AddWaitStep -> step
            is SuggestedFix.AddScrollStep -> step.copy(action = "SCROLL", value = fix.direction)
            is SuggestedFix.ChangeAction -> step.copy(action = fix.newAction)
            is SuggestedFix.UpdateValue -> step.copy(value = fix.newValue)
        }
    }
}
