package com.example.xihe.safety

import org.junit.Test
import org.junit.Assert.*

/**
 * 🧪 OperationSafetyManager 单元测试
 * 
 * 测试风险评估和关键词检测功能
 */
class OperationSafetyManagerTest {
    
    // 危险关键词列表（从 OperationSafetyManager 复制）
    private val dangerousKeywords = setOf(
        "支付", "付款", "转账", "汇款", "pay", "payment",
        "删除", "卸载", "清除", "格式化", "delete", "remove", "uninstall",
        "密码", "验证码", "身份证", "银行卡", "password",
        "授权", "权限", "允许", "permission",
        "root", "su", "superuser"
    )
    
    // 敏感应用列表
    private val sensitiveApps = setOf(
        "com.android.vending",
        "com.eg.android.AlipayGphone",
        "com.tencent.mm",
        "com.android.settings",
        "com.android.packageinstaller"
    )
    
    /**
     * 测试危险关键词检测 - 支付相关
     */
    @Test
    fun testDangerousKeywords_payment() {
        val paymentInputs = listOf(
            "帮我支付这个订单",
            "付款给商家",
            "转账给张三500块",
            "汇款到这个账户"
        )
        
        for (input in paymentInputs) {
            val hasDanger = dangerousKeywords.any { input.contains(it, ignoreCase = true) }
            assertTrue("$input 应该被检测为危险操作", hasDanger)
        }
    }
    
    /**
     * 测试危险关键词检测 - 删除相关
     */
    @Test
    fun testDangerousKeywords_delete() {
        val deleteInputs = listOf(
            "删除这个应用",
            "卸载微信",
            "清除所有数据",
            "格式化存储"
        )
        
        for (input in deleteInputs) {
            val hasDanger = dangerousKeywords.any { input.contains(it, ignoreCase = true) }
            assertTrue("$input 应该被检测为危险操作", hasDanger)
        }
    }
    
    /**
     * 测试危险关键词检测 - 敏感信息
     */
    @Test
    fun testDangerousKeywords_sensitiveInfo() {
        val sensitiveInputs = listOf(
            "告诉我密码",
            "发送验证码",
            "输入银行卡号",
            "提供身份证号码"
        )
        
        for (input in sensitiveInputs) {
            val hasDanger = dangerousKeywords.any { input.contains(it, ignoreCase = true) }
            assertTrue("$input 应该被检测为危险操作", hasDanger)
        }
    }
    
    /**
     * 测试安全操作（不包含危险关键词）
     */
    @Test
    fun testSafeOperations() {
        val safeInputs = listOf(
            "打开微信",
            "发消息给张三",
            "搜索今日天气",
            "播放音乐"
        )
        
        for (input in safeInputs) {
            val hasDanger = dangerousKeywords.any { input.contains(it, ignoreCase = true) }
            assertFalse("$input 应该被检测为安全操作", hasDanger)
        }
    }
    
    /**
     * 测试敏感应用检测
     */
    @Test
    fun testSensitiveApps() {
        assertTrue("支付宝应该是敏感应用", sensitiveApps.contains("com.eg.android.AlipayGphone"))
        assertTrue("微信应该是敏感应用", sensitiveApps.contains("com.tencent.mm"))
        assertTrue("系统设置应该是敏感应用", sensitiveApps.contains("com.android.settings"))
        
        assertFalse("抖音不应该是敏感应用", sensitiveApps.contains("com.ss.android.ugc.aweme"))
        assertFalse("淘宝不应该是敏感应用", sensitiveApps.contains("com.taobao.taobao"))
    }
    
    /**
     * 测试风险等级判断逻辑
     */
    @Test
    fun testRiskLevelDetermination() {
        // 模拟风险等级判断
        fun determineRiskLevel(containsDangerWord: Boolean, isSensitiveApp: Boolean): String {
            return when {
                containsDangerWord && isSensitiveApp -> "CRITICAL"
                containsDangerWord -> "HIGH"
                isSensitiveApp -> "MEDIUM"
                else -> "LOW"
            }
        }
        
        assertEquals("CRITICAL", determineRiskLevel(true, true))
        assertEquals("HIGH", determineRiskLevel(true, false))
        assertEquals("MEDIUM", determineRiskLevel(false, true))
        assertEquals("LOW", determineRiskLevel(false, false))
    }
    
    /**
     * 测试英文关键词检测（忽略大小写）
     */
    @Test
    fun testEnglishKeywords_caseInsensitive() {
        val inputs = listOf("delete file", "DELETE FILE", "Delete File")
        
        for (input in inputs) {
            val hasDanger = dangerousKeywords.any { input.contains(it, ignoreCase = true) }
            assertTrue("$input 应该被检测为危险操作（忽略大小写）", hasDanger)
        }
    }
}
