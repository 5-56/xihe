package com.example.xihe.gesture

import org.junit.Test
import org.junit.Assert.*
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * 🧪 GestureOptimizer 单元测试
 * 
 * 测试手势优化相关的数学计算
 */
class GestureOptimizerTest {
    
    /**
     * 测试两点间距离计算
     */
    @Test
    fun testDistanceCalculation() {
        // 水平距离
        val d1 = distance(0f, 0f, 3f, 0f)
        assertEquals(3.0f, d1, 0.001f)
        
        // 垂直距离
        val d2 = distance(0f, 0f, 0f, 4f)
        assertEquals(4.0f, d2, 0.001f)
        
        // 勾股定理 3-4-5
        val d3 = distance(0f, 0f, 3f, 4f)
        assertEquals(5.0f, d3, 0.001f)
    }
    
    /**
     * 测试路径长度计算
     */
    @Test
    fun testPathLength() {
        val points = listOf(
            Point(0f, 0f),
            Point(3f, 0f),
            Point(3f, 4f)
        )
        
        val length = calculatePathLength(points)
        assertEquals(7.0f, length, 0.001f)  // 3 + 4 = 7
    }
    
    /**
     * 测试平均速度计算
     */
    @Test
    fun testAverageSpeed() {
        // 100 像素在 100 毫秒内完成
        val distance = 100f
        val duration = 100L
        
        val speed = distance / duration  // 像素/毫秒
        assertEquals(1.0f, speed, 0.001f)
    }
    
    /**
     * 测试抖动检测
     */
    @Test
    fun testJitterDetection() {
        // 连续两点距离小于阈值视为抖动
        val jitterThreshold = 5f
        
        val p1 = Point(100f, 100f)
        val p2 = Point(102f, 101f)  // 距离约 2.24
        val p3 = Point(110f, 100f)  // 距离约 8.06
        
        val d12 = distance(p1.x, p1.y, p2.x, p2.y)
        val d23 = distance(p2.x, p2.y, p3.x, p3.y)
        
        assertTrue("p1-p2 应该被视为抖动", d12 < jitterThreshold)
        assertFalse("p2-p3 不应该被视为抖动", d23 < jitterThreshold)
    }
    
    /**
     * 测试移动平均平滑
     */
    @Test
    fun testMovingAverageSmooth() {
        val values = listOf(10f, 12f, 11f, 13f, 12f)
        val windowSize = 3
        
        val smoothed = movingAverage(values, windowSize)
        
        // 第一个窗口 [10, 12, 11] 的平均值
        val expected1 = (10f + 12f + 11f) / 3
        assertEquals(expected1, smoothed[0], 0.001f)
    }
    
    /**
     * 测试 Douglas-Peucker 算法简化判断
     */
    @Test
    fun testDouglasPeuckerSimplify() {
        // 点到直线的距离
        val lineStart = Point(0f, 0f)
        val lineEnd = Point(10f, 0f)
        val pointOnLine = Point(5f, 0f)
        val pointOffLine = Point(5f, 3f)
        
        val distOnLine = perpendicularDistance(pointOnLine, lineStart, lineEnd)
        val distOffLine = perpendicularDistance(pointOffLine, lineStart, lineEnd)
        
        assertEquals(0.0f, distOnLine, 0.001f)  // 在线上
        assertEquals(3.0f, distOffLine, 0.001f)  // 距离线 3 个单位
    }
    
    /**
     * 测试贝塞尔曲线控制点计算
     */
    @Test
    fun testBezierControlPoints() {
        val p0 = Point(0f, 0f)
        val p1 = Point(50f, 0f)
        val p2 = Point(100f, 0f)
        
        // 对于直线，控制点应该在直线上
        val control = calculateControlPoint(p0, p1, p2, 0.5f)
        
        // y 坐标应该接近 0
        assertTrue(abs(control.y) < 1f)
    }
    
    /**
     * 测试手势平滑度评分
     */
    @Test
    fun testSmoothnessScore() {
        // 直线应该有最高平滑度
        val straightLine = listOf(
            Point(0f, 0f),
            Point(10f, 0f),
            Point(20f, 0f),
            Point(30f, 0f)
        )
        
        val smoothnessScore = calculateSmoothness(straightLine)
        assertTrue("直线应该有高平滑度", smoothnessScore > 0.9f)
        
        // 锯齿线应该有较低平滑度
        val zigzag = listOf(
            Point(0f, 0f),
            Point(10f, 10f),
            Point(20f, 0f),
            Point(30f, 10f)
        )
        
        val zigzagScore = calculateSmoothness(zigzag)
        assertTrue("锯齿线应该有较低平滑度", zigzagScore < smoothnessScore)
    }
    
    // ==================== 辅助函数 ====================
    
    data class Point(val x: Float, val y: Float)
    
    private fun distance(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x2 - x1
        val dy = y2 - y1
        return sqrt(dx * dx + dy * dy)
    }
    
    private fun calculatePathLength(points: List<Point>): Float {
        if (points.size < 2) return 0f
        var length = 0f
        for (i in 0 until points.size - 1) {
            length += distance(points[i].x, points[i].y, points[i + 1].x, points[i + 1].y)
        }
        return length
    }
    
    private fun movingAverage(values: List<Float>, windowSize: Int): List<Float> {
        if (values.size < windowSize) return values
        val result = mutableListOf<Float>()
        for (i in 0..values.size - windowSize) {
            val window = values.subList(i, i + windowSize)
            result.add(window.sum() / windowSize)
        }
        return result
    }
    
    private fun perpendicularDistance(point: Point, lineStart: Point, lineEnd: Point): Float {
        val dx = lineEnd.x - lineStart.x
        val dy = lineEnd.y - lineStart.y
        
        val lengthSquared = dx * dx + dy * dy
        if (lengthSquared == 0f) {
            return distance(point.x, point.y, lineStart.x, lineStart.y)
        }
        
        val t = maxOf(0f, minOf(1f, 
            ((point.x - lineStart.x) * dx + (point.y - lineStart.y) * dy) / lengthSquared
        ))
        
        val projX = lineStart.x + t * dx
        val projY = lineStart.y + t * dy
        
        return distance(point.x, point.y, projX, projY)
    }
    
    private fun calculateControlPoint(p0: Point, p1: Point, p2: Point, t: Float): Point {
        val x = (1 - t) * (1 - t) * p0.x + 2 * (1 - t) * t * p1.x + t * t * p2.x
        val y = (1 - t) * (1 - t) * p0.y + 2 * (1 - t) * t * p1.y + t * t * p2.y
        return Point(x, y)
    }
    
    private fun calculateSmoothness(points: List<Point>): Float {
        if (points.size < 3) return 1f
        
        var angleChanges = 0f
        for (i in 1 until points.size - 1) {
            val angle1 = kotlin.math.atan2(
                (points[i].y - points[i-1].y).toDouble(),
                (points[i].x - points[i-1].x).toDouble()
            )
            val angle2 = kotlin.math.atan2(
                (points[i+1].y - points[i].y).toDouble(),
                (points[i+1].x - points[i].x).toDouble()
            )
            angleChanges += abs(angle2 - angle1).toFloat()
        }
        
        val maxChange = (points.size - 2) * Math.PI
        return (1 - angleChanges / maxChange).toFloat().coerceIn(0f, 1f)
    }
}
