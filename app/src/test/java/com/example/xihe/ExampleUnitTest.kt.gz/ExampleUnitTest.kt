package com.example.xihe

import com.example.xihe.tools.createSecureHttpClient
import com.example.xihe.tools.validateSafeUrl
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Test
import java.util.concurrent.TimeUnit

class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun validateSafeUrl_allowsPublicHttpsUrl() {
        assertNull(validateSafeUrl("https://example.com/path"))
    }

    @Test
    fun validateSafeUrl_blocksUnsupportedScheme() {
        assertEquals("仅支持 HTTP/HTTPS 协议", validateSafeUrl("ftp://example.com"))
    }

    @Test
    fun validateSafeUrl_blocksLocalAndPrivateAddresses() {
        assertEquals("禁止访问本地或内网地址", validateSafeUrl("http://localhost/api"))
        assertEquals("禁止访问本地或内网地址", validateSafeUrl("http://192.168.1.2/status"))
        assertEquals("禁止访问本地或内网地址", validateSafeUrl("http://[::1]/health"))
    }

    @Test
    fun validateSafeUrl_blocksLocalDomainHostname() {
        assertEquals("禁止访问本地或内网地址", validateSafeUrl("http://printer.local"))
    }

    @Test
    fun createSecureHttpClient_usesExpectedTimeouts() {
        val client = createSecureHttpClient()
        assertEquals(TimeUnit.SECONDS.toMillis(10).toInt(), client.connectTimeoutMillis)
        assertEquals(TimeUnit.SECONDS.toMillis(20).toInt(), client.readTimeoutMillis)
        assertEquals(TimeUnit.SECONDS.toMillis(20).toInt(), client.writeTimeoutMillis)
    }
}
