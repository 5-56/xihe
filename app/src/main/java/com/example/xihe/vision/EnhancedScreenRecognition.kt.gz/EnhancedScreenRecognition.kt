package com.example.xihe.vision

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import com.example.xihe.utils.LogManager
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.image.ops.ResizeOp
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min

/**
 * 👁️ 增强屏幕识别系统
 * 
 * 功能:
 * 1. 目标检测 (Object Detection)
 * 2. 模板匹配 (Template Matching)
 * 3. 文字识别增强 (Enhanced OCR)
 * 4. 图标识别 (Icon Recognition)
 * 5. 布局分析 (Layout Analysis)
 * 
 * 优化点:
 * - 从基础OCR -> 多模态识别
 * - 更准确的元素定位
 * - 支持复杂界面分析
 * - 自适应不同分辨率
 */
class EnhancedScreenRecognition(
    private val context: Context
) {
    
    companion object {
        private const val TAG = "EnhancedRecognition"
        
        // 模型参数
        private const val INPUT_SIZE = 320
        private const val NUM_CLASSES = 91  // COCO 数据集类别数
        private const val CONFIDENCE_THRESHOLD = 0.5f
        private const val IOU_THRESHOLD = 0.45f
    }
    
    // TFLite 解释器 (目标检测模型)
    private var objectDetector: Interpreter? = null
    
    // 模板库
    private val templateLibrary = mutableMapOf<String, Bitmap>()
    
    // OCR 引擎
    private val ocrEngine = OCREngine(context)
    
    init {
        initializeModels()
    }
    
    /**
     * 🔧 初始化模型
     */
    private fun initializeModels() {
        try {
            // 加载目标检测模型
            val options = Interpreter.Options().apply {
                setNumThreads(4)  // 多线程加速
                setUseNNAPI(true)  // 使用 NNAPI 硬件加速
            }
            
            // TODO: 实际部署时需要添加模型文件到 assets
            // objectDetector = Interpreter(loadModelFile("ssd_mobilenet_v2.tflite"), options)
            
            LogManager.d(TAG, "✅ 识别模型已初始化")
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 模型初始化失败: ${e.message}", e)
        }
    }
    
    /**
     * 🎯 智能目标检测
     * 使用深度学习模型检测屏幕上的各种UI元素
     */
    fun detectObjects(screenshot: Bitmap): List<DetectedObject> {
        try {
            if (objectDetector == null) {
                LogManager.w(TAG, "⚠️ 目标检测模型未加载，使用替代方案")
                return detectObjectsFallback(screenshot)
            }
            
            // 1. 预处理图像
            val resizedBitmap = Bitmap.createScaledBitmap(screenshot, INPUT_SIZE, INPUT_SIZE, true)
            val inputBuffer = preprocessImage(resizedBitmap)
            
            // 2. 运行推理
            val outputLocations = Array(1) { Array(10) { FloatArray(4) } }  // [1, 10, 4]
            val outputClasses = Array(1) { FloatArray(10) }  // [1, 10]
            val outputScores = Array(1) { FloatArray(10) }  // [1, 10]
            val numDetections = FloatArray(1)
            
            val outputs = mapOf(
                0 to outputLocations,
                1 to outputClasses,
                2 to outputScores,
                3 to numDetections
            )
            
            objectDetector?.runForMultipleInputsOutputs(arrayOf(inputBuffer), outputs)
            
            // 3. 后处理结果
            val detectedObjects = mutableListOf<DetectedObject>()
            val count = numDetections[0].toInt()
            
            for (i in 0 until count) {
                val score = outputScores[0][i]
                if (score >= CONFIDENCE_THRESHOLD) {
                    val location = outputLocations[0][i]
                    val classId = outputClasses[0][i].toInt()
                    
                    // 转换坐标到原图尺寸
                    val box = Rect(
                        (location[1] * screenshot.width).toInt(),
                        (location[0] * screenshot.height).toInt(),
                        (location[3] * screenshot.width).toInt(),
                        (location[2] * screenshot.height).toInt()
                    )
                    
                    detectedObjects.add(
                        DetectedObject(
                            classId = classId,
                            className = getClassName(classId),
                            confidence = score,
                            boundingBox = box,
                            recognitionMethod = RecognitionMethod.OBJECT_DETECTION
                        )
                    )
                }
            }
            
            // 4. 非极大值抑制 (NMS)
            return applyNMS(detectedObjects)
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 目标检测失败: ${e.message}", e)
            return emptyList()
        }
    }
    
    /**
     * 🔍 模板匹配
     * 在屏幕上查找指定模板的位置
     */
    fun matchTemplate(
        screenshot: Bitmap,
        templateName: String,
        threshold: Float = 0.8f
    ): List<MatchResult> {
        val template = templateLibrary[templateName]
        if (template == null) {
            LogManager.w(TAG, "⚠️ 模板不存在: $templateName")
            return emptyList()
        }
        
        return matchTemplate(screenshot, template, threshold)
    }
    
    /**
     * 🔍 模板匹配 (使用Bitmap)
     */
    fun matchTemplate(
        screenshot: Bitmap,
        template: Bitmap,
        threshold: Float = 0.8f
    ): List<MatchResult> {
        val results = mutableListOf<MatchResult>()
        
        try {
            val screenshotGray = convertToGrayscale(screenshot)
            val templateGray = convertToGrayscale(template)
            
            val templateWidth = template.width
            val templateHeight = template.height
            
            // 滑动窗口匹配
            for (y in 0 until screenshot.height - templateHeight step 5) {  // 步长5加速
                for (x in 0 until screenshot.width - templateWidth step 5) {
                    val similarity = calculateSimilarity(
                        screenshotGray, x, y,
                        templateGray, templateWidth, templateHeight
                    )
                    
                    if (similarity >= threshold) {
                        val boundingBox = Rect(x, y, x + templateWidth, y + templateHeight)
                        
                        // 检查是否与已有结果重叠
                        if (!isOverlapping(boundingBox, results)) {
                            results.add(
                                MatchResult(
                                    boundingBox = boundingBox,
                                    similarity = similarity,
                                    centerX = x + templateWidth / 2,
                                    centerY = y + templateHeight / 2
                                )
                            )
                        }
                    }
                }
            }
            
            // 按相似度排序
            results.sortByDescending { it.similarity }
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 模板匹配失败: ${e.message}", e)
        }
        
        return results.take(5)  // 最多返回5个最佳匹配
    }
    
    /**
     * 🔠 增强OCR识别
     * 结合多种OCR引擎，提高识别准确率
     * 🆕 使用 ML Kit 实现
     */
    suspend fun recognizeText(
        screenshot: Bitmap,
        region: Rect? = null
    ): List<TextElement> {
        return try {
            ocrEngine.recognizeText(screenshot, region)
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ OCR识别失败", e)
            emptyList()
        }
    }
    
    /**
     * 🔠 同步版OCR识别（使用缓存）
     */
    fun recognizeTextSync(
        screenshot: Bitmap,
        region: Rect? = null
    ): List<TextElement> {
        return ocrEngine.recognizeTextSync(screenshot, region)
    }
    
    /**
     * 🎯 查找屏幕上的特定文本
     * @return 找到的文本元素，包含位置信息
     */
    suspend fun findTextOnScreen(
        screenshot: Bitmap,
        targetText: String
    ): TextElement? {
        return ocrEngine.findText(screenshot, targetText)
    }
    
    /**
     * 📍 获取屏幕上所有可点击的文本
     */
    suspend fun getAllClickableTexts(screenshot: Bitmap): List<ClickableTextInfo> {
        return ocrEngine.getAllClickableTexts(screenshot)
    }
    
    /**
     * 🎨 图标识别
     * 识别常见的应用图标和UI图标
     */
    fun recognizeIcons(screenshot: Bitmap): List<RecognizedIcon> {
        val icons = mutableListOf<RecognizedIcon>()
        
        // 1. 检测可能的图标区域 (通常是正方形或接近正方形)
        val candidateRegions = detectIconRegions(screenshot)
        
        // 2. 对每个候选区域进行图标识别
        for (region in candidateRegions) {
            val iconBitmap = Bitmap.createBitmap(
                screenshot,
                region.left,
                region.top,
                region.width(),
                region.height()
            )
            
            // 与已知图标模板匹配
            val matchedIconName = matchIconWithLibrary(iconBitmap)
            
            if (matchedIconName != null) {
                icons.add(
                    RecognizedIcon(
                        name = matchedIconName,
                        boundingBox = region,
                        confidence = 0.85f
                    )
                )
            }
        }
        
        return icons
    }
    
    /**
     * 📐 布局分析
     * 分析屏幕的布局结构，识别不同的UI区域
     */
    fun analyzeLayout(screenshot: Bitmap): LayoutAnalysis {
        val regions = mutableListOf<LayoutRegion>()
        
        // 1. 边缘检测
        val edges = detectEdges(screenshot)
        
        // 2. 轮廓检测
        val contours = findContours(edges)
        
        // 3. 分组相似区域
        val groupedRegions = groupRegions(contours)
        
        // 4. 分类区域类型
        for (regionContour in groupedRegions) {
            val regionType = classifyRegionType(regionContour, screenshot)
            val boundingBox = getBoundingBox(regionContour)
            
            regions.add(
                LayoutRegion(
                    type = regionType,
                    boundingBox = boundingBox,
                    confidence = 0.7f
                )
            )
        }
        
        return LayoutAnalysis(
            regions = regions,
            topBarHeight = detectTopBarHeight(screenshot),
            bottomBarHeight = detectBottomBarHeight(screenshot),
            contentArea = detectContentArea(regions)
        )
    }
    
    /**
     * 🧠 智能元素定位
     * 结合多种识别方法，智能定位目标元素
     */
    fun locateElement(
        screenshot: Bitmap,
        description: String,
        elementType: ElementType? = null
    ): ElementLocation? {
        LogManager.d(TAG, "🎯 智能定位元素: $description")
        
        // 1. 先尝试OCR文本匹配（使用同步版本）
        val textElements = recognizeTextSync(screenshot)
        val matchedText = textElements.find { 
            it.text.contains(description, ignoreCase = true) 
        }
        
        if (matchedText != null) {
            LogManager.d(TAG, "✅ 通过OCR找到元素")
            return ElementLocation(
                boundingBox = matchedText.boundingBox,
                centerX = matchedText.boundingBox.centerX(),
                centerY = matchedText.boundingBox.centerY(),
                confidence = matchedText.confidence,
                method = RecognitionMethod.OCR
            )
        }
        
        // 2. 尝试图标识别
        if (elementType == ElementType.ICON || elementType == null) {
            val icons = recognizeIcons(screenshot)
            val matchedIcon = icons.find { 
                it.name.contains(description, ignoreCase = true) 
            }
            
            if (matchedIcon != null) {
                LogManager.d(TAG, "✅ 通过图标识别找到元素")
                return ElementLocation(
                    boundingBox = matchedIcon.boundingBox,
                    centerX = matchedIcon.boundingBox.centerX(),
                    centerY = matchedIcon.boundingBox.centerY(),
                    confidence = matchedIcon.confidence,
                    method = RecognitionMethod.ICON_RECOGNITION
                )
            }
        }
        
        // 3. 尝试模板匹配
        if (templateLibrary.containsKey(description)) {
            val matches = matchTemplate(screenshot, description)
            if (matches.isNotEmpty()) {
                val bestMatch = matches.first()
                LogManager.d(TAG, "✅ 通过模板匹配找到元素")
                return ElementLocation(
                    boundingBox = bestMatch.boundingBox,
                    centerX = bestMatch.centerX,
                    centerY = bestMatch.centerY,
                    confidence = bestMatch.similarity,
                    method = RecognitionMethod.TEMPLATE_MATCHING
                )
            }
        }
        
        LogManager.w(TAG, "❌ 未找到匹配的元素")
        return null
    }
    
    /**
     * 📚 添加模板
     */
    fun addTemplate(name: String, template: Bitmap) {
        templateLibrary[name] = template
        LogManager.d(TAG, "✅ 已添加模板: $name")
    }
    
    /**
     * 🧹 清理资源
     */
    fun release() {
        objectDetector?.close()
        ocrEngine.release()
        templateLibrary.clear()
        LogManager.d(TAG, "🧹 资源已释放")
    }
    
    // ==================== 辅助方法 ====================
    
    private fun preprocessImage(bitmap: Bitmap): ByteBuffer {
        val buffer = ByteBuffer.allocateDirect(4 * INPUT_SIZE * INPUT_SIZE * 3)
        buffer.order(ByteOrder.nativeOrder())
        
        val pixels = IntArray(INPUT_SIZE * INPUT_SIZE)
        bitmap.getPixels(pixels, 0, INPUT_SIZE, 0, 0, INPUT_SIZE, INPUT_SIZE)
        
        for (pixel in pixels) {
            buffer.putFloat(((pixel shr 16) and 0xFF) / 255.0f)  // R
            buffer.putFloat(((pixel shr 8) and 0xFF) / 255.0f)   // G
            buffer.putFloat((pixel and 0xFF) / 255.0f)           // B
        }
        
        return buffer
    }
    
    private fun applyNMS(
        detections: List<DetectedObject>,
        iouThreshold: Float = IOU_THRESHOLD
    ): List<DetectedObject> {
        if (detections.isEmpty()) return emptyList()
        
        val sorted = detections.sortedByDescending { it.confidence }
        val selected = mutableListOf<DetectedObject>()
        
        for (detection in sorted) {
            var shouldKeep = true
            
            for (kept in selected) {
                val iou = calculateIoU(detection.boundingBox, kept.boundingBox)
                if (iou > iouThreshold) {
                    shouldKeep = false
                    break
                }
            }
            
            if (shouldKeep) {
                selected.add(detection)
            }
        }
        
        return selected
    }
    
    private fun calculateIoU(box1: Rect, box2: Rect): Float {
        val intersectionArea = max(0, min(box1.right, box2.right) - max(box1.left, box2.left)) *
                             max(0, min(box1.bottom, box2.bottom) - max(box1.top, box2.top))
        
        val box1Area = box1.width() * box1.height()
        val box2Area = box2.width() * box2.height()
        val unionArea = box1Area + box2Area - intersectionArea
        
        return if (unionArea > 0) intersectionArea.toFloat() / unionArea else 0f
    }
    
    private fun convertToGrayscale(bitmap: Bitmap): IntArray {
        val width = bitmap.width
        val height = bitmap.height
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        
        for (i in pixels.indices) {
            val pixel = pixels[i]
            val r = (pixel shr 16) and 0xFF
            val g = (pixel shr 8) and 0xFF
            val b = pixel and 0xFF
            pixels[i] = (0.299 * r + 0.587 * g + 0.114 * b).toInt()
        }
        
        return pixels
    }
    
    private fun calculateSimilarity(
        image: IntArray,
        x: Int,
        y: Int,
        template: IntArray,
        templateWidth: Int,
        templateHeight: Int
    ): Float {
        // 使用归一化互相关 (Normalized Cross-Correlation)
        // 简化实现，实际可以使用更复杂的算法
        var sum = 0f
        var count = 0
        
        for (ty in 0 until templateHeight) {
            for (tx in 0 until templateWidth) {
                val imgPixel = image[(y + ty) * templateWidth + (x + tx)]
                val tmpPixel = template[ty * templateWidth + tx]
                sum += 1 - kotlin.math.abs(imgPixel - tmpPixel) / 255.0f
                count++
            }
        }
        
        return if (count > 0) sum / count else 0f
    }
    
    private fun isOverlapping(box: Rect, results: List<MatchResult>): Boolean {
        for (result in results) {
            if (calculateIoU(box, result.boundingBox) > 0.5f) {
                return true
            }
        }
        return false
    }
    
    private fun detectObjectsFallback(screenshot: Bitmap): List<DetectedObject> {
        // 降级方案：使用基础图像处理检测UI元素
        val detectedObjects = mutableListOf<DetectedObject>()
        val width = screenshot.width
        val height = screenshot.height
        
        try {
            // 1. 检测可能的按钮区域（通过颜色分析和边缘检测）
            val buttonRegions = detectButtonRegions(screenshot)
            buttonRegions.forEachIndexed { index, region ->
                detectedObjects.add(
                    DetectedObject(
                        classId = 100 + index,
                        className = "button",
                        confidence = 0.7f,
                        boundingBox = region,
                        recognitionMethod = RecognitionMethod.FALLBACK
                    )
                )
            }
            
            // 2. 检测输入框区域（通常是较宽的矩形区域）
            val inputRegions = detectInputRegions(screenshot)
            inputRegions.forEachIndexed { index, region ->
                detectedObjects.add(
                    DetectedObject(
                        classId = 200 + index,
                        className = "input_field",
                        confidence = 0.65f,
                        boundingBox = region,
                        recognitionMethod = RecognitionMethod.FALLBACK
                    )
                )
            }
            
            // 3. 检测图标区域
            val iconRegions = detectIconRegions(screenshot).take(10)
            iconRegions.forEachIndexed { index, region ->
                detectedObjects.add(
                    DetectedObject(
                        classId = 300 + index,
                        className = "icon",
                        confidence = 0.6f,
                        boundingBox = region,
                        recognitionMethod = RecognitionMethod.FALLBACK
                    )
                )
            }
            
            LogManager.d(TAG, "✅ Fallback检测完成: ${detectedObjects.size}个元素")
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ Fallback检测失败: ${e.message}", e)
        }
        
        return detectedObjects
    }
    
    /**
     * 🔘 检测按钮区域
     */
    private fun detectButtonRegions(screenshot: Bitmap): List<Rect> {
        val regions = mutableListOf<Rect>()
        val width = screenshot.width
        val height = screenshot.height
        
        // 按钮通常有明显的背景色，检测颜色突变区域
        val minButtonWidth = (width * 0.15).toInt().coerceAtLeast(60)
        val maxButtonWidth = (width * 0.9).toInt()
        val minButtonHeight = 40
        val maxButtonHeight = 80
        
        val stepX = minButtonWidth / 2
        val stepY = minButtonHeight / 2
        
        for (y in 0 until height - minButtonHeight step stepY) {
            for (x in 0 until width - minButtonWidth step stepX) {
                // 检查不同尺寸的区域
                for (bw in listOf(minButtonWidth, minButtonWidth * 2, maxButtonWidth / 2)) {
                    for (bh in listOf(minButtonHeight, maxButtonHeight)) {
                        if (x + bw > width || y + bh > height) continue
                        
                        val region = Rect(x, y, x + bw, y + bh)
                        if (isLikelyButton(screenshot, region)) {
                            if (!regions.any { calculateIoU(it, region) > 0.3f }) {
                                regions.add(region)
                            }
                        }
                    }
                }
            }
        }
        
        return regions.take(20)
    }
    
    /**
     * 🔍 检查是否像按钮
     */
    private fun isLikelyButton(bitmap: Bitmap, region: Rect): Boolean {
        try {
            val regionWidth = region.width().coerceAtMost(bitmap.width - region.left)
            val regionHeight = region.height().coerceAtMost(bitmap.height - region.top)
            if (regionWidth <= 0 || regionHeight <= 0) return false
            
            // 按钮通常宽高比大于2
            val aspectRatio = regionWidth.toFloat() / regionHeight
            if (aspectRatio < 1.5f || aspectRatio > 10f) return false
            
            // 检查颜色均匀性（按钮通常有统一的背景色）
            val pixels = IntArray(regionWidth * regionHeight)
            bitmap.getPixels(pixels, 0, regionWidth, region.left, region.top, regionWidth, regionHeight)
            
            val firstPixel = pixels[0]
            var similarCount = 0
            for (pixel in pixels) {
                if (isSimilarColor(pixel, firstPixel, 30)) {
                    similarCount++
                }
            }
            
            val uniformity = similarCount.toFloat() / pixels.size
            return uniformity > 0.6f  // 60%以上颜色相近
            
        } catch (e: Exception) {
            return false
        }
    }
    
    /**
     * 📝 检测输入框区域
     */
    private fun detectInputRegions(screenshot: Bitmap): List<Rect> {
        val regions = mutableListOf<Rect>()
        val width = screenshot.width
        val height = screenshot.height
        
        // 输入框通常是较宽的矩形，有边框
        val minInputWidth = (width * 0.5).toInt()
        val inputHeight = 50
        
        for (y in 0 until height - inputHeight step 30) {
            for (x in 0 until (width * 0.3).toInt() step 20) {
                val region = Rect(x, y, x + minInputWidth, y + inputHeight)
                if (isLikelyInputField(screenshot, region)) {
                    if (!regions.any { calculateIoU(it, region) > 0.3f }) {
                        regions.add(region)
                    }
                }
            }
        }
        
        return regions.take(10)
    }
    
    /**
     * 🔍 检查是否像输入框
     */
    private fun isLikelyInputField(bitmap: Bitmap, region: Rect): Boolean {
        try {
            val regionWidth = region.width().coerceAtMost(bitmap.width - region.left)
            val regionHeight = region.height().coerceAtMost(bitmap.height - region.top)
            if (regionWidth <= 0 || regionHeight <= 0) return false
            
            // 输入框宽高比通常大于5
            val aspectRatio = regionWidth.toFloat() / regionHeight
            if (aspectRatio < 4f) return false
            
            // 输入框通常背景较浅或较深（对比色）
            val pixels = IntArray(regionWidth * regionHeight)
            bitmap.getPixels(pixels, 0, regionWidth, region.left, region.top, regionWidth, regionHeight)
            
            // 检查边缘是否有边框
            val edgePixels = mutableListOf<Int>()
            for (x in 0 until regionWidth) {
                edgePixels.add(pixels[x])  // 上边
                edgePixels.add(pixels[(regionHeight - 1) * regionWidth + x])  // 下边
            }
            
            val centerPixel = pixels[regionHeight / 2 * regionWidth + regionWidth / 2]
            var borderCount = 0
            for (edgePixel in edgePixels) {
                if (!isSimilarColor(edgePixel, centerPixel, 50)) {
                    borderCount++
                }
            }
            
            return borderCount > edgePixels.size * 0.3f  // 30%以上边缘与中心不同
            
        } catch (e: Exception) {
            return false
        }
    }
    
    /**
     * 🎨 判断两个颜色是否相近
     */
    private fun isSimilarColor(color1: Int, color2: Int, threshold: Int): Boolean {
        val r1 = (color1 shr 16) and 0xFF
        val g1 = (color1 shr 8) and 0xFF
        val b1 = color1 and 0xFF
        
        val r2 = (color2 shr 16) and 0xFF
        val g2 = (color2 shr 8) and 0xFF
        val b2 = color2 and 0xFF
        
        return kotlin.math.abs(r1 - r2) < threshold &&
               kotlin.math.abs(g1 - g2) < threshold &&
               kotlin.math.abs(b1 - b2) < threshold
    }
    
    private fun getClassName(classId: Int): String {
        // COCO 数据集类别映射（简化版）
        return "object_$classId"
    }
    
    /**
     * 🎯 检测图标区域
     * 通过分析图像特征找出可能的图标位置
     */
    private fun detectIconRegions(screenshot: Bitmap): List<Rect> {
        val regions = mutableListOf<Rect>()
        val width = screenshot.width
        val height = screenshot.height
        
        // 图标通常的尺寸范围
        val minIconSize = (width * 0.05).toInt().coerceAtLeast(32)  // 最小图标
        val maxIconSize = (width * 0.25).toInt().coerceAtMost(256) // 最大图标
        
        // 滑动窗口检测
        val stepSize = minIconSize / 2
        
        for (y in 0 until height - minIconSize step stepSize) {
            for (x in 0 until width - minIconSize step stepSize) {
                // 检查不同尺寸的窗口
                for (size in listOf(minIconSize, minIconSize * 2, maxIconSize)) {
                    if (x + size > width || y + size > height) continue
                    
                    val region = Rect(x, y, x + size, y + size)
                    
                    // 检查是否像图标（接近正方形、有边界、内容丰富）
                    if (isLikelyIcon(screenshot, region)) {
                        // 避免重叠
                        if (!regions.any { calculateIoU(it, region) > 0.5f }) {
                            regions.add(region)
                        }
                    }
                }
            }
        }
        
        return regions.take(50) // 最多返回50个区域
    }
    
    /**
     * 🔍 检查区域是否像图标
     */
    private fun isLikelyIcon(bitmap: Bitmap, region: Rect): Boolean {
        try {
            // 裁剪区域
            val iconBitmap = Bitmap.createBitmap(
                bitmap, 
                region.left, 
                region.top,
                region.width().coerceAtMost(bitmap.width - region.left),
                region.height().coerceAtMost(bitmap.height - region.top)
            )
            
            val width = iconBitmap.width
            val height = iconBitmap.height
            
            // 1. 检查宽高比（图标通常接近正方形）
            val aspectRatio = width.toFloat() / height
            if (aspectRatio < 0.7f || aspectRatio > 1.4f) return false
            
            // 2. 检查边缘像素（图标通常有清晰边界）
            val edgePixels = getEdgePixels(iconBitmap)
            val edgeVariance = calculateVariance(edgePixels)
            
            // 边缘应该有一定变化（不是纯色块）
            if (edgeVariance < 500) return false
            
            // 3. 检查颜色丰富度
            val colorCount = countUniqueColors(iconBitmap, 16) // 量化到每通道16级
            if (colorCount < 3) return false // 太单调
            
            return true
        } catch (e: Exception) {
            return false
        }
    }
    
    private fun getEdgePixels(bitmap: Bitmap): IntArray {
        val width = bitmap.width
        val height = bitmap.height
        val edges = mutableListOf<Int>()
        
        // 上边缘
        for (x in 0 until width) {
            edges.add(bitmap.getPixel(x, 0))
        }
        // 下边缘
        for (x in 0 until width) {
            edges.add(bitmap.getPixel(x, height - 1))
        }
        // 左边缘
        for (y in 0 until height) {
            edges.add(bitmap.getPixel(0, y))
        }
        // 右边缘
        for (y in 0 until height) {
            edges.add(bitmap.getPixel(width - 1, y))
        }
        
        return edges.toIntArray()
    }
    
    private fun calculateVariance(pixels: IntArray): Double {
        if (pixels.isEmpty()) return 0.0
        
        val values = pixels.map { pixel ->
            val r = (pixel shr 16) and 0xFF
            val g = (pixel shr 8) and 0xFF
            val b = pixel and 0xFF
            (r + g + b) / 3.0
        }
        
        val mean = values.average()
        return values.sumOf { (it - mean) * (it - mean) } / values.size
    }
    
    private fun countUniqueColors(bitmap: Bitmap, levels: Int): Int {
        val colorSet = mutableSetOf<Int>()
        val step = 256 / levels
        
        for (y in 0 until bitmap.height step 2) {
            for (x in 0 until bitmap.width step 2) {
                val pixel = bitmap.getPixel(x, y)
                val r = ((pixel shr 16) and 0xFF) / step
                val g = ((pixel shr 8) and 0xFF) / step
                val b = (pixel and 0xFF) / step
                colorSet.add((r shl 16) or (g shl 8) or b)
            }
        }
        
        return colorSet.size
    }
    
    /**
     * 🎯 与图标库匹配
     * 使用颜色直方图和特征匹配
     */
    private fun matchIconWithLibrary(iconBitmap: Bitmap): String? {
        // 常见图标特征库
        val iconFeatures = mapOf(
            "设置" to IconFeature(dominantColors = listOf(0xFF808080.toInt()), hasGear = true),
            "电话" to IconFeature(dominantColors = listOf(0xFF4CAF50.toInt()), hasPhone = true),
            "相机" to IconFeature(dominantColors = listOf(0xFF333333.toInt()), hasCircle = true),
            "图库" to IconFeature(dominantColors = listOf(0xFF2196F3.toInt(), 0xFF4CAF50.toInt())),
            "浏览器" to IconFeature(dominantColors = listOf(0xFF4285F4.toInt(), 0xFFEA4335.toInt())),
            "微信" to IconFeature(dominantColors = listOf(0xFF07C160.toInt()), shape = "rounded"),
            "QQ" to IconFeature(dominantColors = listOf(0xFF12B7F5.toInt()), shape = "penguin"),
            "支付宝" to IconFeature(dominantColors = listOf(0xFF1677FF.toInt()), shape = "rounded"),
            "抖音" to IconFeature(dominantColors = listOf(0xFF000000.toInt(), 0xFFFF0050.toInt())),
            "淘宝" to IconFeature(dominantColors = listOf(0xFFFF5000.toInt())),
            "美团" to IconFeature(dominantColors = listOf(0xFFFFD100.toInt())),
            "饿了么" to IconFeature(dominantColors = listOf(0xFF0097FF.toInt())),
            "哔哩哔哩" to IconFeature(dominantColors = listOf(0xFFFF6699.toInt())),
            "京东" to IconFeature(dominantColors = listOf(0xFFE2231A.toInt())),
            "拼多多" to IconFeature(dominantColors = listOf(0xFFE02E24.toInt()))
        )
        
        // 提取当前图标的主色
        val dominantColor = extractDominantColor(iconBitmap)
        
        // 匹配最接近的图标
        var bestMatch: String? = null
        var bestScore = 0f
        
        for ((name, feature) in iconFeatures) {
            var score = 0f
            
            // 颜色匹配
            for (targetColor in feature.dominantColors) {
                val colorSimilarity = calculateColorSimilarity(dominantColor, targetColor)
                if (colorSimilarity > 0.7f) {
                    score += colorSimilarity
                }
            }
            
            if (score > bestScore && score > 0.6f) {
                bestScore = score
                bestMatch = name
            }
        }
        
        return bestMatch
    }
    
    /**
     * 提取主色
     */
    private fun extractDominantColor(bitmap: Bitmap): Int {
        val colorCount = mutableMapOf<Int, Int>()
        
        for (y in 0 until bitmap.height step 4) {
            for (x in 0 until bitmap.width step 4) {
                val pixel = bitmap.getPixel(x, y)
                // 忽略透明和接近白色/黑色的像素
                val alpha = (pixel shr 24) and 0xFF
                val r = (pixel shr 16) and 0xFF
                val g = (pixel shr 8) and 0xFF
                val b = pixel and 0xFF
                
                if (alpha < 128) continue
                if (r > 240 && g > 240 && b > 240) continue // 白色
                if (r < 15 && g < 15 && b < 15) continue // 黑色
                
                // 量化颜色
                val quantized = ((r / 32) shl 16) or ((g / 32) shl 8) or (b / 32)
                colorCount[quantized] = (colorCount[quantized] ?: 0) + 1
            }
        }
        
        // 返回出现最多的颜色
        val dominant = colorCount.maxByOrNull { it.value }?.key ?: 0
        
        // 还原颜色
        val r = ((dominant shr 16) and 0xFF) * 32 + 16
        val g = ((dominant shr 8) and 0xFF) * 32 + 16
        val b = (dominant and 0xFF) * 32 + 16
        
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    }
    
    /**
     * 计算颜色相似度
     */
    private fun calculateColorSimilarity(color1: Int, color2: Int): Float {
        val r1 = (color1 shr 16) and 0xFF
        val g1 = (color1 shr 8) and 0xFF
        val b1 = color1 and 0xFF
        
        val r2 = (color2 shr 16) and 0xFF
        val g2 = (color2 shr 8) and 0xFF
        val b2 = color2 and 0xFF
        
        val distance = kotlin.math.sqrt(
            ((r1 - r2) * (r1 - r2) + (g1 - g2) * (g1 - g2) + (b1 - b2) * (b1 - b2)).toDouble()
        )
        
        // 最大距离约 441 (sqrt(255^2 * 3))
        return (1 - distance / 441).toFloat().coerceIn(0f, 1f)
    }
    
    /**
     * 图标特征
     */
    private data class IconFeature(
        val dominantColors: List<Int>,
        val hasGear: Boolean = false,
        val hasPhone: Boolean = false,
        val hasCircle: Boolean = false,
        val shape: String = ""
    )
    
    /**
     * 📷 边缘检测 (Sobel 算子)
     */
    private fun detectEdges(bitmap: Bitmap): IntArray {
        val width = bitmap.width
        val height = bitmap.height
        val grayscale = convertToGrayscale(bitmap)
        val edges = IntArray(width * height)
        
        // Sobel 算子
        val sobelX = arrayOf(
            intArrayOf(-1, 0, 1),
            intArrayOf(-2, 0, 2),
            intArrayOf(-1, 0, 1)
        )
        val sobelY = arrayOf(
            intArrayOf(-1, -2, -1),
            intArrayOf(0, 0, 0),
            intArrayOf(1, 2, 1)
        )
        
        for (y in 1 until height - 1) {
            for (x in 1 until width - 1) {
                var gx = 0
                var gy = 0
                
                for (ky in -1..1) {
                    for (kx in -1..1) {
                        val pixel = grayscale[(y + ky) * width + (x + kx)]
                        gx += pixel * sobelX[ky + 1][kx + 1]
                        gy += pixel * sobelY[ky + 1][kx + 1]
                    }
                }
                
                val magnitude = kotlin.math.sqrt((gx * gx + gy * gy).toDouble()).toInt()
                edges[y * width + x] = magnitude.coerceIn(0, 255)
            }
        }
        
        return edges
    }
    
    /**
     * 🔍 查找轮廓
     * 使用连通区域标记算法
     */
    private fun findContours(edges: IntArray, width: Int, height: Int, threshold: Int = 50): List<List<Pair<Int, Int>>> {
        val visited = BooleanArray(edges.size)
        val contours = mutableListOf<List<Pair<Int, Int>>>()
        
        for (y in 0 until height) {
            for (x in 0 until width) {
                val idx = y * width + x
                if (!visited[idx] && edges[idx] > threshold) {
                    // BFS 查找连通区域
                    val contour = mutableListOf<Pair<Int, Int>>()
                    val queue = ArrayDeque<Pair<Int, Int>>()
                    queue.add(Pair(x, y))
                    
                    while (queue.isNotEmpty()) {
                        val (cx, cy) = queue.removeFirst()
                        val cidx = cy * width + cx
                        
                        if (cx < 0 || cx >= width || cy < 0 || cy >= height) continue
                        if (visited[cidx]) continue
                        if (edges[cidx] <= threshold) continue
                        
                        visited[cidx] = true
                        contour.add(Pair(cx, cy))
                        
                        // 8连通
                        for (dy in -1..1) {
                            for (dx in -1..1) {
                                if (dx == 0 && dy == 0) continue
                                queue.add(Pair(cx + dx, cy + dy))
                            }
                        }
                    }
                    
                    if (contour.size > 10) { // 过滤太小的轮廓
                        contours.add(contour)
                    }
                }
            }
        }
        
        return contours
    }
    
    // 保持旧函数签名兼容
    private fun findContours(edges: IntArray): List<List<Pair<Int, Int>>> {
        // 默认假设正方形图像
        val size = kotlin.math.sqrt(edges.size.toDouble()).toInt()
        return findContours(edges, size, size)
    }
    
    private fun groupRegions(contours: List<List<Pair<Int, Int>>>): List<List<Pair<Int, Int>>> {
        // TODO: 区域分组
        return contours
    }
    
    private fun classifyRegionType(
        contour: List<Pair<Int, Int>>,
        screenshot: Bitmap
    ): RegionType {
        // TODO: 区域类型分类
        return RegionType.UNKNOWN
    }
    
    private fun getBoundingBox(contour: List<Pair<Int, Int>>): Rect {
        if (contour.isEmpty()) return Rect()
        
        val left = contour.minOf { it.first }
        val top = contour.minOf { it.second }
        val right = contour.maxOf { it.first }
        val bottom = contour.maxOf { it.second }
        
        return Rect(left, top, right, bottom)
    }
    
    private fun detectTopBarHeight(screenshot: Bitmap): Int {
        // 简单启发式：顶部栏通常是固定高度
        return (screenshot.height * 0.08).toInt()
    }
    
    private fun detectBottomBarHeight(screenshot: Bitmap): Int {
        // 简单启发式：底部栏通常是固定高度
        return (screenshot.height * 0.08).toInt()
    }
    
    private fun detectContentArea(regions: List<LayoutRegion>): Rect {
        // 内容区域通常是最大的区域
        return regions.maxByOrNull { 
            it.boundingBox.width() * it.boundingBox.height() 
        }?.boundingBox ?: Rect()
    }
}

// ==================== OCR引擎 (使用 ML Kit) ====================

/**
 * 🆕 OCR引擎 - 使用 Google ML Kit 实现
 * 
 * 集成 OCRManager，支持：
 * - 中英文混合识别
 * - 离线模式
 * - 区域识别
 */
class OCREngine(private val context: Context) {
    
    private val ocrManager by lazy { 
        com.example.xihe.ocr.OCRManager.getInstance(context) 
    }
    
    /**
     * 🔍 识别图片中的文字
     * @param bitmap 要识别的图片
     * @param region 可选的识别区域（null表示全图）
     * @return 识别到的文本元素列表
     */
    suspend fun recognizeText(bitmap: Bitmap, region: Rect?): List<TextElement> {
        return try {
            // 如果指定了区域，裁剪图片
            val targetBitmap = if (region != null && isValidRegion(region, bitmap)) {
                Bitmap.createBitmap(
                    bitmap,
                    region.left.coerceIn(0, bitmap.width - 1),
                    region.top.coerceIn(0, bitmap.height - 1),
                    (region.width()).coerceIn(1, bitmap.width - region.left),
                    (region.height()).coerceIn(1, bitmap.height - region.top)
                )
            } else {
                bitmap
            }
            
            // 使用 OCRManager 进行识别
            val result = ocrManager.recognizeText(targetBitmap, preferChinese = true)
            
            // 转换结果格式
            result.textBlocks.flatMap { block ->
                block.lines.map { line ->
                    val box = line.boundingBox ?: Rect()
                    // 如果裁剪了图片，需要调整坐标
                    val adjustedBox = if (region != null) {
                        Rect(
                            box.left + region.left,
                            box.top + region.top,
                            box.right + region.left,
                            box.bottom + region.top
                        )
                    } else {
                        box
                    }
                    TextElement(
                        text = line.text,
                        boundingBox = adjustedBox,
                        confidence = 0.9f  // ML Kit 不直接提供行级置信度
                    )
                }
            }
        } catch (e: Exception) {
            com.example.xihe.utils.LogManager.e("OCREngine", "OCR识别失败", e)
            emptyList()
        }
    }
    
    /**
     * 🔍 同步版本（用于兼容）
     */
    fun recognizeTextSync(bitmap: Bitmap, region: Rect?): List<TextElement> {
        // 尝试获取缓存结果
        val cached = ocrManager.getCachedResult()
        if (cached != null) {
            return cached.textBlocks.flatMap { block ->
                block.lines.map { line ->
                    TextElement(
                        text = line.text,
                        boundingBox = line.boundingBox ?: Rect(),
                        confidence = 0.9f
                    )
                }
            }
        }
        return emptyList()
    }
    
    /**
     * 🎯 查找特定文本
     */
    suspend fun findText(bitmap: Bitmap, targetText: String): TextElement? {
        val result = ocrManager.recognizeText(bitmap)
        val matches = ocrManager.findTextInResult(result, targetText, fuzzyMatch = true)
        
        return matches.firstOrNull()?.let { match ->
            TextElement(
                text = match.text,
                boundingBox = match.boundingBox ?: Rect(),
                confidence = match.similarity
            )
        }
    }
    
    /**
     * 📍 获取指定位置的文本
     */
    suspend fun getTextAtPosition(bitmap: Bitmap, x: Int, y: Int): String? {
        val result = ocrManager.recognizeText(bitmap)
        return ocrManager.findTextNearPosition(result, x, y)?.text
    }
    
    /**
     * 📊 获取所有可点击文本位置
     */
    suspend fun getAllClickableTexts(bitmap: Bitmap): List<ClickableTextInfo> {
        val result = ocrManager.recognizeText(bitmap)
        return ocrManager.getAllClickableTextPositions(result).map { clickable ->
            ClickableTextInfo(
                text = clickable.text,
                centerX = clickable.centerX,
                centerY = clickable.centerY,
                boundingBox = clickable.boundingBox
            )
        }
    }
    
    /**
     * ✅ 验证区域有效性
     */
    private fun isValidRegion(region: Rect, bitmap: Bitmap): Boolean {
        return region.left >= 0 && 
               region.top >= 0 && 
               region.right <= bitmap.width && 
               region.bottom <= bitmap.height &&
               region.width() > 0 && 
               region.height() > 0
    }
    
    /**
     * 🧹 释放资源
     */
    fun release() {
        ocrManager.cleanup()
    }
}

/**
 * 📍 可点击文本信息
 */
data class ClickableTextInfo(
    val text: String,
    val centerX: Int,
    val centerY: Int,
    val boundingBox: Rect
)

// ==================== 数据类 ====================

/**
 * 🎯 检测到的对象
 */
data class DetectedObject(
    val classId: Int,
    val className: String,
    val confidence: Float,
    val boundingBox: Rect,
    val recognitionMethod: RecognitionMethod
)

/**
 * 🔍 匹配结果
 */
data class MatchResult(
    val boundingBox: Rect,
    val similarity: Float,
    val centerX: Int,
    val centerY: Int
)

/**
 * 🔠 文本元素
 */
data class TextElement(
    val text: String,
    val boundingBox: Rect,
    val confidence: Float
)

/**
 * 🎨 识别的图标
 */
data class RecognizedIcon(
    val name: String,
    val boundingBox: Rect,
    val confidence: Float
)

/**
 * 📐 布局分析
 */
data class LayoutAnalysis(
    val regions: List<LayoutRegion>,
    val topBarHeight: Int,
    val bottomBarHeight: Int,
    val contentArea: Rect
)

/**
 * 📦 布局区域
 */
data class LayoutRegion(
    val type: RegionType,
    val boundingBox: Rect,
    val confidence: Float
)

/**
 * 📍 元素位置
 */
data class ElementLocation(
    val boundingBox: Rect,
    val centerX: Int,
    val centerY: Int,
    val confidence: Float,
    val method: RecognitionMethod
)

/**
 * 🔧 识别方法
 */
enum class RecognitionMethod {
    OBJECT_DETECTION,       // 目标检测
    TEMPLATE_MATCHING,      // 模板匹配
    OCR,                    // 文字识别
    ICON_RECOGNITION,       // 图标识别
    LAYOUT_ANALYSIS,        // 布局分析
    FALLBACK                // 降级方案（基础图像处理）
}

/**
 * 🎨 元素类型
 */
enum class ElementType {
    BUTTON,         // 按钮
    TEXT,           // 文本
    INPUT,          // 输入框
    ICON,           // 图标
    IMAGE,          // 图片
    LIST,           // 列表
    UNKNOWN         // 未知
}

/**
 * 📐 区域类型
 */
enum class RegionType {
    HEADER,         // 标题栏
    CONTENT,        // 内容区
    FOOTER,         // 底部栏
    SIDEBAR,        // 侧边栏
    DIALOG,         // 对话框
    UNKNOWN         // 未知
}

