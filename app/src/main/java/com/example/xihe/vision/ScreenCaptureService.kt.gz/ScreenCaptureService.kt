package com.example.xihe.vision

import android.app.Activity
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import com.example.xihe.utils.LogManager
import android.view.WindowManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.util.concurrent.CountDownLatch

/**
 * 屏幕截图服务 - 用于AI视觉理解
 * 
 * 功能：
 * 1. 实时捕获屏幕截图
 * 2. 转换为Base64供Vision API使用
 * 3. 支持按需截图和定时截图
 */
class ScreenCaptureService : Service() {
    
    companion object {
        private const val TAG = "ScreenCaptureService"
        
        var instance: ScreenCaptureService? = null
            private set
        
        private val _isCapturing = MutableStateFlow(false)
        val isCapturing = _isCapturing.asStateFlow()
        
        private val _lastScreenshot = MutableStateFlow<Bitmap?>(null)
        val lastScreenshot = _lastScreenshot.asStateFlow()
        
        // 用于请求屏幕截图权限
        const val REQUEST_CODE_SCREEN_CAPTURE = 1001
        
        // Intent Actions
        const val ACTION_START_CAPTURE = "com.example.xihe.ACTION_START_CAPTURE"
        const val ACTION_STOP_CAPTURE = "com.example.xihe.ACTION_STOP_CAPTURE"
        const val ACTION_TAKE_SCREENSHOT = "com.example.xihe.ACTION_TAKE_SCREENSHOT"
        
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "data"
    }
    
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var captureThread: HandlerThread? = null
    private var handler: Handler? = null
    
    private var screenWidth = 0
    private var screenHeight = 0
    private var screenDensity = 0
    
    override fun onCreate() {
        super.onCreate()
        instance = this

        captureThread = HandlerThread("screen-capture-worker").apply { start() }
        handler = Handler(captureThread?.looper ?: Looper.getMainLooper())
        
        // 获取屏幕尺寸
        val windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            val bounds = windowManager.currentWindowMetrics.bounds
            screenWidth = bounds.width()
            screenHeight = bounds.height()
            metrics.setTo(resources.displayMetrics)
            screenDensity = metrics.densityDpi
        } else {
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(metrics)
            screenWidth = metrics.widthPixels
            screenHeight = metrics.heightPixels
            screenDensity = metrics.densityDpi
        }
        
        LogManager.i(TAG, "Screen dimensions: ${screenWidth}x${screenHeight}, density: $screenDensity")
    }
    
    override fun onBind(intent: Intent?): IBinder? = null
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_CAPTURE -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val data = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra<Intent>(EXTRA_DATA)
                }
                startCapture(resultCode, data)
            }
            ACTION_STOP_CAPTURE -> {
                stopCapture()
            }
            ACTION_TAKE_SCREENSHOT -> {
                runOnCaptureWorker {
                    takeScreenshotInternal()
                }
            }
        }
        return START_NOT_STICKY
    }
    
    private fun runOnCaptureWorker(block: () -> Unit) {
        val workerHandler = handler
        if (workerHandler == null || Looper.myLooper() == workerHandler.looper) {
            block()
        } else {
            workerHandler.post { block() }
        }
    }

    private fun <T> runOnCaptureWorkerAndWait(block: () -> T): T {
        val workerHandler = handler
        if (workerHandler == null || Looper.myLooper() == workerHandler.looper) {
            return block()
        }

        var result: Any? = null
        var error: Throwable? = null
        val latch = CountDownLatch(1)
        val posted = workerHandler.post {
            try {
                result = block()
            } catch (t: Throwable) {
                error = t
            } finally {
                latch.countDown()
            }
        }

        if (!posted) {
            return block()
        }

        try {
            latch.await()
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
            return block()
        }

        error?.let { throw it }

        @Suppress("UNCHECKED_CAST")
        return result as T
    }

    private fun startCapture(resultCode: Int, data: Intent?) {
        if (mediaProjection != null) {
            LogManager.i(TAG, "Already capturing")
            return
        }
        
        try {
            if (data == null) {
                LogManager.i(TAG, "Intent data is null")
                return
            }
            val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = projectionManager.getMediaProjection(resultCode, data)
            
            if (mediaProjection == null) {
                LogManager.i(TAG, "Failed to get MediaProjection")
                return
            }
            
            // 创建ImageReader
            imageReader = ImageReader.newInstance(
                screenWidth,
                screenHeight,
                PixelFormat.RGBA_8888,
                2 // maxImages
            )
            
            // 创建虚拟显示
            virtualDisplay = mediaProjection?.createVirtualDisplay(
                "ScreenCapture",
                screenWidth,
                screenHeight,
                screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface,
                null,
                handler
            )
            
            _isCapturing.value = true
            LogManager.i(TAG, "Screen capture started")
            
        } catch (e: Exception) {
            LogManager.i(TAG, "Error starting capture: ${e.message}", e)
            stopCapture()
        }
    }
    
    /**
     * 停止捕获屏幕
     */
    private fun stopCapture() {
        try {
            virtualDisplay?.release()
            virtualDisplay = null
            
            imageReader?.close()
            imageReader = null
            
            mediaProjection?.stop()
            mediaProjection = null
            _lastScreenshot.value = null
            _isCapturing.value = false
            LogManager.i(TAG, "Screen capture stopped")
            
        } catch (e: Exception) {
            LogManager.i(TAG, "Error stopping capture: ${e.message}", e)
        }
    }
    
    /**
     * 立即截图
     */
    fun takeScreenshot(): Bitmap? {
        return runOnCaptureWorkerAndWait {
            takeScreenshotInternal()
        }
    }

    private fun takeScreenshotInternal(): Bitmap? {
        if (imageReader == null) {
            LogManager.i(TAG, "ImageReader not initialized")
            return null
        }
        
        return try {
            val image = imageReader?.acquireLatestImage()
            if (image == null) {
                LogManager.i(TAG, "No image available")
                return null
            }
            
            val bitmap = imageToBitmap(image)
            image.close()
            
            _lastScreenshot.value = bitmap
            LogManager.i(TAG, "Screenshot captured: ${bitmap.width}x${bitmap.height}")
            
            bitmap
        } catch (e: Exception) {
            LogManager.i(TAG, "Error taking screenshot: ${e.message}", e)
            null
        }
    }
    
    /**
     * 将Image转换为Bitmap
     */
    private fun imageToBitmap(image: Image): Bitmap {
        val planes = image.planes
        val buffer: ByteBuffer = planes[0].buffer
        val pixelStride = planes[0].pixelStride
        val rowStride = planes[0].rowStride
        val rowPadding = rowStride - pixelStride * screenWidth
        
        val bitmap = Bitmap.createBitmap(
            screenWidth + rowPadding / pixelStride,
            screenHeight,
            Bitmap.Config.ARGB_8888
        )
        
        bitmap.copyPixelsFromBuffer(buffer)
        
        // 如果有padding，需要裁剪
        return if (rowPadding > 0) {
            val cropped = Bitmap.createBitmap(bitmap, 0, 0, screenWidth, screenHeight)
            bitmap.recycle()
            cropped
        } else {
            bitmap
        }
    }
    
    /**
     * 将Bitmap转换为Base64（用于Vision API）
     */
    fun bitmapToBase64(bitmap: Bitmap, quality: Int = 80): String {
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
        val bytes = outputStream.toByteArray()
        return android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
    }
    
    /**
     * 获取当前截图的Base64
     */
    fun getCurrentScreenshotBase64(quality: Int = 80): String? {
        return runOnCaptureWorkerAndWait {
            val bitmap = takeScreenshotInternal() ?: return@runOnCaptureWorkerAndWait null
            bitmapToBase64(bitmap, quality)
        }
    }

    override fun onDestroy() {
        runOnCaptureWorkerAndWait {
            stopCapture()
        }
        handler?.removeCallbacksAndMessages(null)
        captureThread?.quitSafely()
        captureThread = null
        handler = null
        super.onDestroy()
        instance = null
    }
}
