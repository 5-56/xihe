package com.example.xihe.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import com.example.xihe.utils.LogManager
import androidx.core.app.NotificationCompat
import com.example.xihe.MainActivity
import com.example.xihe.R
import com.example.xihe.training.AutoTrainingWorker
import com.example.xihe.training.SystemMonitor
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest

/**
 * 羲和训练保活服务
 * 
 * 功能：
 * 1. 保持应用在后台持续运行
 * 2. 监控系统状态
 * 3. 自动触发训练
 * 4. 前台服务通知
 * 5. 电源管理优化
 * 
 * 特点：
 * - 前台服务（不会被杀）
 * - WakeLock 保持（可选）
 * - 自动重启机制
 * - 用户可控开关
 */
class TrainingKeepAliveService : Service() {
    
    companion object {
        private const val TAG = "TrainingKeepAlive"
        private const val NOTIFICATION_ID = 1003
        private const val CHANNEL_ID = "xihe_training_channel"
        private const val CHANNEL_NAME = "羲和训练服务"
        
        private const val ACTION_START = "com.example.xihe.ACTION_START_TRAINING_SERVICE"
        private const val ACTION_STOP = "com.example.xihe.ACTION_STOP_TRAINING_SERVICE"
        
        private const val PREF_NAME = "training_service_settings"
        private const val KEY_SERVICE_ENABLED = "service_enabled"
        
        /**
         * 启动服务
         */
        fun start(context: Context) {
            try {
                val intent = Intent(context, TrainingKeepAliveService::class.java).apply {
                    action = ACTION_START
                }
                
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
                
                context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit()
                    .putBoolean(KEY_SERVICE_ENABLED, true)
                    .apply()
                
                LogManager.d(TAG, "✅ 训练保活服务已启动")
            } catch (e: Exception) {
                LogManager.e(TAG, "训练保活服务启动失败", e)
            }
        }
        
        /**
         * 停止服务
         */
        fun stop(context: Context) {
            val intent = Intent(context, TrainingKeepAliveService::class.java)
            context.stopService(intent)
            
            // 保存禁用状态
            context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_SERVICE_ENABLED, false)
                .apply()
            
            LogManager.d(TAG, "👋 训练保活服务已停止")
        }
        
        /**
         * 检查服务是否启用
         */
        fun isEnabled(context: Context): Boolean {
            return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_SERVICE_ENABLED, true) // 默认启用
        }
        
        /**
         * 检查服务是否运行中
         */
        fun isRunning(context: Context): Boolean {
            val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            @Suppress("DEPRECATION")
            for (service in manager.getRunningServices(Int.MAX_VALUE)) {
                if (TrainingKeepAliveService::class.java.name == service.service.className) {
                    return true
                }
            }
            return false
        }
    }
    
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var wakeLock: PowerManager.WakeLock? = null
    private var systemMonitor: SystemMonitor? = null
    private var monitorJob: Job? = null
    
    override fun onCreate() {
        super.onCreate()
        LogManager.d(TAG, "🚀 服务创建")
        
        // 创建通知渠道
        createNotificationChannel()
        
        // 启动前台服务
        startForeground(NOTIFICATION_ID, createNotification(
            title = "羲和训练助手",
            text = "正在后台监控，等待训练时机...",
            isTraining = false
        ))
        
        // 初始化系统监控
        initSystemMonitor()
        
        // 获取 WakeLock（可选，仅在训练时使用）
        // acquireWakeLock()
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        LogManager.d(TAG, "📨 收到启动命令: ${intent?.action}")
        
        when (intent?.action) {
            ACTION_START -> {
                startMonitoring()
            }
            ACTION_STOP -> {
                getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit()
                    .putBoolean(KEY_SERVICE_ENABLED, false)
                    .apply()
                stopSelf()
            }
        }
        
        // 确保服务重启
        return START_STICKY
    }
    
    override fun onBind(intent: Intent?): IBinder? = null
    
    override fun onDestroy() {
        LogManager.d(TAG, "👋 服务销毁")
        
        // 停止监控
        monitorJob?.cancel()
        systemMonitor?.stopMonitoring()
        
        // 释放 WakeLock
        releaseWakeLock()
        
        // 取消协程
        scope.cancel()
        
        super.onDestroy()
        
        // 如果用户没有主动关闭，自动重启
        if (isEnabled(this)) {
            LogManager.d(TAG, "🔄 服务意外停止，准备重启...")
            start(applicationContext)
        }
    }
    
    /**
     * 初始化系统监控
     */
    private fun initSystemMonitor() {
        systemMonitor = SystemMonitor.getInstance(this)
    }
    
    /**
     * 开始监控
     */
    private fun startMonitoring() {
        if (monitorJob?.isActive == true) {
            LogManager.d(TAG, "系统状态监控已在运行，跳过重复启动")
            return
        }

        LogManager.d(TAG, "🔍 开始监控系统状态...")
        
        // 启动系统监控
        systemMonitor?.startMonitoring()
        
        // 监听训练建议
        monitorJob = scope.launch {
            systemMonitor?.trainingRecommendation?.collectLatest { recommendation ->
                // 更新通知
                updateNotification(recommendation.shouldStartTraining)
                
                // 如果推荐训练，触发自动训练
                if (recommendation.shouldStartTraining) {
                    LogManager.d(TAG, "✅ 条件满足，触发自动训练")
                    triggerTraining()
                }
            }
        }
    }
    
    /**
     * 触发训练
     */
    private fun triggerTraining() {
        // 通过 WorkManager 触发训练
        AutoTrainingWorker.schedule(this)
        
        // 更新通知为训练中
        updateNotification(isTraining = true, text = "正在训练中...")
        
        // 训练时获取 WakeLock（防止休眠）
        acquireWakeLock()
    }
    
    /**
     * 创建通知渠道
     */
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "羲和训练服务保活通知"
                setShowBadge(false)
                enableLights(false)
                enableVibration(false)
            }
            
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }
    
    /**
     * 创建通知
     */
    private fun createNotification(
        title: String,
        text: String,
        isTraining: Boolean
    ): Notification {
        // 点击通知打开应用
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        
        // 停止服务的 Action
        val stopIntent = Intent(this, TrainingKeepAliveService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_IMMUTABLE
        )
        
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_launcher_foreground) // 使用应用图标
            .setContentIntent(pendingIntent)
            .setOngoing(true) // 不可滑动删除
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .apply {
                if (!isTraining) {
                    // 非训练时显示停止按钮
                    addAction(
                        R.drawable.ic_launcher_foreground,
                        "停止服务",
                        stopPendingIntent
                    )
                }
            }
            .build()
    }
    
    /**
     * 更新通知
     */
    private fun updateNotification(
        isTraining: Boolean,
        text: String = if (isTraining) "正在训练中..." else "等待训练时机..."
    ) {
        val notification = createNotification(
            title = if (isTraining) "羲和正在学习" else "羲和训练助手",
            text = text,
            isTraining = isTraining
        )
        
        val notificationManager = getSystemService(NotificationManager::class.java)
        notificationManager.notify(NOTIFICATION_ID, notification)
    }
    
    /**
     * 获取 WakeLock
     */
    private fun acquireWakeLock() {
        if (wakeLock == null) {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "Xihe::TrainingWakeLock"
            ).apply {
                setReferenceCounted(false)
            }
        }
        
        wakeLock?.let {
            if (!it.isHeld) {
                // 最多持有60分钟
                it.acquire(60 * 60 * 1000L)
                LogManager.d(TAG, "🔒 WakeLock 已获取")
            }
        }
    }
    
    /**
     * 释放 WakeLock
     */
    private fun releaseWakeLock() {
        wakeLock?.let {
            if (it.isHeld) {
                it.release()
                LogManager.d(TAG, "🔓 WakeLock 已释放")
            }
        }
        wakeLock = null
    }
}
