package com.example.xihe.service

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import com.example.xihe.utils.LogManager
import androidx.core.app.NotificationCompat
import com.example.xihe.MainActivity
import com.example.xihe.OverlayService
import com.example.xihe.R
import com.example.xihe.core.ModuleCoordinator
import com.example.xihe.interaction.VoiceInteractionManager
import com.example.xihe.tools.LifeApiTools
import kotlinx.coroutines.*
import java.util.*

/**
 * 后台唤醒词监听服务
 * 类似小爱同学的后台唤醒功能
 * 
 * 功能：
 * 1. 持续后台监听唤醒词
 * 2. 检测早上起床，主动问候
 * 3. 自动查询天气，提供穿衣建议
 */
class WakeWordService : Service() {
    
    companion object {
        private const val TAG = "WakeWordService"
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "xihe_wake_word_channel"
        private const val PREFS_NAME = "xihe_wake_service"
        private const val KEY_LAST_MORNING_GREET = "last_morning_greet"
        
        // 唤醒词列表
        val WAKE_WORDS = listOf(
            "羲和", "西禾", "希和", "嬉和", "曦和", "熙和",
            "xihe", "你好羲和", "小羲和", "羲和羲和"
        )
        
        // 早起问候时间范围
        private const val MORNING_START_HOUR = 5
        private const val MORNING_END_HOUR = 10
        
        var isRunning = false
            private set
        
        /**
         * 启动唤醒词监听（从外部调用）
         */
        fun startWakeWordListening(context: Context) {
            val intent = Intent(context, WakeWordService::class.java).apply {
                putExtra("action", "start_wake_word")
            }
            context.startService(intent)
        }
        
        /**
         * 停止唤醒词监听（从外部调用）
         */
        fun stopWakeWordListening(context: Context) {
            val intent = Intent(context, WakeWordService::class.java).apply {
                putExtra("action", "stop_wake_word")
            }
            context.startService(intent)
        }
    }
    
    private var wakeLock: PowerManager.WakeLock? = null
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var isListening = false
    
    // 屏幕状态广播接收器
    private var screenReceiver: BroadcastReceiver? = null
    private var lastScreenOnTime = 0L
    
    override fun onCreate() {
        super.onCreate()
        LogManager.i(TAG, " 后台唤醒服务启动...")
        isRunning = true
        
        // 创建通知渠道
        createNotificationChannel()
        
        // 启动前台服务
        startForeground(NOTIFICATION_ID, createNotification())
        
        // 获取 WakeLock 保持 CPU 运行
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "Xihe::WakeWordLock"
        ).apply {
            acquire(10 * 60 * 1000L) // 10分钟后自动释放，会自动续期
        }
        
        // 初始化位置和天气服务
        LifeApiTools.init(applicationContext)
        
        // 注册屏幕状态广播接收器（用于早起检测）
        registerScreenReceiver()
        
        // 只初始化，不自动开始监听
        // 用户需要在设置中手动启用唤醒词功能
        initializeWakeWordDetection()
        
        LogManager.i(TAG, " 唤醒词服务已就绪，但未自动启动监听")
        LogManager.i(TAG, " 请在应用设置中启用「后台唤醒词」功能")
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        LogManager.d(TAG, " 服务收到启动命令")
        
        // 检查是否是手动启动唤醒词监听
        val action = intent?.getStringExtra("action")
        when (action) {
            "start_wake_word" -> {
                LogManager.i(TAG, " 用户手动启动唤醒词监听")
                if (!isListening) {
                    startWakeWordListening()
                }
            }
            "stop_wake_word" -> {
                LogManager.i(TAG, " 用户手动停止唤醒词监听")
                if (isListening) {
                    ModuleCoordinator.stopContinuousListening()
                    isListening = false
                }
            }
            else -> {
                LogManager.d(TAG, " 服务启动，等待用户手动启用唤醒词")
            }
        }
        
        return START_STICKY // 服务被杀死后自动重启
    }
    
    override fun onBind(intent: Intent?): IBinder? = null
    
    override fun onDestroy() {
        super.onDestroy()
        LogManager.i(TAG, " 后台唤醒服务停止")
        isRunning = false
        isListening = false
        
        // 停止监听
        ModuleCoordinator.stopContinuousListening()
        
        // 注销屏幕广播接收器
        unregisterScreenReceiver()
        
        // 释放 WakeLock
        wakeLock?.let {
            if (it.isHeld) {
                it.release()
            }
        }
        
        // 取消协程
        serviceScope.cancel()
    }
    
    /**
     * 注册屏幕状态广播接收器
     */
    private fun registerScreenReceiver() {
        screenReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    Intent.ACTION_SCREEN_ON -> {
                        LogManager.d(TAG, " 屏幕亮起")
                        lastScreenOnTime = System.currentTimeMillis()
                        checkMorningGreeting()
                    }
                    Intent.ACTION_USER_PRESENT -> {
                        LogManager.d(TAG, " 用户解锁")
                        checkMorningGreeting()
                    }
                }
            }
        }
        
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(screenReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(screenReceiver, filter)
        }
        
        LogManager.d(TAG, " 屏幕状态监听已注册")
    }
    
    /**
     * 注销屏幕广播接收器
     */
    private fun unregisterScreenReceiver() {
        screenReceiver?.let {
            try {
                unregisterReceiver(it)
            } catch (e: Exception) {
                LogManager.e(TAG, "注销屏幕接收器失败", e)
            }
        }
        screenReceiver = null
    }
    
    /**
     * 检查是否需要早起问候
     */
    private fun checkMorningGreeting() {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        
        // 检查是否在早起时间范围内
        if (hour < MORNING_START_HOUR || hour >= MORNING_END_HOUR) {
            LogManager.d(TAG, " 不在早起问候时间范围内 (当前: $hour 点)")
            return
        }
        
        // 检查今天是否已经问候过
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val lastGreetDate = prefs.getString(KEY_LAST_MORNING_GREET, "")
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).format(Date())
        
        if (lastGreetDate == today) {
            LogManager.d(TAG, " 今天已经问候过了")
            return
        }
        
        // 执行早起问候
        LogManager.i(TAG, " 检测到早起！开始问候...")
        prefs.edit().putString(KEY_LAST_MORNING_GREET, today).apply()
        
        performMorningGreeting()
    }
    
    /**
     * 执行早起问候
     */
    private fun performMorningGreeting() {
        serviceScope.launch {
            try {
                // 获取当前时间的问候语
                val calendar = Calendar.getInstance()
                val hour = calendar.get(Calendar.HOUR_OF_DAY)
                val timeGreeting = when (hour) {
                    in 5..7 -> "早安"
                    in 8..9 -> "早上好"
                    else -> "你好"
                }
                
                // 先打招呼
                ModuleCoordinator.speak("主人$timeGreeting~让我帮你看看今天的天气吧~")
                delay(3000)
                
                // 查询天气
                val weatherResult = LifeApiTools.getWeatherWithAutoLocation(null)
                
                if (weatherResult.success) {
                    val weatherInfo = weatherResult.message
                    
                    // 让 AI 根据天气生成穿衣建议
                    val aiSuggestion = generateAIClothingSuggestion(weatherInfo)
                    
                    // 播报 AI 生成的建议
                    ModuleCoordinator.speak(aiSuggestion)
                    
                } else {
                    ModuleCoordinator.speak("哎呀，天气信息获取失败了呢~主人记得看看窗外的天气再出门哦！")
                }
                
            } catch (e: Exception) {
                LogManager.e(TAG, "早起问候失败", e)
            }
        }
    }
    
    /**
     * 让 AI 根据天气生成穿衣建议
     */
    private suspend fun generateAIClothingSuggestion(weatherInfo: String): String {
        return try {
            val prompt = """
你是羲和，主人刚刚起床，你查到了今天的天气信息如下：

$weatherInfo

请根据这个天气信息，用可爱活泼的语气给主人：
1. 简要播报今天的天气（温度、天气状况）
2. 给出穿衣建议
3. 如果有雨雪，提醒带伞或注意安全
4. 可以加一些贴心的小叮嘱

要求：
- 语气要可爱、贴心
- 用语气词如"呀"、"呢"、"哦"
- 回复控制在100字以内，适合语音播报
- 直接给出建议，不要说"好的"、"根据天气"这类开场白
""".trimIndent()

            // 使用 LLMClient 生成建议
            val response = com.example.xihe.core.LLMClient().chatCompletion(prompt)
            response.ifEmpty { 
                "今天天气信息：$weatherInfo，记得根据天气穿衣哦~" 
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "AI 生成穿衣建议失败", e)
            // 如果 AI 失败，返回简单的天气信息
            "今天的天气：$weatherInfo，主人记得看天气穿衣哦~"
        }
    }
    
    /**
     * 创建通知渠道
     */
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "羲和唤醒服务",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "羲和正在后台监听唤醒词"
                setShowBadge(false)
            }
            
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }
    
    /**
     * 创建前台服务通知
     */
    private fun createNotification(): Notification {
        // 点击通知打开主界面
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("羲和正在待命")
            .setContentText("说 \"羲和\" 即可唤醒")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }
    
    /**
     * 初始化唤醒词检测
     */
    private fun initializeWakeWordDetection() {
        serviceScope.launch {
            try {
                // 确保 ModuleCoordinator 已初始化
                if (!ModuleCoordinator.isInitialized()) {
                    LogManager.d(TAG, " 初始化 ModuleCoordinator...")
                    ModuleCoordinator.initialize(applicationContext)
                    delay(1000) // 等待初始化完成
                }
                
                // 设置唤醒词回调
                ModuleCoordinator.setOnWakeWordDetected {
                    LogManager.i(TAG, " 检测到唤醒词！启动悬浮窗...")
                    onWakeWordDetected()
                }
                
                // 不再自动开始监听，等待用户手动启动
                LogManager.d(TAG, " 唤醒词检测已初始化完成，等待手动启动")
                
            } catch (e: Exception) {
                LogManager.e(TAG, "初始化唤醒词检测失败", e)
            }
        }
    }
    
    /**
     * 开始唤醒词监听
     */
    private fun startWakeWordListening() {
        if (isListening) {
            LogManager.d(TAG, " 已经在监听中")
            return
        }
        
        try {
            LogManager.i(TAG, " 开始后台唤醒词监听...")
            ModuleCoordinator.startContinuousListening()
            isListening = true
            
            // 定期续期 WakeLock
            serviceScope.launch {
                while (isActive && isListening) {
                    delay(5 * 60 * 1000L) // 每5分钟
                    wakeLock?.let {
                        if (it.isHeld) {
                            it.release()
                        }
                        it.acquire(10 * 60 * 1000L)
                    }
                }
            }
            
        } catch (e: Exception) {
            LogManager.e(TAG, "启动唤醒词监听失败", e)
        }
    }
    
    /**
     * 检测到唤醒词时的处理
     */
    private fun onWakeWordDetected() {
        serviceScope.launch {
            try {
                LogManager.i(TAG, " 唤醒词被检测到，启动实时对话模式...")
                
                // 播放提示音
                ModuleCoordinator.speak("我在~主人有什么吩咐？")
                
                // 更新通知
                val notification = NotificationCompat.Builder(this@WakeWordService, CHANNEL_ID)
                    .setContentTitle("羲和实时对话中")
                    .setContentText("正在与您对话...")
                    .setSmallIcon(R.drawable.ic_launcher_foreground)
                    .setOngoing(true)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .build()
                
                val notificationManager = getSystemService(NotificationManager::class.java)
                notificationManager.notify(NOTIFICATION_ID, notification)
                
            } catch (e: Exception) {
                LogManager.e(TAG, "处理唤醒词失败", e)
            }
        }
    }
    
    /**
     * 当对话结束时恢复待命通知
     */
    fun restoreIdleNotification() {
        val notificationManager = getSystemService(NotificationManager::class.java)
        notificationManager.notify(NOTIFICATION_ID, createNotification())
    }
}
