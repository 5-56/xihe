package com.example.xihe.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.example.xihe.MainActivity
import com.example.xihe.R
import com.example.xihe.collector.LifeDataCollector
import com.example.xihe.training.AutoTrainingScheduler
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import com.example.xihe.utils.LogManager

/**
 * 羲和AI后台服务
 * 
 * 核心功能：
 * 1. 前台服务 - 防止被系统杀死
 * 2. 持续数据收集 - 24小时不间断
 * 3. 自动训练 - 定期训练个性化模型
 * 4. 数据持久化 - 安全存储用户数据
 * 5. 电量优化 - 智能节能
 * 
 * 保活策略：
 * - 前台服务 + 通知栏常驻
 * - WakeLock 保持CPU运行
 * - JobScheduler 定时拉起
 * - 开机自启动
 * - 守护进程
 */
class XiheBackgroundService : Service() {
    
    companion object {
        private const val TAG = "XiheBackgroundService"
        private const val NOTIFICATION_ID = 1002
        private const val CHANNEL_ID = "xihe_background_channel"
        private const val CHANNEL_NAME = "羲和AI后台服务"
        
        // 服务状态
        @Volatile
        var isRunning = false
            private set

        private val _isRunningFlow = MutableStateFlow(false)
        val isRunningFlow = _isRunningFlow.asStateFlow()

        private fun updateRunningState(running: Boolean) {
            isRunning = running
            _isRunningFlow.value = running
        }
        
        /**
         * 启动后台服务
         */
        fun start(context: Context) {
            try {
                val intent = Intent(context, XiheBackgroundService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
                LogManager.d(TAG, "后台服务已启动")
            } catch (e: Exception) {
                LogManager.e(TAG, "后台服务启动失败", e)
            }
        }
        
        /**
         * 停止后台服务
         */
        fun stop(context: Context) {
            val intent = Intent(context, XiheBackgroundService::class.java)
            context.stopService(intent)
            LogManager.d(TAG, "后台服务已停止")
        }
    }
    
    // 协程作用域
    private val serviceScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    
    // 数据收集器
    private lateinit var dataCollector: LifeDataCollector
    
    // 自动训练调度器
    private lateinit var trainingScheduler: AutoTrainingScheduler
    
    // WakeLock（保持CPU运行）
    private var wakeLock: PowerManager.WakeLock? = null
    
    // 收集任务
    private var collectionJob: Job? = null
    
    override fun onCreate() {
        super.onCreate()
        LogManager.d(TAG, "服务创建")
        
        // 初始化组件
        dataCollector = LifeDataCollector.getInstance(this)
        trainingScheduler = AutoTrainingScheduler.getInstance(this)
        
        // 获取 WakeLock
        acquireWakeLock()
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        LogManager.d(TAG, "服务启动命令")
        
        // 创建通知渠道
        createNotificationChannel()
        
        // 启动前台服务
        val notification = createNotification()
        startForeground(NOTIFICATION_ID, notification)
        
        // 标记服务运行中
        updateRunningState(true)
        
        // 启动数据收集
        startDataCollection()
        
        // 启动自动训练
        trainingScheduler.start()
        
        // 返回 START_STICKY 确保服务被杀后自动重启
        return START_STICKY
    }
    
    override fun onBind(intent: Intent?): IBinder? {
        return null
    }
    
    override fun onDestroy() {
        LogManager.d(TAG, "服务销毁")
        
        updateRunningState(false)
        
        // 停止数据收集
        stopDataCollection()
        
        // 停止训练调度
        trainingScheduler.stop()
        
        // 释放 WakeLock
        releaseWakeLock()
        
        // 取消所有协程
        serviceScope.cancel()
        
        super.onDestroy()
        
        // 重新启动服务（守护进程）
        if (shouldRestart()) {
            start(applicationContext)
        }
    }
    
    /**
     * 启动数据收集
     */
    private fun startDataCollection() {
        if (collectionJob?.isActive == true) {
            return
        }

        collectionJob?.cancel()
        
        collectionJob = serviceScope.launch {
            LogManager.d(TAG, "开始数据收集")

            try {
                dataCollector.startCollecting()
            } catch (e: Exception) {
                LogManager.e(TAG, "启动数据收集失败: ${e.message}", e)
            }
            
            // 持续运行
            while (isActive) {
                try {
                    // 每隔一段时间更新通知
                    updateNotification()
                    
                    // 检查是否需要训练
                    checkAndTrain()
                    
                    // 等待
                    delay(60_000) // 每分钟检查一次
                    
                } catch (e: Exception) {
                    LogManager.e(TAG, "数据收集错误: ${e.message}", e)
                }
            }
        }
    }
    
    /**
     * 停止数据收集
     */
    private fun stopDataCollection() {
        collectionJob?.cancel()
        collectionJob = null
        if (::dataCollector.isInitialized) {
            dataCollector.stopCollecting()
        }
        LogManager.d(TAG, "数据收集已停止")
    }
    
    /**
     * 检查并训练
     */
    private suspend fun checkAndTrain() {
        if (trainingScheduler.shouldTrain()) {
            LogManager.d(TAG, "满足训练条件，开始训练...")
            trainingScheduler.triggerTraining()
        }
    }
    
    /**
     * 创建通知渠道
     */
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_LOW // 低重要性，不打扰用户
            ).apply {
                description = "羲和AI正在后台为您服务"
                setShowBadge(false)
                enableVibration(false)
                setSound(null, null)
            }
            
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }
    
    /**
     * 创建通知
     */
    private fun createNotification(): Notification {
        // 点击通知打开APP
        val intent = packageManager.getLaunchIntentForPackage(packageName)
            ?: Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("羲和AI正在守护您")
            .setContentText("正在记录您的生活,训练个性化AI...")
            .setSmallIcon(android.R.drawable.ic_dialog_info) // 使用系统图标
            .setContentIntent(pendingIntent)
            .setOngoing(true) // 常驻通知
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }
    
    /**
     * 更新通知
     */
    private fun updateNotification() {
        val stats = dataCollector.getCollectionStats()
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("羲和AI正在守护您")
            .setContentText("已收集 ${stats.totalRecords} 条数据 | ${stats.todayRecords} 条今日记录")
            .setSmallIcon(android.R.drawable.ic_dialog_info) // 使用系统图标
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        
        val notificationManager = getSystemService(NotificationManager::class.java)
        notificationManager.notify(NOTIFICATION_ID, notification)
    }
    
    /**
     * 获取 WakeLock
     */
    private fun acquireWakeLock() {
        try {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "XiheAI::BackgroundService"
            ).apply {
                acquire(10 * 60 * 1000L) // 10分钟
            }
            LogManager.d(TAG, "WakeLock已获取")
        } catch (e: Exception) {
            LogManager.e(TAG, "WakeLock获取失败: ${e.message}", e)
        }
    }
    
    /**
     * 释放 WakeLock
     */
    private fun releaseWakeLock() {
        try {
            wakeLock?.let {
                if (it.isHeld) {
                    it.release()
                    LogManager.d(TAG, "WakeLock已释放")
                }
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "WakeLock释放失败: ${e.message}", e)
        }
    }
    
    /**
     * 是否应该重启
     */
    private fun shouldRestart(): Boolean {
        val prefs = getSharedPreferences("xihe_settings", Context.MODE_PRIVATE)
        return prefs.getBoolean("enable_background_wake", false)
    }
}
