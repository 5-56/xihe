package com.example.xihe.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import com.example.xihe.utils.LogManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.xihe.ai.TaskPlanner
import com.example.xihe.core.AutomationEngine
import com.example.xihe.screen.ScreenAnalyzer
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * 🚀 增强版无障碍服务
 * 提供智能的屏幕理解和操作能力
 */
class EnhancedAccessibilityService : AccessibilityService() {
    
    companion object {
        private const val TAG = "EnhancedA11yService"
        
        // 服务状态
        private val _isConnected = MutableStateFlow(false)
        val isConnected = _isConnected.asStateFlow()
        
        // 当前实例
        @Volatile
        private var instance: EnhancedAccessibilityService? = null
        
        fun getInstance(): EnhancedAccessibilityService? = instance
    }
    
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val screenAnalyzer = ScreenAnalyzer()
    
    // 当前屏幕状态
    private val _currentScreenState = MutableStateFlow<ScreenAnalyzer.ScreenState?>(null)
    val currentScreenState = _currentScreenState.asStateFlow()
    
    // 操作历史记录
    private val actionHistory = mutableListOf<ActionRecord>()
    
    // 学习模式
    private var learningMode = false
    private val learnedPatterns = mutableMapOf<String, List<ActionRecord>>()
    
    /**
     * 操作记录
     */
    data class ActionRecord(
        val timestamp: Long,
        val action: String,
        val target: String?,
        val result: Boolean,
        val screenStateBefore: ScreenAnalyzer.ScreenState?,
        val screenStateAfter: ScreenAnalyzer.ScreenState?
    )
    
    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isConnected.value = true
        
        LogManager.i(TAG, "🎯 增强无障碍服务已连接")
        
        // 配置服务
        configureService()
        
        // 开始监控屏幕
        startScreenMonitoring()
    }
    
    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                handleWindowChange(event)
            }
            AccessibilityEvent.TYPE_VIEW_CLICKED -> {
                if (learningMode) {
                    recordUserAction(event, "click")
                }
            }
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> {
                if (learningMode) {
                    recordUserAction(event, "text_input")
                }
            }
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                if (learningMode) {
                    recordUserAction(event, "scroll")
                }
            }
        }
    }
    
    override fun onInterrupt() {
        LogManager.w(TAG, "无障碍服务被中断")
    }
    
    override fun onDestroy() {
        super.onDestroy()
        instance = null
        _isConnected.value = false
        scope.cancel()
        LogManager.i(TAG, "无障碍服务已断开")
    }
    
    /**
     * 配置服务
     */
    private fun configureService() {
        // 动态配置服务参数
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val config = serviceInfo
            config?.let {
                // 监听所有事件类型
                it.eventTypes = AccessibilityEvent.TYPES_ALL_MASK
                // 快速响应
                it.notificationTimeout = 100
                // 获取窗口内容
                it.flags = it.flags or AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
                serviceInfo = it
            }
        }
    }
    
    /**
     * 开始屏幕监控
     */
    private fun startScreenMonitoring() {
        scope.launch {
            while (isActive) {
                delay(500) // 每500ms更新一次
                updateCurrentScreenState()
            }
        }
    }
    
    /**
     * 更新当前屏幕状态
     */
    private fun updateCurrentScreenState() {
        rootInActiveWindow?.let { root ->
            val state = screenAnalyzer.analyzeScreen(root)
            _currentScreenState.value = state
        }
    }
    
    /**
     * 处理窗口变化
     */
    private fun handleWindowChange(event: AccessibilityEvent) {
        LogManager.d(TAG, "窗口变化: ${event.packageName}/${event.className}")
        
        // 更新屏幕状态
        updateCurrentScreenState()
    }
    
    /**
     * 记录用户操作（学习模式）
     */
    private fun recordUserAction(event: AccessibilityEvent, actionType: String) {
        if (!learningMode) return
        
        val source = event.source
        val target = source?.let {
            "${it.text ?: it.contentDescription ?: it.className}"
        }
        
        val record = ActionRecord(
            timestamp = System.currentTimeMillis(),
            action = actionType,
            target = target,
            result = true,
            screenStateBefore = _currentScreenState.value,
            screenStateAfter = null
        )
        
        actionHistory.add(record)
        LogManager.d(TAG, "记录用户操作: $actionType -> $target")
    }
    
    // ==================== 智能操作API ====================
    
    /**
     * 🎯 执行智能点击
     */
    suspend fun smartClick(description: String): Boolean {
        LogManager.d(TAG, "执行智能点击: $description")
        
        val element = findElementByDescription(description)
        if (element == null) {
            LogManager.w(TAG, "未找到元素: $description")
            return false
        }
        
        return clickElement(element)
    }
    
    /**
     * 📝 智能输入文本
     */
    suspend fun smartInputText(text: String, targetDescription: String? = null): Boolean {
        LogManager.d(TAG, "智能输入文本: $text")
        
        // 如果指定了目标，先点击目标
        if (targetDescription != null) {
            val element = findElementByDescription(targetDescription)
            if (element != null) {
                clickElement(element)
                delay(500) // 等待键盘弹出
            }
        }
        
        // 查找当前焦点的输入框
        val focusedNode = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (focusedNode != null) {
            val bundle = Bundle()
            bundle.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            val result = focusedNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, bundle)
            return result
        }
        
        // 如果没有焦点，尝试找到第一个可编辑的元素
        val editText = findEditableElement()
        if (editText != null) {
            clickElement(editText)
            delay(500)
            return smartInputText(text, null) // 递归调用
        }
        
        return false
    }
    
    /**
     * 📜 智能滚动
     */
    suspend fun smartScroll(direction: String, distance: Int = 500): Boolean {
        LogManager.d(TAG, "智能滚动: 方向=$direction, 距离=$distance")
        
        val scrollableNode = findScrollableElement()
        if (scrollableNode == null) {
            LogManager.w(TAG, "未找到可滚动元素")
            return false
        }
        
        val rect = Rect()
        scrollableNode.getBoundsInScreen(rect)
        
        val startX = rect.centerX().toFloat()
        val startY = rect.centerY().toFloat()
        val endX: Float
        val endY: Float
        
        when (direction.lowercase()) {
            "up", "上" -> {
                endX = startX
                endY = startY - distance
            }
            "down", "下" -> {
                endX = startX
                endY = startY + distance
            }
            "left", "左" -> {
                endX = startX - distance
                endY = startY
            }
            "right", "右" -> {
                endX = startX + distance
                endY = startY
            }
            else -> {
                endX = startX
                endY = startY + distance
            }
        }
        
        return performSwipe(startX, startY, endX, endY)
    }
    
    /**
     * 🚀 启动应用
     */
    suspend fun launchApp(packageName: String): Boolean {
        LogManager.d(TAG, "启动应用: $packageName")
        
        return try {
            val packageCandidates = buildPackageCandidates(packageName)
            if (packageCandidates.any { launchByPackageName(it) }) {
                delay(2000)
                true
            } else {
                val keywords = buildSearchKeywords(packageName)
                val launchIntent = findLauncherIntentByKeywords(keywords)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(launchIntent)
                    delay(2000)
                    true
                } else {
                    LogManager.e(TAG, "无法启动应用: " + packageName)
                    false
                }
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "启动应用失败", e)
            false
        }
    }
    
    /**
     * 🔙 返回操作
     */
    private fun launchByPackageName(packageName: String): Boolean {
        if (packageName.isBlank()) {
            return false
        }
        val intent = packageManager.getLaunchIntentForPackage(packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        return true
    }

    private fun buildPackageCandidates(query: String): List<String> {
        val normalizedQuery = normalizeAppKeyword(query)
        val candidates = LinkedHashSet<String>()
        if (query.contains('.')) {
            candidates.add(query)
        }
        knownAppMappings().forEach { (aliases, packages) ->
            if (aliases.any { alias ->
                    val normalizedAlias = normalizeAppKeyword(alias)
                    normalizedQuery == normalizedAlias || normalizedQuery.contains(normalizedAlias)
                }) {
                candidates.addAll(packages)
            }
        }
        return candidates.toList()
    }

    private fun buildSearchKeywords(query: String): List<String> {
        val normalizedQuery = normalizeAppKeyword(query)
        val keywords = LinkedHashSet<String>()
        keywords.add(query.trim())
        knownAppMappings().forEach { (aliases, packages) ->
            if (aliases.any { alias ->
                    val normalizedAlias = normalizeAppKeyword(alias)
                    normalizedQuery == normalizedAlias || normalizedQuery.contains(normalizedAlias)
                }) {
                keywords.addAll(aliases)
                keywords.addAll(packages)
            }
        }
        return keywords.filter { it.isNotBlank() }
    }

    private fun findLauncherIntentByKeywords(keywords: List<String>): Intent? {
        if (keywords.isEmpty()) {
            return null
        }
        val launcherIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val activities = packageManager.queryIntentActivities(launcherIntent, 0)
        val matchedActivity = activities.firstOrNull { info ->
            val label = info.loadLabel(packageManager)?.toString().orEmpty()
            val packageName = info.activityInfo?.packageName.orEmpty()
            keywords.any { keyword ->
                keyword.isNotBlank() && (
                    label.contains(keyword, ignoreCase = true) ||
                        packageName.contains(keyword, ignoreCase = true)
                    )
            }
        } ?: return null
        return Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            setClassName(matchedActivity.activityInfo.packageName, matchedActivity.activityInfo.name)
        }
    }

    private fun normalizeAppKeyword(value: String): String {
        return value.trim()
            .lowercase()
            .replace(Regex("\\s+"), "")
            .removeSuffix("应用")
            .removeSuffix("app")
    }

    private fun knownAppMappings(): List<Pair<List<String>, List<String>>> {
        return listOf(
            listOf("微信", "wechat") to listOf("com.tencent.mm"),
            listOf("QQ", "qq", "腾讯qq") to listOf("com.tencent.mobileqq"),
            listOf("支付宝", "alipay") to listOf("com.eg.android.AlipayGphone"),
            listOf("淘宝", "taobao") to listOf("com.taobao.taobao"),
            listOf("抖音", "douyin") to listOf("com.ss.android.ugc.aweme"),
            listOf("快手", "kuaishou") to listOf("com.kuaishou.nebula", "com.smile.gifmaker"),
            listOf("哔哩哔哩", "B站", "b站", "bilibili") to listOf("tv.danmaku.bili"),
            listOf("小红书", "xiaohongshu", "redbook") to listOf("com.xingin.xhs"),
            listOf("京东", "jd", "jingdong") to listOf("com.jingdong.app.mall"),
            listOf("拼多多", "pdd", "pinduoduo") to listOf("com.xunmeng.pinduoduo")
        )
    }

    fun performBack(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_BACK)
    }
    
    /**
     * 🏠 返回主页
     */
    fun performHome(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_HOME)
    }
    
    /**
     * 📱 打开最近任务
     */
    fun performRecentApps(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_RECENTS)
    }
    
    /**
     * 📸 截屏
     */
    fun performScreenshot(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        } else {
            LogManager.w(TAG, "当前系统版本不支持截屏")
            false
        }
    }
    
    // ==================== 辅助方法 ====================
    
    /**
     * 根据描述查找元素
     */
    private fun findElementByDescription(description: String): AccessibilityNodeInfo? {
        val currentState = _currentScreenState.value ?: return null
        val targetElement = screenAnalyzer.findElement(currentState.elements, description)
        
        if (targetElement != null) {
            return findNodeByBounds(targetElement.bounds)
        }
        
        // 降级到传统查找方法
        return findElementTraditional(description)
    }
    
    /**
     * 传统方式查找元素
     */
    private fun findElementTraditional(text: String): AccessibilityNodeInfo? {
        rootInActiveWindow?.let { root ->
            // 按文本查找
            root.findAccessibilityNodeInfosByText(text).firstOrNull()?.let { return it }
            
            // 按描述查找
            return findByContentDescription(root, text)
        }
        return null
    }
    
    /**
     * 根据内容描述查找
     */
    private fun findByContentDescription(
        node: AccessibilityNodeInfo,
        description: String
    ): AccessibilityNodeInfo? {
        if (node.contentDescription?.toString()?.contains(description) == true) {
            return node
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findByContentDescription(child, description)
            if (found != null) {
                return found
            }
        }
        
        return null
    }
    
    /**
     * 根据边界查找节点
     */
    private fun findNodeByBounds(bounds: ScreenAnalyzer.ElementBounds): AccessibilityNodeInfo? {
        return findNodeByBoundsRecursive(rootInActiveWindow, bounds)
    }
    
    /**
     * 递归查找匹配边界的节点
     */
    private fun findNodeByBoundsRecursive(
        node: AccessibilityNodeInfo?,
        targetBounds: ScreenAnalyzer.ElementBounds
    ): AccessibilityNodeInfo? {
        if (node == null) return null
        
        val rect = Rect()
        node.getBoundsInScreen(rect)
        
        // 检查边界是否匹配
        if (rect.left == targetBounds.left &&
            rect.top == targetBounds.top &&
            rect.right == targetBounds.right &&
            rect.bottom == targetBounds.bottom) {
            return node
        }
        
        // 递归查找子节点
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findNodeByBoundsRecursive(child, targetBounds)
            if (found != null) {
                return found
            }
        }
        
        return null
    }
    
    /**
     * 查找可编辑元素
     */
    private fun findEditableElement(): AccessibilityNodeInfo? {
        return findElementByClassName("android.widget.EditText")
    }
    
    /**
     * 查找可滚动元素
     */
    private fun findScrollableElement(): AccessibilityNodeInfo? {
        return findScrollableRecursive(rootInActiveWindow)
    }
    
    /**
     * 递归查找可滚动元素
     */
    private fun findScrollableRecursive(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        
        if (node.isScrollable) {
            return node
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findScrollableRecursive(child)
            if (found != null) {
                return found
            }
        }
        
        return null
    }
    
    /**
     * 根据类名查找元素
     */
    private fun findElementByClassName(className: String): AccessibilityNodeInfo? {
        return findByClassNameRecursive(rootInActiveWindow, className)
    }
    
    /**
     * 递归按类名查找
     */
    private fun findByClassNameRecursive(
        node: AccessibilityNodeInfo?,
        className: String
    ): AccessibilityNodeInfo? {
        if (node == null) return null
        
        if (node.className?.toString()?.contains(className) == true) {
            return node
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findByClassNameRecursive(child, className)
            if (found != null) {
                return found
            }
        }
        
        return null
    }
    
    /**
     * 点击元素
     */
    private fun clickElement(node: AccessibilityNodeInfo): Boolean {
        return if (node.isClickable) {
            node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        } else {
            // 如果元素本身不可点击，尝试点击其父元素
            var parent = node.parent
            while (parent != null) {
                if (parent.isClickable) {
                    val result = parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    return result
                }
                parent = parent.parent
            }
            
            // 如果都不可点击，使用手势点击
            val rect = Rect()
            node.getBoundsInScreen(rect)
            performTap(rect.centerX().toFloat(), rect.centerY().toFloat())
        }
    }
    
    /**
     * 执行点击手势
     */
    private fun performTap(x: Float, y: Float): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
        
        val path = Path()
        path.moveTo(x, y)
        
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 100))
            .build()
        
        return dispatchGesture(gesture, null, null)
    }
    
    /**
     * 执行滑动手势
     */
    private fun performSwipe(
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        duration: Long = 300
    ): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
        
        val path = Path()
        path.moveTo(startX, startY)
        path.lineTo(endX, endY)
        
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, duration))
            .build()
        
        return dispatchGesture(gesture, null, null)
    }
    
    /**
     * 开启/关闭学习模式
     */
    fun setLearningMode(enabled: Boolean) {
        learningMode = enabled
        if (enabled) {
            actionHistory.clear()
            LogManager.i(TAG, "📚 学习模式已开启")
        } else {
            // 分析并保存学习到的模式
            if (actionHistory.isNotEmpty()) {
                analyzeLearningData()
            }
            LogManager.i(TAG, "📚 学习模式已关闭")
        }
    }
    
    /**
     * 分析学习数据
     */
    private fun analyzeLearningData() {
        // 这里可以实现更复杂的模式识别算法
        val pattern = actionHistory.toList()
        val patternName = "pattern_${System.currentTimeMillis()}"
        learnedPatterns[patternName] = pattern
        
        LogManager.d(TAG, "学习到新模式: $patternName, 包含${pattern.size}个操作")
    }
    
    /**
     * 执行学习到的模式
     */
    suspend fun executeLearnedPattern(patternName: String): Boolean {
        val pattern = learnedPatterns[patternName] ?: return false
        
        LogManager.d(TAG, "执行学习模式: $patternName")
        
        for (action in pattern) {
            val success = when (action.action) {
                "click" -> action.target?.let { smartClick(it) } ?: false
                "text_input" -> action.target?.let { smartInputText(it) } ?: false
                "scroll" -> smartScroll("down")
                else -> false
            }
            
            if (!success) {
                LogManager.w(TAG, "模式执行失败: ${action.action}")
                return false
            }
            
            delay(action.timestamp) // 使用时间间隔作为延迟
        }
        
        return true
    }
}
