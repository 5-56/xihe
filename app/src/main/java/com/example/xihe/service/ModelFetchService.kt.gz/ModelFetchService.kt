package com.example.xihe.service

import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.core.LLMClient
import com.example.xihe.core.ProviderConfig
import com.example.xihe.core.ProviderRegistry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * 模型列表获取服务
 * 
 * 功能：
 * 1. 根据API配置实时获取可用模型列表
 * 2. 支持多种API提供商格式
 * 3. 缓存模型列表，减少重复请求
 */
object ModelFetchService {
    private const val TAG = "ModelFetchService"
    
    // 模型列表缓存 (providerId -> (lastFetchTime, models))
    private val modelsCache = mutableMapOf<String, Pair<Long, List<String>>>()
    private const val CACHE_DURATION_MS = 5 * 60 * 1000L // 5分钟缓存
    
    /**
     * 获取指定提供商的可用模型列表
     * 
     * @param baseUrl API的Base URL
     * @param apiKey API密钥
     * @param providerId 提供商ID (如 "openai", "deepseek" 等)
     * @param forceRefresh 是否强制刷新（忽略缓存）
     * @return Result<List<String>> 成功返回模型列表，失败返回错误信息
     */
    suspend fun fetchModels(
        baseUrl: String,
        apiKey: String,
        providerId: String,
        forceRefresh: Boolean = false
    ): Result<List<String>> = withContext(Dispatchers.IO) {
        try {
            LogManager.i(TAG, "📋 开始获取模型列表: provider=$providerId, baseUrl=$baseUrl")
            
            // 验证参数
            if (baseUrl.isBlank()) {
                return@withContext Result.failure(Exception("请先填写 Base URL"))
            }
            
            // 本地模型不需要API Key
            val isLocalModel = providerId == "local" || 
                baseUrl.contains("localhost") || 
                baseUrl.contains("127.0.0.1")
            
            if (apiKey.isBlank() && !isLocalModel) {
                return@withContext Result.failure(Exception("请先填写 API Key"))
            }
            
            // 检查缓存
            val cacheKey = "$providerId:$baseUrl:${apiKey.take(8)}"
            if (!forceRefresh) {
                modelsCache[cacheKey]?.let { (timestamp, models) ->
                    if (System.currentTimeMillis() - timestamp < CACHE_DURATION_MS) {
                        LogManager.i(TAG, "✅ 使用缓存的模型列表: ${models.size} 个模型")
                        return@withContext Result.success(models)
                    }
                }
            }
            
            // 创建临时 LLMClient 获取模型列表
            val client = LLMClient(
                baseUrl = baseUrl,
                apiKey = apiKey,
                modelName = "",
                providerId = providerId
            )
            
            val models = client.fetchAvailableModels()
            
            if (models.isEmpty()) {
                LogManager.i(TAG, "⚠️ 获取到空的模型列表")
                return@withContext Result.failure(Exception("未获取到模型列表，请检查API配置是否正确"))
            }
            
            // 更新缓存
            modelsCache[cacheKey] = System.currentTimeMillis() to models
            
            LogManager.i(TAG, "✅ 成功获取 ${models.size} 个模型")
            Result.success(models)
            
        } catch (e: Exception) {
            LogManager.i(TAG, "❌ 获取模型列表失败", e)
            Result.failure(Exception(getErrorMessage(e)))
        }
    }
    
    /**
     * 获取推荐的默认模型
     * 根据提供商返回推荐的默认模型名称
     */
    fun getDefaultModelForProvider(providerId: String): String {
        return when (providerId) {
            "openai" -> "gpt-4o"
            "deepseek" -> "deepseek-chat"
            "moonshot" -> "moonshot-v1-8k"
            "google", "google_openai" -> "gemini-1.5-flash"
            "zhipu" -> "glm-4"
            "openrouter" -> "openai/gpt-4o"
            "local" -> "llama3"
            else -> ""
        }
    }
    
    /**
     * 获取提供商的常用模型列表
     * 当无法获取实时模型列表时，提供预设选项
     */
    fun getPresetModelsForProvider(providerId: String): List<String> {
        return when (providerId) {
            "openai" -> listOf(
                "gpt-4o",
                "gpt-4o-mini", 
                "gpt-4-turbo",
                "gpt-4",
                "gpt-3.5-turbo"
            )
            "deepseek" -> listOf(
                "deepseek-chat",
                "deepseek-coder",
                "deepseek-reasoner"
            )
            "moonshot" -> listOf(
                "moonshot-v1-8k",
                "moonshot-v1-32k",
                "moonshot-v1-128k"
            )
            "google", "google_openai" -> listOf(
                "gemini-1.5-flash",
                "gemini-1.5-pro",
                "gemini-2.0-flash-exp",
                "gemini-1.0-pro"
            )
            "zhipu" -> listOf(
                "glm-4",
                "glm-4-flash",
                "glm-4-plus",
                "glm-3-turbo"
            )
            "openrouter" -> listOf(
                "openai/gpt-4o",
                "anthropic/claude-3-opus",
                "anthropic/claude-3-sonnet",
                "google/gemini-pro"
            )
            "local" -> listOf(
                "llama3",
                "llama3:8b",
                "mistral",
                "codellama",
                "qwen2"
            )
            else -> emptyList()
        }
    }
    
    /**
     * 清除指定提供商的缓存
     */
    fun clearCache(providerId: String? = null) {
        if (providerId != null) {
            modelsCache.keys.filter { it.startsWith("$providerId:") }
                .forEach { modelsCache.remove(it) }
        } else {
            modelsCache.clear()
        }
    }
    
    /**
     * 格式化错误消息
     */
    private fun getErrorMessage(e: Exception): String {
        val message = e.message ?: "未知错误"
        return when {
            message.contains("401") -> "API Key 无效或已过期"
            message.contains("403") -> "没有访问权限，请检查API Key"
            message.contains("404") -> "API端点不存在，请检查Base URL"
            message.contains("429") -> "请求过于频繁，请稍后再试"
            message.contains("timeout", ignoreCase = true) -> "连接超时，请检查网络"
            message.contains("Unable to resolve host") -> "无法连接服务器，请检查网络"
            else -> message
        }
    }
}
