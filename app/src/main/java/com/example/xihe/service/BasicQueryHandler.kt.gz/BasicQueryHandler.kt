package com.example.xihe.service

import android.content.Context
import android.os.Environment
import android.os.StatFs
import com.example.xihe.utils.LogManager
import com.example.xihe.tools.LifeApiTools
import com.example.xihe.security.PrivacyPermissionManager
import com.example.xihe.security.PrivacyPermissionManager.PrivacyType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/**
 * 基础功能查询处理器
 * 
 * 功能：
 * 1. 检测用户是否在询问基础信息（天气、时间、位置、文件等）
 * 2. 获取实时数据
 * 3. 将数据注入到AI回复的上下文中
 * 
 * 使用场景：
 * - "现在几点了"
 * - "今天天气怎么样"
 * - "我在哪里"
 * - "查看我的文件"
 * - "手机存储还有多少"
 */
object BasicQueryHandler {
    private const val TAG = "BasicQueryHandler"
    
    /**
     * 基础查询类型
     */
    enum class QueryType {
        TIME,           // 时间查询
        DATE,           // 日期查询
        WEATHER,        // 天气查询
        LOCATION,       // 位置查询
        STORAGE,        // 存储查询
        BATTERY,        // 电量查询
        DEVICE_INFO,    // 设备信息
        FILE_LIST,      // 文件列表
        NONE            // 非基础查询
    }
    
    /**
     * 查询结果
     */
    data class QueryResult(
        val type: QueryType,
        val success: Boolean,
        val data: String,
        val shouldInjectToContext: Boolean = true  // 是否需要注入到AI上下文
    )
    
    // ==================== 查询类型检测 ====================
    
    /**
     * 检测用户输入是否包含基础查询
     * 返回检测到的查询类型列表（可能同时问多个问题）
     */
    fun detectQueryTypes(input: String): List<QueryType> {
        val normalizedInput = input.lowercase().replace(" ", "")
        val detectedTypes = mutableListOf<QueryType>()
        
        // 时间相关关键词
        val timeKeywords = listOf(
            "几点", "现在时间", "什么时间", "当前时间", "时间是", "报时",
            "现在几点", "目前时间", "几点钟", "几点了"
        )
        if (timeKeywords.any { normalizedInput.contains(it) }) {
            detectedTypes.add(QueryType.TIME)
        }
        
        // 日期相关关键词
        val dateKeywords = listOf(
            "今天日期", "今天几号", "星期几", "什么日期", "当前日期",
            "今天是", "哪一天", "农历", "阳历", "几月几日", "几月几号"
        )
        if (dateKeywords.any { normalizedInput.contains(it) }) {
            detectedTypes.add(QueryType.DATE)
        }
        
        // 天气相关关键词
        val weatherKeywords = listOf(
            "天气", "气温", "温度", "下雨", "下雪", "晴天", "阴天",
            "多少度", "穿什么", "带伞", "会下雨", "冷不冷", "热不热",
            "天气怎么样", "天气如何", "今天天气", "明天天气"
        )
        if (weatherKeywords.any { normalizedInput.contains(it) }) {
            detectedTypes.add(QueryType.WEATHER)
        }
        
        // 位置相关关键词
        val locationKeywords = listOf(
            "在哪", "在哪里", "位置", "定位", "我的位置", "当前位置",
            "什么地方", "哪个城市", "所在地", "在什么地方", "我在哪"
        )
        if (locationKeywords.any { normalizedInput.contains(it) }) {
            detectedTypes.add(QueryType.LOCATION)
        }
        
        // 存储相关关键词
        val storageKeywords = listOf(
            "存储", "内存", "空间", "容量", "还有多少", "剩余空间",
            "存储空间", "手机内存", "可用空间", "占用多少"
        )
        if (storageKeywords.any { normalizedInput.contains(it) }) {
            detectedTypes.add(QueryType.STORAGE)
        }
        
        // 电量相关关键词
        val batteryKeywords = listOf(
            "电量", "电池", "还有多少电", "剩余电量", "充电",
            "电量多少", "电池电量", "还剩多少电"
        )
        if (batteryKeywords.any { normalizedInput.contains(it) }) {
            detectedTypes.add(QueryType.BATTERY)
        }
        
        // 设备信息关键词
        val deviceKeywords = listOf(
            "手机型号", "设备信息", "系统版本", "安卓版本",
            "什么手机", "手机信息"
        )
        if (deviceKeywords.any { normalizedInput.contains(it) }) {
            detectedTypes.add(QueryType.DEVICE_INFO)
        }
        
        // 文件相关关键词
        val fileKeywords = listOf(
            "文件", "图片", "照片", "视频", "音乐", "下载",
            "查看文件", "我的文件", "文件夹", "最近文件", "文档"
        )
        if (fileKeywords.any { normalizedInput.contains(it) }) {
            detectedTypes.add(QueryType.FILE_LIST)
        }
        
        return detectedTypes
    }
    
    /**
     * 检测是否是基础查询
     */
    fun isBasicQuery(input: String): Boolean {
        return detectQueryTypes(input).isNotEmpty()
    }
    
    // ==================== 数据获取 ====================
    
    /**
     * 处理基础查询，获取实时数据
     */
    suspend fun handleQuery(context: Context, input: String): List<QueryResult> {
        val queryTypes = detectQueryTypes(input)
        if (queryTypes.isEmpty()) {
            return emptyList()
        }
        
        LogManager.d(TAG, "检测到基础查询: $queryTypes")
        
        val results = mutableListOf<QueryResult>()
        
        for (type in queryTypes) {
            val result = when (type) {
                QueryType.TIME -> getTimeInfo()
                QueryType.DATE -> getDateInfo()
                QueryType.WEATHER -> getWeatherInfo(context, input)
                QueryType.LOCATION -> getLocationInfo(context)
                QueryType.STORAGE -> getStorageInfo()
                QueryType.BATTERY -> getBatteryInfo(context)
                QueryType.DEVICE_INFO -> getDeviceInfo(context)
                QueryType.FILE_LIST -> getFileListInfo(input)
                QueryType.NONE -> null
            }
            
            result?.let { results.add(it) }
        }
        
        return results
    }
    
    /**
     * 获取时间信息
     */
    private fun getTimeInfo(): QueryResult {
        return try {
            val now = Date()
            val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.CHINA)
            val time = timeFormat.format(now)
            
            // 判断时段
            val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            val period = when {
                hour < 6 -> "凌晨"
                hour < 9 -> "早上"
                hour < 12 -> "上午"
                hour < 14 -> "中午"
                hour < 18 -> "下午"
                hour < 22 -> "晚上"
                else -> "深夜"
            }
            
            val data = "当前时间是${period} $time"
            LogManager.d(TAG, " $data")
            QueryResult(QueryType.TIME, true, data)
        } catch (e: Exception) {
            LogManager.e(TAG, "获取时间失败", e)
            QueryResult(QueryType.TIME, false, "时间获取失败")
        }
    }
    
    /**
     * 获取日期信息
     */
    private fun getDateInfo(): QueryResult {
        return try {
            val result = LifeApiTools.getCurrentDateTime()
            if (result.success) {
                QueryResult(QueryType.DATE, true, "${result.data}")
            } else {
                // 备用方案
                val now = Date()
                val dateFormat = SimpleDateFormat("yyyy年MM月dd日", Locale.CHINA)
                val weekFormat = SimpleDateFormat("EEEE", Locale.CHINA)
                val data = "今天是${dateFormat.format(now)} ${weekFormat.format(now)}"
                QueryResult(QueryType.DATE, true, data)
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "获取日期失败", e)
            QueryResult(QueryType.DATE, false, "日期获取失败")
        }
    }
    
    /**
     * 获取天气信息
     */
    private suspend fun getWeatherInfo(context: Context, input: String): QueryResult {
        return try {
            // 检测用户是否指定了城市
            val cityPattern = Regex("(.+?)(天气|气温|温度)")
            val matchResult = cityPattern.find(input)
            val specifiedCity = matchResult?.groupValues?.get(1)?.trim()
                ?.replace("的", "")
                ?.replace("查", "")
                ?.replace("看", "")
                ?.replace("一下", "")
                ?.takeIf { it.length in 2..10 && !it.contains("今天") && !it.contains("明天") }
            
            LogManager.d(TAG, " 获取天气，指定城市: $specifiedCity")
            
            // 初始化 LifeApiTools
            LifeApiTools.init(context)
            
            val result = LifeApiTools.getWeatherWithAutoLocation(specifiedCity)
            
            if (result.success) {
                QueryResult(QueryType.WEATHER, true, "${result.data}")
            } else {
                QueryResult(QueryType.WEATHER, false, "天气获取失败：${result.data}")
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "获取天气失败", e)
            QueryResult(QueryType.WEATHER, false, "天气获取失败: ${e.message}")
        }
    }
    
    /**
     * 获取位置信息
     */
    private suspend fun getLocationInfo(context: Context): QueryResult {
        // 检查位置隐私权限 - 如果未授权，自动授权（优化用户体验）
        if (!PrivacyPermissionManager.hasPermission(PrivacyType.LOCATION)) {
            LogManager.d(TAG, " 位置隐私权限未授权，自动授权以提升体验")
            // 自动授权位置权限（用户可在设置中关闭）
            PrivacyPermissionManager.setPermission(PrivacyType.LOCATION, true)
        }
        
        // 初始化LocationManager
        LocationManager.init(context)
        
        return try {
            // 首先检查系统定位权限
            if (!LocationManager.hasLocationPermission(context)) {
                LogManager.w(TAG, " 系统定位权限未授予")
                return QueryResult(
                    QueryType.LOCATION, 
                    false, 
                    "需要定位权限：请先在系统设置中授予羲和定位权限，才能获取您的位置信息哦~",
                    shouldInjectToContext = true
                )
            }
            
            val city = LocationManager.getCurrentCity(context)
            
            if (city != null) {
                val data = "当前位置：你目前在：$city"
                LogManager.d(TAG, " $data")
                QueryResult(QueryType.LOCATION, true, data)
            } else {
                // 尝试获取更详细的位置信息
                val detailedLocation = LocationManager.getDetailedLocation(context)
                if (detailedLocation != null) {
                    QueryResult(QueryType.LOCATION, true, "$detailedLocation")
                } else {
                    QueryResult(QueryType.LOCATION, false, "位置获取失败：无法获取位置，可能是GPS信号弱或定位服务未开启，请检查设置")
                }
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "获取位置失败", e)
            QueryResult(QueryType.LOCATION, false, "位置获取失败: ${e.message}")
        }
    }
    
    /**
     * 获取存储信息
     */
    private fun getStorageInfo(): QueryResult {
        return try {
            val path = Environment.getDataDirectory()
            val stat = StatFs(path.path)
            
            val blockSize = stat.blockSizeLong
            val totalBlocks = stat.blockCountLong
            val availableBlocks = stat.availableBlocksLong
            
            val totalSize = totalBlocks * blockSize / (1024 * 1024 * 1024.0) // GB
            val availableSize = availableBlocks * blockSize / (1024 * 1024 * 1024.0) // GB
            val usedSize = totalSize - availableSize
            val usedPercent = (usedSize / totalSize * 100).toInt()
            
            val data = buildString {
                append("存储空间信息：\n")
                append("• 总空间：${String.format("%.1f", totalSize)} GB\n")
                append("• 已用：${String.format("%.1f", usedSize)} GB ($usedPercent%)\n")
                append("• 可用：${String.format("%.1f", availableSize)} GB")
            }
            
            LogManager.d(TAG, " $data")
            QueryResult(QueryType.STORAGE, true, data)
        } catch (e: Exception) {
            LogManager.e(TAG, "获取存储信息失败", e)
            QueryResult(QueryType.STORAGE, false, "存储信息获取失败")
        }
    }
    
    /**
     * 获取电量信息
     */
    private fun getBatteryInfo(context: Context): QueryResult {
        return try {
            val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager
            val batteryLevel = batteryManager.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
            val isCharging = batteryManager.isCharging
            
            val chargingStatus = if (isCharging) "充电中" else "未充电"
            val batteryEmoji = when {
                batteryLevel >= 80 -> ""
                batteryLevel >= 50 -> ""
                batteryLevel >= 20 -> ""
                else -> ""
            }
            
            val data = "电池状态：$batteryEmoji 当前电量：$batteryLevel% ($chargingStatus)"
            LogManager.d(TAG, data)
            QueryResult(QueryType.BATTERY, true, data)
        } catch (e: Exception) {
            LogManager.e(TAG, "获取电量失败", e)
            QueryResult(QueryType.BATTERY, false, "电量信息获取失败")
        }
    }
    
    /**
     * 获取设备信息
     */
    private fun getDeviceInfo(context: Context): QueryResult {
        return try {
            val manufacturer = android.os.Build.MANUFACTURER
            val model = android.os.Build.MODEL
            val androidVersion = android.os.Build.VERSION.RELEASE
            val sdkVersion = android.os.Build.VERSION.SDK_INT
            
            val data = buildString {
                append("设备信息：\n")
                append("• 品牌：$manufacturer\n")
                append("• 型号：$model\n")
                append("• Android版本：$androidVersion (API $sdkVersion)")
            }
            
            LogManager.d(TAG, " $data")
            QueryResult(QueryType.DEVICE_INFO, true, data)
        } catch (e: Exception) {
            LogManager.e(TAG, "获取设备信息失败", e)
            QueryResult(QueryType.DEVICE_INFO, false, "设备信息获取失败")
        }
    }
    
    /**
     * 获取文件列表信息
     */
    private fun getFileListInfo(input: String): QueryResult {
        // 检查文件隐私权限
        val normalizedInput = input.lowercase()
        
        // 根据查询内容确定需要的权限类型
        val requiredType = when {
            normalizedInput.contains("图片") || normalizedInput.contains("照片") -> PrivacyType.PHOTOS
            normalizedInput.contains("视频") -> PrivacyType.VIDEOS
            else -> PrivacyType.FILES
        }
        
        if (!PrivacyPermissionManager.hasPermission(requiredType)) {
            LogManager.d(TAG, " ${requiredType.displayName}权限未授权，需要用户确认")
            return QueryResult(
                QueryType.FILE_LIST, 
                false, 
                "需要隐私授权：访问${requiredType.displayName}需要您的授权，请在设置中开启隐私权限，或在弹窗中同意授权。",
                shouldInjectToContext = false
            )
        }
        
        return try {
            
            // 确定要查看的目录类型
            val targetDir = when {
                normalizedInput.contains("图片") || normalizedInput.contains("照片") -> 
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                normalizedInput.contains("视频") -> 
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
                normalizedInput.contains("音乐") -> 
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
                normalizedInput.contains("下载") -> 
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                normalizedInput.contains("文档") -> 
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
                else -> 
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            }
            
            val dirName = when {
                normalizedInput.contains("图片") || normalizedInput.contains("照片") -> "图片"
                normalizedInput.contains("视频") -> "视频"
                normalizedInput.contains("音乐") -> "音乐"
                normalizedInput.contains("下载") -> "下载"
                normalizedInput.contains("文档") -> "文档"
                else -> "下载"
            }
            
            if (!targetDir.exists()) {
                return QueryResult(QueryType.FILE_LIST, true, "${dirName}文件夹文件夹为空或不存在")
            }
            
            val files = targetDir.listFiles()?.sortedByDescending { it.lastModified() }?.take(10) ?: emptyList()
            
            if (files.isEmpty()) {
                return QueryResult(QueryType.FILE_LIST, true, "没有找到文件")
            }
            
            val dateFormat = SimpleDateFormat("MM-dd HH:mm", Locale.CHINA)
            
            val data = buildString {
                append("${dirName}文件夹最近的 ${files.size} 个文件：\n")
                files.forEachIndexed { index, file ->
                    val size = if (file.isDirectory) {
                        "文件夹"
                    } else {
                        val sizeKB = file.length() / 1024.0
                        if (sizeKB > 1024) {
                            String.format("%.1f MB", sizeKB / 1024)
                        } else {
                            String.format("%.0f KB", sizeKB)
                        }
                    }
                    val date = dateFormat.format(Date(file.lastModified()))
                    append("${index + 1}. ${file.name} ($size, $date)\n")
                }
            }
            
            LogManager.d(TAG, " 获取文件列表：${files.size} 个文件")
            QueryResult(QueryType.FILE_LIST, true, data)
        } catch (e: Exception) {
            LogManager.e(TAG, "获取文件列表失败", e)
            QueryResult(QueryType.FILE_LIST, false, "文件列表获取失败：${e.message}")
        }
    }
    
    // ==================== 上下文注入 ====================
    
    /**
     * 将查询结果格式化为LLM可理解的上下文
     */
    fun formatResultsForContext(results: List<QueryResult>): String {
        if (results.isEmpty()) return ""
        
        val successfulResults = results.filter { it.success }
        if (successfulResults.isEmpty()) return ""
        
        return buildString {
            append("\n\n【系统已获取的实时信息，请根据这些信息回答用户】\n")
            successfulResults.forEach { result ->
                append("${result.data}\n")
            }
            append("\n请用自然、友好的语气，基于以上实时信息回答用户的问题。")
        }
    }
    
    /**
     * 生成包含实时数据的增强提示词
     */
    suspend fun enhancePromptWithRealTimeData(
        context: Context,
        userInput: String,
        originalPrompt: String
    ): String {
        val results = handleQuery(context, userInput)
        
        if (results.isEmpty()) {
            return originalPrompt
        }
        
        val contextInfo = formatResultsForContext(results)
        
        return if (contextInfo.isNotEmpty()) {
            "$originalPrompt$contextInfo"
        } else {
            originalPrompt
        }
    }
}
