package com.example.xihe.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import com.example.xihe.utils.LogManager
import androidx.core.app.NotificationCompat
import com.example.xihe.MainActivity
import com.example.xihe.R
import com.example.xihe.training.AutoTrainingScheduler
import com.example.xihe.training.SystemMonitor
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * 🛡️ 保活前台服务
 *
 * 功能：
 * 1. 前台服务，显示常驻通知
 * 2. 定期检查训练状态
 * 3. 在空闲时自动启动训练
 * 4. 防止被系统杀死
 */
class KeepAliveService : Service() {

    companion object {
        private const val TAG = "KeepAliveService"
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "xihe_keep_alive"
        private const val CHANNEL_NAME = "羲和保活服务"
        
        // WakeLock 超时时间：10分钟
        private const val WAKE_LOCK_TIMEOUT = 10 * 60 * 1000L
        // 检查间隔（5分钟）
        private const val CHECK_INTERVAL = 5 * 60 * 1000L

        // 运行状态标志
        @Volatile
        var isRunning = false
            private set

        fun start(context: Context) {
            try {
                val intent = Intent(context, KeepAliveService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (e: Exception) {
                LogManager.e(TAG, "启动 KeepAliveService 失败", e)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, KeepAliveService::class.java)
            context.stopService(intent)
        }
    }

    // 使用 SupervisorJob 确保子协程失败不影响其他协程
    private val scope = CoroutineScope(
        SupervisorJob() +
        Dispatchers.Default +
        CoroutineName("KeepAliveServiceScope")
    )
    private var monitorJob: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        LogManager.d(TAG, "🛡️ KeepAliveService onCreate")
        isRunning = true

        // 创建通知渠道
        createNotificationChannel()

        // 启动前台服务
        startForeground(NOTIFICATION_ID, createNotification())

        // 获取唤醒锁（防止CPU休眠）
        acquireWakeLock()

        // 开始监控
        startMonitoring()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        LogManager.d(TAG, "🛡️ KeepAliveService onStartCommand")
        isRunning = true

        // 确保前台服务正在运行
        startForeground(NOTIFICATION_ID, createNotification())

        // 返回 START_STICKY 以确保服务被杀死后自动重启
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        LogManager.d(TAG, "🛡️ KeepAliveService onDestroy - 尝试重启")
        isRunning = false

        // 停止监控
        monitorJob?.cancel()
        
        // 取消协程作用域并等待完成
        scope.cancel("Service destroyed")
        
        // 释放唤醒锁（必须在super.onDestroy之前）
        releaseWakeLock()

        super.onDestroy()
        
        // 尝试重启服务（保活机制）- 在super.onDestroy之后
        if (isBackgroundWakeEnabled()) {
            restartService()
        } else {
            LogManager.d(TAG, "ℹ️ 后台唤醒未开启，停止自动重启")
        }
    }

    /**
     * 创建通知渠道
     */
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_LOW  // 低重要性，不会发出声音
            ).apply {
                description = "羲和AI助手后台运行服务，用于自动训练和保持应用活跃"
                setShowBadge(false)
            }

            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager?.createNotificationChannel(channel)
        }
    }

    /**
     * 创建前台通知
     */
    private fun createNotification(): Notification {
        // 点击通知打开应用
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("🤖 羲和AI助手正在运行")
            .setContentText("后台保活中，随时准备为您服务~")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setOngoing(true)  // 不可滑动删除
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    /**
     * 更新通知内容
     */
    private fun updateNotification(title: String, content: String) {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(content)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        val notificationManager = getSystemService(NotificationManager::class.java)
        notificationManager?.notify(NOTIFICATION_ID, notification)
    }

    /**
     * 开始监控
     */
    private fun startMonitoring() {
        monitorJob = scope.launch {
            LogManager.d(TAG, "📊 开始监控训练状态")

            while (isActive) {
                try {
                    checkAndStartTraining()
                    delay(CHECK_INTERVAL)
                } catch (e: Exception) {
                    LogManager.e(TAG, "监控出错", e)
                    delay(60000)  // 出错后等待1分钟
                }
            }
        }
    }

    /**
     * 检查并启动训练
     */
    private suspend fun checkAndStartTraining() {
        try {
            val systemMonitor = SystemMonitor.getInstance(this)
            val scheduler = AutoTrainingScheduler.getInstance(this)

            // 检查是否应该训练
            val recommendation = systemMonitor.trainingRecommendation.value

            if (recommendation?.shouldStartTraining == true || scheduler.shouldTrain()) {
                LogManager.d(TAG, "✅ 条件满足，准备启动训练")
                updateNotification("🎓 羲和正在学习", "自动训练模型中...")

                // 确保 WakeLock 有效
                renewWakeLock()

                // 启动训练
                scheduler.triggerTraining()

                // 等待一段时间（训练在后台进行）
                delay(60000)  // 等待1分钟

                updateNotification("🤖 羲和AI助手正在运行", "后台保活中，随时准备为您服务~")
            } else {
                LogManager.d(TAG, "⏸️ 暂不满足训练条件")
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "检查训练失败", e)
        }
    }

    /**
     * 获取唤醒锁
     * 添加超时保护，防止内存泄漏和电池耗尽
     */
    private fun acquireWakeLock() {
        try {
            releaseWakeLock() // 先释放旧的锁（如果有）

            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "XiheAI::KeepAliveWakeLock"
            ).apply {
                setReferenceCounted(false) // 非引用计数模式，便于管理
                acquire(WAKE_LOCK_TIMEOUT) // ⭐ 添加10分钟超时保护
                LogManager.d(TAG, "🔋 唤醒锁已获取（超时: ${WAKE_LOCK_TIMEOUT/1000/60}分钟）")
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "获取唤醒锁失败", e)
        }
    }

    /**
     * 续期唤醒锁
     * 在长时间任务执行时调用，确保 WakeLock 保持有效
     */
    private fun renewWakeLock() {
        try {
            wakeLock?.let {
                if (!it.isHeld) {
                    it.acquire(WAKE_LOCK_TIMEOUT)
                    LogManager.d(TAG, "🔋 唤醒锁已续期")
                }
            } ?: acquireWakeLock() // 如果没有锁，重新获取
        } catch (e: Exception) {
            LogManager.e(TAG, "续期唤醒锁失败", e)
        }
    }

    /**
     * 释放唤醒锁
     */
    private fun releaseWakeLock() {
        try {
            wakeLock?.let {
                if (it.isHeld) {
                    it.release()
                    LogManager.d(TAG, "🔋 唤醒锁已释放")
                }
            }
            wakeLock = null
        } catch (e: Exception) {
            LogManager.e(TAG, "释放唤醒锁失败", e)
        }
    }

    /**
     * 重启服务（保活机制）
     */
    private fun restartService() {
        try {
            LogManager.d(TAG, "🔄 发送保活广播以重启服务...")
            // 发送保活广播
            val intent = Intent("com.example.xihe.KEEP_ALIVE")
            intent.setPackage(packageName)
            sendBroadcast(intent)
        } catch (e: Exception) {
            LogManager.e(TAG, "重启服务失败", e)
        }
    }

    private fun isBackgroundWakeEnabled(): Boolean {
        val prefs = getSharedPreferences("xihe_settings", Context.MODE_PRIVATE)
        return prefs.getBoolean("enable_background_wake", false)
    }

    /**
     * 任务被移除时（用户在最近任务中清除应用）
     */
    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        LogManager.d(TAG, "⚠️ 任务被移除，准备重启服务")
        isRunning = false

        // 发送保活广播重启服务
        if (isBackgroundWakeEnabled()) {
            restartService()
        } else {
            LogManager.d(TAG, "ℹ️ 后台唤醒未开启，停止自动重启")
        }

        // 尝试直接重启
        if (isBackgroundWakeEnabled()) {
            start(applicationContext)
        }
    }
}
