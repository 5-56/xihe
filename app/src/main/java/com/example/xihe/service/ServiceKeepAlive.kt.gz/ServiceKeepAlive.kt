package com.example.xihe.service

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.SystemClock
import com.example.xihe.utils.LogManager

/**
 * 服务保活管理器
 * 使用 AlarmManager 定期检查并重启后台服务
 */
object ServiceKeepAlive {
    private const val TAG = "ServiceKeepAlive"
    private const val ACTION_KEEP_ALIVE = "com.example.xihe.KEEP_ALIVE"
    private const val INTERVAL_MS = 15 * 60 * 1000L  // 15分钟
    
    /**
     * 启动保活机制
     */
    fun start(context: Context) {
        LogManager.d(TAG, " 启动服务保活机制...")
        
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, KeepAliveReceiver::class.java).apply {
            action = ACTION_KEEP_ALIVE
        }
        
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        
        // 设置重复闹钟
        alarmManager.setRepeating(
            AlarmManager.ELAPSED_REALTIME_WAKEUP,
            SystemClock.elapsedRealtime() + INTERVAL_MS,
            INTERVAL_MS,
            pendingIntent
        )
        
        LogManager.d(TAG, " 保活闹钟已设置")
    }
    
    /**
     * 停止保活机制
     */
    fun stop(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, KeepAliveReceiver::class.java).apply {
            action = ACTION_KEEP_ALIVE
        }
        
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        
        alarmManager.cancel(pendingIntent)
        LogManager.d(TAG, " 保活闹钟已取消")
    }
    
    /**
     * 检查并重启服务
     */
    fun checkAndRestartService(context: Context) {
        // 检查唤醒词服务
        if (!WakeWordService.isRunning) {
            LogManager.i(TAG, " 检测到唤醒词服务未运行，正在重启...")
            startWakeWordService(context)
        }
        
        // 检查保活训练服务
        if (!KeepAliveService.isRunning) {
            LogManager.i(TAG, " 检测到保活服务未运行，正在重启...")
            startKeepAliveService(context)
        }
        
        LogManager.d(TAG, " 服务状态检查完成")
    }
    
    /**
     * 启动唤醒词服务
     */
    fun startWakeWordService(context: Context) {
        try {
            val intent = Intent(context, WakeWordService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
            LogManager.i(TAG, " 唤醒词服务已启动")
        } catch (e: Exception) {
            LogManager.e(TAG, "启动唤醒词服务失败", e)
        }
    }
    
    /**
     * 启动保活服务
     */
    fun startKeepAliveService(context: Context) {
        try {
            KeepAliveService.start(context)
            LogManager.i(TAG, " 保活服务已启动")
        } catch (e: Exception) {
            LogManager.e(TAG, "启动保活服务失败", e)
        }
    }
}

/**
 * 保活广播接收器
 */
class KeepAliveReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent?.action != "com.example.xihe.KEEP_ALIVE") {
            return
        }

        LogManager.d("KeepAliveReceiver", " 收到保活广播...")
        context?.let {
            val prefs = it.getSharedPreferences("xihe_settings", Context.MODE_PRIVATE)
            if (!prefs.getBoolean("enable_background_wake", false)) {
                LogManager.d("KeepAliveReceiver", " 后台唤醒未开启，忽略保活广播")
                return
            }

            ServiceKeepAlive.checkAndRestartService(it)
        }
    }
}
