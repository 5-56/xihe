package com.example.xihe.service

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.os.Bundle
import android.os.Looper
import com.example.xihe.utils.LogManager
import androidx.core.app.ActivityCompat
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import kotlin.coroutines.resume

/**
 * 位置管理器
 * 获取用户当前位置，用于本地天气查询
 * 使用 Android 原生 LocationManager API
 */
object LocationManager {
    private const val TAG = "LocationManager"
    
    private var androidLocationManager: android.location.LocationManager? = null
    private var lastKnownCity: String? = null
    private var lastLocationTime: Long = 0
    private const val LOCATION_CACHE_TIME = 10 * 60 * 1000L  // 10分钟缓存
    
    fun init(context: Context) {
        androidLocationManager = context.getSystemService(Context.LOCATION_SERVICE) as? android.location.LocationManager
        LogManager.i(TAG, "位置管理器初始化完成")
    }
    
    /**
     * 检查是否有定位权限
     */
    fun hasLocationPermission(context: Context): Boolean {
        return ActivityCompat.checkSelfPermission(
            context, 
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED ||
        ActivityCompat.checkSelfPermission(
            context, 
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }
    
    /**
     * 获取当前城市名称
     */
    suspend fun getCurrentCity(context: Context): String? {
        // 检查缓存
        if (lastKnownCity != null && 
            System.currentTimeMillis() - lastLocationTime < LOCATION_CACHE_TIME) {
            LogManager.i(TAG, "使用缓存的城市: $lastKnownCity")
            return lastKnownCity
        }
        
        if (!hasLocationPermission(context)) {
            LogManager.i(TAG, "没有定位权限")
            return null
        }
        
        return try {
            val location = getLastLocation(context)
            if (location != null) {
                val city = getCityFromLocation(context, location)
                if (city != null) {
                    lastKnownCity = city
                    lastLocationTime = System.currentTimeMillis()
                    LogManager.i(TAG, "获取到城市: $city")
                }
                city
            } else {
                LogManager.i(TAG, "无法获取位置")
                null
            }
        } catch (e: Exception) {
            LogManager.i(TAG, "获取城市失败", e)
            null
        }
    }
    
    /**
     * 获取最后已知位置
     */
    @Suppress("MissingPermission")
    private suspend fun getLastLocation(context: Context): Location? = 
        suspendCancellableCoroutine { continuation ->
            val locationManager = androidLocationManager 
                ?: context.getSystemService(Context.LOCATION_SERVICE) as? android.location.LocationManager
            
            if (locationManager == null) {
                LogManager.i(TAG, "LocationManager 不可用")
                continuation.resume(null)
                return@suspendCancellableCoroutine
            }
            
            try {
                // 尝试获取最后已知位置
                var location: Location? = null
                
                // 尝试 GPS
                if (locationManager.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER)) {
                    location = locationManager.getLastKnownLocation(android.location.LocationManager.GPS_PROVIDER)
                }
                
                // 尝试网络定位
                if (location == null && locationManager.isProviderEnabled(android.location.LocationManager.NETWORK_PROVIDER)) {
                    location = locationManager.getLastKnownLocation(android.location.LocationManager.NETWORK_PROVIDER)
                }
                
                // 尝试被动定位
                if (location == null) {
                    location = locationManager.getLastKnownLocation(android.location.LocationManager.PASSIVE_PROVIDER)
                }
                
                if (location != null) {
                    LogManager.i(TAG, "获取到最后位置: ${location.latitude}, ${location.longitude}")
                    continuation.resume(location)
                } else {
                    // 请求一次位置更新
                    LogManager.i(TAG, "没有缓存位置，请求单次更新...")
                    requestSingleLocation(context, locationManager) { newLocation ->
                        continuation.resume(newLocation)
                    }
                }
            } catch (e: Exception) {
                LogManager.i(TAG, "位置请求异常", e)
                continuation.resume(null)
            }
        }
    
    /**
     * 请求单次位置更新
     */
    @Suppress("MissingPermission")
    private fun requestSingleLocation(
        context: Context, 
        locationManager: android.location.LocationManager,
        callback: (Location?) -> Unit
    ) {
        val locationListener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                locationManager.removeUpdates(this)
                callback(location)
            }
            
            @Deprecated("Deprecated in Java")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }
        
        try {
            val provider = when {
                locationManager.isProviderEnabled(android.location.LocationManager.NETWORK_PROVIDER) -> 
                    android.location.LocationManager.NETWORK_PROVIDER
                locationManager.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER) -> 
                    android.location.LocationManager.GPS_PROVIDER
                else -> {
                    callback(null)
                    return
                }
            }
            
            locationManager.requestSingleUpdate(provider, locationListener, Looper.getMainLooper())
            
            // 5秒超时
            android.os.Handler(Looper.getMainLooper()).postDelayed({
                locationManager.removeUpdates(locationListener)
                if (lastKnownCity == null) {
                    callback(null)
                }
            }, 5000)
            
        } catch (e: Exception) {
            LogManager.i(TAG, "请求位置更新失败", e)
            callback(null)
        }
    }
    
    /**
     * 从经纬度获取城市名称
     */
    private fun getCityFromLocation(context: Context, location: Location): String? {
        return try {
            val geocoder = Geocoder(context, Locale.CHINESE)
            @Suppress("DEPRECATION")
            val addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1)
            
            if (!addresses.isNullOrEmpty()) {
                val address = addresses[0]
                // 优先使用城市名，其次是区域名
                val city = address.locality ?: address.subAdminArea ?: address.adminArea
                LogManager.i(TAG, "地理编码结果: $city (${address.adminArea}/${address.subAdminArea}/${address.locality})")
                city
            } else {
                null
            }
        } catch (e: Exception) {
            LogManager.i(TAG, "地理编码失败", e)
            null
        }
    }
    
    /**
     * 获取缓存的城市（不进行网络请求）
     */
    fun getCachedCity(): String? = lastKnownCity
    
    /**
     * 清除缓存
     */
    fun clearCache() {
        lastKnownCity = null
        lastLocationTime = 0
    }
    
    /**
     * 获取详细位置信息（包括省市区）
     */
    suspend fun getDetailedLocation(context: Context): String? {
        if (!hasLocationPermission(context)) {
            return null
        }
        
        return try {
            val location = getLastLocation(context)
            if (location != null) {
                val geocoder = Geocoder(context, Locale.CHINESE)
                @Suppress("DEPRECATION")
                val addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1)
                
                if (!addresses.isNullOrEmpty()) {
                    val address = addresses[0]
                    val province = address.adminArea ?: ""
                    val city = address.locality ?: address.subAdminArea ?: ""
                    val district = address.subLocality ?: ""
                    val street = address.thoroughfare ?: ""
                    
                    buildString {
                        append("你目前在")
                        if (province.isNotBlank()) append(province)
                        if (city.isNotBlank() && city != province) append(city)
                        if (district.isNotBlank()) append(district)
                        if (street.isNotBlank()) append("，$street 附近")
                        append("（经度: %.4f, 纬度: %.4f）".format(location.longitude, location.latitude))
                    }
                } else {
                    "位置: 经度 %.4f, 纬度 %.4f（无法获取地址名称）".format(location.longitude, location.latitude)
                }
            } else {
                null
            }
        } catch (e: Exception) {
            LogManager.i(TAG, "获取详细位置失败", e)
            null
        }
    }
}
