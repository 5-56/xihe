package com.example.xihe.calendar

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

/**
 * 📅 日历与提醒管理器
 * 提供日历事件、闹钟、提醒等功能
 */
class CalendarManager private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "CalendarManager"
        
        @Volatile
        private var instance: CalendarManager? = null
        
        fun getInstance(context: Context): CalendarManager {
            return instance ?: synchronized(this) {
                instance ?: CalendarManager(context.applicationContext).also { instance = it }
            }
        }
    }
    
    private val contentResolver = context.contentResolver
    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    
    /**
     * 日历事件
     */
    data class CalendarEvent(
        val id: Long,
        val title: String,
        val description: String?,
        val location: String?,
        val startTime: Long,
        val endTime: Long,
        val allDay: Boolean,
        val calendarId: Long,
        val calendarName: String?
    )
    
    /**
     * 闹钟信息
     */
    data class Alarm(
        val id: Int,
        val hour: Int,
        val minute: Int,
        val label: String?,
        val enabled: Boolean,
        val repeatDays: List<Int> = emptyList() // 0=周日, 1=周一, ..., 6=周六
    )
    
    /**
     * 提醒信息
     */
    data class Reminder(
        val id: String,
        val title: String,
        val description: String?,
        val time: Long,
        val type: ReminderType
    )
    
    enum class ReminderType {
        ONE_TIME,   // 一次性
        DAILY,      // 每日
        WEEKLY,     // 每周
        MONTHLY     // 每月
    }
    
    // ==================== 日历事件管理 ====================
    
    /**
     * 📅 创建日历事件
     */
    suspend fun createEvent(
        title: String,
        description: String? = null,
        location: String? = null,
        startTime: Long,
        endTime: Long,
        allDay: Boolean = false,
        calendarId: Long? = null
    ): Long? = withContext(Dispatchers.IO) {
        if (!checkPermission(Manifest.permission.WRITE_CALENDAR)) {
            LogManager.w(TAG, "⚠️ 没有写入日历权限")
            return@withContext null
        }
        
        try {
            val actualCalendarId = calendarId ?: getPrimaryCalendarId()
            if (actualCalendarId == null) {
                LogManager.w(TAG, "⚠️ 未找到可用日历")
                return@withContext null
            }
            
            val values = ContentValues().apply {
                put(CalendarContract.Events.CALENDAR_ID, actualCalendarId)
                put(CalendarContract.Events.TITLE, title)
                put(CalendarContract.Events.DESCRIPTION, description)
                put(CalendarContract.Events.EVENT_LOCATION, location)
                put(CalendarContract.Events.DTSTART, startTime)
                put(CalendarContract.Events.DTEND, endTime)
                put(CalendarContract.Events.ALL_DAY, if (allDay) 1 else 0)
                put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
            }
            
            val uri = contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
            val eventId = uri?.lastPathSegment?.toLongOrNull()
            
            if (eventId != null) {
                LogManager.i(TAG, "✅ 创建日历事件成功: $title (ID: $eventId)")
            }
            
            eventId
        } catch (e: Exception) {
            LogManager.e(TAG, "创建日历事件失败", e)
            null
        }
    }
    
    /**
     * 🔍 获取日历事件
     */
    suspend fun getEvents(
        startTime: Long,
        endTime: Long,
        limit: Int = 100
    ): List<CalendarEvent> = withContext(Dispatchers.IO) {
        if (!checkPermission(Manifest.permission.READ_CALENDAR)) {
            LogManager.w(TAG, "⚠️ 没有读取日历权限")
            return@withContext emptyList()
        }
        
        val events = mutableListOf<CalendarEvent>()
        
        try {
            val projection = arrayOf(
                CalendarContract.Events._ID,
                CalendarContract.Events.TITLE,
                CalendarContract.Events.DESCRIPTION,
                CalendarContract.Events.EVENT_LOCATION,
                CalendarContract.Events.DTSTART,
                CalendarContract.Events.DTEND,
                CalendarContract.Events.ALL_DAY,
                CalendarContract.Events.CALENDAR_ID,
                CalendarContract.Events.CALENDAR_DISPLAY_NAME
            )
            
            val selection = "(${CalendarContract.Events.DTSTART} >= ? AND ${CalendarContract.Events.DTSTART} <= ?)"
            val selectionArgs = arrayOf(startTime.toString(), endTime.toString())
            
            val cursor = contentResolver.query(
                CalendarContract.Events.CONTENT_URI,
                projection,
                selection,
                selectionArgs,
                "${CalendarContract.Events.DTSTART} ASC LIMIT $limit"
            )
            
            cursor?.use {
                while (it.moveToNext()) {
                    val id = it.getLong(0)
                    val title = it.getString(1) ?: ""
                    val description = it.getString(2)
                    val location = it.getString(3)
                    val start = it.getLong(4)
                    val end = it.getLong(5)
                    val allDay = it.getInt(6) == 1
                    val calendarId = it.getLong(7)
                    val calendarName = it.getString(8)
                    
                    events.add(
                        CalendarEvent(
                            id, title, description, location,
                            start, end, allDay, calendarId, calendarName
                        )
                    )
                }
            }
            
            LogManager.d(TAG, "📅 获取日历事件: ${events.size}个")
        } catch (e: Exception) {
            LogManager.e(TAG, "获取日历事件失败", e)
        }
        
        events
    }
    
    /**
     * 📅 获取今天的事件
     */
    suspend fun getTodayEvents(): List<CalendarEvent> = withContext(Dispatchers.IO) {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        val startTime = calendar.timeInMillis
        
        calendar.set(Calendar.HOUR_OF_DAY, 23)
        calendar.set(Calendar.MINUTE, 59)
        calendar.set(Calendar.SECOND, 59)
        val endTime = calendar.timeInMillis
        
        getEvents(startTime, endTime)
    }
    
    /**
     * 📅 获取本周的事件
     */
    suspend fun getWeekEvents(): List<CalendarEvent> = withContext(Dispatchers.IO) {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        val startTime = calendar.timeInMillis
        
        calendar.add(Calendar.WEEK_OF_YEAR, 1)
        val endTime = calendar.timeInMillis
        
        getEvents(startTime, endTime)
    }
    
    /**
     * 🗑️ 删除日历事件
     */
    suspend fun deleteEvent(eventId: Long): Boolean = withContext(Dispatchers.IO) {
        if (!checkPermission(Manifest.permission.WRITE_CALENDAR)) {
            LogManager.w(TAG, "⚠️ 没有写入日历权限")
            return@withContext false
        }
        
        try {
            val uri = ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, eventId)
            val deleted = contentResolver.delete(uri, null, null)
            
            LogManager.d(TAG, "🗑️ 删除日历事件: $eventId, 结果: $deleted")
            deleted > 0
        } catch (e: Exception) {
            LogManager.e(TAG, "删除日历事件失败", e)
            false
        }
    }
    
    /**
     * ✏️ 更新日历事件
     */
    suspend fun updateEvent(
        eventId: Long,
        title: String? = null,
        description: String? = null,
        location: String? = null,
        startTime: Long? = null,
        endTime: Long? = null
    ): Boolean = withContext(Dispatchers.IO) {
        if (!checkPermission(Manifest.permission.WRITE_CALENDAR)) {
            LogManager.w(TAG, "⚠️ 没有写入日历权限")
            return@withContext false
        }
        
        try {
            val values = ContentValues().apply {
                title?.let { put(CalendarContract.Events.TITLE, it) }
                description?.let { put(CalendarContract.Events.DESCRIPTION, it) }
                location?.let { put(CalendarContract.Events.EVENT_LOCATION, it) }
                startTime?.let { put(CalendarContract.Events.DTSTART, it) }
                endTime?.let { put(CalendarContract.Events.DTEND, it) }
            }
            
            val uri = ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, eventId)
            val updated = contentResolver.update(uri, values, null, null)
            
            LogManager.d(TAG, "✏️ 更新日历事件: $eventId, 结果: $updated")
            updated > 0
        } catch (e: Exception) {
            LogManager.e(TAG, "更新日历事件失败", e)
            false
        }
    }
    
    /**
     * 🔍 搜索日历事件
     */
    suspend fun searchEvents(keyword: String): List<CalendarEvent> = withContext(Dispatchers.IO) {
        if (!checkPermission(Manifest.permission.READ_CALENDAR)) {
            return@withContext emptyList()
        }
        
        val events = mutableListOf<CalendarEvent>()
        
        try {
            val projection = arrayOf(
                CalendarContract.Events._ID,
                CalendarContract.Events.TITLE,
                CalendarContract.Events.DESCRIPTION,
                CalendarContract.Events.EVENT_LOCATION,
                CalendarContract.Events.DTSTART,
                CalendarContract.Events.DTEND,
                CalendarContract.Events.ALL_DAY,
                CalendarContract.Events.CALENDAR_ID,
                CalendarContract.Events.CALENDAR_DISPLAY_NAME
            )
            
            val selection = "(${CalendarContract.Events.TITLE} LIKE ? OR ${CalendarContract.Events.DESCRIPTION} LIKE ?)"
            val selectionArgs = arrayOf("%$keyword%", "%$keyword%")
            
            val cursor = contentResolver.query(
                CalendarContract.Events.CONTENT_URI,
                projection,
                selection,
                selectionArgs,
                "${CalendarContract.Events.DTSTART} DESC LIMIT 50"
            )
            
            cursor?.use {
                while (it.moveToNext()) {
                    val id = it.getLong(0)
                    val title = it.getString(1) ?: ""
                    val description = it.getString(2)
                    val location = it.getString(3)
                    val start = it.getLong(4)
                    val end = it.getLong(5)
                    val allDay = it.getInt(6) == 1
                    val calendarId = it.getLong(7)
                    val calendarName = it.getString(8)
                    
                    events.add(
                        CalendarEvent(
                            id, title, description, location,
                            start, end, allDay, calendarId, calendarName
                        )
                    )
                }
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "搜索日历事件失败", e)
        }
        
        events
    }
    
    /**
     * 📅 获取主日历ID
     */
    private fun getPrimaryCalendarId(): Long? {
        try {
            val projection = arrayOf(
                CalendarContract.Calendars._ID,
                CalendarContract.Calendars.IS_PRIMARY
            )
            
            val cursor = contentResolver.query(
                CalendarContract.Calendars.CONTENT_URI,
                projection,
                null, null, null
            )
            
            cursor?.use {
                while (it.moveToNext()) {
                    val id = it.getLong(0)
                    val isPrimary = it.getInt(1) == 1
                    if (isPrimary) {
                        return id
                    }
                }
                // 如果没有主日历，返回第一个
                if (it.moveToFirst()) {
                    return it.getLong(0)
                }
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "获取主日历ID失败", e)
        }
        
        return null
    }
    
    // ==================== 闹钟管理 ====================
    
    /**
     * ⏰ 设置闹钟
     */
    fun setAlarm(
        hour: Int,
        minute: Int,
        label: String? = null,
        repeatDays: List<Int> = emptyList()
    ): Boolean {
        return try {
            val intent = Intent(android.provider.AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(android.provider.AlarmClock.EXTRA_HOUR, hour)
                putExtra(android.provider.AlarmClock.EXTRA_MINUTES, minute)
                putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, label)
                putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, true)
                
                if (repeatDays.isNotEmpty()) {
                    val days = ArrayList<Int>()
                    repeatDays.forEach { days.add(it + 1) } // Android闹钟API使用1-7
                    putExtra(android.provider.AlarmClock.EXTRA_DAYS, days)
                }
                
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            
            context.startActivity(intent)
            LogManager.i(TAG, "⏰ 设置闹钟: $hour:$minute")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "设置闹钟失败", e)
            false
        }
    }
    
    /**
     * ⏱️ 设置定时器
     */
    fun setTimer(seconds: Int, message: String? = null): Boolean {
        return try {
            val intent = Intent(android.provider.AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(android.provider.AlarmClock.EXTRA_LENGTH, seconds)
                putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, message)
                putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            
            context.startActivity(intent)
            LogManager.i(TAG, "⏱️ 设置定时器: ${seconds}秒")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "设置定时器失败", e)
            false
        }
    }
    
    /**
     * 🔔 创建提醒
     */
    fun createReminder(
        title: String,
        description: String? = null,
        time: Long,
        type: ReminderType = ReminderType.ONE_TIME
    ): Boolean {
        return try {
            val intent = Intent(context, ReminderReceiver::class.java).apply {
                putExtra("title", title)
                putExtra("description", description)
                putExtra("type", type.name)
            }
            
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                time.toInt(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                time,
                pendingIntent
            )
            
            LogManager.i(TAG, "🔔 创建提醒: $title")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "创建提醒失败", e)
            false
        }
    }
    
    /**
     * 🗑️ 取消提醒
     */
    fun cancelReminder(reminderId: Int): Boolean {
        return try {
            val intent = Intent(context, ReminderReceiver::class.java)
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                reminderId,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            
            alarmManager.cancel(pendingIntent)
            LogManager.d(TAG, "🗑️ 取消提醒: $reminderId")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "取消提醒失败", e)
            false
        }
    }
    
    /**
     * 📅 快速创建事件
     */
    suspend fun quickCreateEvent(
        title: String,
        dateTime: String,
        duration: Int = 60
    ): Long? {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
            val startTime = sdf.parse(dateTime)?.time ?: System.currentTimeMillis()
            val endTime = startTime + duration * 60 * 1000
            
            createEvent(title, startTime = startTime, endTime = endTime)
        } catch (e: Exception) {
            LogManager.e(TAG, "快速创建事件失败", e)
            null
        }
    }
    
    /**
     * ✅ 检查权限
     */
    private fun checkPermission(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
    }
}

/**
 * 📢 提醒接收器
 */
class ReminderReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        // 处理提醒逻辑
        val title = intent?.getStringExtra("title")
        val description = intent?.getStringExtra("description")
        LogManager.d("ReminderReceiver", "收到提醒: $title")
        // 可以在这里发送通知
    }
}

/**
 * ContentUris辅助类
 */
object ContentUris {
    fun withAppendedId(uri: Uri, id: Long): Uri {
        return Uri.withAppendedPath(uri, id.toString())
    }
}
