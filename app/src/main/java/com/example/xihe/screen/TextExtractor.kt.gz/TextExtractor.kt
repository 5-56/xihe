package com.example.xihe.screen

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import com.example.xihe.utils.LogManager
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.*

/**
 * 📝 文本提取器
 * 从屏幕提取文本内容
 */
class TextExtractor(
    private val service: AccessibilityService
) {
    
    companion object {
        private const val TAG = "TextExtractor"
    }
    
    /**
     * 📝 提取所有文本
     */
    fun extractAllText(): ExtractedText {
        val rootNode = service.rootInActiveWindow ?: run {
            LogManager.w(TAG, "⚠️ 无法获取根节点")
            return ExtractedText(
                fullText = "",
                textBlocks = emptyList(),
                textCount = 0
            )
        }
        
        val textBlocks = mutableListOf<TextBlock>()
        extractTextRecursive(rootNode, textBlocks)
        
        val fullText = textBlocks.joinToString("\n") { it.text }
        
        LogManager.d(TAG, "📝 提取了 ${textBlocks.size} 个文本块")
        
        return ExtractedText(
            fullText = fullText,
            textBlocks = textBlocks,
            textCount = textBlocks.size
        )
    }
    
    /**
     * 🌲 递归提取文本
     */
    private fun extractTextRecursive(node: AccessibilityNodeInfo, textBlocks: MutableList<TextBlock>) {
        try {
            if (node.isVisibleToUser) {
                val text = node.text?.toString()
                val contentDesc = node.contentDescription?.toString()
                
                if (!text.isNullOrBlank() || !contentDesc.isNullOrBlank()) {
                    val bounds = Rect()
                    node.getBoundsInScreen(bounds)
                    
                    val textBlock = TextBlock(
                        text = text ?: contentDesc ?: "",
                        bounds = bounds,
                        className = node.className?.toString() ?: "",
                        isEditable = node.isEditable,
                        isClickable = node.isClickable
                    )
                    
                    textBlocks.add(textBlock)
                }
            }
            
            for (i in 0 until node.childCount) {
                val child = node.getChild(i)
                if (child != null) {
                    extractTextRecursive(child, textBlocks)
                }
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 提取文本失败", e)
        }
    }
    
    /**
     * 🔍 提取特定区域的文本
     */
    fun extractTextInRegion(region: Rect): List<TextBlock> {
        val allText = extractAllText()
        return allText.textBlocks.filter { textBlock ->
            Rect.intersects(region, textBlock.bounds)
        }
    }
    
    /**
     * 🔍 搜索文本
     */
    fun searchText(query: String, ignoreCase: Boolean = true): List<TextBlock> {
        val allText = extractAllText()
        return allText.textBlocks.filter { textBlock ->
            textBlock.text.contains(query, ignoreCase)
        }
    }
    
    /**
     * 📊 提取所有按钮文本
     */
    fun extractButtonTexts(): List<String> {
        val allText = extractAllText()
        return allText.textBlocks
            .filter { it.isClickable && it.text.isNotBlank() }
            .map { it.text }
            .distinct()
    }
    
    /**
     * 📋 提取所有列表项文本
     */
    fun extractListItemTexts(): List<String> {
        val allText = extractAllText()
        return allText.textBlocks
            .filter { 
                it.className.contains("TextView", ignoreCase = true) &&
                it.text.isNotBlank()
            }
            .map { it.text }
    }
    
    /**
     * 📝 提取标题文本
     */
    fun extractTitleText(): String? {
        val rootNode = service.rootInActiveWindow ?: return null
        
        // 尝试查找标题栏
        val titleNode = findNodeByClassName(rootNode, "android.widget.TextView")
        val title = titleNode?.text?.toString()
        
        return title
    }
    
    /**
     * 🔍 根据类名查找节点
     */
    private fun findNodeByClassName(node: AccessibilityNodeInfo, className: String): AccessibilityNodeInfo? {
        try {
            if (node.className?.toString()?.equals(className, ignoreCase = true) == true) {
                return node
            }
            
            for (i in 0 until node.childCount) {
                val child = node.getChild(i)
                if (child != null) {
                    val result = findNodeByClassName(child, className)
                    if (result != null) {
                        return result
                    }
                }
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 查找节点失败", e)
        }
        
        return null
    }
    
    /**
     * 📊 分析文本统计
     */
    fun analyzeTextStatistics(): TextStatistics {
        val extracted = extractAllText()
        val fullText = extracted.fullText
        
        return TextStatistics(
            totalCharacters = fullText.length,
            totalWords = fullText.split("\\s+".toRegex()).size,
            totalLines = extracted.textBlocks.size,
            chineseCharacters = fullText.count { it.toString().matches("[\u4e00-\u9fa5]".toRegex()) },
            englishWords = fullText.split("\\s+".toRegex())
                .count { it.matches("[a-zA-Z]+".toRegex()) },
            numbers = fullText.count { it.isDigit() },
            punctuation = fullText.count { !it.isLetterOrDigit() && !it.isWhitespace() }
        )
    }
    
    /**
     * 🎯 提取关键信息
     */
    fun extractKeyInfo(): KeyInfo {
        val extracted = extractAllText()
        val fullText = extracted.fullText
        
        // 提取电话号码
        val phonePattern = "1[3-9]\\d{9}".toRegex()
        val phones = phonePattern.findAll(fullText).map { it.value }.toList()
        
        // 提取邮箱
        val emailPattern = "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}".toRegex()
        val emails = emailPattern.findAll(fullText).map { it.value }.toList()
        
        // 提取URL
        val urlPattern = "https?://[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}[/\\w.-]*".toRegex()
        val urls = urlPattern.findAll(fullText).map { it.value }.toList()
        
        // 提取价格
        val pricePattern = "¥\\s*\\d+(\\.\\d{1,2})?|\\d+(\\.\\d{1,2})?\\s*元".toRegex()
        val prices = pricePattern.findAll(fullText).map { it.value }.toList()
        
        return KeyInfo(
            phones = phones,
            emails = emails,
            urls = urls,
            prices = prices
        )
    }
    
    /**
     * 💾 导出文本内容
     */
    fun exportText(format: ExportFormat = ExportFormat.PLAIN): String {
        val extracted = extractAllText()
        
        return when (format) {
            ExportFormat.PLAIN -> {
                extracted.fullText
            }
            ExportFormat.STRUCTURED -> {
                val sb = StringBuilder()
                sb.appendLine("屏幕文本提取")
                sb.appendLine("=".repeat(50))
                sb.appendLine("提取时间: ${System.currentTimeMillis()}")
                sb.appendLine("文本块数: ${extracted.textCount}")
                sb.appendLine()
                
                for ((index, block) in extracted.textBlocks.withIndex()) {
                    sb.appendLine("文本块 #${index + 1}")
                    sb.appendLine("  内容: ${block.text}")
                    sb.appendLine("  位置: (${block.bounds.left}, ${block.bounds.top})")
                    sb.appendLine("  类型: ${block.className}")
                    sb.appendLine("-".repeat(50))
                }
                
                sb.toString()
            }
            ExportFormat.JSON -> {
                // 简单的JSON格式
                val sb = StringBuilder()
                sb.appendLine("{")
                sb.appendLine("  \"timestamp\": ${System.currentTimeMillis()},")
                sb.appendLine("  \"textCount\": ${extracted.textCount},")
                sb.appendLine("  \"textBlocks\": [")
                
                extracted.textBlocks.forEachIndexed { index, block ->
                    sb.appendLine("    {")
                    sb.appendLine("      \"text\": \"${block.text.replace("\"", "\\\"")}\",")
                    sb.appendLine("      \"bounds\": {")
                    sb.appendLine("        \"left\": ${block.bounds.left},")
                    sb.appendLine("        \"top\": ${block.bounds.top},")
                    sb.appendLine("        \"right\": ${block.bounds.right},")
                    sb.appendLine("        \"bottom\": ${block.bounds.bottom}")
                    sb.appendLine("      }")
                    sb.append("    }")
                    if (index < extracted.textBlocks.size - 1) {
                        sb.appendLine(",")
                    } else {
                        sb.appendLine()
                    }
                }
                
                sb.appendLine("  ]")
                sb.appendLine("}")
                
                sb.toString()
            }
        }
    }
    
    // ============ 数据类型 ============
    
    /**
     * 📝 提取的文本
     */
    data class ExtractedText(
        val fullText: String,
        val textBlocks: List<TextBlock>,
        val textCount: Int
    )
    
    /**
     * 📦 文本块
     */
    data class TextBlock(
        val text: String,
        val bounds: Rect,
        val className: String,
        val isEditable: Boolean,
        val isClickable: Boolean
    )
    
    /**
     * 📊 文本统计
     */
    data class TextStatistics(
        val totalCharacters: Int,
        val totalWords: Int,
        val totalLines: Int,
        val chineseCharacters: Int,
        val englishWords: Int,
        val numbers: Int,
        val punctuation: Int
    )
    
    /**
     * 🎯 关键信息
     */
    data class KeyInfo(
        val phones: List<String>,
        val emails: List<String>,
        val urls: List<String>,
        val prices: List<String>
    )
    
    /**
     * 📄 导出格式
     */
    enum class ExportFormat {
        PLAIN,          // 纯文本
        STRUCTURED,     // 结构化文本
        JSON            // JSON格式
    }
}
