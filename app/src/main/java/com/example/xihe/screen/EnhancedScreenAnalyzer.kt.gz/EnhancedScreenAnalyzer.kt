package com.example.xihe.screen

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import com.example.xihe.utils.LogManager
import com.example.xihe.utils.GeometryUtils
import android.view.accessibility.AccessibilityNodeInfo
import com.example.xihe.ocr.OCRManager
import com.example.xihe.ocr.TextMatchResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ConcurrentHashMap

/**
 * 🔍 增强屏幕分析器
 * 
 * 功能：
 * - 📝 OCR文字识别集成
 * - 🎨 UI布局理解
 * - 🏷️ 语义元素识别
 * - 🎯 多策略元素定位
 * - 📊 屏幕状态管理
 */
object EnhancedScreenAnalyzer {
    
    private const val TAG = "EnhancedScreen"
    
    private var context: Context? = null
    private var ocrManager: OCRManager? = null
    
    // 屏幕状态缓存
    private val screenStateCache = ConcurrentHashMap<Long, EnhancedScreenState>()
    private const val CACHE_MAX_SIZE = 10
    private const val CACHE_VALID_DURATION = 2000L // 2秒
    
    // 屏幕历史记录
    private val _screenHistory = MutableStateFlow<List<ScreenSnapshot>>(emptyList())
    val screenHistory = _screenHistory.asStateFlow()
    
    // 页面类型识别模式
    private val pageTypePatterns = mapOf(
        PageType.CHAT to listOf("发送", "消息", "聊天", "输入", "表情", "语音"),
        PageType.LIST to listOf("列表", "更多", "加载", "刷新", "筛选"),
        PageType.SEARCH to listOf("搜索", "搜一搜", "找", "查找", "search"),
        PageType.LOGIN to listOf("登录", "注册", "密码", "验证码", "手机号"),
        PageType.SETTINGS to listOf("设置", "关于", "版本", "账号", "隐私"),
        PageType.PAYMENT to listOf("支付", "付款", "金额", "确认支付", "密码"),
        PageType.FORM to listOf("提交", "填写", "必填", "选择", "确定"),
        PageType.DETAIL to listOf("详情", "介绍", "评论", "收藏", "分享")
    )
    
    // 语义元素模式
    private val semanticPatterns = mapOf(
        SemanticType.SEARCH_BOX to listOf("搜索", "search", "搜一搜", "查找"),
        SemanticType.SEND_BUTTON to listOf("发送", "send", "发表", "提交"),
        SemanticType.CONFIRM_BUTTON to listOf("确定", "确认", "好的", "ok", "是"),
        SemanticType.CANCEL_BUTTON to listOf("取消", "cancel", "关闭", "否"),
        SemanticType.BACK_BUTTON to listOf("返回", "back", "←", "<"),
        SemanticType.MORE_BUTTON to listOf("更多", "more", "...", "⋮"),
        SemanticType.INPUT_FIELD to listOf("输入", "请输入", "input"),
        SemanticType.LOGIN_BUTTON to listOf("登录", "login", "登陆"),
        SemanticType.REGISTER_BUTTON to listOf("注册", "register", "sign up"),
        SemanticType.PAY_BUTTON to listOf("支付", "付款", "pay", "购买"),
        SemanticType.SHARE_BUTTON to listOf("分享", "share", "转发"),
        SemanticType.LIKE_BUTTON to listOf("点赞", "喜欢", "like", "❤"),
        SemanticType.COMMENT_BUTTON to listOf("评论", "comment", "留言"),
        SemanticType.MENU_BUTTON to listOf("菜单", "menu", "☰", "≡")
    )
    
    /**
     * 🚀 初始化
     */
    fun initialize(appContext: Context) {
        context = appContext.applicationContext
        ocrManager = OCRManager.getInstance(appContext)
        LogManager.i(TAG, "✅ EnhancedScreenAnalyzer 初始化完成")
    }
    
    // ==================== 📱 综合屏幕分析 ====================
    
    /**
     * 📱 分析屏幕（综合分析）
     */
    suspend fun analyzeScreen(
        rootNode: AccessibilityNodeInfo?,
        screenshot: Bitmap? = null,
        packageName: String = ""
    ): EnhancedScreenState {
        val startTime = System.currentTimeMillis()
        LogManager.d(TAG, "🔍 开始综合屏幕分析...")
        
        // 1. 基础UI树分析
        val uiElements = if (rootNode != null) {
            analyzeUITree(rootNode)
        } else {
            emptyList()
        }
        
        // 2. OCR文字识别（如果有截图）
        val ocrResult = if (screenshot != null) {
            val manager = ocrManager  // 保存到局部变量避免并发问题
            if (manager != null) {
                try {
                    manager.recognizeText(screenshot)
                } catch (e: Exception) {
                    LogManager.e(TAG, "OCR识别失败", e)
                    null
                }
            } else {
                null
            }
        } else {
            null
        }
        
        // 3. 识别页面类型
        val pageType = identifyPageType(uiElements, ocrResult)
        
        // 4. 识别语义元素
        val semanticElements = identifySemanticElements(uiElements, ocrResult)
        
        // 5. 分析布局结构
        val layoutInfo = analyzeLayout(uiElements)
        
        // 6. 检测特殊状态
        val hasDialog = detectDialog(uiElements)
        val hasKeyboard = detectKeyboard(rootNode)
        val isLoading = detectLoading(uiElements, ocrResult)
        
        val state = EnhancedScreenState(
            timestamp = startTime,
            packageName = packageName,
            pageType = pageType,
            uiElements = uiElements,
            semanticElements = semanticElements,
            layoutInfo = layoutInfo,
            ocrTexts = ocrResult?.textBlocks?.map { it.text } ?: emptyList(),
            hasDialog = hasDialog,
            hasKeyboard = hasKeyboard,
            isLoading = isLoading,
            analysisTime = System.currentTimeMillis() - startTime
        )
        
        // 缓存结果
        cacheScreenState(state)
        
        // 记录历史
        addToHistory(state, screenshot)
        
        LogManager.d(TAG, "✅ 屏幕分析完成: ${uiElements.size}个元素, 页面类型=$pageType, 耗时=${state.analysisTime}ms")
        return state
    }
    
    /**
     * 🌳 分析UI树
     */
    private fun analyzeUITree(rootNode: AccessibilityNodeInfo): List<EnhancedUIElement> {
        val elements = mutableListOf<EnhancedUIElement>()
        var elementId = 0
        
        fun traverse(node: AccessibilityNodeInfo, depth: Int, parentId: Int?) {
            val id = elementId++
            val bounds = Rect()
            node.getBoundsInScreen(bounds)
            
            // 推断元素类型
            val elementType = inferElementType(node)
            
            // 推断语义
            val semanticType = inferSemanticType(node)
            
            val element = EnhancedUIElement(
                id = id,
                parentId = parentId,
                depth = depth,
                className = node.className?.toString() ?: "",
                text = node.text?.toString(),
                contentDescription = node.contentDescription?.toString(),
                resourceId = node.viewIdResourceName,
                bounds = ElementBounds(bounds.left, bounds.top, bounds.right, bounds.bottom),
                elementType = elementType,
                semanticType = semanticType,
                isClickable = node.isClickable,
                isLongClickable = node.isLongClickable,
                isScrollable = node.isScrollable,
                isEditable = node.isEditable,
                isCheckable = node.isCheckable,
                isChecked = node.isChecked,
                isEnabled = node.isEnabled,
                isSelected = node.isSelected,
                isFocused = node.isFocused,
                isVisible = bounds.width() > 0 && bounds.height() > 0
            )
            
            elements.add(element)
            
            // 遍历子节点
            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { child ->
                    traverse(child, depth + 1, id)
                    child.recycle()
                }
            }
        }
        
        traverse(rootNode, 0, null)
        return elements
    }
    
    /**
     * 🏷️ 推断元素类型
     */
    private fun inferElementType(node: AccessibilityNodeInfo): UIElementType {
        val className = node.className?.toString()?.lowercase() ?: ""
        
        return when {
            className.contains("button") -> UIElementType.BUTTON
            className.contains("edittext") || node.isEditable -> UIElementType.INPUT
            className.contains("imageview") -> UIElementType.IMAGE
            className.contains("textview") -> UIElementType.TEXT
            className.contains("checkbox") -> UIElementType.CHECKBOX
            className.contains("switch") -> UIElementType.SWITCH
            className.contains("radiobutton") -> UIElementType.RADIO
            className.contains("recyclerview") || className.contains("listview") -> UIElementType.LIST
            className.contains("webview") -> UIElementType.WEBVIEW
            className.contains("progressbar") -> UIElementType.PROGRESS
            className.contains("seekbar") -> UIElementType.SLIDER
            className.contains("tabhost") || className.contains("tablayout") -> UIElementType.TAB
            node.isScrollable -> UIElementType.SCROLLABLE
            node.isClickable -> UIElementType.CLICKABLE
            else -> UIElementType.OTHER
        }
    }
    
    /**
     * 🎯 推断语义类型
     */
    private fun inferSemanticType(node: AccessibilityNodeInfo): SemanticType? {
        val text = (node.text?.toString() ?: "").lowercase()
        val desc = (node.contentDescription?.toString() ?: "").lowercase()
        val combined = "$text $desc"
        
        for ((semantic, patterns) in semanticPatterns) {
            if (patterns.any { combined.contains(it.lowercase()) }) {
                return semantic
            }
        }
        
        return null
    }
    
    // ==================== 🏷️ 页面类型识别 ====================
    
    /**
     * 📄 识别页面类型
     */
    private fun identifyPageType(
        elements: List<EnhancedUIElement>,
        ocrResult: OCRManager.OCRResult?
    ): PageType {
        // 收集所有文本
        val allTexts = mutableListOf<String>()
        elements.forEach { e ->
            e.text?.let { allTexts.add(it.lowercase()) }
            e.contentDescription?.let { allTexts.add(it.lowercase()) }
        }
        ocrResult?.textBlocks?.forEach { allTexts.add(it.text.lowercase()) }
        
        val combinedText = allTexts.joinToString(" ")
        
        // 计算每种页面类型的匹配分数
        val scores = pageTypePatterns.mapValues { (_, patterns) ->
            patterns.count { combinedText.contains(it.lowercase()) }
        }
        
        // 返回最高分的类型
        return scores.maxByOrNull { it.value }?.let {
            if (it.value >= 2) it.key else PageType.UNKNOWN
        } ?: PageType.UNKNOWN
    }
    
    // ==================== 🎯 语义元素识别 ====================
    
    /**
     * 🏷️ 识别语义元素
     */
    private fun identifySemanticElements(
        elements: List<EnhancedUIElement>,
        ocrResult: OCRManager.OCRResult?
    ): List<SemanticElement> {
        val semanticElements = mutableListOf<SemanticElement>()
        
        // 从UI元素识别
        elements.filter { it.semanticType != null }.forEach { element ->
            element.semanticType?.let { semanticType ->
                semanticElements.add(SemanticElement(
                    type = semanticType,
                    elementId = element.id,
                    text = element.text ?: element.contentDescription,
                    bounds = element.bounds,
                    confidence = 0.9f,
                    source = "accessibility"
                ))
            }
        }
        
        // 从OCR结果识别
        ocrResult?.textBlocks?.forEach { block ->
            val text = block.text.lowercase()
            for ((semantic, patterns) in semanticPatterns) {
                if (patterns.any { text.contains(it.lowercase()) }) {
                    block.boundingBox?.let { box ->
                        semanticElements.add(SemanticElement(
                            type = semantic,
                            elementId = null,
                            text = block.text,
                            bounds = ElementBounds(box.left, box.top, box.right, box.bottom),
                            confidence = 0.7f,
                            source = "ocr"
                        ))
                    }
                }
            }
        }
        
        return semanticElements
    }
    
    // ==================== 📐 布局分析 ====================
    
    /**
     * 📐 分析布局结构
     */
    private fun analyzeLayout(elements: List<EnhancedUIElement>): LayoutInfo {
        if (elements.isEmpty()) {
            return LayoutInfo()
        }
        
        // 识别顶部栏
        val topBar = elements.filter { 
            it.bounds.top < 200 && it.isClickable
        }
        
        // 识别底部栏
        val bottomBar = elements.filter { 
            it.bounds.bottom > 2000 && it.isClickable
        }
        
        // 识别列表区域
        val lists = elements.filter { 
            it.elementType == UIElementType.LIST || it.isScrollable
        }
        
        // 识别输入框
        val inputs = elements.filter { 
            it.elementType == UIElementType.INPUT || it.isEditable
        }
        
        // 识别按钮
        val buttons = elements.filter { 
            it.elementType == UIElementType.BUTTON || 
            (it.isClickable && it.text != null)
        }
        
        return LayoutInfo(
            hasTopBar = topBar.isNotEmpty(),
            hasBottomBar = bottomBar.isNotEmpty(),
            hasScrollableContent = lists.isNotEmpty(),
            inputCount = inputs.size,
            buttonCount = buttons.size,
            totalElements = elements.size,
            maxDepth = elements.maxOfOrNull { it.depth } ?: 0
        )
    }
    
    // ==================== 🔍 元素定位 ====================
    
    /**
     * 🎯 多策略元素查找
     */
    fun findElement(
        state: EnhancedScreenState,
        query: ElementQuery
    ): List<ElementMatch> {
        val matches = mutableListOf<ElementMatch>()
        
        // 策略1: 通过ID查找
        if (query.resourceId != null) {
            val byId = state.uiElements.filter { 
                it.resourceId?.contains(query.resourceId) == true 
            }
            byId.forEach { e ->
                matches.add(ElementMatch(e, MatchStrategy.BY_ID, 1.0f))
            }
        }
        
        // 策略2: 通过文本查找
        if (query.text != null) {
            val normalizedQuery = query.text.lowercase()
            state.uiElements.forEach { e ->
                val text = (e.text ?: "").lowercase()
                val desc = (e.contentDescription ?: "").lowercase()
                
                val textSimilarity = calculateSimilarity(text, normalizedQuery)
                val descSimilarity = calculateSimilarity(desc, normalizedQuery)
                val maxSimilarity = maxOf(textSimilarity, descSimilarity)
                
                if (maxSimilarity >= query.minSimilarity) {
                    matches.add(ElementMatch(e, MatchStrategy.BY_TEXT, maxSimilarity))
                }
            }
        }
        
        // 策略3: 通过语义类型查找
        if (query.semanticType != null) {
            val bySemantic = state.semanticElements.filter { 
                it.type == query.semanticType 
            }
            bySemantic.forEach { se ->
                val element = state.uiElements.find { it.id == se.elementId }
                if (element != null) {
                    matches.add(ElementMatch(element, MatchStrategy.BY_SEMANTIC, se.confidence))
                }
            }
        }
        
        // 策略4: 通过位置查找
        if (query.nearX != null && query.nearY != null) {
            state.uiElements.forEach { e ->
                val distance = calculateDistance(
                    query.nearX, query.nearY,
                    e.bounds.centerX, e.bounds.centerY
                )
                if (distance <= (query.maxDistance ?: 200)) {
                    val score = 1.0f - (distance / 500f).coerceAtMost(1.0f)
                    matches.add(ElementMatch(e, MatchStrategy.BY_POSITION, score))
                }
            }
        }
        
        // 策略5: 通过元素类型查找
        if (query.elementType != null) {
            val byType = state.uiElements.filter { it.elementType == query.elementType }
            byType.forEach { e ->
                matches.add(ElementMatch(e, MatchStrategy.BY_TYPE, 0.8f))
            }
        }
        
        // 合并相同元素的匹配结果，取最高分
        val uniqueMatches = matches
            .groupBy { it.element.id }
            .mapNotNull { (_, group) -> group.maxByOrNull { it.score } }
            .sortedByDescending { it.score }
        
        return uniqueMatches
    }
    
    /**
     * 🎯 等待元素出现
     */
    suspend fun waitForElement(
        query: ElementQuery,
        rootNodeProvider: suspend () -> AccessibilityNodeInfo?,
        timeout: Long = 5000,
        pollInterval: Long = 500
    ): EnhancedUIElement? {
        val startTime = System.currentTimeMillis()
        
        while (System.currentTimeMillis() - startTime < timeout) {
            val rootNode = rootNodeProvider()
            if (rootNode != null) {
                val state = analyzeScreen(rootNode, null, "")
                val matches = findElement(state, query)
                if (matches.isNotEmpty()) {
                    LogManager.d(TAG, "✅ 找到元素: ${matches.first().element.text}")
                    return matches.first().element
                }
            }
            kotlinx.coroutines.delay(pollInterval)
        }
        
        LogManager.w(TAG, "⏰ 等待元素超时: $query")
        return null
    }
    
    // ==================== 📊 屏幕状态管理 ====================
    
    /**
     * 💾 缓存屏幕状态
     */
    private fun cacheScreenState(state: EnhancedScreenState) {
        // 清理旧缓存
        if (screenStateCache.size >= CACHE_MAX_SIZE) {
            val oldestKey = screenStateCache.keys.minOrNull()
            oldestKey?.let { screenStateCache.remove(it) }
        }
        screenStateCache[state.timestamp] = state
    }
    
    /**
     * 📂 获取缓存的屏幕状态
     */
    fun getCachedState(): EnhancedScreenState? {
        val now = System.currentTimeMillis()
        return screenStateCache.values
            .filter { now - it.timestamp < CACHE_VALID_DURATION }
            .maxByOrNull { it.timestamp }
    }
    
    /**
     * 📜 添加到历史记录
     */
    private fun addToHistory(state: EnhancedScreenState, screenshot: Bitmap?) {
        val snapshot = ScreenSnapshot(
            timestamp = state.timestamp,
            packageName = state.packageName,
            pageType = state.pageType,
            elementCount = state.uiElements.size,
            hasScreenshot = screenshot != null
        )
        
        val history = _screenHistory.value.toMutableList()
        history.add(snapshot)
        
        // 保留最近50条记录
        if (history.size > 50) {
            history.removeAt(0)
        }
        
        _screenHistory.value = history
    }
    
    /**
     * 🔄 检测屏幕变化
     */
    fun detectScreenChange(
        oldState: EnhancedScreenState?,
        newState: EnhancedScreenState
    ): ScreenChange {
        if (oldState == null) {
            return ScreenChange(
                hasChanged = true,
                changeType = ChangeType.NEW_SCREEN,
                changedElements = emptyList()
            )
        }
        
        // 检测页面类型变化
        if (oldState.pageType != newState.pageType) {
            return ScreenChange(
                hasChanged = true,
                changeType = ChangeType.PAGE_TYPE_CHANGED,
                oldPageType = oldState.pageType,
                newPageType = newState.pageType
            )
        }
        
        // 检测元素数量变化
        val elementDiff = newState.uiElements.size - oldState.uiElements.size
        if (kotlin.math.abs(elementDiff) > 5) {
            return ScreenChange(
                hasChanged = true,
                changeType = ChangeType.ELEMENTS_CHANGED,
                elementCountDiff = elementDiff
            )
        }
        
        // 检测弹窗变化
        if (oldState.hasDialog != newState.hasDialog) {
            return ScreenChange(
                hasChanged = true,
                changeType = if (newState.hasDialog) ChangeType.DIALOG_APPEARED else ChangeType.DIALOG_DISMISSED
            )
        }
        
        return ScreenChange(hasChanged = false, changeType = ChangeType.NO_CHANGE)
    }
    
    // ==================== 🔧 辅助方法 ====================
    
    private fun detectDialog(elements: List<EnhancedUIElement>): Boolean {
        return elements.any { e ->
            e.className.contains("Dialog", ignoreCase = true) ||
            e.className.contains("PopupWindow", ignoreCase = true) ||
            e.contentDescription?.contains("对话框") == true
        }
    }
    
    private fun detectKeyboard(rootNode: AccessibilityNodeInfo?): Boolean {
        // 简单检测：查找输入法相关的包名
        return rootNode?.packageName?.toString()?.contains("inputmethod") == true
    }
    
    private fun detectLoading(
        elements: List<EnhancedUIElement>,
        ocrResult: OCRManager.OCRResult?
    ): Boolean {
        val hasProgressBar = elements.any { it.elementType == UIElementType.PROGRESS }
        val hasLoadingText = ocrResult?.fullText?.contains("加载") == true ||
                            ocrResult?.fullText?.contains("loading") == true
        return hasProgressBar || hasLoadingText
    }
    
    private fun calculateSimilarity(s1: String, s2: String): Float {
        if (s1 == s2) return 1.0f
        if (s1.isEmpty() || s2.isEmpty()) return 0.0f
        if (s1.contains(s2) || s2.contains(s1)) {
            return minOf(s1.length, s2.length).toFloat() / maxOf(s1.length, s2.length)
        }
        return 0.0f
    }
    
    private fun calculateDistance(x1: Int, y1: Int, x2: Int, y2: Int): Int {
        return GeometryUtils.calculateDistance(x1, y1, x2, y2).toInt()
    }
}

// ==================== 📦 数据类定义 ====================

/**
 * 📱 增强屏幕状态
 */
data class EnhancedScreenState(
    val timestamp: Long,
    val packageName: String,
    val pageType: PageType,
    val uiElements: List<EnhancedUIElement>,
    val semanticElements: List<SemanticElement>,
    val layoutInfo: LayoutInfo,
    val ocrTexts: List<String>,
    val hasDialog: Boolean,
    val hasKeyboard: Boolean,
    val isLoading: Boolean,
    val analysisTime: Long
)

/**
 * 🎨 增强UI元素
 */
data class EnhancedUIElement(
    val id: Int,
    val parentId: Int?,
    val depth: Int,
    val className: String,
    val text: String?,
    val contentDescription: String?,
    val resourceId: String?,
    val bounds: ElementBounds,
    val elementType: UIElementType,
    val semanticType: SemanticType?,
    val isClickable: Boolean,
    val isLongClickable: Boolean,
    val isScrollable: Boolean,
    val isEditable: Boolean,
    val isCheckable: Boolean,
    val isChecked: Boolean,
    val isEnabled: Boolean,
    val isSelected: Boolean,
    val isFocused: Boolean,
    val isVisible: Boolean
)

/**
 * 📐 元素边界
 */
data class ElementBounds(
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int
) {
    val centerX: Int get() = (left + right) / 2
    val centerY: Int get() = (top + bottom) / 2
    val width: Int get() = right - left
    val height: Int get() = bottom - top
}

/**
 * 🎨 UI元素类型
 */
enum class UIElementType {
    BUTTON, INPUT, TEXT, IMAGE, CHECKBOX, SWITCH, RADIO,
    LIST, WEBVIEW, PROGRESS, SLIDER, TAB, SCROLLABLE, CLICKABLE, OTHER
}

/**
 * 🏷️ 语义类型
 */
enum class SemanticType {
    SEARCH_BOX, SEND_BUTTON, CONFIRM_BUTTON, CANCEL_BUTTON,
    BACK_BUTTON, MORE_BUTTON, INPUT_FIELD, LOGIN_BUTTON,
    REGISTER_BUTTON, PAY_BUTTON, SHARE_BUTTON, LIKE_BUTTON,
    COMMENT_BUTTON, MENU_BUTTON
}

/**
 * 📄 页面类型
 */
enum class PageType {
    HOME, CHAT, LIST, SEARCH, LOGIN, SETTINGS, PAYMENT, FORM, DETAIL, UNKNOWN
}

/**
 * 🏷️ 语义元素
 */
data class SemanticElement(
    val type: SemanticType,
    val elementId: Int?,
    val text: String?,
    val bounds: ElementBounds,
    val confidence: Float,
    val source: String
)

/**
 * 📐 布局信息
 */
data class LayoutInfo(
    val hasTopBar: Boolean = false,
    val hasBottomBar: Boolean = false,
    val hasScrollableContent: Boolean = false,
    val inputCount: Int = 0,
    val buttonCount: Int = 0,
    val totalElements: Int = 0,
    val maxDepth: Int = 0
)

/**
 * 🔍 元素查询
 */
data class ElementQuery(
    val text: String? = null,
    val resourceId: String? = null,
    val semanticType: SemanticType? = null,
    val elementType: UIElementType? = null,
    val nearX: Int? = null,
    val nearY: Int? = null,
    val maxDistance: Int? = null,
    val minSimilarity: Float = 0.7f
)

/**
 * 🎯 元素匹配结果
 */
data class ElementMatch(
    val element: EnhancedUIElement,
    val strategy: MatchStrategy,
    val score: Float
)

/**
 * 🎯 匹配策略
 */
enum class MatchStrategy {
    BY_ID, BY_TEXT, BY_SEMANTIC, BY_POSITION, BY_TYPE
}

/**
 * 📜 屏幕快照
 */
data class ScreenSnapshot(
    val timestamp: Long,
    val packageName: String,
    val pageType: PageType,
    val elementCount: Int,
    val hasScreenshot: Boolean
)

/**
 * 🔄 屏幕变化
 */
data class ScreenChange(
    val hasChanged: Boolean,
    val changeType: ChangeType,
    val oldPageType: PageType? = null,
    val newPageType: PageType? = null,
    val elementCountDiff: Int = 0,
    val changedElements: List<Int> = emptyList()
)

/**
 * 🔄 变化类型
 */
enum class ChangeType {
    NO_CHANGE, NEW_SCREEN, PAGE_TYPE_CHANGED, ELEMENTS_CHANGED,
    DIALOG_APPEARED, DIALOG_DISMISSED, CONTENT_UPDATED
}
