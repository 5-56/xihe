package com.example.xihe.screen

import android.graphics.Rect
import com.example.xihe.utils.LogManager
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.serialization.Serializable

/**
 * 📱 屏幕分析器
 * 智能分析屏幕内容，理解UI结构和语义
 */
class ScreenAnalyzer {
    
    companion object {
        private const val TAG = "ScreenAnalyzer"
    }
    
    /**
     * 屏幕状态
     */
    @Serializable
    data class ScreenState(
        val timestamp: Long = System.currentTimeMillis(),
        val packageName: String = "",
        val activityName: String = "",
        val elements: List<UIElement> = emptyList(),
        val screenType: ScreenType = ScreenType.UNKNOWN,
        val appScene: String = "UNKNOWN", // 使用String而不是enum以兼容序列化
        val hasDialog: Boolean = false,
        val hasKeyboard: Boolean = false,
        val scrollable: Boolean = false,
        val metadata: Map<String, String> = emptyMap(),
        val contextHints: String = "" // 🆕 上下文提示，帮助AI理解当前场景
    )
    
    /**
     * UI元素
     */
    @Serializable
    data class UIElement(
        val id: String,
        val className: String,
        val text: String? = null,
        val contentDescription: String? = null,
        val bounds: ElementBounds,
        val type: ElementType,
        val clickable: Boolean = false,
        val scrollable: Boolean = false,
        val editable: Boolean = false,
        val checked: Boolean = false,
        val enabled: Boolean = true,
        val selected: Boolean = false,
        val children: List<UIElement> = emptyList(),
        val semanticInfo: SemanticInfo? = null
    )
    
    /**
     * 元素边界
     */
    @Serializable
    data class ElementBounds(
        val left: Int,
        val top: Int,
        val right: Int,
        val bottom: Int,
        val centerX: Int = (left + right) / 2,
        val centerY: Int = (top + bottom) / 2
    )
    
    /**
     * 元素类型
     */
    enum class ElementType {
        BUTTON,
        TEXT,
        EDIT_TEXT,
        IMAGE,
        LIST,
        LIST_ITEM,
        CHECKBOX,
        RADIO_BUTTON,
        SWITCH,
        TAB,
        MENU,
        DIALOG,
        WEBVIEW,
        VIDEO,
        UNKNOWN
    }
    
    /**
     * 屏幕类型
     */
    enum class ScreenType {
        HOME,           // 主屏幕
        LAUNCHER,       // 启动器
        CHAT,           // 聊天界面
        LIST,           // 列表界面
        DETAIL,         // 详情页
        SETTINGS,       // 设置页
        FORM,           // 表单页
        WEBVIEW,        // 网页
        VIDEO_PLAYER,   // 视频播放
        DIALOG,         // 对话框
        KEYBOARD,       // 键盘
        
        // 🆕 智能场景识别
        SHORT_VIDEO,    // 短视频（抖音、快手等）
        LONG_VIDEO,     // 长视频（B站、YouTube等）
        NOVEL_READER,   // 小说阅读
        NEWS_FEED,      // 新闻资讯流
        SHOPPING,       // 购物界面
        SOCIAL_FEED,    // 社交媒体信息流
        MUSIC_PLAYER,   // 音乐播放
        IMAGE_GALLERY,  // 图片浏览
        BROWSER,        // 浏览器
        
        UNKNOWN         // 未知
    }
    
    /**
     * 应用场景 - 更细粒度的场景识别
     */
    enum class AppScene {
        // 视频类
        SHORT_VIDEO_FEED,      // 短视频信息流（上下滑动切换）
        VIDEO_PLAYING,         // 视频播放中
        VIDEO_LIST,            // 视频列表
        
        // 阅读类
        NOVEL_READING,         // 小说阅读中（上下翻页）
        ARTICLE_READING,       // 文章阅读
        
        // 购物类
        PRODUCT_LIST,          // 商品列表（左右滑动）
        PRODUCT_DETAIL,        // 商品详情
        SHOPPING_CART,         // 购物车
        
        // 社交类
        SOCIAL_TIMELINE,       // 社交时间线
        CHAT_CONVERSATION,     // 聊天对话
        
        // 通用
        SCROLLABLE_LIST,       // 可滚动列表
        STATIC_PAGE,           // 静态页面
        UNKNOWN
    }
    
    /**
     * 语义信息
     */
    @Serializable
    data class SemanticInfo(
        val purpose: String? = null,      // 元素用途
        val importance: Float = 0.5f,     // 重要性 0-1
        val actionHint: String? = null,   // 操作提示
        val relatedElements: List<String> = emptyList() // 相关元素ID
    )
    
    /**
     * 分析屏幕
     */
    fun analyzeScreen(rootNode: AccessibilityNodeInfo?): ScreenState {
        if (rootNode == null) {
            LogManager.e(TAG, "根节点为空，无法分析屏幕")
            return ScreenState()
        }
        
        LogManager.d(TAG, "开始分析屏幕: ${rootNode.packageName}")
        
        // 提取所有UI元素
        val elements = extractElements(rootNode)
        
        val packageName = rootNode.packageName?.toString() ?: ""
        
        // 识别屏幕类型
        val screenType = identifyScreenType(elements, packageName)
        
        // 识别应用场景
        val appScene = identifyAppScene(elements, packageName, screenType)
        
        // 生成上下文提示
        val contextHints = generateContextHints(packageName, screenType, appScene, elements)
        
        // 检测特殊状态
        val hasDialog = detectDialog(elements)
        val hasKeyboard = detectKeyboard(rootNode)
        val scrollable = elements.any { it.scrollable }
        
        // 添加语义信息
        enrichSemanticInfo(elements, screenType)
        
        val state = ScreenState(
            packageName = packageName,
            activityName = rootNode.className?.toString() ?: "",
            elements = elements,
            screenType = screenType,
            appScene = appScene.name,
            hasDialog = hasDialog,
            hasKeyboard = hasKeyboard,
            scrollable = scrollable,
            metadata = extractMetadata(rootNode, elements),
            contextHints = contextHints
        )
        
        LogManager.d(TAG, "屏幕分析完成: 类型=$screenType, 元素数=${elements.size}")
        return state
    }
    
    /**
     * 提取所有元素
     */
    private fun extractElements(
        node: AccessibilityNodeInfo,
        parentId: String = "root",
        depth: Int = 0
    ): List<UIElement> {
        val elements = mutableListOf<UIElement>()
        
        // 限制递归深度，避免栈溢出
        if (depth > 20) return elements
        
        // 生成元素ID
        val elementId = "${parentId}_${node.className}_$depth"
        
        // 获取元素边界
        val rect = Rect()
        node.getBoundsInScreen(rect)
        val bounds = ElementBounds(rect.left, rect.top, rect.right, rect.bottom)
        
        // 确定元素类型
        val elementType = determineElementType(node)
        
        // 创建UI元素
        val element = UIElement(
            id = elementId,
            className = node.className?.toString() ?: "",
            text = node.text?.toString(),
            contentDescription = node.contentDescription?.toString(),
            bounds = bounds,
            type = elementType,
            clickable = node.isClickable,
            scrollable = node.isScrollable,
            editable = node.className?.toString()?.contains("EditText") == true,
            checked = node.isChecked,
            enabled = node.isEnabled,
            selected = node.isSelected
        )
        
        // 只添加有意义的元素
        if (isSignificantElement(element)) {
            elements.add(element)
        }
        
        // 递归处理子节点
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            if (child != null) {
                elements.addAll(extractElements(child, elementId, depth + 1))
                child.recycle()
            }
        }
        
        return elements
    }
    
    /**
     * 确定元素类型
     */
    private fun determineElementType(node: AccessibilityNodeInfo): ElementType {
        val className = node.className?.toString() ?: return ElementType.UNKNOWN
        
        return when {
            className.contains("Button") -> ElementType.BUTTON
            className.contains("EditText") -> ElementType.EDIT_TEXT
            className.contains("TextView") -> ElementType.TEXT
            className.contains("ImageView") || className.contains("ImageButton") -> ElementType.IMAGE
            className.contains("ListView") || className.contains("RecyclerView") -> ElementType.LIST
            className.contains("CheckBox") -> ElementType.CHECKBOX
            className.contains("RadioButton") -> ElementType.RADIO_BUTTON
            className.contains("Switch") -> ElementType.SWITCH
            className.contains("TabLayout") -> ElementType.TAB
            className.contains("WebView") -> ElementType.WEBVIEW
            className.contains("VideoView") -> ElementType.VIDEO
            node.isClickable -> ElementType.BUTTON
            else -> ElementType.UNKNOWN
        }
    }
    
    /**
     * 判断元素是否重要
     */
    private fun isSignificantElement(element: UIElement): Boolean {
        // 过滤掉太小的元素
        val width = element.bounds.right - element.bounds.left
        val height = element.bounds.bottom - element.bounds.top
        if (width < 10 || height < 10) return false
        
        // 保留有文本或描述的元素
        if (!element.text.isNullOrEmpty() || !element.contentDescription.isNullOrEmpty()) {
            return true
        }
        
        // 保留可交互元素
        if (element.clickable || element.editable || element.scrollable) {
            return true
        }
        
        // 保留特定类型的元素
        return element.type in listOf(
            ElementType.BUTTON,
            ElementType.EDIT_TEXT,
            ElementType.CHECKBOX,
            ElementType.RADIO_BUTTON,
            ElementType.SWITCH
        )
    }
    
    /**
     * 识别屏幕类型（增强版）
     */
    private fun identifyScreenType(
        elements: List<UIElement>,
        packageName: String
    ): ScreenType {
        // 检查是否是对话框
        if (elements.any { it.className.contains("Dialog") }) {
            return ScreenType.DIALOG
        }
        
        // 检查是否是主屏幕
        if (packageName.contains("launcher")) {
            return ScreenType.LAUNCHER
        }
        
        // 根据包名识别应用类型
        when {
            // 短视频APP
            packageName.contains("douyin") || packageName.contains("tiktok") ||
            packageName.contains("kuaishou") || packageName.contains("快手") -> {
                return ScreenType.SHORT_VIDEO
            }
            
            // 长视频APP
            packageName.contains("bilibili") || packageName.contains("youtube") ||
            packageName.contains("iqiyi") || packageName.contains("tencent.video") -> {
                return ScreenType.LONG_VIDEO
            }
            
            // 小说阅读APP
            packageName.contains("qidian") || packageName.contains("novel") ||
            packageName.contains("reader") || packageName.contains("书") -> {
                return ScreenType.NOVEL_READER
            }
            
            // 新闻资讯APP
            packageName.contains("toutiao") || packageName.contains("news") ||
            packageName.contains("163") || packageName.contains("sohu") -> {
                return ScreenType.NEWS_FEED
            }
            
            // 购物APP
            packageName.contains("taobao") || packageName.contains("jd") ||
            packageName.contains("pinduoduo") || packageName.contains("tmall") ||
            packageName.contains("shop") || packageName.contains("mall") -> {
                return ScreenType.SHOPPING
            }
            
            // 社交媒体APP
            packageName.contains("weibo") || packageName.contains("xiaohongshu") ||
            packageName.contains("instagram") || packageName.contains("facebook") -> {
                return ScreenType.SOCIAL_FEED
            }
            
            // 音乐APP
            packageName.contains("music") || packageName.contains("netease") ||
            packageName.contains("kugou") || packageName.contains("kuwo") -> {
                return ScreenType.MUSIC_PLAYER
            }
            
            // 浏览器
            packageName.contains("browser") || packageName.contains("chrome") ||
            packageName.contains("firefox") || packageName.contains("edge") -> {
                return ScreenType.BROWSER
            }
        }
        
        // 根据元素特征判断
        val editTextCount = elements.count { it.type == ElementType.EDIT_TEXT }
        val buttonCount = elements.count { it.type == ElementType.BUTTON }
        val listCount = elements.count { it.type == ElementType.LIST }
        val hasMessageInput = elements.any { 
            it.contentDescription?.contains("消息") == true || 
            it.text?.contains("说点什么") == true 
        }
        
        return when {
            hasMessageInput -> ScreenType.CHAT
            editTextCount >= 3 -> ScreenType.FORM
            listCount > 0 && elements.size > 10 -> ScreenType.LIST
            packageName.contains("settings") -> ScreenType.SETTINGS
            elements.any { it.type == ElementType.WEBVIEW } -> ScreenType.WEBVIEW
            elements.any { it.type == ElementType.VIDEO } -> ScreenType.VIDEO_PLAYER
            buttonCount > 5 -> ScreenType.HOME
            else -> ScreenType.UNKNOWN
        }
    }
    
    /**
     * 识别应用场景 - 更细粒度的场景识别
     */
    private fun identifyAppScene(
        elements: List<UIElement>,
        packageName: String,
        screenType: ScreenType
    ): AppScene {
        return when (screenType) {
            ScreenType.SHORT_VIDEO -> {
                // 短视频场景
                AppScene.SHORT_VIDEO_FEED
            }
            
            ScreenType.LONG_VIDEO -> {
                // 长视频场景 - 判断是列表还是播放
                if (elements.any { it.className.contains("VideoView") || it.className.contains("Player") }) {
                    AppScene.VIDEO_PLAYING
                } else {
                    AppScene.VIDEO_LIST
                }
            }
            
            ScreenType.NOVEL_READER -> {
                // 小说阅读场景
                AppScene.NOVEL_READING
            }
            
            ScreenType.NEWS_FEED -> {
                // 新闻资讯流
                AppScene.SCROLLABLE_LIST
            }
            
            ScreenType.SHOPPING -> {
                // 购物场景 - 判断是商品列表还是详情页
                val hasPrice = elements.any { it.text?.contains("¥") == true || it.text?.contains("元") == true }
                val hasBuyButton = elements.any { 
                    it.text?.contains("购买") == true || 
                    it.text?.contains("加入购物车") == true ||
                    it.text?.contains("立即购买") == true
                }
                
                when {
                    hasBuyButton && hasPrice -> AppScene.PRODUCT_DETAIL
                    packageName.contains("cart") -> AppScene.SHOPPING_CART
                    else -> AppScene.PRODUCT_LIST
                }
            }
            
            ScreenType.SOCIAL_FEED -> {
                // 社交媒体时间线
                AppScene.SOCIAL_TIMELINE
            }
            
            ScreenType.CHAT -> {
                // 聊天对话
                AppScene.CHAT_CONVERSATION
            }
            
            ScreenType.LIST -> {
                // 可滚动列表
                AppScene.SCROLLABLE_LIST
            }
            
            else -> {
                // 默认判断是否可滚动
                if (elements.any { it.scrollable }) {
                    AppScene.SCROLLABLE_LIST
                } else {
                    AppScene.STATIC_PAGE
                }
            }
        }
    }
    
    /**
     * 生成上下文提示 - 帮助AI理解当前场景和指令含义
     */
    private fun generateContextHints(
        packageName: String,
        screenType: ScreenType,
        appScene: AppScene,
        elements: List<UIElement>
    ): String {
        val hints = mutableListOf<String>()
        
        // 识别应用名称
        val appName = when {
            packageName.contains("douyin") -> "抖音"
            packageName.contains("kuaishou") -> "快手"
            packageName.contains("bilibili") -> "B站"
            packageName.contains("taobao") -> "淘宝"
            packageName.contains("jd") -> "京东"
            packageName.contains("wechat") -> "微信"
            packageName.contains("qq") -> "QQ"
            packageName.contains("weibo") -> "微博"
            packageName.contains("xiaohongshu") -> "小红书"
            packageName.contains("toutiao") -> "头条"
            else -> "当前应用"
        }
        
        hints.add("当前应用：$appName")
        
        // 根据场景添加操作提示
        when (appScene) {
            AppScene.SHORT_VIDEO_FEED -> {
                hints.add("【短视频场景】")
                hints.add("• '向上滑动' = 切换到下一个视频")
                hints.add("• '向下滑动' = 返回上一个视频")
                hints.add("• '下一个' = 向上滑动")
                hints.add("• '上一个' = 向下滑动")
                hints.add("• '点赞' = 双击屏幕或点击爱心按钮")
            }
            
            AppScene.NOVEL_READING -> {
                // 检测翻页方向 - 左右翻页 vs 上下滚动
                val isHorizontalPage = detectHorizontalPaging(elements)
                
                if (isHorizontalPage) {
                    hints.add("【小说阅读场景 - 左右翻页】")
                    hints.add("• '下一页' = 向左滑动（翻到下一页）")
                    hints.add("• '上一页' = 向右滑动（返回上一页）")
                    hints.add("• '向左' = 下一页")
                    hints.add("• '向右' = 上一页")
                    hints.add(" 当前是仿真书页翻页模式")
                } else {
                    hints.add("【小说阅读场景 - 上下滚动】")
                    hints.add("• '下一页' = 向上滑动（继续阅读）")
                    hints.add("• '上一页' = 向下滑动（返回）")
                    hints.add("• '向上' = 下一页")
                    hints.add("• '向下' = 上一页")
                    hints.add(" 当前是滚动式阅读模式")
                }
            }
            
            AppScene.PRODUCT_LIST -> {
                hints.add("【购物列表场景】")
                hints.add("• '向左滑动' = 查看更多商品")
                hints.add("• '向右滑动' = 返回之前的商品")
                hints.add("• '下一个' = 切换到下一个商品")
            }
            
            AppScene.PRODUCT_DETAIL -> {
                hints.add("【商品详情场景】")
                hints.add("• '向上滑动' = 查看更多商品信息")
                hints.add("• '购买' = 点击购买按钮")
                hints.add("• '加入购物车' = 点击购物车按钮")
            }
            
            AppScene.SOCIAL_TIMELINE -> {
                hints.add("【社交信息流场景】")
                hints.add("• '向上滑动' = 查看更多内容")
                hints.add("• '向下滑动' = 返回之前的内容")
                hints.add("• '刷新' = 下拉刷新")
            }
            
            AppScene.VIDEO_PLAYING -> {
                hints.add("【视频播放场景】")
                hints.add("• '暂停' = 点击屏幕中央")
                hints.add("• '播放' = 点击播放按钮")
                hints.add("• '全屏' = 点击全屏按钮")
            }
            
            AppScene.SCROLLABLE_LIST -> {
                hints.add("【可滚动列表场景】")
                hints.add("• '向上滑动' = 查看更多内容")
                hints.add("• '向下滑动' = 返回顶部")
            }
            
            else -> {
                hints.add("【通用场景】")
            }
        }
        
        // 添加可用操作的提示
        val hasSearchBox = elements.any { 
            it.type == ElementType.EDIT_TEXT && 
            (it.text?.contains("搜索") == true || it.contentDescription?.contains("search") == true)
        }
        if (hasSearchBox) {
            hints.add("• 可以使用搜索功能")
        }
        
        return hints.joinToString("\n")
    }
    
    /**
     * 检测对话框
     */
    private fun detectDialog(elements: List<UIElement>): Boolean {
        return elements.any { 
            it.className.contains("Dialog") || 
            it.className.contains("AlertDialog") ||
            it.className.contains("PopupWindow")
        }
    }
    
    /**
     * 检测键盘
     */
    private fun detectKeyboard(rootNode: AccessibilityNodeInfo): Boolean {
        // 通过包名判断
        val packageName = rootNode.packageName?.toString() ?: ""
        return packageName.contains("inputmethod") || 
               packageName.contains("keyboard")
    }
    
    /**
     * 检测是否是水平翻页模式（左右翻页）
     * 用于区分仿真书页翻页和滚动式阅读
     */
    private fun detectHorizontalPaging(elements: List<UIElement>): Boolean {
        // 检测方法1：查找ViewPager组件（通常用于左右翻页）
        val hasViewPager = elements.any { 
            it.className.contains("ViewPager") || 
            it.className.contains("HorizontalScrollView") ||
            it.className.contains("RecyclerView") && it.scrollable
        }
        
        // 检测方法2：查找翻页相关的UI元素
        val hasPageIndicator = elements.any {
            it.text?.contains("页") == true ||
            it.contentDescription?.contains("page") == true ||
            it.contentDescription?.contains("翻页") == true
        }
        
        // 检测方法3：查找典型的翻页控件文字
        val hasPageControls = elements.any {
            it.text?.contains("上一页") == true ||
            it.text?.contains("下一页") == true ||
            it.text?.contains("上一章") == true ||
            it.text?.contains("下一章") == true
        }
        
        // 检测方法4：如果没有明显的纵向滚动容器，可能是翻页模式
        val hasVerticalScroll = elements.any {
            it.className.contains("ScrollView") && !it.className.contains("Horizontal")
        }
        
        // 综合判断：如果有ViewPager或翻页控件，且没有明显的纵向滚动，则判定为左右翻页
        return (hasViewPager || hasPageControls) && !hasVerticalScroll
    }
    
    /**
     * 添加语义信息
     */
    private fun enrichSemanticInfo(elements: List<UIElement>, screenType: ScreenType) {
        elements.forEach { element ->
            val semanticInfo = when {
                // 发送按钮
                element.text?.contains("发送") == true || 
                element.contentDescription?.contains("send") == true -> {
                    SemanticInfo(
                        purpose = "发送消息",
                        importance = 0.9f,
                        actionHint = "点击发送消息"
                    )
                }
                
                // 返回按钮
                element.contentDescription?.contains("返回") == true ||
                element.contentDescription?.contains("back") == true -> {
                    SemanticInfo(
                        purpose = "返回上一页",
                        importance = 0.8f,
                        actionHint = "点击返回"
                    )
                }
                
                // 输入框
                element.type == ElementType.EDIT_TEXT -> {
                    SemanticInfo(
                        purpose = "文本输入",
                        importance = 0.7f,
                        actionHint = "点击输入文字"
                    )
                }
                
                // 列表项
                element.type == ElementType.LIST_ITEM -> {
                    SemanticInfo(
                        purpose = "列表选项",
                        importance = 0.5f,
                        actionHint = "点击查看详情"
                    )
                }
                
                else -> null
            }
            
            // 这里应该更新element的semanticInfo，但由于data class的不可变性，
            // 实际使用时需要返回新的列表或使用mutable结构
        }
    }
    
    /**
     * 提取元数据
     */
    private fun extractMetadata(
        rootNode: AccessibilityNodeInfo,
        elements: List<UIElement>
    ): Map<String, String> {
        val metadata = mutableMapOf<String, String>()
        
        metadata["element_count"] = elements.size.toString()
        metadata["clickable_count"] = elements.count { it.clickable }.toString()
        metadata["editable_count"] = elements.count { it.editable }.toString()
        metadata["package_name"] = rootNode.packageName?.toString() ?: ""
        metadata["class_name"] = rootNode.className?.toString() ?: ""
        metadata["window_id"] = rootNode.windowId.toString()
        
        // 尝试识别应用
        val appName = identifyApp(rootNode.packageName?.toString())
        if (appName != null) {
            metadata["app_name"] = appName
        }
        
        return metadata
    }
    
    /**
     * 识别应用
     */
    private fun identifyApp(packageName: String?): String? {
        return when (packageName) {
            "com.tencent.mm" -> "微信"
            "com.tencent.mobileqq" -> "QQ"
            "com.eg.android.AlipayGphone" -> "支付宝"
            "com.taobao.taobao" -> "淘宝"
            "com.ss.android.ugc.aweme" -> "抖音"
            "tv.danmaku.bili" -> "哔哩哔哩"
            "com.zhihu.android" -> "知乎"
            "com.sina.weibo" -> "微博"
            "com.netease.cloudmusic" -> "网易云音乐"
            "com.sankuai.meituan" -> "美团"
            "com.jingdong.app.mall" -> "京东"
            else -> null
        }
    }
    
    /**
     * 查找元素
     */
    fun findElement(
        elements: List<UIElement>,
        query: String
    ): UIElement? {
        // 精确匹配文本
        elements.find { it.text == query }?.let { return it }
        
        // 精确匹配描述
        elements.find { it.contentDescription == query }?.let { return it }
        
        // 模糊匹配文本
        elements.find { it.text?.contains(query) == true }?.let { return it }
        
        // 模糊匹配描述
        elements.find { it.contentDescription?.contains(query) == true }?.let { return it }
        
        // 语义匹配
        return findBySemantic(elements, query)
    }
    
    /**
     * 语义查找
     */
    private fun findBySemantic(elements: List<UIElement>, query: String): UIElement? {
        // 常见的语义映射
        val semanticMap = mapOf(
            "发送按钮" to listOf("发送", "send", "发出", "提交"),
            "返回按钮" to listOf("返回", "back", "后退", "取消"),
            "确认按钮" to listOf("确定", "确认", "ok", "yes", "是"),
            "输入框" to listOf("输入", "请输入", "搜索", "search"),
            "更多" to listOf("更多", "more", "···", "...")
        )
        
        for ((semantic, keywords) in semanticMap) {
            if (query.contains(semantic.substringBefore("按钮"))) {
                for (keyword in keywords) {
                    elements.find { 
                        it.text?.contains(keyword) == true || 
                        it.contentDescription?.contains(keyword) == true 
                    }?.let { return it }
                }
            }
        }
        
        return null
    }
    
    // ==================== 增强功能：多策略元素定位 ====================
    
    /**
     * 智能元素查找 - 多策略定位
     * 按优先级尝试：ID → 文本精确匹配 → 文本模糊匹配 → 描述匹配 → 语义匹配 → 坐标范围
     */
    fun smartFindElement(
        elements: List<UIElement>,
        query: String,
        preferredType: ElementType? = null,
        nearCoordinate: Pair<Int, Int>? = null
    ): UIElement? {
        LogManager.d(TAG, " 智能查找元素: query=$query, preferredType=$preferredType")
        
        // 过滤可见且有效的元素
        val visibleElements = elements.filter { isElementVisible(it) && it.enabled }
        
        // 策略1: ID精确匹配
        visibleElements.find { it.id.contains(query, ignoreCase = true) }?.let {
            LogManager.d(TAG, " 通过ID找到: ${it.id}")
            return it
        }
        
        // 策略2: 文本精确匹配
        visibleElements.find { it.text == query }?.let {
            LogManager.d(TAG, " 通过精确文本找到: ${it.text}")
            return it
        }
        
        // 策略3: 内容描述精确匹配
        visibleElements.find { it.contentDescription == query }?.let {
            LogManager.d(TAG, " 通过精确描述找到: ${it.contentDescription}")
            return it
        }
        
        // 策略4: 文本模糊匹配（考虑类型偏好）
        val fuzzyMatches = visibleElements.filter { 
            it.text?.contains(query, ignoreCase = true) == true ||
            it.contentDescription?.contains(query, ignoreCase = true) == true
        }
        
        if (fuzzyMatches.isNotEmpty()) {
            // 如果有类型偏好，优先返回匹配类型的
            if (preferredType != null) {
                fuzzyMatches.find { it.type == preferredType }?.let {
                    LogManager.d(TAG, " 通过模糊匹配+类型偏好找到: ${it.text}")
                    return it
                }
            }
            
            // 如果有坐标偏好，返回最近的
            if (nearCoordinate != null) {
                val nearest = findNearestElement(fuzzyMatches, nearCoordinate)
                LogManager.d(TAG, " 通过模糊匹配+坐标偏好找到: ${nearest?.text}")
                return nearest
            }
            
            LogManager.d(TAG, " 通过模糊匹配找到: ${fuzzyMatches.first().text}")
            return fuzzyMatches.first()
        }
        
        // 策略5: 语义匹配
        findBySemantic(visibleElements, query)?.let {
            LogManager.d(TAG, " 通过语义匹配找到: ${it.text}")
            return it
        }
        
        // 策略6: 类型+位置推测（用于没有文本的元素）
        if (preferredType != null && nearCoordinate != null) {
            val typeMatches = visibleElements.filter { it.type == preferredType }
            if (typeMatches.isNotEmpty()) {
                val nearest = findNearestElement(typeMatches, nearCoordinate)
                LogManager.d(TAG, " 通过类型+位置推测找到: ${nearest?.id}")
                return nearest
            }
        }
        
        LogManager.e(TAG, " 未找到元素: $query")
        return null
    }
    
    /**
     * 查找最近的元素
     */
    private fun findNearestElement(elements: List<UIElement>, coordinate: Pair<Int, Int>): UIElement? {
        if (elements.isEmpty()) return null
        
        return elements.minByOrNull { element ->
            val dx = element.bounds.centerX - coordinate.first
            val dy = element.bounds.centerY - coordinate.second
            dx * dx + dy * dy // 欧氏距离的平方
        }
    }
    
    /**
     * 👁️ 检测元素是否可见
     */
    fun isElementVisible(element: UIElement): Boolean {
        val bounds = element.bounds
        val width = bounds.right - bounds.left
        val height = bounds.bottom - bounds.top
        
        // 检查尺寸是否合理
        if (width <= 0 || height <= 0) return false
        
        // 检查是否在屏幕范围内（假设最大1440x3200）
        if (bounds.left < 0 || bounds.top < 0) return false
        if (bounds.right > 1440 || bounds.bottom > 3200) return false
        
        return true
    }
    
    /**
     * 🎯 查找可点击区域的最佳点击位置
     * 考虑元素的实际可点击区域，避免点击边缘
     */
    fun getBestClickPosition(element: UIElement): Pair<Int, Int> {
        val bounds = element.bounds
        val width = bounds.right - bounds.left
        val height = bounds.bottom - bounds.top
        
        // 如果元素较小，直接返回中心点
        if (width < 100 || height < 100) {
            return Pair(bounds.centerX, bounds.centerY)
        }
        
        // 对于较大元素，稍微偏离中心以避免可能的遮挡
        // 向右下方偏移10%
        val offsetX = (width * 0.1).toInt()
        val offsetY = (height * 0.1).toInt()
        
        return Pair(bounds.centerX + offsetX, bounds.centerY + offsetY)
    }
    
    /**
     * 🔄 查找相似元素（用于容错）
     * 当目标元素位置变化时，通过相似度匹配找到新位置
     */
    fun findSimilarElement(
        elements: List<UIElement>,
        targetText: String?,
        targetType: ElementType,
        originalBounds: ElementBounds?
    ): UIElement? {
        val candidates = elements.filter { it.type == targetType && it.enabled }
        
        if (candidates.isEmpty()) return null
        
        // 计算每个候选元素的相似度分数
        val scored = candidates.map { element ->
            var score = 0.0
            
            // 文本相似度
            if (!targetText.isNullOrEmpty() && !element.text.isNullOrEmpty()) {
                val similarity = calculateTextSimilarity(targetText, element.text ?: "")
                score += similarity * 50  // 文本权重50%
            }
            
            // 位置相似度
            if (originalBounds != null) {
                val positionSimilarity = calculatePositionSimilarity(originalBounds, element.bounds)
                score += positionSimilarity * 30  // 位置权重30%
            }
            
            // 类型匹配加分
            if (element.type == targetType) {
                score += 20  // 类型权重20%
            }
            
            Pair(element, score)
        }
        
        // 返回分数最高的元素（如果分数超过阈值）
        val best = scored.maxByOrNull { it.second }
        return if (best != null && best.second > 30) best.first else null
    }
    
    /**
     * 📊 计算文本相似度 (简化版Levenshtein)
     */
    private fun calculateTextSimilarity(text1: String, text2: String): Double {
        val maxLen = maxOf(text1.length, text2.length)
        if (maxLen == 0) return 1.0
        
        // 计算公共子串长度
        var commonChars = 0
        val shorter = if (text1.length < text2.length) text1 else text2
        val longer = if (text1.length >= text2.length) text1 else text2
        
        for (char in shorter) {
            if (longer.contains(char)) {
                commonChars++
            }
        }
        
        return commonChars.toDouble() / maxLen
    }
    
    /**
     * 📍 计算位置相似度
     */
    private fun calculatePositionSimilarity(bounds1: ElementBounds, bounds2: ElementBounds): Double {
        val maxDistance = 500.0  // 最大距离阈值
        
        val dx = (bounds1.centerX - bounds2.centerX).toDouble()
        val dy = (bounds1.centerY - bounds2.centerY).toDouble()
        val distance = kotlin.math.sqrt(dx * dx + dy * dy)
        
        return maxOf(0.0, 1.0 - (distance / maxDistance))
    }
    
    /**
     * 📋 查找所有可交互元素
     */
    fun findInteractableElements(elements: List<UIElement>): List<UIElement> {
        return elements.filter { element ->
            isElementVisible(element) &&
            element.enabled &&
            (element.clickable || element.editable || element.type == ElementType.BUTTON)
        }.sortedBy { it.bounds.top }  // 按位置从上到下排序
    }
    
    /**
     * 🔍 查找输入框
     */
    fun findEditableElement(elements: List<UIElement>, hint: String? = null): UIElement? {
        val editables = elements.filter { it.type == ElementType.EDIT_TEXT && it.enabled }
        
        if (editables.isEmpty()) return null
        
        // 如果有提示词，优先匹配
        if (!hint.isNullOrEmpty()) {
            editables.find { 
                it.text?.contains(hint, ignoreCase = true) == true ||
                it.contentDescription?.contains(hint, ignoreCase = true) == true
            }?.let { return it }
        }
        
        // 返回第一个空的输入框
        editables.find { it.text.isNullOrEmpty() }?.let { return it }
        
        // 返回第一个输入框
        return editables.first()
    }
    
    /**
     * 📱 获取屏幕摘要（用于AI理解）
     */
    fun getScreenSummary(state: ScreenState): String {
        val summary = StringBuilder()
        summary.appendLine("📱 屏幕分析摘要:")
        summary.appendLine("- 应用: ${state.metadata["app_name"] ?: state.packageName}")
        summary.appendLine("- 页面类型: ${state.screenType}")
        summary.appendLine("- 元素总数: ${state.elements.size}")
        summary.appendLine("- 可交互元素: ${state.elements.count { it.clickable || it.editable }}")
        
        if (state.hasDialog) summary.appendLine("- ⚠️ 检测到对话框")
        if (state.hasKeyboard) summary.appendLine("- ⌨️ 键盘已打开")
        if (state.scrollable) summary.appendLine("- 📜 页面可滚动")
        
        // 列出关键元素
        val keyElements = state.elements.filter { 
            it.clickable && !it.text.isNullOrEmpty() 
        }.take(10)
        
        if (keyElements.isNotEmpty()) {
            summary.appendLine("\n🎯 关键可点击元素:")
            keyElements.forEach { 
                summary.appendLine("  - ${it.text} (${it.type})")
            }
        }
        
        return summary.toString()
    }
    
    // ==================== 🔧 增强功能：OCR 文字识别集成 ====================
    
    /**
     * 📷 OCR 增强的屏幕状态
     */
    data class OCREnhancedScreenState(
        val screenState: ScreenState,
        val ocrTexts: List<OCRDetectedText> = emptyList(),
        val hasOCRData: Boolean = false
    )
    
    /**
     * 📝 OCR 检测到的文本
     */
    data class OCRDetectedText(
        val text: String,
        val bounds: ElementBounds,
        val confidence: Float = 1.0f,
        val matchedElement: UIElement? = null  // 与 Accessibility 元素的匹配
    )
    
    /**
     * 🔍 通过 OCR 查找元素
     * 当 Accessibility 无法获取文本时，通过 OCR 查找
     */
    fun findElementByOCR(
        elements: List<UIElement>,
        ocrTexts: List<OCRDetectedText>,
        targetText: String,
        fuzzyMatch: Boolean = true
    ): OCRFindResult? {
        LogManager.d(TAG, "🔍 OCR 查找: targetText=$targetText")
        
        // 首先在 OCR 结果中查找文本
        val normalizedTarget = targetText.lowercase().trim()
        
        val matchingOCR = ocrTexts.filter { ocr ->
            val ocrText = ocr.text.lowercase().trim()
            if (fuzzyMatch) {
                ocrText.contains(normalizedTarget) || 
                normalizedTarget.contains(ocrText) ||
                calculateTextSimilarity(ocrText, normalizedTarget) > 0.7
            } else {
                ocrText == normalizedTarget
            }
        }.sortedByDescending { ocr -> calculateTextSimilarity(ocr.text, targetText) }
        
        if (matchingOCR.isEmpty()) {
            LogManager.d(TAG, "❌ OCR 未找到匹配文本")
            return null
        }
        
        val bestOCRMatch = matchingOCR.first()
        LogManager.d(TAG, "✅ OCR 找到匹配: ${bestOCRMatch.text}")
        
        // 查找与 OCR 位置重叠的可点击元素
        val clickableElement = findClickableElementNearOCR(elements, bestOCRMatch)
        
        return OCRFindResult(
            ocrText = bestOCRMatch,
            clickableElement = clickableElement,
            clickPosition = Pair(bestOCRMatch.bounds.centerX, bestOCRMatch.bounds.centerY)
        )
    }
    
    /**
     * 🎯 查找 OCR 位置附近的可点击元素
     */
    private fun findClickableElementNearOCR(
        elements: List<UIElement>,
        ocrText: OCRDetectedText
    ): UIElement? {
        val ocrBounds = ocrText.bounds
        
        // 查找包含或重叠 OCR 区域的可点击元素
        val candidates = elements.filter { element ->
            element.clickable && element.enabled &&
            boundsOverlap(element.bounds, ocrBounds)
        }
        
        if (candidates.isEmpty()) {
            // 如果没有重叠的，查找最近的可点击元素
            val nearbyClickables = elements.filter { it.clickable && it.enabled }
            return findNearestElement(nearbyClickables, Pair(ocrBounds.centerX, ocrBounds.centerY))
        }
        
        // 返回面积最小的（最精确匹配的）
        return candidates.minByOrNull { 
            (it.bounds.right - it.bounds.left) * (it.bounds.bottom - it.bounds.top)
        }
    }
    
    /**
     * 📐 判断边界是否重叠
     */
    private fun boundsOverlap(b1: ElementBounds, b2: ElementBounds): Boolean {
        return !(b1.right < b2.left || b2.right < b1.left ||
                b1.bottom < b2.top || b2.bottom < b1.top)
    }
    
    /**
     * 🔄 合并 Accessibility 和 OCR 数据
     */
    fun mergeAccessibilityWithOCR(
        elements: List<UIElement>,
        ocrTexts: List<OCRDetectedText>
    ): List<UIElement> {
        val mergedElements = elements.toMutableList()
        
        // 找出 OCR 检测到但 Accessibility 没有的文本
        for (ocrText in ocrTexts) {
            val hasMatch = elements.any { element ->
                // 检查是否有元素在相同位置已有相同文本
                val samePosition = boundsOverlap(element.bounds, ocrText.bounds)
                val sameText = element.text?.contains(ocrText.text, ignoreCase = true) == true
                samePosition && sameText
            }
            
            if (!hasMatch && ocrText.text.length > 1) {
                // 创建一个 OCR 来源的虚拟元素
                val ocrElement = UIElement(
                    id = "ocr_${ocrText.bounds.centerX}_${ocrText.bounds.centerY}",
                    className = "OCRText",
                    text = ocrText.text,
                    bounds = ocrText.bounds,
                    type = ElementType.TEXT,
                    clickable = true,  // 假设 OCR 文本可点击
                    semanticInfo = SemanticInfo(
                        purpose = "OCR检测文本",
                        importance = 0.6f
                    )
                )
                mergedElements.add(ocrElement)
            }
        }
        
        LogManager.d(TAG, "🔄 合并后元素数: ${mergedElements.size} (原: ${elements.size}, OCR新增: ${mergedElements.size - elements.size})")
        return mergedElements
    }
    
    /**
     * 📊 生成 OCR 增强的屏幕摘要
     */
    fun getOCREnhancedSummary(
        state: ScreenState,
        ocrTexts: List<OCRDetectedText>
    ): String {
        val summary = StringBuilder(getScreenSummary(state))
        
        if (ocrTexts.isNotEmpty()) {
            summary.appendLine("\n📝 OCR 检测到的文本:")
            ocrTexts.take(15).forEach { ocr ->
                summary.appendLine("  - \"${ocr.text}\" at (${ocr.bounds.centerX}, ${ocr.bounds.centerY})")
            }
            
            if (ocrTexts.size > 15) {
                summary.appendLine("  ... 还有 ${ocrTexts.size - 15} 个文本")
            }
        }
        
        return summary.toString()
    }
}

/**
 * 🎯 OCR 查找结果
 */
data class OCRFindResult(
    val ocrText: ScreenAnalyzer.OCRDetectedText,
    val clickableElement: ScreenAnalyzer.UIElement?,
    val clickPosition: Pair<Int, Int>  // 推荐的点击位置
)
