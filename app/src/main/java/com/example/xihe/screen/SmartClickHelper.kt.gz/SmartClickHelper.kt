package com.example.xihe.screen

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import com.example.xihe.utils.LogManager
import android.view.accessibility.AccessibilityNodeInfo
import androidx.annotation.RequiresApi
import kotlinx.coroutines.*

/**
 * 🎯 智能点击助手
 * 提供智能的点击和交互功能
 */
class SmartClickHelper(
    private val service: AccessibilityService,
    private val analyzer: ScreenElementAnalyzer
) {
    
    companion object {
        private const val TAG = "SmartClickHelper"
        private const val CLICK_DURATION = 100L
        private const val LONG_CLICK_DURATION = 1000L
    }
    
    /**
     * 🎯 根据文本点击元素
     */
    suspend fun clickByText(
        text: String,
        exact: Boolean = false,
        timeout: Long = 5000L
    ): Boolean = withContext(Dispatchers.Main) {
        try {
            val startTime = System.currentTimeMillis()
            
            while (System.currentTimeMillis() - startTime < timeout) {
                analyzer.analyzeScreen()
                val elements = analyzer.findElementsByText(text, exact)
                
                if (elements.isNotEmpty()) {
                    val element = elements.first()
                    return@withContext clickElement(element)
                }
                
                delay(500)
            }
            
            LogManager.i(TAG, "⚠️ 未找到文本: $text")
            false
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 点击失败", e)
            false
        }
    }
    
    /**
     * 🎯 点击指定位置
     */
    @RequiresApi(Build.VERSION_CODES.N)
    suspend fun clickAtPosition(x: Int, y: Int): Boolean = withContext(Dispatchers.Main) {
        try {
            val path = Path()
            path.moveTo(x.toFloat(), y.toFloat())
            
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, CLICK_DURATION))
                .build()
            
            val result = service.dispatchGesture(
                gesture,
                null,
                null
            )
            
            LogManager.d(TAG, "🎯 点击位置: ($x, $y)")
            result
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 点击位置失败", e)
            false
        }
    }
    
    /**
     * 🎯 点击元素
     */
    suspend fun clickElement(element: ScreenElementAnalyzer.ScreenElement): Boolean {
        return try {
            if (element.isClickable) {
                val centerX = element.bounds.centerX()
                val centerY = element.bounds.centerY()
                
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    clickAtPosition(centerX, centerY)
                } else {
                    // 使用无障碍节点点击（备用方案）
                    clickNodeByBounds(element.bounds)
                }
            } else {
                LogManager.i(TAG, "⚠️ 元素不可点击")
                false
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 点击元素失败", e)
            false
        }
    }
    
    /**
     * 🎯 长按元素
     */
    @RequiresApi(Build.VERSION_CODES.N)
    suspend fun longClickElement(element: ScreenElementAnalyzer.ScreenElement): Boolean {
        return try {
            val centerX = element.bounds.centerX()
            val centerY = element.bounds.centerY()
            
            val path = Path()
            path.moveTo(centerX.toFloat(), centerY.toFloat())
            
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, LONG_CLICK_DURATION))
                .build()
            
            service.dispatchGesture(gesture, null, null)
            
            LogManager.d(TAG, "🎯 长按元素: ${element.text}")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 长按元素失败", e)
            false
        }
    }
    
    /**
     * ⌨️ 在输入框中输入文本
     */
    suspend fun inputText(text: String, targetField: String = ""): Boolean {
        return try {
            analyzer.analyzeScreen()
            
            // 查找输入框
            val inputs = analyzer.findAllInputs()
            val targetInput = if (targetField.isNotBlank()) {
                inputs.find { 
                    it.text.contains(targetField, ignoreCase = true) ||
                    it.contentDescription.contains(targetField, ignoreCase = true)
                }
            } else {
                inputs.firstOrNull()
            }
            
            if (targetInput != null) {
                // 点击输入框获取焦点
                clickElement(targetInput)
                delay(300)
                
                // 使用无障碍节点输入
                val node = findNodeByBounds(targetInput.bounds)
                if (node != null) {
                    val bundle = android.os.Bundle()
                    bundle.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
                    node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, bundle)
                    
                    LogManager.d(TAG, "⌨️ 输入文本: $text")
                    true
                } else {
                    false
                }
            } else {
                LogManager.i(TAG, "⚠️ 未找到输入框")
                false
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 输入文本失败", e)
            false
        }
    }
    
    /**
     * 📋 粘贴文本到输入框
     */
    suspend fun pasteText(targetField: String = ""): Boolean {
        return try {
            analyzer.analyzeScreen()
            
            val inputs = analyzer.findAllInputs()
            val targetInput = if (targetField.isNotBlank()) {
                inputs.find { 
                    it.text.contains(targetField, ignoreCase = true) ||
                    it.contentDescription.contains(targetField, ignoreCase = true)
                }
            } else {
                inputs.firstOrNull()
            }
            
            if (targetInput != null) {
                // 点击输入框
                clickElement(targetInput)
                delay(300)
                
                // 执行粘贴操作
                val node = findNodeByBounds(targetInput.bounds)
                if (node != null) {
                    node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
                    
                    LogManager.d(TAG, "📋 粘贴文本")
                    true
                } else {
                    false
                }
            } else {
                LogManager.i(TAG, "⚠️ 未找到输入框")
                false
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 粘贴失败", e)
            false
        }
    }
    
    /**
     * 📜 滚动到指定文本
     */
    suspend fun scrollToText(text: String, maxScrolls: Int = 10): Boolean {
        return try {
            for (i in 0 until maxScrolls) {
                analyzer.analyzeScreen()
                val elements = analyzer.findElementsByText(text, false)
                
                if (elements.isNotEmpty()) {
                    LogManager.d(TAG, "✅ 找到文本: $text")
                    return true
                }
                
                // 执行向下滚动
                service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
                delay(500)
            }
            
            LogManager.i(TAG, "⚠️ 未找到文本: $text")
            false
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 滚动失败", e)
            false
        }
    }
    
    /**
     * 🔄 切换复选框/开关
     */
    suspend fun toggleCheckbox(text: String): Boolean {
        return try {
            analyzer.analyzeScreen()
            val elements = analyzer.findElementsByText(text, false)
                .filter { it.isCheckable }
            
            if (elements.isNotEmpty()) {
                val element = elements.first()
                clickElement(element)
                LogManager.d(TAG, "🔄 切换: $text")
                true
            } else {
                LogManager.i(TAG, "⚠️ 未找到可切换元素: $text")
                false
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 切换失败", e)
            false
        }
    }
    
    /**
     * 🎯 智能点击（尝试多种方式）
     */
    suspend fun smartClick(target: String): Boolean {
        // 1. 尝试精确文本匹配
        if (clickByText(target, exact = true, timeout = 1000)) {
            return true
        }
        
        // 2. 尝试模糊文本匹配
        if (clickByText(target, exact = false, timeout = 1000)) {
            return true
        }
        
        // 3. 尝试内容描述匹配
        analyzer.analyzeScreen()
        val elements = analyzer.findElementsByText(target, false)
        if (elements.isNotEmpty()) {
            return clickElement(elements.first())
        }
        
        LogManager.i(TAG, "⚠️ 智能点击失败: $target")
        return false
    }
    
    /**
     * 🔍 根据边界查找节点
     */
    private fun findNodeByBounds(bounds: Rect): AccessibilityNodeInfo? {
        val rootNode = service.rootInActiveWindow ?: return null
        return findNodeByBoundsRecursive(rootNode, bounds)
    }
    
    private fun findNodeByBoundsRecursive(node: AccessibilityNodeInfo, targetBounds: Rect): AccessibilityNodeInfo? {
        try {
            val nodeBounds = Rect()
            node.getBoundsInScreen(nodeBounds)
            
            if (nodeBounds == targetBounds) {
                return node
            }
            
            for (i in 0 until node.childCount) {
                val child = node.getChild(i)
                if (child != null) {
                    val result = findNodeByBoundsRecursive(child, targetBounds)
                    if (result != null) {
                        return result
                    }
                }
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 查找节点失败", e)
        }
        
        return null
    }
    
    /**
     * 🎯 根据边界点击节点
     */
    private fun clickNodeByBounds(bounds: Rect): Boolean {
        val node = findNodeByBounds(bounds)
        return if (node != null) {
            val result = node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            result
        } else {
            false
        }
    }
}
