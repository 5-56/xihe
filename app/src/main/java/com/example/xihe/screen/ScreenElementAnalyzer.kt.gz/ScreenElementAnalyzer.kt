package com.example.xihe.screen

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import com.example.xihe.utils.LogManager
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs

/**
 * 🔍 屏幕元素分析器
 * 分析屏幕上的可交互元素
 */
class ScreenElementAnalyzer(
    private val service: AccessibilityService
) {
    
    companion object {
        private const val TAG = "ScreenElementAnalyzer"
    }
    
    private val _elements = MutableStateFlow<List<ScreenElement>>(emptyList())
    val elements = _elements.asStateFlow()
    
    /**
     * 🔍 分析当前屏幕
     */
    fun analyzeScreen(): List<ScreenElement> {
        val rootNode = service.rootInActiveWindow ?: run {
            LogManager.w(TAG, "⚠️ 无法获取根节点")
            return emptyList()
        }
        
        val elements = mutableListOf<ScreenElement>()
        traverseNode(rootNode, elements)
        
        _elements.value = elements
        
        LogManager.d(TAG, "🔍 分析完成，找到 ${elements.size} 个元素")
        
        return elements
    }
    
    /**
     * 🌲 遍历节点树
     */
    private fun traverseNode(node: AccessibilityNodeInfo, elements: MutableList<ScreenElement>) {
        try {
            // 只收集可交互或有文本的元素
            if (node.isVisibleToUser && (node.isClickable || node.isLongClickable || 
                node.isFocusable || node.isCheckable || node.isEditable ||
                !node.text.isNullOrBlank() || !node.contentDescription.isNullOrBlank())) {
                
                val bounds = Rect()
                node.getBoundsInScreen(bounds)
                
                val element = ScreenElement(
                    id = node.hashCode().toString(),
                    text = node.text?.toString() ?: "",
                    contentDescription = node.contentDescription?.toString() ?: "",
                    className = node.className?.toString() ?: "",
                    packageName = node.packageName?.toString() ?: "",
                    bounds = bounds,
                    isClickable = node.isClickable,
                    isLongClickable = node.isLongClickable,
                    isCheckable = node.isCheckable,
                    isChecked = node.isChecked,
                    isEditable = node.isEditable,
                    isFocusable = node.isFocusable,
                    isFocused = node.isFocused,
                    isEnabled = node.isEnabled,
                    isPassword = node.isPassword,
                    type = detectElementType(node)
                )
                
                elements.add(element)
            }
            
            // 递归遍历子节点
            for (i in 0 until node.childCount) {
                val child = node.getChild(i)
                if (child != null) {
                    traverseNode(child, elements)
                    child.recycle()
                }
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 遍历节点失败", e)
        }
    }
    
    /**
     * 🎯 检测元素类型
     */
    private fun detectElementType(node: AccessibilityNodeInfo): ElementType {
        val className = node.className?.toString()?.lowercase() ?: ""
        
        return when {
            className.contains("button") -> ElementType.BUTTON
            className.contains("edittext") || className.contains("textfield") -> ElementType.INPUT
            className.contains("textview") -> ElementType.TEXT
            className.contains("imageview") || className.contains("imagebutton") -> ElementType.IMAGE
            className.contains("checkbox") -> ElementType.CHECKBOX
            className.contains("radiobutton") -> ElementType.RADIO
            className.contains("switch") -> ElementType.SWITCH
            className.contains("seekbar") || className.contains("progressbar") -> ElementType.SLIDER
            className.contains("spinner") || className.contains("dropdown") -> ElementType.DROPDOWN
            className.contains("listview") || className.contains("recyclerview") -> ElementType.LIST
            className.contains("scrollview") -> ElementType.SCROLLVIEW
            node.isClickable -> ElementType.CLICKABLE
            else -> ElementType.UNKNOWN
        }
    }
    
    /**
     * 🔍 根据文本查找元素
     */
    fun findElementsByText(text: String, exact: Boolean = false): List<ScreenElement> {
        return _elements.value.filter { element ->
            if (exact) {
                element.text.equals(text, ignoreCase = true) ||
                element.contentDescription.equals(text, ignoreCase = true)
            } else {
                element.text.contains(text, ignoreCase = true) ||
                element.contentDescription.contains(text, ignoreCase = true)
            }
        }
    }
    
    /**
     * 🔍 根据类型查找元素
     */
    fun findElementsByType(type: ElementType): List<ScreenElement> {
        return _elements.value.filter { it.type == type }
    }
    
    /**
     * 🔍 根据ID查找元素
     */
    fun findElementById(id: String): ScreenElement? {
        return _elements.value.find { it.id == id }
    }
    
    /**
     * 🔍 根据位置查找元素
     */
    fun findElementAtPosition(x: Int, y: Int): ScreenElement? {
        return _elements.value.find { element ->
            element.bounds.contains(x, y)
        }
    }
    
    /**
     * 🔍 查找最近的元素
     */
    fun findNearestElement(x: Int, y: Int, maxDistance: Int = 200): ScreenElement? {
        var nearest: ScreenElement? = null
        var minDistance = Int.MAX_VALUE
        
        for (element in _elements.value) {
            val centerX = element.bounds.centerX()
            val centerY = element.bounds.centerY()
            val distance = abs(centerX - x) + abs(centerY - y) // 曼哈顿距离
            
            if (distance < minDistance && distance <= maxDistance) {
                minDistance = distance
                nearest = element
            }
        }
        
        return nearest
    }
    
    /**
     * 🔍 查找所有按钮
     */
    fun findAllButtons(): List<ScreenElement> {
        return _elements.value.filter { 
            it.type == ElementType.BUTTON || 
            (it.isClickable && it.text.isNotBlank())
        }
    }
    
    /**
     * 🔍 查找所有输入框
     */
    fun findAllInputs(): List<ScreenElement> {
        return _elements.value.filter { it.type == ElementType.INPUT || it.isEditable }
    }
    
    /**
     * 🔍 查找所有文本
     */
    fun findAllTexts(): List<ScreenElement> {
        return _elements.value.filter { 
            it.text.isNotBlank() && it.type == ElementType.TEXT 
        }
    }
    
    /**
     * 📊 获取屏幕统计
     */
    fun getScreenStatistics(): ScreenStatistics {
        val elements = _elements.value
        
        return ScreenStatistics(
            totalElements = elements.size,
            clickableElements = elements.count { it.isClickable },
            editableElements = elements.count { it.isEditable },
            textElements = elements.count { it.text.isNotBlank() },
            buttonCount = elements.count { it.type == ElementType.BUTTON },
            inputCount = elements.count { it.type == ElementType.INPUT },
            imageCount = elements.count { it.type == ElementType.IMAGE }
        )
    }
    
    /**
     * 📱 获取屏幕布局
     */
    fun getScreenLayout(): ScreenLayout {
        val elements = _elements.value
        
        if (elements.isEmpty()) {
            return ScreenLayout(
                rows = emptyList(),
                columns = emptyList()
            )
        }
        
        // 按Y坐标分组（行）
        val rows = elements.groupBy { it.bounds.top / 100 }
            .entries.sortedBy { it.key }
            .map { it.value.sortedBy { element -> element.bounds.left } }
        
        // 按X坐标分组（列）
        val columns = elements.groupBy { it.bounds.left / 100 }
            .entries.sortedBy { it.key }
            .map { it.value.sortedBy { element -> element.bounds.top } }
        
        return ScreenLayout(
            rows = rows,
            columns = columns
        )
    }
    
    /**
     * 💾 导出屏幕结构
     */
    fun exportScreenStructure(): String {
        val sb = StringBuilder()
        sb.appendLine("屏幕结构分析")
        sb.appendLine("=".repeat(50))
        sb.appendLine("总元素数: ${_elements.value.size}")
        sb.appendLine("分析时间: ${System.currentTimeMillis()}")
        sb.appendLine()
        
        for ((index, element) in _elements.value.withIndex()) {
            sb.appendLine("元素 #${index + 1}")
            sb.appendLine("  文本: ${element.text}")
            sb.appendLine("  描述: ${element.contentDescription}")
            sb.appendLine("  类型: ${element.type}")
            sb.appendLine("  类名: ${element.className}")
            sb.appendLine("  位置: (${element.bounds.left}, ${element.bounds.top}) - (${element.bounds.right}, ${element.bounds.bottom})")
            sb.appendLine("  可点击: ${element.isClickable}")
            sb.appendLine("  可编辑: ${element.isEditable}")
            sb.appendLine("-".repeat(50))
        }
        
        return sb.toString()
    }
    
    // ============ 数据类型 ============
    
    /**
     * 📱 屏幕元素
     */
    data class ScreenElement(
        val id: String,
        val text: String,
        val contentDescription: String,
        val className: String,
        val packageName: String,
        val bounds: Rect,
        val isClickable: Boolean,
        val isLongClickable: Boolean,
        val isCheckable: Boolean,
        val isChecked: Boolean,
        val isEditable: Boolean,
        val isFocusable: Boolean,
        val isFocused: Boolean,
        val isEnabled: Boolean,
        val isPassword: Boolean,
        val type: ElementType
    )
    
    /**
     * 🏷️ 元素类型
     */
    enum class ElementType {
        BUTTON,         // 按钮
        INPUT,          // 输入框
        TEXT,           // 文本
        IMAGE,          // 图片
        CHECKBOX,       // 复选框
        RADIO,          // 单选框
        SWITCH,         // 开关
        SLIDER,         // 滑块
        DROPDOWN,       // 下拉框
        LIST,           // 列表
        SCROLLVIEW,     // 滚动视图
        CLICKABLE,      // 可点击元素
        UNKNOWN         // 未知类型
    }
    
    /**
     * 📊 屏幕统计
     */
    data class ScreenStatistics(
        val totalElements: Int,
        val clickableElements: Int,
        val editableElements: Int,
        val textElements: Int,
        val buttonCount: Int,
        val inputCount: Int,
        val imageCount: Int
    )
    
    /**
     * 📐 屏幕布局
     */
    data class ScreenLayout(
        val rows: List<List<ScreenElement>>,
        val columns: List<List<ScreenElement>>
    )
}
