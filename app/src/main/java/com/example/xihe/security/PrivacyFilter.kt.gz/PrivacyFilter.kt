package com.example.xihe.security

import com.example.xihe.utils.LogManager

/**
 * 🔒 隐私过滤器 (静态工具类)
 * 
 * 在发送数据到云端API之前，自动过滤敏感信息
 * 确保用户隐私数据不会被上传
 */
object PrivacyFilter {
    
    private const val TAG = "PrivacyFilter"
    
    // 是否启用隐私过滤（默认启用）
    var isEnabled: Boolean = true
    
    // 敏感数据正则表达式
    private val PHONE_PATTERN = Regex("""1[3-9]\d{9}""")  // 手机号
    private val ID_CARD_PATTERN = Regex("""\d{17}[\dXx]""")  // 身份证号
    private val BANK_CARD_PATTERN = Regex("""\d{16,19}""")  // 银行卡号
    private val EMAIL_PATTERN = Regex("""[\w.+-]+@[\w.-]+\.\w+""")  // 邮箱
    private val GPS_PATTERN = Regex("""\d+\.\d{5,}[,，]\s*\d+\.\d{5,}""")  // GPS坐标
    private val IP_PATTERN = Regex("""\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}""")  // IP地址
    private val PASSWORD_PATTERN = Regex("""(?:密码|password|pwd|pin|验证码)[：:=\s]*\S+""", RegexOption.IGNORE_CASE)
    
    // 🆕 更多敏感数据类型
    private val IMEI_PATTERN = Regex("""\d{15,17}""")  // IMEI设备号
    private val MAC_PATTERN = Regex("""([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}""")  // MAC地址
    private val PLATE_PATTERN = Regex("""[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领][A-Z][A-Z0-9]{5,6}""")  // 车牌号
    private val QQ_PATTERN = Regex("""[QqＱｑ]{2}[：:=\s]*\d{5,11}""")  // QQ号
    private val WECHAT_PATTERN = Regex("""微信[号：:=\s]*[a-zA-Z0-9_-]{6,20}""")  // 微信号
    private val ADDRESS_PATTERN = Regex("""(?:省|市|区|县|镇|村|路|街|号|栋|单元|室|楼).{0,30}(?:省|市|区|县|镇|村|路|街|号|栋|单元|室|楼)""")  // 地址
    private val NAME_TITLE_PATTERN = Regex("""(?:姓名|真名|本名|名字)[：:=\s]*[\u4e00-\u9fa5]{2,4}""")  // 姓名
    private val APIKEY_PATTERN = Regex("""(?:api[_-]?key|secret|token|bearer)[：:=\s]*[a-zA-Z0-9_-]{20,}""", RegexOption.IGNORE_CASE)  // API密钥
    
    // 统计
    private var filteredCount = 0
    
    /**
     * 🧹 清洗文本，过滤敏感信息
     * 
     * @param text 原始文本
     * @return 过滤后的安全文本
     */
    fun sanitize(text: String): String {
        if (!isEnabled) {
            return text
        }
        
        var sanitized = text
        var hasFiltered = false
        
        // 1. 过滤手机号 (保留前3后4)
        PHONE_PATTERN.findAll(sanitized).toList().forEach { match ->
            val masked = maskPhone(match.value)
            sanitized = sanitized.replace(match.value, masked)
            hasFiltered = true
        }
        
        // 2. 过滤身份证号
        ID_CARD_PATTERN.findAll(sanitized).toList().forEach { match ->
            sanitized = sanitized.replace(match.value, "[身份证已隐藏]")
            hasFiltered = true
        }
        
        // 3. 过滤银行卡号 (16-19位)
        BANK_CARD_PATTERN.findAll(sanitized).toList()
            .filter { it.value.length in 16..19 }
            .forEach { match ->
                sanitized = sanitized.replace(match.value, "[银行卡已隐藏]")
                hasFiltered = true
            }
        
        // 4. 过滤邮箱
        EMAIL_PATTERN.findAll(sanitized).toList().forEach { match ->
            val masked = maskEmail(match.value)
            sanitized = sanitized.replace(match.value, masked)
            hasFiltered = true
        }
        
        // 5. 过滤GPS坐标
        GPS_PATTERN.findAll(sanitized).toList().forEach { match ->
            sanitized = sanitized.replace(match.value, "[位置已隐藏]")
            hasFiltered = true
        }
        
        // 6. 过滤密码
        PASSWORD_PATTERN.findAll(sanitized).toList().forEach { match ->
            sanitized = sanitized.replace(match.value, "[密码已隐藏]")
            hasFiltered = true
        }
        
        // 7. 过滤IP地址
        IP_PATTERN.findAll(sanitized).toList().forEach { match ->
            sanitized = sanitized.replace(match.value, "[IP已隐藏]")
            hasFiltered = true
        }
        
        // 8. 过滤MAC地址
        MAC_PATTERN.findAll(sanitized).toList().forEach { match ->
            sanitized = sanitized.replace(match.value, "[MAC已隐藏]")
            hasFiltered = true
        }
        
        // 9. 过滤车牌号
        PLATE_PATTERN.findAll(sanitized).toList().forEach { match ->
            sanitized = sanitized.replace(match.value, "[车牌已隐藏]")
            hasFiltered = true
        }
        
        // 10. 过滤QQ号
        QQ_PATTERN.findAll(sanitized).toList().forEach { match ->
            sanitized = sanitized.replace(match.value, "[QQ已隐藏]")
            hasFiltered = true
        }
        
        // 11. 过滤微信号
        WECHAT_PATTERN.findAll(sanitized).toList().forEach { match ->
            sanitized = sanitized.replace(match.value, "[微信已隐藏]")
            hasFiltered = true
        }
        
        // 12. 过滤详细地址
        ADDRESS_PATTERN.findAll(sanitized).toList().forEach { match ->
            sanitized = sanitized.replace(match.value, "[地址已隐藏]")
            hasFiltered = true
        }
        
        // 13. 过滤姓名（带标题的）
        NAME_TITLE_PATTERN.findAll(sanitized).toList().forEach { match ->
            sanitized = sanitized.replace(match.value, "[姓名已隐藏]")
            hasFiltered = true
        }
        
        // 14. 过滤API密钥
        APIKEY_PATTERN.findAll(sanitized).toList().forEach { match ->
            sanitized = sanitized.replace(match.value, "[密钥已隐藏]")
            hasFiltered = true
        }
        
        if (hasFiltered) {
            filteredCount++
            LogManager.d(TAG, "🔒 已过滤敏感信息 (累计: $filteredCount 次)")
        }
        
        return sanitized
    }
    
    /**
     * 🔍 检查文本是否包含敏感信息
     */
    fun containsSensitiveData(text: String): Boolean {
        return PHONE_PATTERN.containsMatchIn(text) ||
               ID_CARD_PATTERN.containsMatchIn(text) ||
               BANK_CARD_PATTERN.findAll(text).any { it.value.length in 16..19 } ||
               GPS_PATTERN.containsMatchIn(text) ||
               PASSWORD_PATTERN.containsMatchIn(text)
    }
    
    /**
     * 📊 获取过滤统计
     */
    fun getFilteredCount(): Int = filteredCount
    
    /**
     * 🔄 重置统计
     */
    fun resetStatistics() {
        filteredCount = 0
    }
    
    // ==================== 工具方法 ====================
    
    private fun maskPhone(phone: String): String {
        return if (phone.length == 11) {
            "${phone.substring(0, 3)}****${phone.substring(7)}"
        } else {
            "[手机号已隐藏]"
        }
    }
    
    private fun maskEmail(email: String): String {
        val atIndex = email.indexOf('@')
        return if (atIndex > 2) {
            "${email.substring(0, 2)}***${email.substring(atIndex)}"
        } else {
            "[邮箱已隐藏]"
        }
    }
}
