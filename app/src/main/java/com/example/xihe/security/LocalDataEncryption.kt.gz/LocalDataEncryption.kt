package com.example.xihe.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.example.xihe.utils.LogManager
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * 🔐 本地数据加密工具
 * 
 * 使用 Android KeyStore 进行安全的本地数据加密
 * 确保敏感数据在本地存储时也是加密的
 */
object LocalDataEncryption {
    
    private const val TAG = "LocalDataEncryption"
    private const val KEY_ALIAS = "xihe_privacy_key"
    private const val ANDROID_KEYSTORE = "AndroidKeyStore"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val IV_SIZE = 12
    private const val TAG_SIZE = 128
    
    /**
     * 🔑 获取或创建加密密钥
     */
    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        
        // 检查密钥是否已存在
        if (keyStore.containsAlias(KEY_ALIAS)) {
            val entry = keyStore.getEntry(KEY_ALIAS, null) as KeyStore.SecretKeyEntry
            return entry.secretKey
        }
        
        // 创建新密钥
        val keyGenerator = KeyGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_AES,
            ANDROID_KEYSTORE
        )
        
        val keySpec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        
        keyGenerator.init(keySpec)
        return keyGenerator.generateKey()
    }
    
    /**
     * 🔒 加密数据
     * 
     * @param plainText 明文
     * @return Base64编码的密文（包含IV）
     */
    fun encrypt(plainText: String): String {
        return try {
            val key = getOrCreateKey()
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, key)
            
            val iv = cipher.iv
            val encryptedBytes = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
            
            // 将IV和密文组合
            val combined = ByteArray(iv.size + encryptedBytes.size)
            System.arraycopy(iv, 0, combined, 0, iv.size)
            System.arraycopy(encryptedBytes, 0, combined, iv.size, encryptedBytes.size)
            
            Base64.encodeToString(combined, Base64.NO_WRAP)
        } catch (e: Exception) {
            LogManager.w(TAG, "加密失败", e)
            throw SecurityException("数据加密失败: ${e.message}")
        }
    }
    
    /**
     * 🔓 解密数据
     * 
     * @param encryptedText Base64编码的密文
     * @return 明文
     */
    fun decrypt(encryptedText: String): String {
        return try {
            val key = getOrCreateKey()
            val combined = Base64.decode(encryptedText, Base64.NO_WRAP)
            
            // 提取IV和密文
            val iv = combined.copyOfRange(0, IV_SIZE)
            val encryptedBytes = combined.copyOfRange(IV_SIZE, combined.size)
            
            val cipher = Cipher.getInstance(TRANSFORMATION)
            val spec = GCMParameterSpec(TAG_SIZE, iv)
            cipher.init(Cipher.DECRYPT_MODE, key, spec)
            
            val decryptedBytes = cipher.doFinal(encryptedBytes)
            String(decryptedBytes, Charsets.UTF_8)
        } catch (e: Exception) {
            LogManager.w(TAG, "解密失败", e)
            throw SecurityException("数据解密失败: ${e.message}")
        }
    }
    
    /**
     * 🔒 安全存储敏感数据
     */
    fun secureStore(context: Context, key: String, value: String) {
        val prefs = context.getSharedPreferences("xihe_secure_prefs", Context.MODE_PRIVATE)
        val encryptedValue = encrypt(value)
        prefs.edit().putString(key, encryptedValue).apply()
        LogManager.w(TAG, "🔒 已安全存储: $key")
    }
    
    /**
     * 🔓 安全读取敏感数据
     */
    fun secureLoad(context: Context, key: String): String? {
        val prefs = context.getSharedPreferences("xihe_secure_prefs", Context.MODE_PRIVATE)
        val encryptedValue = prefs.getString(key, null) ?: return null
        return try {
            decrypt(encryptedValue)
        } catch (e: Exception) {
            LogManager.w(TAG, "读取解密失败: $key", e)
            null
        }
    }
    
    /**
     * 🗑️ 安全删除敏感数据
     */
    fun secureDelete(context: Context, key: String) {
        val prefs = context.getSharedPreferences("xihe_secure_prefs", Context.MODE_PRIVATE)
        prefs.edit().remove(key).apply()
        LogManager.w(TAG, "🗑️ 已安全删除: $key")
    }
    
    /**
     * 🧹 清除所有安全存储的数据
     */
    fun clearAll(context: Context) {
        val prefs = context.getSharedPreferences("xihe_secure_prefs", Context.MODE_PRIVATE)
        prefs.edit().clear().apply()
        LogManager.w(TAG, "🧹 已清除所有安全存储数据")
    }
}
