package com.example.xihe.security

import android.content.Context
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * 🔒 隐私保护管理器
 * 
 * 确保用户敏感数据不会被上传到云端API
 * 
 * 功能：
 * 1. 过滤敏感数据（位置、电话、身份证等）
 * 2. 本地数据加密存储
 * 3. API调用前数据清洗
 * 4. 隐私设置管理
 */
class PrivacyProtectionManager private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "PrivacyProtection"
        
        @Volatile
        private var instance: PrivacyProtectionManager? = null
        
        fun getInstance(context: Context): PrivacyProtectionManager {
            return instance ?: synchronized(this) {
                instance ?: PrivacyProtectionManager(context.applicationContext).also { 
                    instance = it 
                }
            }
        }
        
        // 敏感数据正则表达式
        private val PHONE_PATTERN = Regex("""1[3-9]\d{9}""")  // 手机号
        private val ID_CARD_PATTERN = Regex("""\d{17}[\dXx]""")  // 身份证号
        private val BANK_CARD_PATTERN = Regex("""\d{16,19}""")  // 银行卡号
        private val EMAIL_PATTERN = Regex("""[\w.+-]+@[\w.-]+\.\w+""")  // 邮箱
        private val GPS_PATTERN = Regex("""\d+\.\d{5,}[,，]\s*\d+\.\d{5,}""")  // GPS坐标
        private val IP_PATTERN = Regex("""\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}""")  // IP地址
        private val PASSWORD_PATTERN = Regex("""(?:密码|password|pwd)[：:=\s]*\S+""", RegexOption.IGNORE_CASE)
        
        // 敏感关键词
        private val SENSITIVE_KEYWORDS = listOf(
            "密码", "password", "pwd",
            "身份证", "idcard", "id card",
            "银行卡", "信用卡", "借记卡",
            "验证码", "captcha", "code",
            "私钥", "秘钥", "secret",
            "token", "apikey", "api_key"
        )
    }
    
    // 隐私保护开关
    private val _privacyProtectionEnabled = MutableStateFlow(true)
    val privacyProtectionEnabled = _privacyProtectionEnabled.asStateFlow()
    
    // 具体保护选项
    private val _filterPhoneNumbers = MutableStateFlow(true)
    private val _filterIdCards = MutableStateFlow(true)
    private val _filterLocation = MutableStateFlow(true)
    private val _filterBankCards = MutableStateFlow(true)
    private val _filterEmails = MutableStateFlow(true)
    private val _filterPasswords = MutableStateFlow(true)
    
    // 统计
    private var filteredCount = 0
    
    /**
     * 🔄 启用/禁用隐私保护
     */
    fun setPrivacyProtectionEnabled(enabled: Boolean) {
        _privacyProtectionEnabled.value = enabled
        LogManager.d(TAG, "🔒 隐私保护: ${if (enabled) "启用" else "禁用"}")
    }
    
    /**
     * 🧹 清洗发送给API的数据
     * 在调用云端API之前调用此方法，过滤敏感信息
     * 
     * @param text 原始文本
     * @return 过滤后的安全文本
     */
    fun sanitizeForApi(text: String): String {
        if (!_privacyProtectionEnabled.value) {
            return text
        }
        
        var sanitized = text
        var filterApplied = false
        
        // 1. 过滤手机号
        if (_filterPhoneNumbers.value) {
            val phoneMatches = PHONE_PATTERN.findAll(sanitized).toList()
            if (phoneMatches.isNotEmpty()) {
                phoneMatches.forEach { match ->
                    val masked = maskPhoneNumber(match.value)
                    sanitized = sanitized.replace(match.value, masked)
                }
                filterApplied = true
                LogManager.d(TAG, "📱 已过滤 ${phoneMatches.size} 个手机号")
            }
        }
        
        // 2. 过滤身份证号
        if (_filterIdCards.value) {
            val idMatches = ID_CARD_PATTERN.findAll(sanitized).toList()
            if (idMatches.isNotEmpty()) {
                idMatches.forEach { match ->
                    sanitized = sanitized.replace(match.value, "[身份证号已隐藏]")
                }
                filterApplied = true
                LogManager.d(TAG, "🪪 已过滤 ${idMatches.size} 个身份证号")
            }
        }
        
        // 3. 过滤银行卡号
        if (_filterBankCards.value) {
            val bankMatches = BANK_CARD_PATTERN.findAll(sanitized).toList()
            // 只过滤看起来像银行卡号的（16-19位纯数字）
            bankMatches.filter { it.value.length in 16..19 }.forEach { match ->
                sanitized = sanitized.replace(match.value, "[银行卡号已隐藏]")
                filterApplied = true
            }
        }
        
        // 4. 过滤邮箱
        if (_filterEmails.value) {
            val emailMatches = EMAIL_PATTERN.findAll(sanitized).toList()
            if (emailMatches.isNotEmpty()) {
                emailMatches.forEach { match ->
                    val masked = maskEmail(match.value)
                    sanitized = sanitized.replace(match.value, masked)
                }
                filterApplied = true
            }
        }
        
        // 5. 过滤GPS坐标
        if (_filterLocation.value) {
            val gpsMatches = GPS_PATTERN.findAll(sanitized).toList()
            if (gpsMatches.isNotEmpty()) {
                gpsMatches.forEach { match ->
                    sanitized = sanitized.replace(match.value, "[位置已隐藏]")
                }
                filterApplied = true
                LogManager.d(TAG, "📍 已过滤 ${gpsMatches.size} 个GPS坐标")
            }
        }
        
        // 6. 过滤密码相关
        if (_filterPasswords.value) {
            val pwdMatches = PASSWORD_PATTERN.findAll(sanitized).toList()
            if (pwdMatches.isNotEmpty()) {
                pwdMatches.forEach { match ->
                    sanitized = sanitized.replace(match.value, "[密码已隐藏]")
                }
                filterApplied = true
                LogManager.d(TAG, "🔑 已过滤 ${pwdMatches.size} 处密码信息")
            }
        }
        
        // 7. 过滤IP地址
        val ipMatches = IP_PATTERN.findAll(sanitized).toList()
        if (ipMatches.isNotEmpty()) {
            ipMatches.forEach { match ->
                sanitized = sanitized.replace(match.value, "[IP已隐藏]")
            }
            filterApplied = true
        }
        
        if (filterApplied) {
            filteredCount++
            LogManager.i(TAG, "🔒 数据清洗完成，已过滤敏感信息 (累计: $filteredCount 次)")
        }
        
        return sanitized
    }
    
    /**
     * 🔍 检查文本是否包含敏感信息
     */
    fun containsSensitiveData(text: String): SensitiveDataCheckResult {
        val findings = mutableListOf<String>()
        
        if (PHONE_PATTERN.containsMatchIn(text)) findings.add("手机号")
        if (ID_CARD_PATTERN.containsMatchIn(text)) findings.add("身份证号")
        if (BANK_CARD_PATTERN.findAll(text).any { it.value.length in 16..19 }) findings.add("银行卡号")
        if (EMAIL_PATTERN.containsMatchIn(text)) findings.add("邮箱地址")
        if (GPS_PATTERN.containsMatchIn(text)) findings.add("GPS坐标")
        if (PASSWORD_PATTERN.containsMatchIn(text)) findings.add("密码")
        
        SENSITIVE_KEYWORDS.forEach { keyword ->
            if (text.contains(keyword, ignoreCase = true)) {
                if (!findings.contains("敏感关键词")) {
                    findings.add("敏感关键词")
                }
            }
        }
        
        return SensitiveDataCheckResult(
            hasSensitiveData = findings.isNotEmpty(),
            findings = findings,
            suggestion = if (findings.isNotEmpty()) {
                "检测到敏感信息: ${findings.joinToString("、")}，建议启用隐私保护"
            } else {
                "未检测到敏感信息"
            }
        )
    }
    
    /**
     * 🚫 获取不应发送到云端的本地数据类型列表
     */
    fun getBlockedDataTypes(): List<String> {
        return listOf(
            "用户位置信息 (GPS坐标)",
            "手机号码",
            "身份证号码",
            "银行卡号",
            "密码和验证码",
            "私人通讯录",
            "应用使用记录",
            "环境声音录音",
            "设备唯一标识符"
        )
    }
    
    /**
     * 📊 获取隐私保护统计
     */
    fun getStatistics(): PrivacyStatistics {
        return PrivacyStatistics(
            isEnabled = _privacyProtectionEnabled.value,
            filteredCount = filteredCount,
            blockedDataTypes = getBlockedDataTypes().size
        )
    }
    
    // ==================== 工具方法 ====================
    
    /**
     * 脱敏手机号 (保留前3后4)
     */
    private fun maskPhoneNumber(phone: String): String {
        return if (phone.length == 11) {
            "${phone.substring(0, 3)}****${phone.substring(7)}"
        } else {
            "[手机号已隐藏]"
        }
    }
    
    /**
     * 脱敏邮箱 (保留@前2位和域名)
     */
    private fun maskEmail(email: String): String {
        val atIndex = email.indexOf('@')
        return if (atIndex > 2) {
            "${email.substring(0, 2)}***${email.substring(atIndex)}"
        } else {
            "[邮箱已隐藏]"
        }
    }
}

/**
 * 敏感数据检查结果
 */
data class SensitiveDataCheckResult(
    val hasSensitiveData: Boolean,
    val findings: List<String>,
    val suggestion: String
)

/**
 * 隐私保护统计
 */
data class PrivacyStatistics(
    val isEnabled: Boolean,
    val filteredCount: Int,
    val blockedDataTypes: Int
)
