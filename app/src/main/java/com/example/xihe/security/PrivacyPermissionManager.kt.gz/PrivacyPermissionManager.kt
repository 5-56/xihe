package com.example.xihe.security

import android.content.Context
import android.content.SharedPreferences
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * 🔐 隐私权限管理器
 * 
 * 功能：
 * 1. 管理隐私数据的访问权限
 * 2. 提供弹窗确认机制
 * 3. 支持一键开启所有隐私权限
 * 
 * 隐私数据类型：
 * - 照片/图片
 * - 视频
 * - 短信
 * - 通讯录
 * - 通话记录
 * - 文件/文档
 * - 位置信息
 */
object PrivacyPermissionManager {
    private const val TAG = "PrivacyPermissionManager"
    private const val PREF_NAME = "xihe_privacy_preferences"
    
    // 隐私数据类型
    enum class PrivacyType(val displayName: String, val icon: String) {
        PHOTOS("照片/图片", "📷"),
        VIDEOS("视频", "🎬"),
        SMS("短信", "💬"),
        CONTACTS("通讯录", "📇"),
        CALL_LOGS("通话记录", "📞"),
        FILES("文件/文档", "📁"),
        LOCATION("位置信息", "📍")
    }
    
    // 权限状态
    private val _permissionStates = MutableStateFlow<Map<PrivacyType, Boolean>>(emptyMap())
    val permissionStates: StateFlow<Map<PrivacyType, Boolean>> = _permissionStates.asStateFlow()
    
    // 是否开启全局隐私授权（一键开启后不再弹窗）
    private val _globalPrivacyEnabled = MutableStateFlow(false)
    val globalPrivacyEnabled: StateFlow<Boolean> = _globalPrivacyEnabled.asStateFlow()
    
    // 待确认的权限请求
    data class PermissionRequest(
        val type: PrivacyType,
        val reason: String,
        val onGranted: () -> Unit,
        val onDenied: () -> Unit
    )
    
    private val _pendingRequest = MutableStateFlow<PermissionRequest?>(null)
    val pendingRequest: StateFlow<PermissionRequest?> = _pendingRequest.asStateFlow()
    
    private var prefs: SharedPreferences? = null
    
    /**
     * 初始化
     */
    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        loadPermissionStates()
        LogManager.d(TAG, "🔐 隐私权限管理器初始化完成")
    }
    
    /**
     * 加载保存的权限状态
     */
    private fun loadPermissionStates() {
        val states = mutableMapOf<PrivacyType, Boolean>()
        
        prefs?.let { p ->
            PrivacyType.values().forEach { type ->
                states[type] = p.getBoolean("privacy_${type.name}", false)
            }
            _globalPrivacyEnabled.value = p.getBoolean("global_privacy_enabled", false)
        }
        
        _permissionStates.value = states
        LogManager.d(TAG, "📖 加载权限状态: $states, 全局授权: ${_globalPrivacyEnabled.value}")
    }
    
    /**
     * 保存权限状态
     */
    private fun savePermissionState(type: PrivacyType, granted: Boolean) {
        prefs?.edit()?.apply {
            putBoolean("privacy_${type.name}", granted)
            apply()
        }
        
        val newStates = _permissionStates.value.toMutableMap()
        newStates[type] = granted
        _permissionStates.value = newStates
        
        LogManager.d(TAG, "💾 保存权限状态: ${type.name} = $granted")
    }
    
    /**
     * 设置全局隐私授权
     */
    fun setGlobalPrivacyEnabled(enabled: Boolean) {
        prefs?.edit()?.apply {
            putBoolean("global_privacy_enabled", enabled)
            apply()
        }
        _globalPrivacyEnabled.value = enabled
        
        if (enabled) {
            // 一键开启所有权限
            PrivacyType.values().forEach { type ->
                savePermissionState(type, true)
            }
            LogManager.d(TAG, "🔓 一键开启所有隐私权限")
        }
    }
    
    /**
     * 设置单个隐私权限
     */
    fun setPermission(type: PrivacyType, granted: Boolean) {
        savePermissionState(type, granted)
    }
    
    /**
     * 检查是否有权限访问隐私数据
     * @return true 可以直接访问, false 需要弹窗确认
     */
    fun hasPermission(type: PrivacyType): Boolean {
        // 如果开启了全局授权，直接返回true
        if (_globalPrivacyEnabled.value) {
            return true
        }
        
        // 检查单项权限
        return _permissionStates.value[type] == true
    }
    
    /**
     * 请求隐私权限（会触发弹窗）
     * @param type 隐私数据类型
     * @param reason 访问原因
     * @param onGranted 授权后回调
     * @param onDenied 拒绝后回调
     * @return true 已有权限直接执行, false 需要等待用户确认
     */
    fun requestPermission(
        type: PrivacyType,
        reason: String,
        onGranted: () -> Unit,
        onDenied: () -> Unit
    ): Boolean {
        // 如果已有权限，直接执行
        if (hasPermission(type)) {
            LogManager.d(TAG, "✅ 已有权限: ${type.displayName}")
            onGranted()
            return true
        }
        
        // 创建权限请求，等待用户确认
        LogManager.d(TAG, "🔐 请求权限: ${type.displayName}, 原因: $reason")
        _pendingRequest.value = PermissionRequest(type, reason, onGranted, onDenied)
        return false
    }
    
    /**
     * 用户同意授权
     */
    fun grantPendingRequest(rememberChoice: Boolean = false) {
        val request = _pendingRequest.value ?: return
        
        if (rememberChoice) {
            savePermissionState(request.type, true)
        }
        
        LogManager.d(TAG, "✅ 用户同意授权: ${request.type.displayName}, 记住选择: $rememberChoice")
        request.onGranted()
        _pendingRequest.value = null
    }
    
    /**
     * 用户拒绝授权
     */
    fun denyPendingRequest() {
        val request = _pendingRequest.value ?: return
        
        LogManager.d(TAG, "❌ 用户拒绝授权: ${request.type.displayName}")
        request.onDenied()
        _pendingRequest.value = null
    }
    
    /**
     * 取消当前请求
     */
    fun cancelPendingRequest() {
        _pendingRequest.value = null
    }
    
    /**
     * 重置所有隐私权限
     */
    fun resetAllPermissions() {
        prefs?.edit()?.apply {
            PrivacyType.values().forEach { type ->
                putBoolean("privacy_${type.name}", false)
            }
            putBoolean("global_privacy_enabled", false)
            apply()
        }
        
        _permissionStates.value = PrivacyType.values().associateWith { false }
        _globalPrivacyEnabled.value = false
        
        LogManager.d(TAG, "🔄 已重置所有隐私权限")
    }
    
    /**
     * 获取权限统计信息
     */
    fun getPermissionStats(): PermissionStats {
        val total = PrivacyType.values().size
        val granted = _permissionStates.value.count { it.value }
        return PermissionStats(total, granted)
    }
    
    data class PermissionStats(
        val total: Int,
        val granted: Int
    ) {
        val percentage: Int get() = if (total > 0) (granted * 100 / total) else 0
    }
    
    // ==================== 便捷方法 ====================
    
    /**
     * 检查照片权限
     */
    fun hasPhotosPermission() = hasPermission(PrivacyType.PHOTOS)
    
    /**
     * 检查视频权限
     */
    fun hasVideosPermission() = hasPermission(PrivacyType.VIDEOS)
    
    /**
     * 检查短信权限
     */
    fun hasSmsPermission() = hasPermission(PrivacyType.SMS)
    
    /**
     * 检查通讯录权限
     */
    fun hasContactsPermission() = hasPermission(PrivacyType.CONTACTS)
    
    /**
     * 检查通话记录权限
     */
    fun hasCallLogsPermission() = hasPermission(PrivacyType.CALL_LOGS)
    
    /**
     * 检查文件权限
     */
    fun hasFilesPermission() = hasPermission(PrivacyType.FILES)
    
    /**
     * 检查位置权限
     */
    fun hasLocationPermission() = hasPermission(PrivacyType.LOCATION)
}
