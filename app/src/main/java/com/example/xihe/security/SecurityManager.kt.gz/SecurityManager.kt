package com.example.xihe.security

import android.content.Context
import android.util.Base64
import com.example.xihe.utils.LogManager
import com.example.xihe.ai.TaskPlanner
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * 🛡️ 安全管理器
 * 负责保护用户隐私、检测危险操作、加密敏感数据
 */
object SecurityManager {
    
    private const val TAG = "SecurityManager"
    
    /**
     * 安全级别
     */
    enum class SafetyLevel {
        SAFE,           // 安全
        LOW_RISK,       // 低风险
        MEDIUM_RISK,    // 中风险
        HIGH_RISK,      // 高风险
        CRITICAL,       // 危险
        FORBIDDEN       // 禁止
    }
    
    /**
     * 安全检查结果
     */
    @Serializable
    data class SecurityCheckResult(
        val level: SafetyLevel,
        val requiresConfirmation: Boolean,
        val warnings: List<String> = emptyList(),
        val blockedReasons: List<String> = emptyList(),
        val suggestedAction: String? = null,
        val riskScore: Float = 0f  // 0-1
    )
    
    /**
     * 隐私数据类型
     */
    enum class PrivacyDataType {
        PASSWORD,
        CREDIT_CARD,
        ID_NUMBER,
        PHONE_NUMBER,
        EMAIL,
        ADDRESS,
        BANK_ACCOUNT,
        API_KEY,
        PERSONAL_INFO
    }
    
    /**
     * 审计日志
     */
    @Serializable
    data class AuditLog(
        val timestamp: Long,
        val action: String,
        val target: String?,
        val result: Boolean,
        val riskLevel: SafetyLevel,
        val userId: String? = null,
        val metadata: Map<String, String> = emptyMap()
    )
    
    // 加密相关常量
    private const val AES_MODE = "AES/CBC/PKCS5Padding"
    private const val AES_KEY_SIZE = 256
    private const val SALT = "XiheAI2024Security"
    
    // 危险操作黑名单
    private val dangerousKeywords = setOf(
        // 金融相关
        "支付", "转账", "付款", "提现", "充值", "贷款", "信用卡", "银行卡",
        // 隐私相关
        "密码", "验证码", "身份证", "私钥", "助记词",
        // 系统危险操作
        "删除", "卸载", "格式化", "恢复出厂", "刷机", "root", "越狱",
        // 权限相关
        "授权", "允许", "权限", "访问通讯录", "访问相册", "访问位置"
    )
    
    // 敏感应用列表
    private val sensitiveApps = setOf(
        "com.android.vending",  // Play商店
        "com.android.settings",  // 设置
        "com.eg.android.AlipayGphone",  // 支付宝
        "com.tencent.mm",  // 微信（支付功能）
        "com.icbc",  // 工商银行
        "com.chinamworld.bocmbci",  // 中国银行
        "com.ccb.ccbnetbank"  // 建设银行
    )
    
    // 审计日志存储
    private val auditLogs = mutableListOf<AuditLog>()
    private val _auditStream = MutableStateFlow<List<AuditLog>>(emptyList())
    val auditStream = _auditStream.asStateFlow()
    
    // 安全配置
    private var strictMode = false  // 严格模式
    private var privacyMode = false  // 隐私模式
    private val whitelistedActions = mutableSetOf<String>()  // 白名单
    private val blacklistedActions = mutableSetOf<String>()  // 黑名单
    
    /**
     * 🔍 检查操作安全性
     */
    fun checkOperationSafety(
        action: String,
        target: String? = null,
        context: Map<String, Any> = emptyMap()
    ): SecurityCheckResult {
        LogManager.d(TAG, "检查操作安全性: action=$action, target=$target")
        
        val warnings = mutableListOf<String>()
        val blockedReasons = mutableListOf<String>()
        var riskScore = 0f
        
        // 检查黑名单
        if (blacklistedActions.contains(action)) {
            blockedReasons.add("该操作已被加入黑名单")
            return SecurityCheckResult(
                level = SafetyLevel.FORBIDDEN,
                requiresConfirmation = false,
                blockedReasons = blockedReasons,
                riskScore = 1f
            )
        }
        
        // 检查白名单（白名单操作仍需要基础安全检查）
        val isWhitelisted = whitelistedActions.contains(action)
        if (isWhitelisted) {
            riskScore *= 0.5f  // 白名单操作风险减半
        }
        
        // 分析操作内容
        val actionLower = action.lowercase()
        val targetLower = target?.lowercase() ?: ""
        
        // 检查危险关键词
        for (keyword in dangerousKeywords) {
            if (actionLower.contains(keyword) || targetLower.contains(keyword)) {
                riskScore += 0.3f
                warnings.add("操作涉及敏感内容: $keyword")
            }
        }
        
        // 检查目标应用
        val targetApp = context["targetApp"] as? String
        if (targetApp != null && sensitiveApps.contains(targetApp)) {
            riskScore += 0.4f
            warnings.add("目标为敏感应用")
        }
        
        // 检查特定场景
        when {
            actionLower.contains("支付") || actionLower.contains("转账") -> {
                riskScore += 0.6f
                warnings.add("涉及金融交易")
            }
            actionLower.contains("删除") && targetLower.contains("全部") -> {
                riskScore += 0.5f
                warnings.add("批量删除操作")
            }
            actionLower.contains("分享") && context["hasPersonalInfo"] == true -> {
                riskScore += 0.4f
                warnings.add("分享包含个人信息")
            }
            actionLower.contains("发送") && targetLower.contains("所有") -> {
                riskScore += 0.3f
                warnings.add("群发消息")
            }
        }
        
        // 严格模式下提高风险评分
        if (strictMode) {
            riskScore *= 1.5f
        }
        
        // 确保风险分数在0-1范围内
        riskScore = riskScore.coerceIn(0f, 1f)
        
        // 根据风险分数确定安全级别
        val level = when {
            riskScore >= 0.8f -> SafetyLevel.CRITICAL
            riskScore >= 0.6f -> SafetyLevel.HIGH_RISK
            riskScore >= 0.4f -> SafetyLevel.MEDIUM_RISK
            riskScore >= 0.2f -> SafetyLevel.LOW_RISK
            else -> SafetyLevel.SAFE
        }
        
        // 确定是否需要用户确认
        val requiresConfirmation = when (level) {
            SafetyLevel.CRITICAL -> true
            SafetyLevel.HIGH_RISK -> true
            SafetyLevel.MEDIUM_RISK -> strictMode
            else -> false
        }
        
        // 生成建议
        val suggestedAction = when (level) {
            SafetyLevel.CRITICAL -> "建议取消操作或仔细检查"
            SafetyLevel.HIGH_RISK -> "请确认操作内容无误"
            SafetyLevel.MEDIUM_RISK -> "建议谨慎操作"
            else -> null
        }
        
        // 记录审计日志
        recordAudit(action, target, true, level)
        
        return SecurityCheckResult(
            level = level,
            requiresConfirmation = requiresConfirmation,
            warnings = warnings,
            blockedReasons = blockedReasons,
            suggestedAction = suggestedAction,
            riskScore = riskScore
        )
    }
    
    /**
     * 🔐 加密敏感数据
     */
    fun encryptSensitiveData(data: String, context: Context): String {
        return try {
            LocalDataEncryption.encrypt(data)
        } catch (e: Exception) {
            LogManager.e(TAG, "加密失败", e)
            hashData(data)
        }
    }

    /**
     * 🔓 解密敏感数据
     */
    fun decryptSensitiveData(encryptedData: String, context: Context): String {
        return try {
            LocalDataEncryption.decrypt(encryptedData)
        } catch (primaryError: Exception) {
            try {
                decryptSensitiveDataLegacy(encryptedData, context)
            } catch (legacyError: Exception) {
                LogManager.e(TAG, "解密失败", legacyError)
                ""
            }
        }
    }

    /**
     * 📊 检测隐私数据类型
     */
    fun detectPrivacyDataType(text: String): PrivacyDataType? {
        val patterns = mapOf(
            PrivacyDataType.PASSWORD to "^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d@\$!%*#?&]{8,}$".toRegex(),
            PrivacyDataType.CREDIT_CARD to "^[0-9]{13,19}$".toRegex(),
            PrivacyDataType.ID_NUMBER to "^[1-9]\\d{5}(19|20)\\d{2}(0[1-9]|1[0-2])(0[1-9]|[12]\\d|3[01])\\d{3}[0-9Xx]$".toRegex(),
            PrivacyDataType.PHONE_NUMBER to "^1[3-9]\\d{9}$".toRegex(),
            PrivacyDataType.EMAIL to "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$".toRegex(),
            PrivacyDataType.BANK_ACCOUNT to "^[0-9]{16,19}$".toRegex()
        )
        
        for ((type, pattern) in patterns) {
            if (pattern.matches(text)) {
                LogManager.w(TAG, "检测到隐私数据类型: $type")
                return type
            }
        }
        
        // 基于关键词检测
        val textLower = text.lowercase()
        return when {
            textLower.contains("密码") || textLower.contains("password") -> PrivacyDataType.PASSWORD
            textLower.contains("api") && textLower.contains("key") -> PrivacyDataType.API_KEY
            textLower.contains("地址") || textLower.contains("address") -> PrivacyDataType.ADDRESS
            else -> null
        }
    }
    
    /**
     * 🚫 检查任务计划安全性
     */
    fun checkTaskPlanSafety(plan: TaskPlanner.TaskPlan): SecurityCheckResult {
        LogManager.d(TAG, "检查任务计划安全性: ${plan.taskId}")
        
        var maxRiskScore = 0f
        val allWarnings = mutableListOf<String>()
        val allBlockedReasons = mutableListOf<String>()
        
        // 检查每个步骤
        for (step in plan.steps) {
            val stepContext = mapOf(
                "action" to step.action.name,
                "target" to (step.target ?: ""),
                "value" to (step.value ?: "")
            )
            
            val stepCheck = checkOperationSafety(
                action = step.description,
                target = step.target,
                context = stepContext
            )
            
            maxRiskScore = maxOf(maxRiskScore, stepCheck.riskScore)
            allWarnings.addAll(stepCheck.warnings)
            allBlockedReasons.addAll(stepCheck.blockedReasons)
        }
        
        // 根据任务整体风险级别调整
        val taskRiskMultiplier = when (plan.riskLevel) {
            TaskPlanner.RiskLevel.CRITICAL -> 1.5f
            TaskPlanner.RiskLevel.HIGH -> 1.3f
            TaskPlanner.RiskLevel.MEDIUM -> 1.1f
            else -> 1.0f
        }
        
        maxRiskScore = (maxRiskScore * taskRiskMultiplier).coerceIn(0f, 1f)
        
        // 确定最终安全级别
        val level = when {
            allBlockedReasons.isNotEmpty() -> SafetyLevel.FORBIDDEN
            maxRiskScore >= 0.8f -> SafetyLevel.CRITICAL
            maxRiskScore >= 0.6f -> SafetyLevel.HIGH_RISK
            maxRiskScore >= 0.4f -> SafetyLevel.MEDIUM_RISK
            maxRiskScore >= 0.2f -> SafetyLevel.LOW_RISK
            else -> SafetyLevel.SAFE
        }
        
        return SecurityCheckResult(
            level = level,
            requiresConfirmation = level >= SafetyLevel.MEDIUM_RISK,
            warnings = allWarnings.distinct(),
            blockedReasons = allBlockedReasons.distinct(),
            suggestedAction = if (level >= SafetyLevel.HIGH_RISK) {
                "建议详细检查任务步骤"
            } else null,
            riskScore = maxRiskScore
        )
    }
    
    /**
     * 📝 记录审计日志
     */
    fun recordAudit(
        action: String,
        target: String?,
        result: Boolean,
        riskLevel: SafetyLevel,
        metadata: Map<String, String> = emptyMap()
    ) {
        val log = AuditLog(
            timestamp = System.currentTimeMillis(),
            action = action,
            target = target,
            result = result,
            riskLevel = riskLevel,
            metadata = metadata
        )
        
        auditLogs.add(log)
        _auditStream.value = auditLogs.toList()
        
        // 保持日志数量在合理范围内
        if (auditLogs.size > 1000) {
            auditLogs.removeAt(0)
        }
        
        // 高风险操作立即持久化
        if (riskLevel >= SafetyLevel.HIGH_RISK) {
            persistAuditLog(log)
        }
    }
    
    /**
     * 🔒 设置严格模式
     */
    fun setStrictMode(enabled: Boolean) {
        strictMode = enabled
        LogManager.i(TAG, "严格模式: ${if (enabled) "开启" else "关闭"}")
    }
    
    /**
     * 👤 设置隐私模式
     */
    fun setPrivacyMode(enabled: Boolean) {
        privacyMode = enabled
        LogManager.i(TAG, "隐私模式: ${if (enabled) "开启" else "关闭"}")
        
        if (enabled) {
            // 隐私模式下清理敏感缓存
            clearSensitiveCache()
        }
    }
    
    /**
     * ➕ 添加到白名单
     */
    fun addToWhitelist(action: String) {
        whitelistedActions.add(action)
        blacklistedActions.remove(action)  // 从黑名单移除
        LogManager.d(TAG, "添加白名单: $action")
    }
    
    /**
     * ➖ 添加到黑名单
     */
    fun addToBlacklist(action: String) {
        blacklistedActions.add(action)
        whitelistedActions.remove(action)  // 从白名单移除
        LogManager.d(TAG, "添加黑名单: $action")
    }
    
    /**
     * 🗑️ 清理敏感缓存
     */
    fun clearSensitiveCache() {
        // 清理内存中的敏感数据
        LogManager.d(TAG, "清理敏感缓存")
        // 这里可以添加具体的缓存清理逻辑
    }
    
    /**
     * 📈 获取安全统计
     */
    fun getSecurityStatistics(): SecurityStatistics {
        val totalOperations = auditLogs.size
        val blockedOperations = auditLogs.count { it.riskLevel >= SafetyLevel.CRITICAL }
        val highRiskOperations = auditLogs.count { it.riskLevel >= SafetyLevel.HIGH_RISK }
        
        return SecurityStatistics(
            totalOperations = totalOperations,
            blockedOperations = blockedOperations,
            highRiskOperations = highRiskOperations,
            safetyScore = calculateSafetyScore(),
            lastAuditTime = auditLogs.lastOrNull()?.timestamp ?: 0
        )
    }
    
    /**
     * 安全统计信息
     */
    data class SecurityStatistics(
        val totalOperations: Int,
        val blockedOperations: Int,
        val highRiskOperations: Int,
        val safetyScore: Float,  // 0-100
        val lastAuditTime: Long
    )
    
    // ==================== 私有辅助方法 ====================
    
    private fun decryptSensitiveDataLegacy(encryptedData: String, context: Context): String {
        val key = getOrCreateSecretKey(context)
        val combined = Base64.decode(encryptedData, Base64.DEFAULT)

        val iv = combined.sliceArray(0..15)
        val encrypted = combined.sliceArray(16 until combined.size)

        val cipher = Cipher.getInstance(AES_MODE)
        val ivSpec = IvParameterSpec(iv)
        cipher.init(Cipher.DECRYPT_MODE, key, ivSpec)

        return String(cipher.doFinal(encrypted))
    }


    /**
     * 获取或创建密钥
     */
    private fun getOrCreateSecretKey(context: Context): SecretKey {
        val prefs = context.getSharedPreferences("security_prefs", Context.MODE_PRIVATE)
        val keyString = prefs.getString("secret_key", null)
        
        return if (keyString != null) {
            // 从存储中恢复密钥
            val keyBytes = Base64.decode(keyString, Base64.DEFAULT)
            SecretKeySpec(keyBytes, "AES")
        } else {
            // 生成新密钥
            val keyGen = KeyGenerator.getInstance("AES")
            keyGen.init(AES_KEY_SIZE)
            val key = keyGen.generateKey()
            
            // 保存密钥
            val keyBytes = key.encoded
            val keyString = Base64.encodeToString(keyBytes, Base64.DEFAULT)
            prefs.edit().putString("secret_key", keyString).apply()
            
            key
        }
    }
    
    /**
     * 哈希数据
     */
    private fun hashData(data: String): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val hash = digest.digest((data + SALT).toByteArray())
            Base64.encodeToString(hash, Base64.NO_WRAP)
        } catch (e: Exception) {
            LogManager.e(TAG, "哈希失败", e)
            ""
        }
    }
    
    /**
     * 持久化审计日志
     */
    private fun persistAuditLog(log: AuditLog) {
        try {
            // 这里可以实现数据库存储或文件存储
            val json = Json.encodeToString(log)
            LogManager.d(TAG, "持久化审计日志: $json")
        } catch (e: Exception) {
            LogManager.e(TAG, "持久化审计日志失败", e)
        }
    }
    
    /**
     * 计算安全评分
     */
    private fun calculateSafetyScore(): Float {
        if (auditLogs.isEmpty()) return 100f
        
        val recentLogs = auditLogs.takeLast(100)  // 最近100条
        val safeCount = recentLogs.count { it.riskLevel <= SafetyLevel.LOW_RISK }
        
        return (safeCount.toFloat() / recentLogs.size * 100).coerceIn(0f, 100f)
    }
}
