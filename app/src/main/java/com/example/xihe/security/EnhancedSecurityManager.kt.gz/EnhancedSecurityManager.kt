package com.example.xihe.security

import android.content.Context
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.Contextual
import java.text.SimpleDateFormat
import java.util.*

/**
 * 🔒 增强安全管理器
 * 
 * 功能:
 * 1. 支付操作保护
 * 2. 隐私数据保护
 * 3. 操作审计日志
 * 4. 异常行为检测
 * 5. 权限细化控制
 * 
 * 优化点:
 * - 从基础安全 -> 多层保护
 * - 增加操作审计
 * - 智能异常检测
 * - 用户可控权限
 */
class EnhancedSecurityManager(private val context: Context) {
    
    companion object {
        private const val TAG = "EnhancedSecurity"
        private const val MAX_AUDIT_LOGS = 1000
        
        // 敏感操作阈值
        private const val PAYMENT_THRESHOLD = 1000f  // 支付金额阈值（元）
        private const val MAX_FAILED_ATTEMPTS = 3     // 最大失败次数
        private const val ANOMALY_SCORE_THRESHOLD = 0.7f  // 异常分数阈值
    }
    
    // 安全状态
    private val _securityState = MutableStateFlow(SecurityState.NORMAL)
    val securityState = _securityState.asStateFlow()
    
    // 审计日志
    private val auditLogs = mutableListOf<AuditLog>()
    
    // 失败计数器
    private val failureCounter = mutableMapOf<String, Int>()
    
    // 白名单/黑名单
    private val allowedApps = mutableSetOf<String>()
    private val blockedApps = mutableSetOf<String>()
    private val blockedActions = mutableSetOf<ActionType>()
    
    init {
        initializeSecurityConfig()
    }
    
    /**
     * 🔐 初始化安全配置
     */
    private fun initializeSecurityConfig() {
        // 默认允许的应用
        allowedApps.addAll(listOf(
            "com.tencent.mm",           // 微信
            "com.taobao.taobao",        // 淘宝
            "com.jingdong.app.mall",    // 京东
            "com.sina.weibo"            // 微博
        ))
        
        // 默认阻止的操作
        blockedActions.addAll(listOf(
            ActionType.UNINSTALL_APP,
            ActionType.DELETE_ALL_DATA,
            ActionType.FACTORY_RESET,
            ActionType.GRANT_ADMIN
        ))
        
        LogManager.d(TAG, "🔐 安全配置已初始化")
    }
    
    /**
     * 🛡️ 检查操作安全性
     */
    fun checkOperationSecurity(operation: Operation): SecurityCheckResult {
        LogManager.d(TAG, "🛡️ 检查操作: ${operation.type}")
        
        // 1. 检查应用白名单
        if (!isAppAllowed(operation.targetApp)) {
            return SecurityCheckResult(
                allowed = false,
                level = SecurityLevel.HIGH_RISK,
                reason = "应用不在白名单中",
                requiresConfirmation = true,
                userMessage = "此应用未经授权，是否继续？"
            )
        }
        
        // 2. 检查操作黑名单
        if (isActionBlocked(operation.type)) {
            return SecurityCheckResult(
                allowed = false,
                level = SecurityLevel.CRITICAL,
                reason = "操作已被阻止",
                requiresConfirmation = false,
                userMessage = "此操作已被安全策略禁止"
            )
        }
        
        // 3. 支付操作特殊检查
        if (operation.type == ActionType.PAYMENT) {
            return checkPaymentSecurity(operation)
        }
        
        // 4. 隐私操作检查
        if (isPrivacyOperation(operation)) {
            return checkPrivacySecurity(operation)
        }
        
        // 5. 异常检测
        val anomalyScore = detectAnomalyBehavior(operation)
        if (anomalyScore > ANOMALY_SCORE_THRESHOLD) {
            return SecurityCheckResult(
                allowed = true,
                level = SecurityLevel.MEDIUM_RISK,
                reason = "检测到异常行为模式",
                requiresConfirmation = true,
                userMessage = "此操作看起来有些异常，确认继续吗？",
                anomalyScore = anomalyScore
            )
        }
        
        // 6. 检查失败次数
        val failureCount = failureCounter[operation.taskId] ?: 0
        if (failureCount >= MAX_FAILED_ATTEMPTS) {
            return SecurityCheckResult(
                allowed = false,
                level = SecurityLevel.HIGH_RISK,
                reason = "失败次数过多",
                requiresConfirmation = false,
                userMessage = "操作失败次数过多，已暂停"
            )
        }
        
        // 通过所有检查
        return SecurityCheckResult(
            allowed = true,
            level = SecurityLevel.SAFE,
            reason = "安全检查通过",
            requiresConfirmation = false,
            userMessage = null
        )
    }
    
    /**
     * 💰 检查支付安全
     */
    private fun checkPaymentSecurity(operation: Operation): SecurityCheckResult {
        val amount = operation.parameters["amount"]?.toFloatOrNull() ?: 0f
        val payee = operation.parameters["payee"] ?: "未知"
        
        return when {
            // 金额超过阈值 - 需要二次确认
            amount > PAYMENT_THRESHOLD -> {
                SecurityCheckResult(
                    allowed = true,
                    level = SecurityLevel.HIGH_RISK,
                    reason = "支付金额较大",
                    requiresConfirmation = true,
                    userMessage = "即将支付 ¥$amount 给 $payee，请确认"
                )
            }
            
            // 陌生收款人 - 警告
            !isKnownPayee(payee) -> {
                SecurityCheckResult(
                    allowed = true,
                    level = SecurityLevel.MEDIUM_RISK,
                    reason = "陌生收款人",
                    requiresConfirmation = true,
                    userMessage = "收款人 $payee 不在常用联系人中，确认支付吗？"
                )
            }
            
            // 正常支付
            else -> {
                SecurityCheckResult(
                    allowed = true,
                    level = SecurityLevel.LOW_RISK,
                    reason = "正常支付",
                    requiresConfirmation = true,  // 所有支付都需要确认
                    userMessage = "确认支付 ¥$amount 给 $payee 吗？"
                )
            }
        }
    }
    
    /**
     * 🔐 检查隐私安全
     */
    private fun checkPrivacySecurity(operation: Operation): SecurityCheckResult {
        val dataType = operation.parameters["dataType"] ?: ""
        
        return when {
            isSensitiveData(dataType) -> {
                SecurityCheckResult(
                    allowed = true,
                    level = SecurityLevel.HIGH_RISK,
                    reason = "涉及敏感隐私数据",
                    requiresConfirmation = true,
                    userMessage = "此操作需要访问 $dataType，是否允许？"
                )
            }
            else -> {
                SecurityCheckResult(
                    allowed = true,
                    level = SecurityLevel.LOW_RISK,
                    reason = "一般数据访问",
                    requiresConfirmation = false,
                    userMessage = null
                )
            }
        }
    }
    
    /**
     * 🚨 异常行为检测
     */
    private fun detectAnomalyBehavior(operation: Operation): Float {
        var anomalyScore = 0f
        
        // 1. 时间异常 (深夜操作)
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        if (hour in 0..5) {
            anomalyScore += 0.2f
        }
        
        // 2. 频率异常 (短时间内大量操作)
        val recentOps = getRecentOperations(5 * 60 * 1000)  // 最近5分钟
        if (recentOps.size > 20) {
            anomalyScore += 0.3f
        }
        
        // 3. 操作序列异常 (不符合正常模式)
        if (isAbnormalSequence(operation)) {
            anomalyScore += 0.3f
        }
        
        // 4. 目标应用异常 (从未使用过的应用)
        if (!hasUsedAppBefore(operation.targetApp)) {
            anomalyScore += 0.2f
        }
        
        return anomalyScore.coerceIn(0f, 1f)
    }
    
    /**
     * 📝 记录审计日志
     */
    fun logOperation(
        operation: Operation,
        result: OperationResult,
        securityCheck: SecurityCheckResult? = null
    ) {
        val log = AuditLog(
            timestamp = System.currentTimeMillis(),
            operation = operation,
            result = result,
            securityCheck = securityCheck,
            userId = getCurrentUserId()
        )
        
        auditLogs.add(log)
        
        // 保持日志数量限制
        if (auditLogs.size > MAX_AUDIT_LOGS) {
            auditLogs.removeAt(0)
        }
        
        LogManager.d(TAG, "📝 已记录操作: ${operation.type} - ${result.status}")
        
        // 如果失败，更新失败计数
        if (result.status == OperationStatus.FAILED) {
            val count = failureCounter.getOrDefault(operation.taskId, 0)
            failureCounter[operation.taskId] = count + 1
        } else if (result.status == OperationStatus.SUCCESS) {
            // 成功则清除失败计数
            failureCounter.remove(operation.taskId)
        }
    }
    
    /**
     * 📊 获取审计日志
     */
    fun getAuditLogs(
        startTime: Long? = null,
        endTime: Long? = null,
        operationType: ActionType? = null
    ): List<AuditLog> {
        return auditLogs.filter { log ->
            (startTime == null || log.timestamp >= startTime) &&
            (endTime == null || log.timestamp <= endTime) &&
            (operationType == null || log.operation.type == operationType)
        }
    }
    
    /**
     * 📈 生成安全报告
     */
    fun generateSecurityReport(days: Int = 7): SecurityReport {
        val cutoffTime = System.currentTimeMillis() - (days * 24 * 60 * 60 * 1000L)
        val recentLogs = auditLogs.filter { it.timestamp >= cutoffTime }
        
        val totalOperations = recentLogs.size
        val successfulOps = recentLogs.count { it.result.status == OperationStatus.SUCCESS }
        val failedOps = recentLogs.count { it.result.status == OperationStatus.FAILED }
        val blockedOps = recentLogs.count { it.securityCheck?.allowed == false }
        
        val highRiskOps = recentLogs.count {
            it.securityCheck?.level in listOf(SecurityLevel.HIGH_RISK, SecurityLevel.CRITICAL)
        }
        
        val paymentOps = recentLogs.count { it.operation.type == ActionType.PAYMENT }
        val privacyOps = recentLogs.count { isPrivacyOperation(it.operation) }
        
        return SecurityReport(
            periodDays = days,
            totalOperations = totalOperations,
            successfulOperations = successfulOps,
            failedOperations = failedOps,
            blockedOperations = blockedOps,
            highRiskOperations = highRiskOps,
            paymentOperations = paymentOps,
            privacyOperations = privacyOps,
            anomalyDetections = recentLogs.count { 
                (it.securityCheck?.anomalyScore ?: 0f) > ANOMALY_SCORE_THRESHOLD 
            },
            recommendations = generateRecommendations(recentLogs)
        )
    }
    
    /**
     * 🔧 权限管理
     */
    fun updateAppPermission(packageName: String, allowed: Boolean) {
        if (allowed) {
            allowedApps.add(packageName)
            blockedApps.remove(packageName)
        } else {
            blockedApps.add(packageName)
            allowedApps.remove(packageName)
        }
        LogManager.d(TAG, "🔧 更新应用权限: $packageName = $allowed")
    }
    
    fun updateActionPermission(action: ActionType, blocked: Boolean) {
        if (blocked) {
            blockedActions.add(action)
        } else {
            blockedActions.remove(action)
        }
        LogManager.d(TAG, "🔧 更新操作权限: $action = ${!blocked}")
    }
    
    // ==================== 辅助方法 ====================
    
    private fun isAppAllowed(packageName: String?): Boolean {
        if (packageName == null) return true
        if (blockedApps.contains(packageName)) return false
        // 如果白名单为空，允许所有应用
        return allowedApps.isEmpty() || allowedApps.contains(packageName)
    }
    
    private fun isActionBlocked(action: ActionType): Boolean {
        return blockedActions.contains(action)
    }
    
    private fun isPrivacyOperation(operation: Operation): Boolean {
        return operation.type in listOf(
            ActionType.READ_CONTACTS,
            ActionType.READ_SMS,
            ActionType.READ_PHOTOS,
            ActionType.ACCESS_LOCATION,
            ActionType.ACCESS_CAMERA
        )
    }
    
    private fun isSensitiveData(dataType: String): Boolean {
        return dataType in listOf(
            "通讯录", "短信", "照片", "位置", "摄像头",
            "麦克风", "通话记录", "银行卡"
        )
    }
    
    private fun isKnownPayee(payee: String): Boolean {
        // 从历史支付记录中检查是否是已知收款人
        val paymentLogs = auditLogs.filter { it.operation.type == ActionType.PAYMENT }
        val knownPayees = paymentLogs.mapNotNull { it.operation.parameters["payee"] }.toSet()
        return payee in knownPayees
    }
    
    private fun getRecentOperations(timeWindow: Long): List<AuditLog> {
        val cutoff = System.currentTimeMillis() - timeWindow
        return auditLogs.filter { it.timestamp >= cutoff }
    }
    
    private fun isAbnormalSequence(operation: Operation): Boolean {
        // 基于规则的异常序列检测
        val recentOps = getRecentOperations(60_000) // 最近1分钟的操作
        if (recentOps.size < 3) return false
        
        // 检测异常模式：连续重复相同操作
        val lastThreeOps = recentOps.takeLast(3)
        if (lastThreeOps.all { it.operation.type == operation.type }) {
            return true
        }
        
        // 检测异常模式：连续失败后仍重试
        val lastFailures = recentOps.takeLast(3).count { it.result.status == OperationStatus.FAILED }
        if (lastFailures >= 2) {
            return true
        }
        
        // 检测异常模式：短时间内操作多个不同应用
        val uniqueApps = recentOps.mapNotNull { it.operation.targetApp }.toSet()
        if (uniqueApps.size > 5) {
            return true
        }
        
        return false
    }
    
    private fun hasUsedAppBefore(packageName: String?): Boolean {
        if (packageName == null) return true
        return auditLogs.any { it.operation.targetApp == packageName }
    }
    
    private fun getCurrentUserId(): String {
        // 从 SharedPreferences 获取用户ID，如果没有则生成一个
        val prefs = context.getSharedPreferences("security_prefs", Context.MODE_PRIVATE)
        var userId = prefs.getString("user_id", null)
        if (userId == null) {
            userId = "user_${System.currentTimeMillis()}"
            prefs.edit().putString("user_id", userId).apply()
        }
        return userId
    }
    
    private fun generateRecommendations(logs: List<AuditLog>): List<String> {
        val recommendations = mutableListOf<String>()
        
        // 分析失败率
        val failureRate = logs.count { it.result.status == OperationStatus.FAILED }.toFloat() / logs.size
        if (failureRate > 0.3f) {
            recommendations.add("失败率较高，建议检查自动化脚本")
        }
        
        // 分析高风险操作
        val highRiskRate = logs.count { 
            it.securityCheck?.level in listOf(SecurityLevel.HIGH_RISK, SecurityLevel.CRITICAL)
        }.toFloat() / logs.size
        if (highRiskRate > 0.2f) {
            recommendations.add("高风险操作较多，建议加强安全审核")
        }
        
        return recommendations
    }
}

// ==================== 数据类 ====================

/**
 * 🔒 安全状态
 */
enum class SecurityState {
    NORMAL,         // 正常
    WARNING,        // 警告
    ALERT,          // 警报
    LOCKED          // 锁定
}

/**
 * ⚠️ 安全级别
 */
enum class SecurityLevel {
    SAFE,           // 安全
    LOW_RISK,       // 低风险
    MEDIUM_RISK,    // 中风险
    HIGH_RISK,      // 高风险
    CRITICAL        // 危险
}

/**
 * 🎬 操作类型
 */
enum class ActionType {
    // 正常操作
    CLICK, INPUT, SCROLL, SWIPE,
    LAUNCH_APP, CLOSE_APP,
    
    // 支付操作
    PAYMENT, TRANSFER,
    
    // 隐私操作
    READ_CONTACTS, READ_SMS, READ_PHOTOS,
    ACCESS_LOCATION, ACCESS_CAMERA, ACCESS_MICROPHONE,
    
    // 危险操作
    UNINSTALL_APP, DELETE_ALL_DATA,
    FACTORY_RESET, GRANT_ADMIN,
    
    // 其他
    CUSTOM
}

/**
 * 🎯 操作信息
 */
@Serializable
data class Operation(
    val taskId: String,
    val type: ActionType,
    val targetApp: String?,
    val description: String,
    val parameters: Map<String, String> = emptyMap(),
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * ✅ 操作结果
 */
@Serializable
data class OperationResult(
    val status: OperationStatus,
    val message: String,
    val duration: Long = 0,
    val errorCode: String? = null
)

/**
 * 📊 操作状态
 */
enum class OperationStatus {
    SUCCESS,        // 成功
    FAILED,         // 失败
    CANCELLED,      // 取消
    TIMEOUT         // 超时
}

/**
 * 🛡️ 安全检查结果
 */
data class SecurityCheckResult(
    val allowed: Boolean,
    val level: SecurityLevel,
    val reason: String,
    val requiresConfirmation: Boolean,
    val userMessage: String?,
    val anomalyScore: Float = 0f
)

/**
 * 📝 审计日志
 */
@Serializable
data class AuditLog(
    val timestamp: Long,
    val operation: Operation,
    val result: OperationResult,
    @Contextual val securityCheck: SecurityCheckResult?,
    val userId: String
) {
    fun getFormattedTime(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }
}

/**
 * 📊 安全报告
 */
data class SecurityReport(
    val periodDays: Int,
    val totalOperations: Int,
    val successfulOperations: Int,
    val failedOperations: Int,
    val blockedOperations: Int,
    val highRiskOperations: Int,
    val paymentOperations: Int,
    val privacyOperations: Int,
    val anomalyDetections: Int,
    val recommendations: List<String>
) {
    val successRate: Float
        get() = if (totalOperations > 0) {
            successfulOperations.toFloat() / totalOperations
        } else 0f
}

