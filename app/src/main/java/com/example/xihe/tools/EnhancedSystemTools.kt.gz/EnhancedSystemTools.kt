package com.example.xihe.tools

import android.content.Context
import com.example.xihe.camera.CameraManager
import com.example.xihe.notification.EnhancedNotificationManager
import com.example.xihe.system.SystemControlManager
import com.example.xihe.communication.CommunicationManager
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.int
import kotlinx.serialization.json.boolean

// ==================== 相机工具 ====================

class TakePictureToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "take_picture",
        description = "拍照功能，可指定前置/后置摄像头、闪光灯模式和画质",
        category = "相机",
        parameters = listOf(
            ToolParameter("facing", "string", "摄像头方向：front(前置)或back(后置)", required = false),
            ToolParameter("flash", "string", "闪光灯模式：off(关闭)、on(开启)、auto(自动)", required = false),
            ToolParameter("quality", "string", "画质：low(低)、medium(中)、high(高)", required = false),
            ToolParameter("save_file", "boolean", "是否保存到文件", required = false)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val facing = parameters["facing"]?.jsonPrimitive?.content?.let {
                when (it.lowercase()) {
                    "front" -> CameraManager.CameraFacing.FRONT
                    else -> CameraManager.CameraFacing.BACK
                }
            } ?: CameraManager.CameraFacing.BACK
            
            val flash = parameters["flash"]?.jsonPrimitive?.content?.let {
                when (it.lowercase()) {
                    "on" -> CameraManager.FlashMode.ON
                    "auto" -> CameraManager.FlashMode.AUTO
                    else -> CameraManager.FlashMode.OFF
                }
            } ?: CameraManager.FlashMode.OFF
            
            val quality = parameters["quality"]?.jsonPrimitive?.content?.let {
                when (it.lowercase()) {
                    "low" -> CameraManager.ImageQuality.LOW
                    "medium" -> CameraManager.ImageQuality.MEDIUM
                    else -> CameraManager.ImageQuality.HIGH
                }
            } ?: CameraManager.ImageQuality.HIGH
            
            val saveFile = parameters["save_file"]?.jsonPrimitive?.boolean ?: true
            
            val config = CameraManager.CameraConfig(facing, flash, quality)
            val result = CameraManager.getInstance(context).takePicture(config, saveFile)
            
            if (result.success) {
                ToolResult(true, "✅ 拍照成功${if (result.filePath != null) "，已保存到: ${result.filePath}" else ""}")
            } else {
                ToolResult(false, result.errorMessage ?: "拍照失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "拍照失败: ${e.message}")
        }
    }
}

class QuickCaptureToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "quick_capture",
        description = "快速拍照（使用默认配置）",
        category = "相机",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val result = CameraManager.getInstance(context).quickCapture()
            if (result.success) {
                ToolResult(true, "✅ 快速拍照成功: ${result.filePath}")
            } else {
                ToolResult(false, result.errorMessage ?: "拍照失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "拍照失败: ${e.message}")
        }
    }
}

class TakeSelfieToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "take_selfie",
        description = "自拍（使用前置摄像头）",
        category = "相机",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val result = CameraManager.getInstance(context).takeSelfie()
            if (result.success) {
                ToolResult(true, "✅ 自拍成功: ${result.filePath}")
            } else {
                ToolResult(false, result.errorMessage ?: "自拍失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "自拍失败: ${e.message}")
        }
    }
}

// ==================== 通知工具 ====================

class GetNotificationsToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "get_notifications",
        description = "获取当前所有通知",
        category = "通知",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val notifications = EnhancedNotificationManager.getInstance(context).getActiveNotifications()
            val summary = "共有 ${notifications.size} 条通知\n" +
                notifications.take(10).joinToString("\n") { 
                    "【${it.appName}】${it.title}: ${it.text}"
                }
            ToolResult(true, summary)
        } catch (e: Exception) {
            ToolResult(false, "获取通知失败: ${e.message}")
        }
    }
}

class GetMessageNotificationsToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "get_message_notifications",
        description = "获取消息类通知（微信、QQ等）",
        category = "通知",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val notifications = EnhancedNotificationManager.getInstance(context).getMessageNotifications()
            val summary = "共有 ${notifications.size} 条消息通知\n" +
                notifications.take(10).joinToString("\n") {
                    "【${it.appName}】${it.title}: ${it.text}"
                }
            ToolResult(true, summary)
        } catch (e: Exception) {
            ToolResult(false, "获取消息通知失败: ${e.message}")
        }
    }
}

class ClearNotificationToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "clear_notification",
        description = "清除指定应用的通知",
        category = "通知",
        parameters = listOf(
            ToolParameter("package_name", "string", "应用包名，如com.tencent.mm", required = true)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val packageName = parameters["package_name"]?.jsonPrimitive?.content
                ?: return ToolResult(false, "缺少package_name参数")
            
            val success = EnhancedNotificationManager.getInstance(context).clearNotificationsByPackage(packageName)
            if (success) {
                ToolResult(true, "✅ 已清除 $packageName 的通知")
            } else {
                ToolResult(false, "清除通知失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "清除通知失败: ${e.message}")
        }
    }
}

// ==================== 系统控制工具 ====================

class SetVolumeToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "set_volume",
        description = "设置音量（0-100）",
        category = "系统控制",
        parameters = listOf(
            ToolParameter("type", "string", "音量类型：music(媒体)、ring(铃声)、alarm(闹钟)、notification(通知)、call(通话)", required = true),
            ToolParameter("volume", "number", "音量值（0-100）", required = true)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val typeStr = parameters["type"]?.jsonPrimitive?.content
                ?: return ToolResult(false, "缺少type参数")
            val volume = parameters["volume"]?.jsonPrimitive?.int
                ?: return ToolResult(false, "缺少volume参数")
            
            val type = when (typeStr.lowercase()) {
                "music" -> SystemControlManager.VolumeControl.StreamType.MUSIC
                "ring" -> SystemControlManager.VolumeControl.StreamType.RING
                "alarm" -> SystemControlManager.VolumeControl.StreamType.ALARM
                "notification" -> SystemControlManager.VolumeControl.StreamType.NOTIFICATION
                "call" -> SystemControlManager.VolumeControl.StreamType.CALL
                else -> return ToolResult(false, "未知的音量类型: $typeStr")
            }
            
            val success = SystemControlManager.getInstance(context).setVolume(type, volume)
            if (success) {
                ToolResult(true, "✅ 已设置${typeStr}音量为 $volume%")
            } else {
                ToolResult(false, "设置音量失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "设置音量失败: ${e.message}")
        }
    }
}

class SetBrightnessToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "set_brightness",
        description = "设置屏幕亮度（0-100）",
        category = "系统控制",
        parameters = listOf(
            ToolParameter("brightness", "number", "亮度值（0-100）", required = true)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val brightness = parameters["brightness"]?.jsonPrimitive?.int
                ?: return ToolResult(false, "缺少brightness参数")
            
            val success = SystemControlManager.getInstance(context).setBrightness(brightness)
            if (success) {
                ToolResult(true, "✅ 已设置屏幕亮度为 $brightness%")
            } else {
                ToolResult(false, "设置亮度失败，可能需要系统设置权限")
            }
        } catch (e: Exception) {
            ToolResult(false, "设置亮度失败: ${e.message}")
        }
    }
}

class SetFlashlightToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "set_flashlight",
        description = "开关手电筒",
        category = "系统控制",
        parameters = listOf(
            ToolParameter("enable", "boolean", "true=开启，false=关闭", required = true)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val enable = parameters["enable"]?.jsonPrimitive?.boolean
                ?: return ToolResult(false, "缺少enable参数")
            
            val success = SystemControlManager.getInstance(context).setFlashlight(enable)
            if (success) {
                ToolResult(true, "✅ 手电筒已${if (enable) "开启" else "关闭"}")
            } else {
                ToolResult(false, "手电筒控制失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "手电筒控制失败: ${e.message}")
        }
    }
}

class ToggleFlashlightToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "toggle_flashlight",
        description = "切换手电筒状态",
        category = "系统控制",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val success = SystemControlManager.getInstance(context).toggleFlashlight()
            if (success) {
                val isOn = SystemControlManager.getInstance(context).isFlashlightOn()
                ToolResult(true, "✅ 手电筒已${if (isOn) "开启" else "关闭"}")
            } else {
                ToolResult(false, "手电筒切换失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "手电筒切换失败: ${e.message}")
        }
    }
}

class SetDoNotDisturbToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "set_do_not_disturb",
        description = "开关勿扰模式",
        category = "系统控制",
        parameters = listOf(
            ToolParameter("enable", "boolean", "true=开启，false=关闭", required = true)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val enable = parameters["enable"]?.jsonPrimitive?.boolean
                ?: return ToolResult(false, "缺少enable参数")
            
            val success = SystemControlManager.getInstance(context).setDoNotDisturb(enable)
            if (success) {
                ToolResult(true, "✅ 勿扰模式已${if (enable) "开启" else "关闭"}")
            } else {
                ToolResult(false, "勿扰模式设置失败，可能需要权限")
            }
        } catch (e: Exception) {
            ToolResult(false, "勿扰模式设置失败: ${e.message}")
        }
    }
}

class GetBatteryInfoToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "get_battery_info",
        description = "获取电池信息",
        category = "系统控制",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val info = SystemControlManager.getInstance(context).getBatteryInfo()
            val message = "🔋 电量: ${info.percentage}%\n" +
                "⚡ 充电状态: ${if (info.isCharging) "充电中" else "未充电"}\n" +
                "🔌 充电方式: ${info.chargingType}"
            ToolResult(true, message)
        } catch (e: Exception) {
            ToolResult(false, "获取电池信息失败: ${e.message}")
        }
    }
}

// ==================== 通讯工具 ====================

class SendSmsToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "send_sms",
        description = "发送短信",
        category = "通讯",
        parameters = listOf(
            ToolParameter("phone_number", "string", "电话号码", required = true),
            ToolParameter("message", "string", "短信内容", required = true)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val phoneNumber = parameters["phone_number"]?.jsonPrimitive?.content
                ?: return ToolResult(false, "缺少phone_number参数")
            val message = parameters["message"]?.jsonPrimitive?.content
                ?: return ToolResult(false, "缺少message参数")
            
            val success = CommunicationManager.getInstance(context).sendSms(phoneNumber, message)
            if (success) {
                ToolResult(true, "✅ 短信已发送到 $phoneNumber")
            } else {
                ToolResult(false, "发送短信失败，可能需要权限")
            }
        } catch (e: Exception) {
            ToolResult(false, "发送短信失败: ${e.message}")
        }
    }
}

class MakeCallToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "make_call",
        description = "拨打电话",
        category = "通讯",
        parameters = listOf(
            ToolParameter("phone_number", "string", "电话号码", required = true)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val phoneNumber = parameters["phone_number"]?.jsonPrimitive?.content
                ?: return ToolResult(false, "缺少phone_number参数")
            
            val success = CommunicationManager.getInstance(context).makeCall(phoneNumber)
            if (success) {
                ToolResult(true, "✅ 正在拨打 $phoneNumber")
            } else {
                ToolResult(false, "拨打电话失败，可能需要权限")
            }
        } catch (e: Exception) {
            ToolResult(false, "拨打电话失败: ${e.message}")
        }
    }
}

class SearchContactsToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "search_contacts",
        description = "搜索联系人",
        category = "通讯",
        parameters = listOf(
            ToolParameter("query", "string", "搜索关键词（姓名或电话）", required = true)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val query = parameters["query"]?.jsonPrimitive?.content
                ?: return ToolResult(false, "缺少query参数")
            
            val contacts = CommunicationManager.getInstance(context).searchContacts(query)
            if (contacts.isEmpty()) {
                ToolResult(true, "未找到匹配的联系人")
            } else {
                val summary = "找到 ${contacts.size} 个联系人：\n" +
                    contacts.take(10).joinToString("\n") { contact ->
                        "${contact.name}: ${contact.phoneNumbers.joinToString(", ")}"
                    }
                ToolResult(true, summary)
            }
        } catch (e: Exception) {
            ToolResult(false, "搜索联系人失败: ${e.message}")
        }
    }
}

class GetSmsMessagesToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "get_sms_messages",
        description = "获取短信列表",
        category = "通讯",
        parameters = listOf(
            ToolParameter("type", "string", "类型：inbox(收件箱)或sent(已发送)", required = false),
            ToolParameter("limit", "number", "获取数量，默认10", required = false)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val type = parameters["type"]?.jsonPrimitive?.content ?: "inbox"
            val limit = parameters["limit"]?.jsonPrimitive?.int ?: 10
            
            val messages = when (type.lowercase()) {
                "sent" -> CommunicationManager.getInstance(context).getSentMessages(limit)
                else -> CommunicationManager.getInstance(context).getInboxMessages(limit)
            }
            
            if (messages.isEmpty()) {
                ToolResult(true, "没有短信")
            } else {
                val summary = "共有 ${messages.size} 条短信：\n" +
                    messages.joinToString("\n") { msg ->
                        "${msg.address}: ${msg.body.take(50)}${if (msg.body.length > 50) "..." else ""}"
                    }
                ToolResult(true, summary)
            }
        } catch (e: Exception) {
            ToolResult(false, "获取短信失败: ${e.message}")
        }
    }
}

class GetCallLogsToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "get_call_logs",
        description = "获取通话记录",
        category = "通讯",
        parameters = listOf(
            ToolParameter("limit", "number", "获取数量，默认10", required = false)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val limit = parameters["limit"]?.jsonPrimitive?.int ?: 10
            val logs = CommunicationManager.getInstance(context).getRecentCalls(limit)
            
            if (logs.isEmpty()) {
                ToolResult(true, "没有通话记录")
            } else {
                val summary = "共有 ${logs.size} 条通话记录：\n" +
                    logs.joinToString("\n") { log ->
                        val typeStr = when (log.type) {
                            CommunicationManager.CallType.INCOMING -> "来电"
                            CommunicationManager.CallType.OUTGOING -> "去电"
                            CommunicationManager.CallType.MISSED -> "未接"
                            CommunicationManager.CallType.REJECTED -> "拒接"
                        }
                        "$typeStr - ${log.name ?: log.number} (${log.duration}秒)"
                    }
                ToolResult(true, summary)
            }
        } catch (e: Exception) {
            ToolResult(false, "获取通话记录失败: ${e.message}")
        }
    }
}
