package com.example.xihe.tools

import android.content.Context
import com.example.xihe.utils.LogManager
import kotlinx.serialization.json.JsonObject

/**
 * 工具注册表 - 管理所有可用工具
 */
object ToolRegistry {
    private const val TAG = "ToolRegistry"
    private val tools = mutableMapOf<String, Tool>()
    
    /**
     * 注册工具
     */
    fun registerTool(tool: Tool) {
        tools[tool.definition.name] = tool
        LogManager.d(TAG, "注册工具: ${tool.definition.name} (${tool.definition.category})")
    }
    
    /**
     * 获取工具
     */
    fun getTool(name: String): Tool? {
        return tools[name]
    }
    
    /**
     * 获取所有工具定义（用于发送给LLM）
     */
    fun getAllToolDefinitions(): List<ToolDefinition> {
        return tools.values.map { it.definition }
    }
    
    /**
     * 执行工具调用
     */
    suspend fun executeTool(toolCall: ToolCall): ToolResult {
        val tool = getTool(toolCall.toolName)
        
        if (tool == null) {
            return ToolResult(
                success = false,
                message = "未找到工具: ${toolCall.toolName}",
                error = "TOOL_NOT_FOUND"
            )
        }
        
        return try {
            tool.execute(toolCall.parameters)
        } catch (e: Exception) {
            LogManager.e(TAG, "工具执行失败: ${toolCall.toolName}", e)
            ToolResult(
                success = false,
                message = "工具执行出错: ${e.message}",
                error = "EXECUTION_ERROR"
            )
        }
    }
    
    /**
     * 初始化所有内置工具
     */
    fun initializeTools(context: Context) {
        // 注册基础文件系统工具
        registerTool(ReadFileToolImpl(context))
        registerTool(WriteFileToolImpl(context))
        registerTool(ListFilesToolImpl(context))
        registerTool(DeleteFileToolImpl(context))
        registerTool(FileExistsToolImpl(context))
        
        // 注册高级文件工具
        registerTool(SearchFilesToolImpl(context))
        registerTool(CopyFileToolImpl(context))
        registerTool(MoveFileToolImpl(context))
        registerTool(CreateDirectoryToolImpl(context))
        registerTool(GetFileInfoToolImpl(context))
        
        // 注册 HTTP 工具
        registerTool(HttpGetToolImpl())
        registerTool(HttpPostToolImpl())
        registerTool(DownloadFileToolImpl(context))
        
        // 注册系统工具
        registerTool(GetDeviceInfoToolImpl(context))
        registerTool(GetInstalledAppsToolImpl(context))
        registerTool(LaunchAppToolImpl(context))
        registerTool(OpenUrlToolImpl(context))
        registerTool(GetClipboardToolImpl(context))
        registerTool(SetClipboardToolImpl(context))
        registerTool(OpenSettingsToolImpl(context))
        registerTool(TakeScreenshotToolImpl(context))
        registerTool(GetCurrentTimeToolImpl())
        
        // 注册生活 API 工具
        registerTool(GetDateTimeToolImpl())
        registerTool(GetWeatherToolImpl())
        registerTool(GetHolidayToolImpl())
        registerTool(RandomNumberToolImpl())
        registerTool(FlipCoinToolImpl())
        registerTool(RollDiceToolImpl())
        registerTool(DailyQuoteToolImpl())
        registerTool(CalculatorToolImpl())
        registerTool(GetPublicIPToolImpl())
        registerTool(DaysBetweenToolImpl())
        
        // 注册自动化场景工具
        registerTool(VideoSwipeToolImpl(context))
        registerTool(FormFillerToolImpl(context))
        registerTool(GameAutomationToolImpl(context))
        
        // 注册游戏工具
        registerTool(GomokuToolImpl(context))
        registerTool(DouDiZhuToolImpl(context))
        registerTool(GameAIToolImpl(context))
        
        // 🆕 注册相机工具
        registerTool(TakePictureToolImpl(context))
        registerTool(QuickCaptureToolImpl(context))
        registerTool(TakeSelfieToolImpl(context))
        
        // 🆕 注册增强通知工具
        registerTool(GetNotificationsToolImpl(context))
        registerTool(GetMessageNotificationsToolImpl(context))
        registerTool(ClearNotificationToolImpl(context))
        
        // 🆕 注册系统控制工具
        registerTool(SetVolumeToolImpl(context))
        registerTool(SetBrightnessToolImpl(context))
        registerTool(SetFlashlightToolImpl(context))
        registerTool(ToggleFlashlightToolImpl(context))
        registerTool(SetDoNotDisturbToolImpl(context))
        registerTool(GetBatteryInfoToolImpl(context))
        
        // 🆕 注册通讯工具
        registerTool(SendSmsToolImpl(context))
        registerTool(MakeCallToolImpl(context))
        registerTool(SearchContactsToolImpl(context))
        registerTool(GetSmsMessagesToolImpl(context))
        registerTool(GetCallLogsToolImpl(context))
        
        // 🆕 注册日历与提醒工具
        registerTool(CreateEventToolImpl(context))
        registerTool(GetTodayEventsToolImpl(context))
        registerTool(SetAlarmToolImpl(context))
        registerTool(SetTimerToolImpl(context))
        
        // 🆕 注册媒体录制工具
        registerTool(StartAudioRecordingToolImpl(context))
        registerTool(StopAudioRecordingToolImpl(context))
        registerTool(GetAudioRecordingsToolImpl(context))
        
        // 🆕 注册联系人增强工具
        registerTool(AddContactToolImpl(context))
        registerTool(UpdateContactToolImpl(context))
        registerTool(DeleteContactToolImpl(context))
        
        // 🆕 注册蓝牙工具
        registerTool(EnableBluetoothToolImpl(context))
        registerTool(DisableBluetoothToolImpl(context))
        registerTool(StartBluetoothDiscoveryToolImpl(context))
        registerTool(GetBondedDevicesToolImpl(context))
        
        // 🆕 注册数据统计工具
        registerTool(GetAppUsageStatsToolImpl(context))
        registerTool(GetScreenTimeStatsToolImpl(context))
        registerTool(GetStorageInfoToolImpl(context))
        registerTool(GetMemoryInfoToolImpl(context))
        registerTool(GetNetworkStatsToolImpl(context))
        registerTool(GetSystemOverviewToolImpl(context))
        
        // 🆕 注册NFC工具
        registerTool(CheckNFCToolImpl(context))
        registerTool(OpenNFCSettingsToolImpl(context))
        
        // 🆕 注册应用集成工具
        registerTool(OpenWeChatToolImpl(context))
        registerTool(OpenWeChatScanToolImpl(context))
        registerTool(OpenAlipayToolImpl(context))
        registerTool(OpenAlipayScanToolImpl(context))
        registerTool(SearchOnTaobaoToolImpl(context))
        registerTool(OpenInBrowserToolImpl(context))
        
        // 🆕 注册文件压缩工具
        registerTool(CompressFileToolImpl(context))
        registerTool(ExtractZipToolImpl(context))
        registerTool(ListZipContentsToolImpl(context))
        
        // 🆕 注册系统维护工具
        registerTool(ClearAppCacheToolImpl(context))
        registerTool(DeepCleanupToolImpl(context))
        registerTool(GetInstalledAppsToolImpl(context))
        registerTool(UninstallAppToolImpl(context))
        registerTool(ForceStopAppToolImpl(context))
        registerTool(GetOptimizationSuggestionsToolImpl(context))
        registerTool(GetSystemInfoToolImpl(context))
        
        // 🆕 注册搜索工具
        registerTool(UniversalSearchToolImpl(context))
        registerTool(SmartSearchToolImpl(context))
        
        // 🆕 注册脚本工具
        registerTool(CreateScriptToolImpl(context))
        registerTool(ExecuteScriptToolImpl(context))
        registerTool(ListScriptsToolImpl(context))
        registerTool(DeleteScriptToolImpl(context))
        
        // 🆕 注册重复动作工具
        registerTool(StartRecordingToolImpl(context))
        registerTool(StopRecordingToolImpl(context))
        registerTool(RepeatActionsToolImpl(context))
        registerTool(RepeatClickToolImpl(context))
        registerTool(RepeatSwipeToolImpl(context))
        
        LogManager.d(TAG, "已注册 ${tools.size} 个工具")
    }
    
    /**
     * 获取所有已注册的工具
     */
    fun getRegisteredTools(): List<ToolDefinition> {
        return tools.values.map { it.definition }
    }
    
    /**
     * 获取工具列表（按类别分组）
     */
    fun getToolsByCategory(): Map<String, List<ToolDefinition>> {
        return tools.values
            .map { it.definition }
            .groupBy { it.category }
    }
}
