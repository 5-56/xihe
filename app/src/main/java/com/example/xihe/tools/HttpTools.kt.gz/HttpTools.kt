package com.example.xihe.tools

import android.content.Context
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.io.IOException

class HttpGetToolImpl : Tool() {
    private val client = createSecureHttpClient()

    override val definition = ToolDefinition(
        name = "http_get",
        description = "Send an HTTP GET request.",
        category = "http",
        parameters = listOf(
            ToolParameter("url", "Request URL", "string", required = true),
            ToolParameter("headers", "Optional headers", "object", required = false)
        )
    )

    override suspend fun execute(parameters: JsonObject): ToolResult {
        validateParameters(parameters)?.let { return it }

        return try {
            val url = parameters["url"]?.jsonPrimitive?.content ?: return ToolResult(
                success = false,
                message = "URL is required",
                error = "INVALID_URL"
            )

            validateSafeUrl(url)?.let { reason ->
                return ToolResult(success = false, message = reason, error = "INVALID_URL")
            }

            val requestBuilder = Request.Builder().url(url)
            parameters["headers"]?.jsonObject?.forEach { (key, value) ->
                requestBuilder.addHeader(key, value.jsonPrimitive.content)
            }

            client.newCall(requestBuilder.build()).execute().use { response ->
                if (response.isSuccessful) {
                    ToolResult(
                        success = true,
                        message = "Request succeeded (${response.code})",
                        data = buildJsonObject {
                            put("statusCode", JsonPrimitive(response.code))
                            put("body", JsonPrimitive(response.body?.string() ?: ""))
                            put("contentType", JsonPrimitive(response.header("Content-Type") ?: ""))
                        }
                    )
                } else {
                    ToolResult(
                        success = false,
                        message = "Request failed: HTTP ${response.code}",
                        error = "HTTP_ERROR",
                        data = buildJsonObject {
                            put("statusCode", JsonPrimitive(response.code))
                            put("message", JsonPrimitive(response.message))
                        }
                    )
                }
            }
        } catch (e: IOException) {
            ToolResult(success = false, message = "Network request failed: ${e.message}", error = "NETWORK_ERROR")
        } catch (e: Exception) {
            ToolResult(success = false, message = "Request failed: ${e.message}", error = "REQUEST_ERROR")
        }
    }
}

class HttpPostToolImpl : Tool() {
    private val client = createSecureHttpClient()

    override val definition = ToolDefinition(
        name = "http_post",
        description = "Send an HTTP POST request.",
        category = "http",
        parameters = listOf(
            ToolParameter("url", "Request URL", "string", required = true),
            ToolParameter("body", "Request body", "string", required = true),
            ToolParameter("contentType", "Content type", "string", required = false),
            ToolParameter("headers", "Optional headers", "object", required = false)
        )
    )

    override suspend fun execute(parameters: JsonObject): ToolResult {
        validateParameters(parameters)?.let { return it }

        return try {
            val url = parameters["url"]?.jsonPrimitive?.content ?: return ToolResult(
                success = false,
                message = "URL is required",
                error = "INVALID_URL"
            )

            validateSafeUrl(url)?.let { reason ->
                return ToolResult(success = false, message = reason, error = "INVALID_URL")
            }

            val bodyContent = parameters["body"]?.jsonPrimitive?.content ?: return ToolResult(
                success = false,
                message = "Request body is required",
                error = "INVALID_BODY"
            )

            val contentType = parameters["contentType"]?.jsonPrimitive?.content ?: "application/json"
            val requestBuilder = Request.Builder()
                .url(url)
                .post(bodyContent.toRequestBody(contentType.toMediaType()))

            parameters["headers"]?.jsonObject?.forEach { (key, value) ->
                requestBuilder.addHeader(key, value.jsonPrimitive.content)
            }

            client.newCall(requestBuilder.build()).execute().use { response ->
                if (response.isSuccessful) {
                    ToolResult(
                        success = true,
                        message = "POST request succeeded (${response.code})",
                        data = buildJsonObject {
                            put("statusCode", JsonPrimitive(response.code))
                            put("body", JsonPrimitive(response.body?.string() ?: ""))
                            put("contentType", JsonPrimitive(response.header("Content-Type") ?: ""))
                        }
                    )
                } else {
                    ToolResult(
                        success = false,
                        message = "POST request failed: HTTP ${response.code}",
                        error = "HTTP_ERROR",
                        data = buildJsonObject {
                            put("statusCode", JsonPrimitive(response.code))
                            put("message", JsonPrimitive(response.message))
                        }
                    )
                }
            }
        } catch (e: IOException) {
            ToolResult(success = false, message = "Network request failed: ${e.message}", error = "NETWORK_ERROR")
        } catch (e: Exception) {
            ToolResult(success = false, message = "POST request failed: ${e.message}", error = "REQUEST_ERROR")
        }
    }
}

class DownloadFileToolImpl(private val context: Context) : Tool() {
    private val client = createSecureHttpClient()

    override val definition = ToolDefinition(
        name = "download_file",
        description = "Download a remote file into app storage.",
        category = "http",
        parameters = listOf(
            ToolParameter("url", "File URL", "string", required = true),
            ToolParameter("savePath", "Relative path under app filesDir", "string", required = true)
        )
    )

    override suspend fun execute(parameters: JsonObject): ToolResult {
        validateParameters(parameters)?.let { return it }

        return try {
            val url = parameters["url"]?.jsonPrimitive?.content ?: return ToolResult(
                success = false,
                message = "URL is required",
                error = "INVALID_URL"
            )

            validateSafeUrl(url)?.let { reason ->
                return ToolResult(success = false, message = reason, error = "INVALID_URL")
            }

            val savePath = parameters["savePath"]?.jsonPrimitive?.content ?: return ToolResult(
                success = false,
                message = "Save path is required",
                error = "INVALID_PATH"
            )

            val targetFile = resolveDownloadTarget(context, savePath) ?: return ToolResult(
                success = false,
                message = "Save path is invalid",
                error = "INVALID_PATH"
            )

            client.newCall(Request.Builder().url(url).build()).execute().use { response ->
                if (!response.isSuccessful) {
                    return ToolResult(
                        success = false,
                        message = "Download failed: HTTP ${response.code}",
                        error = "HTTP_ERROR"
                    )
                }

                val body = response.body ?: return ToolResult(
                    success = false,
                    message = "Download failed: empty response body",
                    error = "EMPTY_BODY"
                )

                targetFile.parentFile?.mkdirs()
                body.byteStream().use { input ->
                    targetFile.outputStream().use { output ->
                        input.copyTo(output)
                    }
                }

                ToolResult(
                    success = true,
                    message = "Download succeeded (${targetFile.length()} bytes)",
                    data = buildJsonObject {
                        put("path", JsonPrimitive(targetFile.absolutePath))
                        put("size", JsonPrimitive(targetFile.length()))
                    }
                )
            }
        } catch (e: IOException) {
            ToolResult(success = false, message = "Download failed: ${e.message}", error = "DOWNLOAD_ERROR")
        } catch (e: Exception) {
            ToolResult(success = false, message = "Download failed: ${e.message}", error = "REQUEST_ERROR")
        }
    }
}

private fun resolveDownloadTarget(context: Context, savePath: String): File? {
    val normalized = savePath.trim().replace('\\', '/')
    if (normalized.isBlank()) {
        return null
    }
    if (normalized.startsWith("/") || normalized.matches(Regex("^[A-Za-z]:.*"))) {
        return null
    }
    if (normalized.split('/').any { it == ".." }) {
        return null
    }

    val baseDir = context.filesDir.canonicalFile
    val targetFile = File(baseDir, normalized).canonicalFile
    return if (targetFile.path == baseDir.path || targetFile.path.startsWith(baseDir.path + File.separator)) {
        targetFile
    } else {
        null
    }
}
