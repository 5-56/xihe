package com.example.xihe.tools

import android.content.Context
import com.example.xihe.calendar.CalendarManager
import com.example.xihe.media.MediaRecorderManager
import com.example.xihe.communication.CommunicationManager
import com.example.xihe.bluetooth.BluetoothManager
import com.example.xihe.analytics.DataAnalyzer
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.int
import kotlinx.serialization.json.boolean
import kotlinx.serialization.json.long

// ==================== 日历与提醒工具 ====================

class CreateEventToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "create_calendar_event",
        description = "创建日历事件",
        category = "日历",
        parameters = listOf(
            ToolParameter("title", "string", "事件标题", required = true),
            ToolParameter("description", "string", "事件描述", required = false),
            ToolParameter("location", "string", "事件地点", required = false),
            ToolParameter("start_time", "number", "开始时间戳(毫秒)", required = true),
            ToolParameter("end_time", "number", "结束时间戳(毫秒)", required = true),
            ToolParameter("all_day", "boolean", "是否全天事件", required = false)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val title = parameters["title"]?.jsonPrimitive?.content
                ?: return ToolResult(false, "缺少title参数")
            val description = parameters["description"]?.jsonPrimitive?.content
            val location = parameters["location"]?.jsonPrimitive?.content
            val startTime = parameters["start_time"]?.jsonPrimitive?.long
                ?: return ToolResult(false, "缺少start_time参数")
            val endTime = parameters["end_time"]?.jsonPrimitive?.long
                ?: return ToolResult(false, "缺少end_time参数")
            val allDay = parameters["all_day"]?.jsonPrimitive?.boolean ?: false
            
            val eventId = CalendarManager.getInstance(context).createEvent(
                title, description, location, startTime, endTime, allDay
            )
            
            if (eventId != null) {
                ToolResult(true, "✅ 日历事件已创建: $title (ID: $eventId)")
            } else {
                ToolResult(false, "创建日历事件失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "创建日历事件失败: ${e.message}")
        }
    }
}

class GetTodayEventsToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "get_today_events",
        description = "获取今天的日历事件",
        category = "日历",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val events = CalendarManager.getInstance(context).getTodayEvents()
            if (events.isEmpty()) {
                ToolResult(true, "今天没有日程安排")
            } else {
                val summary = "今天有 ${events.size} 个事件：\n" +
                    events.joinToString("\n") { event ->
                        "📅 ${event.title}${if (event.location != null) " @ ${event.location}" else ""}"
                    }
                ToolResult(true, summary)
            }
        } catch (e: Exception) {
            ToolResult(false, "获取今天事件失败: ${e.message}")
        }
    }
}

class SetAlarmToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "set_alarm",
        description = "设置闹钟",
        category = "日历",
        parameters = listOf(
            ToolParameter("hour", "number", "小时(0-23)", required = true),
            ToolParameter("minute", "number", "分钟(0-59)", required = true),
            ToolParameter("label", "string", "闹钟标签", required = false)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val hour = parameters["hour"]?.jsonPrimitive?.int
                ?: return ToolResult(false, "缺少hour参数")
            val minute = parameters["minute"]?.jsonPrimitive?.int
                ?: return ToolResult(false, "缺少minute参数")
            val label = parameters["label"]?.jsonPrimitive?.content
            
            val success = CalendarManager.getInstance(context).setAlarm(hour, minute, label)
            if (success) {
                ToolResult(true, "⏰ 闹钟已设置: $hour:${String.format("%02d", minute)}")
            } else {
                ToolResult(false, "设置闹钟失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "设置闹钟失败: ${e.message}")
        }
    }
}

class SetTimerToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "set_timer",
        description = "设置定时器",
        category = "日历",
        parameters = listOf(
            ToolParameter("seconds", "number", "定时秒数", required = true),
            ToolParameter("message", "string", "定时器消息", required = false)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val seconds = parameters["seconds"]?.jsonPrimitive?.int
                ?: return ToolResult(false, "缺少seconds参数")
            val message = parameters["message"]?.jsonPrimitive?.content
            
            val success = CalendarManager.getInstance(context).setTimer(seconds, message)
            if (success) {
                val minutes = seconds / 60
                val secs = seconds % 60
                ToolResult(true, "⏱️ 定时器已设置: ${minutes}分${secs}秒")
            } else {
                ToolResult(false, "设置定时器失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "设置定时器失败: ${e.message}")
        }
    }
}

// ==================== 媒体录制工具 ====================

class StartAudioRecordingToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "start_audio_recording",
        description = "开始录音",
        category = "媒体",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val success = MediaRecorderManager.getInstance(context).startAudioRecording()
            if (success) {
                ToolResult(true, "🎤 录音已开始")
            } else {
                ToolResult(false, "开始录音失败，请检查权限")
            }
        } catch (e: Exception) {
            ToolResult(false, "开始录音失败: ${e.message}")
        }
    }
}

class StopAudioRecordingToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "stop_audio_recording",
        description = "停止录音",
        category = "媒体",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val result = MediaRecorderManager.getInstance(context).stopAudioRecording()
            if (result.success) {
                ToolResult(true, "⏹️ 录音已停止并保存: ${result.filePath}")
            } else {
                ToolResult(false, result.errorMessage ?: "停止录音失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "停止录音失败: ${e.message}")
        }
    }
}

class GetAudioRecordingsToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "get_audio_recordings",
        description = "获取所有录音文件列表",
        category = "媒体",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val recordings = MediaRecorderManager.getInstance(context).getAudioRecordings()
            if (recordings.isEmpty()) {
                ToolResult(true, "没有录音文件")
            } else {
                val summary = "共有 ${recordings.size} 个录音文件：\n" +
                    recordings.take(10).joinToString("\n") { file ->
                        "🎤 ${file.name} (${file.length() / 1024} KB)"
                    }
                ToolResult(true, summary)
            }
        } catch (e: Exception) {
            ToolResult(false, "获取录音列表失败: ${e.message}")
        }
    }
}

// ==================== 联系人增强工具 ====================

class AddContactToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "add_contact",
        description = "添加新联系人",
        category = "通讯",
        parameters = listOf(
            ToolParameter("name", "string", "联系人姓名", required = true),
            ToolParameter("phone_number", "string", "电话号码", required = true),
            ToolParameter("email", "string", "邮箱地址", required = false)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val name = parameters["name"]?.jsonPrimitive?.content
                ?: return ToolResult(false, "缺少name参数")
            val phoneNumber = parameters["phone_number"]?.jsonPrimitive?.content
                ?: return ToolResult(false, "缺少phone_number参数")
            val email = parameters["email"]?.jsonPrimitive?.content
            
            val success = CommunicationManager.getInstance(context).addContact(name, phoneNumber, email)
            if (success) {
                ToolResult(true, "✅ 联系人已添加: $name ($phoneNumber)")
            } else {
                ToolResult(false, "添加联系人失败，可能需要权限")
            }
        } catch (e: Exception) {
            ToolResult(false, "添加联系人失败: ${e.message}")
        }
    }
}

class UpdateContactToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "update_contact",
        description = "更新联系人信息",
        category = "通讯",
        parameters = listOf(
            ToolParameter("contact_id", "string", "联系人ID", required = true),
            ToolParameter("name", "string", "新姓名", required = false),
            ToolParameter("phone_number", "string", "新电话号码", required = false),
            ToolParameter("email", "string", "新邮箱", required = false)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val contactId = parameters["contact_id"]?.jsonPrimitive?.content
                ?: return ToolResult(false, "缺少contact_id参数")
            val name = parameters["name"]?.jsonPrimitive?.content
            val phoneNumber = parameters["phone_number"]?.jsonPrimitive?.content
            val email = parameters["email"]?.jsonPrimitive?.content
            
            val success = CommunicationManager.getInstance(context)
                .updateContact(contactId, name, phoneNumber, email)
            if (success) {
                ToolResult(true, "✅ 联系人已更新")
            } else {
                ToolResult(false, "更新联系人失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "更新联系人失败: ${e.message}")
        }
    }
}

class DeleteContactToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "delete_contact",
        description = "删除联系人",
        category = "通讯",
        parameters = listOf(
            ToolParameter("contact_id", "string", "联系人ID", required = true)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val contactId = parameters["contact_id"]?.jsonPrimitive?.content
                ?: return ToolResult(false, "缺少contact_id参数")
            
            val success = CommunicationManager.getInstance(context).deleteContact(contactId)
            if (success) {
                ToolResult(true, "✅ 联系人已删除")
            } else {
                ToolResult(false, "删除联系人失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "删除联系人失败: ${e.message}")
        }
    }
}

// ==================== 蓝牙工具 ====================

class EnableBluetoothToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "enable_bluetooth",
        description = "开启蓝牙",
        category = "蓝牙",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val success = BluetoothManager.getInstance(context).enableBluetooth()
            if (success) {
                ToolResult(true, "✅ 蓝牙已开启")
            } else {
                ToolResult(false, "开启蓝牙失败，可能需要用户手动操作")
            }
        } catch (e: Exception) {
            ToolResult(false, "开启蓝牙失败: ${e.message}")
        }
    }
}

class DisableBluetoothToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "disable_bluetooth",
        description = "关闭蓝牙",
        category = "蓝牙",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val success = BluetoothManager.getInstance(context).disableBluetooth()
            if (success) {
                ToolResult(true, "✅ 蓝牙已关闭")
            } else {
                ToolResult(false, "关闭蓝牙失败，可能需要用户手动操作")
            }
        } catch (e: Exception) {
            ToolResult(false, "关闭蓝牙失败: ${e.message}")
        }
    }
}

class StartBluetoothDiscoveryToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "start_bluetooth_discovery",
        description = "开始扫描蓝牙设备",
        category = "蓝牙",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val success = BluetoothManager.getInstance(context).startDiscovery()
            if (success) {
                ToolResult(true, "🔍 开始扫描蓝牙设备")
            } else {
                ToolResult(false, "开始扫描失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "开始扫描失败: ${e.message}")
        }
    }
}

class GetBondedDevicesToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "get_bonded_bluetooth_devices",
        description = "获取已配对的蓝牙设备",
        category = "蓝牙",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val devices = BluetoothManager.getInstance(context).getBondedDevices()
            if (devices.isEmpty()) {
                ToolResult(true, "没有已配对的蓝牙设备")
            } else {
                val summary = "共有 ${devices.size} 个已配对设备：\n" +
                    devices.joinToString("\n") { device ->
                        "📱 ${device.name ?: "未知"} (${device.address})"
                    }
                ToolResult(true, summary)
            }
        } catch (e: Exception) {
            ToolResult(false, "获取已配对设备失败: ${e.message}")
        }
    }
}

// ==================== 数据统计工具 ====================

class GetAppUsageStatsToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "get_app_usage_stats",
        description = "获取应用使用统计",
        category = "数据分析",
        parameters = listOf(
            ToolParameter("days", "number", "统计天数，默认7天", required = false)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val days = parameters["days"]?.jsonPrimitive?.int ?: 7
            val stats = DataAnalyzer.getInstance(context).getAppUsageStats(days)
            
            if (stats.isEmpty()) {
                ToolResult(true, "没有应用使用数据")
            } else {
                val summary = "过去${days}天应用使用统计：\n" +
                    stats.take(10).joinToString("\n") { stat ->
                        "📱 ${stat.appName}: ${stat.getTotalTimeFormatted()}"
                    }
                ToolResult(true, summary)
            }
        } catch (e: Exception) {
            ToolResult(false, "获取应用使用统计失败: ${e.message}")
        }
    }
}

class GetScreenTimeStatsToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "get_screen_time_stats",
        description = "获取屏幕使用时间统计",
        category = "数据分析",
        parameters = listOf(
            ToolParameter("days", "number", "统计天数，默认7天", required = false)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val days = parameters["days"]?.jsonPrimitive?.int ?: 7
            val stats = DataAnalyzer.getInstance(context).getScreenTimeStats(days)
            
            val summary = "📊 屏幕使用时间统计（过去${days}天）\n" +
                "总计: ${stats.getTotalTimeFormatted()}\n" +
                "平均: ${stats.getAverageTimeFormatted()}/天\n\n" +
                "使用最多的应用：\n" +
                stats.topApps.joinToString("\n") { app ->
                    "📱 ${app.appName}: ${app.getTotalTimeFormatted()}"
                }
            ToolResult(true, summary)
        } catch (e: Exception) {
            ToolResult(false, "获取屏幕时间统计失败: ${e.message}")
        }
    }
}

class GetStorageInfoToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "get_storage_info",
        description = "获取存储空间信息",
        category = "数据分析",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val storage = DataAnalyzer.getInstance(context).getInternalStorageInfo()
            val summary = "💾 存储空间信息\n" +
                "总容量: ${storage.getTotalSpaceFormatted()}\n" +
                "已用: ${storage.getUsedSpaceFormatted()}\n" +
                "可用: ${storage.getFreeSpaceFormatted()}\n" +
                "使用率: ${"%.1f".format(storage.usagePercentage)}%"
            ToolResult(true, summary)
        } catch (e: Exception) {
            ToolResult(false, "获取存储信息失败: ${e.message}")
        }
    }
}

class GetMemoryInfoToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "get_memory_info",
        description = "获取内存信息",
        category = "数据分析",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val memory = DataAnalyzer.getInstance(context).getMemoryInfo()
            val totalGB = memory.totalRam / (1024.0 * 1024 * 1024)
            val availableGB = memory.availableRam / (1024.0 * 1024 * 1024)
            val usedGB = memory.usedRam / (1024.0 * 1024 * 1024)
            
            val summary = "🧠 内存信息\n" +
                "总容量: ${"%.2f".format(totalGB)} GB\n" +
                "已用: ${"%.2f".format(usedGB)} GB\n" +
                "可用: ${"%.2f".format(availableGB)} GB\n" +
                "使用率: ${"%.1f".format(memory.usagePercentage)}%\n" +
                "内存不足: ${if (memory.isLowMemory) "是" else "否"}"
            ToolResult(true, summary)
        } catch (e: Exception) {
            ToolResult(false, "获取内存信息失败: ${e.message}")
        }
    }
}

class GetNetworkStatsToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "get_network_stats",
        description = "获取网络流量统计",
        category = "数据分析",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val stats = DataAnalyzer.getInstance(context).getNetworkStats()
            val totalTraffic = stats.getTotalTraffic()
            
            val summary = "📊 网络流量统计\n" +
                "总流量: ${stats.getTotalTrafficFormatted()}\n" +
                "移动数据: ${DataAnalyzer.getInstance(context).formatSize(stats.mobileRxBytes + stats.mobileTxBytes)}\n" +
                "WiFi流量: ${DataAnalyzer.getInstance(context).formatSize(stats.wifiRxBytes + stats.wifiTxBytes)}"
            ToolResult(true, summary)
        } catch (e: Exception) {
            ToolResult(false, "获取网络统计失败: ${e.message}")
        }
    }
}

class GetSystemOverviewToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "get_system_overview",
        description = "获取系统概览（存储、内存、网络、应用使用）",
        category = "数据分析",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val overview = DataAnalyzer.getInstance(context).getSystemOverview()
            
            val summary = "📊 系统概览\n\n" +
                "💾 存储: ${overview.storage.getFreeSpaceFormatted()} 可用 / ${overview.storage.getTotalSpaceFormatted()}\n" +
                "🧠 内存: ${"%.1f".format(overview.memory.usagePercentage)}% 使用中\n" +
                "📊 流量: ${overview.network.getTotalTrafficFormatted()}\n\n" +
                "使用最多的应用：\n" +
                overview.topApps.take(5).joinToString("\n") { app ->
                    "📱 ${app.appName}: ${app.getTotalTimeFormatted()}"
                }
            ToolResult(true, summary)
        } catch (e: Exception) {
            ToolResult(false, "获取系统概览失败: ${e.message}")
        }
    }
}
