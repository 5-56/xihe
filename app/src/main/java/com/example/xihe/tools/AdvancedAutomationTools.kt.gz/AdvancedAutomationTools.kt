package com.example.xihe.tools

import android.content.Context
import com.example.xihe.search.UniversalSearchManager
import com.example.xihe.scripts.ScriptManager
import com.example.xihe.automation.RepeatActionManager
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.int
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject

// ==================== 搜索工具 ====================

class UniversalSearchToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "universal_search",
        description = "通用搜索功能，支持在Google、百度、淘宝、京东、B站等平台搜索",
        category = "搜索",
        parameters = listOf(
            ToolParameter("keyword", "string", "搜索关键词", required = true),
            ToolParameter("platform", "string", "搜索平台：google/baidu/taobao/jd/bilibili/wechat/douyin等", required = false)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val keyword = parameters["keyword"]?.jsonPrimitive?.content
                ?: return ToolResult(false, "缺少keyword参数")
            
            val platformStr = parameters["platform"]?.jsonPrimitive?.content ?: "baidu"
            val platform = when (platformStr.lowercase()) {
                "google" -> UniversalSearchManager.SearchPlatform.GOOGLE
                "baidu" -> UniversalSearchManager.SearchPlatform.BAIDU
                "taobao", "淘宝" -> UniversalSearchManager.SearchPlatform.TAOBAO
                "jd", "京东" -> UniversalSearchManager.SearchPlatform.JD
                "wechat", "微信" -> UniversalSearchManager.SearchPlatform.WECHAT
                "douyin", "抖音" -> UniversalSearchManager.SearchPlatform.DOUYIN
                "bilibili", "b站" -> UniversalSearchManager.SearchPlatform.BILIBILI
                "zhihu", "知乎" -> UniversalSearchManager.SearchPlatform.ZHIHU
                "weibo", "微博" -> UniversalSearchManager.SearchPlatform.WEIBO
                "xiaohongshu", "小红书" -> UniversalSearchManager.SearchPlatform.XIAOHONGSHU
                else -> UniversalSearchManager.SearchPlatform.BAIDU
            }
            
            val result = UniversalSearchManager.getInstance(context).search(platform, keyword)
            if (result.success) {
                ToolResult(true, "✅ ${result.message}")
            } else {
                ToolResult(false, result.message ?: "搜索失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "搜索失败: ${e.message}")
        }
    }
}

class SmartSearchToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "smart_search",
        description = "智能搜索，AI自动选择最合适的平台",
        category = "搜索",
        parameters = listOf(
            ToolParameter("keyword", "string", "搜索关键词", required = true),
            ToolParameter("context", "string", "上下文信息，帮助AI选择平台", required = false)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val keyword = parameters["keyword"]?.jsonPrimitive?.content
                ?: return ToolResult(false, "缺少keyword参数")
            val contextInfo = parameters["context"]?.jsonPrimitive?.content
            
            val result = UniversalSearchManager.getInstance(context).smartSearch(keyword, contextInfo)
            if (result.success) {
                ToolResult(true, "✅ ${result.message}")
            } else {
                ToolResult(false, result.message ?: "搜索失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "智能搜索失败: ${e.message}")
        }
    }
}

// ==================== 脚本工具 ====================

class CreateScriptToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "create_script",
        description = "创建自动化脚本",
        category = "脚本",
        parameters = listOf(
            ToolParameter("name", "string", "脚本名称", required = true),
            ToolParameter("description", "string", "脚本描述", required = false)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val name = parameters["name"]?.jsonPrimitive?.content
                ?: return ToolResult(false, "缺少name参数")
            val description = parameters["description"]?.jsonPrimitive?.content ?: ""
            
            val script = ScriptManager.getInstance(context).createScript(name, description)
            val saved = ScriptManager.getInstance(context).saveScript(script)
            
            if (saved) {
                ToolResult(true, "✅ 脚本已创建: $name (ID: ${script.id})")
            } else {
                ToolResult(false, "保存脚本失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "创建脚本失败: ${e.message}")
        }
    }
}

class ExecuteScriptToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "execute_script",
        description = "执行自动化脚本",
        category = "脚本",
        parameters = listOf(
            ToolParameter("script_id", "string", "脚本ID", required = true)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val scriptId = parameters["script_id"]?.jsonPrimitive?.content
                ?: return ToolResult(false, "缺少script_id参数")
            
            val script = ScriptManager.getInstance(context).loadScript(scriptId)
                ?: return ToolResult(false, "脚本不存在")
            
            val result = ScriptManager.getInstance(context).executeScript(script)
            if (result.success) {
                ToolResult(true, "✅ 脚本执行完成: ${result.executedActions}/${result.totalActions} 个动作")
            } else {
                ToolResult(false, result.errorMessage ?: "脚本执行失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "执行脚本失败: ${e.message}")
        }
    }
}

class ListScriptsToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "list_scripts",
        description = "列出所有脚本",
        category = "脚本",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val scripts = ScriptManager.getInstance(context).getAllScripts()
            if (scripts.isEmpty()) {
                ToolResult(true, "没有保存的脚本")
            } else {
                val summary = "共有 ${scripts.size} 个脚本：\n" +
                    scripts.joinToString("\n") { script ->
                        "📝 ${script.name} (${script.actions.size} 个动作) - ID: ${script.id}"
                    }
                ToolResult(true, summary)
            }
        } catch (e: Exception) {
            ToolResult(false, "获取脚本列表失败: ${e.message}")
        }
    }
}

class DeleteScriptToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "delete_script",
        description = "删除脚本",
        category = "脚本",
        parameters = listOf(
            ToolParameter("script_id", "string", "脚本ID", required = true)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val scriptId = parameters["script_id"]?.jsonPrimitive?.content
                ?: return ToolResult(false, "缺少script_id参数")
            
            val success = ScriptManager.getInstance(context).deleteScript(scriptId)
            if (success) {
                ToolResult(true, "✅ 脚本已删除")
            } else {
                ToolResult(false, "删除脚本失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "删除脚本失败: ${e.message}")
        }
    }
}

// ==================== 重复动作工具 ====================

class StartRecordingToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "start_recording",
        description = "开始录制操作动作",
        category = "重复动作",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            RepeatActionManager.getInstance(context).startRecording()
            ToolResult(true, "🎬 开始录制操作")
        } catch (e: Exception) {
            ToolResult(false, "开始录制失败: ${e.message}")
        }
    }
}

class StopRecordingToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "stop_recording",
        description = "停止录制操作动作",
        category = "重复动作",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val actions = RepeatActionManager.getInstance(context).stopRecording()
            ToolResult(true, "⏹️ 录制完成，共录制 ${actions.size} 个动作")
        } catch (e: Exception) {
            ToolResult(false, "停止录制失败: ${e.message}")
        }
    }
}

class RepeatActionsToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "repeat_actions",
        description = "重复执行已录制的动作",
        category = "重复动作",
        parameters = listOf(
            ToolParameter("count", "number", "重复次数", required = true),
            ToolParameter("delay", "number", "每次循环间隔（毫秒），默认1000", required = false)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val count = parameters["count"]?.jsonPrimitive?.int
                ?: return ToolResult(false, "缺少count参数")
            val delay = parameters["delay"]?.jsonPrimitive?.int?.toLong() ?: 1000L
            
            val actions = RepeatActionManager.getInstance(context).getRecordedActions()
            if (actions.isEmpty()) {
                return ToolResult(false, "没有录制的动作")
            }
            
            val result = RepeatActionManager.getInstance(context).repeatActions(
                actions, count, delay
            ) { current, total ->
                // 进度回调
            }
            
            if (result.success) {
                ToolResult(true, "✅ 重复执行完成: ${result.completedCycles}/${result.totalCycles} 个循环")
            } else {
                ToolResult(false, result.errorMessage ?: "重复执行失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "重复执行失败: ${e.message}")
        }
    }
}

class RepeatClickToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "repeat_click",
        description = "重复点击指定位置",
        category = "重复动作",
        parameters = listOf(
            ToolParameter("x", "number", "X坐标", required = true),
            ToolParameter("y", "number", "Y坐标", required = true),
            ToolParameter("count", "number", "点击次数", required = true),
            ToolParameter("interval", "number", "间隔毫秒数，默认500", required = false)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val x = parameters["x"]?.jsonPrimitive?.content?.toFloatOrNull()
                ?: return ToolResult(false, "缺少x参数")
            val y = parameters["y"]?.jsonPrimitive?.content?.toFloatOrNull()
                ?: return ToolResult(false, "缺少y参数")
            val count = parameters["count"]?.jsonPrimitive?.int
                ?: return ToolResult(false, "缺少count参数")
            val interval = parameters["interval"]?.jsonPrimitive?.int?.toLong() ?: 500L
            
            val result = RepeatActionManager.getInstance(context).repeatClick(
                x, y, count, interval
            )
            
            if (result.success) {
                ToolResult(true, "✅ 重复点击完成: ${result.executedActions} 次")
            } else {
                ToolResult(false, result.errorMessage ?: "重复点击失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "重复点击失败: ${e.message}")
        }
    }
}

class RepeatSwipeToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "repeat_swipe",
        description = "重复滑动",
        category = "重复动作",
        parameters = listOf(
            ToolParameter("start_x", "number", "起始X坐标", required = true),
            ToolParameter("start_y", "number", "起始Y坐标", required = true),
            ToolParameter("end_x", "number", "结束X坐标", required = true),
            ToolParameter("end_y", "number", "结束Y坐标", required = true),
            ToolParameter("count", "number", "滑动次数", required = true),
            ToolParameter("interval", "number", "间隔毫秒数，默认1000", required = false)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val startX = parameters["start_x"]?.jsonPrimitive?.content?.toFloatOrNull()
                ?: return ToolResult(false, "缺少start_x参数")
            val startY = parameters["start_y"]?.jsonPrimitive?.content?.toFloatOrNull()
                ?: return ToolResult(false, "缺少start_y参数")
            val endX = parameters["end_x"]?.jsonPrimitive?.content?.toFloatOrNull()
                ?: return ToolResult(false, "缺少end_x参数")
            val endY = parameters["end_y"]?.jsonPrimitive?.content?.toFloatOrNull()
                ?: return ToolResult(false, "缺少end_y参数")
            val count = parameters["count"]?.jsonPrimitive?.int
                ?: return ToolResult(false, "缺少count参数")
            val interval = parameters["interval"]?.jsonPrimitive?.int?.toLong() ?: 1000L
            
            val result = RepeatActionManager.getInstance(context).repeatSwipe(
                startX, startY, endX, endY, count, interval
            )
            
            if (result.success) {
                ToolResult(true, "✅ 重复滑动完成: ${result.executedActions} 次")
            } else {
                ToolResult(false, result.errorMessage ?: "重复滑动失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "重复滑动失败: ${e.message}")
        }
    }
}
