package com.example.xihe.tools

import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.intOrNull

/**
 * 🌍 生活 API 工具实现
 */

// ============ 📅 日期时间工具 ============

class GetDateTimeToolImpl : Tool() {
    override val definition = ToolDefinition(
        name = "get_datetime",
        description = "获取当前日期时间，包括公历、农历、星期等信息",
        category = "生活工具",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return LifeApiTools.getCurrentDateTime()
    }
}

class DaysBetweenToolImpl : Tool() {
    override val definition = ToolDefinition(
        name = "days_between",
        description = "计算两个日期之间的天数差",
        category = "生活工具",
        parameters = listOf(
            ToolParameter("start_date", "string", "开始日期（格式：yyyy-MM-dd）", true),
            ToolParameter("end_date", "string", "结束日期（格式：yyyy-MM-dd）", true)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        val startDate = parameters["start_date"]?.jsonPrimitive?.content ?: return ToolResult(false, "缺少开始日期")
        val endDate = parameters["end_date"]?.jsonPrimitive?.content ?: return ToolResult(false, "缺少结束日期")
        return LifeApiTools.calculateDaysBetween(startDate, endDate)
    }
}

// ============ 🌤️ 天气工具 ============

class GetWeatherToolImpl : Tool() {
    override val definition = ToolDefinition(
        name = "get_weather",
        description = "获取天气信息。如果不指定城市，则自动获取当前位置的天气",
        category = "生活工具",
        parameters = listOf(
            ToolParameter("city", "string", "城市名称（可选，不填则自动定位）", false)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        val city = parameters["city"]?.jsonPrimitive?.content
        return LifeApiTools.getWeatherWithAutoLocation(city)
    }
}

// ============ 📆 节假日工具 ============

class GetHolidayToolImpl : Tool() {
    override val definition = ToolDefinition(
        name = "get_holiday",
        description = "获取中国节假日信息，包括下一个节日和本月节日",
        category = "生活工具",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return LifeApiTools.getHolidayInfo()
    }
}

// ============ 🎲 随机工具 ============

class RandomNumberToolImpl : Tool() {
    override val definition = ToolDefinition(
        name = "random_number",
        description = "生成指定范围内的随机数",
        category = "生活工具",
        parameters = listOf(
            ToolParameter("min", "number", "最小值", true),
            ToolParameter("max", "number", "最大值", true)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        val min = parameters["min"]?.jsonPrimitive?.intOrNull ?: 1
        val max = parameters["max"]?.jsonPrimitive?.intOrNull ?: 100
        return LifeApiTools.generateRandomNumber(min, max)
    }
}

class FlipCoinToolImpl : Tool() {
    override val definition = ToolDefinition(
        name = "flip_coin",
        description = "抛硬币，返回正面或反面",
        category = "生活工具",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return LifeApiTools.flipCoin()
    }
}

class RollDiceToolImpl : Tool() {
    override val definition = ToolDefinition(
        name = "roll_dice",
        description = "掷骰子，返回1-6的随机数",
        category = "生活工具",
        parameters = listOf(
            ToolParameter("count", "number", "骰子数量（默认1个）", false)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        val count = parameters["count"]?.jsonPrimitive?.intOrNull ?: 1
        return LifeApiTools.rollDice(count)
    }
}

// ============ 📖 每日一句 ============

class DailyQuoteToolImpl : Tool() {
    override val definition = ToolDefinition(
        name = "daily_quote",
        description = "获取每日一句励志名言或鸡汤",
        category = "生活工具",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return LifeApiTools.getDailyQuote()
    }
}

// ============ 🔢 计算器 ============

class CalculatorToolImpl : Tool() {
    override val definition = ToolDefinition(
        name = "calculate",
        description = "简单数学计算，支持加减乘除",
        category = "生活工具",
        parameters = listOf(
            ToolParameter("expression", "string", "数学表达式（如：1+2*3）", true)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        val expression = parameters["expression"]?.jsonPrimitive?.content ?: return ToolResult(false, "请输入计算表达式")
        return LifeApiTools.calculate(expression)
    }
}

// ============ 🌐 网络工具 ============

class GetPublicIPToolImpl : Tool() {
    override val definition = ToolDefinition(
        name = "get_public_ip",
        description = "获取当前设备的公网IP地址",
        category = "生活工具",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return LifeApiTools.getPublicIP()
    }
}
