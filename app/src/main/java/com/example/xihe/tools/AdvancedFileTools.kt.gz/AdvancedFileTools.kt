package com.example.xihe.tools

import android.content.Context
import kotlinx.serialization.json.*
import java.io.File

/**
 * 搜索文件工具
 */
class SearchFilesToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "search_files",
        description = "在指定目录中搜索文件名匹配的文件。",
        category = "file",
        parameters = listOf(
            ToolParameter(
                name = "directory",
                description = "搜索的目录路径",
                type = "string",
                required = true
            ),
            ToolParameter(
                name = "pattern",
                description = "文件名匹配模式（支持通配符*）",
                type = "string",
                required = true
            ),
            ToolParameter(
                name = "recursive",
                description = "是否递归搜索子目录（默认true）",
                type = "boolean",
                required = false
            )
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        validateParameters(parameters)?.let { return it }
        
        return try {
            val directory = parameters["directory"]?.jsonPrimitive?.content ?: return ToolResult(
                success = false,
                message = "目录参数为空",
                error = "INVALID_DIRECTORY"
            )
            
            val pattern = parameters["pattern"]?.jsonPrimitive?.content ?: return ToolResult(
                success = false,
                message = "搜索模式为空",
                error = "INVALID_PATTERN"
            )
            
            val recursive = parameters["recursive"]?.jsonPrimitive?.booleanOrNull ?: true
            
            val dir = resolveFile(directory)
            
            if (!dir.exists()) {
                return ToolResult(
                    success = false,
                    message = "目录不存在: $directory",
                    error = "DIR_NOT_FOUND"
                )
            }
            
            if (!dir.isDirectory) {
                return ToolResult(
                    success = false,
                    message = "路径不是目录: $directory",
                    error = "NOT_A_DIRECTORY"
                )
            }
            
            val regex = pattern.replace("*", ".*").toRegex()
            val results = searchFiles(dir, regex, recursive)
            
            val filesJson = results.map { file ->
                buildJsonObject {
                    put("name", file.name)
                    put("path", file.absolutePath)
                    put("size", file.length())
                    put("isDirectory", file.isDirectory)
                }
            }
            
            ToolResult(
                success = true,
                message = "找到 ${results.size} 个匹配的文件",
                data = buildJsonObject {
                    put("matches", JsonArray(filesJson))
                    put("count", results.size)
                }
            )
        } catch (e: Exception) {
            ToolResult(
                success = false,
                message = "搜索失败: ${e.message}",
                error = "SEARCH_ERROR"
            )
        }
    }
    
    private fun searchFiles(dir: File, pattern: Regex, recursive: Boolean): List<File> {
        val results = mutableListOf<File>()
        
        dir.listFiles()?.forEach { file ->
            if (pattern.matches(file.name)) {
                results.add(file)
            }
            
            if (recursive && file.isDirectory) {
                results.addAll(searchFiles(file, pattern, recursive))
            }
        }
        
        return results
    }
    
    private fun resolveFile(path: String): File {
        return if (path.startsWith("/")) {
            File(path)
        } else {
            File(context.filesDir, path)
        }
    }
}

/**
 * 复制文件工具
 */
class CopyFileToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "copy_file",
        description = "复制文件或目录到新位置。",
        category = "file",
        parameters = listOf(
            ToolParameter(
                name = "source",
                description = "源文件路径",
                type = "string",
                required = true
            ),
            ToolParameter(
                name = "destination",
                description = "目标路径",
                type = "string",
                required = true
            ),
            ToolParameter(
                name = "overwrite",
                description = "如果目标存在是否覆盖（默认false）",
                type = "boolean",
                required = false
            )
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        validateParameters(parameters)?.let { return it }
        
        return try {
            val source = parameters["source"]?.jsonPrimitive?.content ?: return ToolResult(
                success = false,
                message = "源路径为空",
                error = "INVALID_SOURCE"
            )
            
            val destination = parameters["destination"]?.jsonPrimitive?.content ?: return ToolResult(
                success = false,
                message = "目标路径为空",
                error = "INVALID_DESTINATION"
            )
            
            val overwrite = parameters["overwrite"]?.jsonPrimitive?.booleanOrNull ?: false
            
            val sourceFile = resolveFile(source)
            val destFile = resolveFile(destination)
            
            if (!sourceFile.exists()) {
                return ToolResult(
                    success = false,
                    message = "源文件不存在: $source",
                    error = "SOURCE_NOT_FOUND"
                )
            }
            
            if (destFile.exists() && !overwrite) {
                return ToolResult(
                    success = false,
                    message = "目标已存在且未设置覆盖",
                    error = "DESTINATION_EXISTS"
                )
            }
            
            // 确保目标目录存在
            destFile.parentFile?.mkdirs()
            
            sourceFile.copyTo(destFile, overwrite = overwrite)
            
            ToolResult(
                success = true,
                message = "文件复制成功",
                data = buildJsonObject {
                    put("source", sourceFile.absolutePath)
                    put("destination", destFile.absolutePath)
                    put("size", destFile.length())
                }
            )
        } catch (e: Exception) {
            ToolResult(
                success = false,
                message = "复制失败: ${e.message}",
                error = "COPY_ERROR"
            )
        }
    }
    
    private fun resolveFile(path: String): File {
        return if (path.startsWith("/")) {
            File(path)
        } else {
            File(context.filesDir, path)
        }
    }
}

/**
 * 移动文件工具
 */
class MoveFileToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "move_file",
        description = "移动或重命名文件。",
        category = "file",
        parameters = listOf(
            ToolParameter(
                name = "source",
                description = "源文件路径",
                type = "string",
                required = true
            ),
            ToolParameter(
                name = "destination",
                description = "目标路径",
                type = "string",
                required = true
            )
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        validateParameters(parameters)?.let { return it }
        
        return try {
            val source = parameters["source"]?.jsonPrimitive?.content ?: return ToolResult(
                success = false,
                message = "源路径为空",
                error = "INVALID_SOURCE"
            )
            
            val destination = parameters["destination"]?.jsonPrimitive?.content ?: return ToolResult(
                success = false,
                message = "目标路径为空",
                error = "INVALID_DESTINATION"
            )
            
            val sourceFile = resolveFile(source)
            val destFile = resolveFile(destination)
            
            if (!sourceFile.exists()) {
                return ToolResult(
                    success = false,
                    message = "源文件不存在: $source",
                    error = "SOURCE_NOT_FOUND"
                )
            }
            
            // 确保目标目录存在
            destFile.parentFile?.mkdirs()
            
            val success = sourceFile.renameTo(destFile)
            
            if (success) {
                ToolResult(
                    success = true,
                    message = "文件移动成功",
                    data = buildJsonObject {
                        put("oldPath", sourceFile.absolutePath)
                        put("newPath", destFile.absolutePath)
                    }
                )
            } else {
                ToolResult(
                    success = false,
                    message = "移动失败",
                    error = "MOVE_FAILED"
                )
            }
        } catch (e: Exception) {
            ToolResult(
                success = false,
                message = "移动失败: ${e.message}",
                error = "MOVE_ERROR"
            )
        }
    }
    
    private fun resolveFile(path: String): File {
        return if (path.startsWith("/")) {
            File(path)
        } else {
            File(context.filesDir, path)
        }
    }
}

/**
 * 创建目录工具
 */
class CreateDirectoryToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "create_directory",
        description = "创建新目录（包括所有必需的父目录）。",
        category = "file",
        parameters = listOf(
            ToolParameter(
                name = "path",
                description = "要创建的目录路径",
                type = "string",
                required = true
            )
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        validateParameters(parameters)?.let { return it }
        
        return try {
            val path = parameters["path"]?.jsonPrimitive?.content ?: return ToolResult(
                success = false,
                message = "路径参数为空",
                error = "INVALID_PATH"
            )
            
            val dir = resolveFile(path)
            
            if (dir.exists()) {
                if (dir.isDirectory) {
                    return ToolResult(
                        success = true,
                        message = "目录已存在",
                        data = buildJsonObject {
                            put("path", dir.absolutePath)
                        }
                    )
                } else {
                    return ToolResult(
                        success = false,
                        message = "路径已存在但不是目录",
                        error = "NOT_A_DIRECTORY"
                    )
                }
            }
            
            val created = dir.mkdirs()
            
            if (created) {
                ToolResult(
                    success = true,
                    message = "目录创建成功",
                    data = buildJsonObject {
                        put("path", dir.absolutePath)
                    }
                )
            } else {
                ToolResult(
                    success = false,
                    message = "目录创建失败",
                    error = "CREATE_FAILED"
                )
            }
        } catch (e: Exception) {
            ToolResult(
                success = false,
                message = "创建目录失败: ${e.message}",
                error = "CREATE_ERROR"
            )
        }
    }
    
    private fun resolveFile(path: String): File {
        return if (path.startsWith("/")) {
            File(path)
        } else {
            File(context.filesDir, path)
        }
    }
}

/**
 * 获取文件信息工具
 */
class GetFileInfoToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "get_file_info",
        description = "获取文件或目录的详细信息。",
        category = "file",
        parameters = listOf(
            ToolParameter(
                name = "path",
                description = "文件或目录路径",
                type = "string",
                required = true
            )
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        validateParameters(parameters)?.let { return it }
        
        return try {
            val path = parameters["path"]?.jsonPrimitive?.content ?: return ToolResult(
                success = false,
                message = "路径参数为空",
                error = "INVALID_PATH"
            )
            
            val file = resolveFile(path)
            
            if (!file.exists()) {
                return ToolResult(
                    success = false,
                    message = "文件不存在: $path",
                    error = "FILE_NOT_FOUND"
                )
            }
            
            ToolResult(
                success = true,
                message = "文件信息获取成功",
                data = buildJsonObject {
                    put("name", file.name)
                    put("path", file.absolutePath)
                    put("size", file.length())
                    put("isDirectory", file.isDirectory)
                    put("isFile", file.isFile)
                    put("canRead", file.canRead())
                    put("canWrite", file.canWrite())
                    put("lastModified", file.lastModified())
                    put("parent", file.parent ?: "")
                }
            )
        } catch (e: Exception) {
            ToolResult(
                success = false,
                message = "获取信息失败: ${e.message}",
                error = "INFO_ERROR"
            )
        }
    }
    
    private fun resolveFile(path: String): File {
        return if (path.startsWith("/")) {
            File(path)
        } else {
            File(context.filesDir, path)
        }
    }
}
