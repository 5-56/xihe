package com.example.xihe.tools

import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.scenarios.*
import com.example.xihe.scenarios.games.*
import kotlinx.serialization.json.*

/**
 * 📹 刷视频工具
 */
class VideoSwipeToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "video_swipe",
        description = "自动刷视频，支持抖音、快手、B站、小红书等平台。可配置滑动次数和停留时间。",
        category = "automation",
        parameters = listOf(
            ToolParameter("app", "string", "视频App名称：抖音/快手/B站/小红书/YouTube", false),
            ToolParameter("count", "integer", "滑动次数，默认50", false),
            ToolParameter("min_stay", "integer", "最小停留秒数，默认3", false),
            ToolParameter("max_stay", "integer", "最大停留秒数，默认15", false)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        val appName = parameters["app"]?.jsonPrimitive?.contentOrNull ?: "抖音"
        val count = parameters["count"]?.jsonPrimitive?.intOrNull ?: 50
        val minStay = parameters["min_stay"]?.jsonPrimitive?.intOrNull ?: 3
        val maxStay = parameters["max_stay"]?.jsonPrimitive?.intOrNull ?: 15
        
        LogManager.d("VideoSwipeTool", "开始刷视频: $appName, 次数=$count")
        
        val scenario = VideoSwipeScenario(context)
        val config = VideoSwipeScenario.VideoSwipeConfig(
            appName = appName,
            swipeCount = count,
            minStaySeconds = minStay,
            maxStaySeconds = maxStay
        )
        
        return try {
            val result = scenario.start(config)
            when (result) {
                is ScenarioResult.Success -> ToolResult(true, result.message)
                is ScenarioResult.PartialSuccess -> ToolResult(true, result.message)
                is ScenarioResult.Failure -> ToolResult(false, result.message, error = "EXECUTION_FAILED")
                is ScenarioResult.Stopped -> ToolResult(true, result.message)
            }
        } catch (e: Exception) {
            LogManager.e("VideoSwipeTool", "执行失败", e)
            ToolResult(false, "刷视频失败: ${e.message}", error = "ERROR")
        }
    }
}

/**
 * 📝 填数据工具
 */
class FormFillerToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "form_filler",
        description = "自动填充表单数据。支持单条填充或批量导入。",
        category = "automation",
        parameters = listOf(
            ToolParameter("fields", "object", "要填充的字段和值，格式：{\"字段提示1\": \"值1\", \"字段提示2\": \"值2\"}", true),
            ToolParameter("submit", "boolean", "填完后是否自动提交，默认false", false),
            ToolParameter("confirm", "boolean", "提交前是否需要确认，默认true", false)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        val fieldsJson = parameters["fields"]?.jsonObject
        if (fieldsJson == null) {
            return ToolResult(false, "缺少必要参数: fields", error = "MISSING_PARAM")
        }
        
        val submit = parameters["submit"]?.jsonPrimitive?.booleanOrNull ?: false
        val confirm = parameters["confirm"]?.jsonPrimitive?.booleanOrNull ?: true
        
        // 解析字段
        val fields = mutableMapOf<String, String>()
        fieldsJson.forEach { (key, value) ->
            fields[key] = value.jsonPrimitive.content
        }
        
        // 构建字段映射
        val mappings = fields.keys.map { hint ->
            FormFillerScenario.FieldMapping(
                sourceField = hint,
                targetHint = hint
            )
        }
        
        LogManager.d("FormFillerTool", "开始填充表单: ${fields.size} 个字段")
        
        val scenario = FormFillerScenario(context)
        val config = FormFillerScenario.FormFillerConfig(
            dataSource = FormFillerScenario.DataSource.Manual(fields),
            fieldMappings = mappings,
            submitAfterFill = submit,
            confirmBeforeFormSubmit = confirm
        )
        
        return try {
            val result = scenario.start(config)
            when (result) {
                is ScenarioResult.Success -> ToolResult(true, result.message)
                is ScenarioResult.PartialSuccess -> ToolResult(true, result.message)
                is ScenarioResult.Failure -> ToolResult(false, result.message, error = "EXECUTION_FAILED")
                is ScenarioResult.Stopped -> ToolResult(true, result.message)
            }
        } catch (e: Exception) {
            LogManager.e("FormFillerTool", "执行失败", e)
            ToolResult(false, "填充表单失败: ${e.message}", error = "ERROR")
        }
    }
}

/**
 * 🎮 游戏自动化工具
 */
class GameAutomationToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "game_automation",
        description = "游戏自动化操作。支持循环点击、多点点击、滑动等操作。仅限单机/放置类游戏辅助。",
        category = "automation",
        parameters = listOf(
            ToolParameter("action", "string", "动作类型：tap/long_press/swipe/multi_tap", true),
            ToolParameter("x", "number", "X坐标（0-1相对坐标或绝对像素）", false),
            ToolParameter("y", "number", "Y坐标（0-1相对坐标或绝对像素）", false),
            ToolParameter("points", "array", "多点点击时的坐标数组，格式：[[x1,y1], [x2,y2]]", false),
            ToolParameter("count", "integer", "循环次数，默认100", false),
            ToolParameter("interval", "integer", "间隔毫秒数，默认1000", false),
            ToolParameter("relative", "boolean", "是否使用相对坐标(0-1)，默认true", false)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        val action = parameters["action"]?.jsonPrimitive?.contentOrNull ?: "tap"
        val x = parameters["x"]?.jsonPrimitive?.floatOrNull ?: 0.5f
        val y = parameters["y"]?.jsonPrimitive?.floatOrNull ?: 0.5f
        val count = parameters["count"]?.jsonPrimitive?.intOrNull ?: 100
        val interval = parameters["interval"]?.jsonPrimitive?.longOrNull ?: 1000L
        val relative = parameters["relative"]?.jsonPrimitive?.booleanOrNull ?: true
        
        LogManager.d("GameAutomationTool", "开始游戏自动化: action=$action, ($x,$y), 次数=$count")
        
        val scenario = GameAutomationScenario(context)
        
        val config = when (action.lowercase()) {
            "tap" -> {
                GameAutomationScenario.MacroTemplates.simpleLoopTap(x, y, relative, interval, count)
            }
            "multi_tap" -> {
                val pointsJson = parameters["points"]?.jsonArray
                val points = if (pointsJson != null) {
                    pointsJson.mapNotNull { point ->
                        val arr = point.jsonArray
                        if (arr.size >= 2) {
                            arr[0].jsonPrimitive.float to arr[1].jsonPrimitive.float
                        } else null
                    }
                } else {
                    listOf(x to y)
                }
                GameAutomationScenario.MacroTemplates.multiPointTap(points, relative, interval, count)
            }
            "long_press" -> {
                val duration = parameters["duration"]?.jsonPrimitive?.longOrNull ?: 1000L
                GameAutomationScenario.GameConfig(
                    actions = listOf(
                        GameAutomationScenario.GameAction.LongPress(x, y, relative, duration, interval)
                    ),
                    loopCount = count
                )
            }
            "swipe" -> {
                val endX = parameters["end_x"]?.jsonPrimitive?.floatOrNull ?: (x + 0.2f)
                val endY = parameters["end_y"]?.jsonPrimitive?.floatOrNull ?: y
                GameAutomationScenario.GameConfig(
                    actions = listOf(
                        GameAutomationScenario.GameAction.Swipe(x, y, endX, endY, relative, 300, interval)
                    ),
                    loopCount = count
                )
            }
            else -> {
                return ToolResult(false, "不支持的动作类型: $action", error = "INVALID_ACTION")
            }
        }
        
        return try {
            val result = scenario.start(config)
            when (result) {
                is ScenarioResult.Success -> ToolResult(true, result.message)
                is ScenarioResult.PartialSuccess -> ToolResult(true, result.message)
                is ScenarioResult.Failure -> ToolResult(false, result.message, error = "EXECUTION_FAILED")
                is ScenarioResult.Stopped -> ToolResult(true, result.message)
            }
        } catch (e: Exception) {
            LogManager.e("GameAutomationTool", "执行失败", e)
            ToolResult(false, "游戏自动化失败: ${e.message}", error = "ERROR")
        }
    }
}

/**
 * ⚫⚪ 五子棋工具
 */
class GomokuToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "gomoku",
        description = "五子棋自动下棋。AI会识别棋盘并计算最优落子位置。",
        category = "game",
        parameters = listOf(
            ToolParameter("play_as", "string", "执黑棋还是白棋：black/white，默认black", false),
            ToolParameter("difficulty", "string", "难度：easy/normal/hard，默认normal", false),
            ToolParameter("app_package", "string", "五子棋App包名（可选）", false)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        val playAsStr = parameters["play_as"]?.jsonPrimitive?.contentOrNull ?: "black"
        val difficulty = parameters["difficulty"]?.jsonPrimitive?.contentOrNull ?: "normal"
        val appPackage = parameters["app_package"]?.jsonPrimitive?.contentOrNull
        
        val playAs = if (playAsStr.lowercase() == "white") GomokuScenario.WHITE else GomokuScenario.BLACK
        val depth = when (difficulty.lowercase()) {
            "easy" -> 2
            "hard" -> 6
            else -> 4
        }
        
        LogManager.d("GomokuTool", "开始五子棋: 执${if (playAs == GomokuScenario.BLACK) "黑" else "白"}, 难度=$difficulty")
        
        val scenario = GomokuScenario(context)
        val config = GomokuScenario.GomokuConfig(
            appPackage = appPackage,
            playAs = playAs,
            searchDepth = depth
        )
        
        return try {
            val result = scenario.start(config)
            when (result) {
                is ScenarioResult.Success -> ToolResult(true, result.message)
                is ScenarioResult.PartialSuccess -> ToolResult(true, result.message)
                is ScenarioResult.Failure -> ToolResult(false, result.message, error = "EXECUTION_FAILED")
                is ScenarioResult.Stopped -> ToolResult(true, result.message)
            }
        } catch (e: Exception) {
            LogManager.e("GomokuTool", "执行失败", e)
            ToolResult(false, "五子棋失败: ${e.message}", error = "ERROR")
        }
    }
}

/**
 * 🃏 斗地主工具
 */
class DouDiZhuToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "doudizhu",
        description = "斗地主自动出牌。AI会识别手牌并计算最优出牌策略。",
        category = "game",
        parameters = listOf(
            ToolParameter("app", "string", "斗地主App名称：欢乐斗地主/QQ斗地主/途游斗地主，默认欢乐斗地主", false),
            ToolParameter("auto_grab", "boolean", "是否自动抢地主，默认true", false),
            ToolParameter("style", "string", "出牌风格：aggressive/balanced/conservative，默认balanced", false),
            ToolParameter("rounds", "integer", "对局数，默认10", false)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        val appName = parameters["app"]?.jsonPrimitive?.contentOrNull ?: "欢乐斗地主"
        val autoGrab = parameters["auto_grab"]?.jsonPrimitive?.booleanOrNull ?: true
        val styleStr = parameters["style"]?.jsonPrimitive?.contentOrNull ?: "balanced"
        val rounds = parameters["rounds"]?.jsonPrimitive?.intOrNull ?: 10
        
        val style = when (styleStr.lowercase()) {
            "aggressive" -> DouDiZhuScenario.PlayStyle.AGGRESSIVE
            "conservative" -> DouDiZhuScenario.PlayStyle.CONSERVATIVE
            else -> DouDiZhuScenario.PlayStyle.BALANCED
        }
        
        LogManager.d("DouDiZhuTool", "开始斗地主: App=$appName, 自动抢=$autoGrab, 风格=$style")
        
        val scenario = DouDiZhuScenario(context)
        val config = DouDiZhuScenario.DouDiZhuConfig(
            appName = appName,
            autoGrab = autoGrab,
            playStyle = style,
            maxRounds = rounds
        )
        
        return try {
            val result = scenario.start(config)
            when (result) {
                is ScenarioResult.Success -> ToolResult(true, result.message)
                is ScenarioResult.PartialSuccess -> ToolResult(true, result.message)
                is ScenarioResult.Failure -> ToolResult(false, result.message, error = "EXECUTION_FAILED")
                is ScenarioResult.Stopped -> ToolResult(true, result.message)
            }
        } catch (e: Exception) {
            LogManager.e("DouDiZhuTool", "执行失败", e)
            ToolResult(false, "斗地主失败: ${e.message}", error = "ERROR")
        }
    }
}

/**
 * 🤖 通用游戏AI工具
 */
class GameAIToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "game_ai",
        description = "通用游戏AI，使用视觉分析自动操作游戏。适用于回合制、放置、卡牌、模拟经营等游戏。⚠️不推荐用于有反作弊的网游。",
        category = "game",
        parameters = listOf(
            ToolParameter("game_package", "string", "游戏包名（可选，用于启动游戏）", false),
            ToolParameter("game_type", "string", "游戏类型：turn_based/idle/card/simulation/mmorpg，默认auto", false),
            ToolParameter("objective", "string", "目标描述，如'自动打怪'、'完成日常'等", false),
            ToolParameter("max_steps", "integer", "最大操作步数，默认500", false),
            ToolParameter("use_vision_ai", "boolean", "是否使用视觉AI分析，默认true", false)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        val gamePackage = parameters["game_package"]?.jsonPrimitive?.contentOrNull
        val gameTypeStr = parameters["game_type"]?.jsonPrimitive?.contentOrNull ?: "custom"
        val objective = parameters["objective"]?.jsonPrimitive?.contentOrNull ?: "按照游戏提示自动操作"
        val maxSteps = parameters["max_steps"]?.jsonPrimitive?.intOrNull ?: 500
        val useVisionAI = parameters["use_vision_ai"]?.jsonPrimitive?.booleanOrNull ?: true
        
        val gameType = when (gameTypeStr.lowercase()) {
            "turn_based" -> GameAIScenario.Companion.GameType.TURN_BASED
            "idle" -> GameAIScenario.Companion.GameType.IDLE
            "card" -> GameAIScenario.Companion.GameType.CARD
            "simulation" -> GameAIScenario.Companion.GameType.SIMULATION
            "mmorpg" -> GameAIScenario.Companion.GameType.MMORPG
            else -> GameAIScenario.Companion.GameType.CUSTOM
        }
        
        LogManager.d("GameAITool", "开始游戏AI: 类型=$gameType, 目标=$objective")
        
        val scenario = GameAIScenario(context)
        val config = GameAIScenario.GameAIConfig(
            gamePackage = gamePackage,
            gameType = gameType,
            objective = objective,
            maxSteps = maxSteps,
            useVisionAI = useVisionAI
        )
        
        return try {
            val result = scenario.start(config)
            when (result) {
                is ScenarioResult.Success -> ToolResult(true, result.message)
                is ScenarioResult.PartialSuccess -> ToolResult(true, result.message)
                is ScenarioResult.Failure -> ToolResult(false, result.message, error = "EXECUTION_FAILED")
                is ScenarioResult.Stopped -> ToolResult(true, result.message)
            }
        } catch (e: Exception) {
            LogManager.e("GameAITool", "执行失败", e)
            ToolResult(false, "游戏AI失败: ${e.message}", error = "ERROR")
        }
    }
}
