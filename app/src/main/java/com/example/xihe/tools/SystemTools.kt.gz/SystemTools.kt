package com.example.xihe.tools

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import kotlinx.serialization.json.*

/**
 * 获取设备信息工具
 */
class GetDeviceInfoToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "get_device_info",
        description = "获取设备的详细信息（型号、系统版本、存储等）。",
        category = "system",
        parameters = listOf()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val info = buildJsonObject {
                put("manufacturer", Build.MANUFACTURER)
                put("model", Build.MODEL)
                put("brand", Build.BRAND)
                put("device", Build.DEVICE)
                put("androidVersion", Build.VERSION.RELEASE)
                put("sdkVersion", Build.VERSION.SDK_INT)
                put("packageName", context.packageName)
                
                // 存储信息
                val filesDir = context.filesDir
                put("appDataPath", filesDir.absolutePath)
                put("availableStorage", filesDir.usableSpace)
                put("totalStorage", filesDir.totalSpace)
            }
            
            ToolResult(
                success = true,
                message = "设备信息获取成功",
                data = info
            )
        } catch (e: Exception) {
            ToolResult(
                success = false,
                message = "获取设备信息失败: ${e.message}",
                error = "INFO_ERROR"
            )
        }
    }
}

/**
 * 获取已安装应用列表工具
 */
class GetInstalledAppsToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "get_installed_apps",
        description = "获取设备上已安装的应用列表。",
        category = "system",
        parameters = listOf(
            ToolParameter(
                name = "systemApps",
                description = "是否包含系统应用（默认false）",
                type = "boolean",
                required = false
            )
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val includeSystem = parameters["systemApps"]?.jsonPrimitive?.booleanOrNull ?: false
            val pm = context.packageManager
            
            val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            val apps = packages
                .filter { app ->
                    includeSystem || (app.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) == 0
                }
                .map { app ->
                    buildJsonObject {
                        put("packageName", app.packageName)
                        put("name", app.loadLabel(pm).toString())
                        put("isSystemApp", (app.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0)
                    }
                }
            
            ToolResult(
                success = true,
                message = "找到 ${apps.size} 个应用",
                data = buildJsonObject {
                    put("apps", JsonArray(apps))
                    put("count", apps.size)
                }
            )
        } catch (e: Exception) {
            ToolResult(
                success = false,
                message = "获取应用列表失败: ${e.message}",
                error = "LIST_ERROR"
            )
        }
    }
}

/**
 * 启动应用工具 (智能升级版 🚀)
 */
class LaunchAppToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "launch_app",
        description = "启动指定的应用程序。支持直接使用应用名称（如 '微信', 'Camera'）进行模糊匹配，也支持使用包名。",
        category = "system",
        parameters = listOf(
            ToolParameter(
                name = "appNameOrPackage",
                description = "应用名称或包名",
                type = "string",
                required = true
            )
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        validateParameters(parameters)?.let { return it }
        
        return try {
            val input = parameters["appNameOrPackage"]?.jsonPrimitive?.content ?: // 兼容旧参数名
                       parameters["packageName"]?.jsonPrimitive?.content
            
            if (input.isNullOrEmpty()) {
                return ToolResult(false, "应用名称参数为空")
            }
            
            val pm = context.packageManager
            
            // 1. 尝试直接作为包名启动
            var intent = pm.getLaunchIntentForPackage(input)
            var targetPackage = input
            
            // 2. 如果失败，尝试作为应用名进行模糊搜索 🔍
            if (intent == null) {
                val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
                val lowerInput = input.lowercase()
                
                // 策略A: 精确匹配名称
                var bestMatch = installedApps.find { 
                    it.loadLabel(pm).toString().lowercase() == lowerInput 
                }
                
                // 策略B: 包含匹配
                if (bestMatch == null) {
                    bestMatch = installedApps.find { 
                        it.loadLabel(pm).toString().lowercase().contains(lowerInput) 
                    }
                }
                
                if (bestMatch != null) {
                    targetPackage = bestMatch.packageName
                    intent = pm.getLaunchIntentForPackage(targetPackage)
                }
            }
            
            if (intent == null) {
                return ToolResult(
                    success = false,
                    message = "未找到名为 '$input' 的应用，也无法作为包名启动。",
                    error = "APP_NOT_FOUND"
                )
            }
            
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            
            ToolResult(
                success = true,
                message = "已启动应用: $targetPackage",
                data = buildJsonObject {
                    put("packageName", targetPackage)
                    put("input", input)
                }
            )
        } catch (e: Exception) {
            ToolResult(
                success = false,
                message = "启动应用失败: ${e.message}",
                error = "LAUNCH_ERROR"
            )
        }
    }
}

/**
 * 打开URL工具
 */
class OpenUrlToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "open_url",
        description = "在浏览器中打开指定的URL。",
        category = "system",
        parameters = listOf(
            ToolParameter(
                name = "url",
                description = "要打开的URL地址",
                type = "string",
                required = true
            )
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        validateParameters(parameters)?.let { return it }
        
        return try {
            val url = parameters["url"]?.jsonPrimitive?.content ?: return ToolResult(
                success = false,
                message = "URL参数为空",
                error = "INVALID_URL"
            )
            
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            
            ToolResult(
                success = true,
                message = "已在浏览器中打开: $url",
                data = buildJsonObject {
                    put("url", url)
                }
            )
        } catch (e: Exception) {
            ToolResult(
                success = false,
                message = "打开URL失败: ${e.message}",
                error = "OPEN_ERROR"
            )
        }
    }
}

/**
 * 剪贴板工具 - 读取
 */
class GetClipboardToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "get_clipboard",
        description = "读取系统剪贴板的内容。",
        category = "system",
        parameters = listOf()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = clipboard.primaryClip
            
            if (clip == null || clip.itemCount == 0) {
                return ToolResult(
                    success = true,
                    message = "剪贴板为空",
                    data = buildJsonObject {
                        put("content", "")
                        put("isEmpty", true)
                    }
                )
            }
            
            val item = clip.getItemAt(0)
            val text = item.text?.toString() ?: ""
            
            ToolResult(
                success = true,
                message = "剪贴板内容读取成功",
                data = buildJsonObject {
                    put("content", text)
                    put("isEmpty", false)
                }
            )
        } catch (e: Exception) {
            ToolResult(
                success = false,
                message = "读取剪贴板失败: ${e.message}",
                error = "READ_ERROR"
            )
        }
    }
}

/**
 * 剪贴板工具 - 写入
 */
class SetClipboardToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "set_clipboard",
        description = "将文本内容复制到系统剪贴板。",
        category = "system",
        parameters = listOf(
            ToolParameter(
                name = "text",
                description = "要复制的文本内容",
                type = "string",
                required = true
            )
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        validateParameters(parameters)?.let { return it }
        
        return try {
            val text = parameters["text"]?.jsonPrimitive?.content ?: return ToolResult(
                success = false,
                message = "文本参数为空",
                error = "INVALID_TEXT"
            )
            
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("羲和复制", text)
            clipboard.setPrimaryClip(clip)
            
            ToolResult(
                success = true,
                message = "内容已复制到剪贴板",
                data = buildJsonObject {
                    put("text", text)
                    put("length", text.length)
                }
            )
        } catch (e: Exception) {
            ToolResult(
                success = false,
                message = "复制到剪贴板失败: ${e.message}",
                error = "COPY_ERROR"
            )
        }
    }
}

/**
 * 打开系统设置工具
 */
class OpenSettingsToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "open_settings",
        description = "打开系统设置页面。",
        category = "system",
        parameters = listOf(
            ToolParameter(
                name = "type",
                description = "设置类型：wifi, bluetooth, location, app_settings, accessibility等",
                type = "string",
                required = false
            )
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val type = parameters["type"]?.jsonPrimitive?.content ?: "settings"
            
            val action = when (type.lowercase()) {
                "wifi" -> Settings.ACTION_WIFI_SETTINGS
                "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                "app_settings" -> Settings.ACTION_APPLICATION_SETTINGS
                "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
                else -> Settings.ACTION_SETTINGS
            }
            
            val intent = Intent(action)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            
            ToolResult(
                success = true,
                message = "已打开${type}设置",
                data = buildJsonObject {
                    put("type", type)
                }
            )
        } catch (e: Exception) {
            ToolResult(
                success = false,
                message = "打开设置失败: ${e.message}",
                error = "OPEN_ERROR"
            )
        }
    }
}

/**
 * 截图工具 📸
 * ⚠️ 限制：仅支持 Android 9+ 且需要无障碍服务权限
 */
class TakeScreenshotToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "take_screenshot",
        description = "触发系统截图功能（需要 Android 9+ 和无障碍权限）。如果不支持，会提示用户使用物理按键截图。",
        category = "system",
        parameters = listOf()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val service = com.example.xihe.CoreAccessibilityService.instance
            
            if (service != null && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
                // Android 9+ 可以通过 Accessibility 触发截图
                val screenshotTaken = service.performGlobalAction(
                    android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT
                )
                
                if (screenshotTaken) {
                    return ToolResult(
                        success = true,
                        message = "截图已触发！请在通知栏或相册中查看。",
                        data = buildJsonObject {
                            put("method", "accessibility_service")
                        }
                    )
                }
            }
            
            // Fallback: 提示用户手动截图
            ToolResult(
                success = false,
                message = "当前设备不支持自动截图（需要 Android 9+ 和无障碍权限）。请使用物理按键（电源+音量下）进行截图。",
                error = "NOT_SUPPORTED"
            )
        } catch (e: Exception) {
            ToolResult(
                success = false,
                message = "截图失败: ${e.message}",
                error = "SCREENSHOT_ERROR"
            )
        }
    }
}

/**
 * 获取当前时间工具 🕐
 */
class GetCurrentTimeToolImpl : Tool() {
    override val definition = ToolDefinition(
        name = "get_current_time",
        description = "获取当前的日期和时间。",
        category = "system",
        parameters = listOf()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val currentTime = System.currentTimeMillis()
            val dateFormat = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss E", java.util.Locale.CHINA)
            val formattedTime = dateFormat.format(java.util.Date(currentTime))
            
            ToolResult(
                success = true,
                message = "当前时间: $formattedTime",
                data = buildJsonObject {
                    put("timestamp", currentTime)
                    put("formatted", formattedTime)
                }
            )
        } catch (e: Exception) {
            ToolResult(
                success = false,
                message = "获取时间失败: ${e.message}",
                error = "TIME_ERROR"
            )
        }
    }
}
