package com.example.xihe.tools

import com.example.xihe.utils.LogManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.*
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

/**
 * 生活 API 工具集
 * 提供天气、日期、日历、节假日等免费 API
 */
object LifeApiTools {
    private const val TAG = "LifeApiTools"
    
    // ============ 日期时间工具 ============
    
    /**
     * 获取当前日期时间
     */
    fun getCurrentDateTime(): ToolResult {
        return try {
            val now = Date()
            val dateFormat = SimpleDateFormat("yyyy年MM月dd日", Locale.CHINA)
            val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.CHINA)
            val weekFormat = SimpleDateFormat("EEEE", Locale.CHINA)
            
            val date = dateFormat.format(now)
            val time = timeFormat.format(now)
            val week = weekFormat.format(now)
            
            // 计算农历（简化版）
            val lunarInfo = getLunarDate(now)
            
            val result = buildString {
                append(" 当前时间信息：\n")
                append("• 公历：$date $week\n")
                append("• 时间：$time\n")
                append("• 农历：$lunarInfo\n")
                append("• 时区：${TimeZone.getDefault().displayName}")
            }
            
            ToolResult(true, result)
        } catch (e: Exception) {
            LogManager.e(TAG, "获取日期时间失败", e)
            ToolResult(false, "获取日期时间失败：${e.message}")
        }
    }
    
    /**
     * 获取农历日期（简化版）
     */
    private fun getLunarDate(date: Date): String {
        val calendar = Calendar.getInstance()
        calendar.time = date
        val month = calendar.get(Calendar.MONTH) + 1
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        
        // 简化的农历转换（实际应用需要更精确的算法）
        val lunarMonths = arrayOf("正月", "二月", "三月", "四月", "五月", "六月",
            "七月", "八月", "九月", "十月", "冬月", "腊月")
        val lunarDays = arrayOf(
            "初一", "初二", "初三", "初四", "初五", "初六", "初七", "初八", "初九", "初十",
            "十一", "十二", "十三", "十四", "十五", "十六", "十七", "十八", "十九", "二十",
            "廿一", "廿二", "廿三", "廿四", "廿五", "廿六", "廿七", "廿八", "廿九", "三十"
        )
        
        // 这里返回一个近似值，实际需要更复杂的农历算法
        val lunarMonth = lunarMonths[(month - 1) % 12]
        val lunarDay = if (day <= 30) lunarDays[day - 1] else "三十"
        
        return "$lunarMonth$lunarDay"
    }
    
    /**
     * 计算两个日期之间的天数
     */
    fun calculateDaysBetween(startDate: String, endDate: String): ToolResult {
        return try {
            val format = SimpleDateFormat("yyyy-MM-dd", Locale.CHINA)
            val start = format.parse(startDate)
            val end = format.parse(endDate)
            
            if (start != null && end != null) {
                val diff = (end.time - start.time) / (1000 * 60 * 60 * 24)
                ToolResult(true, "从 $startDate 到 $endDate 共 $diff 天")
            } else {
                ToolResult(false, "日期格式错误，请使用 yyyy-MM-dd 格式")
            }
        } catch (e: Exception) {
            ToolResult(false, "计算失败：${e.message}")
        }
    }
    
    // ============ 天气工具 ============
    
    // 应用上下文（用于获取定位）
    private var appContext: android.content.Context? = null
    
    fun init(context: android.content.Context) {
        appContext = context.applicationContext
        com.example.xihe.service.LocationManager.init(context)
    }
    
    /**
     * 获取天气信息（支持自动定位）
     */
    suspend fun getWeatherWithAutoLocation(city: String?): ToolResult {
        val targetCity = if (city.isNullOrBlank()) {
            // 尝试自动获取位置
            val context = appContext
            if (context != null) {
                val autoCity = com.example.xihe.service.LocationManager.getCurrentCity(context)
                if (autoCity != null) {
                    LogManager.d(TAG, " 自动定位到城市: $autoCity")
                    autoCity
                } else {
                    return ToolResult(false, "无法获取您的位置，请检查定位权限或手动指定城市名称")
                }
            } else {
                return ToolResult(false, "应用未初始化，无法获取位置")
            }
        } else {
            city
        }
        
        return getWeather(targetCity)
    }
    
    /**
     * 获取天气信息（多API备用）
     */
    suspend fun getWeather(city: String): ToolResult = withContext(Dispatchers.IO) {
        LogManager.d(TAG, " 开始获取天气: $city")
        
        // 尝试多个天气源（增加重试机制）
        var result: ToolResult? = null
        
        // 第一优先：Open-Meteo（国际API，相对稳定）
        result = tryOpenMeteoWithRetry(city, maxRetries = 2)
        if (result != null) {
            LogManager.d(TAG, " Open-Meteo 获取成功")
            return@withContext result
        }
        
        // 第二优先：wttr.in
        result = tryWttrInWithRetry(city, maxRetries = 2)
        if (result != null) {
            LogManager.d(TAG, " wttr.in 获取成功")
            return@withContext result
        }
        
        // 最后：返回友好提示
        LogManager.w(TAG, " 所有天气API都失败")
        trySimulatedWeather(city)
    }
    
    /**
     * wttr.in API 带重试机制
     */
    private suspend fun tryWttrInWithRetry(city: String, maxRetries: Int = 2): ToolResult? {
        repeat(maxRetries) { attempt ->
            val result = tryWttrIn(city)
            if (result != null) return result
            if (attempt < maxRetries - 1) {
                LogManager.d(TAG, "wttr.in 第${attempt + 1}次尝试失败，重试中...")
                kotlinx.coroutines.delay(1000)  // 重试前等待1秒
            }
        }
        return null
    }
    
    private suspend fun tryWttrIn(city: String): ToolResult? = withContext(Dispatchers.IO) {
        try {
            val encodedCity = java.net.URLEncoder.encode(city, "UTF-8")
            val url = URL("https://wttr.in/$encodedCity?format=j1&lang=zh")
            
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 15000  // 增加超时时间到15秒
            connection.readTimeout = 15000
            connection.setRequestProperty("User-Agent", "curl")
            
            if (connection.responseCode == 200) {
                val response = connection.inputStream.bufferedReader().readText()
                val weather = parseWeatherResponse(response, city)
                ToolResult(true, weather)
            } else {
                LogManager.w(TAG, "wttr.in 返回状态码: ${connection.responseCode}")
                null
            }
        } catch (e: java.net.SocketTimeoutException) {
            LogManager.w(TAG, "wttr.in 超时: ${e.message}")
            null
        } catch (e: Exception) {
            LogManager.w(TAG, "wttr.in 获取失败: ${e.message}")
            null
        }
    }
    
    /**
     * Open-Meteo API 带重试机制
     */
    private suspend fun tryOpenMeteoWithRetry(city: String, maxRetries: Int = 2): ToolResult? {
        repeat(maxRetries) { attempt ->
            val result = tryOpenMeteo(city)
            if (result != null) return result
            if (attempt < maxRetries - 1) {
                LogManager.d(TAG, "Open-Meteo 第${attempt + 1}次尝试失败，重试中...")
                kotlinx.coroutines.delay(1000)  // 重试前等待1秒
            }
        }
        return null
    }
    
    /**
     * 尝试 Open-Meteo API（免费无需API key）
     */
    private suspend fun tryOpenMeteo(city: String): ToolResult? = withContext(Dispatchers.IO) {
        try {
            // 先通过 geocoding 获取坐标
            val encodedCity = java.net.URLEncoder.encode(city, "UTF-8")
            val geoUrl = URL("https://geocoding-api.open-meteo.com/v1/search?name=$encodedCity&count=1&language=zh")
            
            val geoConnection = geoUrl.openConnection() as HttpURLConnection
            geoConnection.requestMethod = "GET"
            geoConnection.connectTimeout = 15000  // 增加超时时间到15秒
            geoConnection.readTimeout = 15000
            
            if (geoConnection.responseCode != 200) {
                LogManager.w(TAG, "Open-Meteo geocoding 返回状态码: ${geoConnection.responseCode}")
                return@withContext null
            }
            
            val geoResponse = geoConnection.inputStream.bufferedReader().readText()
            val geoJson = Json.parseToJsonElement(geoResponse).jsonObject
            val results = geoJson["results"]?.jsonArray ?: return@withContext null
            if (results.isEmpty()) {
                LogManager.w(TAG, "Open-Meteo 未找到城市: $city")
                return@withContext null
            }
            
            val location = results[0].jsonObject
            val lat = location["latitude"]?.jsonPrimitive?.double ?: return@withContext null
            val lon = location["longitude"]?.jsonPrimitive?.double ?: return@withContext null
            val cityName = location["name"]?.jsonPrimitive?.content ?: city
            
            LogManager.d(TAG, "Open-Meteo 定位成功: $cityName ($lat, $lon)")
            
            // 获取天气
            val weatherUrl = URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m&timezone=auto")
            
            val weatherConnection = weatherUrl.openConnection() as HttpURLConnection
            weatherConnection.requestMethod = "GET"
            weatherConnection.connectTimeout = 15000  // 增加超时时间到15秒
            weatherConnection.readTimeout = 15000
            
            if (weatherConnection.responseCode != 200) {
                LogManager.w(TAG, "Open-Meteo weather 返回状态码: ${weatherConnection.responseCode}")
                return@withContext null
            }
            
            val weatherResponse = weatherConnection.inputStream.bufferedReader().readText()
            val weatherJson = Json.parseToJsonElement(weatherResponse).jsonObject
            val current = weatherJson["current"]?.jsonObject ?: return@withContext null
            
            val temp = current["temperature_2m"]?.jsonPrimitive?.double?.toInt() ?: 0
            val humidity = current["relative_humidity_2m"]?.jsonPrimitive?.int ?: 0
            val windSpeed = current["wind_speed_10m"]?.jsonPrimitive?.double?.toInt() ?: 0
            val weatherCode = current["weather_code"]?.jsonPrimitive?.int ?: 0
            
            val weatherDesc = getWeatherDescription(weatherCode)
            
            val weather = buildString {
                append(" 天气：\n")
                append("• 天气：$weatherDesc\n")
                append("• 温度：${temp}°C\n")
                append("• 湿度：$humidity%\n")
                append("• 风速：${windSpeed} km/h")
            }
            
            LogManager.d(TAG, "Open-Meteo 获取成功: $cityName ${temp}°C")
            ToolResult(true, weather)
        } catch (e: java.net.SocketTimeoutException) {
            LogManager.w(TAG, "Open-Meteo 超时: ${e.message}")
            null
        } catch (e: Exception) {
            LogManager.w(TAG, "Open-Meteo 获取失败: ${e.message}")
            null
        }
    }
    
    /**
     * 根据天气代码获取描述
     */
    private fun getWeatherDescription(code: Int): String {
        return when (code) {
            0 -> "晴朗 "
            1, 2, 3 -> "多云 "
            45, 48 -> "雾 "
            51, 53, 55 -> "毛毛雨 "
            56, 57 -> "冻毛毛雨 "
            61, 63, 65 -> "雨 "
            66, 67 -> "冻雨 "
            71, 73, 75 -> "雪 "
            77 -> "雪粒 "
            80, 81, 82 -> "阵雨 "
            85, 86 -> "阵雪 "
            95 -> "雷暴 "
            96, 99 -> "雷暴伴冰雹 "
            else -> "未知"
        }
    }
    
    /**
     * 所有API都失败时返回友好提示
     */
    private fun trySimulatedWeather(city: String): ToolResult {
        LogManager.w(TAG, "所有天气API都失败，返回提示信息")
        return ToolResult(
            false, 
            "抱歉，无法获取${city}的天气信息。可能是网络不稳定或服务暂时不可用。\n" +
            "建议：\n" +
            "1. 请检查网络连接\n" +
            "2. 稍后再试\n" +
            "3. 或直接查看手机自带的天气应用"
        )
    }
    
    /**
     * 解析天气 JSON 响应
     */
    private fun parseWeatherResponse(json: String, city: String): String {
        return try {
            val jsonElement = Json.parseToJsonElement(json)
            val current = jsonElement.jsonObject["current_condition"]?.jsonArray?.get(0)?.jsonObject
            
            if (current != null) {
                val temp = current["temp_C"]?.jsonPrimitive?.content ?: "?"
                val feelsLike = current["FeelsLikeC"]?.jsonPrimitive?.content ?: "?"
                val humidity = current["humidity"]?.jsonPrimitive?.content ?: "?"
                val windSpeed = current["windspeedKmph"]?.jsonPrimitive?.content ?: "?"
                val desc = current["lang_zh"]?.jsonArray?.get(0)?.jsonObject?.get("value")?.jsonPrimitive?.content
                    ?: current["weatherDesc"]?.jsonArray?.get(0)?.jsonObject?.get("value")?.jsonPrimitive?.content
                    ?: "未知"
                
                buildString {
                    append("🌤️ $city 天气：\n")
                    append("• 天气：$desc\n")
                    append("• 温度：${temp}°C（体感 ${feelsLike}°C）\n")
                    append("• 湿度：$humidity%\n")
                    append("• 风速：${windSpeed} km/h")
                }
            } else {
                "🌤️ $city：无法解析天气数据"
            }
        } catch (e: Exception) {
            "🌤️ $city：天气数据解析失败"
        }
    }
    
    // ============ 📆 节假日工具 ============
    
    /**
     * 获取中国节假日信息
     */
    fun getHolidayInfo(): ToolResult {
        val calendar = Calendar.getInstance()
        val now = Date()
        
        // 中国主要节假日（固定日期）
        val holidays = listOf(
            Holiday("元旦", 1, 1),
            Holiday("情人节", 2, 14),
            Holiday("妇女节", 3, 8),
            Holiday("植树节", 3, 12),
            Holiday("愚人节", 4, 1),
            Holiday("劳动节", 5, 1),
            Holiday("青年节", 5, 4),
            Holiday("儿童节", 6, 1),
            Holiday("建党节", 7, 1),
            Holiday("建军节", 8, 1),
            Holiday("教师节", 9, 10),
            Holiday("国庆节", 10, 1),
            Holiday("万圣节", 10, 31),
            Holiday("光棍节", 11, 11),
            Holiday("平安夜", 12, 24),
            Holiday("圣诞节", 12, 25)
        )
        
        val currentMonth = calendar.get(Calendar.MONTH) + 1
        val currentDay = calendar.get(Calendar.DAY_OF_MONTH)
        val currentYear = calendar.get(Calendar.YEAR)
        
        // 找到下一个节假日
        var nextHoliday: Holiday? = null
        var daysUntil = Int.MAX_VALUE
        
        for (holiday in holidays) {
            val holidayCalendar = Calendar.getInstance()
            holidayCalendar.set(currentYear, holiday.month - 1, holiday.day)
            
            // 如果今年的已过，算明年的
            if (holidayCalendar.time.before(now)) {
                holidayCalendar.set(Calendar.YEAR, currentYear + 1)
            }
            
            val days = ((holidayCalendar.time.time - now.time) / (1000 * 60 * 60 * 24)).toInt()
            if (days >= 0 && days < daysUntil) {
                daysUntil = days
                nextHoliday = holiday
            }
        }
        
        return if (nextHoliday != null) {
            val result = buildString {
                append("📆 节假日信息：\n")
                append("• 下一个节日：${nextHoliday.name}\n")
                append("• 日期：${nextHoliday.month}月${nextHoliday.day}日\n")
                append("• 距离今天：${daysUntil}天\n\n")
                append("本月节日：\n")
                holidays.filter { it.month == currentMonth }.forEach {
                    append("  • ${it.day}日 - ${it.name}\n")
                }
            }
            ToolResult(true, result)
        } else {
            ToolResult(false, "无法获取节假日信息")
        }
    }
    
    data class Holiday(val name: String, val month: Int, val day: Int)
    
    // ============ 🎲 随机工具 ============
    
    /**
     * 生成随机数
     */
    fun generateRandomNumber(min: Int, max: Int): ToolResult {
        return try {
            val random = Random()
            val result = random.nextInt(max - min + 1) + min
            ToolResult(true, "🎲 随机数结果：$result（范围：$min ~ $max）")
        } catch (e: Exception) {
            ToolResult(false, "生成随机数失败：${e.message}")
        }
    }
    
    /**
     * 抛硬币
     */
    fun flipCoin(): ToolResult {
        val result = if (Random().nextBoolean()) "正面 👆" else "反面 👇"
        return ToolResult(true, "🪙 抛硬币结果：$result")
    }
    
    /**
     * 掷骰子
     */
    fun rollDice(count: Int = 1): ToolResult {
        return try {
            val random = Random()
            val results = (1..count).map { random.nextInt(6) + 1 }
            val total = results.sum()
            
            val result = buildString {
                append("🎲 掷骰子结果：\n")
                if (count > 1) {
                    append("• 每个骰子：${results.joinToString(", ")}\n")
                    append("• 总点数：$total")
                } else {
                    append("• 点数：${results[0]}")
                }
            }
            ToolResult(true, result)
        } catch (e: Exception) {
            ToolResult(false, "掷骰子失败：${e.message}")
        }
    }
    
    // ============ 📖 每日一句 ============
    
    /**
     * 获取每日一句（鸡汤/名言）
     */
    suspend fun getDailyQuote(): ToolResult = withContext(Dispatchers.IO) {
        // 本地名言库
        val quotes = listOf(
            "生活不是等待暴风雨过去，而是学会在雨中跳舞。",
            "成功的秘诀就是每天都比昨天更努力一点点。",
            "你今天的努力，是幸运的伏笔，当下的付出，是明日的花开。",
            "不要等待机会，而要创造机会。",
            "每一个不曾起舞的日子，都是对生命的辜负。",
            "人生没有白走的路，每一步都算数。",
            "你的时间有限，不要浪费于重复别人的生活。",
            "最好的时光在路上，最美的自己在远方。",
            "所有的努力都不会完全白费，你付出多少时间和精力，都是在对未来的积累。",
            "生命中最难的阶段不是没有人懂你，而是你不懂你自己。",
            "别人怎么看你不重要，唯一重要的是你很喜欢真实的自己。",
            "当你觉得晚的时候，恰恰是最早的时候。",
            "梦想不会逃跑，会逃跑的永远都是自己。",
            "你必须非常努力，才能看起来毫不费力。",
            "今天的你，是昨天的选择；明天的你，是今天的决定。"
        )
        
        val quote = quotes.random()
        ToolResult(true, "💬 每日一句：\n「$quote」")
    }
    
    // ============ 🔢 计算器 ============
    
    /**
     * 简单计算
     */
    fun calculate(expression: String): ToolResult {
        return try {
            // 简单的四则运算解析
            val result = evaluateExpression(expression)
            ToolResult(true, "🔢 计算结果：$expression = $result")
        } catch (e: Exception) {
            ToolResult(false, "计算失败：${e.message}")
        }
    }
    
    /**
     * 简单表达式求值
     */
    private fun evaluateExpression(expr: String): Double {
        val cleanExpr = expr.replace(" ", "")
            .replace("×", "*")
            .replace("÷", "/")
            .replace("（", "(")
            .replace("）", ")")
        
        // 直接使用简单解析
        return simpleEval(cleanExpr)
    }
    
    /**
     * 简单四则运算
     */
    private fun simpleEval(expr: String): Double {
        // 只处理简单的两数运算
        val operators = listOf("+", "-", "*", "/")
        for (op in operators) {
            if (expr.contains(op) && expr.indexOf(op) > 0) {
                val parts = expr.split(op, limit = 2)
                if (parts.size == 2) {
                    val a = parts[0].toDoubleOrNull() ?: return 0.0
                    val b = parts[1].toDoubleOrNull() ?: return 0.0
                    return when (op) {
                        "+" -> a + b
                        "-" -> a - b
                        "*" -> a * b
                        "/" -> if (b != 0.0) a / b else 0.0
                        else -> 0.0
                    }
                }
            }
        }
        return expr.toDoubleOrNull() ?: 0.0
    }
    
    // ============ 🌐 IP 和网络信息 ============
    
    /**
     * 获取公网 IP
     */
    suspend fun getPublicIP(): ToolResult = withContext(Dispatchers.IO) {
        try {
            val url = URL("https://api.ipify.org?format=json")
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 5000
            
            if (connection.responseCode == 200) {
                val response = connection.inputStream.bufferedReader().readText()
                val ip = Json.parseToJsonElement(response).jsonObject["ip"]?.jsonPrimitive?.content ?: "未知"
                ToolResult(true, "🌐 你的公网IP：$ip")
            } else {
                ToolResult(false, "无法获取IP地址")
            }
        } catch (e: Exception) {
            ToolResult(false, "获取IP失败：${e.message}")
        }
    }
}
