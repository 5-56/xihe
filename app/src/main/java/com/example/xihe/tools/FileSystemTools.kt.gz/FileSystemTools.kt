package com.example.xihe.tools

import android.content.Context
import kotlinx.serialization.json.*
import java.io.File

/**
 * 读取文件工具
 */
class ReadFileToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "read_file",
        description = "读取文件内容。可以读取文本文件或获取文件信息。",
        category = "file",
        parameters = listOf(
            ToolParameter(
                name = "path",
                description = "文件路径（相对路径或绝对路径）",
                type = "string",
                required = true
            ),
            ToolParameter(
                name = "encoding",
                description = "文件编码（默认UTF-8）",
                type = "string",
                required = false
            )
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        validateParameters(parameters)?.let { return it }
        
        return try {
            val path = parameters["path"]?.jsonPrimitive?.content ?: return ToolResult(
                success = false,
                message = "路径参数为空",
                error = "INVALID_PATH"
            )
            
            val file = resolveFile(path)
            
            if (!file.exists()) {
                return ToolResult(
                    success = false,
                    message = "文件不存在: $path",
                    error = "FILE_NOT_FOUND"
                )
            }
            
            if (!file.isFile) {
                return ToolResult(
                    success = false,
                    message = "路径不是文件: $path",
                    error = "NOT_A_FILE"
                )
            }
            
            val encoding = parameters["encoding"]?.jsonPrimitive?.content ?: "UTF-8"
            val content = file.readText(charset(encoding))
            
            ToolResult(
                success = true,
                message = "成功读取文件 (${file.length()} 字节)",
                data = buildJsonObject {
                    put("content", content)
                    put("size", file.length())
                    put("path", file.absolutePath)
                }
            )
        } catch (e: Exception) {
            ToolResult(
                success = false,
                message = "读取文件失败: ${e.message}",
                error = "READ_ERROR"
            )
        }
    }
    
    private fun resolveFile(path: String): File {
        val root = context.filesDir.canonicalFile
        val sanitized = path.trim().removePrefix("/")
        val target = File(root, sanitized).canonicalFile
        if (target.path != root.path && !target.path.startsWith(root.path + File.separator)) {
            throw SecurityException("路径超出允许范围: " + path)
        }
        return target
    }
}

/**
 * 写入文件工具
 */
class WriteFileToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "write_file",
        description = "写入内容到文件。如果文件不存在会创建，存在则覆盖。",
        category = "file",
        parameters = listOf(
            ToolParameter(
                name = "path",
                description = "文件路径",
                type = "string",
                required = true
            ),
            ToolParameter(
                name = "content",
                description = "要写入的内容",
                type = "string",
                required = true
            ),
            ToolParameter(
                name = "append",
                description = "是否追加模式（默认false，覆盖）",
                type = "boolean",
                required = false
            )
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        validateParameters(parameters)?.let { return it }
        
        return try {
            val path = parameters["path"]?.jsonPrimitive?.content ?: return ToolResult(
                success = false,
                message = "路径参数为空",
                error = "INVALID_PATH"
            )
            
            val content = parameters["content"]?.jsonPrimitive?.content ?: ""
            val append = parameters["append"]?.jsonPrimitive?.booleanOrNull ?: false
            
            val file = resolveFile(path)
            
            // 确保父目录存在
            file.parentFile?.mkdirs()
            
            if (append) {
                file.appendText(content)
            } else {
                file.writeText(content)
            }
            
            ToolResult(
                success = true,
                message = "成功写入文件 (${content.length} 字符)",
                data = buildJsonObject {
                    put("path", file.absolutePath)
                    put("size", file.length())
                }
            )
        } catch (e: Exception) {
            ToolResult(
                success = false,
                message = "写入文件失败: ${e.message}",
                error = "WRITE_ERROR"
            )
        }
    }
    
    private fun resolveFile(path: String): File {
        val root = context.filesDir.canonicalFile
        val sanitized = path.trim().removePrefix("/")
        val target = File(root, sanitized).canonicalFile
        if (target.path != root.path && !target.path.startsWith(root.path + File.separator)) {
            throw SecurityException("路径超出允许范围: " + path)
        }
        return target
    }
}

/**
 * 列出文件工具
 */
class ListFilesToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "list_files",
        description = "列出目录下的所有文件和文件夹。",
        category = "file",
        parameters = listOf(
            ToolParameter(
                name = "path",
                description = "目录路径（默认为应用数据目录）",
                type = "string",
                required = false
            )
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val path = parameters["path"]?.jsonPrimitive?.content
            val dir = if (path != null) {
                resolveFile(path)
            } else {
                context.filesDir
            }
            
            if (!dir.exists()) {
                return ToolResult(
                    success = false,
                    message = "目录不存在: ${dir.path}",
                    error = "DIR_NOT_FOUND"
                )
            }
            
            if (!dir.isDirectory) {
                return ToolResult(
                    success = false,
                    message = "路径不是目录: ${dir.path}",
                    error = "NOT_A_DIRECTORY"
                )
            }
            
            val files = dir.listFiles()?.map { file ->
                buildJsonObject {
                    put("name", file.name)
                    put("path", file.absolutePath)
                    put("isDirectory", file.isDirectory)
                    put("size", file.length())
                    put("lastModified", file.lastModified())
                }
            } ?: emptyList()
            
            ToolResult(
                success = true,
                message = "找到 ${files.size} 个项目",
                data = buildJsonObject {
                    put("path", dir.absolutePath)
                    put("files", JsonArray(files))
                }
            )
        } catch (e: Exception) {
            ToolResult(
                success = false,
                message = "列出文件失败: ${e.message}",
                error = "LIST_ERROR"
            )
        }
    }
    
    private fun resolveFile(path: String): File {
        val root = context.filesDir.canonicalFile
        val sanitized = path.trim().removePrefix("/")
        val target = File(root, sanitized).canonicalFile
        if (target.path != root.path && !target.path.startsWith(root.path + File.separator)) {
            throw SecurityException("路径超出允许范围: " + path)
        }
        return target
    }
}

/**
 * 删除文件工具
 */
class DeleteFileToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "delete_file",
        description = "删除文件或空目录。",
        category = "file",
        parameters = listOf(
            ToolParameter(
                name = "path",
                description = "要删除的文件或目录路径",
                type = "string",
                required = true
            )
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        validateParameters(parameters)?.let { return it }
        
        return try {
            val path = parameters["path"]?.jsonPrimitive?.content ?: return ToolResult(
                success = false,
                message = "路径参数为空",
                error = "INVALID_PATH"
            )
            
            val file = resolveFile(path)
            
            if (!file.exists()) {
                return ToolResult(
                    success = false,
                    message = "文件不存在: $path",
                    error = "FILE_NOT_FOUND"
                )
            }
            
            val deleted = file.delete()
            
            if (deleted) {
                ToolResult(
                    success = true,
                    message = "成功删除: ${file.name}",
                    data = buildJsonObject {
                        put("path", file.absolutePath)
                    }
                )
            } else {
                ToolResult(
                    success = false,
                    message = "删除失败（可能目录不为空）",
                    error = "DELETE_FAILED"
                )
            }
        } catch (e: Exception) {
            ToolResult(
                success = false,
                message = "删除失败: ${e.message}",
                error = "DELETE_ERROR"
            )
        }
    }
    
    private fun resolveFile(path: String): File {
        val root = context.filesDir.canonicalFile
        val sanitized = path.trim().removePrefix("/")
        val target = File(root, sanitized).canonicalFile
        if (target.path != root.path && !target.path.startsWith(root.path + File.separator)) {
            throw SecurityException("路径超出允许范围: " + path)
        }
        return target
    }
}

/**
 * 检查文件是否存在工具
 */
class FileExistsToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "file_exists",
        description = "检查文件或目录是否存在。",
        category = "file",
        parameters = listOf(
            ToolParameter(
                name = "path",
                description = "文件或目录路径",
                type = "string",
                required = true
            )
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        validateParameters(parameters)?.let { return it }
        
        return try {
            val path = parameters["path"]?.jsonPrimitive?.content ?: return ToolResult(
                success = false,
                message = "路径参数为空",
                error = "INVALID_PATH"
            )
            
            val file = resolveFile(path)
            val exists = file.exists()
            
            ToolResult(
                success = true,
                message = if (exists) "文件存在" else "文件不存在",
                data = buildJsonObject {
                    put("exists", exists)
                    put("path", file.absolutePath)
                    if (exists) {
                        put("isDirectory", file.isDirectory)
                        put("isFile", file.isFile)
                        put("size", file.length())
                    }
                }
            )
        } catch (e: Exception) {
            ToolResult(
                success = false,
                message = "检查文件失败: ${e.message}",
                error = "CHECK_ERROR"
            )
        }
    }
    
    private fun resolveFile(path: String): File {
        val root = context.filesDir.canonicalFile
        val sanitized = path.trim().removePrefix("/")
        val target = File(root, sanitized).canonicalFile
        if (target.path != root.path && !target.path.startsWith(root.path + File.separator)) {
            throw SecurityException("路径超出允许范围: " + path)
        }
        return target
    }
}
