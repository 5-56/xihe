package com.example.xihe.tools

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import okhttp3.OkHttpClient
import java.net.InetAddress
import java.net.URI
import java.util.concurrent.TimeUnit

/**
 * 工具参数定义
 */
@Serializable
data class ToolParameter(
    val name: String,
    val description: String,
    val type: String, // "string", "number", "boolean", "object", "array"
    val required: Boolean = false,
    val default: JsonElement? = null
)

/**
 * 工具定义
 */
@Serializable
data class ToolDefinition(
    val name: String,
    val description: String,
    val category: String, // "file", "http", "system", etc.
    val parameters: List<ToolParameter>,
    val isEnabled: Boolean = true
)

/**
 * 工具执行结果
 */
@Serializable
data class ToolResult(
    val success: Boolean,
    val message: String,
    val data: JsonElement? = null,
    val error: String? = null
)

/**
 * 工具调用请求
 */
@Serializable
data class ToolCall(
    val toolName: String,
    val parameters: JsonObject
)

/**
 * 工具基类
 */
abstract class Tool {
    abstract val definition: ToolDefinition

    /**
     * 执行工具
     */
    abstract suspend fun execute(parameters: JsonObject): ToolResult

    /**
     * 验证参数
     */
    protected fun validateParameters(parameters: JsonObject): ToolResult? {
        for (param in definition.parameters) {
            if (param.required && !parameters.containsKey(param.name)) {
                return ToolResult(
                    success = false,
                    message = "缺少必需参数: ${param.name}",
                    error = "MISSING_PARAMETER"
                )
            }
        }
        return null
    }
}

private fun parseIpv4(host: String): IntArray? {
    val parts = host.split(".")
    if (parts.size != 4) {
        return null
    }
    val octets = IntArray(4)
    for (i in parts.indices) {
        val value = parts[i].toIntOrNull() ?: return null
        if (value !in 0..255) {
            return null
        }
        octets[i] = value
    }
    return octets
}

private fun isPrivateIpv4(octets: IntArray): Boolean {
    val first = octets[0]
    val second = octets[1]
    return first == 0 ||
        first == 10 ||
        first == 127 ||
        (first == 169 && second == 254) ||
        (first == 172 && second in 16..31) ||
        (first == 192 && second == 168) ||
        (first == 100 && second in 64..127) ||
        (first == 198 && second in 18..19)
}

private fun isPrivateIpv6(host: String): Boolean {
    if (!host.contains(":")) {
        return false
    }
    val address = try {
        InetAddress.getByName(host.substringBefore("%"))
    } catch (e: Exception) {
        return false
    }
    val bytes = address.address
    if (bytes.size != 16) {
        return false
    }
    if (address.isAnyLocalAddress || address.isLoopbackAddress || address.isLinkLocalAddress || address.isSiteLocalAddress) {
        return true
    }
    val first = bytes[0].toInt() and 0xFF
    val second = bytes[1].toInt() and 0xFF
    if ((first and 0xFE) == 0xFC) {
        return true
    }
    if (first == 0xFE && (second and 0xC0) == 0x80) {
        return true
    }
    val isIpv4Mapped = bytes.sliceArray(0..9).all { it.toInt() == 0 } &&
        (bytes[10].toInt() and 0xFF) == 0xFF &&
        (bytes[11].toInt() and 0xFF) == 0xFF
    if (!isIpv4Mapped) {
        return false
    }
    val mappedIpv4 = intArrayOf(
        bytes[12].toInt() and 0xFF,
        bytes[13].toInt() and 0xFF,
        bytes[14].toInt() and 0xFF,
        bytes[15].toInt() and 0xFF
    )
    return isPrivateIpv4(mappedIpv4)
}

private fun isLocalHostname(host: String): Boolean {
    return host == "localhost" ||
        host.endsWith(".localhost") ||
        host.endsWith(".local") ||
        host.endsWith(".localdomain")
}

private fun isPrivateHost(host: String): Boolean {
    val ipv4 = parseIpv4(host)
    if (ipv4 != null) {
        return isPrivateIpv4(ipv4)
    }
    return isPrivateIpv6(host)
}

fun validateSafeUrl(url: String): String? {
    val uri = try {
        URI(url)
    } catch (e: Exception) {
        return "URL 格式无效"
    }

    val scheme = uri.scheme?.lowercase() ?: return "URL 缺少协议"
    if (scheme != "http" && scheme != "https") {
        return "仅支持 HTTP/HTTPS 协议"
    }

    val host = uri.host?.trim()?.trimEnd('.')?.lowercase() ?: return "URL 缺少主机名"
    if (host.isBlank()) {
        return "URL 缺少主机名"
    }
    if (host.all { it.isDigit() }) {
        return "禁止访问本地或内网地址"
    }
    if (isLocalHostname(host) || isPrivateHost(host)) {
        return "禁止访问本地或内网地址"
    }

    return null
}

fun createSecureHttpClient(): OkHttpClient {
    return OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()
}
