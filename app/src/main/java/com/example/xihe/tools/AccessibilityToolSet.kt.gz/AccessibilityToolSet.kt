package com.example.xihe.tools

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.accessibility.AccessibilityNodeInfo
import com.example.xihe.CoreAccessibilityService
import kotlinx.coroutines.delay
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.floatOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import java.io.File
import java.io.FileOutputStream

object AccessibilityToolSet {
    fun register(context: Context) {
        ToolRegistry.registerTool(GetScreenInfoToolImpl())
        ToolRegistry.registerTool(FindNodeInfoToolImpl())
        ToolRegistry.registerTool(TakeAccessibilityScreenshotToolImpl(context))
        ToolRegistry.registerTool(InputTextFocusedToolImpl())
        ToolRegistry.registerTool(OpenAppByNameToolImpl(context))
        ToolRegistry.registerTool(GetInstalledAppsToolImpl(context))
        ToolRegistry.registerTool(PressBackToolImpl())
        ToolRegistry.registerTool(PressHomeToolImpl())
        ToolRegistry.registerTool(OpenRecentAppsToolImpl())
        ToolRegistry.registerTool(ExpandNotificationsToolImpl())
        ToolRegistry.registerTool(CollapseNotificationsToolImpl())
        ToolRegistry.registerTool(LockScreenToolImpl())
        ToolRegistry.registerTool(WaitToolImpl())
        ToolRegistry.registerTool(TapToolImpl())
        ToolRegistry.registerTool(LongPressToolImpl())
        ToolRegistry.registerTool(SwipeToolImpl())
        ToolRegistry.registerTool(ClickByTextToolImpl())
        ToolRegistry.registerTool(ClickByIdToolImpl())
        ToolRegistry.registerTool(RepeatActionsAgentToolImpl())
        ToolRegistry.registerTool(SendFileToolImpl(context))
        ToolRegistry.registerTool(FinishToolImpl())
        ToolRegistry.registerTool(SearchAppInStoreToolImpl(context))
    }

    internal fun service(): CoreAccessibilityService? = CoreAccessibilityService.getInstance()

    internal fun missingService(): ToolResult = ToolResult(false, "Accessibility service is not connected", error = "ACCESSIBILITY_NOT_CONNECTED")

    internal fun nodeToJson(node: AccessibilityNodeInfo, depth: Int = 0, maxDepth: Int = 6): JsonObject {
        val rect = android.graphics.Rect()
        node.getBoundsInScreen(rect)
        return buildJsonObject {
            put("text", node.text?.toString().orEmpty())
            put("contentDescription", node.contentDescription?.toString().orEmpty())
            put("viewId", node.viewIdResourceName.orEmpty())
            put("className", node.className?.toString().orEmpty())
            put("packageName", node.packageName?.toString().orEmpty())
            put("clickable", node.isClickable)
            put("editable", node.isEditable)
            put("enabled", node.isEnabled)
            put("bounds", buildJsonArray {
                add(JsonPrimitive(rect.left))
                add(JsonPrimitive(rect.top))
                add(JsonPrimitive(rect.right))
                add(JsonPrimitive(rect.bottom))
            })
            if (depth < maxDepth && node.childCount > 0) {
                put("children", buildJsonArray {
                    for (i in 0 until node.childCount.coerceAtMost(25)) {
                        node.getChild(i)?.let { add(nodeToJson(it, depth + 1, maxDepth)) }
                    }
                })
            }
        }
    }

    internal fun findNode(root: AccessibilityNodeInfo, query: String, byId: Boolean): AccessibilityNodeInfo? {
        val text = root.text?.toString().orEmpty()
        val desc = root.contentDescription?.toString().orEmpty()
        val id = root.viewIdResourceName.orEmpty()
        val matched = if (byId) id.contains(query, ignoreCase = true) else text.contains(query, ignoreCase = true) || desc.contains(query, ignoreCase = true)
        if (matched) return root
        for (i in 0 until root.childCount) {
            val child = root.getChild(i) ?: continue
            val found = findNode(child, query, byId)
            if (found != null) return found
        }
        return null
    }

    internal fun nodeCenter(node: AccessibilityNodeInfo): Pair<Float, Float> {
        val rect = android.graphics.Rect()
        node.getBoundsInScreen(rect)
        return rect.centerX().toFloat() to rect.centerY().toFloat()
    }

    internal suspend fun clickNode(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        while (current != null) {
            if (current.isClickable && current.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            current = current.parent
        }
        val (x, y) = nodeCenter(node)
        return service()?.tapAsync(x, y) == true
    }
}

class GetScreenInfoToolImpl : Tool() {
    override val definition = ToolDefinition("get_screen_info", "Get current UI hierarchy tree and screen metadata", "accessibility", emptyList())
    override suspend fun execute(parameters: JsonObject): ToolResult {
        val service = AccessibilityToolSet.service() ?: return AccessibilityToolSet.missingService()
        val root = service.rootInActiveWindow ?: return ToolResult(false, "No active window", error = "NO_ROOT")
        val size = service.getScreenSize()
        return ToolResult(true, "Screen info captured", buildJsonObject {
            put("packageName", service.getCurrentPackageName().orEmpty())
            put("width", size.first)
            put("height", size.second)
            put("tree", AccessibilityToolSet.nodeToJson(root))
        })
    }
}

class FindNodeInfoToolImpl : Tool() {
    override val definition = ToolDefinition("find_node_info", "Find a UI node by visible text or resource id", "accessibility", listOf(ToolParameter("query", "Search text or resource id", "string", true), ToolParameter("by_id", "Search by resource id", "boolean")))
    override suspend fun execute(parameters: JsonObject): ToolResult {
        val service = AccessibilityToolSet.service() ?: return AccessibilityToolSet.missingService()
        val root = service.rootInActiveWindow ?: return ToolResult(false, "No active window", error = "NO_ROOT")
        val query = parameters["query"]?.jsonPrimitive?.contentOrNull.orEmpty()
        val byId = parameters["by_id"]?.jsonPrimitive?.contentOrNull == "true"
        val node = AccessibilityToolSet.findNode(root, query, byId) ?: return ToolResult(false, "Node not found", error = "NODE_NOT_FOUND")
        return ToolResult(true, "Node found", AccessibilityToolSet.nodeToJson(node, maxDepth = 1))
    }
}

class TakeAccessibilityScreenshotToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition("take_screenshot", "Capture current screen as PNG and return local file path", "accessibility", emptyList())
    override suspend fun execute(parameters: JsonObject): ToolResult {
        val service = AccessibilityToolSet.service() ?: return AccessibilityToolSet.missingService()
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R || !service.canTakeScreenshot()) return ToolResult(false, "Screenshot requires Android 11+", error = "UNSUPPORTED")
        val bitmap = service.takeScreenshotAsync() ?: return ToolResult(false, "Screenshot failed", error = "SCREENSHOT_FAILED")
        val file = File(context.cacheDir, "agent_screenshot_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bitmap.recycle()
        return ToolResult(true, "Screenshot saved", buildJsonObject { put("path", file.absolutePath) })
    }
}

class InputTextFocusedToolImpl : Tool() {
    override val definition = ToolDefinition("input_text", "Input text into focused editable field", "accessibility", listOf(ToolParameter("text", "Text to input", "string", true)))
    override suspend fun execute(parameters: JsonObject): ToolResult {
        val service = AccessibilityToolSet.service() ?: return AccessibilityToolSet.missingService()
        val text = parameters["text"]?.jsonPrimitive?.contentOrNull.orEmpty()
        return if (service.inputText(text)) ToolResult(true, "Text input success") else ToolResult(false, "Text input failed", error = "INPUT_FAILED")
    }
}

class OpenAppByNameToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition("open_app", "Open app by package name or app label", "accessibility", listOf(ToolParameter("name", "App package name or display name", "string", true)))
    override suspend fun execute(parameters: JsonObject): ToolResult {
        val name = parameters["name"]?.jsonPrimitive?.contentOrNull
            ?: parameters["app"]?.jsonPrimitive?.contentOrNull
            ?: parameters["app_name"]?.jsonPrimitive?.contentOrNull
            ?: parameters["package"]?.jsonPrimitive?.contentOrNull
            ?: return ToolResult(false, "Missing app name", error = "MISSING_PARAMETER")
        val pm = context.packageManager
        val packageName = if (name.contains('.')) name else pm.getInstalledApplications(0).firstOrNull { pm.getApplicationLabel(it).toString().contains(name, ignoreCase = true) }?.packageName
        val intent = packageName?.let { pm.getLaunchIntentForPackage(it) } ?: return ToolResult(false, "App not found: $name", error = "APP_NOT_FOUND")
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        context.startActivity(intent)
        return ToolResult(true, "Opened app: $name", buildJsonObject { put("packageName", packageName) })
    }
}

class PressBackToolImpl : Tool() {
    override val definition = ToolDefinition("press_back", "Press Android back", "accessibility", emptyList())
    override suspend fun execute(parameters: JsonObject): ToolResult = global(AccessibilityService.GLOBAL_ACTION_BACK, "Back pressed")
}

class PressHomeToolImpl : Tool() {
    override val definition = ToolDefinition("press_home", "Press Android home", "accessibility", emptyList())
    override suspend fun execute(parameters: JsonObject): ToolResult = global(AccessibilityService.GLOBAL_ACTION_HOME, "Home pressed")
}

class OpenRecentAppsToolImpl : Tool() {
    override val definition = ToolDefinition("open_recent_apps", "Open recent apps", "accessibility", emptyList())
    override suspend fun execute(parameters: JsonObject): ToolResult = global(AccessibilityService.GLOBAL_ACTION_RECENTS, "Recent apps opened")
}

class ExpandNotificationsToolImpl : Tool() {
    override val definition = ToolDefinition("expand_notifications", "Expand notification shade", "accessibility", emptyList())
    override suspend fun execute(parameters: JsonObject): ToolResult = global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, "Notifications expanded")
}

class CollapseNotificationsToolImpl : Tool() {
    override val definition = ToolDefinition("collapse_notifications", "Collapse notification shade by pressing back", "accessibility", emptyList())
    override suspend fun execute(parameters: JsonObject): ToolResult = global(AccessibilityService.GLOBAL_ACTION_BACK, "Notifications collapsed")
}

class LockScreenToolImpl : Tool() {
    override val definition = ToolDefinition("lock_screen", "Lock screen", "accessibility", emptyList())
    override suspend fun execute(parameters: JsonObject): ToolResult = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN, "Screen locked") else ToolResult(false, "Lock screen requires Android 9+", error = "UNSUPPORTED")
}

class WaitToolImpl : Tool() {
    override val definition = ToolDefinition("wait", "Wait for milliseconds", "accessibility", listOf(ToolParameter("ms", "Milliseconds", "number")))
    override suspend fun execute(parameters: JsonObject): ToolResult {
        val ms = parameters["ms"]?.jsonPrimitive?.intOrNull?.coerceIn(0, 30000) ?: 1000
        delay(ms.toLong())
        return ToolResult(true, "Waited ${ms}ms")
    }
}

class TapToolImpl : Tool() {
    override val definition = ToolDefinition("tap", "Tap at coordinate x,y", "accessibility", listOf(ToolParameter("x", "X coordinate", "number", true), ToolParameter("y", "Y coordinate", "number", true)))
    override suspend fun execute(parameters: JsonObject): ToolResult {
        val service = AccessibilityToolSet.service() ?: return AccessibilityToolSet.missingService()
        val x = parameters["x"]?.jsonPrimitive?.floatOrNull ?: return ToolResult(false, "Missing x", error = "MISSING_PARAMETER")
        val y = parameters["y"]?.jsonPrimitive?.floatOrNull ?: return ToolResult(false, "Missing y", error = "MISSING_PARAMETER")
        return if (service.tapAsync(x, y)) ToolResult(true, "Tapped at $x,$y") else ToolResult(false, "Tap failed", error = "GESTURE_FAILED")
    }
}

class LongPressToolImpl : Tool() {
    override val definition = ToolDefinition("long_press", "Long press at coordinate x,y", "accessibility", listOf(ToolParameter("x", "X coordinate", "number", true), ToolParameter("y", "Y coordinate", "number", true), ToolParameter("duration_ms", "Duration milliseconds", "number")))
    override suspend fun execute(parameters: JsonObject): ToolResult {
        val service = AccessibilityToolSet.service() ?: return AccessibilityToolSet.missingService()
        val x = parameters["x"]?.jsonPrimitive?.floatOrNull ?: return ToolResult(false, "Missing x", error = "MISSING_PARAMETER")
        val y = parameters["y"]?.jsonPrimitive?.floatOrNull ?: return ToolResult(false, "Missing y", error = "MISSING_PARAMETER")
        val duration = parameters["duration_ms"]?.jsonPrimitive?.intOrNull?.toLong() ?: 800L
        return if (service.longPressAsync(x, y, duration)) ToolResult(true, "Long press success") else ToolResult(false, "Long press failed", error = "GESTURE_FAILED")
    }
}

class SwipeToolImpl : Tool() {
    override val definition = ToolDefinition("swipe", "Swipe from A to B", "accessibility", listOf(ToolParameter("start_x", "Start X", "number", true), ToolParameter("start_y", "Start Y", "number", true), ToolParameter("end_x", "End X", "number", true), ToolParameter("end_y", "End Y", "number", true), ToolParameter("duration_ms", "Duration milliseconds", "number")))
    override suspend fun execute(parameters: JsonObject): ToolResult {
        val service = AccessibilityToolSet.service() ?: return AccessibilityToolSet.missingService()
        val sx = parameters["start_x"]?.jsonPrimitive?.floatOrNull ?: return ToolResult(false, "Missing start_x", error = "MISSING_PARAMETER")
        val sy = parameters["start_y"]?.jsonPrimitive?.floatOrNull ?: return ToolResult(false, "Missing start_y", error = "MISSING_PARAMETER")
        val ex = parameters["end_x"]?.jsonPrimitive?.floatOrNull ?: return ToolResult(false, "Missing end_x", error = "MISSING_PARAMETER")
        val ey = parameters["end_y"]?.jsonPrimitive?.floatOrNull ?: return ToolResult(false, "Missing end_y", error = "MISSING_PARAMETER")
        val duration = parameters["duration_ms"]?.jsonPrimitive?.intOrNull?.toLong() ?: 300L
        return if (service.swipeAsync(sx, sy, ex, ey, duration)) ToolResult(true, "Swipe success") else ToolResult(false, "Swipe failed", error = "GESTURE_FAILED")
    }
}

class ClickByTextToolImpl : Tool() {
    override val definition = ToolDefinition("click_by_text", "Click element by visible text or content description", "accessibility", listOf(ToolParameter("text", "Visible text", "string", true)))
    override suspend fun execute(parameters: JsonObject): ToolResult {
        val service = AccessibilityToolSet.service() ?: return AccessibilityToolSet.missingService()
        val text = parameters["text"]?.jsonPrimitive?.contentOrNull
            ?: parameters["query"]?.jsonPrimitive?.contentOrNull
            ?: parameters["label"]?.jsonPrimitive?.contentOrNull
            ?: return ToolResult(false, "Missing text", error = "MISSING_PARAMETER")
        val root = service.rootInActiveWindow ?: return ToolResult(false, "No active window", error = "NO_ROOT")
        val node = AccessibilityToolSet.findNode(root, text, byId = false) ?: return ToolResult(false, "Text not found: $text", error = "NODE_NOT_FOUND")
        return if (AccessibilityToolSet.clickNode(node)) ToolResult(true, "Clicked text: $text") else ToolResult(false, "Text not clicked: $text", error = "GESTURE_FAILED")
    }
}

class ClickByIdToolImpl : Tool() {
    override val definition = ToolDefinition("click_by_id", "Click element by resource id", "accessibility", listOf(ToolParameter("id", "Resource id", "string", true)))
    override suspend fun execute(parameters: JsonObject): ToolResult {
        val service = AccessibilityToolSet.service() ?: return AccessibilityToolSet.missingService()
        val root = service.rootInActiveWindow ?: return ToolResult(false, "No active window", error = "NO_ROOT")
        val id = parameters["id"]?.jsonPrimitive?.contentOrNull
            ?: parameters["resource_id"]?.jsonPrimitive?.contentOrNull
            ?: parameters["viewId"]?.jsonPrimitive?.contentOrNull
            ?: return ToolResult(false, "Missing id", error = "MISSING_PARAMETER")
        val node = AccessibilityToolSet.findNode(root, id, byId = true) ?: return ToolResult(false, "Id not found: $id", error = "NODE_NOT_FOUND")
        return if (AccessibilityToolSet.clickNode(node)) ToolResult(true, "Clicked id: $id") else ToolResult(false, "Click failed", error = "GESTURE_FAILED")
    }
}

class RepeatActionsAgentToolImpl : Tool() {
    override val definition = ToolDefinition("repeat_actions", "Repeat a list of tool actions", "accessibility", listOf(ToolParameter("actions", "Array of {toolName, parameters}", "array", true), ToolParameter("count", "Repeat count", "number")))
    override suspend fun execute(parameters: JsonObject): ToolResult {
        val actions = parameters["actions"]?.jsonArray ?: return ToolResult(false, "Missing actions", error = "MISSING_PARAMETER")
        val count = parameters["count"]?.jsonPrimitive?.intOrNull?.coerceIn(1, 50) ?: 1
        var executed = 0
        repeat(count) {
            for (action in actions) {
                val obj = action.jsonObject
                val name = obj["toolName"]?.jsonPrimitive?.contentOrNull ?: obj["name"]?.jsonPrimitive?.contentOrNull ?: return@repeat
                val params = obj["parameters"]?.jsonObject ?: JsonObject(emptyMap())
                val result = ToolRegistry.executeTool(ToolCall(name, params))
                executed++
                if (!result.success) return ToolResult(false, "Repeat failed at $name: ${result.message}", error = result.error)
            }
        }
        return ToolResult(true, "Repeated actions executed: $executed")
    }
}

class SendFileToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition("send_file", "Return a file path for channel delivery", "channel", listOf(ToolParameter("path", "Local file path", "string", true)))
    override suspend fun execute(parameters: JsonObject): ToolResult {
        val path = parameters["path"]?.jsonPrimitive?.contentOrNull.orEmpty()
        val file = File(path)
        return if (file.exists()) ToolResult(true, "File ready to send", buildJsonObject { put("path", file.absolutePath); put("size", file.length()) }) else ToolResult(false, "File not found", error = "FILE_NOT_FOUND")
    }
}

class FinishToolImpl : Tool() {
    override val definition = ToolDefinition("finish", "Finish the task and return summary", "agent", listOf(ToolParameter("summary", "Final summary", "string", true)))
    override suspend fun execute(parameters: JsonObject): ToolResult {
        val summary = parameters["summary"]?.jsonPrimitive?.contentOrNull ?: "Task finished"
        return ToolResult(true, summary, buildJsonObject { put("finished", true); put("summary", summary) })
    }
}

class SearchAppInStoreToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition("search_app_in_store", "Search app in app store by name", "system", listOf(ToolParameter("name", "App name", "string", true)))
    override suspend fun execute(parameters: JsonObject): ToolResult {
        val name = parameters["name"]?.jsonPrimitive?.contentOrNull
            ?: parameters["app"]?.jsonPrimitive?.contentOrNull
            ?: parameters["app_name"]?.jsonPrimitive?.contentOrNull
            ?: return ToolResult(false, "Missing app name", error = "MISSING_PARAMETER")
        val encodedName = Uri.encode(name)
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=$encodedName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            ToolResult(true, "Searching app store: $name")
        } catch (e: Exception) {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/search?q=$encodedName&c=apps")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            ToolResult(true, "Searching web app store: $name")
        }
    }
}

private fun global(action: Int, message: String): ToolResult {
    val service = AccessibilityToolSet.service() ?: return AccessibilityToolSet.missingService()
    return if (service.performGlobalAction(action)) ToolResult(true, message) else ToolResult(false, "Global action failed", error = "GLOBAL_ACTION_FAILED")
}
