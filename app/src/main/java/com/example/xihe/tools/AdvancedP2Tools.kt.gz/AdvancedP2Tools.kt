package com.example.xihe.tools

import android.content.Context
import com.example.xihe.nfc.NFCManager
import com.example.xihe.integration.AppIntegrationManager
import com.example.xihe.compression.CompressionManager
import com.example.xihe.maintenance.SystemMaintenanceManager
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive

// ==================== NFC工具 ====================

class CheckNFCToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "check_nfc",
        description = "检查NFC是否可用和开启",
        category = "NFC",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val nfcManager = NFCManager.getInstance(context)
            val isAvailable = nfcManager.isNFCAvailable()
            val isEnabled = nfcManager.isNFCEnabled()
            
            val message = when {
                !isAvailable -> "📲 设备不支持NFC"
                !isEnabled -> "📲 NFC未开启，请在设置中开启"
                else -> "✅ NFC已开启且可用"
            }
            ToolResult(true, message)
        } catch (e: Exception) {
            ToolResult(false, "检查NFC失败: ${e.message}")
        }
    }
}

class OpenNFCSettingsToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "open_nfc_settings",
        description = "打开NFC设置",
        category = "NFC",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val success = NFCManager.getInstance(context).openNFCSettings()
            if (success) {
                ToolResult(true, "✅ 已打开NFC设置")
            } else {
                ToolResult(false, "打开NFC设置失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "打开NFC设置失败: ${e.message}")
        }
    }
}

// ==================== 应用集成工具 ====================

class OpenWeChatToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "open_wechat",
        description = "打开微信",
        category = "应用集成",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val success = AppIntegrationManager.getInstance(context).openWeChat()
            if (success) {
                ToolResult(true, "✅ 已打开微信")
            } else {
                ToolResult(false, "打开微信失败，可能未安装")
            }
        } catch (e: Exception) {
            ToolResult(false, "打开微信失败: ${e.message}")
        }
    }
}

class OpenWeChatScanToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "open_wechat_scan",
        description = "打开微信扫一扫",
        category = "应用集成",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val success = AppIntegrationManager.getInstance(context).openWeChatScan()
            if (success) {
                ToolResult(true, "✅ 已打开微信扫一扫")
            } else {
                ToolResult(false, "打开微信扫一扫失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "打开微信扫一扫失败: ${e.message}")
        }
    }
}

class OpenAlipayToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "open_alipay",
        description = "打开支付宝",
        category = "应用集成",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val success = AppIntegrationManager.getInstance(context).openAlipay()
            if (success) {
                ToolResult(true, "✅ 已打开支付宝")
            } else {
                ToolResult(false, "打开支付宝失败，可能未安装")
            }
        } catch (e: Exception) {
            ToolResult(false, "打开支付宝失败: ${e.message}")
        }
    }
}

class OpenAlipayScanToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "open_alipay_scan",
        description = "打开支付宝扫一扫",
        category = "应用集成",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val success = AppIntegrationManager.getInstance(context).openAlipayScan()
            if (success) {
                ToolResult(true, "✅ 已打开支付宝扫一扫")
            } else {
                ToolResult(false, "打开支付宝扫一扫失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "打开支付宝扫一扫失败: ${e.message}")
        }
    }
}

class SearchOnTaobaoToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "search_on_taobao",
        description = "在淘宝搜索商品",
        category = "应用集成",
        parameters = listOf(
            ToolParameter("keyword", "string", "搜索关键词", required = true)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val keyword = parameters["keyword"]?.jsonPrimitive?.content
                ?: return ToolResult(false, "缺少keyword参数")
            
            val success = AppIntegrationManager.getInstance(context).searchOnTaobao(keyword)
            if (success) {
                ToolResult(true, "✅ 正在淘宝搜索: $keyword")
            } else {
                ToolResult(false, "淘宝搜索失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "淘宝搜索失败: ${e.message}")
        }
    }
}

class OpenInBrowserToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "open_in_browser",
        description = "在浏览器中打开网址",
        category = "应用集成",
        parameters = listOf(
            ToolParameter("url", "string", "网址URL", required = true)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val url = parameters["url"]?.jsonPrimitive?.content
                ?: return ToolResult(false, "缺少url参数")
            
            val success = AppIntegrationManager.getInstance(context).openInBrowser(url)
            if (success) {
                ToolResult(true, "✅ 已在浏览器中打开: $url")
            } else {
                ToolResult(false, "打开浏览器失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "打开浏览器失败: ${e.message}")
        }
    }
}

// ==================== 压缩工具 ====================

class CompressFileToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "compress_file",
        description = "压缩文件或文件夹为ZIP",
        category = "文件压缩",
        parameters = listOf(
            ToolParameter("input_path", "string", "输入文件或文件夹路径", required = true),
            ToolParameter("output_path", "string", "输出ZIP文件路径（可选）", required = false)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val inputPath = parameters["input_path"]?.jsonPrimitive?.content
                ?: return ToolResult(false, "缺少input_path参数")
            val outputPath = parameters["output_path"]?.jsonPrimitive?.content
            
            val result = CompressionManager.getInstance(context).compressFile(inputPath, outputPath)
            if (result.success) {
                ToolResult(true, "✅ 压缩完成: ${result.outputPath}\n压缩率: ${result.getCompressionRatioFormatted()}")
            } else {
                ToolResult(false, result.errorMessage ?: "压缩失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "压缩失败: ${e.message}")
        }
    }
}

class ExtractZipToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "extract_zip",
        description = "解压ZIP文件",
        category = "文件压缩",
        parameters = listOf(
            ToolParameter("zip_path", "string", "ZIP文件路径", required = true),
            ToolParameter("output_dir", "string", "输出目录（可选）", required = false)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val zipPath = parameters["zip_path"]?.jsonPrimitive?.content
                ?: return ToolResult(false, "缺少zip_path参数")
            val outputDir = parameters["output_dir"]?.jsonPrimitive?.content
            
            val result = CompressionManager.getInstance(context).extractZip(zipPath, outputDir)
            if (result.success) {
                ToolResult(true, "✅ 解压完成: ${result.outputDir}\n解压了 ${result.extractedFiles} 个文件")
            } else {
                ToolResult(false, result.errorMessage ?: "解压失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "解压失败: ${e.message}")
        }
    }
}

class ListZipContentsToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "list_zip_contents",
        description = "列出ZIP文件内容",
        category = "文件压缩",
        parameters = listOf(
            ToolParameter("zip_path", "string", "ZIP文件路径", required = true)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val zipPath = parameters["zip_path"]?.jsonPrimitive?.content
                ?: return ToolResult(false, "缺少zip_path参数")
            
            val contents = CompressionManager.getInstance(context).listZipContents(zipPath)
            if (contents.isEmpty()) {
                ToolResult(true, "ZIP文件为空或读取失败")
            } else {
                val summary = "ZIP文件包含 ${contents.size} 个条目：\n" +
                    contents.take(20).joinToString("\n") { item ->
                        val type = if (item.isDirectory) "📁" else "📄"
                        "$type ${item.name} (${item.getSizeFormatted()})"
                    }
                ToolResult(true, summary)
            }
        } catch (e: Exception) {
            ToolResult(false, "列出ZIP内容失败: ${e.message}")
        }
    }
}

// ==================== 系统维护工具 ====================

class ClearAppCacheToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "clear_app_cache",
        description = "清理应用缓存",
        category = "系统维护",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val result = SystemMaintenanceManager.getInstance(context).clearAppCache()
            if (result.success) {
                ToolResult(true, "🧹 清理缓存完成\n释放空间: ${result.getFreedSpaceFormatted()}\n删除文件: ${result.filesDeleted}个")
            } else {
                ToolResult(false, result.errorMessage ?: "清理缓存失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "清理缓存失败: ${e.message}")
        }
    }
}

class DeepCleanupToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "deep_cleanup",
        description = "深度清理（缓存+临时文件）",
        category = "系统维护",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val result = SystemMaintenanceManager.getInstance(context).deepCleanup()
            if (result.success) {
                ToolResult(true, "🧹 深度清理完成\n释放空间: ${result.getFreedSpaceFormatted()}\n删除文件: ${result.filesDeleted}个")
            } else {
                ToolResult(false, result.errorMessage ?: "深度清理失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "深度清理失败: ${e.message}")
        }
    }
}

class UninstallAppToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "uninstall_app",
        description = "卸载应用",
        category = "系统维护",
        parameters = listOf(
            ToolParameter("package_name", "string", "应用包名", required = true)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val packageName = parameters["package_name"]?.jsonPrimitive?.content
                ?: return ToolResult(false, "缺少package_name参数")
            
            val success = SystemMaintenanceManager.getInstance(context).uninstallApp(packageName)
            if (success) {
                ToolResult(true, "✅ 已打开卸载界面")
            } else {
                ToolResult(false, "打开卸载界面失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "卸载应用失败: ${e.message}")
        }
    }
}

class ForceStopAppToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "force_stop_app",
        description = "强制停止应用",
        category = "系统维护",
        parameters = listOf(
            ToolParameter("package_name", "string", "应用包名", required = true)
        )
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val packageName = parameters["package_name"]?.jsonPrimitive?.content
                ?: return ToolResult(false, "缺少package_name参数")
            
            val success = SystemMaintenanceManager.getInstance(context).forceStopApp(packageName)
            if (success) {
                ToolResult(true, "✅ 已强制停止应用: $packageName")
            } else {
                ToolResult(false, "强制停止应用失败")
            }
        } catch (e: Exception) {
            ToolResult(false, "强制停止应用失败: ${e.message}")
        }
    }
}

class GetOptimizationSuggestionsToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "get_optimization_suggestions",
        description = "获取系统优化建议",
        category = "系统维护",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val suggestions = SystemMaintenanceManager.getInstance(context).getOptimizationSuggestions()
            if (suggestions.isEmpty()) {
                ToolResult(true, "✅ 系统状态良好，暂无优化建议")
            } else {
                val summary = "📊 发现 ${suggestions.size} 条优化建议：\n\n" +
                    suggestions.joinToString("\n\n") { suggestion ->
                        val emoji = when (suggestion.severity) {
                            "high" -> "🔴"
                            "medium" -> "🟡"
                            else -> "🟢"
                        }
                        "$emoji ${suggestion.title}\n${suggestion.description}\n💡 建议: ${suggestion.action}"
                    }
                ToolResult(true, summary)
            }
        } catch (e: Exception) {
            ToolResult(false, "获取优化建议失败: ${e.message}")
        }
    }
}

class GetSystemInfoToolImpl(private val context: Context) : Tool() {
    override val definition = ToolDefinition(
        name = "get_system_info",
        description = "获取系统详细信息",
        category = "系统维护",
        parameters = emptyList()
    )
    
    override suspend fun execute(parameters: JsonObject): ToolResult {
        return try {
            val info = SystemMaintenanceManager.getInstance(context).getSystemInfo()
            val summary = "📊 系统信息\n\n" +
                "Android版本: ${info.androidVersion} (SDK ${info.sdkVersion})\n" +
                "设备制造商: ${info.manufacturer}\n" +
                "设备型号: ${info.model}\n" +
                "处理器核心数: ${info.totalProcessors}\n" +
                "总内存: ${info.totalMemory / (1024 * 1024)} MB\n" +
                "可用内存: ${info.availableMemory / (1024 * 1024)} MB"
            ToolResult(true, summary)
        } catch (e: Exception) {
            ToolResult(false, "获取系统信息失败: ${e.message}")
        }
    }
}
