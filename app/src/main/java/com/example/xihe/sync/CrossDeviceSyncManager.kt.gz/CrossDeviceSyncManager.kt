package com.example.xihe.sync

import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.intelligence.MemorySystem
import com.example.xihe.intelligence.EmotionRecognizer
import com.example.xihe.utils.DeviceStatusHelper
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.util.UUID

/**
 * 🔄 跨设备协同管理器
 * 实现多设备间的状态同步和协作
 */
class CrossDeviceSyncManager(private val context: Context) {
    
    companion object {
        private const val TAG = "CrossDeviceSync"
        
        // 同步间隔
        private const val SYNC_INTERVAL_MS = 30_000L // 30秒
        
        @Volatile
        private var instance: CrossDeviceSyncManager? = null
        
        fun getInstance(context: Context): CrossDeviceSyncManager {
            return instance ?: synchronized(this) {
                instance ?: CrossDeviceSyncManager(context.applicationContext).also {
                    instance = it
                }
            }
        }
    }
    
    // 设备ID
    private val deviceId = UUID.randomUUID().toString()
    
    // 设备类型
    private val deviceType = DeviceType.PHONE
    
    // 连接的设备列表
    private val _connectedDevices = MutableStateFlow<List<ConnectedDevice>>(emptyList())
    val connectedDevices = _connectedDevices.asStateFlow()
    
    // 同步状态
    private val _syncState = MutableStateFlow(SyncState.IDLE)
    val syncState = _syncState.asStateFlow()
    
    // 跨设备任务
    private var crossDeviceTask: CrossDeviceTask? = null
    
    // 记忆系统
    private val memorySystem = MemorySystem.getInstance(context)
    
    // 情绪识别
    private val emotionRecognizer = EmotionRecognizer.getInstance(context)
    
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var syncJob: Job? = null
    
    // 是否启用
    private var isEnabled = false
    
    /**
     * 🚀 启动跨设备同步
     */
    fun start() {
        if (isEnabled) {
            LogManager.d(TAG, "⚠️ 跨设备同步已在运行")
            return
        }
        
        LogManager.i(TAG, "启动跨设备同步系统")
        isEnabled = true
        
        // 注册设备
        registerDevice()
        
        // 启动同步任务
        startSyncTask()
        
        // 扫描附近设备
        scanNearbyDevices()
    }
    
    /**
     * 🛑 停止跨设备同步
     */
    fun stop() {
        LogManager.i(TAG, "停止跨设备同步系统")
        isEnabled = false
        syncJob?.cancel()
        syncJob = null
    }
    
    /**
     * 注册设备
     */
    private fun registerDevice() {
        LogManager.d(TAG, "注册设备: $deviceId ($deviceType)")
        
        // 本地注册：将设备信息存储到 SharedPreferences
        val prefs = context.getSharedPreferences("device_sync", Context.MODE_PRIVATE)
        prefs.edit().apply {
            putString("device_id", deviceId)
            putString("device_type", deviceType.name)
            putLong("register_time", System.currentTimeMillis())
            apply()
        }
        LogManager.d(TAG, "设备注册完成")
    }
    
    /**
     * 启动同步任务
     */
    private fun startSyncTask() {
        syncJob = scope.launch {
            while (isActive && isEnabled) {
                try {
                    delay(SYNC_INTERVAL_MS)
                    
                    // 同步用户数据
                    syncUserData()
                    
                    // 同步设备状态
                    syncDeviceState()
                    
                } catch (e: Exception) {
                    LogManager.e(TAG, "❌ 同步失败", e)
                }
            }
        }
    }
    
    /**
     * 🔍 扫描附近设备
     */
    private fun scanNearbyDevices() {
        scope.launch {
            LogManager.d(TAG, "🔍 扫描附近设备...")
            
            // 使用本地网络发现或 NSD (Network Service Discovery)
            // 目前使用模拟数据，未来可集成 Wi-Fi Direct 或 Nearby Connections API
            delay(2000)
            
            val mockDevices = listOf(
                ConnectedDevice(
                    id = UUID.randomUUID().toString(),
                    name = "主人的电脑",
                    type = DeviceType.COMPUTER,
                    status = DeviceStatus.ONLINE,
                    lastSyncTime = System.currentTimeMillis()
                ),
                ConnectedDevice(
                    id = UUID.randomUUID().toString(),
                    name = "主人的平板",
                    type = DeviceType.TABLET,
                    status = DeviceStatus.ONLINE,
                    lastSyncTime = System.currentTimeMillis()
                )
            )
            
            _connectedDevices.value = mockDevices
            LogManager.d(TAG, "✅ 发现 ${mockDevices.size} 台设备")
        }
    }
    
    /**
     * 📊 同步用户数据
     */
    private suspend fun syncUserData() {
        _syncState.value = SyncState.SYNCING
        
        try {
            // 同步用户画像
            val profile = memorySystem.userProfile.value
            val syncData = createSyncData(profile)
            
            LogManager.d(TAG, "📊 同步用户数据: ${syncData.length()} bytes")
            
            // 本地存储同步数据（未来可扩展为云同步）
            saveSyncDataLocally(syncData)
            
            _syncState.value = SyncState.SYNCED
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 同步用户数据失败", e)
            _syncState.value = SyncState.ERROR
        }
    }
    
    /**
     * 📱 同步设备状态
     */
    private suspend fun syncDeviceState() {
        try {
            val deviceState = DeviceState(
                deviceId = deviceId,
                deviceType = deviceType,
                batteryLevel = getBatteryLevel(),
                isCharging = isCharging(),
                currentApp = getCurrentApp(),
                screenOn = isScreenOn(),
                timestamp = System.currentTimeMillis()
            )
            
            LogManager.d(TAG, "📱 同步设备状态: ${deviceState.currentApp}")
            
            // 本地存储设备状态
            saveDeviceStateLocally(deviceState)
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 同步设备状态失败", e)
        }
    }
    
    /**
     * 📦 创建同步数据
     */
    private fun createSyncData(profile: com.example.xihe.intelligence.UserProfile): JSONObject {
        return JSONObject().apply {
            put("deviceId", deviceId)
            put("deviceType", deviceType.name)
            put("timestamp", System.currentTimeMillis())
            
            // 用户画像
            put("profile", JSONObject().apply {
                put("musicLikes", profile.preferences.musicLikes)
                put("foodLikes", profile.preferences.foodLikes)
                // ... 其他数据
            })
            
            // 情绪状态
            val emotion = emotionRecognizer.currentEmotion.value
            put("emotion", JSONObject().apply {
                put("type", emotion.emotion.name)
                put("intensity", emotion.intensity)
            })
        }
    }
    
    /**
     * 🔄 跨设备任务切换
     * 
     * 场景: 从手机切换到电脑
     */
    fun transferTask(targetDevice: ConnectedDevice, task: String) {
        LogManager.d(TAG, "🔄 任务切换: $task → ${targetDevice.name}")
        
        crossDeviceTask = CrossDeviceTask(
            taskId = UUID.randomUUID().toString(),
            taskType = TaskType.CONTENT_TRANSFER,
            content = task,
            sourceDevice = deviceId,
            targetDevice = targetDevice.id,
            status = TaskStatus.PENDING
        )
        
        // 发送任务到目标设备
        crossDeviceTask?.let { sendTaskToDevice(targetDevice, it) }
    }
    
    /**
     * 📤 发送任务到设备
     */
    private fun sendTaskToDevice(device: ConnectedDevice, task: CrossDeviceTask) {
        scope.launch {
            try {
                LogManager.d(TAG, "📤 发送任务到 ${device.name}")
                
                // 构建任务数据
                val taskJson = JSONObject().apply {
                    put("taskId", task.taskId)
                    put("taskType", task.taskType.name)
                    put("content", task.content)
                    put("sourceDevice", task.sourceDevice)
                    put("targetDevice", task.targetDevice)
                    put("timestamp", System.currentTimeMillis())
                }
                
                // 通过本地网络发送（使用 UDP 广播或 HTTP）
                val sendSuccess = sendViaLocalNetwork(device.address, taskJson)
                
                if (sendSuccess) {
                    task.status = TaskStatus.SENT
                    LogManager.d(TAG, "✅ 任务发送成功")
                } else {
                    task.status = TaskStatus.FAILED
                    LogManager.w(TAG, "⚠️ 任务发送失败，设备可能不在线")
                }
                
            } catch (e: Exception) {
                LogManager.e(TAG, "❌ 发送任务失败", e)
                task.status = TaskStatus.FAILED
            }
        }
    }
    
    private suspend fun sendViaLocalNetwork(address: String, data: JSONObject): Boolean {
        return kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val url = java.net.URL("http://$address:8765/sync")
                val connection = url.openConnection() as java.net.HttpURLConnection
                connection.requestMethod = "POST"
                connection.setRequestProperty("Content-Type", "application/json")
                connection.doOutput = true
                connection.connectTimeout = 5000
                connection.readTimeout = 5000
                
                connection.outputStream.use { os ->
                    os.write(data.toString().toByteArray())
                }
                
                val responseCode = connection.responseCode
                connection.disconnect()
                
                responseCode == 200
            } catch (e: Exception) {
                LogManager.e(TAG, "网络发送失败: ${e.message}")
                false
            }
        }
    }
    
    /**
     * 📥 接收任务
     */
    fun receiveTask(taskData: JSONObject) {
        try {
            val task = CrossDeviceTask(
                taskId = taskData.getString("taskId"),
                taskType = TaskType.valueOf(taskData.getString("taskType")),
                content = taskData.getString("content"),
                sourceDevice = taskData.getString("sourceDevice"),
                targetDevice = deviceId,
                status = TaskStatus.RECEIVED
            )
            
            LogManager.d(TAG, "📥 接收到任务: ${task.content}")
            
            // 处理任务
            handleReceivedTask(task)
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 接收任务失败", e)
        }
    }
    
    /**
     * ⚙️ 处理接收的任务
     */
    private fun handleReceivedTask(task: CrossDeviceTask) {
        when (task.taskType) {
            TaskType.CONTENT_TRANSFER -> {
                // 内容转移：保存内容到剪贴板或打开对应应用
                LogManager.d(TAG, "📝 处理内容转移: ${task.content}")
                saveContentToClipboard(task.content)
            }
            
            TaskType.STATE_SYNC -> {
                // 状态同步：更新本地缓存状态
                LogManager.d(TAG, "🔄 处理状态同步")
                updateLocalStateFromTask(task)
            }
            
            TaskType.NOTIFICATION -> {
                // 通知转发：显示本地通知
                LogManager.d(TAG, "🔔 处理通知转发")
                showLocalNotification(task.content)
            }
        }
        
        task.status = TaskStatus.COMPLETED
    }
    
    /**
     * 📋 保存内容到剪贴板
     */
    private fun saveContentToClipboard(content: String) {
        try {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            val clip = android.content.ClipData.newPlainText("跨设备内容", content)
            clipboard.setPrimaryClip(clip)
            LogManager.d(TAG, "📋 内容已复制到剪贴板")
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 复制到剪贴板失败", e)
        }
    }
    
    /**
     * 🔄 从任务更新本地状态
     */
    private fun updateLocalStateFromTask(task: CrossDeviceTask) {
        try {
            val stateData = JSONObject(task.content)
            val prefs = context.getSharedPreferences("remote_state", Context.MODE_PRIVATE)
            prefs.edit().apply {
                putString("remote_state_json", stateData.toString())
                putLong("remote_state_time", System.currentTimeMillis())
                apply()
            }
            LogManager.d(TAG, "🔄 本地状态已更新")
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 更新本地状态失败", e)
        }
    }
    
    /**
     * 🔔 显示本地通知
     */
    private fun showLocalNotification(content: String) {
        try {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            
            // 创建通知渠道 (Android 8.0+)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                val channel = android.app.NotificationChannel(
                    "cross_device",
                    "跨设备通知",
                    android.app.NotificationManager.IMPORTANCE_DEFAULT
                )
                notificationManager.createNotificationChannel(channel)
            }
            
            val notification = android.app.Notification.Builder(context, "cross_device")
                .setContentTitle("来自其他设备")
                .setContentText(content)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setAutoCancel(true)
                .build()
            
            notificationManager.notify(System.currentTimeMillis().toInt(), notification)
            LogManager.d(TAG, "🔔 通知已显示")
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 显示通知失败", e)
        }
    }
    
    /**
     * 📱 无缝切换场景
     * 
     * 场景1: 手机看视频 → 投屏到电视
     * 场景2: 电脑查资料 → 发送到手机
     * 场景3: 手机语音输入 → 同步到电脑
     */
    fun seamlessHandoff(scenario: HandoffScenario) {
        LogManager.d(TAG, "📱 无缝切换: $scenario")
        
        when (scenario) {
            HandoffScenario.VIDEO_TO_TV -> {
                LogManager.d(TAG, "📺 视频投屏到电视")
                // 查找电视设备并发送投屏请求
                val tvDevice = _connectedDevices.value.find { it.type == DeviceType.TV }
                if (tvDevice != null) {
                    transferTask(tvDevice, "CAST_VIDEO")
                } else {
                    LogManager.w(TAG, "⚠️ 未找到电视设备")
                }
            }
            
            HandoffScenario.RESEARCH_TO_PHONE -> {
                LogManager.d(TAG, "📱 资料发送到手机")
                // 查找手机设备并发送资料
                val phoneDevice = _connectedDevices.value.find { it.type == DeviceType.PHONE && it.id != deviceId }
                if (phoneDevice != null) {
                    transferTask(phoneDevice, "TRANSFER_RESEARCH")
                } else {
                    LogManager.w(TAG, "⚠️ 未找到其他手机设备")
                }
            }
            
            HandoffScenario.VOICE_INPUT_SYNC -> {
                LogManager.d(TAG, "🎤 语音输入同步")
                // 同步语音输入到电脑设备
                val computerDevice = _connectedDevices.value.find { it.type == DeviceType.COMPUTER }
                if (computerDevice != null) {
                    transferTask(computerDevice, "SYNC_VOICE_INPUT")
                } else {
                    LogManager.w(TAG, "⚠️ 未找到电脑设备")
                }
            }
        }
    }
    
    /**
     * 🔋 获取电池电量
     * 🆕 使用 DeviceStatusHelper 获取真实值
     */
    private fun getBatteryLevel(): Int {
        return DeviceStatusHelper.getBatteryLevel(context)
    }
    
    /**
     * 🔌 是否正在充电
     * 🆕 使用 DeviceStatusHelper 获取真实值
     */
    private fun isCharging(): Boolean {
        return DeviceStatusHelper.isCharging(context)
    }
    
    /**
     * 📱 获取当前应用
     * 🆕 使用 DeviceStatusHelper 获取真实值
     */
    private fun getCurrentApp(): String {
        return DeviceStatusHelper.getCurrentForegroundApp(context) ?: "羲和AI"
    }
    
    /**
     * 📺 屏幕是否点亮
     * 🆕 使用 DeviceStatusHelper 获取真实值
     */
    private fun isScreenOn(): Boolean {
        return DeviceStatusHelper.isScreenOn(context)
    }
    
    /**
     * 💾 本地存储同步数据
     */
    private fun saveSyncDataLocally(syncData: JSONObject) {
        try {
            val prefs = context.getSharedPreferences("sync_data", Context.MODE_PRIVATE)
            prefs.edit().apply {
                putString("last_sync_data", syncData.toString())
                putLong("last_sync_time", System.currentTimeMillis())
                apply()
            }
            LogManager.d(TAG, "💾 同步数据已本地存储")
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 存储同步数据失败", e)
        }
    }
    
    /**
     * 💾 本地存储设备状态
     */
    private fun saveDeviceStateLocally(deviceState: DeviceState) {
        try {
            val prefs = context.getSharedPreferences("device_state", Context.MODE_PRIVATE)
            prefs.edit().apply {
                putString("device_id", deviceState.deviceId)
                putString("device_type", deviceState.deviceType.name)
                putInt("battery_level", deviceState.batteryLevel)
                putBoolean("is_charging", deviceState.isCharging)
                putString("current_app", deviceState.currentApp)
                putBoolean("screen_on", deviceState.screenOn)
                putLong("timestamp", deviceState.timestamp)
                apply()
            }
            LogManager.d(TAG, "💾 设备状态已本地存储")
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 存储设备状态失败", e)
        }
    }
    
    /**
     * 📖 读取本地同步数据
     */
    fun getLocalSyncData(): JSONObject? {
        return try {
            val prefs = context.getSharedPreferences("sync_data", Context.MODE_PRIVATE)
            val dataStr = prefs.getString("last_sync_data", null)
            dataStr?.let { JSONObject(it) }
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 读取同步数据失败", e)
            null
        }
    }
    
    /**
     * ⏰ 获取上次同步时间
     */
    fun getLastSyncTime(): Long {
        val prefs = context.getSharedPreferences("sync_data", Context.MODE_PRIVATE)
        return prefs.getLong("last_sync_time", 0)
    }
}

/**
 * 📱 设备类型
 */
enum class DeviceType {
    PHONE,      // 手机
    TABLET,     // 平板
    COMPUTER,   // 电脑
    WATCH,      // 手表
    TV,         // 电视
    SPEAKER     // 音箱
}

/**
 * 🔗 设备状态
 */
enum class DeviceStatus {
    ONLINE,     // 在线
    OFFLINE,    // 离线
    BUSY        // 忙碌
}

/**
 * 🔄 同步状态
 */
enum class SyncState {
    IDLE,       // 空闲
    SYNCING,    // 同步中
    SYNCED,     // 已同步
    ERROR       // 错误
}

/**
 * 📋 任务类型
 */
enum class TaskType {
    CONTENT_TRANSFER,   // 内容转移
    STATE_SYNC,         // 状态同步
    NOTIFICATION        // 通知
}

/**
 * ⚙️ 任务状态
 */
enum class TaskStatus {
    PENDING,    // 等待中
    SENT,       // 已发送
    RECEIVED,   // 已接收
    COMPLETED,  // 已完成
    FAILED      // 失败
}

/**
 * 📱 切换场景
 */
enum class HandoffScenario {
    VIDEO_TO_TV,            // 视频到电视
    RESEARCH_TO_PHONE,      // 资料到手机
    VOICE_INPUT_SYNC        // 语音输入同步
}

/**
 * 📱 连接的设备
 */
data class ConnectedDevice(
    val id: String,
    val name: String,
    val type: DeviceType,
    val status: DeviceStatus,
    val lastSyncTime: Long,
    val address: String = "192.168.1.1"
)

/**
 * 📊 设备状态
 */
data class DeviceState(
    val deviceId: String,
    val deviceType: DeviceType,
    val batteryLevel: Int,
    val isCharging: Boolean,
    val currentApp: String,
    val screenOn: Boolean,
    val timestamp: Long
)

/**
 * 📋 跨设备任务
 */
data class CrossDeviceTask(
    val taskId: String,
    val taskType: TaskType,
    val content: String,
    val sourceDevice: String,
    val targetDevice: String,
    var status: TaskStatus
)
