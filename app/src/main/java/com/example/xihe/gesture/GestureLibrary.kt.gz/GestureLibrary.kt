package com.example.xihe.gesture

import android.content.Context
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

/**
 * 手势库
 * 管理所有录制的手势
 */
class GestureLibrary(private val context: Context) {
    
    companion object {
        private const val TAG = "GestureLibrary"
        private const val GESTURES_DIR = "gestures"
        private const val GESTURE_FILE_EXTENSION = ".gesture"
        
        @Volatile
        private var instance: GestureLibrary? = null
        
        fun getInstance(context: Context): GestureLibrary {
            return instance ?: synchronized(this) {
                instance ?: GestureLibrary(context.applicationContext).also { instance = it }
            }
        }
    }
    
    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
    }
    
    private val gesturesMap = mutableMapOf<String, RecordedGesture>()
    private val _gestures = MutableStateFlow<List<RecordedGesture>>(emptyList())
    val gestures = _gestures.asStateFlow()
    
    private val gesturesDir: File by lazy {
        File(context.filesDir, GESTURES_DIR).apply {
            if (!exists()) {
                mkdirs()
            }
        }
    }
    
    init {
        loadGestures()
    }
    
    /**
     * 保存手势
     */
    suspend fun saveGesture(gesture: RecordedGesture): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val file = File(gesturesDir, "${gesture.id}$GESTURE_FILE_EXTENSION")
                val jsonString = json.encodeToString(gesture)
                file.writeText(jsonString)
                
                gesturesMap[gesture.id] = gesture
                updateGesturesList()
                
                LogManager.d(TAG, " 手势已保存: ${gesture.name}")
                true
            } catch (e: Exception) {
                LogManager.d(TAG, " 保存手势失败", e)
                false
            }
        }
    }
    
    /**
     * 删除手势
     */
    suspend fun deleteGesture(gestureId: String): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val file = File(gesturesDir, "$gestureId$GESTURE_FILE_EXTENSION")
                val deleted = file.delete()
                
                if (deleted) {
                    gesturesMap.remove(gestureId)
                    updateGesturesList()
                    LogManager.d(TAG, " 手势已删除: $gestureId")
                }
                
                deleted
            } catch (e: Exception) {
                LogManager.d(TAG, " 删除手势失败", e)
                false
            }
        }
    }
    
    /**
     * 加载所有手势
     */
    private fun loadGestures() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val files = gesturesDir.listFiles { file ->
                    file.extension == GESTURE_FILE_EXTENSION.removePrefix(".")
                }
                
                files?.forEach { file ->
                    try {
                        val jsonString = file.readText()
                        val gesture = json.decodeFromString<RecordedGesture>(jsonString)
                        gesturesMap[gesture.id] = gesture
                    } catch (e: Exception) {
                        LogManager.d(TAG, " 加载手势文件失败: ${file.name}", e)
                    }
                }
                
                updateGesturesList()
                LogManager.d(TAG, " 已加载 ${gesturesMap.size} 个手势")
                
            } catch (e: Exception) {
                LogManager.d(TAG, " 加载手势库失败", e)
            }
        }
    }
    
    /**
     * 根据ID获取手势
     */
    fun getGestureById(id: String): RecordedGesture? {
        return gesturesMap[id]
    }
    
    /**
     * 根据名称搜索手势
     */
    fun searchByName(query: String): List<RecordedGesture> {
        if (query.isBlank()) return gesturesMap.values.toList()
        
        return gesturesMap.values.filter { gesture ->
            gesture.name.contains(query, ignoreCase = true) ||
            gesture.description.contains(query, ignoreCase = true)
        }
    }
    
    /**
     * 根据标签搜索手势
     */
    fun searchByTags(tags: List<String>): List<RecordedGesture> {
        if (tags.isEmpty()) return gesturesMap.values.toList()
        
        return gesturesMap.values.filter { gesture ->
            tags.any { tag -> gesture.tags.contains(tag) }
        }
    }
    
    /**
     * 根据分类获取手势
     */
    fun getGesturesByCategory(category: GestureCategory): List<RecordedGesture> {
        return gesturesMap.values.filter { it.category == category }
    }
    
    /**
     * 导出手势（JSON格式）
     */
    fun exportGesture(gestureId: String): String? {
        val gesture = gesturesMap[gestureId] ?: return null
        return try {
            json.encodeToString(gesture)
        } catch (e: Exception) {
            LogManager.d(TAG, " 导出手势失败", e)
            null
        }
    }
    
    /**
     * 导入手势（JSON格式）
     */
    suspend fun importGesture(jsonString: String): RecordedGesture? {
        return try {
            val gesture = json.decodeFromString<RecordedGesture>(jsonString)
            if (saveGesture(gesture)) {
                LogManager.d(TAG, " 手势导入成功: ${gesture.name}")
                gesture
            } else {
                null
            }
        } catch (e: Exception) {
            LogManager.d(TAG, " 导入手势失败", e)
            null
        }
    }
    
    /**
     * 获取统计信息
     */
    fun getStatistics(): GestureStatistics {
        val totalCount = gesturesMap.size
        val categoryCounts = gesturesMap.values
            .groupBy { it.category }
            .mapValues { it.value.size }
        
        val avgDuration = gesturesMap.values
            .map { it.duration }
            .average()
        
        val avgActionCount = gesturesMap.values
            .map { it.actions.size }
            .average()
        
        return GestureStatistics(
            totalCount = totalCount,
            categoryCounts = categoryCounts,
            averageDuration = avgDuration.toLong(),
            averageActionCount = avgActionCount.toInt()
        )
    }
    
    /**
     * 🔄 更新手势列表
     */
    private fun updateGesturesList() {
        _gestures.value = gesturesMap.values
            .sortedByDescending { it.createdAt }
    }
    
    /**
     * 📊 统计信息
     */
    data class GestureStatistics(
        val totalCount: Int,
        val categoryCounts: Map<GestureCategory, Int>,
        val averageDuration: Long,
        val averageActionCount: Int
    )
}
