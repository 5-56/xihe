package com.example.xihe.gesture

import com.example.xihe.utils.LogManager
import kotlin.math.*

/**
 * 🎨 手势优化器
 * 对录制的手势进行优化处理
 */
object GestureOptimizer {
    
    private const val TAG = "GestureOptimizer"
    
    /**
     * 🎯 优化手势（综合优化）
     */
    fun optimizeGesture(gesture: RecordedGesture): RecordedGesture {
        LogManager.d(TAG, "🎯 开始优化手势: ${gesture.name}")
        
        var optimizedActions = gesture.actions
        
        // 1. 去除抖动
        optimizedActions = removeJitter(optimizedActions)
        
        // 2. 路径平滑
        optimizedActions = smoothPath(optimizedActions)
        
        // 3. 简化路径
        optimizedActions = simplifyPath(optimizedActions)
        
        // 4. 优化时间间隔
        optimizedActions = optimizeTimings(optimizedActions)
        
        val optimizedGesture = gesture.copy(actions = optimizedActions)
        
        LogManager.d(TAG, "✅ 优化完成: ${gesture.actions.size} -> ${optimizedActions.size} 个动作")
        
        return optimizedGesture
    }
    
    /**
     * 🔧 去除抖动
     * 移除过于频繁的微小移动
     */
    private fun removeJitter(actions: List<GestureAction>): List<GestureAction> {
        if (actions.size < 3) return actions
        
        val result = mutableListOf<GestureAction>()
        val minDistance = 5f // 最小移动距离阈值
        
        var lastX = 0f
        var lastY = 0f
        var isFirst = true
        
        for (action in actions) {
            when (action) {
                is GestureAction.Touch -> {
                    result.add(action)
                    lastX = action.x
                    lastY = action.y
                    isFirst = true
                }
                
                is GestureAction.Move -> {
                    if (isFirst) {
                        result.add(action)
                        lastX = action.x
                        lastY = action.y
                        isFirst = false
                    } else {
                        val distance = calculateDistance(lastX, lastY, action.x, action.y)
                        if (distance >= minDistance) {
                            result.add(action)
                            lastX = action.x
                            lastY = action.y
                        }
                    }
                }
                
                is GestureAction.Release -> {
                    result.add(action)
                }
                
                is GestureAction.Wait -> {
                    result.add(action)
                }
            }
        }
        
        return result
    }
    
    /**
     * 🎨 路径平滑（移动平均）
     */
    private fun smoothPath(actions: List<GestureAction>): List<GestureAction> {
        if (actions.size < 5) return actions
        
        val result = mutableListOf<GestureAction>()
        val windowSize = 5
        
        for (i in actions.indices) {
            val action = actions[i]
            
            if (action is GestureAction.Move) {
                // 获取窗口内的动作
                val start = maxOf(0, i - windowSize / 2)
                val end = minOf(actions.size, i + windowSize / 2 + 1)
                val window = actions.subList(start, end)
                    .filterIsInstance<GestureAction.Move>()
                    .filter { it.pointerId == action.pointerId }
                
                if (window.isNotEmpty()) {
                    // 计算平均位置
                    val avgX = window.map { it.x }.average().toFloat()
                    val avgY = window.map { it.y }.average().toFloat()
                    
                    result.add(action.copy(x = avgX, y = avgY))
                } else {
                    result.add(action)
                }
            } else {
                result.add(action)
            }
        }
        
        return result
    }
    
    /**
     * ✂️ 简化路径（Douglas-Peucker算法）
     */
    private fun simplifyPath(actions: List<GestureAction>): List<GestureAction> {
        val result = mutableListOf<GestureAction>()
        val epsilon = 10f // 简化阈值
        
        // 按指针ID分组
        val actionsByPointer = actions.groupBy { it.pointerId }
        
        for ((pointerId, pointerActions) in actionsByPointer) {
            val simplified = douglasPeucker(pointerActions, epsilon)
            result.addAll(simplified)
        }
        
        // 按时间戳排序
        return result.sortedBy { it.timestamp }
    }
    
    /**
     * 📐 Douglas-Peucker算法实现
     */
    private fun douglasPeucker(
        actions: List<GestureAction>,
        epsilon: Float
    ): List<GestureAction> {
        if (actions.size < 3) return actions
        
        // 提取移动动作
        val moves = actions.filterIsInstance<GestureAction.Move>()
        if (moves.size < 3) return actions
        
        // 找到距离起点和终点连线最远的点
        val start = moves.first()
        val end = moves.last()
        var maxDistance = 0f
        var maxIndex = 0
        
        for (i in 1 until moves.size - 1) {
            val distance = perpendicularDistance(
                moves[i].x, moves[i].y,
                start.x, start.y,
                end.x, end.y
            )
            if (distance > maxDistance) {
                maxDistance = distance
                maxIndex = i
            }
        }
        
        // 如果最大距离大于阈值，递归简化
        if (maxDistance > epsilon) {
            val left = douglasPeucker(moves.subList(0, maxIndex + 1), epsilon)
            val right = douglasPeucker(moves.subList(maxIndex, moves.size), epsilon)
            return (left + right.drop(1))
        } else {
            return listOf(start, end)
        }
    }
    
    /**
     * 📏 点到直线的垂直距离
     */
    private fun perpendicularDistance(
        px: Float, py: Float,
        x1: Float, y1: Float,
        x2: Float, y2: Float
    ): Float {
        val dx = x2 - x1
        val dy = y2 - y1
        
        if (dx == 0f && dy == 0f) {
            return calculateDistance(px, py, x1, y1)
        }
        
        val t = ((px - x1) * dx + (py - y1) * dy) / (dx * dx + dy * dy)
        
        val nearestX = x1 + t * dx
        val nearestY = y1 + t * dy
        
        return calculateDistance(px, py, nearestX, nearestY)
    }
    
    /**
     * ⏱️ 优化时间间隔
     * 调整动作之间的时间间隔，使手势更自然
     */
    private fun optimizeTimings(actions: List<GestureAction>): List<GestureAction> {
        if (actions.size < 2) return actions
        
        val result = mutableListOf<GestureAction>()
        var currentTime = 0L
        val minInterval = 16L // 最小间隔（约60fps）
        
        for (i in actions.indices) {
            val action = actions[i]
            val nextTime = if (i < actions.size - 1) {
                val interval = actions[i + 1].timestamp - action.timestamp
                currentTime + maxOf(interval, minInterval)
            } else {
                action.timestamp
            }
            
            val optimizedAction = when (action) {
                is GestureAction.Touch -> action.copy(timestamp = currentTime)
                is GestureAction.Move -> action.copy(timestamp = currentTime)
                is GestureAction.Release -> action.copy(timestamp = currentTime)
                is GestureAction.Wait -> action.copy(timestamp = currentTime)
            }
            
            result.add(optimizedAction)
            currentTime = nextTime
        }
        
        return result
    }
    
    /**
     * 🌊 生成贝塞尔曲线路径
     * 将直线路径转换为平滑的曲线路径
     */
    fun generateBezierPath(
        start: Pair<Float, Float>,
        end: Pair<Float, Float>,
        controlPoints: List<Pair<Float, Float>> = emptyList()
    ): List<Pair<Float, Float>> {
        val points = mutableListOf<Pair<Float, Float>>()
        val segments = 20 // 曲线分段数
        
        if (controlPoints.isEmpty()) {
            // 二次贝塞尔曲线（单个控制点）
            val control = Pair(
                (start.first + end.first) / 2,
                (start.second + end.second) / 2 - 50
            )
            
            for (i in 0..segments) {
                val t = i.toFloat() / segments
                val x = (1 - t) * (1 - t) * start.first +
                        2 * (1 - t) * t * control.first +
                        t * t * end.first
                val y = (1 - t) * (1 - t) * start.second +
                        2 * (1 - t) * t * control.second +
                        t * t * end.second
                points.add(Pair(x, y))
            }
        } else if (controlPoints.size == 1) {
            // 二次贝塞尔曲线
            val control = controlPoints[0]
            for (i in 0..segments) {
                val t = i.toFloat() / segments
                val x = (1 - t) * (1 - t) * start.first +
                        2 * (1 - t) * t * control.first +
                        t * t * end.first
                val y = (1 - t) * (1 - t) * start.second +
                        2 * (1 - t) * t * control.second +
                        t * t * end.second
                points.add(Pair(x, y))
            }
        } else {
            // 三次贝塞尔曲线
            val control1 = controlPoints[0]
            val control2 = controlPoints[1]
            
            for (i in 0..segments) {
                val t = i.toFloat() / segments
                val x = (1 - t) * (1 - t) * (1 - t) * start.first +
                        3 * (1 - t) * (1 - t) * t * control1.first +
                        3 * (1 - t) * t * t * control2.first +
                        t * t * t * end.first
                val y = (1 - t) * (1 - t) * (1 - t) * start.second +
                        3 * (1 - t) * (1 - t) * t * control1.second +
                        3 * (1 - t) * t * t * control2.second +
                        t * t * t * end.second
                points.add(Pair(x, y))
            }
        }
        
        return points
    }
    
    /**
     * 🎯 添加惯性效果
     * 使手势结束时更自然（减速）
     */
    fun addInertia(actions: List<GestureAction>): List<GestureAction> {
        if (actions.size < 3) return actions
        
        val result = actions.toMutableList()
        val lastMoves = actions.filterIsInstance<GestureAction.Move>().takeLast(5)
        
        if (lastMoves.size >= 2) {
            // 计算最后的移动方向和速度
            val last = lastMoves.last()
            val secondLast = lastMoves[lastMoves.size - 2]
            
            val dx = last.x - secondLast.x
            val dy = last.y - secondLast.y
            val distance = sqrt(dx * dx + dy * dy)
            
            if (distance > 10) {
                // 添加减速的移动
                val inertiaSteps = 5
                for (i in 1..inertiaSteps) {
                    val factor = 1 - (i.toFloat() / inertiaSteps)
                    val newX = last.x + dx * factor * 0.5f
                    val newY = last.y + dy * factor * 0.5f
                    
                    result.add(GestureAction.Move(
                        x = newX,
                        y = newY,
                        timestamp = last.timestamp + i * 16L,
                        pointerId = last.pointerId
                    ))
                }
            }
        }
        
        return result
    }
    
    /**
     * 📊 分析手势特征
     */
    fun analyzeGesture(gesture: RecordedGesture): GestureAnalysis {
        val moves = gesture.actions.filterIsInstance<GestureAction.Move>()
        
        if (moves.isEmpty()) {
            return GestureAnalysis(
                totalDistance = 0f,
                averageSpeed = 0f,
                maxSpeed = 0f,
                smoothness = 1f,
                complexity = 1
            )
        }
        
        // 计算总距离
        var totalDistance = 0f
        for (i in 1 until moves.size) {
            totalDistance += calculateDistance(
                moves[i - 1].x, moves[i - 1].y,
                moves[i].x, moves[i].y
            )
        }
        
        // 计算平均速度
        val duration = (moves.last().timestamp - moves.first().timestamp).toFloat()
        val averageSpeed = if (duration > 0) totalDistance / duration else 0f
        
        // 计算最大速度
        var maxSpeed = 0f
        for (i in 1 until moves.size) {
            val distance = calculateDistance(
                moves[i - 1].x, moves[i - 1].y,
                moves[i].x, moves[i].y
            )
            val time = (moves[i].timestamp - moves[i - 1].timestamp).toFloat()
            val speed = if (time > 0) distance / time else 0f
            maxSpeed = maxOf(maxSpeed, speed)
        }
        
        // 计算平滑度（方向变化）
        var directionChanges = 0
        for (i in 2 until moves.size) {
            val angle1 = atan2(
                moves[i - 1].y - moves[i - 2].y,
                moves[i - 1].x - moves[i - 2].x
            )
            val angle2 = atan2(
                moves[i].y - moves[i - 1].y,
                moves[i].x - moves[i - 1].x
            )
            val angleDiff = abs(angle1 - angle2)
            if (angleDiff > PI / 4) { // 45度以上算方向变化
                directionChanges++
            }
        }
        val smoothness = 1f - (directionChanges.toFloat() / moves.size)
        
        return GestureAnalysis(
            totalDistance = totalDistance,
            averageSpeed = averageSpeed,
            maxSpeed = maxSpeed,
            smoothness = smoothness,
            complexity = moves.size
        )
    }
    
    /**
     * 📏 计算两点距离
     */
    private fun calculateDistance(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x2 - x1
        val dy = y2 - y1
        return sqrt(dx * dx + dy * dy)
    }
    
    /**
     * 📊 手势分析结果
     */
    data class GestureAnalysis(
        val totalDistance: Float,      // 总移动距离
        val averageSpeed: Float,        // 平均速度
        val maxSpeed: Float,            // 最大速度
        val smoothness: Float,          // 平滑度（0-1）
        val complexity: Int             // 复杂度（动作数量）
    )
}
