package com.example.xihe.gesture

import android.accessibilityservice.GestureDescription
import android.graphics.Path
import com.example.xihe.utils.LogManager
import com.example.xihe.service.EnhancedAccessibilityService
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * ▶️ 手势回放器
 * 用于回放录制的手势
 */
class GesturePlayer {
    
    companion object {
        private const val TAG = "GesturePlayer"
        private const val DEFAULT_SPEED = 1.0f
    }
    
    private val _playbackState = MutableStateFlow<PlaybackState>(PlaybackState.Idle)
    val playbackState = _playbackState.asStateFlow()
    
    private var playbackJob: Job? = null
    
    /**
     * ▶️ 回放手势
     * @param gesture 要回放的手势
     * @param speedMultiplier 速度倍数（1.0 = 正常速度，2.0 = 2倍速）
     * @param loop 是否循环播放
     */
    suspend fun playGesture(
        gesture: RecordedGesture,
        speedMultiplier: Float = DEFAULT_SPEED,
        loop: Boolean = false
    ): Boolean {
        return withContext(Dispatchers.Main) {
            try {
                val accessibilityService = EnhancedAccessibilityService.getInstance()
                if (accessibilityService == null) {
                    LogManager.w(TAG, "❌ 无障碍服务未启动")
                    return@withContext false
                }
                
                _playbackState.value = PlaybackState.Playing(
                    gestureName = gesture.name,
                    progress = 0f
                )
                
                LogManager.i(TAG, "▶️ 开始回放手势: ${gesture.name}, 速度: ${speedMultiplier}x")
                
                do {
                    val success = playGestureOnce(gesture, speedMultiplier, accessibilityService)
                    if (!success) {
                        _playbackState.value = PlaybackState.Error("回放失败")
                        return@withContext false
                    }
                    
                    if (loop) {
                        delay(500) // 循环间隔
                    }
                } while (loop && _playbackState.value is PlaybackState.Playing)
                
                _playbackState.value = PlaybackState.Completed
                LogManager.i(TAG, "✅ 手势回放完成")
                true
                
            } catch (e: Exception) {
                LogManager.e(TAG, "❌ 手势回放失败", e)
                _playbackState.value = PlaybackState.Error(e.message ?: "未知错误")
                false
            }
        }
    }
    
    /**
     * 回放一次手势
     */
    private suspend fun playGestureOnce(
        gesture: RecordedGesture,
        speedMultiplier: Float,
        accessibilityService: EnhancedAccessibilityService
    ): Boolean {
        // 按指针ID分组动作
        val actionsByPointer = gesture.actions.groupBy { it.pointerId }
        
        // 如果是单点触控，使用简单回放
        if (actionsByPointer.size == 1) {
            return playSingleTouchGesture(gesture, speedMultiplier, accessibilityService)
        }
        
        // 多点触控，需要同步处理
        return playMultiTouchGesture(gesture, speedMultiplier, accessibilityService)
    }
    
    /**
     * 回放单点触控手势
     */
    private suspend fun playSingleTouchGesture(
        gesture: RecordedGesture,
        speedMultiplier: Float,
        accessibilityService: EnhancedAccessibilityService
    ): Boolean {
        val path = Path()
        var startX = 0f
        var startY = 0f
        var lastTimestamp = 0L
        var pathStarted = false
        
        for ((index, action) in gesture.actions.withIndex()) {
            // 更新进度
            val progress = (index + 1).toFloat() / gesture.actions.size
            _playbackState.value = PlaybackState.Playing(
                gestureName = gesture.name,
                progress = progress
            )
            
            // 等待到正确的时间点
            val delay = ((action.timestamp - lastTimestamp) / speedMultiplier).toLong()
            if (delay > 0) {
                delay(delay)
            }
            
            when (action) {
                is GestureAction.Touch -> {
                    startX = action.x
                    startY = action.y
                    path.moveTo(action.x, action.y)
                    pathStarted = true
                }
                
                is GestureAction.Move -> {
                    if (pathStarted) {
                        path.lineTo(action.x, action.y)
                    }
                }
                
                is GestureAction.Release -> {
                    if (pathStarted) {
                        // 执行手势
                        val duration = ((action.timestamp / speedMultiplier).toLong()).coerceIn(1, 60000)
                        
                        val gestureBuilder = GestureDescription.Builder()
                        val strokeDescription = GestureDescription.StrokeDescription(
                            path,
                            0,
                            duration
                        )
                        gestureBuilder.addStroke(strokeDescription)
                        
                        val result = CompletableDeferred<Boolean>()
                        accessibilityService.dispatchGesture(
                            gestureBuilder.build(),
                            object : android.accessibilityservice.AccessibilityService.GestureResultCallback() {
                                override fun onCompleted(gestureDescription: GestureDescription?) {
                                    result.complete(true)
                                }
                                
                                override fun onCancelled(gestureDescription: GestureDescription?) {
                                    result.complete(false)
                                }
                            },
                            null
                        )
                        
                        if (!result.await()) {
                            LogManager.e(TAG, "❌ 手势执行失败")
                            return false
                        }
                        
                        // 重置路径
                        path.reset()
                        pathStarted = false
                    }
                }
                
                is GestureAction.Wait -> {
                    delay(action.duration)
                }
            }
            
            lastTimestamp = action.timestamp
        }
        
        return true
    }
    
    /**
     * 回放多点触控手势
     */
    private suspend fun playMultiTouchGesture(
        gesture: RecordedGesture,
        speedMultiplier: Float,
        accessibilityService: EnhancedAccessibilityService
    ): Boolean {
        // 按指针ID分组
        val actionsByPointer = gesture.actions.groupBy { it.pointerId }
        val paths = mutableMapOf<Int, Path>()
        val startTimes = mutableMapOf<Int, Long>()
        val endTimes = mutableMapOf<Int, Long>()
        
        // 为每个指针创建路径
        for ((pointerId, actions) in actionsByPointer) {
            val path = Path()
            var pathStarted = false
            
            for (action in actions) {
                when (action) {
                    is GestureAction.Touch -> {
                        path.moveTo(action.x, action.y)
                        pathStarted = true
                        startTimes[pointerId] = (action.timestamp / speedMultiplier).toLong()
                    }
                    
                    is GestureAction.Move -> {
                        if (pathStarted) {
                            path.lineTo(action.x, action.y)
                        }
                    }
                    
                    is GestureAction.Release -> {
                        endTimes[pointerId] = (action.timestamp / speedMultiplier).toLong()
                    }
                    
                    else -> {}
                }
            }
            
            paths[pointerId] = path
        }
        
        // 构建多点触控手势
        val gestureBuilder = GestureDescription.Builder()
        
        for ((pointerId, path) in paths) {
            val startTime = startTimes[pointerId] ?: 0L
            val endTime = endTimes[pointerId] ?: gesture.duration
            val duration = ((endTime - startTime) / speedMultiplier).toLong().coerceIn(1, 60000)
            
            val strokeDescription = GestureDescription.StrokeDescription(
                path,
                startTime,
                duration
            )
            gestureBuilder.addStroke(strokeDescription)
        }
        
        // 执行手势
        val result = CompletableDeferred<Boolean>()
        accessibilityService.dispatchGesture(
            gestureBuilder.build(),
            object : android.accessibilityservice.AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    result.complete(true)
                }
                
                override fun onCancelled(gestureDescription: GestureDescription?) {
                    result.complete(false)
                }
            },
            null
        )
        
        return result.await()
    }
    
    /**
     * ⏸️ 暂停回放
     */
    fun pausePlayback() {
        playbackJob?.cancel()
        _playbackState.value = PlaybackState.Paused
        LogManager.d(TAG, "⏸️ 暂停回放")
    }
    
    /**
     * ⏹️ 停止回放
     */
    fun stopPlayback() {
        playbackJob?.cancel()
        _playbackState.value = PlaybackState.Idle
        LogManager.d(TAG, "⏹️ 停止回放")
    }
    
    /**
     * 回放状态
     */
    sealed class PlaybackState {
        object Idle : PlaybackState()
        
        data class Playing(
            val gestureName: String,
            val progress: Float
        ) : PlaybackState()
        
        object Paused : PlaybackState()
        object Completed : PlaybackState()
        
        data class Error(
            val message: String
        ) : PlaybackState()
    }
}
