package com.example.xihe.gesture

import android.content.Context
import com.example.xihe.utils.LogManager
import android.view.MotionEvent
import com.example.xihe.service.EnhancedAccessibilityService
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.*
import kotlin.math.sqrt

/**
 * 🎬 手势录制器
 * 用于录制用户的手势操作
 */
class GestureRecorder(private val context: Context) {
    
    companion object {
        private const val TAG = "GestureRecorder"
    }
    
    private val recordedActions = mutableListOf<GestureAction>()
    private var isRecording = false
    private var recordingStartTime = 0L
    private var gestureName = ""
    
    private val _recordingState = MutableStateFlow<RecordingState>(RecordingState.Idle)
    val recordingState = _recordingState.asStateFlow()
    
    /**
     * 🎬 开始录制手势
     */
    fun startRecording(name: String = "gesture_${System.currentTimeMillis()}") {
        if (isRecording) {
            LogManager.w(TAG, "已经在录制中")
            return
        }
        
        isRecording = true
        recordingStartTime = System.currentTimeMillis()
        recordedActions.clear()
        gestureName = name
        
        _recordingState.value = RecordingState.Recording(
            gestureName = name,
            actionCount = 0,
            duration = 0L
        )
        
        LogManager.i(TAG, "🎬 开始录制手势: $name")
    }
    
    /**
     * 📝 记录触摸事件
     */
    fun recordTouchEvent(event: MotionEvent) {
        if (!isRecording) return
        
        val relativeTime = System.currentTimeMillis() - recordingStartTime
        
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val action = GestureAction.Touch(
                    x = event.x,
                    y = event.y,
                    timestamp = relativeTime,
                    pointerId = event.getPointerId(0),
                    pressure = event.pressure
                )
                recordedActions.add(action)
                LogManager.d(TAG, "📍 按下: (${event.x}, ${event.y})")
            }
            
            MotionEvent.ACTION_MOVE -> {
                // 记录所有活动指针的移动
                for (i in 0 until event.pointerCount) {
                    val action = GestureAction.Move(
                        x = event.getX(i),
                        y = event.getY(i),
                        timestamp = relativeTime,
                        pointerId = event.getPointerId(i),
                        pressure = event.getPressure(i)
                    )
                    recordedActions.add(action)
                }
            }
            
            MotionEvent.ACTION_UP -> {
                val action = GestureAction.Release(
                    x = event.x,
                    y = event.y,
                    timestamp = relativeTime,
                    pointerId = event.getPointerId(0)
                )
                recordedActions.add(action)
                LogManager.d(TAG, "🖐️ 抬起: (${event.x}, ${event.y})")
            }
            
            MotionEvent.ACTION_POINTER_DOWN -> {
                val pointerIndex = event.actionIndex
                val action = GestureAction.Touch(
                    x = event.getX(pointerIndex),
                    y = event.getY(pointerIndex),
                    timestamp = relativeTime,
                    pointerId = event.getPointerId(pointerIndex),
                    pressure = event.getPressure(pointerIndex)
                )
                recordedActions.add(action)
                LogManager.d(TAG, "📍 额外指针按下: pointer ${event.getPointerId(pointerIndex)}")
            }
            
            MotionEvent.ACTION_POINTER_UP -> {
                val pointerIndex = event.actionIndex
                val action = GestureAction.Release(
                    x = event.getX(pointerIndex),
                    y = event.getY(pointerIndex),
                    timestamp = relativeTime,
                    pointerId = event.getPointerId(pointerIndex)
                )
                recordedActions.add(action)
                LogManager.d(TAG, "🖐️ 额外指针抬起: pointer ${event.getPointerId(pointerIndex)}")
            }
        }
        
        // 更新录制状态
        _recordingState.value = RecordingState.Recording(
            gestureName = gestureName,
            actionCount = recordedActions.size,
            duration = relativeTime
        )
    }
    
    /**
     * ⏹️ 停止录制并保存
     */
    fun stopRecording(): RecordedGesture? {
        if (!isRecording) {
            LogManager.w(TAG, "没有在录制中")
            return null
        }
        
        isRecording = false
        
        if (recordedActions.isEmpty()) {
            LogManager.w(TAG, "⚠️ 没有录制到任何动作")
            _recordingState.value = RecordingState.Idle
            return null
        }
        
        val duration = recordedActions.lastOrNull()?.timestamp ?: 0L
        val gesture = RecordedGesture(
            id = UUID.randomUUID().toString(),
            name = gestureName,
            actions = recordedActions.toList(),
            duration = duration,
            createdAt = System.currentTimeMillis(),
            category = detectGestureCategory(recordedActions)
        )
        
        _recordingState.value = RecordingState.Completed(gesture)
        
        LogManager.i(TAG, "✅ 手势录制完成: ${gesture.actions.size}个动作, 时长: ${duration}ms")
        LogManager.i(TAG, "📊 手势信息: 类别=${gesture.category}, 多点触控=${gesture.isMultiTouch()}, 距离=${gesture.getTotalDistance()}px")
        
        return gesture
    }
    
    /**
     * 🔍 检测手势类别
     */
    private fun detectGestureCategory(actions: List<GestureAction>): GestureCategory {
        val touches = actions.filterIsInstance<GestureAction.Touch>()
        val moves = actions.filterIsInstance<GestureAction.Move>()
        val releases = actions.filterIsInstance<GestureAction.Release>()
        
        // 多点触控
        val pointerIds = actions.map { it.pointerId }.toSet()
        if (pointerIds.size > 1) {
            // 判断是捏合还是旋转
            return if (isPinchGesture(actions)) {
                GestureCategory.PINCH
            } else {
                GestureCategory.ROTATE
            }
        }
        
        // 单点触控
        if (moves.isEmpty()) {
            // 没有移动，判断是点击还是长按
            val duration = (releases.firstOrNull()?.timestamp ?: 0L) - 
                          (touches.firstOrNull()?.timestamp ?: 0L)
            return if (duration > 500) {
                GestureCategory.LONG_PRESS
            } else {
                GestureCategory.CLICK
            }
        }
        
        // 有移动，判断是滑动还是拖拽
        val totalDistance = calculateTotalDistance(actions)
        return if (totalDistance > 100) {
            GestureCategory.SWIPE
        } else {
            GestureCategory.DRAG
        }
    }
    
    /**
     * 判断是否是捏合手势
     */
    private fun isPinchGesture(actions: List<GestureAction>): Boolean {
        val moves = actions.filterIsInstance<GestureAction.Move>()
        if (moves.size < 4) return false
        
        // 简单判断：两个指针的距离在变化
        val pointer0Moves = moves.filter { it.pointerId == 0 }
        val pointer1Moves = moves.filter { it.pointerId == 1 }
        
        if (pointer0Moves.size < 2 || pointer1Moves.size < 2) return false
        
        val initialDistance = calculateDistance(
            pointer0Moves.first().x, pointer0Moves.first().y,
            pointer1Moves.first().x, pointer1Moves.first().y
        )
        
        val finalDistance = calculateDistance(
            pointer0Moves.last().x, pointer0Moves.last().y,
            pointer1Moves.last().x, pointer1Moves.last().y
        )
        
        // 距离变化超过50px认为是捏合
        return kotlin.math.abs(finalDistance - initialDistance) > 50
    }
    
    /**
     * 计算总移动距离
     */
    private fun calculateTotalDistance(actions: List<GestureAction>): Float {
        var distance = 0f
        var lastX = 0f
        var lastY = 0f
        var isFirst = true
        
        for (action in actions) {
            when (action) {
                is GestureAction.Touch -> {
                    lastX = action.x
                    lastY = action.y
                    isFirst = true
                }
                is GestureAction.Move -> {
                    if (!isFirst) {
                        distance += calculateDistance(lastX, lastY, action.x, action.y)
                    }
                    lastX = action.x
                    lastY = action.y
                    isFirst = false
                }
                else -> {}
            }
        }
        
        return distance
    }
    
    /**
     * 计算两点距离
     */
    private fun calculateDistance(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x2 - x1
        val dy = y2 - y1
        return sqrt(dx * dx + dy * dy)
    }
    
    /**
     * 录制状态
     */
    sealed class RecordingState {
        object Idle : RecordingState()
        
        data class Recording(
            val gestureName: String,
            val actionCount: Int,
            val duration: Long
        ) : RecordingState()
        
        data class Completed(
            val gesture: RecordedGesture
        ) : RecordingState()
    }
}
