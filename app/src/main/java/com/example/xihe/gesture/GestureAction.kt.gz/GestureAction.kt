package com.example.xihe.gesture

import kotlinx.serialization.Serializable

/**
 * 🎨 手势动作基类
 * 用于记录手势操作的每个动作
 */
@Serializable
sealed class GestureAction {
    abstract val timestamp: Long
    abstract val pointerId: Int
    
    /**
     * 触摸动作（手指按下）
     */
    @Serializable
    data class Touch(
        val x: Float,
        val y: Float,
        override val timestamp: Long,
        override val pointerId: Int,
        val pressure: Float = 1.0f
    ) : GestureAction()
    
    /**
     * 移动动作（手指移动）
     */
    @Serializable
    data class Move(
        val x: Float,
        val y: Float,
        override val timestamp: Long,
        override val pointerId: Int,
        val pressure: Float = 1.0f
    ) : GestureAction()
    
    /**
     * 释放动作（手指抬起）
     */
    @Serializable
    data class Release(
        val x: Float,
        val y: Float,
        override val timestamp: Long,
        override val pointerId: Int
    ) : GestureAction()
    
    /**
     * 等待动作（延迟）
     */
    @Serializable
    data class Wait(
        override val timestamp: Long,
        val duration: Long,
        override val pointerId: Int = 0
    ) : GestureAction()
}

/**
 * 📹 录制的手势
 */
@Serializable
data class RecordedGesture(
    val id: String,
    val name: String,
    val description: String = "",
    val actions: List<GestureAction>,
    val duration: Long,
    val createdAt: Long,
    val tags: List<String> = emptyList(),
    val category: GestureCategory = GestureCategory.CUSTOM,
    val thumbnail: String? = null
) {
    /**
     * 获取手势的总触摸点数
     */
    fun getTouchPointCount(): Int {
        return actions.filterIsInstance<GestureAction.Touch>().size
    }
    
    /**
     * 获取手势的移动距离
     */
    fun getTotalDistance(): Float {
        var distance = 0f
        var lastX = 0f
        var lastY = 0f
        var isFirst = true
        
        for (action in actions) {
            when (action) {
                is GestureAction.Touch -> {
                    lastX = action.x
                    lastY = action.y
                    isFirst = true
                }
                is GestureAction.Move -> {
                    if (!isFirst) {
                        val dx = action.x - lastX
                        val dy = action.y - lastY
                        distance += kotlin.math.sqrt(dx * dx + dy * dy)
                    }
                    lastX = action.x
                    lastY = action.y
                    isFirst = false
                }
                else -> {}
            }
        }
        
        return distance
    }
    
    /**
     * 是否是多点触控手势
     */
    fun isMultiTouch(): Boolean {
        val pointerIds = actions.map { it.pointerId }.toSet()
        return pointerIds.size > 1
    }
}

/**
 * 🏷️ 手势分类
 */
enum class GestureCategory {
    CLICK,          // 单击
    LONG_PRESS,     // 长按
    SWIPE,          // 滑动
    PINCH,          // 捏合
    ROTATE,         // 旋转
    DRAG,           // 拖拽
    CUSTOM,         // 自定义
    GAME            // 游戏专用
}
