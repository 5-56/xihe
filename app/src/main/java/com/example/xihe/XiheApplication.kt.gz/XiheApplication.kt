package com.example.xihe

import android.app.Application
import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.utils.PerformanceMonitor
import com.example.xihe.core.UnifiedMemoryManager
import com.example.xihe.service.TrainingKeepAliveService
import com.example.xihe.training.AutoTrainingWorker
import com.example.xihe.core.AutomationEngine
import com.example.xihe.core.EnhancedAutomationEngine
import com.example.xihe.core.ProviderRegistry
import com.example.xihe.tools.ToolRegistry
import com.example.xihe.core.ModuleCoordinator
import com.example.xihe.service.KeepAliveService
import com.example.xihe.security.PrivacyPermissionManager
import com.example.xihe.ocr.DeepSeekOCRService
import com.example.xihe.multimodal.LocalImageAnalyzer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * 🧠 羲和应用程序类
 *
 * 应用启动时的初始化入口
 */
class XiheApplication : Application() {

    companion object {
        private const val TAG = "XiheApplication"

        /** 应用实例，用于全局访问 */
        @Volatile
        private var instance: XiheApplication? = null

        fun getInstance(): XiheApplication? = instance
    }

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        instance = this

        LogManager.i(TAG, "🚀 羲和AI助手启动中 (异步初始化模式)...")
        
        // 1. 初始化性能监控
        PerformanceMonitor.startMonitoring(this)
        PerformanceMonitor.logMemoryUsage("Application.onCreate")
        
        // 2. 异步初始化其余系统
        applicationScope.launch {
            val startTime = System.currentTimeMillis()
            
            // A阶段：核心自动化与服务（按序，因为有依赖）
            initCoreSystems()
            
            // B阶段：数据与内存（并行）
            applicationScope.launch { initMemorySystem() }
            
            // C阶段：扩展功能（延迟 1 秒，避开启动高峰）
            delay(1000)
            applicationScope.launch { initTrainingSystem() }
            applicationScope.launch { initDeepSeekOCR() }
            
            val duration = System.currentTimeMillis() - startTime
            LogManager.i(TAG, "✅ 羲和AI助手异步加载完成，总耗时: ${duration}ms")
        }
    }

    /**
     * 初始化核心系统
     */
    private fun initCoreSystems() {
        try {
            LogManager.d(TAG, "📦 开始初始化核心系统...")

            // 初始化自动化引擎（内部会处理 ModuleCoordinator 初始化）
            AutomationEngine.init(this)
            LogManager.d(TAG, "✅ AutomationEngine 初始化完成")

            // 初始化服务提供商注册表
            ProviderRegistry.initialize(this)
            LogManager.d(TAG, "✅ ProviderRegistry 初始化完成")

            // 初始化增强版自动化引擎
            EnhancedAutomationEngine.initialize(
                this,
                EnhancedAutomationEngine.EngineConfig(
                    enableVoice = true,
                    enableLearning = true,
                    enableSecurity = true,
                    enablePerformanceOptimization = true,
                    debugMode = BuildConfig.DEBUG
                )
            )
            LogManager.d(TAG, "✅ EnhancedAutomationEngine 初始化完成")

            // 初始化工具注册表
            ToolRegistry.initializeTools(this)
            LogManager.d(TAG, "✅ ToolRegistry 初始化完成")

            // 注意：ModuleCoordinator 已在 AutomationEngine.init() 中初始化
            // 这里不再重复初始化，避免警告日志
            if (!ModuleCoordinator.isInitialized()) {
                ModuleCoordinator.initialize(
                    this,
                    ModuleCoordinator.ModuleConfig(
                        enableAI = true,
                        enableVoice = true,
                        enableLearning = true,
                        enablePerformance = true,
                        enableCrossApp = false
                    )
                )
                LogManager.d(TAG, "✅ ModuleCoordinator 初始化完成")
            } else {
                LogManager.d(TAG, "ℹ️ ModuleCoordinator 已初始化，跳过")
            }

            // 按用户设置启动保活服务
            val keepAlivePrefs = getSharedPreferences("xihe_settings", Context.MODE_PRIVATE)
            val enableBackgroundWake = keepAlivePrefs.getBoolean("enable_background_wake", false)
            if (enableBackgroundWake) {
                try {
                    KeepAliveService.start(this)
                    LogManager.d(TAG, "✅ KeepAliveService 已启动")
                } catch (e: Exception) {
                    LogManager.e(TAG, "⚠️ KeepAliveService 启动失败", e)
                }
            } else {
                LogManager.d(TAG, "ℹ️ 后台唤醒未开启，跳过 KeepAliveService 自动启动")
            }

            // 初始化隐私权限管理器
            PrivacyPermissionManager.init(this)
            LogManager.d(TAG, "✅ PrivacyPermissionManager 初始化完成")

            LogManager.i(TAG, "✅ 核心系统初始化完成")
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 核心系统初始化失败", e)
        }
    }

    /**
     * 初始化内存管理系统
     */
    private fun initMemorySystem() {
        try {
            LogManager.d(TAG, "💾 开始初始化内存管理系统...")
            UnifiedMemoryManager.init(this)
            LogManager.i(TAG, "✅ 内存管理系统初始化完成")
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 内存管理系统初始化失败", e)
        }
    }

    /**
     * 初始化训练系统
     */
    private fun initTrainingSystem() {
        try {
            LogManager.d(TAG, "🎓 开始初始化训练系统...")

            // 安排自动训练任务
            AutoTrainingWorker.schedule(this)
            LogManager.d(TAG, "✅ 自动训练Worker已安排")

            // 根据设置决定是否启动训练保活服务
            if (TrainingKeepAliveService.isEnabled(this)) {
                TrainingKeepAliveService.start(this)
                LogManager.d(TAG, "✅ 训练保活服务已启动")
            } else {
                LogManager.d(TAG, "ℹ️ 训练保活服务未启用")
            }

            LogManager.i(TAG, "✅ 训练系统初始化完成")
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 训练系统初始化失败", e)
            // 训练系统失败不影响主流程
        }
    }

    /**
     * 初始化 DeepSeek OCR 服务
     *
     * 注意：API Key 应由用户在设置中配置，不再硬编码默认值
     */
    private fun initDeepSeekOCR() {
        try {
            LogManager.d(TAG, "👁️ 开始初始化 DeepSeek OCR 服务...")

            val deepSeekService = DeepSeekOCRService.getInstance(this)

            // 检查是否已配置 API Key
            if (deepSeekService.loadApiKey()) {
                LogManager.i(TAG, "✅ DeepSeek OCR API Key 已加载")
            } else {
                // 不再硬编码默认 API Key，提示用户配置
                LogManager.w(TAG, "⚠️ DeepSeek OCR API Key 未配置，请在设置中配置以启用云端OCR功能")
            }

            // 初始化本地图像分析器
            val imageAnalyzer = LocalImageAnalyzer.getInstance(this)
            // 仅当 API Key 已配置时才优先使用云端 OCR
            imageAnalyzer.setPreferCloudOCR(deepSeekService.isConfigured())

            LogManager.i(TAG, "✅ DeepSeek OCR 服务初始化完成")
            LogManager.d(TAG, "📊 OCR服务状态: ${deepSeekService.getStatusInfo()}")

        } catch (e: Exception) {
            LogManager.e(TAG, "❌ DeepSeek OCR 服务初始化失败", e)
        }
    }

    override fun onTerminate() {
        LogManager.i(TAG, "👋 羲和AI助手正在关闭...")
        PerformanceMonitor.stopMonitoring()
        instance = null
        super.onTerminate()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        LogManager.w(TAG, "⚠️ 系统内存不足，尝试释放资源...")
        PerformanceMonitor.logMemoryUsage("onLowMemory")
        // 触发内存清理
        com.example.xihe.core.EngineStateManager.cleanupOldMessages()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        when (level) {
            TRIM_MEMORY_RUNNING_LOW -> {
                LogManager.w(TAG, "⚠️ 应用运行中，系统内存偏低")
            }
            TRIM_MEMORY_RUNNING_CRITICAL -> {
                LogManager.w(TAG, "⚠️ 应用运行中，系统内存严重不足")
            }
            TRIM_MEMORY_UI_HIDDEN -> {
                LogManager.d(TAG, "ℹ️ 应用UI已隐藏")
            }
        }
    }
}
