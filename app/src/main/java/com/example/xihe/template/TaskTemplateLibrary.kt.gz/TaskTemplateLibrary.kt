package com.example.xihe.template

import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.crossapp.CrossAppAction
import com.example.xihe.crossapp.CrossAppStep
import com.example.xihe.crossapp.CrossAppTask
import com.example.xihe.crossapp.ShareType
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.*

/**
 * 任务模板库
 * 管理预定义的任务模板
 */
class TaskTemplateLibrary(private val context: Context) {
    
    companion object {
        private const val TAG = "TaskTemplateLibrary"
        private const val TEMPLATES_DIR = "task_templates"
        private const val TEMPLATE_FILE_EXTENSION = ".template"
        
        @Volatile
        private var instance: TaskTemplateLibrary? = null
        
        fun getInstance(context: Context): TaskTemplateLibrary {
            return instance ?: synchronized(this) {
                instance ?: TaskTemplateLibrary(context.applicationContext).also { instance = it }
            }
        }
    }
    
    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
    }
    
    private val templatesMap = mutableMapOf<String, TaskTemplate>()
    private val _templates = MutableStateFlow<List<TaskTemplate>>(emptyList())
    val templates = _templates.asStateFlow()
    
    private val templatesDir: File by lazy {
        File(context.filesDir, TEMPLATES_DIR).apply {
            if (!exists()) {
                mkdirs()
            }
        }
    }
    
    init {
        loadBuiltInTemplates()
        loadUserTemplates()
    }
    
    /**
     * 加载内置模板
     */
    private fun loadBuiltInTemplates() {
        // 微信→备忘录
        addTemplate(TaskTemplate(
            id = "wechat_to_note",
            name = "微信复制到备忘录",
            description = "从微信复制文本到系统备忘录",
            category = TemplateCategory.PRODUCTIVITY,
            icon = "",
            isBuiltIn = true,
            steps = listOf(
                TemplateStep(
                    description = "打开微信并复制文本",
                    action = "copy_text"
                ),
                TemplateStep(
                    description = "打开备忘录",
                    action = "open_app"
                ),
                TemplateStep(
                    description = "粘贴文本",
                    action = "paste_text"
                )
            )
        ))
        
        // 截图分享
        addTemplate(TaskTemplate(
            id = "screenshot_share",
            name = "截图并分享",
            description = "截取当前屏幕并分享到指定应用",
            category = TemplateCategory.UTILITY,
            icon = "",
            isBuiltIn = true,
            steps = listOf(
                TemplateStep(
                    description = "截取当前屏幕",
                    action = "capture_screen"
                ),
                TemplateStep(
                    description = "分享截图",
                    action = "share_content"
                )
            )
        ))
        
        // 定时提醒
        addTemplate(TaskTemplate(
            id = "timed_reminder",
            name = "定时提醒",
            description = "在指定时间发送提醒通知",
            category = TemplateCategory.REMINDER,
            icon = "",
            isBuiltIn = true,
            steps = listOf(
                TemplateStep(
                    description = "等待指定时间",
                    action = "wait"
                ),
                TemplateStep(
                    description = "发送提醒通知",
                    action = "send_notification"
                )
            )
        ))
        
        // 批量消息发送
        addTemplate(TaskTemplate(
            id = "batch_message",
            name = "批量发送消息",
            description = "向多个联系人发送相同消息",
            category = TemplateCategory.MESSAGING,
            icon = "",
            isBuiltIn = true,
            steps = listOf(
                TemplateStep(
                    description = "打开消息应用",
                    action = "open_app"
                ),
                TemplateStep(
                    description = "选择联系人",
                    action = "select_contact"
                ),
                TemplateStep(
                    description = "发送消息",
                    action = "send_message"
                ),
                TemplateStep(
                    description = "重复上述步骤",
                    action = "repeat"
                )
            )
        ))
        
        // 自动回复
        addTemplate(TaskTemplate(
            id = "auto_reply",
            name = "自动回复消息",
            description = "收到特定消息时自动回复",
            category = TemplateCategory.MESSAGING,
            icon = "",
            isBuiltIn = true,
            steps = listOf(
                TemplateStep(
                    description = "监听新消息",
                    action = "listen_notification"
                ),
                TemplateStep(
                    description = "检查消息内容",
                    action = "check_content"
                ),
                TemplateStep(
                    description = "自动回复",
                    action = "auto_reply"
                )
            )
        ))
        
        // 网页内容提取
        addTemplate(TaskTemplate(
            id = "web_content_extract",
            name = "提取网页内容",
            description = "从网页提取文本并保存",
            category = TemplateCategory.WEB,
            icon = "",
            isBuiltIn = true,
            steps = listOf(
                TemplateStep(
                    description = "打开网页",
                    action = "open_url"
                ),
                TemplateStep(
                    description = "提取文本内容",
                    action = "extract_text"
                ),
                TemplateStep(
                    description = "保存到文件",
                    action = "save_file"
                )
            )
        ))
        
        LogManager.d(TAG, "已加载 ${templatesMap.size} 个内置模板")
    }
    
    /**
     * 加载用户模板
     */
    private fun loadUserTemplates() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val files = templatesDir.listFiles { file ->
                    file.extension == TEMPLATE_FILE_EXTENSION.removePrefix(".")
                }
                
                files?.forEach { file ->
                    try {
                        val jsonString = file.readText()
                        val template = json.decodeFromString<TaskTemplate>(jsonString)
                        templatesMap[template.id] = template
                    } catch (e: Exception) {
                        LogManager.d(TAG, "加载模板文件失败: ${file.name}", e)
                    }
                }
                
                updateTemplatesList()
                LogManager.d(TAG, "已加载用户模板")
                
            } catch (e: Exception) {
                LogManager.d(TAG, "加载用户模板失败", e)
            }
        }
    }
    
    /**
     * 保存模板
     */
    suspend fun saveTemplate(template: TaskTemplate): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val file = File(templatesDir, "${template.id}$TEMPLATE_FILE_EXTENSION")
                val jsonString = json.encodeToString(template)
                file.writeText(jsonString)
                
                addTemplate(template)
                
                LogManager.d(TAG, "模板已保存: ${template.name}")
                true
            } catch (e: Exception) {
                LogManager.d(TAG, "保存模板失败", e)
                false
            }
        }
    }
    
    /**
     * 删除模板
     */
    suspend fun deleteTemplate(templateId: String): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val template = templatesMap[templateId]
                if (template != null && template.isBuiltIn) {
                    LogManager.d(TAG, "不能删除内置模板")
                    return@withContext false
                }
                
                val file = File(templatesDir, "$templateId$TEMPLATE_FILE_EXTENSION")
                val deleted = file.delete()
                
                if (deleted) {
                    templatesMap.remove(templateId)
                    updateTemplatesList()
                    LogManager.d(TAG, "模板已删除: $templateId")
                }
                
                deleted
            } catch (e: Exception) {
                LogManager.d(TAG, "删除模板失败", e)
                false
            }
        }
    }
    
    /**
     * 添加模板到内存
     * 📝 添加模板到内存
     */
    private fun addTemplate(template: TaskTemplate) {
        templatesMap[template.id] = template
        updateTemplatesList()
    }
    
    /**
     * 🔍 根据ID获取模板
     */
    fun getTemplateById(id: String): TaskTemplate? {
        return templatesMap[id]
    }
    
    /**
     * 🔍 根据分类获取模板
     */
    fun getTemplatesByCategory(category: TemplateCategory): List<TaskTemplate> {
        return templatesMap.values.filter { it.category == category }
    }
    
    /**
     * 🔍 搜索模板
     */
    fun searchTemplates(query: String): List<TaskTemplate> {
        if (query.isBlank()) return templatesMap.values.toList()
        
        return templatesMap.values.filter { template ->
            template.name.contains(query, ignoreCase = true) ||
            template.description.contains(query, ignoreCase = true) ||
            template.tags.any { it.contains(query, ignoreCase = true) }
        }
    }
    
    /**
     * 🎯 根据标签获取模板
     */
    fun getTemplatesByTag(tag: String): List<TaskTemplate> {
        return templatesMap.values.filter { template ->
            template.tags.contains(tag)
        }
    }
    
    /**
     * 🔄 模板转换为实际任务
     */
    fun templateToTask(
        template: TaskTemplate,
        parameters: Map<String, String> = emptyMap()
    ): CrossAppTask {
        val steps = template.steps.map { templateStep ->
            CrossAppStep(
                stepId = UUID.randomUUID().toString(),
                targetApp = parameters["targetApp"] ?: "Unknown",
                targetPackage = parameters["targetPackage"] ?: "",
                description = templateStep.description,
                action = createActionFromTemplate(templateStep, parameters)
            )
        }
        
        return CrossAppTask(
            id = UUID.randomUUID().toString(),
            name = template.name,
            description = template.description,
            steps = steps
        )
    }
    
    /**
     * 🎬 根据模板步骤创建动作
     */
    private fun createActionFromTemplate(
        step: TemplateStep,
        parameters: Map<String, String>
    ): CrossAppAction {
        return when (step.action) {
            "copy_text" -> CrossAppAction.CopyText(
                text = parameters["text"] ?: ""
            )
            "paste_text" -> CrossAppAction.PasteText(
                targetField = parameters["targetField"] ?: ""
            )
            "share_content" -> CrossAppAction.ShareContent(
                content = parameters["content"] ?: "",
                type = ShareType.TEXT
            )
            "capture_screen" -> CrossAppAction.CaptureScreen()
            "wait" -> CrossAppAction.Wait(
                duration = parameters["duration"]?.toLongOrNull() ?: 1000L
            )
            else -> CrossAppAction.CustomOperation(
                operation = step.action,
                params = parameters
            )
        }
    }
    
    /**
     * 📊 获取模板统计
     */
    fun getTemplateStatistics(): TemplateStatistics {
        val categoryCounts = templatesMap.values
            .groupBy { it.category }
            .mapValues { it.value.size }
        
        return TemplateStatistics(
            totalTemplates = templatesMap.size,
            builtInTemplates = templatesMap.values.count { it.isBuiltIn },
            userTemplates = templatesMap.values.count { !it.isBuiltIn },
            categoryCounts = categoryCounts
        )
    }
    
    /**
     * 🔄 更新模板列表
     */
    private fun updateTemplatesList() {
        _templates.value = templatesMap.values
            .sortedWith(compareBy({ !it.isBuiltIn }, { it.name }))
    }
    
    // ============ 数据类型 ============
    
    /**
     * 📋 任务模板
     */
    @Serializable
    data class TaskTemplate(
        val id: String,
        val name: String,
        val description: String,
        val category: TemplateCategory,
        val icon: String,
        val isBuiltIn: Boolean = false,
        val steps: List<TemplateStep>,
        val tags: List<String> = emptyList(),
        val createdAt: Long = System.currentTimeMillis(),
        val updatedAt: Long = System.currentTimeMillis()
    )
    
    /**
     * 📝 模板步骤
     */
    @Serializable
    data class TemplateStep(
        val description: String,
        val action: String,
        val parameters: Map<String, String> = emptyMap()
    )
    
    /**
     * 🏷️ 模板分类
     */
    @Serializable
    enum class TemplateCategory {
        PRODUCTIVITY,   // 生产力
        MESSAGING,      // 消息
        WEB,           // 网页
        UTILITY,       // 实用工具
        REMINDER,      // 提醒
        AUTOMATION,    // 自动化
        CUSTOM         // 自定义
    }
    
    /**
     * 📊 模板统计
     */
    data class TemplateStatistics(
        val totalTemplates: Int,
        val builtInTemplates: Int,
        val userTemplates: Int,
        val categoryCounts: Map<TemplateCategory, Int>
    )
}
