package com.example.xihe.health

import android.content.Context
import android.content.SharedPreferences
import com.example.xihe.utils.LogManager
import com.example.xihe.intelligence.MemorySystem
import com.example.xihe.intelligence.EmotionRecognizer
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.LocalDateTime
import java.time.LocalDate
import java.time.Duration

/**
 * 健康管理系统
 * 监测用户健康状态，提供健康提醒和建议
 */
class HealthManager(private val context: Context) {
    
    companion object {
        private const val TAG = "HealthManager"
        
        // 健康提醒间隔
        private const val WATER_REMINDER_INTERVAL_MS = 60 * 60 * 1000L // 1小时
        private const val SITTING_REMINDER_INTERVAL_MS = 90 * 60 * 1000L // 1.5小时
        private const val EYE_REST_INTERVAL_MS = 60 * 60 * 1000L // 1小时
        private const val POSTURE_CHECK_INTERVAL_MS = 45 * 60 * 1000L // 45分钟
        
        // 每日目标
        private const val DAILY_WATER_GOAL = 8 // 8杯水
        private const val DAILY_STEPS_GOAL = 10000 // 10000步
        private const val DAILY_EXERCISE_MINUTES = 30 // 30分钟运动
        
        // SharedPreferences 键名
        private const val PREFS_NAME = "health_data"
        private const val KEY_DATE = "date"
        private const val KEY_WATER_COUNT = "water_count"
        private const val KEY_LAST_WATER_TIME = "last_water_time"
        private const val KEY_STEPS = "steps"
        private const val KEY_EXERCISE_MINUTES = "exercise_minutes"
        private const val KEY_SITTING_START_TIME = "sitting_start_time"
        private const val KEY_SCREEN_START_TIME = "screen_start_time"
        private const val KEY_LAST_POSTURE_CHECK = "last_posture_check"
        private const val KEY_HAS_SLEEP_REMINDER = "has_sleep_reminder"
        private const val KEY_HAS_MORNING_REMINDER = "has_morning_reminder"
        private const val KEY_HAS_EXERCISE_REMINDER = "has_exercise_reminder"
        private const val KEY_HAS_STEPS_ACHIEVEMENT = "has_steps_achievement"
        private const val KEY_HAS_EXERCISE_ACHIEVEMENT = "has_exercise_achievement"
        
        @Volatile
        private var instance: HealthManager? = null
        
        fun getInstance(context: Context): HealthManager {
            return instance ?: synchronized(this) {
                instance ?: HealthManager(context.applicationContext).also {
                    instance = it
                }
            }
        }
    }
    
    // 健康状态
    private val _healthState = MutableStateFlow(HealthState())
    val healthState = _healthState.asStateFlow()
    
    // 今日健康数据
    private var todayData = DailyHealthData()
    
    // 监控任务
    private var monitoringJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    
    // 记忆系统（获取用户习惯）
    private val memorySystem = MemorySystem.getInstance(context)
    
    // 情绪识别（评估压力）
    private val emotionRecognizer = EmotionRecognizer.getInstance(context)
    
    // SharedPreferences
    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    
    // 是否启用
    private var isEnabled = false
    
    /**
     * 启动健康管理
     */
    fun start() {
        if (isEnabled) {
            LogManager.d(TAG, "健康管理系统已在运行")
            return
        }
        
        LogManager.i(TAG, "启动健康管理系统")
        isEnabled = true
        
        // 启动监控
        startHealthMonitoring()
        
        // 加载今日数据
        loadTodayData()
    }
    
    /**
     * 停止健康管理
     */
    fun stop() {
        LogManager.i(TAG, "停止健康管理系统")
        isEnabled = false
        monitoringJob?.cancel()
        monitoringJob = null
        
        // 保存今日数据
        saveTodayData()
    }
    
    /**
     * 启动健康监控
     */
    private fun startHealthMonitoring() {
        monitoringJob = scope.launch {
            while (isActive && isEnabled) {
                try {
                    delay(60_000) // 每分钟检查一次
                    
                    // 检查各项健康指标
                    checkWaterReminder()
                    checkSittingTime()
                    checkEyeRest()
                    checkPosture()
                    checkSleepTime()
                    checkExercise()
                    
                } catch (e: Exception) {
                    LogManager.e(TAG, "健康监控失败", e)
                }
            }
        }
    }
    
    /**
     * 检查喝水提醒
     */
    private fun checkWaterReminder() {
        val lastWaterTime = todayData.lastWaterTime
        val now = System.currentTimeMillis()
        
        if (lastWaterTime == 0L || now - lastWaterTime >= WATER_REMINDER_INTERVAL_MS) {
            if (todayData.waterCount < DAILY_WATER_GOAL) {
                triggerHealthReminder(
                    HealthReminder(
                        type = ReminderType.WATER,
                        priority = Priority.MEDIUM,
                        message = "主人，该喝水啦！ 今天还需要喝${DAILY_WATER_GOAL - todayData.waterCount}杯水哦",
                        suggestion = "喝一杯温水补充水分",
                        icon = ""
                    )
                )
            }
        }
    }
    
    /**
     * 检查久坐提醒
     */
    private fun checkSittingTime() {
        val sittingDuration = todayData.currentSittingDuration
        
        if (sittingDuration >= SITTING_REMINDER_INTERVAL_MS) {
            triggerHealthReminder(
                HealthReminder(
                    type = ReminderType.SITTING,
                    priority = Priority.HIGH,
                    message = "主人，已经坐了${sittingDuration / (60 * 1000)}分钟了！起来活动一下吧~",
                    suggestion = "站起来走动走动，伸伸懒腰",
                    icon = ""
                )
            )
            
            // 重置久坐时间
            todayData.resetSittingTime()
        }
    }
    
    /**
     * 检查用眼休息
     */
    private fun checkEyeRest() {
        val screenTime = todayData.currentScreenTime
        
        if (screenTime >= EYE_REST_INTERVAL_MS) {
            triggerHealthReminder(
                HealthReminder(
                    type = ReminderType.EYE_REST,
                    priority = Priority.MEDIUM,
                    message = "主人，看屏幕${screenTime / (60 * 1000)}分钟了，休息一下眼睛吧",
                    suggestion = "看看远处，或者闭眼休息一会儿",
                    icon = ""
                )
            )
            
            // 重置屏幕时间
            todayData.resetScreenTime()
        }
    }
    
    /**
     * 检查姿势提醒
     */
    private fun checkPosture() {
        val timeSinceLastPostureCheck = System.currentTimeMillis() - todayData.lastPostureCheckTime
        
        if (timeSinceLastPostureCheck >= POSTURE_CHECK_INTERVAL_MS) {
            triggerHealthReminder(
                HealthReminder(
                    type = ReminderType.POSTURE,
                    priority = Priority.LOW,
                    message = "主人，记得保持良好的坐姿哦~",
                    suggestion = "挺直腰背，不要驼背",
                    icon = ""
                )
            )
            
            todayData.lastPostureCheckTime = System.currentTimeMillis()
        }
    }
    
    /**
     * 检查睡眠时间
     */
    private fun checkSleepTime() {
        val now = LocalDateTime.now()
        val hour = now.hour
        
        // 深夜提醒 (23:00 - 02:00)
        if (hour >= 23 || hour < 2) {
            if (!todayData.hasSleepReminder) {
                triggerHealthReminder(
                    HealthReminder(
                        type = ReminderType.SLEEP,
                        priority = Priority.HIGH,
                        message = "主人，已经很晚了，该休息啦！ 充足的睡眠很重要哦",
                        suggestion = "准备睡觉，明天才有好精神",
                        icon = ""
                    )
                )
                
                todayData.hasSleepReminder = true
            }
        }
        
        // 早晨提醒 (6:00 - 8:00)
        if (hour in 6..8) {
            if (!todayData.hasMorningReminder) {
                triggerHealthReminder(
                    HealthReminder(
                        type = ReminderType.MORNING,
                        priority = Priority.LOW,
                        message = "主人，早上好！ 美好的一天开始啦~",
                        suggestion = "伸个懒腰，喝杯温水",
                        icon = ""
                    )
                )
                
                todayData.hasMorningReminder = true
            }
        }
    }
    
    /**
     * 检查运动
     */
    private fun checkExercise() {
        // 检查是否达到每日运动目标
        if (todayData.exerciseMinutes < DAILY_EXERCISE_MINUTES) {
            val now = LocalDateTime.now()
            val hour = now.hour
            
            // 下午或傍晚提醒运动 (15:00 - 19:00)
            if (hour in 15..19 && !todayData.hasExerciseReminder) {
                triggerHealthReminder(
                    HealthReminder(
                        type = ReminderType.EXERCISE,
                        priority = Priority.MEDIUM,
                        message = "主人，今天还没运动呢！ 要不要出去活动一下？",
                        suggestion = "跑步、散步或者做做运动",
                        icon = ""
                    )
                )
                
                todayData.hasExerciseReminder = true
            }
        }
    }
    
    /**
     * 触发健康提醒
     */
    private fun triggerHealthReminder(reminder: HealthReminder) {
        LogManager.i(TAG, "健康提醒: ${reminder.message}")
        
        // 更新健康状态
        _healthState.value = _healthState.value.copy(
            lastReminder = reminder,
            lastReminderTime = System.currentTimeMillis()
        )
        
        // 记录提醒历史
        todayData.reminders.add(reminder)
    }
    
    /**
     * 记录喝水
     */
    fun recordWater(cups: Int = 1) {
        todayData.waterCount += cups
        todayData.lastWaterTime = System.currentTimeMillis()
        
        LogManager.d(TAG, "记录喝水: ${todayData.waterCount}/${DAILY_WATER_GOAL}杯")
        
        // 检查目标完成
        if (todayData.waterCount >= DAILY_WATER_GOAL) {
            triggerHealthReminder(
                HealthReminder(
                    type = ReminderType.ACHIEVEMENT,
                    priority = Priority.LOW,
                    message = "主人，今天的喝水目标已达成！ 保持下去哦~",
                    suggestion = "继续保持良好习惯",
                    icon = ""
                )
            )
        }
        
        updateHealthState()
    }
    
    /**
     * 记录步数
     */
    fun recordSteps(steps: Int) {
        todayData.steps = steps
        
        LogManager.d(TAG, "记录步数: ${todayData.steps}/${DAILY_STEPS_GOAL}步")
        
        // 检查目标完成
        if (todayData.steps >= DAILY_STEPS_GOAL && !todayData.hasStepsAchievement) {
            triggerHealthReminder(
                HealthReminder(
                    type = ReminderType.ACHIEVEMENT,
                    priority = Priority.LOW,
                    message = "主人，今天的步数目标达成了！ 太棒啦！",
                    suggestion = "继续加油",
                    icon = ""
                )
            )
            todayData.hasStepsAchievement = true
        }
        
        updateHealthState()
    }
    
    /**
     * 开始运动记录
     */
    fun startExercise(exerciseType: String = "general") {
        todayData.isExercising = true
        todayData.exerciseStartTime = System.currentTimeMillis()
        LogManager.d(TAG, "开始运动记录: $exerciseType")
    }
    
    /**
     * 停止运动记录
     */
    fun stopExercise() {
        if (todayData.isExercising && todayData.exerciseStartTime > 0) {
            val duration = (System.currentTimeMillis() - todayData.exerciseStartTime) / 60000
            recordExercise(duration.toInt())
            todayData.isExercising = false
            todayData.exerciseStartTime = 0
            LogManager.d(TAG, "停止运动记录: ${duration}分钟")
        }
    }
    
    /**
     * 记录运动
     */
    fun recordExercise(minutes: Int) {
        todayData.exerciseMinutes += minutes
        
        LogManager.d(TAG, "记录运动: ${todayData.exerciseMinutes}/${DAILY_EXERCISE_MINUTES}分钟")
        
        // 检查目标完成
        if (todayData.exerciseMinutes >= DAILY_EXERCISE_MINUTES && !todayData.hasExerciseAchievement) {
            triggerHealthReminder(
                HealthReminder(
                    type = ReminderType.ACHIEVEMENT,
                    priority = Priority.LOW,
                    message = "主人，今天的运动目标完成了！ 身体棒棒哒！",
                    suggestion = "保持运动习惯",
                    icon = ""
                )
            )
            todayData.hasExerciseAchievement = true
        }
        
        updateHealthState()
    }
    
    /**
     * 记录活动（站立/坐下）
     */
    fun recordActivity(isActive: Boolean) {
        if (isActive) {
            // 站立/活动
            todayData.resetSittingTime()
            LogManager.d(TAG, "用户开始活动")
        } else {
            // 坐下
            todayData.startSitting()
            LogManager.d(TAG, "用户开始坐着")
        }
    }
    
    /**
     * 记录屏幕使用
     */
    fun recordScreenUsage(isUsing: Boolean) {
        if (isUsing) {
            todayData.startScreenTime()
            LogManager.d(TAG, "开始使用屏幕")
        } else {
            todayData.resetScreenTime()
            LogManager.d(TAG, "停止使用屏幕")
        }
    }
    
    /**
     * 更新健康状态
     */
    private fun updateHealthState() {
        _healthState.value = _healthState.value.copy(
            waterProgress = todayData.waterCount.toFloat() / DAILY_WATER_GOAL,
            stepsProgress = todayData.steps.toFloat() / DAILY_STEPS_GOAL,
            exerciseProgress = todayData.exerciseMinutes.toFloat() / DAILY_EXERCISE_MINUTES,
            dailyData = todayData
        )
    }
    
    /**
     * 获取健康报告
     */
    fun getHealthReport(): HealthReport {
        val waterProgress = (todayData.waterCount.toFloat() / DAILY_WATER_GOAL * 100).toInt()
        val stepsProgress = (todayData.steps.toFloat() / DAILY_STEPS_GOAL * 100).toInt()
        val exerciseProgress = (todayData.exerciseMinutes.toFloat() / DAILY_EXERCISE_MINUTES * 100).toInt()
        
        val overallScore = (waterProgress + stepsProgress + exerciseProgress) / 3
        
        val evaluation = when {
            overallScore >= 90 -> "优秀！保持下去！"
            overallScore >= 70 -> "不错哦，继续加油！"
            overallScore >= 50 -> "还不错，可以更好！"
            else -> "需要多关注健康啦！"
        }
        
        return HealthReport(
            date = LocalDateTime.now(),
            waterCount = todayData.waterCount,
            waterGoal = DAILY_WATER_GOAL,
            steps = todayData.steps,
            stepsGoal = DAILY_STEPS_GOAL,
            exerciseMinutes = todayData.exerciseMinutes,
            exerciseGoal = DAILY_EXERCISE_MINUTES,
            overallScore = overallScore,
            evaluation = evaluation,
            suggestions = generateHealthSuggestions()
        )
    }
    
    /**
     * 生成健康建议
     */
    private fun generateHealthSuggestions(): List<String> {
        val suggestions = mutableListOf<String>()
        
        if (todayData.waterCount < DAILY_WATER_GOAL) {
            suggestions.add("多喝水，保持身体水分充足")
        }
        
        if (todayData.steps < DAILY_STEPS_GOAL) {
            suggestions.add("增加步数，多走动走动")
        }
        
        if (todayData.exerciseMinutes < DAILY_EXERCISE_MINUTES) {
            suggestions.add("坚持运动，增强体质")
        }
        
        if (todayData.currentSittingDuration > 60 * 60 * 1000) {
            suggestions.add("避免久坐，每小时站起来活动")
        }
        
        // 基于情绪的建议
        val emotion = emotionRecognizer.currentEmotion.value
        if (emotion.emotion == com.example.xihe.intelligence.Emotion.STRESSED) {
            suggestions.add("压力较大，建议做些放松运动")
        }
        
        return suggestions
    }
    
    /**
     * 加载今日数据
     */
    private fun loadTodayData() {
        try {
            val savedDate = prefs.getString(KEY_DATE, null)
            val today = LocalDate.now().toString()
            
            // 检查是否是今天的数据
            if (savedDate == today) {
                // 加载今天的数据
                todayData = DailyHealthData(
                    waterCount = prefs.getInt(KEY_WATER_COUNT, 0),
                    lastWaterTime = prefs.getLong(KEY_LAST_WATER_TIME, 0),
                    steps = prefs.getInt(KEY_STEPS, 0),
                    exerciseMinutes = prefs.getInt(KEY_EXERCISE_MINUTES, 0),
                    sittingStartTime = prefs.getLong(KEY_SITTING_START_TIME, 0),
                    screenStartTime = prefs.getLong(KEY_SCREEN_START_TIME, 0),
                    lastPostureCheckTime = prefs.getLong(KEY_LAST_POSTURE_CHECK, 0),
                    hasSleepReminder = prefs.getBoolean(KEY_HAS_SLEEP_REMINDER, false),
                    hasMorningReminder = prefs.getBoolean(KEY_HAS_MORNING_REMINDER, false),
                    hasExerciseReminder = prefs.getBoolean(KEY_HAS_EXERCISE_REMINDER, false),
                    hasStepsAchievement = prefs.getBoolean(KEY_HAS_STEPS_ACHIEVEMENT, false),
                    hasExerciseAchievement = prefs.getBoolean(KEY_HAS_EXERCISE_ACHIEVEMENT, false)
                )
                LogManager.d(TAG, "加载今日健康数据: 水${todayData.waterCount}杯, 步数${todayData.steps}, 运动${todayData.exerciseMinutes}分钟")
            } else {
                // 新的一天，重置数据
                todayData = DailyHealthData()
                saveTodayData() // 保存新的日期
                LogManager.d(TAG, "新的一天，重置健康数据")
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "加载健康数据失败", e)
            todayData = DailyHealthData()
        }
    }
    
    /**
     * 保存今日数据
     */
    private fun saveTodayData() {
        try {
            prefs.edit().apply {
                putString(KEY_DATE, LocalDate.now().toString())
                putInt(KEY_WATER_COUNT, todayData.waterCount)
                putLong(KEY_LAST_WATER_TIME, todayData.lastWaterTime)
                putInt(KEY_STEPS, todayData.steps)
                putInt(KEY_EXERCISE_MINUTES, todayData.exerciseMinutes)
                putLong(KEY_SITTING_START_TIME, todayData.sittingStartTime)
                putLong(KEY_SCREEN_START_TIME, todayData.screenStartTime)
                putLong(KEY_LAST_POSTURE_CHECK, todayData.lastPostureCheckTime)
                putBoolean(KEY_HAS_SLEEP_REMINDER, todayData.hasSleepReminder)
                putBoolean(KEY_HAS_MORNING_REMINDER, todayData.hasMorningReminder)
                putBoolean(KEY_HAS_EXERCISE_REMINDER, todayData.hasExerciseReminder)
                putBoolean(KEY_HAS_STEPS_ACHIEVEMENT, todayData.hasStepsAchievement)
                putBoolean(KEY_HAS_EXERCISE_ACHIEVEMENT, todayData.hasExerciseAchievement)
                apply()
            }
            LogManager.d(TAG, "保存今日健康数据成功")
        } catch (e: Exception) {
            LogManager.e(TAG, "保存健康数据失败", e)
        }
    }
}

/**
 * 健康状态
 */
data class HealthState(
    val waterProgress: Float = 0f,
    val stepsProgress: Float = 0f,
    val exerciseProgress: Float = 0f,
    val lastReminder: HealthReminder? = null,
    val lastReminderTime: Long = 0,
    val dailyData: DailyHealthData = DailyHealthData()
)

/**
 * 📅 每日健康数据
 */
data class DailyHealthData(
    var waterCount: Int = 0,
    var lastWaterTime: Long = 0,
    var steps: Int = 0,
    var exerciseMinutes: Int = 0,
    var sittingStartTime: Long = 0,
    var screenStartTime: Long = 0,
    var lastPostureCheckTime: Long = 0,
    var hasSleepReminder: Boolean = false,
    var hasMorningReminder: Boolean = false,
    var hasExerciseReminder: Boolean = false,
    var hasStepsAchievement: Boolean = false,
    var hasExerciseAchievement: Boolean = false,
    var isExercising: Boolean = false,
    var exerciseStartTime: Long = 0,
    val reminders: MutableList<HealthReminder> = mutableListOf()
) {
    val currentSittingDuration: Long
        get() = if (sittingStartTime > 0) {
            System.currentTimeMillis() - sittingStartTime
        } else 0
    
    val currentScreenTime: Long
        get() = if (screenStartTime > 0) {
            System.currentTimeMillis() - screenStartTime
        } else 0
    
    fun startSitting() {
        if (sittingStartTime == 0L) {
            sittingStartTime = System.currentTimeMillis()
        }
    }
    
    fun resetSittingTime() {
        sittingStartTime = 0
    }
    
    fun startScreenTime() {
        if (screenStartTime == 0L) {
            screenStartTime = System.currentTimeMillis()
        }
    }
    
    fun resetScreenTime() {
        screenStartTime = 0
    }
}

/**
 * 📢 健康提醒
 */
data class HealthReminder(
    val type: ReminderType,
    val priority: Priority,
    val message: String,
    val suggestion: String,
    val icon: String,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * 📋 提醒类型
 */
enum class ReminderType {
    WATER,          // 喝水
    SITTING,        // 久坐
    EYE_REST,       // 用眼休息
    POSTURE,        // 姿势
    SLEEP,          // 睡眠
    MORNING,        // 早晨
    EXERCISE,       // 运动
    ACHIEVEMENT     // 成就
}

/**
 * ⚡ 优先级
 */
enum class Priority {
    LOW, MEDIUM, HIGH
}

/**
 * 📊 健康报告
 */
data class HealthReport(
    val date: LocalDateTime,
    val waterCount: Int,
    val waterGoal: Int,
    val steps: Int,
    val stepsGoal: Int,
    val exerciseMinutes: Int,
    val exerciseGoal: Int,
    val overallScore: Int,
    val evaluation: String,
    val suggestions: List<String>
)
