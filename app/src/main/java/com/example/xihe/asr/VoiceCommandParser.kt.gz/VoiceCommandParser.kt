package com.example.xihe.asr

import com.example.xihe.utils.LogManager

/**
 * 🎯 语音命令智能解析器
 * 将自然语言转换为结构化的操作指令
 */
class VoiceCommandParser {
    
    companion object {
        private const val TAG = "VoiceCommandParser"
    }
    
    /**
     * 解析语音命令
     */
    fun parse(text: String): ParsedCommand {
        LogManager.d(TAG, "🔍 解析命令: $text")
        
        val normalizedText = text.trim().lowercase()
        
        // 1. 检测命令类型
        val commandType = detectCommandType(normalizedText)
        
        // 2. 提取参数
        val params = extractParameters(normalizedText, commandType)
        
        // 3. 计算置信度
        val confidence = calculateConfidence(normalizedText, commandType, params)
        
        val result = ParsedCommand(
            originalText = text,
            commandType = commandType,
            parameters = params,
            confidence = confidence
        )
        
        LogManager.i(TAG, "✅ 解析结果: $commandType (置信度: $confidence)")
        LogManager.d(TAG, "  参数: $params")
        
        return result
    }
    
    /**
     * 检测命令类型
     */
    private fun detectCommandType(text: String): CommandType {
        return when {
            // 应用控制
            text.matches(Regex(".*(打开|启动|运行).*")) -> CommandType.OPEN_APP
            text.matches(Regex(".*(关闭|退出|结束).*")) -> CommandType.CLOSE_APP
            
            // 搜索查询
            text.matches(Regex(".*(搜索|查找|找|查).*")) -> CommandType.SEARCH
            text.matches(Regex(".*(什么|怎么|为什么|哪里|谁).*")) -> CommandType.QUERY
            
            // 媒体控制
            text.matches(Regex(".*(播放|放).*")) -> CommandType.PLAY
            text.matches(Regex(".*(暂停|停).*")) -> CommandType.PAUSE
            text.matches(Regex(".*(继续).*")) -> CommandType.RESUME
            text.matches(Regex(".*(下一个|下一首|切歌).*")) -> CommandType.NEXT
            text.matches(Regex(".*(上一个|上一首).*")) -> CommandType.PREVIOUS
            
            // 系统控制
            text.matches(Regex(".*(音量|声音).*(大|增加|提高|加).*")) -> CommandType.VOLUME_UP
            text.matches(Regex(".*(音量|声音).*(小|减少|降低|减).*")) -> CommandType.VOLUME_DOWN
            text.matches(Regex(".*(亮度).*(大|增加|提高|加).*")) -> CommandType.BRIGHTNESS_UP
            text.matches(Regex(".*(亮度).*(小|减少|降低|减).*")) -> CommandType.BRIGHTNESS_DOWN
            text.matches(Regex(".*(返回|后退).*")) -> CommandType.BACK
            text.matches(Regex(".*(主页|桌面|首页).*")) -> CommandType.HOME
            
            // 导航操作
            text.matches(Regex(".*(向上|往上|上滑).*")) -> CommandType.SCROLL_UP
            text.matches(Regex(".*(向下|往下|下滑).*")) -> CommandType.SCROLL_DOWN
            text.matches(Regex(".*(点击|点|按).*")) -> CommandType.CLICK
            
            // 通讯
            text.matches(Regex(".*(打电话|拨打|呼叫).*")) -> CommandType.CALL
            text.matches(Regex(".*(发消息|发送|聊天).*")) -> CommandType.SEND_MESSAGE
            
            // 日常对话
            text.matches(Regex("(你好|嗨|hi|hello).*")) -> CommandType.GREETING
            text.matches(Regex(".*(谢谢|感谢).*")) -> CommandType.THANKS
            text.matches(Regex(".*(再见|拜拜|bye).*")) -> CommandType.GOODBYE
            
            // 默认为聊天
            else -> CommandType.CHAT
        }
    }
    
    /**
     * 提取参数
     */
    private fun extractParameters(text: String, commandType: CommandType): Map<String, String> {
        val params = mutableMapOf<String, String>()
        
        when (commandType) {
            CommandType.OPEN_APP, CommandType.CLOSE_APP -> {
                // 提取应用名称
                val appName = extractAppName(text)
                if (appName != null) {
                    params["app"] = appName
                }
            }
            
            CommandType.SEARCH, CommandType.QUERY -> {
                // 提取搜索关键词
                val keyword = extractSearchKeyword(text)
                if (keyword != null) {
                    params["keyword"] = keyword
                }
            }
            
            CommandType.PLAY -> {
                // 提取播放内容
                val content = extractPlayContent(text)
                if (content != null) {
                    params["content"] = content
                }
            }
            
            CommandType.CLICK -> {
                // 提取点击目标
                val target = extractClickTarget(text)
                if (target != null) {
                    params["target"] = target
                }
            }
            
            CommandType.CALL, CommandType.SEND_MESSAGE -> {
                // 提取联系人
                val contact = extractContact(text)
                if (contact != null) {
                    params["contact"] = contact
                }
                
                // 提取消息内容
                if (commandType == CommandType.SEND_MESSAGE) {
                    val message = extractMessage(text)
                    if (message != null) {
                        params["message"] = message
                    }
                }
            }
            
            else -> {
                // 其他命令保留原文
                params["text"] = text
            }
        }
        
        return params
    }
    
    /**
     * 提取应用名称
     */
    private fun extractAppName(text: String): String? {
        // 移除命令词
        val cleaned = text
            .replace(Regex("(打开|启动|运行|关闭|退出|结束)"), "")
            .trim()
        
        return if (cleaned.isNotEmpty()) cleaned else null
    }
    
    /**
     * 提取搜索关键词
     */
    private fun extractSearchKeyword(text: String): String? {
        // 移除搜索命令词
        val cleaned = text
            .replace(Regex("(搜索|查找|找|查|帮我|给我)"), "")
            .trim()
        
        return if (cleaned.isNotEmpty()) cleaned else null
    }
    
    /**
     * 提取播放内容
     */
    private fun extractPlayContent(text: String): String? {
        val cleaned = text
            .replace(Regex("(播放|放|帮我|给我)"), "")
            .trim()
        
        return if (cleaned.isNotEmpty()) cleaned else null
    }
    
    /**
     * 提取点击目标
     */
    private fun extractClickTarget(text: String): String? {
        val cleaned = text
            .replace(Regex("(点击|点|按|帮我|给我)"), "")
            .trim()
        
        return if (cleaned.isNotEmpty()) cleaned else null
    }
    
    /**
     * 提取联系人
     */
    private fun extractContact(text: String): String? {
        // 提取"给XXX"或"XXX"
        val match = Regex("给(.+?)(打电话|发消息|发送)").find(text)
        if (match != null) {
            return match.groupValues[1].trim()
        }
        
        val cleaned = text
            .replace(Regex("(打电话|拨打|呼叫|发消息|发送|给|帮我)"), "")
            .trim()
        
        return if (cleaned.isNotEmpty()) cleaned else null
    }
    
    /**
     * 提取消息内容
     */
    private fun extractMessage(text: String): String? {
        // 提取"说XXX"或"内容是XXX"
        val sayMatch = Regex("说(.+)").find(text)
        if (sayMatch != null) {
            return sayMatch.groupValues[1].trim()
        }
        
        val contentMatch = Regex("内容是(.+)").find(text)
        if (contentMatch != null) {
            return contentMatch.groupValues[1].trim()
        }
        
        return null
    }
    
    /**
     * 计算置信度
     */
    private fun calculateConfidence(
        text: String,
        commandType: CommandType,
        params: Map<String, String>
    ): Float {
        var confidence = 0.5f
        
        // 根据命令类型调整
        if (commandType != CommandType.CHAT) {
            confidence += 0.2f
        }
        
        // 根据参数完整性调整
        val requiredParams = getRequiredParams(commandType)
        if (requiredParams.isEmpty() || params.keys.containsAll(requiredParams)) {
            confidence += 0.2f
        }
        
        // 根据文本长度调整
        if (text.length in 3..20) {
            confidence += 0.1f
        }
        
        return confidence.coerceIn(0f, 1f)
    }
    
    /**
     * 获取必需参数
     */
    private fun getRequiredParams(commandType: CommandType): Set<String> {
        return when (commandType) {
            CommandType.OPEN_APP, CommandType.CLOSE_APP -> setOf("app")
            CommandType.SEARCH, CommandType.QUERY -> setOf("keyword")
            CommandType.PLAY -> setOf("content")
            CommandType.CLICK -> setOf("target")
            CommandType.CALL, CommandType.SEND_MESSAGE -> setOf("contact")
            else -> emptySet()
        }
    }
    
    /**
     * 命令类型
     */
    enum class CommandType {
        // 应用控制
        OPEN_APP,
        CLOSE_APP,
        
        // 搜索查询
        SEARCH,
        QUERY,
        
        // 媒体控制
        PLAY,
        PAUSE,
        RESUME,
        NEXT,
        PREVIOUS,
        
        // 系统控制
        VOLUME_UP,
        VOLUME_DOWN,
        BRIGHTNESS_UP,
        BRIGHTNESS_DOWN,
        BACK,
        HOME,
        
        // 导航操作
        SCROLL_UP,
        SCROLL_DOWN,
        CLICK,
        
        // 通讯
        CALL,
        SEND_MESSAGE,
        
        // 日常对话
        GREETING,
        THANKS,
        GOODBYE,
        CHAT
    }
    
    /**
     * 解析结果
     */
    data class ParsedCommand(
        val originalText: String,
        val commandType: CommandType,
        val parameters: Map<String, String>,
        val confidence: Float
    )
}
