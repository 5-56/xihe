package com.example.xihe.asr

import com.example.xihe.utils.LogManager
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * 🎵 音频增强器
 * 提供噪音抑制、音量归一化等功能，提升语音识别质量
 */
class AudioEnhancer {
    
    companion object {
        private const val TAG = "AudioEnhancer"
    }
    
    /**
     * 增强配置
     */
    data class EnhanceConfig(
        val enableNoiseReduction: Boolean = true,      // 噪音抑制
        val enableVolumeNormalization: Boolean = true, // 音量归一化
        val enableSilenceDetection: Boolean = true,    // 静音检测
        val noiseThreshold: Float = 0.1f,              // 噪音阈值
        val silenceThreshold: Float = 0.05f,           // 静音阈值
        val targetVolume: Float = 0.7f                 // 目标音量
    )
    
    private var config = EnhanceConfig()
    
    /**
     * 设置配置
     */
    fun setConfig(newConfig: EnhanceConfig) {
        config = newConfig
        LogManager.d(TAG, "✅ 音频增强配置已更新")
    }
    
    /**
     * 增强音频数据
     */
    fun enhance(audioData: ShortArray): EnhanceResult {
        var enhanced = audioData.copyOf()
        val operations = mutableListOf<String>()
        
        // 1. 检测音频质量
        val quality = analyzeQuality(audioData)
        
        // 2. 噪音抑制
        if (config.enableNoiseReduction && quality.noiseLevel > config.noiseThreshold) {
            enhanced = reduceNoise(enhanced)
            operations.add("噪音抑制")
        }
        
        // 3. 音量归一化
        if (config.enableVolumeNormalization) {
            enhanced = normalizeVolume(enhanced, config.targetVolume)
            operations.add("音量归一化")
        }
        
        // 4. 静音检测
        val isSilence = if (config.enableSilenceDetection) {
            detectSilence(enhanced, config.silenceThreshold)
        } else {
            false
        }
        
        return EnhanceResult(
            originalData = audioData,
            enhancedData = enhanced,
            quality = quality,
            isSilence = isSilence,
            operations = operations
        )
    }
    
    /**
     * 分析音频质量
     */
    private fun analyzeQuality(audioData: ShortArray): AudioQuality {
        if (audioData.isEmpty()) {
            return AudioQuality(0f, 0f, 0f)
        }
        
        // 计算RMS（均方根）- 表示音量
        val rms = calculateRMS(audioData)
        
        // 计算信噪比估计
        val snr = estimateSNR(audioData)
        
        // 计算噪音水平
        val noiseLevel = estimateNoiseLevel(audioData)
        
        return AudioQuality(
            volume = rms,
            snr = snr,
            noiseLevel = noiseLevel
        )
    }
    
    /**
     * 计算RMS（均方根）
     */
    private fun calculateRMS(audioData: ShortArray): Float {
        var sum = 0.0
        for (sample in audioData) {
            val normalized = sample / 32768.0
            sum += normalized * normalized
        }
        return sqrt(sum / audioData.size).toFloat()
    }
    
    /**
     * 估计信噪比
     */
    private fun estimateSNR(audioData: ShortArray): Float {
        // 简化的SNR估计：信号强度 / 噪音强度
        val signalPower = calculateRMS(audioData)
        val noisePower = estimateNoiseLevel(audioData)
        
        return if (noisePower > 0) {
            (signalPower / noisePower).coerceIn(0f, 100f)
        } else {
            100f
        }
    }
    
    /**
     * 估计噪音水平
     */
    private fun estimateNoiseLevel(audioData: ShortArray): Float {
        // 使用最小值法估计噪音
        val windowSize = 100
        val minValues = mutableListOf<Float>()
        
        for (i in 0 until audioData.size step windowSize) {
            val end = minOf(i + windowSize, audioData.size)
            val window = audioData.sliceArray(i until end)
            minValues.add(calculateRMS(window))
        }
        
        return minValues.minOrNull() ?: 0f
    }
    
    /**
     * 噪音抑制
     */
    private fun reduceNoise(audioData: ShortArray): ShortArray {
        val result = ShortArray(audioData.size)
        val noiseLevel = estimateNoiseLevel(audioData)
        val threshold = (noiseLevel * 32768 * 1.5).toInt()
        
        for (i in audioData.indices) {
            result[i] = if (abs(audioData[i].toInt()) < threshold) {
                0
            } else {
                audioData[i]
            }
        }
        
        LogManager.d(TAG, "🔇 噪音抑制: 阈值=$threshold")
        return result
    }
    
    /**
     * 音量归一化
     */
    private fun normalizeVolume(audioData: ShortArray, targetVolume: Float): ShortArray {
        val currentRMS = calculateRMS(audioData)
        if (currentRMS == 0f) return audioData
        
        val gain = targetVolume / currentRMS
        val result = ShortArray(audioData.size)
        
        for (i in audioData.indices) {
            val normalized = (audioData[i] * gain).toInt()
            result[i] = normalized.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        
        LogManager.d(TAG, "🔊 音量归一化: 增益=${String.format("%.2f", gain)}")
        return result
    }
    
    /**
     * 检测静音
     */
    private fun detectSilence(audioData: ShortArray, threshold: Float): Boolean {
        val rms = calculateRMS(audioData)
        val isSilence = rms < threshold
        
        if (isSilence) {
            LogManager.d(TAG, "🔇 检测到静音: RMS=$rms")
        }
        
        return isSilence
    }
    
    /**
     * 音频质量
     */
    data class AudioQuality(
        val volume: Float,      // 音量 (0-1)
        val snr: Float,         // 信噪比
        val noiseLevel: Float   // 噪音水平
    ) {
        val isGood: Boolean
            get() = volume > 0.1f && snr > 10f && noiseLevel < 0.2f
        
        val qualityScore: Float
            get() {
                var score = 0f
                if (volume in 0.2f..0.8f) score += 0.3f
                if (snr > 15f) score += 0.4f
                if (noiseLevel < 0.15f) score += 0.3f
                return score
            }
    }
    
    /**
     * 增强结果
     */
    data class EnhanceResult(
        val originalData: ShortArray,
        val enhancedData: ShortArray,
        val quality: AudioQuality,
        val isSilence: Boolean,
        val operations: List<String>
    ) {
        val improved: Boolean
            get() = operations.isNotEmpty()
    }
}
