package com.example.xihe.asr

import com.example.xihe.utils.LogManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * 🎯 智能语音识别优化器
 * 通过多种策略提升语音识别准确率
 */
class SmartASROptimizer {
    
    companion object {
        private const val TAG = "SmartASROptimizer"
    }
    
    /**
     * 优化策略配置
     */
    data class OptimizationConfig(
        val enableContextCorrection: Boolean = true,      // 上下文纠错
        val enableCommonPhraseCorrection: Boolean = true, // 常用短语纠错
        val enableNumberCorrection: Boolean = true,       // 数字纠错
        val enablePunctuationFix: Boolean = true,         // 标点修复
        val enableLLMCorrection: Boolean = false,         // LLM智能纠错（需要API）
        val confidenceThreshold: Float = 0.6f             // 置信度阈值
    )
    
    private var config = OptimizationConfig()
    private val conversationHistory = mutableListOf<String>()
    private val MAX_HISTORY = 10
    
    // 常见识别错误映射表
    private val commonErrors = mapOf(
        // 同音字纠错
        "在吗" to "在吗",
        "在嘛" to "在吗",
        "在马" to "在吗",
        "你好啊" to "你好啊",
        "你好呀" to "你好啊",
        "打开微信" to "打开微信",
        "打开威信" to "打开微信",
        "打开为信" to "打开微信",
        "关闭微信" to "关闭微信",
        "关闭威信" to "关闭微信",
        
        // 常用指令纠错
        "帮我打开" to "帮我打开",
        "帮我打卡" to "帮我打开",
        "帮我搭开" to "帮我打开",
        "给我打开" to "给我打开",
        "给我搭开" to "给我打开",
        
        // 数字纠错
        "一" to "1",
        "二" to "2",
        "三" to "3",
        "四" to "4",
        "五" to "5",
        "六" to "6",
        "七" to "7",
        "八" to "8",
        "九" to "9",
        "十" to "10",
        
        // 应用名称纠错
        "淘宝" to "淘宝",
        "逃宝" to "淘宝",
        "陶宝" to "淘宝",
        "支付宝" to "支付宝",
        "支付包" to "支付宝",
        "知乎" to "知乎",
        "之乎" to "知乎",
        "抖音" to "抖音",
        "斗音" to "抖音"
    )
    
    // 常用短语模板
    private val commonPhrases = listOf(
        "打开",
        "关闭",
        "帮我",
        "给我",
        "查询",
        "搜索",
        "播放",
        "暂停",
        "继续",
        "停止",
        "你好",
        "在吗",
        "怎么样",
        "什么时候",
        "在哪里",
        "为什么"
    )
    
    /**
     * 设置优化配置
     */
    fun setConfig(newConfig: OptimizationConfig) {
        config = newConfig
        LogManager.d(TAG, "✅ 优化配置已更新")
    }
    
    /**
     * 优化识别结果
     */
    suspend fun optimizeResult(
        rawText: String,
        confidence: Float = 1.0f,
        llmClient: com.example.xihe.core.LLMClient? = null
    ): OptimizationResult = withContext(Dispatchers.Default) {
        LogManager.d(TAG, "🔍 开始优化识别结果: $rawText (置信度: $confidence)")
        
        var optimizedText = rawText
        val corrections = mutableListOf<String>()
        
        // 1. 基础清理
        optimizedText = basicCleanup(optimizedText)
        
        // 2. 常见错误纠正
        if (config.enableCommonPhraseCorrection) {
            val (corrected, changes) = correctCommonErrors(optimizedText)
            optimizedText = corrected
            corrections.addAll(changes)
        }
        
        // 3. 上下文纠错
        if (config.enableContextCorrection && conversationHistory.isNotEmpty()) {
            val (corrected, changes) = correctWithContext(optimizedText)
            optimizedText = corrected
            corrections.addAll(changes)
        }
        
        // 4. 数字纠错
        if (config.enableNumberCorrection) {
            val (corrected, changes) = correctNumbers(optimizedText)
            optimizedText = corrected
            corrections.addAll(changes)
        }
        
        // 5. 标点修复
        if (config.enablePunctuationFix) {
            optimizedText = fixPunctuation(optimizedText)
        }
        
        // 6. LLM智能纠错（可选，需要API）
        if (config.enableLLMCorrection && llmClient != null && confidence < config.confidenceThreshold) {
            try {
                val (corrected, changes) = correctWithLLM(optimizedText, llmClient)
                optimizedText = corrected
                corrections.addAll(changes)
            } catch (e: Exception) {
                LogManager.e(TAG, "LLM纠错失败", e)
            }
        }
        
        // 记录到历史
        addToHistory(optimizedText)
        
        val result = OptimizationResult(
            originalText = rawText,
            optimizedText = optimizedText,
            confidence = confidence,
            corrections = corrections,
            improved = optimizedText != rawText
        )
        
        if (result.improved) {
            LogManager.i(TAG, "✅ 识别结果已优化:")
            LogManager.i(TAG, "  原始: $rawText")
            LogManager.i(TAG, "  优化: $optimizedText")
            LogManager.i(TAG, "  纠正: ${corrections.joinToString(", ")}")
        }
        
        result
    }
    
    /**
     * 基础清理
     */
    private fun basicCleanup(text: String): String {
        return text
            .trim()
            .replace(Regex("\\s+"), " ")  // 多个空格合并为一个
            .replace(Regex("[，。！？；：、]+$"), "")  // 移除末尾多余标点
    }
    
    /**
     * 纠正常见错误
     */
    private fun correctCommonErrors(text: String): Pair<String, List<String>> {
        var corrected = text
        val changes = mutableListOf<String>()
        
        for ((error, correct) in commonErrors) {
            if (corrected.contains(error) && error != correct) {
                corrected = corrected.replace(error, correct)
                changes.add("$error → $correct")
            }
        }
        
        return Pair(corrected, changes)
    }
    
    /**
     * 基于上下文纠错
     */
    private fun correctWithContext(text: String): Pair<String, List<String>> {
        var corrected = text
        val changes = mutableListOf<String>()
        
        // 检查是否是对上一句话的回应
        if (conversationHistory.isNotEmpty()) {
            val lastMessage = conversationHistory.last()
            
            // 如果上一句是问句，当前回答可能是"是"、"对"、"好的"等
            if (lastMessage.contains("吗") || lastMessage.contains("？")) {
                if (text.matches(Regex("^[是对好嗯啊]{1,2}$"))) {
                    // 这些简短回答通常是正确的
                    return Pair(corrected, changes)
                }
            }
            
            // 检查是否在延续上一个话题
            val lastWords = lastMessage.split(" ").takeLast(3)
            for (word in lastWords) {
                if (word.length > 1 && text.contains(word)) {
                    // 话题延续，可能识别正确
                    break
                }
            }
        }
        
        return Pair(corrected, changes)
    }
    
    /**
     * 数字纠错
     */
    private fun correctNumbers(text: String): Pair<String, List<String>> {
        var corrected = text
        val changes = mutableListOf<String>()
        
        // 中文数字转阿拉伯数字
        val chineseNumbers = mapOf(
            "零" to "0", "一" to "1", "二" to "2", "三" to "3", "四" to "4",
            "五" to "5", "六" to "6", "七" to "7", "八" to "8", "九" to "9",
            "十" to "10", "百" to "100", "千" to "1000", "万" to "10000"
        )
        
        // 简单替换（复杂的中文数字转换需要更复杂的逻辑）
        for ((chinese, arabic) in chineseNumbers) {
            if (corrected.contains(chinese)) {
                // 只在特定上下文中转换（如"第一"、"一个"等）
                val pattern = Regex("第?$chinese[个次]?")
                if (pattern.containsMatchIn(corrected)) {
                    val old = corrected
                    corrected = corrected.replace(pattern) { matchResult ->
                        matchResult.value.replace(chinese, arabic)
                    }
                    if (old != corrected) {
                        changes.add("数字转换: $chinese → $arabic")
                    }
                }
            }
        }
        
        return Pair(corrected, changes)
    }
    
    /**
     * 修复标点
     */
    private fun fixPunctuation(text: String): String {
        var fixed = text
        
        // 问句添加问号
        if (fixed.matches(Regex(".*[吗呢啊]$")) && !fixed.endsWith("？")) {
            fixed += "？"
        }
        
        // 感叹句添加感叹号
        if (fixed.matches(Regex("^(哇|啊|哎呀|天啊).*")) && !fixed.endsWith("！")) {
            fixed += "！"
        }
        
        return fixed
    }
    
    /**
     * 使用LLM智能纠错
     */
    private suspend fun correctWithLLM(
        text: String,
        llmClient: com.example.xihe.core.LLMClient
    ): Pair<String, List<String>> = withContext(Dispatchers.IO) {
        val prompt = """
你是一个语音识别纠错助手。用户通过语音输入了以下文本，但可能存在识别错误。
请纠正明显的错误，保持原意，只输出纠正后的文本，不要添加任何解释。

原始文本：$text

纠正后的文本：
        """.trimIndent()
        
        try {
            val corrected = llmClient.chatCompletion(prompt, usePersonality = false).trim()
            val changes = if (corrected != text) {
                listOf("LLM纠错: $text → $corrected")
            } else {
                emptyList()
            }
            Pair(corrected, changes)
        } catch (e: Exception) {
            LogManager.e(TAG, "LLM纠错失败", e)
            Pair(text, emptyList())
        }
    }
    
    /**
     * 添加到历史记录
     */
    private fun addToHistory(text: String) {
        conversationHistory.add(text)
        if (conversationHistory.size > MAX_HISTORY) {
            conversationHistory.removeAt(0)
        }
    }
    
    /**
     * 清空历史记录
     */
    fun clearHistory() {
        conversationHistory.clear()
        LogManager.d(TAG, "🗑️ 对话历史已清空")
    }
    
    /**
     * 优化结果
     */
    data class OptimizationResult(
        val originalText: String,
        val optimizedText: String,
        val confidence: Float,
        val corrections: List<String>,
        val improved: Boolean
    )
    
    /**
     * 添加自定义纠错规则
     */
    fun addCustomRule(error: String, correction: String) {
        (commonErrors as MutableMap)[error] = correction
        LogManager.d(TAG, "✅ 添加自定义规则: $error → $correction")
    }
    
    /**
     * 批量添加自定义规则
     */
    fun addCustomRules(rules: Map<String, String>) {
        (commonErrors as MutableMap).putAll(rules)
        LogManager.d(TAG, "✅ 添加 ${rules.size} 条自定义规则")
    }
}
