package com.example.xihe.asr

import android.content.Context
import com.example.xihe.utils.LogManager

/**
 * 🎯 ASR优化助手
 * 提供常用的优化配置和规则
 */
object ASROptimizationHelper {
    
    private const val TAG = "ASROptimizationHelper"
    
    /**
     * 获取推荐的优化配置
     */
    fun getRecommendedConfig(scenario: Scenario = Scenario.GENERAL): SmartASROptimizer.OptimizationConfig {
        return when (scenario) {
            Scenario.GENERAL -> SmartASROptimizer.OptimizationConfig(
                enableContextCorrection = true,
                enableCommonPhraseCorrection = true,
                enableNumberCorrection = true,
                enablePunctuationFix = true,
                enableLLMCorrection = false,
                confidenceThreshold = 0.6f
            )
            
            Scenario.COMMAND -> SmartASROptimizer.OptimizationConfig(
                enableContextCorrection = false,  // 指令模式不需要上下文
                enableCommonPhraseCorrection = true,
                enableNumberCorrection = true,
                enablePunctuationFix = false,  // 指令不需要标点
                enableLLMCorrection = false,
                confidenceThreshold = 0.7f
            )
            
            Scenario.CHAT -> SmartASROptimizer.OptimizationConfig(
                enableContextCorrection = true,  // 聊天需要上下文
                enableCommonPhraseCorrection = true,
                enableNumberCorrection = false,  // 聊天中数字可能是口语
                enablePunctuationFix = true,
                enableLLMCorrection = false,
                confidenceThreshold = 0.5f  // 聊天可以容忍更低的置信度
            )
            
            Scenario.HIGH_ACCURACY -> SmartASROptimizer.OptimizationConfig(
                enableContextCorrection = true,
                enableCommonPhraseCorrection = true,
                enableNumberCorrection = true,
                enablePunctuationFix = true,
                enableLLMCorrection = true,  // 启用LLM纠错
                confidenceThreshold = 0.8f
            )
        }
    }
    
    /**
     * 使用场景
     */
    enum class Scenario {
        GENERAL,        // 通用场景
        COMMAND,        // 指令场景
        CHAT,           // 聊天场景
        HIGH_ACCURACY   // 高准确度场景
    }
    
    /**
     * 获取常用应用名称纠错规则
     */
    fun getAppNameRules(): Map<String, String> {
        return mapOf(
            // 社交应用
            "微信" to "微信",
            "威信" to "微信",
            "为信" to "微信",
            "QQ" to "QQ",
            "扣扣" to "QQ",
            "抖音" to "抖音",
            "斗音" to "抖音",
            "快手" to "快手",
            "块手" to "快手",
            
            // 购物应用
            "淘宝" to "淘宝",
            "逃宝" to "淘宝",
            "陶宝" to "淘宝",
            "京东" to "京东",
            "惊动" to "京东",
            "拼多多" to "拼多多",
            "品多多" to "拼多多",
            
            // 支付应用
            "支付宝" to "支付宝",
            "支付包" to "支付宝",
            "知付宝" to "支付宝",
            
            // 视频应用
            "爱奇艺" to "爱奇艺",
            "爱其艺" to "爱奇艺",
            "腾讯视频" to "腾讯视频",
            "优酷" to "优酷",
            "有酷" to "优酷",
            "哔哩哔哩" to "哔哩哔哩",
            "B站" to "哔哩哔哩",
            
            // 音乐应用
            "网易云音乐" to "网易云音乐",
            "网易云" to "网易云音乐",
            "QQ音乐" to "QQ音乐",
            "酷狗音乐" to "酷狗音乐",
            "酷狗" to "酷狗音乐",
            
            // 新闻应用
            "今日头条" to "今日头条",
            "头条" to "今日头条",
            "知乎" to "知乎",
            "之乎" to "知乎",
            "智乎" to "知乎",
            
            // 地图应用
            "高德地图" to "高德地图",
            "高德" to "高德地图",
            "百度地图" to "百度地图",
            "百度" to "百度地图",
            
            // 浏览器
            "浏览器" to "浏览器",
            "刘览器" to "浏览器",
            "Chrome" to "Chrome",
            "谷歌浏览器" to "Chrome"
        )
    }
    
    /**
     * 获取常用指令纠错规则
     */
    fun getCommandRules(): Map<String, String> {
        return mapOf(
            // 打开指令
            "打开" to "打开",
            "打卡" to "打开",
            "搭开" to "打开",
            "大开" to "打开",
            
            // 关闭指令
            "关闭" to "关闭",
            "关必" to "关闭",
            "管闭" to "关闭",
            
            // 搜索指令
            "搜索" to "搜索",
            "收缩" to "搜索",
            "搜所" to "搜索",
            
            // 播放指令
            "播放" to "播放",
            "波放" to "播放",
            "拨放" to "播放",
            
            // 暂停指令
            "暂停" to "暂停",
            "站停" to "暂停",
            "赞停" to "暂停",
            
            // 继续指令
            "继续" to "继续",
            "记续" to "继续",
            "及续" to "继续",
            
            // 停止指令
            "停止" to "停止",
            "停之" to "停止",
            "停只" to "停止",
            
            // 查询指令
            "查询" to "查询",
            "查寻" to "查询",
            "察询" to "查询",
            
            // 帮我/给我
            "帮我" to "帮我",
            "帮握" to "帮我",
            "给我" to "给我",
            "给握" to "给我"
        )
    }
    
    /**
     * 获取数字纠错规则
     */
    fun getNumberRules(): Map<String, String> {
        return mapOf(
            "一" to "1",
            "二" to "2",
            "两" to "2",
            "三" to "3",
            "四" to "4",
            "五" to "5",
            "六" to "6",
            "七" to "7",
            "八" to "8",
            "九" to "9",
            "十" to "10"
        )
    }
    
    /**
     * 应用所有推荐规则
     */
    fun applyRecommendedRules(optimizer: SmartASROptimizer) {
        val allRules = mutableMapOf<String, String>()
        allRules.putAll(getAppNameRules())
        allRules.putAll(getCommandRules())
        
        optimizer.addCustomRules(allRules)
        LogManager.i(TAG, "✅ 已应用 ${allRules.size} 条推荐规则")
    }
    
    /**
     * 保存用户自定义规则到本地
     */
    fun saveCustomRules(context: Context, rules: Map<String, String>) {
        val prefs = context.getSharedPreferences("asr_custom_rules", Context.MODE_PRIVATE)
        val editor = prefs.edit()
        
        rules.forEach { (error, correction) ->
            editor.putString(error, correction)
        }
        
        editor.apply()
        LogManager.d(TAG, "💾 已保存 ${rules.size} 条自定义规则")
    }
    
    /**
     * 加载用户自定义规则
     */
    fun loadCustomRules(context: Context): Map<String, String> {
        val prefs = context.getSharedPreferences("asr_custom_rules", Context.MODE_PRIVATE)
        val rules = mutableMapOf<String, String>()
        
        prefs.all.forEach { (key, value) ->
            if (value is String) {
                rules[key] = value
            }
        }
        
        LogManager.d(TAG, "📂 已加载 ${rules.size} 条自定义规则")
        return rules
    }
}
