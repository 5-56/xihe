package com.example.xihe.system

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * ⚙️ 系统控制管理器
 * 提供音量、亮度、WiFi、蓝牙、手电筒等系统设置控制
 */
class SystemControlManager private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "SystemControlManager"
        
        @Volatile
        private var instance: SystemControlManager? = null
        
        fun getInstance(context: Context): SystemControlManager {
            return instance ?: synchronized(this) {
                instance ?: SystemControlManager(context.applicationContext).also { instance = it }
            }
        }
    }
    
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    
    private var flashlightEnabled = false
    
    /**
     * 🔊 音量控制
     */
    object VolumeControl {
        enum class StreamType {
            MUSIC,      // 媒体音量
            RING,       // 铃声音量
            ALARM,      // 闹钟音量
            NOTIFICATION, // 通知音量
            CALL        // 通话音量
        }
        
        private fun getStreamType(type: StreamType): Int {
            return when (type) {
                StreamType.MUSIC -> AudioManager.STREAM_MUSIC
                StreamType.RING -> AudioManager.STREAM_RING
                StreamType.ALARM -> AudioManager.STREAM_ALARM
                StreamType.NOTIFICATION -> AudioManager.STREAM_NOTIFICATION
                StreamType.CALL -> AudioManager.STREAM_VOICE_CALL
            }
        }
    }
    
    /**
     * 🔊 设置音量
     * @param type 音量类型
     * @param volume 音量值 (0-100)
     */
    fun setVolume(type: VolumeControl.StreamType, volume: Int): Boolean {
        return try {
            val streamType = when (type) {
                VolumeControl.StreamType.MUSIC -> AudioManager.STREAM_MUSIC
                VolumeControl.StreamType.RING -> AudioManager.STREAM_RING
                VolumeControl.StreamType.ALARM -> AudioManager.STREAM_ALARM
                VolumeControl.StreamType.NOTIFICATION -> AudioManager.STREAM_NOTIFICATION
                VolumeControl.StreamType.CALL -> AudioManager.STREAM_VOICE_CALL
            }
            
            val maxVolume = audioManager.getStreamMaxVolume(streamType)
            val targetVolume = (volume / 100f * maxVolume).toInt().coerceIn(0, maxVolume)
            
            audioManager.setStreamVolume(streamType, targetVolume, 0)
            LogManager.d(TAG, "✅ 设置${type}音量: $volume% ($targetVolume/$maxVolume)")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "设置音量失败", e)
            false
        }
    }
    
    /**
     * 🔊 获取音量
     */
    fun getVolume(type: VolumeControl.StreamType): Int {
        return try {
            val streamType = when (type) {
                VolumeControl.StreamType.MUSIC -> AudioManager.STREAM_MUSIC
                VolumeControl.StreamType.RING -> AudioManager.STREAM_RING
                VolumeControl.StreamType.ALARM -> AudioManager.STREAM_ALARM
                VolumeControl.StreamType.NOTIFICATION -> AudioManager.STREAM_NOTIFICATION
                VolumeControl.StreamType.CALL -> AudioManager.STREAM_VOICE_CALL
            }
            
            val currentVolume = audioManager.getStreamVolume(streamType)
            val maxVolume = audioManager.getStreamMaxVolume(streamType)
            (currentVolume * 100f / maxVolume).toInt()
        } catch (e: Exception) {
            LogManager.e(TAG, "获取音量失败", e)
            -1
        }
    }
    
    /**
     * 🔇 静音/取消静音
     */
    fun setMute(mute: Boolean): Boolean {
        return try {
            val ringerMode = if (mute) {
                AudioManager.RINGER_MODE_SILENT
            } else {
                AudioManager.RINGER_MODE_NORMAL
            }
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (!notificationManager.isNotificationPolicyAccessGranted) {
                    LogManager.w(TAG, "⚠️ 需要勿扰权限")
                    return false
                }
            }
            
            audioManager.ringerMode = ringerMode
            LogManager.d(TAG, "✅ 设置静音: $mute")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "设置静音失败", e)
            false
        }
    }
    
    /**
     * 📳 设置震动模式
     */
    fun setVibrateMode(enable: Boolean): Boolean {
        return try {
            val ringerMode = if (enable) {
                AudioManager.RINGER_MODE_VIBRATE
            } else {
                AudioManager.RINGER_MODE_NORMAL
            }
            audioManager.ringerMode = ringerMode
            LogManager.d(TAG, "✅ 设置震动模式: $enable")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "设置震动模式失败", e)
            false
        }
    }
    
    /**
     * 🔆 设置屏幕亮度
     * @param brightness 亮度值 (0-100)
     * 注意：需要 WRITE_SETTINGS 权限
     */
    fun setBrightness(brightness: Int): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (!Settings.System.canWrite(context)) {
                    LogManager.w(TAG, "⚠️ 需要修改系统设置权限")
                    return false
                }
            }
            
            val brightnessValue = (brightness / 100f * 255).toInt().coerceIn(0, 255)
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS,
                brightnessValue
            )
            
            LogManager.d(TAG, "✅ 设置屏幕亮度: $brightness%")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "设置屏幕亮度失败", e)
            false
        }
    }
    
    /**
     * 🔆 获取屏幕亮度
     */
    fun getBrightness(): Int {
        return try {
            val brightness = Settings.System.getInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS
            )
            (brightness * 100f / 255).toInt()
        } catch (e: Exception) {
            LogManager.e(TAG, "获取屏幕亮度失败", e)
            -1
        }
    }
    
    /**
     * 🔆 设置自动亮度
     */
    fun setAutoBrightness(enable: Boolean): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (!Settings.System.canWrite(context)) {
                    LogManager.w(TAG, "⚠️ 需要修改系统设置权限")
                    return false
                }
            }
            
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                if (enable) Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
                else Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            )
            
            LogManager.d(TAG, "✅ 设置自动亮度: $enable")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "设置自动亮度失败", e)
            false
        }
    }
    
    /**
     * 📱 设置屏幕超时时间
     * @param seconds 超时时间（秒）
     */
    fun setScreenTimeout(seconds: Int): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (!Settings.System.canWrite(context)) {
                    LogManager.w(TAG, "⚠️ 需要修改系统设置权限")
                    return false
                }
            }
            
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_OFF_TIMEOUT,
                seconds * 1000
            )
            
            LogManager.d(TAG, "✅ 设置屏幕超时: ${seconds}秒")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "设置屏幕超时失败", e)
            false
        }
    }
    
    /**
     * 🔦 手电筒控制
     */
    fun setFlashlight(enable: Boolean): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val cameraId = cameraManager.cameraIdList.firstOrNull() ?: return false
                cameraManager.setTorchMode(cameraId, enable)
                flashlightEnabled = enable
                LogManager.d(TAG, "✅ 设置手电筒: $enable")
                true
            } else {
                LogManager.w(TAG, "⚠️ Android 6.0以下不支持手电筒API")
                false
            }
        } catch (e: CameraAccessException) {
            LogManager.e(TAG, "手电筒控制失败", e)
            false
        }
    }
    
    /**
     * 🔦 切换手电筒
     */
    fun toggleFlashlight(): Boolean {
        return setFlashlight(!flashlightEnabled)
    }
    
    /**
     * 🔦 获取手电筒状态
     */
    fun isFlashlightOn(): Boolean {
        return flashlightEnabled
    }
    
    /**
     * 📡 WiFi控制
     */
    @Suppress("DEPRECATION")
    fun setWifiEnabled(enable: Boolean): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                LogManager.w(TAG, "⚠️ Android 10+ 无法通过代码控制WiFi开关")
                LogManager.w(TAG, "💡 请引导用户手动打开WiFi设置")
                openWifiSettings()
                return false
            }
            
            wifiManager.isWifiEnabled = enable
            LogManager.d(TAG, "✅ 设置WiFi: $enable")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "设置WiFi失败", e)
            false
        }
    }
    
    /**
     * 📡 获取WiFi状态
     */
    @Suppress("DEPRECATION")
    fun isWifiEnabled(): Boolean {
        return try {
            wifiManager.isWifiEnabled
        } catch (e: Exception) {
            false
        }
    }
    
    /**
     * 📡 获取WiFi信息
     */
    @Suppress("DEPRECATION")
    fun getWifiInfo(): WifiInfo? {
        return try {
            val info = wifiManager.connectionInfo
            WifiInfo(
                ssid = info.ssid.replace("\"", ""),
                bssid = info.bssid,
                rssi = info.rssi,
                linkSpeed = info.linkSpeed,
                ipAddress = intToIp(info.ipAddress)
            )
        } catch (e: Exception) {
            LogManager.e(TAG, "获取WiFi信息失败", e)
            null
        }
    }
    
    data class WifiInfo(
        val ssid: String,
        val bssid: String,
        val rssi: Int,
        val linkSpeed: Int,
        val ipAddress: String
    )
    
    private fun intToIp(ip: Int): String {
        return "${ip and 0xFF}.${ip shr 8 and 0xFF}.${ip shr 16 and 0xFF}.${ip shr 24 and 0xFF}"
    }
    
    /**
     * ✈️ 飞行模式控制（需要系统权限）
     */
    fun setAirplaneMode(enable: Boolean): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (!Settings.System.canWrite(context)) {
                    LogManager.w(TAG, "⚠️ 需要修改系统设置权限")
                    return false
                }
            }
            
            Settings.Global.putInt(
                context.contentResolver,
                Settings.Global.AIRPLANE_MODE_ON,
                if (enable) 1 else 0
            )
            
            val intent = Intent(Intent.ACTION_AIRPLANE_MODE_CHANGED)
            intent.putExtra("state", enable)
            context.sendBroadcast(intent)
            
            LogManager.d(TAG, "✅ 设置飞行模式: $enable")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "设置飞行模式失败", e)
            false
        }
    }
    
    /**
     * ✈️ 获取飞行模式状态
     */
    fun isAirplaneModeOn(): Boolean {
        return try {
            Settings.Global.getInt(
                context.contentResolver,
                Settings.Global.AIRPLANE_MODE_ON
            ) != 0
        } catch (e: Exception) {
            false
        }
    }
    
    /**
     * 🔄 设置屏幕自动旋转
     */
    fun setAutoRotate(enable: Boolean): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (!Settings.System.canWrite(context)) {
                    LogManager.w(TAG, "⚠️ 需要修改系统设置权限")
                    return false
                }
            }
            
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.ACCELEROMETER_ROTATION,
                if (enable) 1 else 0
            )
            
            LogManager.d(TAG, "✅ 设置自动旋转: $enable")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "设置自动旋转失败", e)
            false
        }
    }
    
    /**
     * 🌙 勿扰模式控制
     */
    fun setDoNotDisturb(enable: Boolean): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (!notificationManager.isNotificationPolicyAccessGranted) {
                    LogManager.w(TAG, "⚠️ 需要勿扰权限")
                    openDoNotDisturbSettings()
                    return false
                }
                
                val filter = if (enable) {
                    NotificationManager.INTERRUPTION_FILTER_NONE
                } else {
                    NotificationManager.INTERRUPTION_FILTER_ALL
                }
                
                notificationManager.setInterruptionFilter(filter)
                LogManager.d(TAG, "✅ 设置勿扰模式: $enable")
                true
            } else {
                LogManager.w(TAG, "⚠️ Android 6.0以下不支持勿扰模式")
                false
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "设置勿扰模式失败", e)
            false
        }
    }
    
    /**
     * 🌙 获取勿扰模式状态
     */
    fun isDoNotDisturbOn(): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                notificationManager.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_NONE
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }
    
    /**
     * 🔋 获取电池信息
     */
    fun getBatteryInfo(): BatteryInfo {
        return try {
            val intent = context.registerReceiver(
                null,
                android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            )
            
            val level = intent?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = intent?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1) ?: -1
            val percentage = if (level >= 0 && scale > 0) {
                (level * 100f / scale).toInt()
            } else {
                -1
            }
            
            val status = intent?.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, -1) ?: -1
            val isCharging = status == android.os.BatteryManager.BATTERY_STATUS_CHARGING ||
                            status == android.os.BatteryManager.BATTERY_STATUS_FULL
            
            val plugged = intent?.getIntExtra(android.os.BatteryManager.EXTRA_PLUGGED, -1) ?: -1
            val chargingType = when (plugged) {
                android.os.BatteryManager.BATTERY_PLUGGED_AC -> "AC"
                android.os.BatteryManager.BATTERY_PLUGGED_USB -> "USB"
                android.os.BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
                else -> "None"
            }
            
            BatteryInfo(
                percentage = percentage,
                isCharging = isCharging,
                chargingType = chargingType
            )
        } catch (e: Exception) {
            LogManager.e(TAG, "获取电池信息失败", e)
            BatteryInfo(-1, false, "Unknown")
        }
    }
    
    data class BatteryInfo(
        val percentage: Int,
        val isCharging: Boolean,
        val chargingType: String
    )
    
    /**
     * ⚙️ 打开系统设置
     */
    fun openSettings(): Boolean {
        return try {
            val intent = Intent(Settings.ACTION_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "打开设置失败", e)
            false
        }
    }
    
    /**
     * 📡 打开WiFi设置
     */
    fun openWifiSettings(): Boolean {
        return try {
            val intent = Intent(Settings.ACTION_WIFI_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "打开WiFi设置失败", e)
            false
        }
    }
    
    /**
     * 🌙 打开勿扰设置
     */
    fun openDoNotDisturbSettings(): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "打开勿扰设置失败", e)
            false
        }
    }
}
