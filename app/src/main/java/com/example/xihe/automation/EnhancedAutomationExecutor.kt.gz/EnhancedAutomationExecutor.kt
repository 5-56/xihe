package com.example.xihe.automation

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityNodeInfo
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.delay

/**
 * 🚀 增强版自动化执行器
 * 提供更智能、更准确的自动化操作
 */
class EnhancedAutomationExecutor(
    private val accessibilityService: AccessibilityService
) {
    
    companion object {
        private const val TAG = "EnhancedAutomation"
        private const val MAX_RETRY = 3
        private const val RETRY_DELAY = 500L
    }
    
    /**
     * 智能点击 - 支持多种查找策略和重试机制
     */
    suspend fun smartClick(
        target: String,
        strategy: FindStrategy = FindStrategy.AUTO
    ): Boolean {
        LogManager.d(TAG, "🎯 智能点击: $target (策略: $strategy)")
        
        var attempts = 0
        while (attempts < MAX_RETRY) {
            attempts++
            
            val node = findNode(target, strategy)
            if (node != null) {
                // 确保节点可点击
                val clickableNode = findClickableParent(node)
                if (clickableNode != null) {
                    val success = clickableNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    clickableNode.recycle()
                    
                    if (success) {
                        LogManager.i(TAG, "✅ 点击成功: $target")
                        return true
                    }
                }
                node.recycle()
            }
            
            if (attempts < MAX_RETRY) {
                LogManager.w(TAG, "⚠️ 点击失败，重试 $attempts/$MAX_RETRY")
                delay(RETRY_DELAY)
            }
        }
        
        LogManager.e(TAG, "❌ 点击失败: $target")
        return false
    }
    
    /**
     * 智能输入 - 支持多种输入方式
     */
    suspend fun smartInput(
        text: String,
        target: String? = null,
        clearFirst: Boolean = true
    ): Boolean {
        LogManager.d(TAG, "⌨️ 智能输入: $text")
        
        val inputNode = if (target != null) {
            findNode(target, FindStrategy.AUTO)
        } else {
            findFocusedEditText()
        }
        
        if (inputNode == null) {
            LogManager.e(TAG, "❌ 未找到输入框")
            return false
        }
        
        try {
            // 聚焦输入框
            inputNode.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            delay(200)
            
            // 清空现有内容
            if (clearFirst) {
                inputNode.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION)
                delay(100)
            }
            
            // 输入文本
            val arguments = android.os.Bundle()
            arguments.putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                text
            )
            val success = inputNode.performAction(
                AccessibilityNodeInfo.ACTION_SET_TEXT,
                arguments
            )
            
            inputNode.recycle()
            
            if (success) {
                LogManager.i(TAG, "✅ 输入成功: $text")
                return true
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 输入失败", e)
        }
        
        return false
    }
    
    /**
     * 智能滚动 - 支持多种滚动方式
     */
    suspend fun smartScroll(
        direction: ScrollDirection,
        distance: ScrollDistance = ScrollDistance.MEDIUM
    ): Boolean {
        LogManager.d(TAG, "📜 智能滚动: $direction ($distance)")
        
        val rootNode = accessibilityService.rootInActiveWindow ?: return false
        
        try {
            val scrollableNode = findScrollableNode(rootNode)
            if (scrollableNode != null) {
                val action = when (direction) {
                    ScrollDirection.UP -> AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                    ScrollDirection.DOWN -> AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                    ScrollDirection.LEFT -> AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                    ScrollDirection.RIGHT -> AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                }
                
                // 根据距离执行多次滚动
                val times = when (distance) {
                    ScrollDistance.SHORT -> 1
                    ScrollDistance.MEDIUM -> 2
                    ScrollDistance.LONG -> 3
                }
                
                repeat(times) {
                    scrollableNode.performAction(action)
                    delay(300)
                }
                
                scrollableNode.recycle()
                LogManager.i(TAG, "✅ 滚动成功")
                return true
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 滚动失败", e)
        } finally {
            rootNode.recycle()
        }
        
        return false
    }
    
    /**
     * 智能等待 - 等待特定元素出现
     */
    suspend fun smartWait(
        target: String,
        timeout: Long = 5000L,
        checkInterval: Long = 500L
    ): Boolean {
        LogManager.d(TAG, "⏳ 智能等待: $target (超时: ${timeout}ms)")
        
        val startTime = System.currentTimeMillis()
        while (System.currentTimeMillis() - startTime < timeout) {
            val node = findNode(target, FindStrategy.AUTO)
            if (node != null) {
                node.recycle()
                LogManager.i(TAG, "✅ 元素已出现: $target")
                return true
            }
            delay(checkInterval)
        }
        
        LogManager.w(TAG, "⚠️ 等待超时: $target")
        return false
    }
    
    /**
     * 智能验证 - 验证操作是否成功
     */
    suspend fun smartVerify(
        expectedText: String? = null,
        expectedElement: String? = null,
        timeout: Long = 3000L
    ): Boolean {
        LogManager.d(TAG, "🔍 智能验证")
        
        delay(500) // 等待界面更新
        
        val rootNode = accessibilityService.rootInActiveWindow ?: return false
        
        try {
            // 验证文本
            if (expectedText != null) {
                val found = findNodeByText(rootNode, expectedText) != null
                if (found) {
                    LogManager.i(TAG, "✅ 验证成功: 找到文本 '$expectedText'")
                    return true
                }
            }
            
            // 验证元素
            if (expectedElement != null) {
                val found = findNode(expectedElement, FindStrategy.AUTO) != null
                if (found) {
                    LogManager.i(TAG, "✅ 验证成功: 找到元素 '$expectedElement'")
                    return true
                }
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 验证失败", e)
        } finally {
            rootNode.recycle()
        }
        
        LogManager.w(TAG, "⚠️ 验证失败")
        return false
    }
    
    /**
     * 查找节点 - 支持多种查找策略
     */
    private fun findNode(
        target: String,
        strategy: FindStrategy
    ): AccessibilityNodeInfo? {
        val rootNode = accessibilityService.rootInActiveWindow ?: return null
        
        return try {
            when (strategy) {
                FindStrategy.TEXT -> findNodeByText(rootNode, target)
                FindStrategy.ID -> findNodeById(rootNode, target)
                FindStrategy.DESCRIPTION -> findNodeByDescription(rootNode, target)
                FindStrategy.AUTO -> {
                    // 自动尝试多种策略
                    findNodeByText(rootNode, target)
                        ?: findNodeById(rootNode, target)
                        ?: findNodeByDescription(rootNode, target)
                }
            }
        } finally {
            rootNode.recycle()
        }
    }
    
    /**
     * 通过文本查找节点
     */
    private fun findNodeByText(
        root: AccessibilityNodeInfo,
        text: String
    ): AccessibilityNodeInfo? {
        // 精确匹配
        var nodes = root.findAccessibilityNodeInfosByText(text)
        if (nodes.isNotEmpty()) {
            return nodes[0]
        }
        
        // 模糊匹配
        return findNodeRecursive(root) { node ->
            node.text?.toString()?.contains(text, ignoreCase = true) == true
        }
    }
    
    /**
     * 通过ID查找节点
     */
    private fun findNodeById(
        root: AccessibilityNodeInfo,
        id: String
    ): AccessibilityNodeInfo? {
        return findNodeRecursive(root) { node ->
            node.viewIdResourceName?.contains(id) == true
        }
    }
    
    /**
     * 通过描述查找节点
     */
    private fun findNodeByDescription(
        root: AccessibilityNodeInfo,
        description: String
    ): AccessibilityNodeInfo? {
        return findNodeRecursive(root) { node ->
            node.contentDescription?.toString()?.contains(description, ignoreCase = true) == true
        }
    }
    
    /**
     * 递归查找节点
     */
    private fun findNodeRecursive(
        node: AccessibilityNodeInfo,
        predicate: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        if (predicate(node)) {
            return node
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findNodeRecursive(child, predicate)
            if (result != null) {
                return result
            }
            child.recycle()
        }
        
        return null
    }
    
    /**
     * 查找可点击的父节点
     */
    private fun findClickableParent(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var current: AccessibilityNodeInfo? = node
        while (current != null) {
            if (current.isClickable) {
                return current
            }
            current = current.parent
        }
        return null
    }
    
    /**
     * 查找可滚动的节点
     */
    private fun findScrollableNode(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        return findNodeRecursive(root) { node ->
            node.isScrollable
        }
    }
    
    /**
     * 查找聚焦的输入框
     */
    private fun findFocusedEditText(): AccessibilityNodeInfo? {
        val rootNode = accessibilityService.rootInActiveWindow ?: return null
        
        return try {
            findNodeRecursive(rootNode) { node ->
                node.isFocused && node.className == "android.widget.EditText"
            }
        } finally {
            rootNode.recycle()
        }
    }
    
    /**
     * 查找策略
     */
    enum class FindStrategy {
        TEXT,           // 通过文本查找
        ID,             // 通过ID查找
        DESCRIPTION,    // 通过描述查找
        AUTO            // 自动选择策略
    }
    
    /**
     * 滚动方向
     */
    enum class ScrollDirection {
        UP,
        DOWN,
        LEFT,
        RIGHT
    }
    
    /**
     * 滚动距离
     */
    enum class ScrollDistance {
        SHORT,
        MEDIUM,
        LONG
    }
}
