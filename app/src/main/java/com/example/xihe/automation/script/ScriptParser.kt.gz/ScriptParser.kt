package com.example.xihe.automation.script

import com.example.xihe.utils.LogManager
import kotlinx.serialization.json.Json
import kotlinx.serialization.SerializationException

/**
 * 🔍 脚本解析器接口
 * 定义脚本解析的统一接口
 */
interface ScriptParser {
    /**
     * 解析脚本输入
     * @param input 脚本内容（文字或JSON格式）
     * @return 解析结果
     */
    fun parse(input: String): ParseResult
    
    /**
     * 检查输入是否为该解析器支持的格式
     */
    fun canParse(input: String): Boolean
}

/**
 * 📋 JSON 脚本解析器
 * 解析 JSON 格式的脚本定义
 */
class JsonScriptParser : ScriptParser {
    
    companion object {
        private const val TAG = "JsonScriptParser"
    }
    
    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
        encodeDefaults = true
        isLenient = true
    }
    
    override fun canParse(input: String): Boolean {
        val trimmed = input.trim()
        return trimmed.startsWith("{") && trimmed.endsWith("}")
    }
    
    override fun parse(input: String): ParseResult {
        if (input.isBlank()) {
            return ParseResult.Error(listOf(ParseError("input", "JSON 内容为空")))
        }
        
        // 1. 验证 JSON 语法
        val syntaxErrors = validateJsonSyntax(input)
        if (syntaxErrors.isNotEmpty()) {
            return ParseResult.Error(syntaxErrors)
        }
        
        // 2. 尝试解析为 ParsedScript
        return try {
            val script = json.decodeFromString<ParsedScript>(input)
            
            // 3. 验证必需字段
            val validationErrors = validateRequiredFields(script)
            if (validationErrors.isNotEmpty()) {
                return ParseResult.Error(validationErrors)
            }
            
            LogManager.i(TAG, "✅ JSON 脚本解析成功: ${script.metadata.name}")
            ParseResult.Success(script)
            
        } catch (e: SerializationException) {
            LogManager.e(TAG, "JSON 解析失败", e)
            ParseResult.Error(listOf(
                ParseError("json", "JSON 解析失败: ${e.message}")
            ))
        } catch (e: Exception) {
            LogManager.e(TAG, "解析异常", e)
            ParseResult.Error(listOf(
                ParseError("unknown", "解析异常: ${e.message}")
            ))
        }
    }
    
    /**
     * 验证 JSON 语法
     */
    private fun validateJsonSyntax(input: String): List<ParseError> {
        val errors = mutableListOf<ParseError>()
        
        try {
            // 尝试解析为通用 JSON 元素
            Json.parseToJsonElement(input)
        } catch (e: SerializationException) {
            val message = e.message ?: "JSON 语法错误"
            // 尝试提取行号
            val lineMatch = Regex("at line (\\d+)").find(message)
            val line = lineMatch?.groupValues?.get(1)?.toIntOrNull()
            
            errors.add(ParseError(
                field = "json_syntax",
                message = "JSON 语法错误: $message",
                line = line
            ))
        }
        
        return errors
    }
    
    /**
     * 验证必需字段
     */
    private fun validateRequiredFields(script: ParsedScript): List<ParseError> {
        val errors = mutableListOf<ParseError>()
        
        // 验证元数据
        if (script.metadata.name.isBlank()) {
            errors.add(ParseError("metadata.name", "缺少脚本名称"))
        }
        
        // 验证步骤
        if (script.steps.isEmpty()) {
            errors.add(ParseError("steps", "脚本步骤列表为空"))
        }
        
        // 验证每个步骤
        script.steps.forEachIndexed { index, step ->
            if (step.description.isBlank()) {
                errors.add(ParseError("steps[$index].description", "步骤 ${index + 1} 缺少描述"))
            }
            if (step.actionType == ActionType.UNKNOWN) {
                errors.add(ParseError("steps[$index].actionType", "步骤 ${index + 1} 操作类型无效"))
            }
        }
        
        return errors
    }
    
    /**
     * 从 JSON 字符串解析脚本（便捷方法）
     */
    fun parseFromJson(jsonString: String): ParsedScript? {
        return when (val result = parse(jsonString)) {
            is ParseResult.Success -> result.script
            is ParseResult.Error -> {
                LogManager.w(TAG, "解析失败: ${result.errors.joinToString { it.message }}")
                null
            }
        }
    }
}
