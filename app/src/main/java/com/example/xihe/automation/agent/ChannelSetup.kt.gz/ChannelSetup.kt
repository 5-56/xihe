package com.example.xihe.automation.agent

import android.content.Context
import android.content.Intent
import android.provider.Settings
import com.example.xihe.CoreAccessibilityService

object ChannelSetup {
    data class CheckResult(
        val ready: Boolean,
        val message: String,
        val settingsIntent: Intent? = null
    )

    fun checkAccessibility(context: Context): CheckResult {
        val connected = CoreAccessibilityService.getInstance() != null || CoreAccessibilityService.isConnected.value
        if (connected) {
            return CheckResult(true, "Accessibility service is running")
        }
        return CheckResult(
            ready = false,
            message = "Accessibility service is not running. Please enable Xihe accessibility service first.",
            settingsIntent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
