package com.example.xihe.automation.flow

import android.content.Context
import com.example.xihe.automation.AdaptiveExecutionEngine
import com.example.xihe.automation.RuntimeOptimizationAdvice
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json

/**
 * 🤖 智能任务代理
 * 全自动系统的对外统一入口
 */
object IntelligentTaskAgent {
    private const val TAG = "IntelligentTaskAgent"
    private val scope = CoroutineScope(Dispatchers.Default)
    @Volatile
    private var appContext: Context? = null

    /**
     * 初始化系统
     */
    fun initialize(context: Context) {
        LogManager.i(TAG, "正在初始化全自动智能代理...")
        appContext = context.applicationContext
        
        // 🆕 初始化脚本库
        com.example.xihe.automation.script.SmartScriptManager.initialize(context)
        
        // 1. 启动触发器监听
        TriggerManager.startMonitoring()
        
        // 2. 设置触发回调
        TriggerManager.onTriggerMatched = { flow ->
            executeFlow(context, flow)
        }
        
        // 3. 加载预设规则 (模拟从文件或数据库加载)
        loadDefaultRules()
    }

    /**
     * 执行特定流程
     */
    fun executeFlow(context: Context, flow: AutomationFlow) {
        scope.launch {
            WorkflowEngine.executeFlow(context, flow)
        }
    }

    /**
     * 根据脚本JSON执行（支持用户导入）
     */
    fun executeScript(context: Context, jsonScript: String) {
        try {
            val flow = Json.decodeFromString<AutomationFlow>(jsonScript)
            executeFlow(context, flow)
        } catch (e: Exception) {
            LogManager.e(TAG, "脚本解析失败", e)
        }
    }

    /**
     * 执行智能指令（模糊匹配）
     */
    suspend fun executeSmartCommand(context: Context, command: String) {
        LogManager.i(TAG, "🧠 分析智能指令: $command")
        
        val learner = com.example.xihe.training.OnDeviceLearner.getInstance(context)
        
        // 1. 尝试匹配脚本库
        val bestScript = learner.findBestScript(command, threshold = 0.4f)
        
        if (bestScript != null) {
            LogManager.i(TAG, "✨ 找到匹配脚本: ${bestScript.metadata.name} (ID: ${bestScript.id})")
            // TODO: 实现脚本执行逻辑
            LogManager.i(TAG, "📜 脚本包含 ${bestScript.flow.steps.size} 个步骤")
            return
        }
        
        // 2. 如果没有匹配脚本，进入自主模式
        LogManager.i(TAG, "🤔 未找到匹配脚本，启动自主智能体 (Autonomous Agent)...")
        
        val session = com.example.xihe.automation.agent.AutonomousSession(context, command)
        session.start()
    }

    fun getRuntimeReflectionSummary(scope: String): String {
        val ctx = appContext ?: return "暂无"
        return AdaptiveExecutionEngine.getInstance(ctx).getRuntimeReflectionSummary(scope)
    }

    fun getRuntimeOptimizationAdvice(
        scope: String,
        action: String,
        target: String? = null
    ): RuntimeOptimizationAdvice {
        val normalizedAction = action.trim().uppercase().ifBlank { "WAIT" }
        val ctx = appContext ?: return RuntimeOptimizationAdvice(
            originalAction = normalizedAction,
            suggestedAction = normalizedAction,
            waitAfterMs = 0L,
            confidence = 0
        )
        return AdaptiveExecutionEngine.getInstance(ctx)
            .getRuntimeOptimizationAdvice(scope, normalizedAction, target)
    }

    fun recordRuntimeReflection(
        scope: String,
        action: String,
        target: String? = null,
        success: Boolean,
        reason: String? = null,
        durationMs: Long = 1L
    ): String? {
        val ctx = appContext ?: return null
        return AdaptiveExecutionEngine.getInstance(ctx).recordRuntimeReflection(
            scope = scope,
            action = action,
            target = target,
            success = success,
            reason = reason,
            durationMs = durationMs
        )
    }

    /**
     * 停止所有任务
     */
    fun stopAll() {
        TriggerManager.stopMonitoring()
        // WorkflowEngine 需要添加取消机制
    }

    private fun loadDefaultRules() {
        // 示例：每天早上打开微信
        val morningFlow = AutomationFlow(
            id = "daily_morning",
            name = "早安流程",
            triggers = listOf(FlowTrigger(TriggerType.TIME, mapOf("time" to "07:00"))),
            actions = listOf(
                FlowAction("1", ActionType.OPEN_APP, mapOf("app_name" to "微信"), nextActionId = "2"),
                FlowAction("2", ActionType.DELAY, mapOf("time" to "5000"), nextActionId = "3"),
                FlowAction("3", ActionType.SMART_FIND_AND_CLICK, mapOf("target" to "朋友圈"))
            )
        )
        
        TriggerManager.registerFlows(listOf(morningFlow))
    }
}
