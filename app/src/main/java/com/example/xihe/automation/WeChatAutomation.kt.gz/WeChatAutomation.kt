package com.example.xihe.automation

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import com.example.xihe.utils.LogManager
import android.view.accessibility.AccessibilityNodeInfo
import com.example.xihe.CoreAccessibilityService
import kotlinx.coroutines.delay

/**
 * 微信自动化模块
 * 实现发送微信消息功能
 */
object WeChatAutomation {
    private const val TAG = "WeChatAutomation"
    private const val WECHAT_PACKAGE = "com.tencent.mm"
    
    /**
     * 发送微信消息
     * @param contact 联系人名称
     * @param message 消息内容
     * @return 是否成功
     */
    suspend fun sendMessage(contact: String, message: String): Result<String> {
        val service = CoreAccessibilityService.instance
            ?: return Result.failure(Exception("无障碍服务未运行"))
        
        try {
            LogManager.w(TAG, "开始发送微信消息: $contact -> $message")
            
            // 1. 打开微信
            if (!openWeChat(service)) {
                return Result.failure(Exception("无法打开微信"))
            }
            
            delay(1500)
            
            // 2. 点击搜索
            if (!clickSearch(service)) {
                return Result.failure(Exception("无法找到搜索按钮"))
            }
            
            delay(800)
            
            // 3. 输入联系人名称
            if (!inputText(service, contact)) {
                return Result.failure(Exception("无法输入联系人名称"))
            }
            
            delay(1000)
            
            // 4. 点击第一个搜索结果
            if (!clickFirstResult(service)) {
                return Result.failure(Exception("未找到联系人"))
            }
            
            delay(1000)
            
            // 5. 输入消息
            if (!inputMessage(service, message)) {
                return Result.failure(Exception("无法输入消息"))
            }
            
            delay(500)
            
            // 6. 点击发送
            if (!clickSend(service)) {
                return Result.failure(Exception("无法点击发送"))
            }
            
            LogManager.w(TAG, "✅ 微信消息发送成功!")
            return Result.success("消息已发送给 $contact 啦～ ✉️")
            
        } catch (e: Exception) {
            LogManager.e(TAG, "发送微信消息失败", e)
            return Result.failure(e)
        }
    }
    
    /**
     * 打开微信
     */
    private suspend fun openWeChat(service: AccessibilityService): Boolean {
        try {
            val intent = service.packageManager.getLaunchIntentForPackage(WECHAT_PACKAGE)
            if (intent != null) {
                intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                service.startActivity(intent)
                delay(2000) // 等待微信启动
                return true
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "打开微信失败", e)
        }
        return false
    }
    
    /**
     * 点击搜索按钮
     */
    private fun clickSearch(service: AccessibilityService): Boolean {
        val root = service.rootInActiveWindow ?: return false
        
        // 尝试多种方式查找搜索按钮
        val searchButton = findNodeByText(root, "搜索")
            ?: findNodeByResourceId(root, "com.tencent.mm:id/f8y")
            ?: findNodeByDescription(root, "搜索")
        
        return searchButton?.let {
            it.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            true
        } ?: false
    }
    
    /**
     * 输入文本
     */
    private fun inputText(service: AccessibilityService, text: String): Boolean {
        val root = service.rootInActiveWindow ?: return false
        
        val editText = findEditText(root)
        return editText?.let {
            val arguments = Bundle()
            arguments.putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                text
            )
            it.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
            true
        } ?: false
    }
    
    /**
     * 点击第一个搜索结果
     */
    private fun clickFirstResult(service: AccessibilityService): Boolean {
        val root = service.rootInActiveWindow ?: return false
        
        // 查找可点击的ListView项
        val firstResult = findClickableListItem(root)
        return firstResult?.let {
            it.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            true
        } ?: false
    }
    
    /**
     * 输入消息
     */
    private fun inputMessage(service: AccessibilityService, message: String): Boolean {
        val root = service.rootInActiveWindow ?: return false
        
        // 查找消息输入框
        val messageBox = findNodeByResourceId(root, "com.tencent.mm:id/aky")
            ?: findEditText(root)
        
        return messageBox?.let {
            val arguments = Bundle()
            arguments.putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                message
            )
            it.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
            true
        } ?: false
    }
    
    /**
     * 点击发送按钮
     */
    private fun clickSend(service: AccessibilityService): Boolean {
        val root = service.rootInActiveWindow ?: return false
        
        val sendButton = findNodeByText(root, "发送")
            ?: findNodeByResourceId(root, "com.tencent.mm:id/akz")
        
        return sendButton?.let {
            it.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            true
        } ?: false
    }
    
    // ========== 辅助函数 ==========
    
    private fun findNodeByText(root: AccessibilityNodeInfo, text: String): AccessibilityNodeInfo? {
        if (root.text?.toString()?.contains(text) == true && root.isClickable) {
            return root
        }
        for (i in 0 until root.childCount) {
            val child = root.getChild(i) ?: continue
            val result = findNodeByText(child, text)
            if (result != null) return result
        }
        return null
    }
    
    private fun findNodeByResourceId(root: AccessibilityNodeInfo, id: String): AccessibilityNodeInfo? {
        if (root.viewIdResourceName == id) {
            return root
        }
        for (i in 0 until root.childCount) {
            val child = root.getChild(i) ?: continue
            val result = findNodeByResourceId(child, id)
            if (result != null) return result
        }
        return null
    }
    
    private fun findNodeByDescription(root: AccessibilityNodeInfo, desc: String): AccessibilityNodeInfo? {
        if (root.contentDescription?.toString()?.contains(desc) == true && root.isClickable) {
            return root
        }
        for (i in 0 until root.childCount) {
            val child = root.getChild(i) ?: continue
            val result = findNodeByDescription(child, desc)
            if (result != null) return result
        }
        return null
    }
    
    private fun findEditText(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (root.className == "android.widget.EditText" && root.isEditable) {
            return root
        }
        for (i in 0 until root.childCount) {
            val child = root.getChild(i) ?: continue
            val result = findEditText(child)
            if (result != null) return result
        }
        return null
    }
    
    private fun findClickableListItem(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        // 查找ListView或RecyclerView的第一个可点击项
        if (root.isClickable && root.className?.contains("LinearLayout") == true) {
            return root
        }
        for (i in 0 until root.childCount) {
            val child = root.getChild(i) ?: continue
            if (child.isClickable) {
                return child
            }
        }
        return null
    }
}
