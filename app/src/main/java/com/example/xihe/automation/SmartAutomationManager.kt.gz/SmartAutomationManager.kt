package com.example.xihe.automation

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import com.example.xihe.utils.LogManager
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.core.ScreenAnalyzer
import com.example.xihe.learning.FeedbackLearningSystem
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * 🤖 智能自动化管理器 (Smart Automation Manager)
 * 
 * 统一管理所有自动化操作，提供智能执行和错误恢复能力
 * 
 * 功能：
 * 1. 手势操作 - 滑动、点击、长按
 * 2. 应用操作 - 打开、关闭、切换应用
 * 3. 系统操作 - 截图、音量、亮度等
 * 4. 导航操作 - 返回、主页、最近任务
 * 5. 文本操作 - 输入、复制、粘贴
 * 6. 智能重试 - 失败时自动重试
 * 7. 错误恢复 - 智能处理异常情况
 */
object SmartAutomationManager {
    
    private const val TAG = "SmartAutomation"
    private val actionMutex = Mutex()
    
    // ==================== 执行结果 ====================
    
    sealed class ExecutionResult {
        data class Success(val message: String, val details: Map<String, Any> = emptyMap()) : ExecutionResult()
        data class Failure(val error: String, val canRetry: Boolean = true) : ExecutionResult()
        data class NeedPermission(val permission: String, val description: String) : ExecutionResult()
    }
    
    private data class RuntimeActionPlan(
        val action: String,
        val params: Map<String, Any>,
        val waitAfterMs: Long,
        val reflectionTarget: String?,
        val shouldTerminate: Boolean
    )

    private fun buildRuntimePlan(
        reflectionEngine: AdaptiveExecutionEngine,
        runtimeScope: String,
        action: String,
        params: Map<String, Any>
    ): RuntimeActionPlan {
        val normalizedAction = action.trim().lowercase().ifBlank { "click" }
        val target = extractRuntimeTarget(normalizedAction, params)
        val advice = reflectionEngine.getRuntimeOptimizationAdvice(
            scope = runtimeScope,
            action = normalizedAction,
            target = target
        )
        val shouldTerminate = advice.suggestedAction.trim().equals("STOP", ignoreCase = true)
        val runtimeAction = if (shouldTerminate) {
            "stop"
        } else {
            normalizeSmartActionName(advice.suggestedAction, normalizedAction)
        }
        val suggestedParams = adjustParamsForSuggestedAction(advice.suggestedAction, params)
        val runtimeParams = applyRuntimeParamAdjustments(runtimeAction, suggestedParams, advice.paramAdjustments)
        return RuntimeActionPlan(
            action = runtimeAction,
            params = runtimeParams,
            waitAfterMs = if (shouldTerminate) 0L else advice.waitAfterMs.coerceAtLeast(0L),
            reflectionTarget = target,
            shouldTerminate = shouldTerminate
        )
    }

    private fun normalizeSmartActionName(suggestedAction: String, fallbackAction: String): String {
        val fallback = fallbackAction.trim().lowercase().ifBlank { "click" }
        val candidate = suggestedAction.trim().uppercase().ifBlank { fallback.uppercase() }
        return when (candidate) {
            "CLICK", "CLICK_FUZZY", "CLICK_TEXT" -> "click"
            "SWIPE", "SWIPE_UP", "SWIPE_DOWN", "SCROLL", "SCROLL_UP", "SCROLL_DOWN" -> "swipe"
            "LONG_PRESS" -> "long_press"
            "BACK", "PRESS_BACK" -> "back"
            "HOME" -> "home"
            "RECENT", "RECENT_APPS" -> "recent_apps"
            "SCREENSHOT", "TAKE_SCREENSHOT" -> "screenshot"
            "OPEN_APP", "OPEN APP", "LAUNCH", "LAUNCH_APP" -> "open_app"
            "INPUT", "INPUT_TEXT", "TYPE", "INPUT TO" -> "input_text"
            "WAIT", "DELAY" -> "wait"
            "VOLUME_UP" -> "volume_up"
            "VOLUME_DOWN" -> "volume_down"
            "SETTINGS" -> "settings"
            "LOCK_SCREEN", "LOCK" -> "lock_screen"
            "STOP" -> "stop"
            else -> fallback
        }
    }

    private fun adjustParamsForSuggestedAction(
        suggestedAction: String,
        params: Map<String, Any>
    ): Map<String, Any> {
        val candidate = suggestedAction.trim().uppercase()
        return when (candidate) {
            "SWIPE_UP", "SCROLL_UP" -> params + ("direction" to "UP")
            "SWIPE_DOWN", "SCROLL_DOWN" -> params + ("direction" to "DOWN")
            "WAIT", "DELAY" -> {
                if (params.containsKey("time") || params.containsKey("duration") || params.containsKey("wait_ms")) {
                    params
                } else {
                    params + ("time" to 800L)
                }
            }
            else -> params
        }
    }

    private fun applyRuntimeParamAdjustments(
        action: String,
        params: Map<String, Any>,
        paramAdjustments: Map<String, String>
    ): Map<String, Any> {
        if (paramAdjustments.isEmpty()) {
            return params
        }
        val adjusted = params.toMutableMap()
        when (action) {
            "swipe" -> {
                paramAdjustments["direction"]?.trim()?.takeIf { it.isNotEmpty() }?.let {
                    adjusted["direction"] = it.uppercase()
                }
                val distance = paramAdjustments["distance"]?.toFloatOrNull()
                if (distance != null) {
                    adjusted["distance"] = distance.coerceIn(120f, 1200f)
                }
            }
            "wait", "delay" -> {
                val waitMs = paramAdjustments["time"]?.toLongOrNull()
                    ?: paramAdjustments["wait_ms"]?.toLongOrNull()
                    ?: paramAdjustments["duration"]?.toLongOrNull()
                if (waitMs != null) {
                    adjusted["time"] = waitMs.coerceIn(200L, 10000L)
                }
            }
            else -> {
                paramAdjustments.forEach { (key, value) ->
                    if (adjusted[key] == null) {
                        adjusted[key] = value
                    }
                }
            }
        }
        return adjusted
    }

    private fun extractRuntimeTarget(action: String, params: Map<String, Any>): String? {
        return when (action) {
            "click" -> params["text"]?.toString() ?: params["label"]?.toString() ?: params["position"]?.toString()
            "open_app" -> params["app"]?.toString() ?: params["app_name"]?.toString()
            "swipe" -> {
                val direction = params["direction"]?.toString()?.uppercase() ?: "UP"
                val distance = (params["distance"] as? Number)?.toFloat()
                    ?: params["distance"]?.toString()?.toFloatOrNull()
                    ?: 400f
                "direction=$direction|distance=${distance.toInt().coerceIn(120, 1200)}"
            }
            "wait", "delay" -> {
                val waitMs = (params["time"] as? Number)?.toLong()
                    ?: (params["duration"] as? Number)?.toLong()
                    ?: (params["wait_ms"] as? Number)?.toLong()
                    ?: params["time"]?.toString()?.toLongOrNull()
                    ?: params["duration"]?.toString()?.toLongOrNull()
                    ?: params["wait_ms"]?.toString()?.toLongOrNull()
                    ?: 800L
                "wait_ms=${waitMs.coerceIn(200L, 10000L)}"
            }
            "settings" -> params["type"]?.toString()
            "input_text" -> params["field"]?.toString() ?: params["hint"]?.toString() ?: "text_input"
            else -> params["target"]?.toString()
        }?.trim()?.takeIf { it.isNotEmpty() }
    }

    private fun resolveResultReason(result: ExecutionResult): String? {
        return when (result) {
            is ExecutionResult.Success -> result.message
            is ExecutionResult.Failure -> result.error
            is ExecutionResult.NeedPermission -> result.description
        }
    }

    private fun buildRuntimeReflectionParameters(action: String, params: Map<String, Any>): Map<String, String> {
        return when (action) {
            "swipe" -> {
                val direction = params["direction"]?.toString()?.trim()?.uppercase()?.takeIf { it.isNotEmpty() }
                val distance = (params["distance"] as? Number)?.toLong()
                    ?: params["distance"]?.toString()?.toLongOrNull()
                buildMap {
                    direction?.let { put("direction", it) }
                    distance?.let { put("distance", it.coerceIn(120L, 1200L).toString()) }
                }
            }
            "wait", "delay" -> {
                val waitMs = (params["time"] as? Number)?.toLong()
                    ?: (params["duration"] as? Number)?.toLong()
                    ?: (params["wait_ms"] as? Number)?.toLong()
                    ?: params["time"]?.toString()?.toLongOrNull()
                    ?: params["duration"]?.toString()?.toLongOrNull()
                    ?: params["wait_ms"]?.toString()?.toLongOrNull()
                if (waitMs == null) {
                    emptyMap()
                } else {
                    mapOf("time" to waitMs.coerceIn(200L, 10000L).toString())
                }
            }
            else -> emptyMap()
        }
    }

    // ==================== 手势操作 ====================
    
    /**
     * 执行滑动操作（优化版，使用suspend函数等待完成）
     */
    suspend fun swipe(
        direction: String,
        distance: Float = 400f,
        duration: Long = 300L
    ): ExecutionResult {
        LogManager.d(TAG, "🎯 执行滑动: $direction, 距离: $distance")
        
        val service = CoreAccessibilityService.instance
            ?: return ExecutionResult.NeedPermission("无障碍服务", "需要开启无障碍服务才能执行滑动操作")
        
        return try {
            val displayMetrics = service.resources.displayMetrics
            val width = displayMetrics.widthPixels.toFloat()
            val height = displayMetrics.heightPixels.toFloat()
            val halfDistance = distance / 2
            
            val (startX, startY, endX, endY) = when (direction.uppercase()) {
                "UP" -> listOf(width / 2, height / 2 + halfDistance, width / 2, height / 2 - halfDistance)
                "DOWN" -> listOf(width / 2, height / 2 - halfDistance, width / 2, height / 2 + halfDistance)
                "LEFT" -> listOf(width / 2 + halfDistance, height / 2, width / 2 - halfDistance, height / 2)
                "RIGHT" -> listOf(width / 2 - halfDistance, height / 2, width / 2 + halfDistance, height / 2)
                else -> listOf(width / 2, height / 2 + halfDistance, width / 2, height / 2 - halfDistance)
            }
            
            // 🆕 使用suspend函数等待完成
            val success = service.swipeAsync(startX, startY, endX, endY, duration)
            
            val directionChinese = when (direction.uppercase()) {
                "UP" -> "向上"
                "DOWN" -> "向下"
                "LEFT" -> "向左"
                "RIGHT" -> "向右"
                else -> "向上"
            }
            
            if (success) {
                ExecutionResult.Success("${directionChinese}滑动成功", mapOf("direction" to direction))
            } else {
                ExecutionResult.Failure("${directionChinese}滑动被取消")
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "滑动失败", e)
            ExecutionResult.Failure("滑动失败: ${e.message}")
        }
    }
    
    /**
     * 执行点击操作（优化版，使用suspend函数等待完成）
     */
    suspend fun click(
        x: Float? = null,
        y: Float? = null,
        position: String = "center"
    ): ExecutionResult {
        LogManager.d(TAG, "🎯 执行点击: position=$position, x=$x, y=$y")
        
        val service = CoreAccessibilityService.instance
            ?: return ExecutionResult.NeedPermission("无障碍服务", "需要开启无障碍服务才能执行点击操作")
        
        return try {
            val displayMetrics = service.resources.displayMetrics
            val width = displayMetrics.widthPixels.toFloat()
            val height = displayMetrics.heightPixels.toFloat()
            
            val (clickX, clickY) = if (x != null && y != null) {
                Pair(x, y)
            } else {
                when (position.lowercase()) {
                    "top" -> Pair(width / 2, height * 0.15f)
                    "bottom" -> Pair(width / 2, height * 0.85f)
                    "left" -> Pair(width * 0.15f, height / 2)
                    "right" -> Pair(width * 0.85f, height / 2)
                    "top_left" -> Pair(width * 0.15f, height * 0.15f)
                    "top_right" -> Pair(width * 0.85f, height * 0.15f)
                    "bottom_left" -> Pair(width * 0.15f, height * 0.85f)
                    "bottom_right" -> Pair(width * 0.85f, height * 0.85f)
                    else -> Pair(width / 2, height / 2)
                }
            }
            
            // 🆕 使用suspend函数等待完成
            val success = service.tapAsync(clickX, clickY)
            
            if (success) {
                ExecutionResult.Success("点击成功", mapOf("x" to clickX, "y" to clickY))
            } else {
                ExecutionResult.Failure("点击被取消")
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "点击失败", e)
            ExecutionResult.Failure("点击失败: ${e.message}")
        }
    }
    
    /**
     * 执行长按操作（优化版，使用suspend函数等待完成）
     */
    suspend fun longPress(
        x: Float? = null,
        y: Float? = null,
        duration: Long = 800L
    ): ExecutionResult {
        LogManager.d(TAG, "🎯 执行长按: x=$x, y=$y, duration=$duration")
        
        val service = CoreAccessibilityService.instance
            ?: return ExecutionResult.NeedPermission("无障碍服务", "需要开启无障碍服务才能执行长按操作")
        
        return try {
            val displayMetrics = service.resources.displayMetrics
            val pressX = x ?: (displayMetrics.widthPixels / 2f)
            val pressY = y ?: (displayMetrics.heightPixels / 2f)
            
            // 🆕 使用suspend函数等待完成
            val success = service.longPressAsync(pressX, pressY, duration)
            
            if (success) {
                ExecutionResult.Success("长按成功", mapOf("x" to pressX, "y" to pressY))
            } else {
                ExecutionResult.Failure("长按被取消")
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "长按失败", e)
            ExecutionResult.Failure("长按失败: ${e.message}")
        }
    }
    
    suspend fun inputText(
        text: String
    ): ExecutionResult {
        val normalizedText = text.trim()
        if (normalizedText.isEmpty()) {
            return ExecutionResult.Failure("输入内容为空", canRetry = false)
        }

        LogManager.d(TAG, "🎯 执行输入: length=${normalizedText.length}")

        val service = CoreAccessibilityService.instance
            ?: return ExecutionResult.NeedPermission("无障碍服务", "需要开启无障碍服务才能执行输入操作")

        return try {
            val success = service.inputText(normalizedText)
            if (success) {
                ExecutionResult.Success("输入成功", mapOf("length" to normalizedText.length))
            } else {
                ExecutionResult.Failure("输入失败")
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "输入失败", e)
            ExecutionResult.Failure("输入失败: ${e.message}")
        }
    }

    // ==================== 导航操作 ====================
    
    /**
     * 执行返回操作
     */
    suspend fun goBack(): ExecutionResult {
        LogManager.d(TAG, "🎯 执行返回")
        
        val service = CoreAccessibilityService.instance
            ?: return ExecutionResult.NeedPermission("无障碍服务", "需要开启无障碍服务才能执行返回操作")
        
        return try {
            service.performGlobalBack()
            delay(300)
            ExecutionResult.Success("返回成功")
        } catch (e: Exception) {
            ExecutionResult.Failure("返回失败: ${e.message}")
        }
    }
    
    /**
     * 返回主页
     */
    suspend fun goHome(): ExecutionResult {
        LogManager.d(TAG, "🎯 返回主页")
        
        val service = CoreAccessibilityService.instance
            ?: return ExecutionResult.NeedPermission("无障碍服务", "需要开启无障碍服务才能返回主页")
        
        return try {
            service.performGlobalHome()
            delay(500)
            ExecutionResult.Success("已返回主页")
        } catch (e: Exception) {
            ExecutionResult.Failure("返回主页失败: ${e.message}")
        }
    }
    
    /**
     * 打开最近任务
     */
    suspend fun openRecentApps(): ExecutionResult {
        LogManager.d(TAG, "🎯 打开最近任务")
        
        val service = CoreAccessibilityService.instance
            ?: return ExecutionResult.NeedPermission("无障碍服务", "需要开启无障碍服务才能打开最近任务")
        
        return try {
            service.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS)
            delay(500)
            ExecutionResult.Success("已打开最近任务")
        } catch (e: Exception) {
            ExecutionResult.Failure("打开最近任务失败: ${e.message}")
        }
    }
    
    // ==================== 应用操作 ====================
    
    /**
     * 打开应用
     */
    suspend fun openApp(context: Context, appName: String): ExecutionResult {
        LogManager.d(TAG, "🎯 打开应用: $appName")
        
        val packageName = getPackageName(appName)
        
        return try {
            val pm = context.packageManager
            val launchIntent = pm.getLaunchIntentForPackage(packageName)
            
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                delay(1000)
                ExecutionResult.Success("已打开$appName", mapOf("package" to packageName))
            } else {
                // 尝试通过应用名称搜索
                val intent = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_LAUNCHER)
                }
                
                val apps = pm.queryIntentActivities(intent, 0)
                val matchedApp = apps.find { 
                    it.loadLabel(pm).toString().contains(appName, ignoreCase = true) 
                }
                
                if (matchedApp != null) {
                    val appIntent = pm.getLaunchIntentForPackage(matchedApp.activityInfo.packageName)
                    if (appIntent != null) {
                        appIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(appIntent)
                        delay(1000)
                        return ExecutionResult.Success("已打开$appName")
                    }
                }
                
                ExecutionResult.Failure("未找到应用: $appName", canRetry = false)
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "打开应用失败", e)
            ExecutionResult.Failure("打开应用失败: ${e.message}")
        }
    }
    
    /**
     * 获取应用包名
     */
    private fun getPackageName(appName: String): String {
        val packageMap = mapOf(
            "微信" to "com.tencent.mm",
            "qq" to "com.tencent.mobileqq",
            "抖音" to "com.ss.android.ugc.aweme",
            "快手" to "com.smile.gifmaker",
            "淘宝" to "com.taobao.taobao",
            "支付宝" to "com.eg.android.AlipayGphone",
            "美团" to "com.sankuai.meituan",
            "饿了么" to "me.ele",
            "哔哩哔哩" to "tv.danmaku.bili",
            "b站" to "tv.danmaku.bili",
            "bilibili" to "tv.danmaku.bili",
            "微博" to "com.sina.weibo",
            "知乎" to "com.zhihu.android",
            "网易云音乐" to "com.netease.cloudmusic",
            "qq音乐" to "com.tencent.qqmusic",
            "酷狗音乐" to "com.kugou.android",
            "高德地图" to "com.autonavi.minimap",
            "高德" to "com.autonavi.minimap",
            "百度地图" to "com.baidu.BaiduMap",
            "滴滴" to "com.sdu.didi.psnger",
            "京东" to "com.jingdong.app.mall",
            "拼多多" to "com.xunmeng.pinduoduo",
            "小红书" to "com.xingin.xhs",
            "钉钉" to "com.alibaba.android.rimet",
            "飞书" to "com.ss.android.lark",
            "telegram" to "org.telegram.messenger",
            "电报" to "org.telegram.messenger",
            "chrome" to "com.android.chrome",
            "浏览器" to "com.android.browser"
        )
        
        return packageMap[appName.lowercase()] ?: appName
    }
    
    // ==================== 系统操作 ====================
    
    /**
     * 执行锁屏
     */
    suspend fun lockScreen(): ExecutionResult {
        LogManager.d(TAG, "🎯 执行锁屏")

        val service = CoreAccessibilityService.instance
            ?: return ExecutionResult.NeedPermission("无障碍服务", "需要开启无障碍服务才能锁屏")

        return try {
            val success = service.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
            if (success) {
                ExecutionResult.Success("已锁屏")
            } else {
                ExecutionResult.Failure("锁屏失败")
            }
        } catch (e: Exception) {
            ExecutionResult.Failure("锁屏失败: ${e.message}")
        }
    }

    suspend fun takeScreenshot(): ExecutionResult {
        LogManager.d(TAG, "🎯 执行截图")
        
        val service = CoreAccessibilityService.instance
            ?: return ExecutionResult.NeedPermission("无障碍服务", "需要开启无障碍服务才能截图")
        
        return try {
            // 使用全局操作进行截图
            service.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
            delay(500)
            ExecutionResult.Success("截图成功")
        } catch (e: Exception) {
            ExecutionResult.Failure("截图失败: ${e.message}")
        }
    }
    
    /**
     * 调节音量
     */
    suspend fun adjustVolume(context: Context, increase: Boolean): ExecutionResult {
        LogManager.d(TAG, "🎯 调节音量: ${if (increase) "增大" else "减小"}")
        
        return try {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
            val direction = if (increase) 
                android.media.AudioManager.ADJUST_RAISE 
            else 
                android.media.AudioManager.ADJUST_LOWER
            
            audioManager.adjustVolume(direction, android.media.AudioManager.FLAG_SHOW_UI)
            
            ExecutionResult.Success(if (increase) "音量已增大" else "音量已减小")
        } catch (e: Exception) {
            ExecutionResult.Failure("调节音量失败: ${e.message}")
        }
    }
    
    /**
     * 打开设置页面
     */
    suspend fun openSettings(context: Context, settingType: String = "main"): ExecutionResult {
        LogManager.d(TAG, "🎯 打开设置: $settingType")
        
        return try {
            val intent = when (settingType.lowercase()) {
                "wifi" -> Intent(Settings.ACTION_WIFI_SETTINGS)
                "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
                "display" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
                "sound" -> Intent(Settings.ACTION_SOUND_SETTINGS)
                "battery" -> Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
                "storage" -> Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)
                "accessibility" -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                "location" -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                "app" -> Intent(Settings.ACTION_APPLICATION_SETTINGS)
                else -> Intent(Settings.ACTION_SETTINGS)
            }
            
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            delay(500)
            
            ExecutionResult.Success("已打开设置")
        } catch (e: Exception) {
            ExecutionResult.Failure("打开设置失败: ${e.message}")
        }
    }
    
    // ==================== 屏幕分析 ====================
    
    /**
     * 分析屏幕内容
     */
    fun analyzeScreen(): ScreenAnalyzer.ScreenSummary? {
        val service = CoreAccessibilityService.instance ?: return null
        val rootNode = service.rootInActiveWindow ?: return null
        val packageName = rootNode.packageName?.toString() ?: "unknown"
        
        val summary = ScreenAnalyzer.getScreenSummary(rootNode, packageName)
        rootNode.recycle()
        
        return summary
    }
    
    /**
     * 查找屏幕元素
     */
    fun findElement(text: String): FindResult? {
        val service = CoreAccessibilityService.instance ?: return null
        val rootNode = service.rootInActiveWindow ?: return null
        
        val foundNodes = rootNode.findAccessibilityNodeInfosByText(text)
        
        return if (foundNodes.isNotEmpty()) {
            val firstNode = foundNodes.first()
            val rect = android.graphics.Rect()
            firstNode.getBoundsInScreen(rect)
            
            FindResult(
                found = true,
                count = foundNodes.size,
                x = rect.centerX().toFloat(),
                y = rect.centerY().toFloat(),
                bounds = rect
            )
        } else {
            FindResult(found = false, count = 0, x = 0f, y = 0f, bounds = null)
        }.also {
            rootNode.recycle()
        }
    }
    
    data class FindResult(
        val found: Boolean,
        val count: Int,
        val x: Float,
        val y: Float,
        val bounds: android.graphics.Rect?
    )
    
    // ==================== 智能执行 ====================
    
    /**
     * 智能执行操作（带重试和错误恢复）
     */
    suspend fun smartExecute(
        context: Context,
        action: String,
        params: Map<String, Any>,
        maxRetries: Int = 3,
        runtimeScope: String = "smart_automation"
    ): ExecutionResult {
        var lastResult: ExecutionResult = ExecutionResult.Failure("未执行")
        val reflectionEngine = AdaptiveExecutionEngine.getInstance(context)
        
        for (attempt in 1..maxRetries) {
            val runtimePlan = buildRuntimePlan(reflectionEngine, runtimeScope, action, params)
            val runtimeTarget = runtimePlan.reflectionTarget ?: extractRuntimeTarget(runtimePlan.action, runtimePlan.params)
            LogManager.d(TAG, "🔄 执行尝试 $attempt/$maxRetries: $action -> ${runtimePlan.action}")
            
            if (runtimePlan.shouldTerminate) return ExecutionResult.Success("运行时策略建议停止，已终止执行")
            val actionStartTime = System.currentTimeMillis()
            lastResult = actionMutex.withLock {
                executeAction(context, runtimePlan.action, runtimePlan.params)
            }
            val actionDurationMs = (System.currentTimeMillis() - actionStartTime).coerceAtLeast(1L)
            val success = lastResult is ExecutionResult.Success
            val reflectionUpdate = reflectionEngine.recordRuntimeReflection(
                scope = runtimeScope,
                action = runtimePlan.action,
                target = runtimeTarget,
                success = success,
                reason = if (success) null else resolveResultReason(lastResult),
                durationMs = actionDurationMs,
                parameters = buildRuntimeReflectionParameters(runtimePlan.action, runtimePlan.params)
            )
            if (!reflectionUpdate.isNullOrBlank()) {
                LogManager.d(TAG, "策略更新: $reflectionUpdate")
            }
            if (runtimePlan.waitAfterMs > 0L) {
                delay(runtimePlan.waitAfterMs)
            }
            
            when (lastResult) {
                is ExecutionResult.Success -> {
                    // 记录成功
                    FeedbackLearningSystem.recordSuccess(
                        context,
                        runtimeTarget ?: params["input"]?.toString() ?: action,
                        action,
                        runtimePlan.action,
                        0
                    )
                    return lastResult
                }
                is ExecutionResult.NeedPermission -> {
                    // 权限问题，不重试
                    return lastResult
                }
                is ExecutionResult.Failure -> {
                    if (!lastResult.canRetry || attempt >= maxRetries) {
                        // 记录失败
                        FeedbackLearningSystem.recordFailure(
                            context,
                            runtimeTarget ?: params["input"]?.toString() ?: action,
                            action,
                            runtimePlan.action,
                            lastResult.error
                        )
                        return lastResult
                    }
                    // 等待后重试
                    delay(500L * attempt)
                }
            }
        }
        
        return lastResult
    }
    
    /**
     * 执行具体操作
     */
    private suspend fun executeAction(
        context: Context,
        action: String,
        params: Map<String, Any>
    ): ExecutionResult {
        return when (action.lowercase()) {
            "swipe", "gesture_swipe" -> {
                val direction = params["direction"]?.toString() ?: "UP"
                val distance = (params["distance"] as? Number)?.toFloat()
                    ?: params["distance"]?.toString()?.toFloatOrNull()
                    ?: 400f
                swipe(direction, distance)
            }
            "click", "gesture_click" -> {
                val text = params["text"]?.toString() ?: params["label"]?.toString()
                var clickX = (params["x"] as? Number)?.toFloat() ?: params["x"]?.toString()?.toFloatOrNull()
                var clickY = (params["y"] as? Number)?.toFloat() ?: params["y"]?.toString()?.toFloatOrNull()
                
                // 智能文本定位
                if (!text.isNullOrBlank()) {
                    val findResult = findElement(text)
                    if (findResult != null && findResult.found) {
                        clickX = findResult.x
                        clickY = findResult.y
                        LogManager.d(TAG, "已找到文本 '$text' 位于 ($clickX, $clickY)")
                    } else {
                        LogManager.w(TAG, "未找到文本 '$text'，尝试使用默认坐标")
                    }
                }

                val position = params["position"]?.toString() ?: "center"
                click(clickX, clickY, position)
            }
            "long_press", "gesture_long_press" -> {
                val x = (params["x"] as? Number)?.toFloat() ?: params["x"]?.toString()?.toFloatOrNull()
                val y = (params["y"] as? Number)?.toFloat() ?: params["y"]?.toString()?.toFloatOrNull()
                val duration = (params["duration"] as? Number)?.toLong()
                    ?: params["duration"]?.toString()?.toLongOrNull()
                    ?: 800L
                longPress(x, y, duration)
            }
            "input", "input_text", "type" -> {
                val text = params["text"]?.toString()
                    ?: params["input"]?.toString()
                    ?: params["value"]?.toString()
                    ?: ""
                inputText(text)
            }
            "wait", "delay" -> {
                val timeMs = (params["time"] as? Number)?.toLong()
                    ?: (params["duration"] as? Number)?.toLong()
                    ?: (params["wait_ms"] as? Number)?.toLong()
                    ?: params["time"]?.toString()?.toLongOrNull()
                    ?: params["duration"]?.toString()?.toLongOrNull()
                    ?: params["wait_ms"]?.toString()?.toLongOrNull()
                    ?: 800L
                delay(timeMs.coerceAtLeast(0L))
                ExecutionResult.Success("等待 ${timeMs}ms")
            }
            "back", "go_back", "gesture_back" -> goBack()
            "home", "go_home", "gesture_home" -> goHome()
            "recent", "recent_apps" -> openRecentApps()
            "screenshot", "take_screenshot" -> takeScreenshot()
            "lock_screen", "lock" -> lockScreen()
            "open_app" -> {
                val appName = params["app"]?.toString() ?: params["app_name"]?.toString() ?: ""
                openApp(context, appName)
            }
            "volume_up" -> adjustVolume(context, true)
            "volume_down" -> adjustVolume(context, false)
            "settings" -> {
                val type = params["type"]?.toString() ?: "main"
                openSettings(context, type)
            }
            "stop" -> ExecutionResult.Success("已停止执行")
            else -> ExecutionResult.Failure("未知操作: $action", canRetry = false)
        }
    }
}
