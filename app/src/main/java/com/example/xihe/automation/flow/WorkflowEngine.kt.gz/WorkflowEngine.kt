package com.example.xihe.automation.flow

import android.content.Context
import com.example.xihe.automation.AdaptiveExecutionEngine
import com.example.xihe.automation.SmartAutomationManager
import com.example.xihe.training.LocalModelTrainer
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull

/**
 * 🎬 工作流引擎
 * 负责解析和执行自动化流程
 */
object WorkflowEngine {
    private const val TAG = "WorkflowEngine"

    private data class ActionExecutionOutcome(
        val success: Boolean,
        val shouldTerminate: Boolean = false
    )

    /**
     * 执行完整工作流
     */
    suspend fun executeFlow(context: Context, flow: AutomationFlow) {
        LogManager.i(TAG, "🎬 开始执行流程: ${flow.name}")
        
        // 构建Action查找表
        val actionMap = flow.actions.associateBy { it.id }
        
        // 找到起始节点（假设第一个就是，或者可以定义startActionId）
        var currentAction = flow.actions.firstOrNull()
        
        val startTime = System.currentTimeMillis()
        
        try {
            val completed = withTimeoutOrNull(flow.timeoutSeconds * 1000) {
                while (currentAction != null) {
                    val action = currentAction ?: break
                    val outcome = executeSingleAction(context, flow.id, action)

                    if (outcome.shouldTerminate) {
                        LogManager.i(TAG, "🛑 流程收到停止信号")
                        break
                    }

                    if (outcome.success) {
                        val nextId = action.nextActionId
                        currentAction = if (nextId != null) actionMap[nextId] else null
                    } else {
                        val errorId = action.onError
                        if (errorId != null) {
                            LogManager.w(TAG, "⚠️ 发生错误，跳转到错误处理: $errorId")
                            currentAction = actionMap[errorId]
                        } else {
                            LogManager.e(TAG, "❌ 流程意外终止")
                            break
                        }
                    }
                    
                    delay(500)
                }
            }

            if (completed == null) {
                LogManager.e(TAG, "⏰ 流程执行超时: ${flow.name}")
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "流程执行异常", e)
        }
        
        val duration = System.currentTimeMillis() - startTime
        LogManager.i(TAG, "🏁 流程结束: ${flow.name}, 耗时: ${duration}ms")
    }

    /**
     * 执行单个动作
     */
    private suspend fun executeSingleAction(
        context: Context,
        flowId: String,
        action: FlowAction
    ): ActionExecutionOutcome {
        if (action.condition != null) {
            if (!checkCondition(context, action.condition)) {
                AuditManager.logAction(context, flowId, action, "SKIPPED", "条件不满足")
                return ActionExecutionOutcome(success = true)
            }
        }

        val reflectionEngine = AdaptiveExecutionEngine.getInstance(context)
        val runtimeScope = "workflow_engine_${flowId}"
        val runtimeOperationScope = "${runtimeScope}_ops"
        val actionTarget = extractActionTarget(action)
        val runtimeAdvice = reflectionEngine.getRuntimeOptimizationAdvice(
            scope = runtimeScope,
            action = action.type.name,
            target = actionTarget
        )
        val effectiveType = normalizeWorkflowActionType(action, runtimeAdvice.suggestedAction)

        val actionStartTime = System.currentTimeMillis()
        if (effectiveType == ActionType.STOP) {
            val message = if (action.type == ActionType.STOP) "流程停止" else "运行时策略建议停止"
            val actionDurationMs = (System.currentTimeMillis() - actionStartTime).coerceAtLeast(1L)
            val reflectionUpdate = reflectionEngine.recordRuntimeReflection(
                scope = runtimeScope,
                action = effectiveType.name,
                target = actionTarget,
                success = true,
                reason = null,
                durationMs = actionDurationMs
            )
            if (!reflectionUpdate.isNullOrBlank()) {
                LogManager.d(TAG, "策略更新: $reflectionUpdate")
            }
            AuditManager.logAction(context, flowId, action, "SUCCESS", message)
            return ActionExecutionOutcome(success = true, shouldTerminate = true)
        }

        var success = false
        var shouldTerminate = false
        var message = "执行成功"
        var reflectionTarget = actionTarget
        var reflectionParams = emptyMap<String, String>()

        try {
            when (effectiveType) {
                ActionType.CLICK -> {
                    val x = action.params["x"]?.toFloatOrNull()
                    val y = action.params["y"]?.toFloatOrNull()
                    val text = action.params["text"] ?: action.params["target"]
                    val result = if (!text.isNullOrBlank()) {
                        SmartAutomationManager.smartExecute(
                            context,
                            action = "click",
                            params = mapOf("text" to text),
                            runtimeScope = runtimeOperationScope
                        )
                    } else {
                        val clickParams = mutableMapOf<String, Any>()
                        x?.let { clickParams["x"] = it }
                        y?.let { clickParams["y"] = it }
                        action.params["position"]?.takeIf { it.isNotBlank() }?.let { clickParams["position"] = it }
                        SmartAutomationManager.smartExecute(
                            context,
                            action = "click",
                            params = clickParams,
                            runtimeScope = runtimeOperationScope
                        )
                    }
                    success = result is SmartAutomationManager.ExecutionResult.Success
                    message = resolveSmartResultMessage(result)
                    if (message == "运行时策略建议停止，已终止执行") {
                        shouldTerminate = true
                    }
                }

                ActionType.SWIPE -> {
                    val suggested = runtimeAdvice.suggestedAction.trim().uppercase()
                    val hintedDirection = runtimeAdvice.paramAdjustments["direction"]
                        ?.trim()
                        ?.uppercase()
                        ?.takeIf { it in setOf("UP", "DOWN", "LEFT", "RIGHT") }
                    val direction = hintedDirection ?: when (suggested) {
                        "SWIPE_UP", "SCROLL_UP" -> "UP"
                        "SWIPE_DOWN", "SCROLL_DOWN" -> "DOWN"
                        else -> action.params["direction"] ?: "UP"
                    }
                    val baseDistance = action.params["distance"]?.toFloatOrNull() ?: 400f
                    val hintedDistance = runtimeAdvice.paramAdjustments["distance"]?.toFloatOrNull()
                    val distance = (hintedDistance ?: baseDistance).coerceIn(120f, 1200f)
                    reflectionTarget = "direction=$direction|distance=${distance.toInt()}"
                    reflectionParams = mapOf(
                        "direction" to direction,
                        "distance" to distance.toInt().toString()
                    )
                    val result = SmartAutomationManager.smartExecute(
                        context,
                        action = "swipe",
                        params = mapOf("direction" to direction, "distance" to distance),
                        runtimeScope = runtimeOperationScope
                    )
                    success = result is SmartAutomationManager.ExecutionResult.Success
                    message = resolveSmartResultMessage(result)
                    if (message == "运行时策略建议停止，已终止执行") {
                        shouldTerminate = true
                    }
                }

                ActionType.INPUT_TEXT -> {
                    val text = action.params["text"] ?: action.params["input"] ?: action.params["value"] ?: ""
                    val inputParams = mutableMapOf<String, Any>("text" to text)
                    action.params["field"]?.takeIf { it.isNotBlank() }?.let { inputParams["field"] = it }
                    action.params["hint"]?.takeIf { it.isNotBlank() }?.let { inputParams["hint"] = it }
                    val result = SmartAutomationManager.smartExecute(
                        context,
                        action = "input_text",
                        params = inputParams,
                        runtimeScope = runtimeOperationScope
                    )
                    success = result is SmartAutomationManager.ExecutionResult.Success
                    message = resolveSmartResultMessage(result)
                    if (message == "运行时策略建议停止，已终止执行") {
                        shouldTerminate = true
                    }
                }

                ActionType.WAIT_FOR_TEXT -> {
                    val target = action.params["target"] ?: action.params["text"] ?: ""
                    val timeoutMs = (
                        runtimeAdvice.paramAdjustments["timeout_ms"]?.toLongOrNull()
                            ?: runtimeAdvice.paramAdjustments["time"]?.toLongOrNull()
                            ?: action.params["timeout_ms"]?.toLongOrNull()
                            ?: 5000L
                        ).coerceIn(500L, 30000L)
                    val intervalMs = (
                        runtimeAdvice.paramAdjustments["poll_interval_ms"]?.toLongOrNull()
                            ?: action.params["poll_interval_ms"]?.toLongOrNull()
                            ?: 300L
                        ).coerceIn(100L, 2000L)
                    reflectionTarget = if (target.isBlank()) {
                        "timeout_ms=$timeoutMs"
                    } else {
                        "target=$target|timeout_ms=$timeoutMs"
                    }
                    reflectionParams = mapOf(
                        "timeout_ms" to timeoutMs.toString(),
                        "poll_interval_ms" to intervalMs.toString()
                    )
                    success = waitForText(target, timeoutMs, intervalMs)
                    message = if (success) "检测到文本 '$target'" else "等待文本超时: '$target'"
                }

                ActionType.BACK -> {
                    val result = SmartAutomationManager.smartExecute(
                        context,
                        action = "back",
                        params = emptyMap(),
                        runtimeScope = runtimeOperationScope
                    )
                    success = result is SmartAutomationManager.ExecutionResult.Success
                    message = resolveSmartResultMessage(result)
                    if (message == "运行时策略建议停止，已终止执行") {
                        shouldTerminate = true
                    }
                }

                ActionType.HOME -> {
                    val result = SmartAutomationManager.smartExecute(
                        context,
                        action = "home",
                        params = emptyMap(),
                        runtimeScope = runtimeOperationScope
                    )
                    success = result is SmartAutomationManager.ExecutionResult.Success
                    message = resolveSmartResultMessage(result)
                    if (message == "运行时策略建议停止，已终止执行") {
                        shouldTerminate = true
                    }
                }

                ActionType.SCREENSHOT -> {
                    val result = SmartAutomationManager.smartExecute(
                        context,
                        action = "screenshot",
                        params = emptyMap(),
                        runtimeScope = runtimeOperationScope
                    )
                    success = result is SmartAutomationManager.ExecutionResult.Success
                    message = resolveSmartResultMessage(result)
                    if (message == "运行时策略建议停止，已终止执行") {
                        shouldTerminate = true
                    }
                }

                ActionType.LOCK_SCREEN -> {
                    val result = SmartAutomationManager.smartExecute(
                        context,
                        action = "lock_screen",
                        params = emptyMap(),
                        runtimeScope = runtimeOperationScope
                    )
                    success = result is SmartAutomationManager.ExecutionResult.Success
                    message = resolveSmartResultMessage(result)
                    if (message == "运行时策略建议停止，已终止执行") {
                        shouldTerminate = true
                    }
                }

                ActionType.DELAY -> {
                    val baseTime = action.params["time"]?.toLongOrNull() ?: 1000L
                    val hintedTime = runtimeAdvice.paramAdjustments["time"]?.toLongOrNull()
                        ?: runtimeAdvice.paramAdjustments["wait_ms"]?.toLongOrNull()
                        ?: runtimeAdvice.paramAdjustments["duration"]?.toLongOrNull()
                    val time = (hintedTime ?: baseTime).coerceIn(100L, 30000L)
                    reflectionTarget = "wait_ms=$time"
                    reflectionParams = mapOf("time" to time.toString())
                    delay(time)
                    success = true
                    message = "等待 ${time}ms"
                }

                ActionType.OPEN_APP -> {
                    val appName = action.params["app_name"] ?: action.params["app"] ?: ""
                    val result = SmartAutomationManager.smartExecute(
                        context,
                        action = "open_app",
                        params = mapOf("app_name" to appName),
                        runtimeScope = runtimeOperationScope
                    )
                    success = result is SmartAutomationManager.ExecutionResult.Success
                    message = resolveSmartResultMessage(result)
                    if (message == "运行时策略建议停止，已终止执行") {
                        shouldTerminate = true
                    }
                }

                ActionType.SMART_FIND_AND_CLICK -> {
                    val target = action.params["target"] ?: action.params["text"] ?: ""
                    val result = SmartAutomationManager.smartExecute(
                        context,
                        action = "click",
                        params = mapOf("text" to target),
                        runtimeScope = runtimeOperationScope
                    )
                    success = result is SmartAutomationManager.ExecutionResult.Success
                    val detail = resolveSmartResultMessage(result)
                    if (detail == "运行时策略建议停止，已终止执行") {
                        shouldTerminate = true
                        success = true
                        message = detail
                    } else {
                        message = if (success) {
                            "智能查找 '$target': 找到"
                        } else {
                            "智能查找 '$target': 未找到 ($detail)"
                        }
                    }
                }

                ActionType.AI_DECISION -> {
                    val prompt = action.params["prompt"] ?: "下一步做什么？"
                    val trainer = LocalModelTrainer.getInstance(context)
                    val screenContext = "当前屏幕显示..."
                    val reflectionSummary = reflectionEngine.getRuntimeReflectionSummary("${runtimeScope}_ai_decision")
                    val prediction = trainer.predict("用户想: $prompt, 屏幕: $screenContext, 历史反思: $reflectionSummary")
                    message = "AI决定: ${prediction.intent}"
                    success = true
                }

                else -> {
                    message = "未实现的动作: $effectiveType"
                    success = false
                }
            }
        } catch (e: Exception) {
            success = false
            message = e.message ?: "未知异常"
        }

        val actionDurationMs = (System.currentTimeMillis() - actionStartTime).coerceAtLeast(1L)
        val reflectionUpdate = reflectionEngine.recordRuntimeReflection(
            scope = runtimeScope,
            action = effectiveType.name,
            target = reflectionTarget,
            success = success,
            reason = if (success) null else message,
            durationMs = actionDurationMs,
            parameters = reflectionParams
        )
        if (!reflectionUpdate.isNullOrBlank()) {
            LogManager.d(TAG, "策略更新: $reflectionUpdate")
        }
        if (shouldTerminate) {
            AuditManager.logAction(context, flowId, action, "SUCCESS", message)
            return ActionExecutionOutcome(success = true, shouldTerminate = true)
        }
        if (runtimeAdvice.waitAfterMs > 0L) {
            delay(runtimeAdvice.waitAfterMs)
        }

        AuditManager.logAction(context, flowId, action, if (success) "SUCCESS" else "FAILED", message)

        return ActionExecutionOutcome(success = success, shouldTerminate = shouldTerminate)
    }

    private fun extractActionTarget(action: FlowAction): String? {
        if (action.type == ActionType.INPUT_TEXT) {
            return action.params["field"] ?: action.params["hint"] ?: "text_input"
        }
        return action.params["target"]
            ?: action.params["text"]
            ?: action.params["app_name"]
            ?: action.params["app"]
            ?: action.params["prompt"]
    }

    private fun normalizeWorkflowActionType(action: FlowAction, suggestedAction: String): ActionType {
        if (action.type == ActionType.STOP) {
            return ActionType.STOP
        }
        val candidate = suggestedAction.trim().uppercase().ifBlank { action.type.name }
        return when (candidate) {
            "CLICK", "CLICK_FUZZY", "CLICK_TEXT" -> {
                if (!action.params["target"].isNullOrBlank()) ActionType.SMART_FIND_AND_CLICK else ActionType.CLICK
            }
            "SMART_FIND_AND_CLICK" -> ActionType.SMART_FIND_AND_CLICK
            "OPEN_APP", "LAUNCH", "LAUNCH_APP", "OPEN APP" -> ActionType.OPEN_APP
            "SWIPE", "SWIPE_UP", "SWIPE_DOWN", "SCROLL", "SCROLL_UP", "SCROLL_DOWN" -> ActionType.SWIPE
            "INPUT", "INPUT_TEXT", "TYPE" -> ActionType.INPUT_TEXT
            "WAIT_FOR_TEXT", "WAIT_TEXT", "WAIT_TEXT_APPEAR" -> ActionType.WAIT_FOR_TEXT
            "BACK", "PRESS_BACK" -> ActionType.BACK
            "HOME" -> ActionType.HOME
            "DELAY", "WAIT" -> ActionType.DELAY
            "AI_DECISION" -> ActionType.AI_DECISION
            "SCREENSHOT", "TAKE_SCREENSHOT" -> ActionType.SCREENSHOT
            "LOCK_SCREEN", "LOCK" -> ActionType.LOCK_SCREEN
            "STOP" -> ActionType.STOP
            else -> action.type
        }
    }

    private fun resolveSmartResultMessage(result: SmartAutomationManager.ExecutionResult): String {
        return when (result) {
            is SmartAutomationManager.ExecutionResult.Success -> result.message
            is SmartAutomationManager.ExecutionResult.Failure -> result.error
            is SmartAutomationManager.ExecutionResult.NeedPermission -> result.description
        }
    }

    private suspend fun waitForText(target: String, timeoutMs: Long, intervalMs: Long): Boolean {
        if (target.isBlank()) {
            return false
        }
        val deadline = System.currentTimeMillis() + timeoutMs.coerceAtLeast(200L)
        val interval = intervalMs.coerceIn(100L, 2000L)
        while (System.currentTimeMillis() <= deadline) {
            val found = SmartAutomationManager.findElement(target)?.found == true
            if (found) {
                return true
            }
            delay(interval)
        }
        return false
    }

    private fun checkCondition(context: Context, condition: FlowCondition): Boolean {
        return when (condition.type) {
            ConditionType.SCREEN_HAS_TEXT -> {
                val result = SmartAutomationManager.findElement(condition.value)
                val found = result?.found == true
                if (condition.operator == "not_contains") !found else found
            }
            else -> true
        }
    }
}
