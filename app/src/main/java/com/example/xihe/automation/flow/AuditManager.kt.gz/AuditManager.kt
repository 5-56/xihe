package com.example.xihe.automation.flow

import android.content.Context
import com.example.xihe.utils.LogManager
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 🕵️‍♂️ 审计管理器
 * 负责记录自动化执行的每一步，支持截图回溯
 */
object AuditManager {
    private const val TAG = "AuditManager"
    private const val LOG_DIR = "automation_logs"
    private const val LOG_RETENTION_DAYS = 30L
    
    private val json = Json { prettyPrint = true }

    /**
     * 记录执行日志
     */
    fun logAction(
        context: Context, 
        flowId: String, 
        action: FlowAction, 
        status: String, 
        message: String,
        screenshotFile: File? = null
    ) {
        try {
            val logEntry = ExecutionLog(
                flowId = flowId,
                timestamp = System.currentTimeMillis(),
                actionId = action.id,
                status = status,
                message = message,
                screenshotPath = screenshotFile?.absolutePath
            )
            
            // 1. 打印到控制台
            if (status == "FAILED") {
                LogManager.e(TAG, "[$flowId] 执行失败: ${action.type} - $message")
            } else {
                LogManager.i(TAG, "[$flowId] 执行: ${action.type} - $status")
            }
            
            // 2. 写入文件 (每天一个日志文件)
            val date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val logDir = File(context.filesDir, LOG_DIR)
            if (!logDir.exists()) logDir.mkdirs()
            cleanupExpiredLogs(logDir)
            
            val logFile = File(logDir, "audit_$date.jsonl")
            logFile.appendText(json.encodeToString(logEntry) + "\n")
            
        } catch (e: Exception) {
            LogManager.e(TAG, "写入审计日志失败", e)
        }
    }

    private fun cleanupExpiredLogs(logDir: File) {
        val expireBefore = System.currentTimeMillis() - LOG_RETENTION_DAYS * 24 * 60 * 60 * 1000
        logDir.listFiles()?.forEach { file ->
            if (file.lastModified() < expireBefore) {
                file.delete()
            }
        }
    }

    /**
     * 获取最近的执行日志
     */
    fun getRecentLogs(context: Context, limit: Int = 50): List<ExecutionLog> {
        val logs = mutableListOf<ExecutionLog>()
        try {
            val logDir = File(context.filesDir, LOG_DIR)
            val files = logDir.listFiles()?.sortedByDescending { it.lastModified() } ?: return emptyList()
            
            for (file in files) {
                file.readLines().reversed().forEach { line ->
                    if (logs.size >= limit) return logs
                    try {
                        logs.add(json.decodeFromString(line))
                    } catch (e: Exception) { }
                }
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "读取日志失败", e)
        }
        return logs
    }
}
