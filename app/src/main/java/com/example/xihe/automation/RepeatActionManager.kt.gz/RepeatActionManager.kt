package com.example.xihe.automation

import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.CoreAccessibilityService
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * 🔄 重复动作管理器
 * 支持录制和重复执行一系列操作
 */
class RepeatActionManager private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "RepeatActionManager"
        
        @Volatile
        private var instance: RepeatActionManager? = null
        
        fun getInstance(context: Context): RepeatActionManager {
            return instance ?: synchronized(this) {
                instance ?: RepeatActionManager(context.applicationContext).also { instance = it }
            }
        }
    }
    
    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()
    
    private val _isExecuting = MutableStateFlow(false)
    val isExecuting: StateFlow<Boolean> = _isExecuting.asStateFlow()
    
    private val recordedActions = mutableListOf<RecordedAction>()
    
    /**
     * 录制的动作
     */
    data class RecordedAction(
        val type: ActionType,
        val timestamp: Long,
        val x: Float? = null,
        val y: Float? = null,
        val text: String? = null,
        val targetId: String? = null,
        val targetText: String? = null
    )
    
    enum class ActionType {
        CLICK,
        LONG_CLICK,
        SWIPE,
        INPUT,
        SCROLL,
        BACK,
        HOME,
        WAIT
    }
    
    /**
     * 执行结果
     */
    data class ExecutionResult(
        val success: Boolean,
        val completedCycles: Int = 0,
        val totalCycles: Int = 0,
        val executedActions: Int = 0,
        val errorMessage: String? = null
    )
    
    /**
     * 🎬 开始录制
     */
    fun startRecording() {
        recordedActions.clear()
        _isRecording.value = true
        LogManager.i(TAG, "🎬 开始录制动作")
    }
    
    /**
     * ⏹️ 停止录制
     */
    fun stopRecording(): List<RecordedAction> {
        _isRecording.value = false
        LogManager.i(TAG, "⏹️ 停止录制，共录制 ${recordedActions.size} 个动作")
        return recordedActions.toList()
    }
    
    /**
     * 📝 记录点击动作
     */
    fun recordClick(x: Float, y: Float, targetText: String? = null) {
        if (!_isRecording.value) return
        
        recordedActions.add(
            RecordedAction(
                type = ActionType.CLICK,
                timestamp = System.currentTimeMillis(),
                x = x,
                y = y,
                targetText = targetText
            )
        )
        LogManager.d(TAG, "📝 记录点击: ($x, $y) $targetText")
    }
    
    /**
     * 📝 记录滑动动作
     */
    fun recordSwipe(startX: Float, startY: Float, endX: Float, endY: Float) {
        if (!_isRecording.value) return
        
        recordedActions.add(
            RecordedAction(
                type = ActionType.SWIPE,
                timestamp = System.currentTimeMillis(),
                x = startX,
                y = startY,
                text = "$endX,$endY"  // 使用text字段存储终点
            )
        )
        LogManager.d(TAG, "📝 记录滑动: ($startX, $startY) -> ($endX, $endY)")
    }
    
    /**
     * 📝 记录输入动作
     */
    fun recordInput(text: String) {
        if (!_isRecording.value) return
        
        recordedActions.add(
            RecordedAction(
                type = ActionType.INPUT,
                timestamp = System.currentTimeMillis(),
                text = text
            )
        )
        LogManager.d(TAG, "📝 记录输入: $text")
    }
    
    /**
     * 🔄 重复执行动作
     */
    suspend fun repeatActions(
        actions: List<RecordedAction>,
        repeatCount: Int,
        delayBetweenCycles: Long = 1000,
        onProgress: ((Int, Int) -> Unit)? = null
    ): ExecutionResult {
        if (_isExecuting.value) {
            return ExecutionResult(false, 0, repeatCount, 0, "已有任务在执行中")
        }
        
        return try {
            _isExecuting.value = true
            val service = CoreAccessibilityService.instance
                ?: return ExecutionResult(false, 0, repeatCount, 0, "无障碍服务未启动")
            
            var completedCycles = 0
            var totalExecutedActions = 0
            
            LogManager.i(TAG, "🔄 开始重复执行 ${actions.size} 个动作，共 $repeatCount 次")
            
            repeat(repeatCount) { cycle ->
                onProgress?.invoke(cycle + 1, repeatCount)
                
                for (action in actions) {
                    if (!_isExecuting.value) {
                        LogManager.i(TAG, "⏹️ 用户中断执行")
                        return ExecutionResult(
                            true,
                            completedCycles,
                            repeatCount,
                            totalExecutedActions,
                            "用户中断"
                        )
                    }
                    
                    executeAction(service, action)
                    totalExecutedActions++
                    
                    // 动作间隔
                    delay(500)
                }
                
                completedCycles++
                
                // 循环间隔
                if (cycle < repeatCount - 1) {
                    delay(delayBetweenCycles)
                }
            }
            
            LogManager.i(TAG, "✅ 重复执行完成：$completedCycles 个循环，$totalExecutedActions 个动作")
            ExecutionResult(true, completedCycles, repeatCount, totalExecutedActions)
        } catch (e: Exception) {
            LogManager.e(TAG, "重复执行失败", e)
            ExecutionResult(false, 0, repeatCount, 0, e.message)
        } finally {
            _isExecuting.value = false
        }
    }
    
    /**
     * 🎯 执行单个动作
     */
    private suspend fun executeAction(service: CoreAccessibilityService, action: RecordedAction) {
        try {
            when (action.type) {
                ActionType.CLICK -> {
                    if (action.x != null && action.y != null) {
                        service.performClick(action.x, action.y)
                    } else if (action.targetText != null) {
                        service.findAndClick(action.targetText)
                    }
                }
                
                ActionType.LONG_CLICK -> {
                    if (action.targetText != null) {
                        service.findAndClick(action.targetText)
                    }
                }
                
                ActionType.SWIPE -> {
                    if (action.x != null && action.y != null && action.text != null) {
                        val endCoords = action.text.split(",")
                        if (endCoords.size == 2) {
                            val endX = endCoords[0].toFloatOrNull()
                            val endY = endCoords[1].toFloatOrNull()
                            if (endX != null && endY != null) {
                                service.swipeAsync(action.x, action.y, endX, endY, 300)
                            }
                        }
                    }
                }
                
                ActionType.INPUT -> {
                    if (action.text != null) {
                        service.inputText(action.text)
                    }
                }
                
                ActionType.SCROLL -> {
                    val (width, height) = service.getScreenSize()
                    service.performScroll(width / 2f, height * 0.7f, width / 2f, height * 0.3f)
                }
                
                ActionType.BACK -> {
                    service.performGlobalBack()
                }
                
                ActionType.HOME -> {
                    service.performGlobalHome()
                }
                
                ActionType.WAIT -> {
                    delay(1000)
                }
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "执行动作失败: ${action.type}", e)
        }
    }
    
    /**
     * ⏹️ 停止执行
     */
    fun stopExecution() {
        _isExecuting.value = false
        LogManager.i(TAG, "⏹️ 停止执行")
    }
    
    /**
     * 🔄 快速重复点击
     */
    suspend fun repeatClick(
        x: Float,
        y: Float,
        count: Int,
        intervalMs: Long = 500
    ): ExecutionResult {
        return try {
            val service = CoreAccessibilityService.instance
                ?: return ExecutionResult(false, 0, count, 0, "无障碍服务未启动")
            
            _isExecuting.value = true
            var successCount = 0
            
            repeat(count) { i ->
                if (!_isExecuting.value) {
                    return ExecutionResult(true, i, count, i, "用户中断")
                }
                
                service.performClick(x, y)
                successCount++
                
                if (i < count - 1) {
                    delay(intervalMs)
                }
            }
            
            ExecutionResult(true, count, count, successCount)
        } catch (e: Exception) {
            ExecutionResult(false, 0, count, 0, e.message)
        } finally {
            _isExecuting.value = false
        }
    }
    
    /**
     * 🔄 快速重复滑动
     */
    suspend fun repeatSwipe(
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        count: Int,
        intervalMs: Long = 1000
    ): ExecutionResult {
        return try {
            val service = CoreAccessibilityService.instance
                ?: return ExecutionResult(false, 0, count, 0, "无障碍服务未启动")
            
            _isExecuting.value = true
            var successCount = 0
            
            repeat(count) { i ->
                if (!_isExecuting.value) {
                    return ExecutionResult(true, i, count, i, "用户中断")
                }
                
                service.swipeAsync(startX, startY, endX, endY, 300)
                successCount++
                
                if (i < count - 1) {
                    delay(intervalMs)
                }
            }
            
            ExecutionResult(true, count, count, successCount)
        } catch (e: Exception) {
            ExecutionResult(false, 0, count, 0, e.message)
        } finally {
            _isExecuting.value = false
        }
    }
    
    /**
     * 📋 获取已录制的动作
     */
    fun getRecordedActions(): List<RecordedAction> {
        return recordedActions.toList()
    }
    
    /**
     * 🗑️ 清空录制的动作
     */
    fun clearRecordedActions() {
        recordedActions.clear()
        LogManager.d(TAG, "🗑️ 清空录制的动作")
    }
    
    /**
     * 📊 获取统计信息
     */
    fun getStats(): Stats {
        return Stats(
            totalRecordedActions = recordedActions.size,
            isRecording = _isRecording.value,
            isExecuting = _isExecuting.value
        )
    }
    
    data class Stats(
        val totalRecordedActions: Int,
        val isRecording: Boolean,
        val isExecuting: Boolean
    )
}
