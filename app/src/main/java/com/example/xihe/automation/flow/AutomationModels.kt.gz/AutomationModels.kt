package com.example.xihe.automation.flow

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject

/**
 * 📜 自动化工作流模型
 * 定义了“在什么情况下(Trigger)，做什么事情(Action)，怎么做(Flow)”
 */

@Serializable
data class AutomationFlow(
    val id: String,
    val name: String,
    val description: String = "",
    val triggers: List<FlowTrigger>,
    val actions: List<FlowAction>,
    val enabled: Boolean = true,
    val timeoutSeconds: Long = 300
)

@Serializable
data class FlowTrigger(
    val type: TriggerType,
    val config: Map<String, String> // 例如: {"time": "08:00", "app": "com.tencent.mm"}
)

enum class TriggerType {
    TIME,           // 定时触发
    NOTIFICATION,   // 通知栏触发
    APP_OPENED,     // 应用打开触发
    SCREEN_TEXT,    // 屏幕出现特定文字
    BATTERY_EVENT,  // 电量/充电事件
    VOICE_COMMAND,  // 语音指令
    MANUAL          // 手动触发
}

@Serializable
data class FlowAction(
    val id: String,
    val type: ActionType,
    val params: Map<String, String> = emptyMap(),
    val nextActionId: String? = null, // 链式调用
    val condition: FlowCondition? = null, // 执行条件
    val onError: String? = null // 错误处理跳转
)

@Serializable
data class FlowCondition(
    val type: ConditionType,
    val key: String,
    val operator: String, // equals, contains, greater, less
    val value: String
)

enum class ConditionType {
    SCREEN_HAS_TEXT,    // 屏幕包含文字
    APP_IS_FOREGROUND,  // 特定应用在前台
    VARIABLE_CHECK      // 变量检查
}

enum class ActionType {
    // 基础操作
    CLICK, SWIPE, INPUT_TEXT, BACK, HOME,
    
    // 智能操作
    SMART_FIND_AND_CLICK, // 找到文字并点击
    AI_DECISION,          // 询问AI下一步做什么
    
    // 流程控制
    DELAY,                // 延时
    WAIT_FOR_TEXT,        // 等待文字出现
    STOP,                 // 停止
    
    // 系统操作
    OPEN_APP,
    SCREENSHOT,
    LOCK_SCREEN
}

@Serializable
data class ExecutionLog(
    val flowId: String,
    val timestamp: Long,
    val actionId: String,
    val status: String, // SUCCESS, FAILED, SKIPPED
    val message: String,
    val screenshotPath: String? = null
)
