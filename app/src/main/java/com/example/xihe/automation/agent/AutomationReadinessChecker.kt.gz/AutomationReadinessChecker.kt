package com.example.xihe.automation.agent

import android.content.Context
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.core.PreferencesManager
import com.example.xihe.ocr.ScreenOCRService
import com.example.xihe.utils.AppPackageMapper
import com.example.xihe.vision.ScreenCaptureService

object AutomationReadinessChecker {
    data class ReadinessReport(
        val canRun: Boolean,
        val summary: String,
        val accessibilityReady: Boolean,
        val llmReady: Boolean,
        val activeWindowReady: Boolean,
        val ocrReady: Boolean,
        val currentPackage: String?,
        val targetAppName: String?,
        val targetPackage: String?,
        val targetAppReady: Boolean,
        val screenWidth: Int?,
        val screenHeight: Int?,
        val issues: List<String>,
        val suggestions: List<String>
    ) {
        fun toPromptContext(): String {
            return buildString {
                appendLine("- canRun: $canRun")
                appendLine("- accessibilityReady: $accessibilityReady")
                appendLine("- llmReady: $llmReady")
                appendLine("- activeWindowReady: $activeWindowReady")
                appendLine("- ocrReady: $ocrReady")
                appendLine("- currentPackage: ${currentPackage ?: "unknown"}")
                appendLine("- targetAppName: ${targetAppName ?: "unknown"}")
                appendLine("- targetPackage: ${targetPackage ?: "unknown"}")
                appendLine("- targetAppReady: $targetAppReady")
                appendLine("- resolution: ${screenWidth ?: "unknown"}x${screenHeight ?: "unknown"}")
                appendLine("- issues: ${if (issues.isEmpty()) "none" else issues.joinToString("; ")}")
                appendLine("- suggestions: ${if (suggestions.isEmpty()) "none" else suggestions.joinToString("; ")}")
            }.trim()
        }
    }

    fun check(context: Context, userMessage: String? = null): ReadinessReport {
        val service = CoreAccessibilityService.getInstance()
        val accessibilityReady = service != null || CoreAccessibilityService.isConnected.value
        val root = service?.rootInActiveWindow
        val activeWindowReady = root != null
        val currentPackage = service?.getCurrentPackageName()
        val size = service?.getScreenSize()
        val apiConfig = PreferencesManager.getApiConfig(context)
        val llmReady = isLlmConfigReady(apiConfig)
        val ocrReady = ScreenOCRService.getInstance(context).hasActiveCaptureSession() ||
            ScreenCaptureService.isCapturing.value
        val targetMatch = findTargetApp(context, userMessage)
        val targetAppName = targetMatch?.first
        val targetPackage = targetMatch?.second
        val targetAppReady = targetPackage == null || targetPackage == currentPackage
        val issues = mutableListOf<String>()
        val suggestions = mutableListOf<String>()

        if (!accessibilityReady) {
            issues.add("无障碍服务未连接")
            suggestions.add("先开启羲和无障碍服务")
        }
        if (accessibilityReady && !activeWindowReady) {
            issues.add("当前没有可读取的活动窗口")
            suggestions.add("解锁屏幕并打开目标 App 页面后重试")
        }
        if (!llmReady) {
            issues.add("LLM 配置不可用")
            suggestions.add("在 API 设置中配置可用的 baseUrl、模型和 API Key，或使用本地接口")
        }
        if (!ocrReady) {
            suggestions.add("需要识别图片/游戏/复杂页面时，先授权屏幕截图以启用 OCR")
        }
        if (targetPackage != null && currentPackage != null && currentPackage != targetPackage) {
            suggestions.add("检测到目标 App：$targetAppName，执行前将尝试打开 $targetPackage")
        } else if (currentPackage == context.packageName) {
            suggestions.add("如果要操作第三方 App，请先说明目标 App，或让助手打开目标 App")
        }

        val canRun = accessibilityReady && activeWindowReady && llmReady
        val summary = if (canRun) {
            "复杂自动化就绪"
        } else {
            "复杂自动化暂不可执行：${issues.joinToString("；")}"
        }

        return ReadinessReport(
            canRun = canRun,
            summary = summary,
            accessibilityReady = accessibilityReady,
            llmReady = llmReady,
            activeWindowReady = activeWindowReady,
            ocrReady = ocrReady,
            currentPackage = currentPackage,
            targetAppName = targetAppName,
            targetPackage = targetPackage,
            targetAppReady = targetAppReady,
            screenWidth = size?.first,
            screenHeight = size?.second,
            issues = issues,
            suggestions = suggestions
        )
    }

    private fun isLlmConfigReady(apiConfig: PreferencesManager.ApiConfig): Boolean {
        val baseUrl = apiConfig.baseUrl.trim()
        val modelName = apiConfig.modelName.trim()
        val providerId = apiConfig.providerId.trim().lowercase()
        val apiKey = apiConfig.apiKey.trim()
        val isLocal = providerId == "local" ||
            baseUrl.contains("localhost", ignoreCase = true) ||
            baseUrl.contains("127.0.0.1")
        return baseUrl.isNotBlank() && modelName.isNotBlank() && (isLocal || apiKey.isNotBlank())
    }

    private fun findTargetApp(context: Context, userMessage: String?): Pair<String, String>? {
        val text = userMessage?.trim().orEmpty()
        if (text.isBlank()) return null
        return AppPackageMapper.fuzzyMatchInstalled(context, text).firstOrNull()
    }
}
