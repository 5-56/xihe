package com.example.xihe.automation.script

import com.example.xihe.utils.LogManager

/**
 * 📝 文字脚本解析器
 * 解析用户提供的自然语言格式脚本
 */
class TextScriptParser : ScriptParser {
    
    companion object {
        private const val TAG = "TextScriptParser"
        
        // 正则表达式模式
        private val TASK_NAME_PATTERN = Regex("【任务名称】(.+?)(?=【|$)", RegexOption.DOT_MATCHES_ALL)
        private val TASK_DESC_PATTERN = Regex("【任务描述】(.+?)(?=【|$)", RegexOption.DOT_MATCHES_ALL)
        private val PLATFORM_PATTERN = Regex("【目标平台】(.+?)(?=【|$)", RegexOption.DOT_MATCHES_ALL)
        private val TIME_PATTERN = Regex("【预计耗时】(.+?)(?=【|$)", RegexOption.DOT_MATCHES_ALL)
        private val DIFFICULTY_PATTERN = Regex("【难度等级】(.+?)(?=【|$)", RegexOption.DOT_MATCHES_ALL)
        
        private val STEP_PATTERN = Regex(
            "步骤\\s*(\\d+):\\s*(.+?)(?=步骤\\s*\\d+:|===|$)",
            setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.MULTILINE)
        )
        
        private val ISSUE_PATTERN = Regex(
            "问题\\s*(\\d+):\\s*(.+?)(?=问题\\s*\\d+:|===|$)",
            setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.MULTILINE)
        )
        
        private val NOTE_PATTERN = Regex(
            "\\d+\\.\\s*\\[(.+?)]\\s*(.+?)(?=\\d+\\.\\s*\\[|$)",
            RegexOption.DOT_MATCHES_ALL
        )
    }
    
    override fun canParse(input: String): Boolean {
        // 检查是否包含文字脚本的特征标记
        return input.contains("【任务名称】") || 
               input.contains("步骤 1:") || 
               input.contains("步骤1:")
    }
    
    override fun parse(input: String): ParseResult {
        if (input.isBlank()) {
            return ParseResult.Error(listOf(ParseError("input", "输入内容为空")))
        }
        
        try {
            // 1. 提取元数据
            val metadata = extractMetadata(input)
            
            // 2. 提取步骤
            val steps = extractSteps(input)
            if (steps.isEmpty()) {
                return ParseResult.Error(listOf(
                    ParseError("steps", "未找到有效的执行步骤")
                ))
            }
            
            // 3. 提取潜在问题
            val issues = extractPotentialIssues(input)
            
            // 4. 提取注意事项
            val notes = extractNotes(input)
            
            val script = ParsedScript(
                metadata = metadata,
                steps = steps,
                potentialIssues = issues,
                notes = notes
            )
            
            LogManager.i(TAG, "✅ 文字脚本解析成功: ${metadata.name}, ${steps.size} 个步骤")
            return ParseResult.Success(script)
            
        } catch (e: Exception) {
            LogManager.e(TAG, "文字脚本解析失败", e)
            return ParseResult.Error(listOf(
                ParseError("parse", "解析失败: ${e.message}")
            ))
        }
    }
    
    /**
     * 提取脚本元数据
     */
    private fun extractMetadata(input: String): ParsedScriptMetadata {
        val name = TASK_NAME_PATTERN.find(input)?.groupValues?.get(1)?.trim() ?: "未命名脚本"
        val description = TASK_DESC_PATTERN.find(input)?.groupValues?.get(1)?.trim() ?: ""
        val platform = PLATFORM_PATTERN.find(input)?.groupValues?.get(1)?.trim() ?: "Android"
        val time = TIME_PATTERN.find(input)?.groupValues?.get(1)?.trim() ?: ""
        val difficulty = DIFFICULTY_PATTERN.find(input)?.groupValues?.get(1)?.trim() ?: ""
        
        return ParsedScriptMetadata(
            name = name,
            description = description,
            targetPlatform = platform,
            estimatedTime = time,
            difficulty = difficulty
        )
    }
    
    /**
     * 提取执行步骤
     */
    private fun extractSteps(input: String): List<ParsedStep> {
        val steps = mutableListOf<ParsedStep>()
        
        STEP_PATTERN.findAll(input).forEach { match ->
            val stepNumber = match.groupValues[1].toIntOrNull() ?: (steps.size + 1)
            val stepContent = match.groupValues[2].trim()
            
            val step = parseStepContent(stepNumber, stepContent)
            steps.add(step)
        }
        
        return steps
    }
    
    /**
     * 解析单个步骤内容
     */
    private fun parseStepContent(id: Int, content: String): ParsedStep {
        // 提取步骤描述（第一行）
        val description = content.lines().firstOrNull()?.trim() ?: "步骤 $id"
        
        // 提取阶段
        val phase = extractField(content, "阶段") ?: ""
        
        // 提取操作类型
        val actionTypeStr = extractField(content, "操作类型") ?: ""
        val actionType = parseActionType(actionTypeStr)
        
        // 提取目标元素
        val targetDesc = extractField(content, "目标元素") ?: ""
        val position = extractField(content, "位置") ?: ""
        val targetElement = if (targetDesc.isNotBlank()) {
            TargetElement(
                description = targetDesc,
                position = position,
                text = extractTextFromDescription(targetDesc)
            )
        } else null
        
        // 提取预期结果
        val expectedResult = extractField(content, "预期结果") ?: ""
        
        // 提取等待时间
        val waitBefore = parseWaitTime(extractField(content, "操作前等待"))
        val waitAfter = parseWaitTime(extractField(content, "操作后等待"))
        
        // 提取错误处理
        val errorHandlingStr = extractField(content, "错误处理") ?: ""
        val maxRetries = extractField(content, "最大重试")?.filter { it.isDigit() }?.toIntOrNull() ?: 2
        val canPause = extractField(content, "可暂停")?.contains("是") ?: true
        
        return ParsedStep(
            id = id,
            phase = phase,
            actionType = actionType,
            description = description,
            targetElement = targetElement,
            expectedResult = expectedResult,
            waitBefore = waitBefore,
            waitAfter = waitAfter,
            errorHandling = ErrorHandling(
                strategy = parseErrorStrategy(errorHandlingStr),
                maxRetries = maxRetries
            ),
            canPause = canPause
        )
    }
    
    /**
     * 从内容中提取指定字段
     */
    private fun extractField(content: String, fieldName: String): String? {
        val pattern = Regex("$fieldName[:：]\\s*(.+?)(?=\\n[\\u4e00-\\u9fa5]+[:：]|$)", RegexOption.DOT_MATCHES_ALL)
        return pattern.find(content)?.groupValues?.get(1)?.trim()
    }
    
    /**
     * 解析操作类型
     */
    private fun parseActionType(typeStr: String): ActionType {
        return when (typeStr.lowercase().trim()) {
            "launchapp", "launch_app", "启动应用" -> ActionType.LAUNCH_APP
            "click", "点击" -> ActionType.CLICK
            "input", "输入" -> ActionType.INPUT
            "scroll", "滚动" -> ActionType.SCROLL
            "long_press", "longpress", "长按" -> ActionType.LONG_PRESS
            "double_click", "doubleclick", "双击" -> ActionType.DOUBLE_CLICK
            "drag", "拖拽" -> ActionType.DRAG
            "system_back", "返回" -> ActionType.SYSTEM_BACK
            "system_home", "主页" -> ActionType.SYSTEM_HOME
            "system_interaction", "系统交互" -> ActionType.SYSTEM_BACK
            "wait", "等待" -> ActionType.WAIT
            "condition", "条件" -> ActionType.CONDITION
            "screenshot", "截图" -> ActionType.SCREENSHOT
            else -> ActionType.CLICK // 默认为点击
        }
    }
    
    /**
     * 解析等待时间
     */
    private fun parseWaitTime(timeStr: String?): Long {
        if (timeStr.isNullOrBlank()) return 1000
        
        val numMatch = Regex("(\\d+)").find(timeStr)
        val value = numMatch?.groupValues?.get(1)?.toLongOrNull() ?: 1000
        
        return when {
            timeStr.contains("秒") || timeStr.contains("s", ignoreCase = true) -> value * 1000
            timeStr.contains("ms", ignoreCase = true) || timeStr.contains("毫秒") -> value
            value > 100 -> value // 假设大于100的是毫秒
            else -> value * 1000 // 否则假设是秒
        }
    }
    
    /**
     * 解析错误处理策略
     */
    private fun parseErrorStrategy(strategyStr: String): ErrorStrategy {
        return when {
            strategyStr.contains("重试") -> ErrorStrategy.RETRY
            strategyStr.contains("跳过") -> ErrorStrategy.SKIP
            strategyStr.contains("停止") || strategyStr.contains("终止") -> ErrorStrategy.STOP
            strategyStr.contains("备选") || strategyStr.contains("fallback") -> ErrorStrategy.FALLBACK
            strategyStr.contains("询问") || strategyStr.contains("用户") -> ErrorStrategy.ASK_USER
            else -> ErrorStrategy.RETRY
        }
    }
    
    /**
     * 从描述中提取文本
     */
    private fun extractTextFromDescription(description: String): String? {
        // 提取引号中的文本
        val quoted = Regex("[\"'「」『』](.+?)[\"'「」『』]").find(description)
        if (quoted != null) return quoted.groupValues[1]
        
        // 提取"xxx"按钮/图标等
        val button = Regex("""["'""''「」『』]?(.+?)["'""''「」『』]?(?:按钮|图标|链接|文字)""").find(description)
        if (button != null) return button.groupValues[1]
        
        return null
    }
    
    /**
     * 提取潜在问题
     */
    private fun extractPotentialIssues(input: String): List<PotentialIssue> {
        val issues = mutableListOf<PotentialIssue>()
        
        ISSUE_PATTERN.findAll(input).forEach { match ->
            val issueNumber = match.groupValues[1].toIntOrNull() ?: (issues.size + 1)
            val issueContent = match.groupValues[2].trim()
            
            val description = issueContent.lines().firstOrNull()?.trim() ?: ""
            val category = extractField(issueContent, "类别")?.let { parseIssueCategory(it) } 
                ?: IssueCategory.OTHER
            val severity = extractField(issueContent, "严重程度")?.let { parseIssueSeverity(it) }
                ?: IssueSeverity.MEDIUM
            val solution = extractField(issueContent, "解决方案") ?: ""
            val prevention = extractField(issueContent, "预防措施") ?: ""
            
            issues.add(PotentialIssue(
                id = issueNumber,
                description = description,
                category = category,
                severity = severity,
                solution = solution,
                prevention = prevention
            ))
        }
        
        return issues
    }
    
    /**
     * 解析问题类别
     */
    private fun parseIssueCategory(categoryStr: String): IssueCategory {
        return when (categoryStr.lowercase()) {
            "network", "网络" -> IssueCategory.NETWORK
            "ui", "界面" -> IssueCategory.UI
            "system", "系统" -> IssueCategory.SYSTEM
            "app", "应用" -> IssueCategory.APP
            "data", "数据" -> IssueCategory.DATA
            "security", "安全" -> IssueCategory.SECURITY
            "performance", "性能" -> IssueCategory.PERFORMANCE
            else -> IssueCategory.OTHER
        }
    }
    
    /**
     * 解析问题严重程度
     */
    private fun parseIssueSeverity(severityStr: String): IssueSeverity {
        return when (severityStr.lowercase()) {
            "minor", "轻微" -> IssueSeverity.MINOR
            "medium", "中等" -> IssueSeverity.MEDIUM
            "major", "重大" -> IssueSeverity.MAJOR
            "fatal", "致命" -> IssueSeverity.FATAL
            else -> IssueSeverity.MEDIUM
        }
    }
    
    /**
     * 提取注意事项
     */
    private fun extractNotes(input: String): List<String> {
        val notes = mutableListOf<String>()
        
        // 查找注意事项部分
        val notesSection = Regex("===\\s*注意事项\\s*===(.+?)(?====|$)", RegexOption.DOT_MATCHES_ALL)
            .find(input)?.groupValues?.get(1) ?: return notes
        
        NOTE_PATTERN.findAll(notesSection).forEach { match ->
            val category = match.groupValues[1]
            val content = match.groupValues[2].trim()
            notes.add("[$category] $content")
        }
        
        return notes
    }
}
