package com.example.xihe.automation.agent

import android.content.Context
import android.os.Build
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.core.LLMClient
import com.example.xihe.core.PreferencesManager
import com.example.xihe.tools.ToolCall
import com.example.xihe.tools.ToolRegistry
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withTimeout
import kotlin.coroutines.coroutineContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

class DefaultAgentService(private val context: Context) {
    data class AgentLoopResult(
        val success: Boolean,
        val summary: String,
        val iterations: Int
    )

    @Serializable
    private data class AgentResponse(
        val thought: String = "",
        val toolName: String? = null,
        val parameters: JsonObject = JsonObject(emptyMap()),
        val finish: Boolean = false,
        val summary: String? = null
    )

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    suspend fun run(
        userMessage: String,
        maxIterations: Int = 40,
        onProgress: (iteration: Int, message: String) -> Unit = { _, _ -> }
    ): AgentLoopResult {
        ToolRegistry.initializeTools(context)
        val llmClient = createConfiguredClient()
        val messages = mutableListOf<String>()
        val readiness = AutomationReadinessChecker.check(context)
        messages.add("USER_TASK:\n$userMessage")

        var lastToolSignature: String? = null
        var repeatedToolCount = 0

        repeat(maxIterations) { index ->
            coroutineContext.ensureActive()

            val basePrompt = buildPrompt(userMessage, messages, readiness)
            onProgress(index + 1, "Calling LLM")

            val response = callAgentWithRetry(llmClient, basePrompt)
                ?: return AgentLoopResult(
                    false,
                    "LLM 连续返回不可解析的内容，已中止调度",
                    index + 1
                )

            LogManager.d(TAG, "Agent iteration ${index + 1}: tool=${response.toolName}, finish=${response.finish}")
            if (response.finish || response.toolName == "finish") {
                val summary = response.summary
                    ?: response.parameters["summary"]?.jsonPrimitive?.contentOrNull
                    ?: "Task finished"
                return AgentLoopResult(true, summary, index + 1)
            }

            val toolName = response.toolName
                ?: return AgentLoopResult(false, "LLM did not choose a tool", index + 1)

            // 死循环检测：连续 3 次选择完全相同的工具与参数则中止
            val toolSignature = compactToolCall(toolName, response.parameters)
            if (toolSignature == lastToolSignature) {
                repeatedToolCount++
                if (repeatedToolCount >= 2) {
                    LogManager.w(TAG, "检测到连续重复工具调用，中止避免死循环: $toolSignature")
                    return AgentLoopResult(
                        false,
                        "检测到连续重复调用同一工具（$toolName），可能陷入死循环，已中止",
                        index + 1
                    )
                }
            } else {
                repeatedToolCount = 0
                lastToolSignature = toolSignature
            }

            onProgress(index + 1, "Executing tool: $toolName")
            val result = try {
                withTimeout(TOOL_EXECUTION_TIMEOUT_MS) {
                    ToolRegistry.executeTool(ToolCall(toolName, response.parameters))
                }
            } catch (e: TimeoutCancellationException) {
                LogManager.w(TAG, "工具 $toolName 执行超时")
                com.example.xihe.tools.ToolResult(
                    success = false,
                    message = "Tool $toolName 执行超时（>${TOOL_EXECUTION_TIMEOUT_MS / 1000}s）"
                )
            } catch (e: Exception) {
                LogManager.w(TAG, "工具 $toolName 执行异常: ${e.message}")
                com.example.xihe.tools.ToolResult(
                    success = false,
                    message = "Tool $toolName 执行异常: ${e.message ?: e.javaClass.simpleName}"
                )
            }

            messages.add("ASSISTANT_TOOL_CALL:$toolSignature")
            messages.add("TOOL_RESULT:${json.encodeToString(com.example.xihe.tools.ToolResult.serializer(), result)}")

            // 上下文限长：只保留最近的 N 轮调用记录以防 prompt 爆炸
            trimMessageHistory(messages)

            val finishedByTool = result.data?.jsonObject?.get("finished")?.jsonPrimitive?.booleanOrNull == true
            if (toolName == "finish" || finishedByTool) {
                return AgentLoopResult(result.success, result.message, index + 1)
            }
        }

        return AgentLoopResult(false, "Reached max iterations: $maxIterations", maxIterations)
    }

    private suspend fun callAgentWithRetry(
        llmClient: LLMClient,
        basePrompt: String
    ): AgentResponse? {
        // 首次调用
        val firstRaw = callLlmWithTimeout(llmClient, basePrompt) ?: return null
        parseAgentResponse(firstRaw)?.let { return it }

        LogManager.w(TAG, "首次 LLM 返回不可解析，进行一次修正重试")
        val correctivePrompt = basePrompt + "\n\nIMPORTANT: 上一次输出不是有效的 JSON 对象。请只输出符合上述 schema 的单个 JSON 对象，不要包含 markdown 、讲解或其他文本。"
        val secondRaw = callLlmWithTimeout(llmClient, correctivePrompt) ?: return null
        return parseAgentResponse(secondRaw)
    }

    private suspend fun callLlmWithTimeout(
        llmClient: LLMClient,
        prompt: String
    ): String? {
        return try {
            withTimeout(LLM_CALL_TIMEOUT_MS) {
                llmClient.chatCompletion(prompt, usePersonality = false)
            }
        } catch (e: TimeoutCancellationException) {
            LogManager.w(TAG, "LLM 调用超时（>${LLM_CALL_TIMEOUT_MS / 1000}s）")
            null
        } catch (e: Exception) {
            LogManager.w(TAG, "LLM 调用异常: ${e.message}")
            null
        }
    }

    private fun trimMessageHistory(messages: MutableList<String>) {
        if (messages.size <= MAX_HISTORY_ITEMS) return
        val taskHeader = messages.firstOrNull { it.startsWith("USER_TASK:") }
        val recent = messages.takeLast(MAX_HISTORY_ITEMS - 1)
        messages.clear()
        if (taskHeader != null) messages.add(taskHeader)
        messages.addAll(recent)
    }

    private fun createConfiguredClient(): LLMClient {
        val config = PreferencesManager.getApiConfig(context)
        return LLMClient(config.baseUrl, config.apiKey, config.modelName, config.providerId)
    }

    private fun buildPrompt(
        userMessage: String,
        history: List<String>,
        readiness: AutomationReadinessChecker.ReadinessReport
    ): String {
        val service = CoreAccessibilityService.getInstance()
        val size = service?.getScreenSize()
        val toolDefs = ToolRegistry.getAllToolDefinitions().joinToString("\n") { tool ->
            val params = tool.parameters.joinToString(", ") { p -> "${p.name}:${p.type}${if (p.required) " required" else ""}" }
            "- ${tool.name}: ${tool.description}. params=[$params]"
        }

        return """
You are the default Android system agent. Complete the user's task by repeatedly selecting exactly one registered tool.

Device context:
- brand: ${Build.BRAND}
- model: ${Build.MODEL}
- sdk: ${Build.VERSION.SDK_INT}
- resolution: ${size?.first ?: "unknown"}x${size?.second ?: "unknown"}
- currentPackage: ${service?.getCurrentPackageName() ?: "unknown"}

Automation readiness:
${readiness.toPromptContext()}

Registered tools:
$toolDefs

Rules:
1. Return only a JSON object, no markdown.
2. JSON schema: {"thought":"short reason","toolName":"tool_name","parameters":{...},"finish":false,"summary":null}
3. To finish, call toolName "finish" with parameters {"summary":"..."} or set finish=true.
4. Prefer get_screen_info before interacting with unknown screens.
5. Use tap/long_press/swipe for coordinates, click_by_text/click_by_id for nodes, press_back/press_home for navigation.
6. Do not exceed the task scope.
7. If OCR is not ready, rely on accessibility nodes first and avoid claiming visual-only details.
8. If the current package is not the target app, open or navigate to the target app before interacting.

User task:
$userMessage

History:
${history.joinToString("\n")}
""".trimIndent()
    }

    private fun parseAgentResponse(raw: String): AgentResponse? {
        val jsonText = extractJsonObject(raw) ?: return null
        return try {
            json.decodeFromString(AgentResponse.serializer(), jsonText)
        } catch (e: Exception) {
            LogManager.w(TAG, "Failed to parse agent JSON: ${e.message}")
            null
        }
    }

    private fun extractJsonObject(text: String): String? {
        val cleaned = text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val start = cleaned.indexOf('{')
        if (start < 0) return null
        var depth = 0
        var inString = false
        var escaped = false
        for (i in start until cleaned.length) {
            val c = cleaned[i]
            if (escaped) {
                escaped = false
                continue
            }
            if (c == '\\') {
                escaped = true
                continue
            }
            if (c == '"') inString = !inString
            if (!inString) {
                if (c == '{') depth++
                if (c == '}') {
                    depth--
                    if (depth == 0) return cleaned.substring(start, i + 1)
                }
            }
        }
        return null
    }

    private fun compactToolCall(toolName: String, parameters: JsonObject): String {
        return json.encodeToString(ToolCall.serializer(), ToolCall(toolName, parameters))
    }

    companion object {
        private const val TAG = "DefaultAgentService"
        private const val LLM_CALL_TIMEOUT_MS = 60_000L
        private const val TOOL_EXECUTION_TIMEOUT_MS = 30_000L
        private const val MAX_HISTORY_ITEMS = 24
    }
}
