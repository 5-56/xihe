package com.example.xihe.automation.script

import android.content.Context
import android.net.Uri
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * 📚 增强版脚本库管理器
 * 管理所有智能脚本的存储、加载、导入导出和删除
 */
object SmartScriptManager {
    private const val TAG = "ScriptManager"
    private const val SCRIPT_DIR = "xihe_scripts"
    private const val EXPORT_DIR = "xihe_exports"
    
    private val json = Json { 
        prettyPrint = true 
        ignoreUnknownKeys = true 
        encodeDefaults = true
    }
    private val scripts = mutableMapOf<String, SmartScript>()
    
    // ==================== 导入导出结果类型 ====================
    
    sealed class ImportResult {
        data class Success(val script: SmartScript) : ImportResult()
        data class Conflict(val existingScript: SmartScript, val newScript: SmartScript) : ImportResult()
        data class Error(val message: String, val details: String? = null) : ImportResult()
    }
    
    sealed class ExportResult {
        data class Success(val uri: Uri, val fileName: String) : ExportResult()
        data class Error(val message: String) : ExportResult()
    }
    
    data class ValidationResult(
        val isValid: Boolean,
        val errors: List<String> = emptyList()
    )
    
    /**
     * 初始化：加载所有脚本
     */
    fun initialize(context: Context) {
        val dir = File(context.filesDir, SCRIPT_DIR)
        if (!dir.exists()) dir.mkdirs()
        
        // 加载内置示例脚本
        if (dir.listFiles().isNullOrEmpty()) {
            createSampleScripts(dir)
        }
        
        // 读取所有脚本
        dir.listFiles { file -> file.extension == "json" }?.forEach { file ->
            try {
                val script = json.decodeFromString<SmartScript>(file.readText())
                scripts[script.id] = script
            } catch (e: Exception) {
                LogManager.e(TAG, "加载脚本失败: ${file.name}", e)
            }
        }
        
        LogManager.i(TAG, "脚本库加载完成，共 ${scripts.size} 个脚本")
    }
    
    /**
     * 获取所有脚本
     */
    fun getAllScripts(): List<SmartScript> = scripts.values.toList()
    
    /**
     * 保存/更新脚本
     */
    fun saveScript(context: Context, script: SmartScript) {
        try {
            val dir = File(context.filesDir, SCRIPT_DIR)
            val file = File(dir, "${script.id}.json")
            file.writeText(json.encodeToString(script))
            scripts[script.id] = script
            LogManager.i(TAG, "脚本已保存: ${script.metadata.name}")
        } catch (e: Exception) {
            LogManager.e(TAG, "保存脚本失败", e)
        }
    }
    
    /**
     * 根据ID获取脚本
     */
    fun getScript(id: String): SmartScript? = scripts[id]
    
    /**
     * 🔍 简单关键词搜索
     */
    fun searchScripts(query: String): List<SmartScript> {
        return scripts.values.filter { 
            it.metadata.name.contains(query, ignoreCase = true) ||
            it.metadata.keywords.any { k -> k.contains(query, ignoreCase = true) }
        }
    }
    
    // ==================== Task 1.1: 脚本格式验证 ====================
    
    /**
     * 验证脚本 JSON 格式
     * @param jsonString JSON 字符串
     * @return ValidationResult 包含验证结果和错误列表
     */
    fun validateScriptFormat(jsonString: String): ValidationResult {
        val errors = mutableListOf<String>()
        
        if (jsonString.isBlank()) {
            return ValidationResult(false, listOf("JSON 内容为空"))
        }
        
        try {
            val script = json.decodeFromString<SmartScript>(jsonString)
            
            // 验证必需字段
            if (script.id.isBlank()) {
                errors.add("缺少脚本 ID")
            }
            if (script.metadata.name.isBlank()) {
                errors.add("缺少脚本名称")
            }
            if (script.flow.steps.isEmpty()) {
                errors.add("脚本步骤列表为空")
            }
            
            // 验证步骤
            script.flow.steps.forEachIndexed { index, step ->
                if (step.id.isBlank()) {
                    errors.add("步骤 ${index + 1} 缺少 ID")
                }
                if (step.type == StepType.ACTION && step.action.isNullOrBlank()) {
                    errors.add("步骤 ${index + 1} (${step.id}) 是 ACTION 类型但缺少 action 字段")
                }
            }
            
            return ValidationResult(errors.isEmpty(), errors)
        } catch (e: kotlinx.serialization.SerializationException) {
            return ValidationResult(false, listOf("JSON 解析失败: ${e.message}"))
        } catch (e: Exception) {
            return ValidationResult(false, listOf("验证失败: ${e.message}"))
        }
    }
    
    // ==================== Task 1.2: 脚本导入功能 ====================
    
    /**
     * 从 URI 导入脚本
     * @param context Context
     * @param uri 文件 URI
     * @return ImportResult 导入结果
     */
    suspend fun importScript(context: Context, uri: Uri): ImportResult = withContext(Dispatchers.IO) {
        try {
            // 读取文件内容
            val jsonString = context.contentResolver.openInputStream(uri)?.use { 
                it.bufferedReader().readText() 
            } ?: return@withContext ImportResult.Error("无法读取文件")
            
            // 验证格式
            val validation = validateScriptFormat(jsonString)
            if (!validation.isValid) {
                return@withContext ImportResult.Error(
                    "脚本格式无效",
                    validation.errors.joinToString("\n")
                )
            }
            
            // 解析脚本
            val newScript = json.decodeFromString<SmartScript>(jsonString)
            
            // 检查冲突
            val existingScript = scripts[newScript.id]
            if (existingScript != null) {
                return@withContext ImportResult.Conflict(existingScript, newScript)
            }
            
            // 保存脚本
            saveScript(context, newScript)
            LogManager.i(TAG, "脚本导入成功: ${newScript.metadata.name}")
            
            ImportResult.Success(newScript)
        } catch (e: SecurityException) {
            ImportResult.Error("文件访问权限不足", e.message)
        } catch (e: Exception) {
            LogManager.e(TAG, "导入脚本失败", e)
            ImportResult.Error("导入失败", e.message)
        }
    }
    
    /**
     * 从 JSON 字符串导入脚本（用于覆盖导入）
     */
    suspend fun importScriptFromJson(context: Context, jsonString: String, overwrite: Boolean = false): ImportResult = withContext(Dispatchers.IO) {
        try {
            val validation = validateScriptFormat(jsonString)
            if (!validation.isValid) {
                return@withContext ImportResult.Error("脚本格式无效", validation.errors.joinToString("\n"))
            }
            
            val newScript = json.decodeFromString<SmartScript>(jsonString)
            
            if (!overwrite && scripts.containsKey(newScript.id)) {
                return@withContext ImportResult.Conflict(scripts[newScript.id]!!, newScript)
            }
            
            saveScript(context, newScript)
            ImportResult.Success(newScript)
        } catch (e: Exception) {
            ImportResult.Error("导入失败", e.message)
        }
    }
    
    // ==================== Task 1.3: 脚本导出功能 ====================
    
    /**
     * 导出单个脚本
     * @param context Context
     * @param scriptId 脚本 ID
     * @return ExportResult 导出结果
     */
    suspend fun exportScript(context: Context, scriptId: String): ExportResult = withContext(Dispatchers.IO) {
        try {
            val script = scripts[scriptId] 
                ?: return@withContext ExportResult.Error("脚本不存在: $scriptId")
            
            val exportDir = File(context.getExternalFilesDir(null), EXPORT_DIR)
            if (!exportDir.exists()) exportDir.mkdirs()
            
            val fileName = generateExportFileName(script)
            val exportFile = File(exportDir, fileName)
            
            exportFile.writeText(json.encodeToString(script))
            
            LogManager.i(TAG, "脚本导出成功: $fileName")
            ExportResult.Success(Uri.fromFile(exportFile), fileName)
        } catch (e: Exception) {
            LogManager.e(TAG, "导出脚本失败", e)
            ExportResult.Error("导出失败: ${e.message}")
        }
    }
    
    /**
     * 批量导出脚本为 ZIP 文件
     * @param context Context
     * @param scriptIds 脚本 ID 列表
     * @return ExportResult 导出结果
     */
    suspend fun exportScripts(context: Context, scriptIds: List<String>): ExportResult = withContext(Dispatchers.IO) {
        try {
            if (scriptIds.isEmpty()) {
                return@withContext ExportResult.Error("未选择任何脚本")
            }
            
            val exportDir = File(context.getExternalFilesDir(null), EXPORT_DIR)
            if (!exportDir.exists()) exportDir.mkdirs()
            
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val zipFileName = "xihe_scripts_$timestamp.zip"
            val zipFile = File(exportDir, zipFileName)
            
            ZipOutputStream(zipFile.outputStream()).use { zos ->
                scriptIds.forEach { scriptId ->
                    val script = scripts[scriptId] ?: return@forEach
                    val fileName = generateExportFileName(script)
                    val entry = ZipEntry(fileName)
                    zos.putNextEntry(entry)
                    zos.write(json.encodeToString(script).toByteArray())
                    zos.closeEntry()
                }
            }
            
            LogManager.i(TAG, "批量导出成功: $zipFileName, 共 ${scriptIds.size} 个脚本")
            ExportResult.Success(Uri.fromFile(zipFile), zipFileName)
        } catch (e: Exception) {
            LogManager.e(TAG, "批量导出失败", e)
            ExportResult.Error("批量导出失败: ${e.message}")
        }
    }
    
    private fun generateExportFileName(script: SmartScript): String {
        val safeName = script.metadata.name.replace(Regex("[^a-zA-Z0-9\\u4e00-\\u9fa5]"), "_")
        return "${safeName}_v${script.metadata.version}.json"
    }
    
    // ==================== Task 1.4: 脚本删除功能 ====================
    
    /**
     * 删除单个脚本
     * @param context Context
     * @param scriptId 脚本 ID
     * @return 是否删除成功
     */
    fun deleteScript(context: Context, scriptId: String): Boolean {
        return try {
            val dir = File(context.filesDir, SCRIPT_DIR)
            val file = File(dir, "$scriptId.json")
            
            val deleted = if (file.exists()) file.delete() else true
            if (deleted) {
                scripts.remove(scriptId)
                LogManager.i(TAG, "脚本已删除: $scriptId")
            }
            deleted
        } catch (e: Exception) {
            LogManager.e(TAG, "删除脚本失败: $scriptId", e)
            false
        }
    }
    
    /**
     * 批量删除脚本
     * @param context Context
     * @param scriptIds 脚本 ID 列表
     * @return 成功删除的数量
     */
    fun deleteScripts(context: Context, scriptIds: List<String>): Int {
        var deletedCount = 0
        scriptIds.forEach { scriptId ->
            if (deleteScript(context, scriptId)) {
                deletedCount++
            }
        }
        LogManager.i(TAG, "批量删除完成: $deletedCount/${scriptIds.size}")
        return deletedCount
    }
    
    // ==================== Task 1.5: 脚本版本管理 ====================
    
    /**
     * 保存脚本并自动递增版本号
     * @param context Context
     * @param script 脚本
     * @param incrementVersion 是否递增版本号
     */
    fun saveScriptWithVersion(context: Context, script: SmartScript, incrementVersion: Boolean = true): SmartScript {
        val updatedScript = if (incrementVersion && scripts.containsKey(script.id)) {
            val currentVersion = scripts[script.id]?.metadata?.version ?: 0
            script.copy(
                metadata = script.metadata.copy(version = currentVersion + 1),
                lastUpdated = System.currentTimeMillis()
            )
        } else {
            script.copy(lastUpdated = System.currentTimeMillis())
        }
        
        saveScript(context, updatedScript)
        return updatedScript
    }
    
    /**
     * 获取脚本的 JSON 字符串（用于编辑器显示）
     */
    fun getScriptJson(scriptId: String): String? {
        val script = scripts[scriptId] ?: return null
        return json.encodeToString(script)
    }

    private fun createSampleScripts(dir: File) {
        // 示例：微信打卡脚本
        // 这是一个占位，实际应该生成完整的 SmartScript JSON
    }
}
