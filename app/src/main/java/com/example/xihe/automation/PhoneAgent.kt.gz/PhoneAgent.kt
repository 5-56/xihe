package com.example.xihe.automation

import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.util.Base64
import com.example.xihe.utils.LogManager
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.core.LLMClient
import kotlinx.coroutines.delay
import java.io.ByteArrayOutputStream

/**
 * 🤖 智能手机Agent
 * 
 * 基于AI视觉模型的自动化执行器
 * 工作流程：截图 → AI分析 → 解析动作 → 执行 → 循环
 * 
 * 🔒 隐私保护：截图仅在本地处理，不上传云端（除非使用API模型）
 */
class PhoneAgent(
    private val context: Context,
    private val maxSteps: Int = 50
) {
    companion object {
        private const val TAG = "PhoneAgent"
        
        // 系统提示词
        private val SYSTEM_PROMPT = """
你是一个智能手机自动化助手。你可以看到手机屏幕截图和界面元素信息，根据用户任务执行操作。

## 可用动作

### 基础操作
- do(action="Tap", element=[x, y]) - 点击坐标（相对坐标0-1000）
- do(action="Long Press", element=[x, y]) - 长按坐标
- do(action="Double Tap", element=[x, y]) - 双击坐标
- do(action="Swipe", start=[x1, y1], end=[x2, y2]) - 滑动

### 快捷操作
- do(action="Click Text", text="按钮文字") - 根据文字查找并点击
- do(action="Scroll Up") - 向上滚动
- do(action="Scroll Down") - 向下滚动

### 输入操作
- do(action="Type", text="内容") - 在当前输入框输入文本
- do(action="Input To", hint="输入框提示", text="内容") - 查找输入框并输入

### 应用操作
- do(action="Launch", app="应用名") - 启动应用

### 系统操作
- do(action="Back") - 返回
- do(action="Home") - 回到主页
- do(action="Recent Apps") - 打开最近任务
- do(action="Notifications") - 打开通知栏
- do(action="Quick Settings") - 打开快速设置

### 完成任务
- finish(message="完成说明") - 任务完成

## 输出格式
<think>分析当前屏幕状态和下一步操作</think>
<answer>do(action="...", ...)</answer>

## 注意事项
1. 坐标使用相对值0-1000，会自动转换为屏幕像素
2. 每次只执行一个动作
3. 优先使用 Click Text 而非坐标点击，更稳定
4. 完成任务后必须调用 finish()
5. 如果操作失败，尝试其他方式完成目标
""".trimIndent()
    }
    
    // 对话历史
    private val conversationHistory = mutableListOf<ConversationMessage>()
    
    // 执行器
    private val actionExecutor = ActionExecutor()
    
    // LLM客户端
    private val llmClient = LLMClient()
    
    /**
     * 🚀 执行任务
     * 
     * @param task 用户任务描述
     * @param onStep 步骤回调（步骤号、状态、思考过程）
     * @return 最终结果
     */
    suspend fun run(
        task: String,
        onStep: suspend (Int, String, String?) -> Unit = { _, _, _ -> }
    ): AgentResult {
        LogManager.i(TAG, "🚀 开始执行任务: $task")
        conversationHistory.clear()
        
        // 检查无障碍服务
        val service = CoreAccessibilityService.instance
        if (service == null) {
            return AgentResult(
                success = false,
                message = "❌ 无障碍服务未启动，请先开启无障碍服务"
            )
        }
        
        // 获取屏幕尺寸
        val (screenWidth, screenHeight) = service.getScreenSize()
        LogManager.d(TAG, "📱 屏幕尺寸: ${screenWidth}x${screenHeight}")
        val reflectionEngine = AdaptiveExecutionEngine.getInstance(context)
        
        repeat(maxSteps) { step ->
            val stepNum = step + 1
            LogManager.d(TAG, "📍 步骤 $stepNum/$maxSteps")
            
            try {
                // 1. 截图
                onStep(stepNum, "正在分析屏幕...", null)
                val screenshot = takeScreenshot(service)
                if (screenshot == null) {
                    LogManager.w(TAG, "⚠️ 截图失败，尝试继续...")
                }
                
                // 2. 构建消息
                val screenInfo = buildScreenInfo(service)
                val userMessage = if (step == 0) {
                    "$task\n\n$screenInfo"
                } else {
                    "** Screen Info **\n\n$screenInfo"
                }
                
                // 3. 调用AI模型
                onStep(stepNum, "正在思考...", null)
                val aiResponse = callAI(userMessage, screenshot)
                
                // 4. 解析响应
                val (thinking, action) = parseResponse(aiResponse)
                LogManager.d(TAG, "💭 思考: $thinking")
                LogManager.d(TAG, "🎯 动作: $action")
                
                onStep(stepNum, "正在执行...", thinking)
                
                // 5. 解析并执行动作
                val parsedAction = ActionParser.parse(action)
                
                // 检查是否完成
                if (parsedAction["_metadata"] == "finish") {
                    val message = parsedAction["message"] as? String ?: "任务完成"
                    LogManager.i(TAG, "✅ 任务完成: $message")
                    return AgentResult(
                        success = true,
                        message = message,
                        steps = stepNum
                    )
                }
                
                // 6. 执行动作
                val optimizedAction = applyRuntimeOptimization(parsedAction, reflectionEngine)
                val actionStartTime = System.currentTimeMillis()
                val result = actionExecutor.execute(optimizedAction, screenWidth, screenHeight)
                val actionDurationMs = (System.currentTimeMillis() - actionStartTime).coerceAtLeast(1L)
                
                if (!result.success) {
                    LogManager.w(TAG, "⚠️ 动作执行失败: ${result.message}")
                }
                
                val runtimeAction = (optimizedAction["action"] as? String)
                    ?: (optimizedAction["_metadata"] as? String)
                    ?: "UNKNOWN"
                val reflectionUpdate = reflectionEngine.recordRuntimeReflection(
                    scope = "phone_agent",
                    action = runtimeAction,
                    target = extractRuntimeTarget(optimizedAction),
                    success = result.success,
                    reason = result.message,
                    durationMs = actionDurationMs
                )
                if (!reflectionUpdate.isNullOrBlank()) {
                    LogManager.d(TAG, "策略更新: $reflectionUpdate")
                }
                val runtimeWaitAfterMs = (optimizedAction["_runtime_wait_after_ms"] as? Number)?.toLong() ?: 0L
                if (runtimeWaitAfterMs > 0L) {
                    delay(runtimeWaitAfterMs)
                }

                if (result.shouldFinish) {
                    return AgentResult(
                        success = result.success,
                        message = result.message ?: "执行结束",
                        steps = stepNum
                    )
                }
                
                // 7. 等待界面稳定
                delay(500)
                
            } catch (e: Exception) {
                LogManager.e(TAG, "❌ 步骤 $stepNum 执行出错", e)
                onStep(stepNum, "出错: ${e.message}", null)
            }
        }
        
        return AgentResult(
            success = false,
            message = "⚠️ 达到最大步数限制 ($maxSteps)",
            steps = maxSteps
        )
    }
    
    /**
     * 📸 截图并转Base64
     */
    private suspend fun takeScreenshot(service: CoreAccessibilityService): String? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val bitmap = service.takeScreenshotAsync()
                bitmap?.let { bitmapToBase64(it) }
            } else {
                // Android 10及以下使用MediaProjection（需要用户授权）
                LogManager.w(TAG, "Android 10及以下需要使用MediaProjection截图")
                null
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "截图失败", e)
            null
        }
    }
    
    /**
     * 🖼️ Bitmap转Base64
     */
    private fun bitmapToBase64(bitmap: Bitmap): String {
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 80, stream)
        return Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
    }
    
    /**
     * 📱 构建屏幕信息（增强版）
     * 包含当前应用、屏幕元素等信息
     */
    private fun buildScreenInfo(service: CoreAccessibilityService): String {
        val packageName = service.getCurrentPackageName() ?: "unknown"
        val (width, height) = service.getScreenSize()
        
        // 获取屏幕元素（限制数量避免 token 过多）
        val elementsJson = try {
            service.getScreenElementsJson()
        } catch (e: Exception) {
            LogManager.w(TAG, "获取屏幕元素失败", e)
            "[]"
        }
        
        return buildString {
            append("""{"current_app":"$packageName",""")
            append(""""screen_size":[${width},${height}],""")
            append(""""elements":$elementsJson}""")
        }
    }
    
    /**
     * 🤖 调用AI模型（支持视觉模型）
     */
    private suspend fun callAI(userMessage: String, imageBase64: String?): String {
        // 初始化 LLM 客户端配置
        val apiConfig = com.example.xihe.core.PreferencesManager.getApiConfig(context)
        llmClient.updateConfig(
            newBaseUrl = apiConfig.baseUrl,
            newApiKey = apiConfig.apiKey,
            newModelName = apiConfig.modelName,
            newProviderId = apiConfig.providerId
        )
        
        val reflectionSummary = AdaptiveExecutionEngine.getInstance(context)
            .getRuntimeReflectionSummary("phone_agent")
        val response = if (imageBase64 != null) {
            // 使用视觉模型分析截图
            val fullPrompt = "$SYSTEM_PROMPT\n\n历史反思策略：\n$reflectionSummary\n\n当前屏幕信息：\n$userMessage\n\n请根据截图和屏幕信息执行下一步操作。"
            try {
                llmClient.chatCompletionWithImage(fullPrompt, imageBase64, usePersonality = false)
            } catch (e: Exception) {
                LogManager.e(TAG, "视觉模型调用失败，回退到纯文本", e)
                // 回退到纯文本模式
                llmClient.chatCompletion("$SYSTEM_PROMPT\n\n历史反思策略：\n$reflectionSummary\n\n用户请求：$userMessage", usePersonality = false)
            }
        } else {
            // 纯文本模式
            llmClient.chatCompletion("$SYSTEM_PROMPT\n\n历史反思策略：\n$reflectionSummary\n\n用户请求：$userMessage", usePersonality = false)
        }
        
        // 保存到历史（不保存图片，节省内存）
        conversationHistory.add(ConversationMessage("user", userMessage))
        conversationHistory.add(ConversationMessage("assistant", response))
        
        // 限制历史长度，避免 token 过多
        while (conversationHistory.size > 10) {
            conversationHistory.removeAt(0)
        }
        
        return response
    }
    
    /**
     * 📝 解析AI响应
     */
    private fun parseResponse(response: String): Pair<String, String> {
        val thinkMatch = Regex("<think>(.*?)</think>", RegexOption.DOT_MATCHES_ALL).find(response)
        val answerMatch = Regex("<answer>(.*?)</answer>", RegexOption.DOT_MATCHES_ALL).find(response)
        
        val thinking = thinkMatch?.groupValues?.get(1)?.trim() ?: ""
        val action = answerMatch?.groupValues?.get(1)?.trim() ?: response.trim()
        
        return Pair(thinking, action)
    }
    private fun applyRuntimeOptimization(
        parsedAction: Map<String, Any>,
        reflectionEngine: AdaptiveExecutionEngine
    ): Map<String, Any> {
        if (parsedAction["_metadata"] != "do") {
            return parsedAction
        }

        val currentAction = (parsedAction["action"] as? String)?.trim()?.takeIf { it.isNotEmpty() }
            ?: return parsedAction
        val target = extractRuntimeTarget(parsedAction)
        val advice = reflectionEngine.getRuntimeOptimizationAdvice(
            scope = "phone_agent",
            action = currentAction,
            target = target
        )

        if (advice.suggestedAction.trim().equals("STOP", ignoreCase = true)) {
            return mapOf("_metadata" to "finish", "action" to "STOP", "message" to "运行时策略建议停止")
        }
        val suggestedAction = normalizePhoneActionName(advice.suggestedAction, currentAction)
        if (suggestedAction == currentAction && advice.waitAfterMs <= 0L) {
            return parsedAction
        }

        val optimized = parsedAction.toMutableMap()
        optimized["action"] = suggestedAction
        if (advice.waitAfterMs > 0L) {
            optimized["_runtime_wait_after_ms"] = advice.waitAfterMs
        }
        return optimized
    }

    private fun normalizePhoneActionName(suggestedAction: String, fallbackAction: String): String {
        val candidate = suggestedAction.trim().uppercase().ifBlank { fallbackAction }
        return when (candidate) {
            "TAP" -> "Tap"
            "LONG PRESS" -> "Long Press"
            "DOUBLE TAP" -> "Double Tap"
            "SWIPE" -> "Swipe"
            "CLICK", "CLICK TEXT" -> "Click Text"
            "SCROLL UP", "SWIPE_UP" -> "Scroll Up"
            "SCROLL DOWN", "SWIPE_DOWN" -> "Scroll Down"
            "TYPE", "INPUT", "INPUT_TEXT" -> "Type"
            "INPUT TO" -> "Input To"
            "LAUNCH", "OPEN_APP", "OPEN APP", "LAUNCH_APP" -> "Launch"
            "BACK", "PRESS_BACK" -> "Back"
            "HOME" -> "Home"
            "RECENT APPS" -> "Recent Apps"
            "NOTIFICATIONS" -> "Notifications"
            "QUICK SETTINGS" -> "Quick Settings"
            else -> fallbackAction
        }
    }

    private fun extractRuntimeTarget(action: Map<String, Any>): String? {
        val target = (action["text"] as? String)
            ?: (action["hint"] as? String)
            ?: (action["app"] as? String)
            ?: (action["action"] as? String)
        return target?.trim()?.takeIf { it.isNotEmpty() }
    }
}

/**
 * 对话消息
 */
data class ConversationMessage(
    val role: String,
    val content: String
)

/**
 * Agent执行结果
 */
data class AgentResult(
    val success: Boolean,
    val message: String,
    val steps: Int = 0
)

/**
 * 🎬 动作执行器
 */
class ActionExecutor {
    companion object {
        private const val TAG = "ActionExecutor"
    }
    
    private val service: CoreAccessibilityService
        get() = CoreAccessibilityService.instance 
            ?: throw IllegalStateException("无障碍服务未启动")
    
    /**
     * 执行解析后的动作
     */
    suspend fun execute(
        action: Map<String, Any>,
        screenWidth: Int,
        screenHeight: Int
    ): ActionResult {
        val actionType = action["_metadata"] as? String
        
        if (actionType == "finish") {
            return ActionResult(true, true, action["message"] as? String)
        }
        
        if (actionType != "do") {
            return ActionResult(false, true, "未知动作类型: $actionType")
        }
        
        return when (action["action"] as? String) {
            "Launch" -> {
                val appName = action["app"] as? String ?: return ActionResult(false, false, "未指定应用")
                val packageName = AppPackages.getPackageName(appName)
                val success = if (packageName != null) {
                    service.launchApp(packageName)
                } else {
                    // 尝试直接作为包名启动
                    service.launchApp(appName)
                }
                delay(1500)
                ActionResult(success, false, if (success) "已启动$appName" else "启动失败")
            }
            
            "Tap" -> {
                val element = action["element"] as? List<*>
                if (element == null || element.size < 2) {
                    return ActionResult(false, false, "坐标格式错误")
                }
                val (x, y) = convertCoordinates(element, screenWidth, screenHeight)
                val success = service.tapAsync(x, y)
                delay(500)
                ActionResult(success, false, if (success) "点击成功" else "点击失败")
            }
            
            "Long Press" -> {
                val element = action["element"] as? List<*>
                if (element == null || element.size < 2) {
                    return ActionResult(false, false, "坐标格式错误")
                }
                val (x, y) = convertCoordinates(element, screenWidth, screenHeight)
                val success = service.longPressAsync(x, y)
                delay(500)
                ActionResult(success, false)
            }
            
            "Swipe" -> {
                val start = action["start"] as? List<*>
                val end = action["end"] as? List<*>
                if (start == null || end == null || start.size < 2 || end.size < 2) {
                    return ActionResult(false, false, "滑动坐标格式错误")
                }
                val (startX, startY) = convertCoordinates(start, screenWidth, screenHeight)
                val (endX, endY) = convertCoordinates(end, screenWidth, screenHeight)
                val success = service.swipeAsync(startX, startY, endX, endY, 500)
                delay(500)
                ActionResult(success, false)
            }
            
            "Type" -> {
                val text = action["text"] as? String ?: ""
                val success = service.inputText(text)
                ActionResult(success, false)
            }
            
            "Back" -> {
                service.performGlobalBack()
                delay(300)
                ActionResult(true, false)
            }
            
            "Home" -> {
                service.performGlobalHome()
                delay(500)
                ActionResult(true, false)
            }
            
            "Double Tap" -> {
                val element = action["element"] as? List<*>
                if (element == null || element.size < 2) {
                    return ActionResult(false, false, "坐标格式错误")
                }
                val (x, y) = convertCoordinates(element, screenWidth, screenHeight)
                service.performDoubleClick(x, y)
                delay(500)
                ActionResult(true, false)
            }
            
            "Scroll Up" -> {
                val centerX = screenWidth / 2f
                val success = service.swipeAsync(centerX, screenHeight * 0.7f, centerX, screenHeight * 0.3f, 400)
                delay(500)
                ActionResult(success, false)
            }
            
            "Scroll Down" -> {
                val centerX = screenWidth / 2f
                val success = service.swipeAsync(centerX, screenHeight * 0.3f, centerX, screenHeight * 0.7f, 400)
                delay(500)
                ActionResult(success, false)
            }
            
            "Click Text" -> {
                val text = action["text"] as? String ?: return ActionResult(false, false, "未指定文本")
                val success = service.findAndClick(text)
                delay(500)
                ActionResult(success, false, if (success) "点击\"$text\"成功" else "未找到\"$text\"")
            }
            
            "Input To" -> {
                val hint = action["hint"] as? String ?: ""
                val text = action["text"] as? String ?: ""
                val success = service.findAndInput(hint, text)
                ActionResult(success, false)
            }
            
            "Recent Apps" -> {
                service.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS)
                delay(500)
                ActionResult(true, false)
            }
            
            "Notifications" -> {
                service.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
                delay(500)
                ActionResult(true, false)
            }
            
            "Quick Settings" -> {
                service.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
                delay(500)
                ActionResult(true, false)
            }
            
            else -> ActionResult(false, false, "未知动作: ${action["action"]}")
        }
    }
    
    /**
     * 将相对坐标(0-1000)转换为屏幕像素坐标
     */
    private fun convertCoordinates(
        element: List<*>,
        screenWidth: Int,
        screenHeight: Int
    ): Pair<Float, Float> {
        val relX = (element[0] as? Number)?.toFloat() ?: 500f
        val relY = (element[1] as? Number)?.toFloat() ?: 500f
        return Pair(
            relX / 1000f * screenWidth,
            relY / 1000f * screenHeight
        )
    }
}

/**
 * 动作执行结果
 */
data class ActionResult(
    val success: Boolean,
    val shouldFinish: Boolean,
    val message: String? = null
)

/**
 * 📝 动作解析器
 */
object ActionParser {
    
    fun parse(actionStr: String): Map<String, Any> {
        val trimmed = actionStr.trim()
        
        return when {
            trimmed.startsWith("do(") -> parseDoAction(trimmed)
            trimmed.startsWith("finish(") -> parseFinishAction(trimmed)
            else -> mapOf("_metadata" to "unknown")
        }
    }
    
    private fun parseDoAction(actionStr: String): Map<String, Any> {
        val result = mutableMapOf<String, Any>("_metadata" to "do")
        val content = actionStr.removePrefix("do(").removeSuffix(")")
        
        // 匹配 key="value"
        Regex("""(\w+)\s*=\s*"([^"]*)"""").findAll(content).forEach {
            result[it.groupValues[1]] = it.groupValues[2]
        }
        
        // 匹配 key=[x, y]
        Regex("""(\w+)\s*=\s*\[([^\]]+)\]""").findAll(content).forEach {
            result[it.groupValues[1]] = it.groupValues[2]
                .split(",")
                .map { v -> v.trim().toIntOrNull() ?: 0 }
        }
        
        return result
    }
    
    private fun parseFinishAction(actionStr: String): Map<String, Any> {
        val result = mutableMapOf<String, Any>("_metadata" to "finish")
        
        Regex("""message\s*=\s*"([^"]*)"""").find(actionStr)?.let {
            result["message"] = it.groupValues[1]
        }
        
        return result
    }
}

/**
 * 📦 应用包名映射
 */
object AppPackages {
    private val packageMap = mapOf(
        "微信" to "com.tencent.mm",
        "qq" to "com.tencent.mobileqq",
        "抖音" to "com.ss.android.ugc.aweme",
        "快手" to "com.smile.gifmaker",
        "淘宝" to "com.taobao.taobao",
        "支付宝" to "com.eg.android.AlipayGphone",
        "美团" to "com.sankuai.meituan",
        "饿了么" to "me.ele",
        "哔哩哔哩" to "tv.danmaku.bili",
        "b站" to "tv.danmaku.bili",
        "bilibili" to "tv.danmaku.bili",
        "微博" to "com.sina.weibo",
        "知乎" to "com.zhihu.android",
        "网易云音乐" to "com.netease.cloudmusic",
        "qq音乐" to "com.tencent.qqmusic",
        "酷狗音乐" to "com.kugou.android",
        "高德地图" to "com.autonavi.minimap",
        "高德" to "com.autonavi.minimap",
        "百度地图" to "com.baidu.BaiduMap",
        "滴滴" to "com.sdu.didi.psnger",
        "京东" to "com.jingdong.app.mall",
        "拼多多" to "com.xunmeng.pinduoduo",
        "小红书" to "com.xingin.xhs",
        "钉钉" to "com.alibaba.android.rimet",
        "飞书" to "com.ss.android.lark",
        "telegram" to "org.telegram.messenger",
        "电报" to "org.telegram.messenger",
        "chrome" to "com.android.chrome",
        "浏览器" to "com.android.browser",
        "相机" to "com.android.camera",
        "相册" to "com.android.gallery",
        "设置" to "com.android.settings",
        "日历" to "com.android.calendar",
        "时钟" to "com.android.deskclock",
        "计算器" to "com.android.calculator2",
        "通讯录" to "com.android.contacts",
        "短信" to "com.android.mms",
        "电话" to "com.android.dialer"
    )
    
    fun getPackageName(appName: String): String? {
        return packageMap[appName.lowercase()] ?: packageMap[appName]
    }
}
