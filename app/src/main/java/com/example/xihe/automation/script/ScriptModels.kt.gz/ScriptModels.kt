package com.example.xihe.automation.script

import com.example.xihe.automation.flow.AutomationFlow
import kotlinx.serialization.Serializable

/**
 * 📜 智能脚本模型 (增强版)
 */
@Serializable
data class SmartScript(
    val id: String,
    val metadata: ScriptMetadata,
    val flow: AdvancedAutomationFlow,
    val variables: MutableMap<String, String> = mutableMapOf(), // 🚀 变量寄存器
    val lastUpdated: Long = System.currentTimeMillis()
)

@Serializable
data class AdvancedAutomationFlow(
    val steps: List<SmartStep>,
    val onGlobalFailure: String? = null // 失败后的补救脚本 ID
)

@Serializable
data class SmartStep(
    val id: String,
    val type: StepType,
    val action: String? = null,      // CLICK, INPUT, SCROLL
    val target: String? = null,      // 目标元素文本/ID
    val value: String? = null,       // 输入内容或变量引用 (如 $NAME)
    val condition: ScriptCondition? = null, // IF 类型步骤的判断条件
    val nextStepIfTrue: String? = null,
    val nextStepIfFalse: String? = null
)

enum class StepType { ACTION, CONDITION, LOOP, DELAY }

@Serializable
data class ScriptCondition(
    val type: ConditionType,
    val pattern: String,
    val targetApp: String? = null
)

enum class ConditionType { ELEMENT_EXISTS, TEXT_CONTAINS, APP_IN_FOREGROUND }

@Serializable
data class ScriptMetadata(
    val name: String,
    val description: String,
    val keywords: List<String>,
    val intent: String,
    val version: Int = 1
)

/**
 * 🧠 决策上下文
 * AI 在做决策时需要的输入信息
 */
data class DecisionContext(
    val userGoal: String,           // 用户想做什么
    val screenText: List<String>,   // 当前屏幕上的文字
    val currentPackage: String,     // 当前应用包名
    val scriptHistory: List<String> // 最近执行过的脚本ID
)

/**
 * 🎯 决策结果
 */
data class DecisionResult(
    val action: String,             // 建议动作 (CLICK, SCROLL, etc.)
    val target: String?,            // 动作目标 (如按钮文字)
    val confidence: Float,          // 置信度
    val reasoning: String           // 推理理由
)
