package com.example.xihe.automation.agent

import android.content.Context
import com.example.xihe.automation.SmartAutomationManager
import com.example.xihe.automation.flow.ActionType
import com.example.xihe.core.ScreenAnalyzer
import com.example.xihe.training.LocalModelTrainer
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.delay

/**
 * 🧠 AI 规划器
 * 负责根据用户目标和当前屏幕状态，决定下一步动作
 */
object AIPlanner {
    private const val TAG = "AIPlanner"

    data class ActionProposal(
        val type: ActionType,
        val params: Map<String, String>,
        val reasoning: String,
        val confidence: Float
    )

    /**
     * 思考下一步动作
     */
    suspend fun planNextStep(
        context: Context, 
        userGoal: String,
        stepHistory: List<String>
    ): ActionProposal? {
        LogManager.i(TAG, "🧠 AI正在思考: 目标='$userGoal'")

        // 1. 获取当前屏幕信息 (模拟视觉输入)
        val screenInfo = SmartAutomationManager.analyzeScreen()
        val screenText = screenInfo?.textContent?.joinToString(" ") ?: ""
        
        LogManager.d(TAG, "👀 看到屏幕内容: ${screenText.take(50)}...")

        // 2. 策略A: 简单的文本匹配 (启发式，速度快)
        // 如果目标中包含屏幕上的某些文字，这通常是下一步的线索
        val keyWords = extractKeywords(userGoal)
        for (word in keyWords) {
            if (screenText.contains(word)) {
                return ActionProposal(
                    type = ActionType.SMART_FIND_AND_CLICK,
                    params = mapOf("target" to word),
                    reasoning = "在屏幕上发现了关键词 '$word'，尝试点击",
                    confidence = 0.9f
                )
            }
        }

        // 3. 策略B: 调用本地大模型 (智能决策)
        // 当简单规则无法解决时，询问本地模型
        try {
            val trainer = LocalModelTrainer.getInstance(context)
            val prompt = "User Goal: $userGoal. Screen contains: $screenText. What is the next UI action?"
            val prediction = trainer.predict(prompt)
            
            // 如果模型认为应该打开应用
            if (prediction.intent == com.example.xihe.training.UserIntent.OPEN_APP) {
                 val appName = userGoal.replace("打开", "").trim()
                 return ActionProposal(
                     type = ActionType.OPEN_APP,
                     params = mapOf("app_name" to appName),
                     reasoning = "模型判断意图为打开应用 '$appName'",
                     confidence = 0.8f
                 )
            }
            
            // 根据模型预测的其他意图进行处理
            if (prediction.confidence > 0.6f) {
                return mapPredictionToProposal(prediction, userGoal, screenText)
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "模型推理失败: ${e.message}", e)
            // 继续使用降级策略
        }

        // 4. 策略C: 智能降级 - 根据历史和上下文决定
        return fallbackStrategy(userGoal, screenText, stepHistory)
    }
    
    /**
     * 将模型预测映射为动作提案
     */
    private fun mapPredictionToProposal(
        prediction: com.example.xihe.training.PredictionResult,
        userGoal: String,
        screenText: String
    ): ActionProposal? {
        return when (prediction.intent.name) {
            "CLICK", "TAP" -> {
                val target = extractTargetFromGoal(userGoal) ?: return null
                ActionProposal(
                    type = ActionType.SMART_FIND_AND_CLICK,
                    params = mapOf("target" to target),
                    reasoning = "模型建议点击 '$target'",
                    confidence = prediction.confidence
                )
            }
            "SCROLL", "SWIPE" -> {
                ActionProposal(
                    type = ActionType.SWIPE,
                    params = mapOf("direction" to "UP"),
                    reasoning = "模型建议滑动查找",
                    confidence = prediction.confidence
                )
            }
            "INPUT", "TYPE" -> {
                val text = extractInputText(userGoal) ?: ""
                ActionProposal(
                    type = ActionType.INPUT_TEXT,
                    params = mapOf("text" to text),
                    reasoning = "模型建议输入文本",
                    confidence = prediction.confidence
                )
            }
            else -> null
        }
    }
    
    /**
     * 降级策略 - 当模型推理失败时使用
     */
    private fun fallbackStrategy(
        userGoal: String,
        screenText: String,
        stepHistory: List<String>
    ): ActionProposal? {
        // 检查是否已经尝试过滑动
        val hasScrolledUp = stepHistory.contains("SWIPE_UP") || stepHistory.contains("SWIPE")
        val hasScrolledDown = stepHistory.contains("SWIPE_DOWN")
        
        // 如果还没滑动过，尝试向上滑动查找
        if (!hasScrolledUp) {
            return ActionProposal(
                type = ActionType.SWIPE,
                params = mapOf("direction" to "UP"),
                reasoning = "当前屏未找到目标，尝试向上滑动查找",
                confidence = 0.5f
            )
        }
        
        // 如果向上滑动过但没向下滑动，尝试向下
        if (!hasScrolledDown) {
            return ActionProposal(
                type = ActionType.SWIPE,
                params = mapOf("direction" to "DOWN"),
                reasoning = "向上滑动未找到，尝试向下滑动",
                confidence = 0.4f
            )
        }
        
        // 如果都尝试过了，返回 null 表示无法继续
        LogManager.w(TAG, "⚠️ 所有降级策略已用尽，无法继续")
        return null
    }
    
    /**
     * 从目标中提取点击目标
     */
    private fun extractTargetFromGoal(goal: String): String? {
        val patterns = listOf(
            Regex("点击[「『\"']?(.+?)[」』\"']?$"),
            Regex("按[「『\"']?(.+?)[」』\"']?$"),
            Regex("找到[「『\"']?(.+?)[」』\"']?并点击"),
        )
        
        for (pattern in patterns) {
            pattern.find(goal)?.let { return it.groupValues[1] }
        }
        
        return null
    }
    
    /**
     * 从目标中提取输入文本
     */
    private fun extractInputText(goal: String): String? {
        val patterns = listOf(
            Regex("输入[「『\"']?(.+?)[」』\"']?$"),
            Regex("填写[「『\"']?(.+?)[」』\"']?$"),
            Regex("写入[「『\"']?(.+?)[」』\"']?$"),
        )
        
        for (pattern in patterns) {
            pattern.find(goal)?.let { return it.groupValues[1] }
        }
        
        return null
    }

    private fun extractKeywords(text: String): List<String> {
        // 简单的关键词提取，实际可用分词库
        return text.replace("打开", "")
                   .replace("点击", "")
                   .replace("帮我", "")
                   .split(" ")
                   .filter { it.length > 1 }
    }
}
