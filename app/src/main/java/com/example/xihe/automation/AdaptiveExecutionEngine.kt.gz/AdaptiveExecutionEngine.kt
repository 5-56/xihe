package com.example.xihe.automation

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.accessibility.AccessibilityNodeInfo
import com.example.xihe.utils.LogManager
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.core.AutomationEngine
import com.example.xihe.core.model.ChatMessageDisplay
import com.example.xihe.core.LLMClient
import com.example.xihe.core.ActionExecutor
import com.example.xihe.scenarios.*
import com.example.xihe.scripts.*
import com.example.xihe.training.TrainingDataCollector
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json

/**
 * 🧠 自适应执行引擎
 * 
 * 完整的智能执行流程：
 * 1. 接收用户指令
 * 2. 识别意图，规划任务
 * 3. 执行步骤，成功则下一步
 * 4. 失败时思考原因，调整策略重试
 * 5. 多次失败时搜索资料学习
 * 6. 重新规划，从断点继续执行
 */
class AdaptiveExecutionEngine(private val context: Context) {
    
    companion object {
        private const val TAG = "AdaptiveExecution"
        private const val MAX_STEP_RETRY = 3
        private const val MAX_TASK_RETRY = 2
        private const val SEARCH_LEARNING_THRESHOLD = 2
        private const val STEP_TIMEOUT_MS = 12000L
        private const val STEP_TIMEOUT_LAUNCH_APP_MS = 18000L
        private const val STEP_TIMEOUT_WAIT_MS = 20000L
        private const val STEP_TIMEOUT_INPUT_TEXT_MS = 8000L
        private const val RETRY_TIMEOUT_INCREMENT_MS = 1500L
        private const val RETRY_BASE_DELAY_MS = 400L
        private const val RETRY_MAX_DELAY_MS = 2400L
        private const val INTENT_CACHE_MAX_SIZE = 80
        private const val PLAN_CACHE_MAX_SIZE = 80
        private const val COMMAND_DEDUP_WINDOW_MS = 1500L
        private const val REFLECTION_WINDOW_SIZE = 6
        private const val REFLECTION_HISTORY_MAX_SIZE = 240
        private const val REFLECTION_FAILURE_THRESHOLD = 2
        private const val REFLECTION_WAIT_INCREMENT_MS = 600L
        private const val REFLECTION_MAX_WAIT_MS = 3500L
        private const val REFLECTION_PARAM_WAIT_INCREMENT_MS = 400L
        private const val REFLECTION_PARAM_WAIT_MAX_MS = 6000L
        private const val REFLECTION_PARAM_WAIT_FOR_TEXT_INCREMENT_MS = 1200L
        private const val REFLECTION_PARAM_WAIT_FOR_TEXT_MAX_MS = 20000L
        private const val REFLECTION_PARAM_SWIPE_DISTANCE_INCREMENT = 120L
        private const val REFLECTION_PARAM_SWIPE_DISTANCE_MAX = 1200L
        private const val REFLECTION_PREFS_NAME = "adaptive_execution_reflection"
        private const val REFLECTION_POLICIES_KEY = "runtime_optimization_policies"
        
        @Volatile
        private var instance: AdaptiveExecutionEngine? = null
        
        fun getInstance(context: Context): AdaptiveExecutionEngine {
            return instance ?: synchronized(this) {
                instance ?: AdaptiveExecutionEngine(context.applicationContext).also { instance = it }
            }
        }
    }
    
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    
    // LLM 客户端
    private val llmClient by lazy { 
        LLMClient(
            AutomationEngine.baseUrl,
            AutomationEngine.apiKey,
            AutomationEngine.modelName,
            AutomationEngine.providerId
        )
    }
    
    // 执行状态
    private val _state = MutableStateFlow<ExecutionEngineState>(ExecutionEngineState.Idle)
    val state: StateFlow<ExecutionEngineState> = _state.asStateFlow()
    
    // 当前任务上下文
    private var currentTask: TaskContext? = null
    private var executionJob: Job? = null
    
    // 执行历史（用于学习）
    private val executionHistory = mutableListOf<ExecutionRecord>()
    
    // 已学习的知识
    private val learnedKnowledge = mutableMapOf<String, LearnedSolution>()
    private val reflectionHistory = mutableListOf<StepReflection>()
    private val stepOptimizations = mutableMapOf<String, StepOptimization>()
    private val reflectionLock = Any()

    private val intentCache = object : LinkedHashMap<String, UserIntent>(INTENT_CACHE_MAX_SIZE, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, UserIntent>?): Boolean {
            return size > INTENT_CACHE_MAX_SIZE
        }
    }

    private val planCache = object : LinkedHashMap<String, TaskPlan>(PLAN_CACHE_MAX_SIZE, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, TaskPlan>?): Boolean {
            return size > PLAN_CACHE_MAX_SIZE
        }
    }
    
    private val commandDedupLock = Any()
    private var lastCommandKey: String = ""
    private var lastCommandTimestamp: Long = 0L

    // 训练数据收集器
    private val trainingDataCollector by lazy { TrainingDataCollector.getInstance(context) }

    init {
        loadReflectionOptimizations()
    }
    
    /**
     * 🚀 执行用户指令
     */
    fun executeCommand(
        userCommand: String,
        onMessage: (String) -> Unit = {}
    ) {
        if (executionJob?.isActive == true || _state.value is ExecutionEngineState.Analyzing || _state.value is ExecutionEngineState.Executing) {
            onMessage("正在执行其他任务，请稍候...")
            return
        }
        
        val dedupKey = normalizeCommandKey(userCommand)
        if (dedupKey.isBlank()) {
            onMessage("指令为空，请重新输入")
            return
        }
        val now = System.currentTimeMillis()
        val isDuplicate = synchronized(commandDedupLock) {
            val duplicated = dedupKey == lastCommandKey && now - lastCommandTimestamp < COMMAND_DEDUP_WINDOW_MS
            if (!duplicated) {
                lastCommandKey = dedupKey
                lastCommandTimestamp = now
            }
            duplicated
        }
        if (isDuplicate) {
            onMessage("检测到重复指令，已忽略")
            return
        }

        executionJob = scope.launch {
            try {
                executeCommandInternal(userCommand, onMessage)
            } catch (e: CancellationException) {
                LogManager.d(TAG, "任务已取消")
                _state.value = ExecutionEngineState.Cancelled
                onMessage("任务已取消")
            } catch (e: Exception) {
                LogManager.e(TAG, "执行异常", e)
                _state.value = ExecutionEngineState.Failed(e.message ?: "未知错误")
                onMessage("执行失败: ${e.message}")
            }
        }
    }
    
    private suspend fun executeCommandInternal(
        userCommand: String,
        onMessage: (String) -> Unit
    ) {
        LogManager.d(TAG, "📝 收到指令: $userCommand")
        onMessage("正在分析指令...")
        
        // 🎓 开始训练数据收集会话
        trainingDataCollector.startSession(userCommand)
        
        _state.value = ExecutionEngineState.Analyzing
        
        // 步骤1: 识别意图
        val intentStartTime = System.currentTimeMillis()
        val intent = recognizeIntent(userCommand)
        if (intent == null) {
            _state.value = ExecutionEngineState.Failed("无法理解指令")
            onMessage("抱歉，我不太理解这个指令")
            return
        }
        
        LogManager.d(TAG, "🎯 识别意图: ${intent.type} - ${intent.description}")
        onMessage("识别到: ${intent.description}")
        
        // 🎓 记录意图识别数据
        trainingDataCollector.recordIntentRecognition(
            userCommand = userCommand,
            recognizedIntent = intent.type,
            intentDescription = intent.description,
            targetApp = intent.app,
            parameters = intent.parameters,
            confidence = 1.0f,
            isCorrect = true
        )
        
        // 步骤2: 规划任务
        val plan = planTask(intent, userCommand)
        if (plan.steps.isEmpty()) {
            _state.value = ExecutionEngineState.Failed("无法规划任务")
            onMessage("无法为此任务制定执行计划")
            return
        }
        
        LogManager.d(TAG, "📋 任务规划: ${plan.steps.size} 个步骤")
        onMessage("已规划 ${plan.steps.size} 个步骤")
        
        // 初始化任务上下文
        currentTask = TaskContext(
            command = userCommand,
            intent = intent,
            plan = plan,
            currentStepIndex = 0,
            retryCount = 0,
            failedSteps = mutableListOf(),
            executedSteps = mutableListOf()
        )
        
        // 步骤3: 执行任务
        _state.value = ExecutionEngineState.Executing(0, plan.steps.size, "开始执行...")
        
        var taskRetryCount = 0
        while (taskRetryCount <= MAX_TASK_RETRY) {
            val success = executeTaskPlan(onMessage)
            
            if (success) {
                _state.value = ExecutionEngineState.Completed("任务执行成功")
                onMessage("✅ 任务完成!")
                
                // 保存成功的执行记录
                saveSuccessfulExecution()
                
                // 🎓 结束训练数据收集会话
                trainingDataCollector.endSession(true, "任务成功完成")
                return
            }
            
            taskRetryCount++
            
            if (taskRetryCount <= MAX_TASK_RETRY) {
                onMessage("🔄 尝试重新规划任务 ($taskRetryCount/$MAX_TASK_RETRY)...")
                
                // 检查是否需要搜索学习
                if (shouldSearchForHelp()) {
                    onMessage("🔍 正在搜索相关资料...")
                    val newKnowledge = searchAndLearn(currentTask!!)
                    
                    if (newKnowledge != null) {
                        onMessage("📚 学习到新方法，重新尝试...")
                        applyLearnedKnowledge(newKnowledge)
                    }
                }
                
                // 重新规划
                val newPlan = replanFromBreakpoint()
                if (newPlan != null) {
                    currentTask = currentTask!!.copy(
                        plan = newPlan,
                        retryCount = taskRetryCount
                    )
                    onMessage("📋 已重新规划，继续执行...")
                } else {
                    break
                }
            }
        }
        
        val failureSummary = buildFailureSummary(currentTask)
        _state.value = ExecutionEngineState.Failed("多次尝试后仍然失败")
        onMessage("❌ 任务执行失败，已尝试 $taskRetryCount 次\n$failureSummary")
        
        // 🎓 结束训练数据收集会话（失败）
        trainingDataCollector.endSession(false, "任务失败，重试 $taskRetryCount 次，$failureSummary")
    }
    
    /**
     * 🎯 识别用户意图
     */
    private suspend fun recognizeIntent(command: String): UserIntent? {
        val normalizedCommand = normalizeCommandKey(command)
        synchronized(intentCache) {
            intentCache[normalizedCommand]
        }?.let { return it }

        val localIntent = recognizeIntentLocally(command)
        if (localIntent != null) {
            synchronized(intentCache) {
                intentCache[normalizedCommand] = localIntent
            }
            return localIntent
        }

        val llmIntent = recognizeIntentWithLLM(command)
        if (llmIntent != null) {
            synchronized(intentCache) {
                intentCache[normalizedCommand] = llmIntent
            }
        }

        return llmIntent
    }

    private fun recognizeIntentLocally(command: String): UserIntent? {
        val lowerCommand = command.lowercase()
        
        // 发消息意图
        if (lowerCommand.contains(Regex("发(送)?.*?(消息|信息|微信|qq)"))) {
            val appMatch = when {
                lowerCommand.contains("微信") -> "微信"
                lowerCommand.contains("qq") -> "QQ"
                lowerCommand.contains("钉钉") -> "钉钉"
                else -> "微信"
            }
            
            // 提取联系人和消息
            val contactMatch = Regex("(给|发给|找)(.+?)(发|说|消息)").find(command)
            val contact = contactMatch?.groupValues?.getOrNull(2)?.trim() ?: ""
            
            val messageMatch = Regex("(说|发|消息[：:])(.+)$").find(command)
            val message = messageMatch?.groupValues?.getOrNull(2)?.trim() ?: ""
            
            return UserIntent(
                type = IntentType.SEND_MESSAGE,
                description = "发送消息给 $contact",
                app = appMatch,
                parameters = mapOf(
                    "contact" to contact,
                    "message" to message
                )
            )
        }
        
        // 刷视频意图
        if (lowerCommand.contains(Regex("(刷|看|浏览).*(视频|抖音|快手|b站)"))) {
            val appMatch = when {
                lowerCommand.contains("抖音") -> "抖音"
                lowerCommand.contains("快手") -> "快手"
                lowerCommand.contains(Regex("b站|bilibili")) -> "B站"
                else -> "抖音"
            }
            
            val countMatch = Regex("(\\d+)\\s*(个|条)?").find(command)
            val count = countMatch?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 10
            
            return UserIntent(
                type = IntentType.WATCH_VIDEO,
                description = "在${appMatch}刷${count}个视频",
                app = appMatch,
                parameters = mapOf("count" to count.toString())
            )
        }
        
        val openApp = extractOpenAppName(command)
        if (openApp != null) {
            return UserIntent(
                type = IntentType.OPEN_APP,
                description = "打开${openApp}",
                app = openApp
            )
        }

        // 搜索意图
        if (lowerCommand.contains(Regex("(搜索|查|找|百度|谷歌)"))) {
            val keywordMatch = Regex("(搜索|查|找|百度|谷歌)(.+)").find(command)
            val keyword = keywordMatch?.groupValues?.getOrNull(2)?.trim() ?: command
            
            return UserIntent(
                type = IntentType.SEARCH,
                description = "搜索: $keyword",
                app = if (lowerCommand.contains("谷歌")) "谷歌" else "百度",
                parameters = mapOf("keyword" to keyword)
            )
        }
        
        // 购物意图
        if (lowerCommand.contains(Regex("(购物|买|淘宝|京东|拼多多|下单)"))) {
            val appMatch = when {
                lowerCommand.contains("淘宝") -> "淘宝"
                lowerCommand.contains("京东") -> "京东"
                lowerCommand.contains("拼多多") -> "拼多多"
                else -> "淘宝"
            }
            
            val productMatch = Regex("(买|搜索|找)(.+?)($|在)").find(command)
            val product = productMatch?.groupValues?.getOrNull(2)?.trim() ?: ""
            
            return UserIntent(
                type = IntentType.SHOPPING,
                description = "在${appMatch}搜索: $product",
                app = appMatch,
                parameters = mapOf("product" to product)
            )
        }
        
        return null
    }
    
    private fun extractOpenAppName(command: String): String? {
        val normalizedCommand = normalizeAppAlias(command)
        if (!(normalizedCommand.contains("打开") || normalizedCommand.contains("启动") || normalizedCommand.contains("运行"))) {
            return null
        }

        knownAppCatalog().forEach { (canonical, aliases, _) ->
            val matched = aliases.any { alias ->
                val normalizedAlias = normalizeAppAlias(alias)
                normalizedCommand.contains(normalizedAlias)
            }
            if (matched) {
                return canonical
            }
        }

        val capture = Regex("(?:打开|启动|运行)\\s*([^\\s，。,.！？!？]+)").find(command)
        val candidateRaw = capture?.groupValues?.getOrNull(1)?.trim().orEmpty()
        if (candidateRaw.isBlank()) {
            return null
        }

        val candidate = normalizeAppAlias(candidateRaw)
        if (candidate.isBlank()) {
            return null
        }

        knownAppCatalog().forEach { (canonical, aliases, _) ->
            val matched = aliases.any { alias ->
                val normalizedAlias = normalizeAppAlias(alias)
                candidate == normalizedAlias || candidate.contains(normalizedAlias) || normalizedAlias.contains(candidate)
            }
            if (matched) {
                return canonical
            }
        }

        val fallback = candidateRaw.replace(Regex("(应用|app)$", RegexOption.IGNORE_CASE), "").trim()
        return fallback.ifBlank { null }
    }

    private fun normalizeAppAlias(appName: String): String {
        return appName.trim()
            .lowercase()
            .replace(Regex("\\s+"), "")
            .removeSuffix("应用")
            .removeSuffix("app")
    }

    private fun knownAppCatalog(): List<Triple<String, List<String>, List<String>>> {
        return listOf(
            Triple("微信", listOf("微信", "wechat"), listOf("com.tencent.mm")),
            Triple("QQ", listOf("qq", "腾讯qq"), listOf("com.tencent.mobileqq")),
            Triple("支付宝", listOf("支付宝", "alipay"), listOf("com.eg.android.AlipayGphone")),
            Triple("淘宝", listOf("淘宝", "taobao"), listOf("com.taobao.taobao")),
            Triple("抖音", listOf("抖音", "douyin"), listOf("com.ss.android.ugc.aweme")),
            Triple("快手", listOf("快手", "kuaishou"), listOf("com.kuaishou.nebula", "com.smile.gifmaker")),
            Triple("B站", listOf("b站", "哔哩哔哩", "哔哩", "bilibili"), listOf("tv.danmaku.bili")),
            Triple("小红书", listOf("小红书", "xiaohongshu", "redbook"), listOf("com.xingin.xhs")),
            Triple("京东", listOf("京东", "jd", "jingdong"), listOf("com.jingdong.app.mall")),
            Triple("拼多多", listOf("拼多多", "pdd", "pinduoduo"), listOf("com.xunmeng.pinduoduo"))
        )
    }

    private suspend fun recognizeIntentWithLLM(command: String): UserIntent? {
        try {
            val prompt = """
分析以下用户指令，识别其意图。

用户指令: "$command"

请以 JSON 格式返回：
{
    "type": "SEND_MESSAGE|WATCH_VIDEO|SEARCH|SHOPPING|OPEN_APP|OTHER",
    "description": "意图描述",
    "app": "目标应用名称",
    "parameters": {
        "key": "value"
    }
}

只返回 JSON，不要其他内容。
""".trimIndent()
            
            val response = llmClient.chatCompletion(prompt)
            val jsonStr = response.trim()
                .removePrefix("```json")
                .removePrefix("```")
                .removeSuffix("```")
                .trim()
            
            val parsed = json.decodeFromString<LLMIntentResponse>(jsonStr)
            
            return UserIntent(
                type = IntentType.valueOf(parsed.type),
                description = parsed.description,
                app = parsed.app,
                parameters = parsed.parameters
            )
        } catch (e: Exception) {
            LogManager.e(TAG, "LLM 意图识别失败", e)
            return null
        }
    }
    
    /**
     * 📋 规划任务
     */
    private suspend fun planTask(intent: UserIntent, command: String): TaskPlan {
        val cacheKey = intent.type.name + "-" + intent.app + "-" + normalizeCommandKey(command)
        synchronized(planCache) {
            planCache[cacheKey]
        }?.let { return it }

        // 检查是否有已学习的解决方案
        val learnedSolution = learnedKnowledge[intent.type.name]
        if (learnedSolution != null) {
            LogManager.d(TAG, "📚 使用已学习的解决方案")
            val learnedPlan = learnedSolution.plan
            if (learnedPlan.steps.isNotEmpty()) {
                synchronized(planCache) {
                    planCache[cacheKey] = learnedPlan
                }
            }
            return learnedPlan
        }
        
        // 获取预定义步骤
        val taskDef = getTaskDefinition(intent)
        if (taskDef != null) {
            val predefinedPlan = TaskPlan(
                steps = taskDef.steps.mapIndexed { index, step ->
                    PlanStep(
                        id = step.stepId,
                        order = index,
                        description = step.description,
                        action = step.action.name,
                        target = step.targetElements.firstOrNull(),
                        parameters = step.parameters.toMutableMap().apply {
                            // 替换参数
                            intent.parameters.forEach { (key, value) ->
                                this[key] = value
                            }
                        }
                    )
                },
                intent = intent
            )
            synchronized(planCache) {
                planCache[cacheKey] = predefinedPlan
            }
            return predefinedPlan
        }
        
        // 使用 LLM 规划
        val llmPlan = planTaskWithLLM(intent, command)
        if (llmPlan.steps.isNotEmpty()) {
            synchronized(planCache) {
                planCache[cacheKey] = llmPlan
            }
        }
        return llmPlan
    }
    
    private fun getTaskDefinition(intent: UserIntent): TaskDefinition? {
        return when (intent.type) {
            IntentType.SEND_MESSAGE -> when (intent.app) {
                "微信" -> TaskStepDefinitions.WECHAT_SEND_MESSAGE
                "QQ" -> TaskStepDefinitions.QQ_SEND_MESSAGE
                else -> TaskStepDefinitions.WECHAT_SEND_MESSAGE
            }
            IntentType.WATCH_VIDEO -> when (intent.app) {
                "抖音" -> TaskStepDefinitions.DOUYIN_WATCH_VIDEO
                "快手" -> TaskStepDefinitions.KUAISHOU_WATCH_VIDEO
                "B站" -> TaskStepDefinitions.BILIBILI_WATCH_VIDEO
                else -> TaskStepDefinitions.DOUYIN_WATCH_VIDEO
            }
            IntentType.SEARCH -> when (intent.app) {
                "百度" -> TaskStepDefinitions.BAIDU_SEARCH
                else -> TaskStepDefinitions.BROWSER_SEARCH
            }
            IntentType.SHOPPING -> when (intent.app) {
                "淘宝" -> TaskStepDefinitions.TAOBAO_SHOPPING
                "京东" -> TaskStepDefinitions.JD_SHOPPING
                "拼多多" -> TaskStepDefinitions.PDD_SHOPPING
                else -> TaskStepDefinitions.TAOBAO_SHOPPING
            }
            IntentType.OPEN_APP -> TaskDefinition(
                taskName = "打开${intent.app}",
                appPackage = getPackageName(intent.app),
                steps = listOf(
                    TaskStep(
                        stepId = "launch_app",
                        description = "启动${intent.app}",
                        action = StepAction.LAUNCH_APP,
                        targetElements = listOf(intent.app)
                    )
                )
            )
            else -> null
        }
    }
    
    private suspend fun planTaskWithLLM(intent: UserIntent, command: String): TaskPlan {
        try {
            val prompt = """
为以下任务制定执行步骤：

用户指令: "$command"
意图类型: ${intent.type}
目标应用: ${intent.app}
参数: ${intent.parameters}
历史反思建议: ${buildReflectionSummary(intent)}

请以 JSON 格式返回执行步骤：
{
    "steps": [
        {
            "id": "step_1",
            "order": 0,
            "description": "步骤描述",
            "action": "LAUNCH_APP|CLICK|INPUT_TEXT|SWIPE_UP|WAIT|PRESS_BACK",
            "target": "目标元素文本",
            "parameters": {}
        }
    ]
}

只返回 JSON，不要其他内容。
""".trimIndent()
            
            val response = llmClient.chatCompletion(prompt)
            val jsonStr = response.trim()
                .removePrefix("```json")
                .removePrefix("```")
                .removeSuffix("```")
                .trim()
            
            val parsed = json.decodeFromString<LLMPlanResponse>(jsonStr)
            
            return TaskPlan(
                steps = parsed.steps,
                intent = intent
            )
        } catch (e: Exception) {
            LogManager.e(TAG, "LLM 任务规划失败", e)
            return TaskPlan(steps = emptyList(), intent = intent)
        }
    }
    
    /**
     * ▶️ 执行任务计划
     */
    private suspend fun executeTaskPlan(onMessage: (String) -> Unit): Boolean {
        val task = currentTask ?: return false
        val service = CoreAccessibilityService.instance
        val steps = task.plan.steps
        if (service == null) {
            val hasNonLaunchStep = steps.any { step ->
                val action = runCatching { StepAction.valueOf(step.action) }.getOrNull()
                action != StepAction.LAUNCH_APP
            }
            if (hasNonLaunchStep) {
                onMessage("❌ 无障碍服务未启动")
                return false
            }
        }

        var stepIndex = task.currentStepIndex
        
        while (stepIndex < steps.size) {
            if (_state.value == ExecutionEngineState.Cancelled) {
                return false
            }
            
            val originalStep = steps[stepIndex]
            val step = applyReflectionOptimization(originalStep, task.intent)
            _state.value = ExecutionEngineState.Executing(
                stepIndex + 1, steps.size,
                "步骤 ${stepIndex + 1}: ${step.description}"
            )
            
            onMessage("📌 ${step.description}")
            LogManager.d(TAG, "执行步骤 ${stepIndex + 1}/${steps.size}: ${step.description}")
            
            // 执行步骤
            val stepStartTime = System.currentTimeMillis()
            val result = executeStepWithRetry(step, service, onMessage)
            val stepDuration = (System.currentTimeMillis() - stepStartTime).coerceAtLeast(1L)
            val reflectionUpdate = runSelfReflectionLoop(task.intent, originalStep, step, result, stepDuration)
            if (!reflectionUpdate.isNullOrBlank()) {
                LogManager.d(TAG, "策略更新: $reflectionUpdate")
                onMessage("策略更新: $reflectionUpdate")
            }
            
            // 🎓 更新训练数据收集进度
            trainingDataCollector.updateSessionProgress(stepIndex + 1, steps.size)
            
            when (result) {
                is StepResult.Success -> {
                    task.executedSteps.add(ExecutedStep(step, true, result.message))
                    
                    // 🎓 记录执行结果
                    trainingDataCollector.recordExecutionResult(
                        action = step.action,
                        target = step.target,
                        success = true,
                        resultMessage = result.message,
                        executionTimeMs = stepDuration
                    )
                    
                    stepIndex++
                    currentTask = task.copy(currentStepIndex = stepIndex)
                }
                is StepResult.Failure -> {
                    task.failedSteps.add(FailedStep(step, result.reason, result.suggestion))
                    LogManager.e(TAG, "步骤失败 ${stepIndex + 1}/${steps.size}: ${step.description}, 原因: ${result.reason}, 建议: ${result.suggestion ?: "无"}")
                    
                    // 🎓 记录执行失败
                    trainingDataCollector.recordExecutionResult(
                        action = step.action,
                        target = step.target,
                        success = false,
                        resultMessage = result.reason,
                        executionTimeMs = stepDuration
                    )
                    
                    // 尝试自适应处理
                    val adapted = service?.let { tryAdaptToFailure(step, result, it, onMessage) } ?: false
                    if (adapted) {
                        stepIndex++
                        currentTask = task.copy(currentStepIndex = stepIndex)
                    } else {
                        currentTask = task.copy(currentStepIndex = stepIndex)
                        return false
                    }
                }
                is StepResult.Skip -> {
                    LogManager.d(TAG, "跳过步骤: ${step.description}")
                    stepIndex++
                    currentTask = task.copy(currentStepIndex = stepIndex)
                }
            }
            
            delay(300) // 步骤间隔
        }
        
        return true
    }
    
    /**
     * 🔄 带重试的步骤执行
     */
    private suspend fun executeStepWithRetry(
        step: PlanStep,
        service: CoreAccessibilityService?,
        onMessage: (String) -> Unit
    ): StepResult {
        var lastResult: StepResult = StepResult.Failure("未执行", null)
        
        for (retry in 0 until MAX_STEP_RETRY) {
            val timeoutMs = getStepTimeoutMs(step) + retry * RETRY_TIMEOUT_INCREMENT_MS
            val result = withTimeoutOrNull(timeoutMs) {
                executeStep(step, service)
            } ?: StepResult.Failure("步骤超时(${timeoutMs}ms): ${step.description}", "请确认页面已加载完成")
            
            when (result) {
                is StepResult.Success -> return result
                is StepResult.Skip -> return result
                is StepResult.Failure -> {
                    lastResult = result
                    
                    if (retry < MAX_STEP_RETRY - 1) {
                        LogManager.d(TAG, "🔄 步骤失败，重试 ${retry + 1}/$MAX_STEP_RETRY: [${step.action}] ${result.reason}")
                        onMessage("⚠️ ${result.reason}，正在第 ${retry + 1} 次重试...")
                        
                        // 分析失败原因，调整策略
                        val adjustment = service?.let { analyzeFailureAndAdjust(step, result, it) }
                        if (adjustment != null) {
                            LogManager.d(TAG, "💡 调整策略: $adjustment")
                            onMessage("💡 $adjustment")
                        }
                        
                        val retryDelay = (RETRY_BASE_DELAY_MS * (1L shl retry)).coerceAtMost(RETRY_MAX_DELAY_MS)
                        delay(retryDelay)
                    }
                }
            }
        }
        
        return lastResult
    }
    
    /**
     * ▶️ 执行单个步骤
     */
    private suspend fun executeStep(step: PlanStep, service: CoreAccessibilityService?): StepResult {
        try {
            val action = try {
                StepAction.valueOf(step.action)
            } catch (e: Exception) {
                return StepResult.Failure("未知动作: ${step.action}", null)
            }
            
            val requiredService = service
            return when (action) {
                StepAction.LAUNCH_APP -> executeLaunchApp(step)
                StepAction.CLICK -> requiredService?.let { executeClick(step, it) }
                    ?: StepResult.Failure("无障碍服务未启动", "请先开启无障碍服务")
                StepAction.CLICK_FUZZY -> requiredService?.let { executeClickFuzzy(step, it) }
                    ?: StepResult.Failure("无障碍服务未启动", "请先开启无障碍服务")
                StepAction.INPUT_TEXT -> requiredService?.let { executeInputText(step, it) }
                    ?: StepResult.Failure("无障碍服务未启动", "请先开启无障碍服务")
                StepAction.WAIT -> executeWait(step)
                StepAction.SWIPE_UP -> requiredService?.let { executeSwipe(it, true) }
                    ?: StepResult.Failure("无障碍服务未启动", "请先开启无障碍服务")
                StepAction.SWIPE_DOWN -> requiredService?.let { executeSwipe(it, false) }
                    ?: StepResult.Failure("无障碍服务未启动", "请先开启无障碍服务")
                StepAction.PRESS_BACK -> requiredService?.let { executePressBack(it) }
                    ?: StepResult.Failure("无障碍服务未启动", "请先开启无障碍服务")
                StepAction.PRESS_ENTER -> requiredService?.let { executePressEnter(it) }
                    ?: StepResult.Failure("无障碍服务未启动", "请先开启无障碍服务")
                StepAction.ENSURE_HOME -> requiredService?.let { executeEnsureHome(step, it) }
                    ?: StepResult.Failure("无障碍服务未启动", "请先开启无障碍服务")
                StepAction.CLOSE_POPUP -> requiredService?.let { executeClosePopup(it) }
                    ?: StepResult.Failure("无障碍服务未启动", "请先开启无障碍服务")
                StepAction.LOOP -> StepResult.Success("循环步骤")
                StepAction.CONDITIONAL -> StepResult.Success("条件步骤")
                else -> requiredService?.let { executeGenericAction(step, it) }
                    ?: StepResult.Failure("无障碍服务未启动", "请先开启无障碍服务")
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "步骤执行异常", e)
            return StepResult.Failure("执行异常(${step.action}): ${e.message}", step.description)
        }
    }
    
    private suspend fun executeLaunchApp(step: PlanStep): StepResult {
        val appName = step.target?.takeIf { it.isNotBlank() }
            ?: currentTask?.intent?.app
            ?: return StepResult.Failure("无任务上下文", null)
        val packageCandidates = buildLaunchPackageCandidates(appName)
        packageCandidates.forEach { packageName ->
            val launchIntent = runCatching { context.packageManager.getLaunchIntentForPackage(packageName) }.getOrNull()
            if (launchIntent != null) {
                return startLaunchIntent(launchIntent)
            }
        }

        val launchIntent = findLaunchIntentByKeywords(buildLaunchKeywords(appName))
        if (launchIntent != null) {
            return startLaunchIntent(launchIntent)
        }

        return StepResult.Failure("找不到应用: $appName", "请确保应用已安装")
        
    }
    
    private suspend fun startLaunchIntent(launchIntent: Intent): StepResult {
        return try {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            delay(2200)
            StepResult.Success("已启动应用")
        } catch (e: Exception) {
            StepResult.Failure("启动失败: ${e.message}", "请检查应用状态")
        }
    }

    private fun buildLaunchPackageCandidates(appName: String): List<String> {
        val candidates = LinkedHashSet<String>()
        val normalizedAppName = normalizeAppAlias(appName)

        if (appName.contains(".")) {
            candidates.add(appName.trim())
        }

        val mappedPackage = getPackageName(appName)
        if (mappedPackage.contains(".")) {
            candidates.add(mappedPackage)
        }

        knownAppCatalog().forEach { (_, aliases, packages) ->
            if (aliases.any { alias ->
                    val normalizedAlias = normalizeAppAlias(alias)
                    normalizedAppName == normalizedAlias || normalizedAppName.contains(normalizedAlias)
                }) {
                candidates.addAll(packages)
            }
        }

        return candidates.toList()
    }

    private fun buildLaunchKeywords(appName: String): List<String> {
        val keywords = LinkedHashSet<String>()
        val normalizedAppName = normalizeAppAlias(appName)
        if (appName.isNotBlank()) {
            keywords.add(appName.trim())
        }

        knownAppCatalog().forEach { (canonical, aliases, packages) ->
            val matched = aliases.any { alias ->
                val normalizedAlias = normalizeAppAlias(alias)
                normalizedAppName == normalizedAlias || normalizedAppName.contains(normalizedAlias)
            } || normalizeAppAlias(canonical) == normalizedAppName
            if (matched) {
                keywords.add(canonical)
                keywords.addAll(aliases)
                keywords.addAll(packages)
            }
        }

        return keywords.filter { it.isNotBlank() }
    }

    private fun findLaunchIntentByKeywords(keywords: List<String>): Intent? {
        if (keywords.isEmpty()) {
            return null
        }

        val launcherIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val activities = context.packageManager.queryIntentActivities(launcherIntent, 0)
        val matchedActivity = activities.firstOrNull { info ->
            val label = info.loadLabel(context.packageManager)?.toString().orEmpty()
            val packageName = info.activityInfo?.packageName.orEmpty()
            keywords.any { keyword ->
                keyword.isNotBlank() && (
                    label.contains(keyword, ignoreCase = true) ||
                        packageName.contains(keyword, ignoreCase = true)
                )
            }
        } ?: return null

        return Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            setClassName(matchedActivity.activityInfo.packageName, matchedActivity.activityInfo.name)
        }
    }

    private suspend fun executeClick(step: PlanStep, service: CoreAccessibilityService): StepResult {
        val target = step.target ?: return StepResult.Failure("未指定点击目标", null)
        val rootNode = service.rootInActiveWindow ?: return StepResult.Failure("无法获取界面", null)
        
        // 替换参数
        val resolvedTarget = resolveParameter(target)
        
        val node = findNodeByText(rootNode, resolvedTarget)
        if (node != null) {
            if (clickNode(node)) {
                delay(step.parameters["waitAfter"]?.toLongOrNull() ?: 500)
                return StepResult.Success("已点击: $resolvedTarget")
            }
        }
        
        return StepResult.Failure("未找到元素: $resolvedTarget", "尝试其他方式定位")
    }
    
    private suspend fun executeClickFuzzy(step: PlanStep, service: CoreAccessibilityService): StepResult {
        val target = step.target ?: return StepResult.Failure("未指定点击目标", null)
        val rootNode = service.rootInActiveWindow ?: return StepResult.Failure("无法获取界面", null)
        
        val resolvedTarget = resolveParameter(target)
        val node = findNodeFuzzy(rootNode, resolvedTarget)
        
        if (node != null && clickNode(node)) {
            delay(500)
            return StepResult.Success("已模糊点击: $resolvedTarget")
        }
        
        return StepResult.Failure("模糊匹配失败: $resolvedTarget", null)
    }
    
    private suspend fun executeInputText(step: PlanStep, service: CoreAccessibilityService): StepResult {
        val text = step.parameters["text"] ?: step.target ?: return StepResult.Failure("无输入内容", null)
        val resolvedText = resolveParameter(text)
        val rootNode = service.rootInActiveWindow ?: return StepResult.Failure("无法获取界面", null)
        
        val editNode = findEditableNode(rootNode)
        if (editNode != null) {
            val bundle = android.os.Bundle()
            bundle.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, resolvedText)
            editNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, bundle)
            delay(300)
            return StepResult.Success("已输入: $resolvedText")
        }
        
        return StepResult.Failure("未找到输入框", "尝试点击输入区域")
    }
    
    private suspend fun executeWait(step: PlanStep): StepResult {
        val duration = step.parameters["duration"]?.toLongOrNull() ?: 1000
        delay(duration)
        return StepResult.Success("等待 ${duration}ms")
    }
    
    private suspend fun executeSwipe(service: CoreAccessibilityService, up: Boolean): StepResult {
        val startY = if (up) 1500f else 500f
        val endY = if (up) 500f else 1500f
        
        val gesture = android.accessibilityservice.GestureDescription.Builder()
            .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(
                android.graphics.Path().apply {
                    moveTo(540f, startY)
                    lineTo(540f, endY)
                },
                0, 300
            ))
            .build()
        
        service.dispatchGesture(gesture, null, null)
        delay(500)
        return StepResult.Success(if (up) "上滑" else "下滑")
    }
    
    private suspend fun executePressBack(service: CoreAccessibilityService): StepResult {
        service.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
        delay(300)
        return StepResult.Success("返回")
    }
    
    private suspend fun executePressEnter(service: CoreAccessibilityService): StepResult {
        delay(100)
        return StepResult.Success("回车")
    }
    
    private suspend fun executeEnsureHome(step: PlanStep, service: CoreAccessibilityService): StepResult {
        for (i in 1..3) {
            val rootNode = service.rootInActiveWindow ?: continue
            
            // 检查是否在主界面
            val hasMainElements = step.parameters["expectedElements"]?.split(",")?.any { elem ->
                findNodeByText(rootNode, elem.trim()) != null
            } ?: true
            
            if (hasMainElements) {
                return StepResult.Success("已在主界面")
            }
            
            executePressBack(service)
            delay(500)
        }
        
        return StepResult.Success("已尝试返回主界面")
    }
    
    private suspend fun executeClosePopup(service: CoreAccessibilityService): StepResult {
        val rootNode = service.rootInActiveWindow ?: return StepResult.Skip
        val closeKeywords = listOf("关闭", "×", "跳过", "我知道了", "取消")
        
        for (keyword in closeKeywords) {
            val node = findNodeByText(rootNode, keyword)
            if (node != null && node.isClickable) {
                clickNode(node)
                delay(300)
                return StepResult.Success("已关闭弹窗")
            }
        }
        
        return StepResult.Skip
    }
    
    private suspend fun executeGenericAction(step: PlanStep, service: CoreAccessibilityService): StepResult {
        LogManager.d(TAG, "执行通用动作: ${step.action}")
        delay(500)
        return StepResult.Success("已执行: ${step.action}")
    }
    
    /**
     * 🧠 分析失败原因并调整
     */
    private suspend fun analyzeFailureAndAdjust(
        step: PlanStep,
        failure: StepResult.Failure,
        service: CoreAccessibilityService
    ): String? {
        val rootNode = service.rootInActiveWindow ?: return null
        
        // 分析当前界面
        val screenInfo = analyzeCurrentScreen(rootNode)
        
        // 检查是否有弹窗
        if (screenInfo.hasPopup) {
            executeClosePopup(service)
            return "检测到弹窗，已尝试关闭"
        }
        
        // 检查是否需要滚动
        if (step.target != null && !screenInfo.visibleTexts.any { it.contains(step.target, ignoreCase = true) }) {
            executeSwipe(service, true)
            return "目标可能在屏幕外，已尝试滚动"
        }
        
        // 检查是否在错误的界面
        if (screenInfo.currentApp != getPackageName(currentTask?.intent?.app ?: "")) {
            executeLaunchApp(step)
            return "检测到应用切换，已重新打开目标应用"
        }
        
        return null
    }
    
    /**
     * 🔄 尝试自适应处理失败
     */
    private suspend fun tryAdaptToFailure(
        step: PlanStep,
        failure: StepResult.Failure,
        service: CoreAccessibilityService,
        onMessage: (String) -> Unit
    ): Boolean {
        LogManager.d(TAG, "🔄 尝试自适应处理: ${failure.reason}")
        
        // 使用 LLM 分析并建议解决方案
        val suggestion = getSuggestionFromLLM(step, failure, service)
        
        if (suggestion != null) {
            onMessage("💡 尝试: ${suggestion.description}")
            
            when (suggestion.action) {
                "scroll_and_retry" -> {
                    executeSwipe(service, true)
                    delay(500)
                    val result = executeStep(step, service)
                    return result is StepResult.Success
                }
                "try_alternative_target" -> {
                    if (suggestion.alternativeTarget != null) {
                        val newStep = step.copy(target = suggestion.alternativeTarget)
                        val result = executeStep(newStep, service)
                        return result is StepResult.Success
                    }
                }
                "wait_and_retry" -> {
                    delay(2000)
                    val result = executeStep(step, service)
                    return result is StepResult.Success
                }
                "skip" -> {
                    return true // 跳过此步骤
                }
            }
        }
        
        return false
    }
    
    private suspend fun getSuggestionFromLLM(
        step: PlanStep,
        failure: StepResult.Failure,
        service: CoreAccessibilityService
    ): AdaptiveSuggestion? {
        try {
            val rootNode = service.rootInActiveWindow
            val screenInfo = if (rootNode != null) analyzeCurrentScreen(rootNode) else null
            
            val prompt = """
步骤执行失败，请分析并建议解决方案：

失败步骤: ${step.description}
动作: ${step.action}
目标: ${step.target}
失败原因: ${failure.reason}

当前界面信息:
- 可见文本: ${screenInfo?.visibleTexts?.take(10)?.joinToString(", ") ?: "未知"}
- 可点击元素: ${screenInfo?.clickableElements?.take(5)?.joinToString(", ") ?: "未知"}
- 历史反思策略: ${getStepOptimizationHint(currentTask?.intent, step)}

请以 JSON 格式返回建议：
{
    "action": "scroll_and_retry|try_alternative_target|wait_and_retry|skip",
    "description": "建议描述",
    "alternativeTarget": "替代目标文本（如果适用）"
}

只返回 JSON，不要其他内容。
""".trimIndent()
            
            val response = llmClient.chatCompletion(prompt)
            val jsonStr = response.trim()
                .removePrefix("```json")
                .removePrefix("```")
                .removeSuffix("```")
                .trim()
            
            return json.decodeFromString<AdaptiveSuggestion>(jsonStr)
        } catch (e: Exception) {
            LogManager.e(TAG, "获取 LLM 建议失败", e)
            return null
        }
    }
    
    /**
     * 🔍 搜索资料学习
     */
    private fun shouldSearchForHelp(): Boolean {
        val task = currentTask ?: return false
        return task.failedSteps.size >= SEARCH_LEARNING_THRESHOLD
    }
    
    private suspend fun searchAndLearn(task: TaskContext): LearnedSolution? {
        try {
            // 构建搜索查询
            val failureDescriptions = task.failedSteps.map { "${it.step.description}: ${it.reason}" }
            val searchQuery = "Android 自动化 ${task.intent.app} ${task.intent.type.name} ${failureDescriptions.firstOrNull() ?: ""}"
            
            LogManager.d(TAG, "🔍 搜索: $searchQuery")
            
            // 打开浏览器搜索
            val encodedQuery = Uri.encode(searchQuery)
            val searchUrl = "https://www.baidu.com/s?wd=$encodedQuery"
            
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(searchUrl))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            
            delay(5000) // 等待页面加载
            
            // 使用 LLM 分析搜索结果并生成解决方案
            val solution = analyzSearchResultsWithLLM(task)
            
            if (solution != null) {
                learnedKnowledge[task.intent.type.name] = solution
                LogManager.d(TAG, "📚 已学习新解决方案")
            }
            
            // 返回目标应用
            delay(2000)
            executeLaunchApp(PlanStep("return", 0, "返回应用", "LAUNCH_APP", null, emptyMap()))
            
            return solution
        } catch (e: Exception) {
            LogManager.e(TAG, "搜索学习失败", e)
            return null
        }
    }
    
    private suspend fun analyzSearchResultsWithLLM(task: TaskContext): LearnedSolution? {
        try {
            val prompt = """
基于以下任务失败信息，生成一个改进的执行方案：

任务: ${task.intent.description}
应用: ${task.intent.app}
失败步骤:
${task.failedSteps.joinToString("\n") { "- ${it.step.description}: ${it.reason}" }}

请生成一个更可靠的执行步骤列表，考虑：
1. 使用更通用的元素定位方式
2. 添加必要的等待时间
3. 处理可能的弹窗
4. 添加备用方案

返回 JSON 格式：
{
    "steps": [
        {"id": "1", "order": 0, "description": "描述", "action": "动作", "target": "目标", "parameters": {}}
    ],
    "tips": "执行建议"
}
""".trimIndent()
            
            val response = llmClient.chatCompletion(prompt)
            val jsonStr = response.trim()
                .removePrefix("```json")
                .removePrefix("```")
                .removeSuffix("```")
                .trim()
            
            val parsed = json.decodeFromString<LLMLearnedSolution>(jsonStr)
            
            return LearnedSolution(
                intentType = task.intent.type.name,
                plan = TaskPlan(steps = parsed.steps, intent = task.intent),
                tips = parsed.tips
            )
        } catch (e: Exception) {
            LogManager.e(TAG, "分析搜索结果失败", e)
            return null
        }
    }
    
    private fun applyLearnedKnowledge(solution: LearnedSolution) {
        val task = currentTask ?: return
        currentTask = task.copy(plan = solution.plan)
        LogManager.d(TAG, "📚 已应用学习到的知识")
    }
    
    /**
     * 🔄 从断点重新规划
     */
    private suspend fun replanFromBreakpoint(): TaskPlan? {
        val task = currentTask ?: return null
        
        try {
            val prompt = """
任务执行在第 ${task.currentStepIndex + 1} 步失败，请重新规划剩余步骤：

原始任务: ${task.command}
意图: ${task.intent.description}
已执行步骤: ${task.executedSteps.map { it.step.description }}
失败步骤: ${task.failedSteps.map { "${it.step.description}: ${it.reason}" }}
历史反思建议: ${buildReflectionSummary(task.intent)}

请生成从当前位置继续执行的步骤，返回 JSON：
{
    "steps": [{"id": "1", "order": 0, "description": "描述", "action": "动作", "target": "目标", "parameters": {}}]
}
""".trimIndent()
            
            val response = llmClient.chatCompletion(prompt)
            val jsonStr = response.trim()
                .removePrefix("```json")
                .removePrefix("```")
                .removeSuffix("```")
                .trim()
            
            val parsed = json.decodeFromString<LLMPlanResponse>(jsonStr)
            
            return TaskPlan(steps = parsed.steps, intent = task.intent)
        } catch (e: Exception) {
            LogManager.e(TAG, "重新规划失败", e)
            return null
        }
    }
    
    /**
     * 💾 保存成功的执行记录
     */
    private fun saveSuccessfulExecution() {
        val task = currentTask ?: return
        
        executionHistory.add(ExecutionRecord(
            command = task.command,
            intent = task.intent,
            steps = task.executedSteps.map { it.step },
            success = true,
            timestamp = System.currentTimeMillis()
        ))
        
        LogManager.d(TAG, "💾 已保存执行记录")
    }
    
    // ==================== 辅助方法 ====================
    
    private fun getPackageName(appName: String): String {
        val normalizedName = normalizeAppAlias(appName)
        knownAppCatalog().forEach { (_, aliases, packages) ->
            val matched = aliases.any { alias ->
                val normalizedAlias = normalizeAppAlias(alias)
                normalizedName == normalizedAlias || normalizedName.contains(normalizedAlias)
            }
            if (matched) {
                return packages.firstOrNull() ?: appName
            }
        }
        return appName
    }

    private fun normalizeCommandKey(command: String): String {
        return command.trim().lowercase().replace(Regex("\\s+"), "")
    }

    private fun getStepTimeoutMs(step: PlanStep): Long {
        return when (step.action.uppercase()) {
            "LAUNCH_APP" -> STEP_TIMEOUT_LAUNCH_APP_MS
            "WAIT" -> STEP_TIMEOUT_WAIT_MS
            "INPUT_TEXT" -> STEP_TIMEOUT_INPUT_TEXT_MS
            else -> STEP_TIMEOUT_MS
        }
    }

    private fun applyReflectionOptimization(step: PlanStep, intent: UserIntent): PlanStep {
        val key = buildReflectionKey(intent, step)
        val optimization = synchronized(reflectionLock) { stepOptimizations[key] } ?: return step

        var action = step.action
        var changed = false
        if (!optimization.preferredAction.isNullOrBlank() && !optimization.preferredAction.equals(step.action, ignoreCase = true)) {
            action = optimization.preferredAction
            changed = true
        }

        val parameters = step.parameters.toMutableMap()
        if (optimization.waitAfterMs > 0) {
            val existingWait = parameters["waitAfter"]?.toLongOrNull() ?: 0L
            if (optimization.waitAfterMs > existingWait) {
                parameters["waitAfter"] = optimization.waitAfterMs.toString()
                changed = true
            }
        }
        optimization.paramHints.forEach { (key, value) ->
            if (value.isNotBlank() && parameters[key] != value) {
                parameters[key] = value
                changed = true
            }
        }

        return if (changed) step.copy(action = action, parameters = parameters) else step
    }

    private fun runSelfReflectionLoop(
        intent: UserIntent,
        originalStep: PlanStep,
        executedStep: PlanStep,
        result: StepResult,
        durationMs: Long
    ): String? {
        val key = buildReflectionKey(intent, originalStep)
        val reflection = StepReflection(
            key = key,
            intentType = intent.type.name,
            app = intent.app,
            action = executedStep.action,
            target = executedStep.target,
            parameters = executedStep.parameters,
            success = result is StepResult.Success || result is StepResult.Skip,
            reason = if (result is StepResult.Failure) result.reason else null,
            durationMs = durationMs,
            timestamp = System.currentTimeMillis()
        )

        var updateMessage: String? = null
        var shouldPersist = false
        synchronized(reflectionLock) {
            reflectionHistory.add(reflection)
            while (reflectionHistory.size > REFLECTION_HISTORY_MAX_SIZE) {
                reflectionHistory.removeAt(0)
            }

            val reflections = reflectionHistory.asReversed()
                .asSequence()
                .filter { it.key == key }
                .take(REFLECTION_WINDOW_SIZE)
                .toList()
                .asReversed()

            val current = stepOptimizations[key]
            val updated = buildOptimizationFromReflections(originalStep, reflections, current)
            if (updated != null) {
                stepOptimizations[key] = updated
                shouldPersist = true
                val changes = mutableListOf<String>()
                if (!updated.preferredAction.isNullOrBlank() && !updated.preferredAction.equals(originalStep.action, ignoreCase = true)) {
                    changes.add("动作=${updated.preferredAction}")
                }
                if (updated.waitAfterMs > 0) {
                    changes.add("waitAfter=${updated.waitAfterMs}ms")
                }
                if (updated.paramHints.isNotEmpty()) {
                    val hintText = updated.paramHints.entries
                        .sortedBy { it.key }
                        .joinToString(",") { "${it.key}=${it.value}" }
                    changes.add("params={$hintText}")
                }
                updateMessage = if (changes.isEmpty()) {
                    "已更新策略"
                } else {
                    "${originalStep.description} -> ${changes.joinToString("，")}"
                }
            }
        }

        if (shouldPersist) {
            persistReflectionOptimizations()
        }

        return updateMessage
    }

    private fun buildOptimizationFromReflections(
        step: PlanStep,
        reflections: List<StepReflection>,
        current: StepOptimization?
    ): StepOptimization? {
        val failureReflections = reflections.filter { !it.success }
        if (failureReflections.size < REFLECTION_FAILURE_THRESHOLD) {
            return null
        }

        val reasons = failureReflections.mapNotNull { it.reason }
        var preferredAction = current?.preferredAction
        var waitAfterMs = current?.waitAfterMs ?: 0L
        var paramHints = current?.paramHints ?: emptyMap()
        var changed = false

        if (step.action.equals("CLICK", ignoreCase = true) && reasons.any { it.contains("未找到元素") || it.contains("模糊匹配失败") }) {
            if (!preferredAction.equals("CLICK_FUZZY", ignoreCase = true)) {
                preferredAction = "CLICK_FUZZY"
                changed = true
            }
        }

        if (reasons.any { it.contains("超时") || it.contains("加载") || it.contains("等待") }) {
            val newWait = (waitAfterMs + REFLECTION_WAIT_INCREMENT_MS).coerceAtMost(REFLECTION_MAX_WAIT_MS)
            if (newWait != waitAfterMs) {
                waitAfterMs = newWait
                changed = true
            }
        }

        val updatedParamHints = buildParamHintsFromReflections(step, failureReflections, paramHints)
        if (updatedParamHints != paramHints) {
            paramHints = updatedParamHints
            changed = true
        }

        if (!changed) {
            return null
        }

        val averageDurationMs = reflections.map { it.durationMs }.average().toLong().coerceAtLeast(1L)
        return StepOptimization(
            preferredAction = preferredAction,
            waitAfterMs = waitAfterMs,
            confidence = (current?.confidence ?: 0) + 1,
            averageDurationMs = averageDurationMs,
            updatedAt = System.currentTimeMillis(),
            paramHints = paramHints
        )
    }

    private fun buildParamHintsFromReflections(
        step: PlanStep,
        failureReflections: List<StepReflection>,
        currentHints: Map<String, String>
    ): Map<String, String> {
        if (failureReflections.size < REFLECTION_FAILURE_THRESHOLD) {
            return currentHints
        }

        val action = step.action.trim().uppercase()
        val hints = currentHints.toMutableMap()

        when (action) {
            "SWIPE", "SCROLL", "SWIPE_UP", "SWIPE_DOWN" -> {
                val baseDistance = resolveBaseRuntimeLong(
                    step = step,
                    failureReflections = failureReflections,
                    hints = hints,
                    keys = listOf("distance", "dist")
                )
                if (baseDistance != null) {
                    val currentDistance = hints["distance"]?.toLongOrNull() ?: baseDistance
                    val increasedDistance = (currentDistance + REFLECTION_PARAM_SWIPE_DISTANCE_INCREMENT)
                        .coerceAtMost(REFLECTION_PARAM_SWIPE_DISTANCE_MAX)
                    if (increasedDistance > currentDistance) {
                        hints["distance"] = increasedDistance.toString()
                    }
                }
            }
            "WAIT", "DELAY" -> {
                val timeoutFailure = failureReflections.any {
                    val reason = it.reason.orEmpty()
                    reason.contains("超时") || reason.contains("等待") || reason.contains("未找到")
                }
                if (timeoutFailure) {
                    val baseWait = resolveBaseRuntimeLong(
                        step = step,
                        failureReflections = failureReflections,
                        hints = hints,
                        keys = listOf("time", "wait_ms", "duration")
                    ) ?: 800L
                    val currentWait = hints["time"]?.toLongOrNull() ?: baseWait
                    val increasedWait = (currentWait + REFLECTION_PARAM_WAIT_INCREMENT_MS)
                        .coerceAtMost(REFLECTION_PARAM_WAIT_MAX_MS)
                    if (increasedWait > currentWait) {
                        hints["time"] = increasedWait.toString()
                    }
                }
            }
            "WAIT_FOR_TEXT", "WAIT_TEXT", "WAIT_TEXT_APPEAR" -> {
                val timeoutFailure = failureReflections.any {
                    val reason = it.reason.orEmpty()
                    reason.contains("超时") || reason.contains("等待") || reason.contains("未找到")
                }
                if (timeoutFailure) {
                    val baseTimeout = resolveBaseRuntimeLong(
                        step = step,
                        failureReflections = failureReflections,
                        hints = hints,
                        keys = listOf("timeout_ms", "time", "wait_ms", "duration")
                    ) ?: 5000L
                    val currentTimeout = hints["timeout_ms"]?.toLongOrNull() ?: baseTimeout
                    val increasedTimeout = (currentTimeout + REFLECTION_PARAM_WAIT_FOR_TEXT_INCREMENT_MS)
                        .coerceAtMost(REFLECTION_PARAM_WAIT_FOR_TEXT_MAX_MS)
                    if (increasedTimeout > currentTimeout) {
                        hints["timeout_ms"] = increasedTimeout.toString()
                    }
                }
            }
        }

        return hints
    }

    private fun resolveBaseRuntimeLong(
        step: PlanStep,
        failureReflections: List<StepReflection>,
        hints: Map<String, String>,
        keys: List<String>
    ): Long? {
        val hintValue = keys.asSequence().mapNotNull { hints[it]?.toLongOrNull() }.firstOrNull()
        if (hintValue != null) {
            return hintValue
        }

        val latestFailureValue = getLatestFailureParamValue(failureReflections, keys)
        if (latestFailureValue != null) {
            return latestFailureValue
        }

        val stepValue = keys.asSequence().mapNotNull { step.parameters[it]?.toLongOrNull() }.firstOrNull()
        if (stepValue != null) {
            return stepValue
        }

        return keys.asSequence().mapNotNull { parseParamValue(step.target, it) }.firstOrNull()
    }

    private fun getLatestFailureParamValue(
        failureReflections: List<StepReflection>,
        keys: List<String>
    ): Long? {
        failureReflections.asReversed().forEach { reflection ->
            val fromParams = keys.asSequence().mapNotNull { reflection.parameters[it]?.toLongOrNull() }.firstOrNull()
            if (fromParams != null) {
                return fromParams
            }
            val fromTarget = keys.asSequence().mapNotNull { parseParamValue(reflection.target, it) }.firstOrNull()
            if (fromTarget != null) {
                return fromTarget
            }
        }
        return null
    }

    private fun parseParamValue(target: String?, key: String): Long? {
        target ?: return null
        val regex = Regex("(?:^|[|,;\\s])$key\\s*[=:]\\s*(\\d+)")
        return regex.find(target)?.groupValues?.getOrNull(1)?.toLongOrNull()
    }

    private fun buildReflectionKey(intent: UserIntent, step: PlanStep): String {
        val app = intent.app.trim().lowercase().replace("|", " ")
        val action = step.action.trim().uppercase().replace("|", " ")
        val target = step.target?.trim()?.lowercase()?.replace("|", " ") ?: "_"
        return "${intent.type.name}|$app|$action|$target"
    }

    private fun buildReflectionSummary(intent: UserIntent): String {
        val app = intent.app.trim().lowercase().replace("|", " ")
        val prefix = "${intent.type.name}|$app|"
        val summaries = synchronized(reflectionLock) {
            stepOptimizations.entries
                .asSequence()
                .filter { it.key.startsWith(prefix) }
                .sortedByDescending { it.value.confidence }
                .take(3)
                .map { entry ->
                    val keyParts = entry.key.split('|', limit = 4)
                    val action = keyParts.getOrNull(2) ?: "UNKNOWN"
                    val target = keyParts.getOrNull(3)?.takeIf { it.isNotBlank() && it != "_" } ?: "任意目标"
                    val info = mutableListOf<String>()
                    entry.value.preferredAction?.let { info.add("动作=$it") }
                    if (entry.value.waitAfterMs > 0) {
                        info.add("waitAfter=${entry.value.waitAfterMs}ms")
                    }
                    if (entry.value.paramHints.isNotEmpty()) {
                        val hintText = entry.value.paramHints.entries
                            .sortedBy { it.key }
                            .joinToString(",") { "${it.key}=${it.value}" }
                        info.add("params={$hintText}")
                    }
                    if (info.isEmpty()) {
                        "[$action/$target] 保持原策略"
                    } else {
                        "[$action/$target] ${info.joinToString(",")}"
                    }
                }
                .toList()
        }
        return if (summaries.isEmpty()) "暂无" else summaries.joinToString("；")
    }

    private fun getStepOptimizationHint(intent: UserIntent?, step: PlanStep): String {
        intent ?: return "暂无"
        val key = buildReflectionKey(intent, step)
        val optimization = synchronized(reflectionLock) { stepOptimizations[key] } ?: return "暂无"
        val parts = mutableListOf<String>()
        optimization.preferredAction?.let { parts.add("动作=$it") }
        if (optimization.waitAfterMs > 0) {
            parts.add("waitAfter=${optimization.waitAfterMs}ms")
        }
        if (optimization.paramHints.isNotEmpty()) {
            val hintText = optimization.paramHints.entries
                .sortedBy { it.key }
                .joinToString(",") { "${it.key}=${it.value}" }
            parts.add("params={$hintText}")
        }
        return if (parts.isEmpty()) "暂无" else parts.joinToString(",")
    }

    fun getRuntimeReflectionSummary(scope: String): String {
        return buildReflectionSummary(buildRuntimeIntent(scope))
    }

    fun getRuntimeOptimizationAdvice(
        scope: String,
        action: String,
        target: String? = null
    ): RuntimeOptimizationAdvice {
        val normalizedAction = action.trim().uppercase().ifBlank { "WAIT" }
        val normalizedTarget = target?.trim()?.takeIf { it.isNotEmpty() }
        val intent = buildRuntimeIntent(scope)
        val step = PlanStep(
            id = "runtime_$normalizedAction",
            order = 0,
            description = "运行时动作",
            action = normalizedAction,
            target = normalizedTarget,
            parameters = emptyMap()
        )
        val optimizedStep = applyReflectionOptimization(step, intent)
        val key = buildReflectionKey(intent, step)
        val optimization = synchronized(reflectionLock) { stepOptimizations[key] }
        val suggestedAction = optimizedStep.action.uppercase().let {
            if (it == "CLICK_FUZZY" && normalizedAction == "CLICK") "CLICK" else it
        }
        val paramAdjustments = optimization?.paramHints.orEmpty() + optimizedStep.parameters
            .filterKeys { it != "waitAfter" }
        return RuntimeOptimizationAdvice(
            originalAction = normalizedAction,
            suggestedAction = suggestedAction,
            waitAfterMs = optimizedStep.parameters["waitAfter"]?.toLongOrNull() ?: optimization?.waitAfterMs ?: 0L,
            confidence = optimization?.confidence ?: 0,
            paramAdjustments = paramAdjustments
        )
    }

    fun recordRuntimeReflection(
        scope: String,
        action: String,
        target: String? = null,
        success: Boolean,
        reason: String? = null,
        durationMs: Long = 1L,
        parameters: Map<String, String> = emptyMap()
    ): String? {
        val normalizedAction = action.trim().uppercase().ifBlank { "WAIT" }
        val normalizedTarget = target?.trim()?.takeIf { it.isNotEmpty() }
        val normalizedParams = parameters
            .mapKeys { it.key.trim() }
            .mapValues { it.value.trim() }
            .filter { (key, value) -> key.isNotEmpty() && value.isNotEmpty() }
        val intent = buildRuntimeIntent(scope)
        val step = PlanStep(
            id = "runtime_${System.currentTimeMillis()}",
            order = 0,
            description = "运行时反思",
            action = normalizedAction,
            target = normalizedTarget,
            parameters = normalizedParams
        )
        val result = if (success) {
            StepResult.Success("成功")
        } else {
            StepResult.Failure(reason ?: "失败", null)
        }
        return runSelfReflectionLoop(intent, step, step, result, durationMs.coerceAtLeast(1L))
    }

    private fun buildRuntimeIntent(scope: String): UserIntent {
        val normalizedScope = normalizeRuntimeScope(scope)
        val runtimeApp = "runtime:$normalizedScope"
        return UserIntent(
            type = IntentType.OTHER,
            description = runtimeApp,
            app = runtimeApp
        )
    }

    private fun normalizeRuntimeScope(scope: String): String {
        return scope.trim()
            .lowercase()
            .replace("|", "_")
            .replace(Regex("\\s+"), "_")
            .ifBlank { "default" }
    }

    private fun persistReflectionOptimizations() {
        try {
            val snapshot = synchronized(reflectionLock) {
                stepOptimizations.entries.map { PersistedOptimizationEntry(it.key, it.value) }
            }
            val payload = json.encodeToString(
                ListSerializer(PersistedOptimizationEntry.serializer()),
                snapshot
            )
            context.getSharedPreferences(REFLECTION_PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(REFLECTION_POLICIES_KEY, payload)
                .apply()
        } catch (e: Exception) {
            LogManager.e(TAG, "保存反思策略失败", e)
        }
    }

    private fun loadReflectionOptimizations() {
        try {
            val payload = context.getSharedPreferences(REFLECTION_PREFS_NAME, Context.MODE_PRIVATE)
                .getString(REFLECTION_POLICIES_KEY, null)
                ?: return
            if (payload.isBlank()) {
                return
            }
            val entries = json.decodeFromString(
                ListSerializer(PersistedOptimizationEntry.serializer()),
                payload
            )
            synchronized(reflectionLock) {
                stepOptimizations.clear()
                entries.forEach { stepOptimizations[it.key] = it.optimization }
            }
            LogManager.d(TAG, "已加载反思策略: ${entries.size}")
        } catch (e: Exception) {
            LogManager.e(TAG, "加载反思策略失败", e)
        }
    }

    private fun buildFailureSummary(task: TaskContext?): String {
        val failedSteps = task?.failedSteps ?: return "失败摘要: 无失败步骤记录"
        if (failedSteps.isEmpty()) {
            return "失败摘要: 无失败步骤记录"
        }
        return failedSteps.takeLast(3).joinToString(prefix = "失败摘要: ", separator = " | ") {
            "${it.step.description}: ${it.reason}"
        }
    }

    private fun resolveParameter(param: String): String {
        var result = param
        val task = currentTask ?: return result
        
        task.intent.parameters.forEach { (key, value) ->
            result = result.replace("{$key}", value)
            result = result.replace("{${key}Name}", value)
        }
        
        return result
    }
    
    private fun analyzeCurrentScreen(rootNode: AccessibilityNodeInfo): ScreenInfo {
        val visibleTexts = mutableListOf<String>()
        val clickableElements = mutableListOf<String>()
        var hasPopup = false
        var currentApp = ""
        
        fun traverse(node: AccessibilityNodeInfo) {
            val text = node.text?.toString() ?: ""
            val desc = node.contentDescription?.toString() ?: ""
            
            if (text.isNotEmpty()) {
                visibleTexts.add(text)
                if (text.contains(Regex("关闭|取消|跳过|我知道了"))) {
                    hasPopup = true
                }
            }
            
            if (node.isClickable && (text.isNotEmpty() || desc.isNotEmpty())) {
                clickableElements.add(text.ifEmpty { desc })
            }
            
            if (node.packageName != null) {
                currentApp = node.packageName.toString()
            }
            
            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { traverse(it) }
            }
        }
        
        traverse(rootNode)
        
        return ScreenInfo(
            visibleTexts = visibleTexts,
            clickableElements = clickableElements,
            hasPopup = hasPopup,
            currentApp = currentApp
        )
    }
    
    private fun findNodeByText(node: AccessibilityNodeInfo, text: String): AccessibilityNodeInfo? {
        val nodeText = node.text?.toString() ?: ""
        val nodeDesc = node.contentDescription?.toString() ?: ""
        
        if (nodeText.contains(text, ignoreCase = true) || nodeDesc.contains(text, ignoreCase = true)) {
            return node
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findNodeByText(child, text)?.let { return it }
        }
        
        return null
    }
    
    private fun findNodeFuzzy(node: AccessibilityNodeInfo, target: String): AccessibilityNodeInfo? {
        val nodeText = node.text?.toString() ?: ""
        
        if (nodeText.isNotEmpty() && calculateSimilarity(nodeText, target) > 0.5) {
            return node
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findNodeFuzzy(child, target)?.let { return it }
        }
        
        return null
    }
    
    private fun findEditableNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable) return node
        
        val className = node.className?.toString() ?: ""
        if (className.contains("EditText")) return node
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findEditableNode(child)?.let { return it }
        }
        
        return null
    }
    
    private fun clickNode(node: AccessibilityNodeInfo): Boolean {
        if (node.isClickable) {
            return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        
        var parent = node.parent
        while (parent != null) {
            if (parent.isClickable) {
                return parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            parent = parent.parent
        }
        
        return false
    }
    
    private fun calculateSimilarity(s1: String, s2: String): Float {
        val longer = if (s1.length > s2.length) s1 else s2
        val shorter = if (s1.length > s2.length) s2 else s1
        
        if (longer.isEmpty()) return 1.0f
        
        var matches = 0
        for (char in shorter) {
            if (longer.contains(char, ignoreCase = true)) matches++
        }
        
        return matches.toFloat() / longer.length
    }
    
    /**
     * 停止执行
     */
    fun stop() {
        executionJob?.cancel()
        executionJob = null
        _state.value = ExecutionEngineState.Cancelled
    }
}

// ==================== 数据类 ====================

enum class IntentType {
    SEND_MESSAGE, WATCH_VIDEO, SEARCH, SHOPPING, OPEN_APP, OTHER
}

data class UserIntent(
    val type: IntentType,
    val description: String,
    val app: String,
    val parameters: Map<String, String> = emptyMap()
)

data class TaskPlan(
    val steps: List<PlanStep>,
    val intent: UserIntent
)

@Serializable
data class PlanStep(
    val id: String,
    val order: Int,
    val description: String,
    val action: String,
    val target: String?,
    val parameters: Map<String, String> = emptyMap()
)

data class TaskContext(
    val command: String,
    val intent: UserIntent,
    val plan: TaskPlan,
    val currentStepIndex: Int,
    val retryCount: Int,
    val failedSteps: MutableList<FailedStep>,
    val executedSteps: MutableList<ExecutedStep>
)

data class FailedStep(
    val step: PlanStep,
    val reason: String,
    val suggestion: String?
)

data class ExecutedStep(
    val step: PlanStep,
    val success: Boolean,
    val message: String
)

data class ExecutionRecord(
    val command: String,
    val intent: UserIntent,
    val steps: List<PlanStep>,
    val success: Boolean,
    val timestamp: Long
)

data class LearnedSolution(
    val intentType: String,
    val plan: TaskPlan,
    val tips: String
)

data class StepReflection(
    val key: String,
    val intentType: String,
    val app: String,
    val action: String,
    val target: String?,
    val parameters: Map<String, String> = emptyMap(),
    val success: Boolean,
    val reason: String?,
    val durationMs: Long,
    val timestamp: Long
)

@Serializable
data class StepOptimization(
    val preferredAction: String? = null,
    val waitAfterMs: Long = 0L,
    val confidence: Int = 0,
    val averageDurationMs: Long = 0L,
    val updatedAt: Long = 0L,
    val paramHints: Map<String, String> = emptyMap()
)

data class RuntimeOptimizationAdvice(
    val originalAction: String,
    val suggestedAction: String,
    val waitAfterMs: Long,
    val confidence: Int,
    val paramAdjustments: Map<String, String> = emptyMap()
)

@Serializable
data class PersistedOptimizationEntry(
    val key: String,
    val optimization: StepOptimization
)

data class ScreenInfo(
    val visibleTexts: List<String>,
    val clickableElements: List<String>,
    val hasPopup: Boolean,
    val currentApp: String
)

sealed class StepResult {
    data class Success(val message: String) : StepResult()
    data class Failure(val reason: String, val suggestion: String?) : StepResult()
    object Skip : StepResult()
}

sealed class ExecutionEngineState {
    object Idle : ExecutionEngineState()
    object Analyzing : ExecutionEngineState()
    data class Executing(val current: Int, val total: Int, val message: String) : ExecutionEngineState()
    data class Completed(val message: String) : ExecutionEngineState()
    data class Failed(val error: String) : ExecutionEngineState()
    object Cancelled : ExecutionEngineState()
}

@Serializable
data class AdaptiveSuggestion(
    val action: String,
    val description: String,
    val alternativeTarget: String? = null
)

@Serializable
data class LLMIntentResponse(
    val type: String,
    val description: String,
    val app: String,
    val parameters: Map<String, String> = emptyMap()
)

@Serializable
data class LLMPlanResponse(
    val steps: List<PlanStep>
)

@Serializable
data class LLMLearnedSolution(
    val steps: List<PlanStep>,
    val tips: String = ""
)
