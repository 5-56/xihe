package com.example.xihe.automation.script

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.core.LLMClient
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.ByteArrayOutputStream

/**
 * 🔧 脚本优化器
 * 基于屏幕分析提供错误修复建议，支持 AI 分析和自动参数优化
 */
class ScriptOptimizer(
    private val context: Context,
    private val llmClient: LLMClient
) {
    companion object {
        private const val TAG = "ScriptOptimizer"
        private const val MIN_CONFIDENCE = 0.5f
        
        private val SYSTEM_PROMPT = """
你是一个 Android 自动化脚本分析专家。你的任务是分析脚本执行失败的原因，并提供精确的修复建议。

分析时请考虑：
1. 目标元素是否存在于当前屏幕
2. 元素文本是否发生变化
3. 应用状态是否正确
4. 是否需要等待或滚动

请始终返回有效的 JSON 格式响应。
        """.trimIndent()
    }
    
    private val json = Json { ignoreUnknownKeys = true }
    
    /**
     * 分析错误并生成优化建议
     * @param step 失败的步骤
     * @param screenshot 当前屏幕截图
     * @param errorMessage 错误信息
     * @return OptimizationSuggestion 优化建议
     */
    suspend fun analyzeError(
        step: SmartStep,
        screenshot: Bitmap,
        errorMessage: String
    ): OptimizationSuggestion = withContext(Dispatchers.IO) {
        try {
            // 获取当前屏幕元素
            val screenElements = getScreenElements()
            
            // 构建分析提示词
            val prompt = buildAnalysisPrompt(step, screenElements, errorMessage)
            
            // 将截图转为 Base64
            val imageBase64 = bitmapToBase64(screenshot)
            
            // 调用 AI 分析
            val response = llmClient.chatCompletionWithImage(
                prompt = "$SYSTEM_PROMPT\n\n$prompt",
                imageBase64 = imageBase64,
                usePersonality = false
            )
            
            // 解析 AI 响应
            parseAIResponse(response, step)
        } catch (e: Exception) {
            LogManager.e(TAG, "AI 分析失败", e)
            // 返回基于规则的默认建议
            generateFallbackSuggestion(step, errorMessage)
        }
    }
    
    /**
     * 应用优化建议到脚本
     * @param script 原始脚本
     * @param stepId 要优化的步骤 ID
     * @param suggestion 优化建议
     * @return 优化后的脚本
     */
    fun applyOptimization(
        script: SmartScript,
        stepId: String,
        suggestion: OptimizationSuggestion
    ): SmartScript {
        val fix = suggestion.suggestedFix ?: return script
        
        val updatedSteps = script.flow.steps.map { step ->
            if (step.id == stepId) {
                applyFixToStep(step, fix)
            } else {
                step
            }
        }
        
        return script.copy(
            flow = script.flow.copy(steps = updatedSteps),
            lastUpdated = System.currentTimeMillis()
        )
    }
    
    /**
     * 批量优化脚本
     * @param script 原始脚本
     * @param report 验证报告
     * @return OptimizedScriptResult 优化结果
     */
    suspend fun optimizeScript(
        script: SmartScript,
        report: ValidationReport
    ): OptimizedScriptResult = withContext(Dispatchers.IO) {
        val appliedFixes = mutableListOf<AppliedFix>()
        val remainingIssues = mutableListOf<String>()
        var currentScript = script
        
        // 遍历所有失败步骤
        report.stepResults.filter { !it.success }.forEach { stepResult ->
            val suggestion = stepResult.optimizationSuggestion
            
            if (suggestion != null && suggestion.suggestedFix != null && suggestion.confidence >= MIN_CONFIDENCE) {
                val step = currentScript.flow.steps.find { it.id == stepResult.stepId }
                if (step != null) {
                    val originalValue = getStepValue(step)
                    currentScript = applyOptimization(currentScript, stepResult.stepId, suggestion)
                    val newValue = getStepValue(currentScript.flow.steps.find { it.id == stepResult.stepId }!!)
                    
                    appliedFixes.add(AppliedFix(
                        stepId = stepResult.stepId,
                        originalValue = originalValue,
                        newValue = newValue,
                        fixType = suggestion.suggestedFix::class.simpleName ?: "Unknown"
                    ))
                }
            } else {
                remainingIssues.add("步骤 ${stepResult.stepId}: ${stepResult.errorMessage ?: "未知错误"}")
            }
        }
        
        OptimizedScriptResult(
            originalScript = script,
            optimizedScript = currentScript,
            appliedFixes = appliedFixes,
            remainingIssues = remainingIssues
        )
    }

    
    private fun applyFixToStep(step: SmartStep, fix: SuggestedFix): SmartStep {
        return when (fix) {
            is SuggestedFix.UpdateTarget -> step.copy(target = fix.newTarget)
            is SuggestedFix.UpdateCoordinates -> step.copy(
                value = "${fix.x},${fix.y}"
            )
            is SuggestedFix.AddWaitStep -> step // 等待步骤需要在外部插入
            is SuggestedFix.AddScrollStep -> step.copy(
                action = "SCROLL",
                value = fix.direction
            )
            is SuggestedFix.ChangeAction -> step.copy(action = fix.newAction)
            is SuggestedFix.UpdateValue -> step.copy(value = fix.newValue)
        }
    }
    
    private fun getStepValue(step: SmartStep): String {
        return listOfNotNull(step.action, step.target, step.value).joinToString(" | ")
    }
    
    private fun getScreenElements(): List<String> {
        return try {
            val service = CoreAccessibilityService.getInstance()
            service?.getTextElements()?.mapNotNull { it.text } ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }
    
    private fun buildAnalysisPrompt(
        step: SmartStep,
        screenElements: List<String>,
        errorMessage: String
    ): String {
        return """
分析以下脚本步骤执行失败的原因，并提供修复建议。

## 失败步骤信息
- 步骤 ID: ${step.id}
- 类型: ${step.type}
- 动作: ${step.action ?: "无"}
- 目标: ${step.target ?: "无"}
- 值: ${step.value ?: "无"}

## 错误信息
$errorMessage

## 当前屏幕可点击元素
${screenElements.take(20).joinToString("\n") { "- $it" }}

## 请分析并返回 JSON 格式的建议
{
  "errorType": "ELEMENT_NOT_FOUND|ELEMENT_MOVED|APP_STATE_CHANGED|PERMISSION_DENIED|TIMEOUT|UNKNOWN",
  "errorDescription": "错误原因描述",
  "suggestedFix": {
    "type": "UPDATE_TARGET|UPDATE_COORDINATES|ADD_WAIT|ADD_SCROLL|CHANGE_ACTION",
    "value": "新的目标文本或坐标或动作"
  },
  "confidence": 0.0-1.0,
  "reasoning": "推理过程"
}
        """.trimIndent()
    }
    
    private fun parseAIResponse(response: String, step: SmartStep): OptimizationSuggestion {
        return try {
            // 提取 JSON 部分
            val jsonMatch = Regex("\\{[^{}]*\"errorType\"[^{}]*\\}").find(response)
            val jsonStr = jsonMatch?.value ?: throw Exception("未找到有效 JSON")
            
            val parsed = json.decodeFromString<AIAnalysisResponse>(jsonStr)
            
            OptimizationSuggestion(
                errorType = ErrorType.valueOf(parsed.errorType),
                errorDescription = parsed.errorDescription,
                suggestedFix = parseSuggestedFix(parsed.suggestedFix),
                confidence = parsed.confidence.coerceIn(0f, 1f),
                reasoning = parsed.reasoning
            )
        } catch (e: Exception) {
            LogManager.w(TAG, "解析 AI 响应失败: ${e.message}")
            generateFallbackSuggestion(step, response)
        }
    }
    
    private fun parseSuggestedFix(fix: AIFixSuggestion?): SuggestedFix? {
        if (fix == null) return null
        
        return when (fix.type.uppercase()) {
            "UPDATE_TARGET" -> SuggestedFix.UpdateTarget(fix.value)
            "UPDATE_COORDINATES" -> {
                val coords = fix.value.split(",").mapNotNull { it.trim().toIntOrNull() }
                if (coords.size >= 2) {
                    SuggestedFix.UpdateCoordinates(coords[0], coords[1])
                } else null
            }
            "ADD_WAIT" -> SuggestedFix.AddWaitStep(fix.value.toLongOrNull() ?: 1000L)
            "ADD_SCROLL" -> SuggestedFix.AddScrollStep(fix.value)
            "CHANGE_ACTION" -> SuggestedFix.ChangeAction(fix.value)
            "UPDATE_VALUE" -> SuggestedFix.UpdateValue(fix.value)
            else -> null
        }
    }
    
    private fun generateFallbackSuggestion(step: SmartStep, errorMessage: String): OptimizationSuggestion {
        // 基于规则的简单分析
        val errorType = when {
            errorMessage.contains("not found", ignoreCase = true) -> ErrorType.ELEMENT_NOT_FOUND
            errorMessage.contains("timeout", ignoreCase = true) -> ErrorType.TIMEOUT
            errorMessage.contains("permission", ignoreCase = true) -> ErrorType.PERMISSION_DENIED
            else -> ErrorType.UNKNOWN
        }
        
        val suggestedFix = when (errorType) {
            ErrorType.ELEMENT_NOT_FOUND -> {
                // 尝试从屏幕元素中找到相似的
                val screenElements = getScreenElements()
                val similar = findSimilarElement(step.target, screenElements)
                if (similar != null) {
                    SuggestedFix.UpdateTarget(similar)
                } else {
                    SuggestedFix.AddScrollStep("DOWN")
                }
            }
            ErrorType.TIMEOUT -> SuggestedFix.AddWaitStep(2000L)
            else -> null
        }
        
        return OptimizationSuggestion(
            errorType = errorType,
            errorDescription = errorMessage,
            suggestedFix = suggestedFix,
            confidence = if (suggestedFix != null) 0.6f else 0.3f,
            reasoning = "基于规则的自动分析"
        )
    }
    
    private fun findSimilarElement(target: String?, elements: List<String>): String? {
        if (target.isNullOrBlank()) return null
        
        // 简单的相似度匹配
        return elements.find { element ->
            element.contains(target, ignoreCase = true) ||
            target.contains(element, ignoreCase = true) ||
            levenshteinDistance(target.lowercase(), element.lowercase()) <= 3
        }
    }
    
    private fun levenshteinDistance(s1: String, s2: String): Int {
        val dp = Array(s1.length + 1) { IntArray(s2.length + 1) }
        
        for (i in 0..s1.length) dp[i][0] = i
        for (j in 0..s2.length) dp[0][j] = j
        
        for (i in 1..s1.length) {
            for (j in 1..s2.length) {
                val cost = if (s1[i - 1] == s2[j - 1]) 0 else 1
                dp[i][j] = minOf(
                    dp[i - 1][j] + 1,
                    dp[i][j - 1] + 1,
                    dp[i - 1][j - 1] + cost
                )
            }
        }
        
        return dp[s1.length][s2.length]
    }
    
    private fun bitmapToBase64(bitmap: Bitmap): String {
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
        return Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
    }
}

// ==================== 数据模型 ====================

data class OptimizationSuggestion(
    val errorType: ErrorType,
    val errorDescription: String,
    val suggestedFix: SuggestedFix?,
    val confidence: Float,
    val reasoning: String
)

enum class ErrorType {
    ELEMENT_NOT_FOUND,      // 元素未找到
    ELEMENT_MOVED,          // 元素位置变化
    APP_STATE_CHANGED,      // 应用状态异常
    PERMISSION_DENIED,      // 权限不足
    TIMEOUT,                // 超时
    UNKNOWN                 // 未知错误
}

sealed class SuggestedFix {
    data class UpdateTarget(val newTarget: String) : SuggestedFix()
    data class UpdateCoordinates(val x: Int, val y: Int) : SuggestedFix()
    data class AddWaitStep(val waitMs: Long) : SuggestedFix()
    data class AddScrollStep(val direction: String) : SuggestedFix()
    data class ChangeAction(val newAction: String) : SuggestedFix()
    data class UpdateValue(val newValue: String) : SuggestedFix()
}

data class OptimizedScriptResult(
    val originalScript: SmartScript,
    val optimizedScript: SmartScript,
    val appliedFixes: List<AppliedFix>,
    val remainingIssues: List<String>
) {
    val hasChanges: Boolean get() = appliedFixes.isNotEmpty()
    val fixCount: Int get() = appliedFixes.size
}

data class AppliedFix(
    val stepId: String,
    val originalValue: String,
    val newValue: String,
    val fixType: String
)

// AI 响应解析模型
@Serializable
private data class AIAnalysisResponse(
    val errorType: String,
    val errorDescription: String,
    val suggestedFix: AIFixSuggestion? = null,
    val confidence: Float,
    val reasoning: String
)

@Serializable
private data class AIFixSuggestion(
    val type: String,
    val value: String
)
