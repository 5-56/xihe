package com.example.xihe.automation.flow

import com.example.xihe.utils.LogManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * ⚡ 触发器管理器
 * 监听系统事件并激活相应的工作流
 */
object TriggerManager {
    private const val TAG = "TriggerManager"
    @Volatile
    private var activeTriggers: List<AutomationFlow> = emptyList()
    private var monitorJob: Job? = null
    private val lastTimeTriggerMinute = mutableMapOf<String, String>()
    
    // 简单的回调，当触发器满足时调用
    var onTriggerMatched: ((AutomationFlow) -> Unit)? = null

    /**
     * 注册监听的流程
     */
    fun registerFlows(flows: List<AutomationFlow>) {
        activeTriggers = flows.filter { it.enabled }
        LogManager.d(TAG, "已注册 ${activeTriggers.size} 个自动化监听")
    }

    /**
     * 启动监听服务
     */
    fun startMonitoring() {
        if (monitorJob?.isActive == true) return
        
        monitorJob = CoroutineScope(Dispatchers.Default).launch {
            while (isActive) {
                try {
                    checkTimeTriggers()
                } catch (e: Exception) {
                    LogManager.e(TAG, "触发器检查失败", e)
                }
                delay(10000)
            }
        }
        LogManager.i(TAG, "触发器监控已启动")
    }

    fun stopMonitoring() {
        monitorJob?.cancel()
        monitorJob = null
        lastTimeTriggerMinute.clear()
    }

    /**
     * 处理外部事件（如通知到达）
     */
    fun onNotificationPosted(packageName: String, title: String, content: String) {
        activeTriggers.forEach { flow ->
            flow.triggers.forEach { trigger ->
                if (trigger.type == TriggerType.NOTIFICATION) {
                    val targetApp = trigger.config["app"]
                    val keyword = trigger.config["keyword"]
                    
                    if (targetApp != null && packageName.contains(targetApp)) {
                        if (keyword == null || content.contains(keyword)) {
                            LogManager.i(TAG, "🔔 触发规则 [${flow.name}] - 收到通知: $packageName")
                            onTriggerMatched?.invoke(flow)
                        }
                    }
                }
            }
        }
    }

    private fun checkTimeTriggers() {
        val now = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        val minuteKey = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())

        lastTimeTriggerMinute.entries.removeAll { it.value != minuteKey }

        activeTriggers.forEach { flow ->
            flow.triggers.forEach { trigger ->
                if (trigger.type == TriggerType.TIME) {
                    val targetTime = trigger.config["time"]
                    if (targetTime == now) {
                        val triggerKey = "${flow.id}:$targetTime"
                        if (lastTimeTriggerMinute[triggerKey] == minuteKey) return@forEach
                        lastTimeTriggerMinute[triggerKey] = minuteKey
                        LogManager.i(TAG, "⏰ 触发规则 [${flow.name}] - 时间到达: $now")
                        onTriggerMatched?.invoke(flow)
                    }
                }
            }
        }
    }
}
