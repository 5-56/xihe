package com.example.xihe.automation.agent

import android.content.Context
import android.accessibilityservice.AccessibilityService
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull

object TaskOrchestrator {
    private const val TAG = "TaskOrchestrator"
    private const val TARGET_APP_WAIT_TIMEOUT_MS = 8_000L
    private const val TARGET_APP_POLL_INTERVAL_MS = 250L
    private val taskMutex = Mutex()

    suspend fun runSingleTask(
        context: Context,
        userMessage: String,
        resetHome: Boolean = true,
        block: suspend () -> DefaultAgentService.AgentLoopResult
    ): DefaultAgentService.AgentLoopResult {
        val readiness = AutomationReadinessChecker.check(context)
        if (!readiness.canRun) {
            return DefaultAgentService.AgentLoopResult(
                success = false,
                summary = readiness.summary + readiness.suggestions.joinToString(
                    prefix = if (readiness.suggestions.isEmpty()) "" else "。建议：",
                    separator = "；"
                ),
                iterations = 0
            )
        }

        return taskMutex.withLock {
            val service = CoreAccessibilityService.getInstance()
            if (resetHome) {
                LogManager.d(TAG, "Reset device state with HOME before task: $userMessage")
                service?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
                delay(300)
            }
            if (readiness.targetPackage != null) {
                openTargetAppIfNeeded(context, readiness.targetPackage, readiness.targetAppName)
            }
            block()
        }
    }

    private suspend fun openTargetAppIfNeeded(
        context: Context,
        targetPackage: String,
        targetAppName: String?
    ) {
        val service = CoreAccessibilityService.getInstance()
        if (service?.getCurrentPackageName() == targetPackage) return

        val launchIntent = context.packageManager.getLaunchIntentForPackage(targetPackage)
        if (launchIntent == null) {
            LogManager.w(TAG, "Target app launch intent not found: $targetAppName/$targetPackage")
            return
        }

        LogManager.i(TAG, "Opening target app before automation: ${targetAppName ?: targetPackage}")
        launchIntent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP)
        context.startActivity(launchIntent)

        val reached = withTimeoutOrNull(TARGET_APP_WAIT_TIMEOUT_MS) {
            while (true) {
                if (CoreAccessibilityService.getInstance()?.getCurrentPackageName() == targetPackage) {
                    return@withTimeoutOrNull true
                }
                delay(TARGET_APP_POLL_INTERVAL_MS)
            }
        } == true

        if (reached) {
            LogManager.i(TAG, "Target app is in foreground: $targetPackage")
        } else {
            LogManager.w(TAG, "Timed out waiting for target app foreground: $targetPackage")
        }
    }
}
