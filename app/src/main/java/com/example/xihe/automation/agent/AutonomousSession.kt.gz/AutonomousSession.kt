package com.example.xihe.automation.agent

import android.content.Context
import com.example.xihe.automation.SmartAutomationManager
import com.example.xihe.automation.flow.ActionType
import com.example.xihe.automation.flow.AuditManager
import com.example.xihe.automation.flow.AutomationFlow
import com.example.xihe.automation.flow.FlowAction
import com.example.xihe.automation.script.AdvancedAutomationFlow
import com.example.xihe.automation.script.SmartScriptManager
import com.example.xihe.automation.script.ScriptMetadata
import com.example.xihe.automation.script.SmartScript
import com.example.xihe.automation.script.SmartStep
import com.example.xihe.automation.script.StepType
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.delay
import java.util.UUID

/**
 * 🕵️‍♂️ 自主任务会话
 * 执行 "观察 -> 思考 -> 行动" 循环，并录制脚本
 */
class AutonomousSession(
    private val context: Context,
    private val userGoal: String,
    private val maxSteps: Int = DEFAULT_MAX_STEPS
) {
    private val TAG = "AutonomousSession"
    
    // 录制的动作序列
    private val recordedActions = mutableListOf<FlowAction>()
    private val stepHistory = mutableListOf<String>()
    
    private var isRunning = false
    
    companion object {
        const val DEFAULT_MAX_STEPS = 10
        const val MIN_CONFIDENCE_THRESHOLD = 0.4f
    }

    /**
     * 开始自主执行
     */
    suspend fun start(): SessionResult {
        LogManager.i(TAG, "🚀 开始自主任务会话: $userGoal (最大步数: $maxSteps)")
        isRunning = true
        var stepCount = 0
        var lastError: String? = null
        
        try {
            while (isRunning && stepCount < maxSteps) {
                // 1. 思考
                val proposal = AIPlanner.planNextStep(context, userGoal, stepHistory)
                
                if (proposal == null) {
                    LogManager.w(TAG, "🤔 AI 无法决定下一步，任务终止")
                    lastError = "AI 无法决定下一步操作"
                    break
                }
                
                if (proposal.confidence < MIN_CONFIDENCE_THRESHOLD) {
                    LogManager.w(TAG, "⚠️ 信心不足 (${proposal.confidence})，停止尝试以防误操作")
                    lastError = "操作置信度过低 (${proposal.confidence})"
                    break
                }
                
                LogManager.i(TAG, "👉 执行动作: ${proposal.type} (${proposal.reasoning})")
                
                // 2. 执行
                val actionId = (stepCount + 1).toString()
                val success = executeAction(proposal, actionId)
                
                // 3. 记录
                if (success) {
                    val flowAction = FlowAction(
                        id = actionId,
                        type = proposal.type,
                        params = proposal.params,
                        nextActionId = (stepCount + 2).toString()
                    )
                    recordedActions.add(flowAction)
                    stepHistory.add(proposal.type.name)
                    
                    // 记录审计日志
                    AuditManager.logAction(context, "AUTONOMOUS_$userGoal", flowAction, "SUCCESS", proposal.reasoning)
                } else {
                    LogManager.e(TAG, "❌ 动作执行失败")
                    lastError = "动作执行失败: ${proposal.type}"
                    break
                }
                
                delay(2000) // 等待界面响应
                stepCount++
            }
            
            // 任务结束，尝试保存脚本
            val scriptSaved = if (recordedActions.isNotEmpty()) {
                saveAsScript()
                true
            } else {
                false
            }
            
            return if (lastError != null) {
                SessionResult.Failed(
                    error = lastError,
                    stepsCompleted = stepCount,
                    scriptSaved = scriptSaved
                )
            } else if (stepCount >= maxSteps) {
                SessionResult.MaxStepsReached(
                    stepsCompleted = stepCount,
                    scriptSaved = scriptSaved
                )
            } else {
                SessionResult.Success(
                    message = "任务完成",
                    stepsCompleted = stepCount,
                    scriptSaved = scriptSaved
                )
            }
            
        } catch (e: Exception) {
            LogManager.e(TAG, "会话异常", e)
            return SessionResult.Failed(
                error = e.message ?: "未知错误",
                stepsCompleted = stepCount,
                scriptSaved = false
            )
        } finally {
            isRunning = false
        }
    }
    
    /**
     * 停止会话
     */
    fun stop() {
        isRunning = false
        LogManager.i(TAG, "🛑 会话已停止")
    }
    
    /**
     * 会话结果
     */
    sealed class SessionResult {
        data class Success(
            val message: String,
            val stepsCompleted: Int,
            val scriptSaved: Boolean
        ) : SessionResult()
        
        data class Failed(
            val error: String,
            val stepsCompleted: Int,
            val scriptSaved: Boolean
        ) : SessionResult()
        
        data class MaxStepsReached(
            val stepsCompleted: Int,
            val scriptSaved: Boolean
        ) : SessionResult()
    }
    
    /**
     * 执行具体动作
     */
    private suspend fun executeAction(proposal: AIPlanner.ActionProposal, id: String): Boolean {
        val result = SmartAutomationManager.smartExecute(
            context, 
            action = convertTypeToCommand(proposal.type), 
            params = proposal.params
        )
        
        return result is SmartAutomationManager.ExecutionResult.Success
    }
    
    private fun convertTypeToCommand(type: ActionType): String {
        return when(type) {
            ActionType.CLICK -> "click"
            ActionType.SMART_FIND_AND_CLICK -> "click"
            ActionType.SWIPE -> "swipe"
            ActionType.OPEN_APP -> "open_app"
            else -> "click"
        }
    }

    /**
     * 💾 将刚才的操作保存为脚本
     */
    private fun saveAsScript() {
        LogManager.i(TAG, "💾 正在将操作序列保存为智能脚本...")
        
        // 修正最后一个动作的 nextActionId
        if (recordedActions.isNotEmpty()) {
            val last = recordedActions.last()
            recordedActions[recordedActions.lastIndex] = last.copy(nextActionId = null)
        }
        
        // 将 FlowAction 转换为 SmartStep
        val smartSteps = recordedActions.map { action ->
            SmartStep(
                id = action.id,
                type = when (action.type) {
                    ActionType.CLICK -> StepType.ACTION
                    ActionType.INPUT_TEXT -> StepType.ACTION
                    ActionType.SWIPE -> StepType.ACTION
                    ActionType.DELAY -> StepType.DELAY
                    else -> StepType.ACTION
                },
                action = action.type.name,
                target = action.params["target"],
                value = action.params["value"]
            )
        }
        
        val advancedFlow = AdvancedAutomationFlow(
            steps = smartSteps,
            onGlobalFailure = null
        )
        
        val script = SmartScript(
            id = UUID.randomUUID().toString(),
            metadata = ScriptMetadata(
                name = userGoal,
                description = "自动生成的任务流程 (by Xihe AI)",
                keywords = extractKeywords(userGoal),
                intent = "AUTO_GENERATED"
            ),
            flow = advancedFlow
        )
        
        SmartScriptManager.saveScript(context, script)
        LogManager.i(TAG, "✅ 脚本已保存！下次可直接调用。")
    }
    
    private fun extractKeywords(text: String): List<String> {
        return text.split(" ").filter { it.length > 1 }
    }
}
