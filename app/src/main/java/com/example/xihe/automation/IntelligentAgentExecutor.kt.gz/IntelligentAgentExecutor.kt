package com.example.xihe.automation

import android.content.Context
import android.graphics.Bitmap
import com.example.xihe.utils.LogManager
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.core.LLMClient
import com.example.xihe.core.ScreenAnalyzer
import com.example.xihe.vision.EnhancedScreenRecognition
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/**
 * 🧠 智能Agent执行器 (Intelligent Agent Executor)
 * 
 * 核心功能：
 * 1. 🔄 Agent循环执行 - 观察→思考→行动→反馈
 * 2. 🖼️ 屏幕理解 - 结合OCR和目标检测理解界面
 * 3. 🎯 动态决策 - LLM实时分析并决定下一步
 * 4. 🔧 自适应执行 - 根据屏幕变化调整策略
 * 5. 📚 执行学习 - 记录成功路径供后续使用
 * 
 * 适用于：
 * - 未见过的复杂任务
 * - 需要多步交互的操作
 * - 界面不确定的场景
 */
object IntelligentAgentExecutor {
    
    private const val TAG = "IntelligentAgent"
    private const val MAX_STEPS = 20 // 单次任务最大步骤数
    private const val STEP_TIMEOUT = 30_000L // 单步超时时间
    private const val MAX_HISTORY_SIZE = 100 // 最大历史记录数
    
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }
    
    // LLM客户端实例
    private val llmClient by lazy { LLMClient() }
    
    // 执行状态
    private val _executionState = MutableStateFlow<AgentExecutionState>(AgentExecutionState.Idle)
    val executionState = _executionState.asStateFlow()
    
    // 执行历史（用于学习）- 使用同步列表
    private val executionHistory = java.util.Collections.synchronizedList(mutableListOf<ExecutionRecord>())
    
    // 历史记录锁
    private val historyLock = Any()
    
    // ==================== 数据类 ====================
    
    @Serializable
    data class AgentTask(
        val goal: String,                    // 用户目标
        val context: String = "",            // 额外上下文
        val maxSteps: Int = MAX_STEPS,       // 最大步骤数
        val requireConfirmation: Boolean = false // 是否需要确认
    )
    
    @Serializable
    data class AgentAction(
        val type: String,           // CLICK, INPUT, SCROLL, BACK, HOME, WAIT, OPEN_APP, DONE
        val target: String = "",    // 目标元素描述
        val value: String = "",     // 输入值或参数
        val confidence: Float = 0f, // 置信度
        val reason: String = ""     // 决策理由
    )
    
    @Serializable
    data class ScreenUnderstanding(
        val description: String,           // 屏幕描述
        val visibleElements: List<String>, // 可见元素
        val currentApp: String = "",       // 当前应用
        val relevantInfo: String = ""      // 与任务相关的信息
    )
    
    sealed class AgentExecutionState {
        object Idle : AgentExecutionState()
        data class Running(
            val taskGoal: String,
            val currentStep: Int,
            val lastAction: String,
            val progress: Float
        ) : AgentExecutionState()
        data class WaitingConfirmation(val nextAction: AgentAction) : AgentExecutionState()
        data class Completed(val success: Boolean, val message: String) : AgentExecutionState()
        data class Failed(val error: String, val stepsTaken: Int) : AgentExecutionState()
    }
    
    data class ExecutionRecord(
        val task: AgentTask,
        val actions: List<AgentAction>,
        val success: Boolean,
        val timestamp: Long = System.currentTimeMillis()
    )
    
    // ==================== 核心执行流程 ====================
    
    /**
     * 🚀 执行智能任务
     * 
     * Agent循环：观察 → 思考 → 行动 → 验证 → 重复
     */
    suspend fun executeTask(
        task: AgentTask,
        context: Context,
        onProgress: (Int, Int, String) -> Unit = { _, _, _ -> }
    ): AgentExecutionResult {
        LogManager.i(TAG, "🚀 开始智能执行任务: ${task.goal}")
        
        val actions = mutableListOf<AgentAction>()
        var stepCount = 0
        var lastError: String? = null
        
        _executionState.value = AgentExecutionState.Running(
            taskGoal = task.goal,
            currentStep = 0,
            lastAction = "初始化",
            progress = 0f
        )
        
        try {
            while (stepCount < task.maxSteps) {
                stepCount++
                val progress = stepCount.toFloat() / task.maxSteps
                
                // 1️⃣ 观察：获取并理解当前屏幕
                onProgress(stepCount, task.maxSteps, "🔍 分析屏幕...")
                val screenUnderstanding = observeScreen(context)
                
                LogManager.d(TAG, "📸 屏幕理解: ${screenUnderstanding.description}")
                
                // 2️⃣ 思考：让LLM决定下一步行动
                onProgress(stepCount, task.maxSteps, "🧠 思考下一步...")
                val nextAction = thinkNextAction(
                    task = task,
                    screenUnderstanding = screenUnderstanding,
                    previousActions = actions,
                    stepCount = stepCount,
                    context = context
                )
                
                LogManager.d(TAG, "🎯 决定行动: ${nextAction.type} - ${nextAction.target} (${nextAction.reason})")
                
                // 检查是否完成
                if (nextAction.type == "DONE") {
                    LogManager.i(TAG, "✅ 任务完成: ${nextAction.reason}")
                    actions.add(nextAction)
                    
                    // 记录成功执行
                    recordExecution(task, actions, true)
                    
                    _executionState.value = AgentExecutionState.Completed(true, nextAction.reason)
                    return AgentExecutionResult.Success(
                        message = nextAction.reason,
                        stepsUsed = stepCount,
                        actions = actions
                    )
                }
                
                // 检查是否需要确认
                if (task.requireConfirmation && nextAction.type in listOf("INPUT", "CLICK")) {
                    _executionState.value = AgentExecutionState.WaitingConfirmation(nextAction)
                    // 等待用户确认（实际实现需要回调）
                }
                
                // 3️⃣ 行动：执行决定的操作
                val runtimePlan = buildRuntimeActionPlan(nextAction, context)
                val plannedAction = runtimePlan.action
                if (plannedAction.type.equals("STOP", ignoreCase = true)) {
                    actions.add(plannedAction)
                    recordExecution(task, actions, true)
                    _executionState.value = AgentExecutionState.Completed(true, "运行时策略建议停止")
                    return AgentExecutionResult.Success(
                        message = "运行时策略建议停止",
                        stepsUsed = stepCount,
                        actions = actions
                    )
                }
                onProgress(stepCount, task.maxSteps, "⚡ 执行: ${plannedAction.type} ${plannedAction.target}")
                _executionState.value = AgentExecutionState.Running(
                    taskGoal = task.goal,
                    currentStep = stepCount,
                    lastAction = "${plannedAction.type}: ${plannedAction.target}",
                    progress = progress
                )
                
                val actionStartTime = System.currentTimeMillis()
                val actionResult = executeAction(plannedAction, context)
                val actionDurationMs = (System.currentTimeMillis() - actionStartTime).coerceAtLeast(1L)
                val reflectionUpdate = AdaptiveExecutionEngine.getInstance(context).recordRuntimeReflection(
                    scope = "intelligent_agent",
                    action = plannedAction.type,
                    target = plannedAction.target.takeIf { it.isNotBlank() },
                    success = actionResult.success,
                    reason = actionResult.error,
                    durationMs = actionDurationMs
                )
                if (!reflectionUpdate.isNullOrBlank()) {
                    LogManager.d(TAG, "策略更新: $reflectionUpdate")
                }
                if (runtimePlan.waitAfterMs > 0L) {
                    delay(runtimePlan.waitAfterMs)
                }
                actions.add(plannedAction)
                
                if (!actionResult.success) {
                    LogManager.w(TAG, "⚠️ 行动执行失败: ${actionResult.error}")
                    lastError = actionResult.error
                    
                    // 尝试恢复
                    val recovered = attemptRecovery(plannedAction, actionResult.error, context)
                    if (!recovered) {
                        // 继续尝试，让LLM重新决策
                        onProgress(stepCount, task.maxSteps, "🔄 执行失败，重新分析...")
                    }
                }
                
                // 4️⃣ 等待界面稳定
                delay(800)
            }
            
            // 达到最大步骤数
            LogManager.w(TAG, "⚠️ 达到最大步骤数: $stepCount")
            recordExecution(task, actions, false)
            
            _executionState.value = AgentExecutionState.Failed(
                "达到最大步骤数($stepCount)仍未完成",
                stepCount
            )
            
            return AgentExecutionResult.Failure(
                error = "任务未能在 $stepCount 步内完成",
                stepsUsed = stepCount,
                partialActions = actions
            )
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 任务执行异常", e)
            recordExecution(task, actions, false)
            
            _executionState.value = AgentExecutionState.Failed(e.message ?: "未知错误", stepCount)
            
            return AgentExecutionResult.Failure(
                error = e.message ?: "执行异常",
                stepsUsed = stepCount,
                partialActions = actions
            )
        }
    }
    
    // ==================== 观察模块 ====================
    
    /**
     * 🔍 观察并理解当前屏幕
     */
    private suspend fun observeScreen(context: Context): ScreenUnderstanding {
        return withContext(Dispatchers.Default) {
            try {
                val service = CoreAccessibilityService.instance
                val visibleElements = mutableListOf<String>()
                var currentApp = ""
                
                // 从Accessibility获取界面信息
                service?.let { svc ->
                    val rootNode = svc.rootInActiveWindow
                    currentApp = rootNode?.packageName?.toString() ?: ""
                    
                    // 遍历获取可见元素
                    fun traverseNode(node: android.view.accessibility.AccessibilityNodeInfo?, depth: Int = 0) {
                        if (node == null || depth > 5) return
                        
                        val text = node.text?.toString()?.trim()
                        val desc = node.contentDescription?.toString()?.trim()
                        val className = node.className?.toString()?.substringAfterLast(".")
                        
                        // 收集有意义的元素
                        if (!text.isNullOrBlank() && text.length < 100) {
                            val type = when {
                                node.isClickable && className?.contains("Button") == true -> "按钮"
                                node.isEditable -> "输入框"
                                className?.contains("Image") == true -> "图片"
                                else -> "文本"
                            }
                            visibleElements.add("[$type] $text")
                        } else if (!desc.isNullOrBlank() && desc.length < 50) {
                            visibleElements.add("[描述] $desc")
                        }
                        
                        // 递归子节点
                        for (i in 0 until node.childCount) {
                            traverseNode(node.getChild(i), depth + 1)
                        }
                    }
                    
                    traverseNode(rootNode)
                }
                
                // 生成屏幕描述
                val description = buildString {
                    append("当前应用: ${getAppName(currentApp)}\n")
                    append("可见元素数量: ${visibleElements.size}\n")
                    if (visibleElements.isNotEmpty()) {
                        append("主要元素: ${visibleElements.take(10).joinToString(", ")}")
                    }
                }
                
                ScreenUnderstanding(
                    description = description,
                    visibleElements = visibleElements.take(30), // 限制数量
                    currentApp = currentApp,
                    relevantInfo = ""
                )
                
            } catch (e: Exception) {
                LogManager.e(TAG, "屏幕观察失败", e)
                ScreenUnderstanding(
                    description = "无法获取屏幕信息",
                    visibleElements = emptyList(),
                    currentApp = "",
                    relevantInfo = "错误: ${e.message}"
                )
            }
        }
    }
    
    private fun getAppName(packageName: String): String {
        return when {
            packageName.contains("wechat") || packageName.contains("mm") -> "微信"
            packageName.contains("qq") -> "QQ"
            packageName.contains("taobao") -> "淘宝"
            packageName.contains("jd") -> "京东"
            packageName.contains("alipay") -> "支付宝"
            packageName.contains("douyin") || packageName.contains("aweme") -> "抖音"
            packageName.contains("bilibili") -> "哔哩哔哩"
            packageName.contains("chrome") -> "Chrome"
            packageName.contains("launcher") -> "桌面"
            else -> packageName.substringAfterLast(".")
        }
    }
    
    // ==================== 思考模块 ====================
    
    /**
     * 🧠 使用LLM决定下一步行动
     */
    private suspend fun thinkNextAction(
        task: AgentTask,
        screenUnderstanding: ScreenUnderstanding,
        previousActions: List<AgentAction>,
        stepCount: Int,
        context: Context
    ): AgentAction {
        return withContext(Dispatchers.IO) {
            try {
                // 构建提示词
                val prompt = buildThinkingPrompt(task, screenUnderstanding, previousActions, stepCount, context)
                
                // 调用LLM
                val response = llmClient.chatCompletion(prompt, usePersonality = false)
                
                // 解析响应
                parseActionFromResponse(response)
                
            } catch (e: Exception) {
                LogManager.e(TAG, "LLM思考失败", e)
                
                // 降级：返回等待动作
                AgentAction(
                    type = "WAIT",
                    value = "2000",
                    confidence = 0.3f,
                    reason = "LLM分析失败，等待后重试"
                )
            }
        }
    }
    
    private fun buildThinkingPrompt(
        task: AgentTask,
        screen: ScreenUnderstanding,
        previousActions: List<AgentAction>,
        stepCount: Int,
        context: Context
    ): String {
        val reflectionSummary = AdaptiveExecutionEngine.getInstance(context)
            .getRuntimeReflectionSummary("intelligent_agent")
        return """
你是一个Android自动化助手。根据当前屏幕状态，决定下一步操作。

【用户目标】
${task.goal}

【当前屏幕】
${screen.description}

【可见元素】
${screen.visibleElements.joinToString("\n")}

【已执行步骤】(共${previousActions.size}步)
${previousActions.takeLast(5).mapIndexed { i, a -> 
    "${i+1}. ${a.type}: ${a.target} - ${a.reason}"
}.joinToString("\n")}

【当前步骤】$stepCount / ${MAX_STEPS}

【历史反思策略】
$reflectionSummary

请决定下一步操作，返回JSON格式：
{
  "type": "操作类型(CLICK/INPUT/SCROLL/BACK/HOME/WAIT/OPEN_APP/DONE)",
  "target": "目标元素文本或描述",
  "value": "输入内容或滚动方向(up/down/left/right)",
  "confidence": 0.0-1.0的置信度,
  "reason": "为什么执行这个操作"
}

规则：
1. 如果目标已完成，返回type="DONE"
2. 如果找不到目标元素，可能需要SCROLL
3. 如果需要打开应用，使用OPEN_APP
4. confidence低于0.5时要谨慎
5. 只返回JSON，不要其他内容
""".trimIndent()
    }
    
    private fun parseActionFromResponse(response: String): AgentAction {
        try {
            // 提取JSON部分
            val jsonStr = response
                .substringAfter("{")
                .substringBeforeLast("}")
                .let { "{$it}" }
            
            // 解析JSON
            val jsonElement = json.parseToJsonElement(jsonStr)
            val obj = jsonElement as? kotlinx.serialization.json.JsonObject
                ?: return defaultWaitAction("无法解析响应")
            
            return AgentAction(
                type = obj["type"]?.toString()?.trim('"') ?: "WAIT",
                target = obj["target"]?.toString()?.trim('"') ?: "",
                value = obj["value"]?.toString()?.trim('"') ?: "",
                confidence = obj["confidence"]?.toString()?.toFloatOrNull() ?: 0.5f,
                reason = obj["reason"]?.toString()?.trim('"') ?: ""
            )
            
        } catch (e: Exception) {
            LogManager.e(TAG, "解析LLM响应失败: $response", e)
            return defaultWaitAction("解析失败")
        }
    }
    
    private fun defaultWaitAction(reason: String) = AgentAction(
        type = "WAIT",
        value = "1000",
        confidence = 0.3f,
        reason = reason
    )
    
    private data class RuntimeActionPlan(
        val action: AgentAction,
        val waitAfterMs: Long
    )

    private fun buildRuntimeActionPlan(action: AgentAction, context: Context): RuntimeActionPlan {
        return try {
            val currentType = action.type.trim().uppercase().ifBlank { "WAIT" }
            val normalizedAction = action.copy(type = currentType)
            val advice = AdaptiveExecutionEngine.getInstance(context).getRuntimeOptimizationAdvice(
                scope = "intelligent_agent",
                action = currentType,
                target = normalizedAction.target.takeIf { it.isNotBlank() }
            )
            val normalizedType = normalizePlannedActionType(currentType, advice.suggestedAction)
            val plannedAction = if (normalizedType == currentType) {
                normalizedAction
            } else {
                normalizedAction.copy(type = normalizedType)
            }
            RuntimeActionPlan(
                action = plannedAction,
                waitAfterMs = advice.waitAfterMs.coerceAtLeast(0L)
            )
        } catch (e: Exception) {
            LogManager.e(TAG, "获取运行时优化建议失败", e)
            RuntimeActionPlan(action = action, waitAfterMs = 0L)
        }
    }

    private fun normalizePlannedActionType(originalType: String, suggestedAction: String): String {
        val fallback = originalType.trim().uppercase().ifBlank { "WAIT" }
        val candidate = suggestedAction.trim().uppercase().ifBlank { fallback }
        return when (candidate) {
            "CLICK_FUZZY" -> "CLICK"
            "LAUNCH", "LAUNCH_APP", "OPEN APP" -> "OPEN_APP"
            "INPUT_TEXT", "TYPE" -> "INPUT"
            "SWIPE_UP", "SWIPE_DOWN", "SWIPE" -> "SCROLL"
            "PRESS_BACK" -> "BACK"
            "STOP" -> "STOP"
            else -> if (candidate in setOf("CLICK", "INPUT", "SCROLL", "BACK", "HOME", "WAIT", "OPEN_APP", "DONE", "STOP")) candidate else fallback
        }
    }

    // ==================== 行动模块 ====================
    
    /**
     * ⚡ 执行具体操作
     */
    private suspend fun executeAction(action: AgentAction, context: Context): ActionResult {
        return withContext(Dispatchers.Default) {
            try {
                val result = when (action.type.uppercase()) {
                    "CLICK" -> executeClick(action.target, context)
                    "INPUT" -> executeInput(action.target, action.value, context)
                    "SCROLL" -> executeScroll(action.value, context)
                    "BACK" -> executeBack(context)
                    "HOME" -> executeHome(context)
                    "WAIT" -> {
                        delay(action.value.toLongOrNull() ?: 1000L)
                        ActionResult(true)
                    }
                    "OPEN_APP" -> executeOpenApp(action.target, context)
                    "DONE" -> ActionResult(true)
                    "STOP" -> ActionResult(true)
                    else -> ActionResult(false, "未知操作类型: ${action.type}")
                }
                result
            } catch (e: Exception) {
                LogManager.e(TAG, "执行操作失败", e)
                ActionResult(false, e.message)
            }
        }
    }
    
    private suspend fun executeClick(target: String, context: Context): ActionResult {
        val service = CoreAccessibilityService.instance
            ?: return ActionResult(false, "无障碍服务未连接")
        
        // 查找目标元素
        val rootNode = service.rootInActiveWindow
            ?: return ActionResult(false, "无法获取界面")
        
        val targetNode = findNodeByText(rootNode, target)
        
        return if (targetNode != null) {
            val clicked = targetNode.performAction(
                android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK
            )
            
            if (clicked) {
                ActionResult(true)
            } else {
                // 尝试点击父节点
                ActionResult(false, "元素不可点击")
            }
        } else {
            ActionResult(false, "未找到元素: $target")
        }
    }
    
    private fun findNodeByText(
        root: android.view.accessibility.AccessibilityNodeInfo,
        text: String
    ): android.view.accessibility.AccessibilityNodeInfo? {
        // 精确匹配
        root.findAccessibilityNodeInfosByText(text).firstOrNull()?.let { return it }
        
        // 模糊匹配
        fun searchNode(node: android.view.accessibility.AccessibilityNodeInfo?): android.view.accessibility.AccessibilityNodeInfo? {
            if (node == null) return null
            
            val nodeText = node.text?.toString() ?: ""
            val nodeDesc = node.contentDescription?.toString() ?: ""
            
            if (nodeText.contains(text, ignoreCase = true) || 
                nodeDesc.contains(text, ignoreCase = true)) {
                return node
            }
            
            for (i in 0 until node.childCount) {
                val result = searchNode(node.getChild(i))
                if (result != null) return result
            }
            
            return null
        }
        
        return searchNode(root)
    }
    
    private suspend fun executeInput(target: String, value: String, context: Context): ActionResult {
        val service = CoreAccessibilityService.instance
            ?: return ActionResult(false, "无障碍服务未连接")
        
        val rootNode = service.rootInActiveWindow
            ?: return ActionResult(false, "无法获取界面")
        
        // 查找输入框
        val inputNode = findEditableNode(rootNode, target)
        
        return if (inputNode != null) {
            // 聚焦
            inputNode.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_FOCUS)
            delay(200)
            
            // 清空
            inputNode.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_SET_TEXT,
                android.os.Bundle().apply {
                    putCharSequence(android.view.accessibility.AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
                })
            delay(100)
            
            // 输入
            inputNode.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_SET_TEXT,
                android.os.Bundle().apply {
                    putCharSequence(android.view.accessibility.AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value)
                })
            
            ActionResult(true)
        } else {
            ActionResult(false, "未找到输入框")
        }
    }
    
    private fun findEditableNode(
        root: android.view.accessibility.AccessibilityNodeInfo,
        hint: String
    ): android.view.accessibility.AccessibilityNodeInfo? {
        fun searchNode(node: android.view.accessibility.AccessibilityNodeInfo?): android.view.accessibility.AccessibilityNodeInfo? {
            if (node == null) return null
            
            if (node.isEditable) {
                val nodeText = node.text?.toString() ?: ""
                val nodeHint = node.hintText?.toString() ?: ""
                
                if (hint.isBlank() || nodeText.contains(hint, true) || nodeHint.contains(hint, true)) {
                    return node
                }
            }
            
            for (i in 0 until node.childCount) {
                val result = searchNode(node.getChild(i))
                if (result != null) return result
            }
            
            return null
        }
        
        return searchNode(root)
    }
    
    private suspend fun executeScroll(direction: String, context: Context): ActionResult {
        val result = SmartAutomationManager.swipe(
            direction = direction.uppercase().ifBlank { "DOWN" },
            distance = 500f
        )
        
        return when (result) {
            is SmartAutomationManager.ExecutionResult.Success -> ActionResult(true)
            is SmartAutomationManager.ExecutionResult.Failure -> ActionResult(false, result.error)
            is SmartAutomationManager.ExecutionResult.NeedPermission -> ActionResult(false, result.description)
        }
    }
    
    private suspend fun executeBack(context: Context): ActionResult {
        val service = CoreAccessibilityService.instance
            ?: return ActionResult(false, "无障碍服务未连接")
        
        val success = service.performGlobalAction(
            android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK
        )
        
        return ActionResult(success, if (!success) "返回操作失败" else null)
    }
    
    private suspend fun executeHome(context: Context): ActionResult {
        val service = CoreAccessibilityService.instance
            ?: return ActionResult(false, "无障碍服务未连接")
        
        val success = service.performGlobalAction(
            android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME
        )
        
        return ActionResult(success, if (!success) "主页操作失败" else null)
    }
    
    private suspend fun executeOpenApp(appName: String, context: Context): ActionResult {
        return try {
            val pm = context.packageManager
            val intent = pm.getLaunchIntentForPackage(getPackageName(appName))
                ?: pm.getLaunchIntentForPackage(appName)
            
            if (intent != null) {
                intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                delay(2000) // 等待应用启动
                ActionResult(true)
            } else {
                ActionResult(false, "找不到应用: $appName")
            }
        } catch (e: Exception) {
            ActionResult(false, e.message)
        }
    }
    
    private fun getPackageName(appName: String): String {
        return when (appName.lowercase()) {
            "微信", "wechat" -> "com.tencent.mm"
            "qq" -> "com.tencent.mobileqq"
            "淘宝", "taobao" -> "com.taobao.taobao"
            "京东", "jd" -> "com.jingdong.app.mall"
            "支付宝", "alipay" -> "com.eg.android.AlipayGphone"
            "抖音", "douyin" -> "com.ss.android.ugc.aweme"
            "快手" -> "com.smile.gifmaker"
            "哔哩哔哩", "bilibili", "b站" -> "tv.danmaku.bili"
            "美团" -> "com.sankuai.meituan"
            "饿了么" -> "me.ele"
            "高德地图" -> "com.autonavi.minimap"
            "百度地图" -> "com.baidu.BaiduMap"
            "网易云音乐" -> "com.netease.cloudmusic"
            "qq音乐" -> "com.tencent.qqmusic"
            else -> appName
        }
    }
    
    // ==================== 恢复模块 ====================
    
    private suspend fun attemptRecovery(
        failedAction: AgentAction,
        error: String?,
        context: Context
    ): Boolean {
        LogManager.d(TAG, "🔧 尝试恢复: $error")
        
        return when {
            error?.contains("未找到", ignoreCase = true) == true -> {
                // 尝试滚动查找
                executeScroll("DOWN", context)
                delay(500)
                true
            }
            error?.contains("不可点击", ignoreCase = true) == true -> {
                // 尝试点击父元素
                false
            }
            else -> false
        }
    }
    
    // ==================== 学习模块 ====================
    
    private fun recordExecution(task: AgentTask, actions: List<AgentAction>, success: Boolean) {
        synchronized(historyLock) {
            executionHistory.add(ExecutionRecord(task, actions, success))
            
            // 保留最近 MAX_HISTORY_SIZE 条记录，使用 FIFO 策略
            while (executionHistory.size > MAX_HISTORY_SIZE) {
                executionHistory.removeAt(0)
            }
        }
        
        LogManager.d(TAG, "📚 记录执行: ${task.goal}, 成功=$success, 步骤=${actions.size}")
    }
    
    /**
     * 查找相似任务的历史执行
     */
    fun findSimilarExecution(goal: String): ExecutionRecord? {
        synchronized(historyLock) {
            return executionHistory
                .filter { it.success }
                .maxByOrNull { calculateSimilarity(it.task.goal, goal) }
                ?.takeIf { calculateSimilarity(it.task.goal, goal) > 0.7f }
        }
    }
    
    private fun calculateSimilarity(a: String, b: String): Float {
        val wordsA = a.lowercase().split(Regex("\\s+")).toSet()
        val wordsB = b.lowercase().split(Regex("\\s+")).toSet()
        
        val intersection = wordsA.intersect(wordsB).size
        val union = wordsA.union(wordsB).size
        
        return if (union > 0) intersection.toFloat() / union else 0f
    }
    
    // ==================== 辅助类 ====================
    
    data class ActionResult(
        val success: Boolean,
        val error: String? = null
    )
    
    sealed class AgentExecutionResult {
        data class Success(
            val message: String,
            val stepsUsed: Int,
            val actions: List<AgentAction>
        ) : AgentExecutionResult()
        
        data class Failure(
            val error: String,
            val stepsUsed: Int,
            val partialActions: List<AgentAction>
        ) : AgentExecutionResult()
        
        data class PartialSuccess(
            val message: String,
            val completedSteps: Int,
            val totalSteps: Int,
            val actions: List<AgentAction>
        ) : AgentExecutionResult()
    }
    
    // ==================== 公共API ====================
    
    /**
     * 取消当前执行
     */
    fun cancelExecution() {
        _executionState.value = AgentExecutionState.Idle
        scope.coroutineContext.cancelChildren()
    }
    
    /**
     * 清理资源（应在应用退出时调用）
     */
    fun cleanup() {
        cancelExecution()
        synchronized(historyLock) {
            executionHistory.clear()
        }
        LogManager.d(TAG, "🧹 IntelligentAgentExecutor 资源已清理")
    }
    
    /**
     * 获取执行统计
     */
    fun getStats(): Map<String, Any> {
        synchronized(historyLock) {
            val successCount = executionHistory.count { it.success }
            val totalCount = executionHistory.size
            
            return mapOf(
                "totalExecutions" to totalCount,
                "successCount" to successCount,
                "successRate" to if (totalCount > 0) successCount.toFloat() / totalCount else 0f,
                "averageSteps" to if (totalCount > 0) 
                    executionHistory.map { it.actions.size }.average() else 0.0
            )
        }
    }
}
