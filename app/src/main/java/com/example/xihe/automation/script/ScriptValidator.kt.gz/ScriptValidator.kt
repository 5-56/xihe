package com.example.xihe.automation.script

import android.content.Context
import android.graphics.Bitmap
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.core.LLMClient
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.FileOutputStream

/**
 * 🔍 脚本验证器
 * 负责执行脚本验证，记录每步结果，支持暂停/恢复/取消
 */
class ScriptValidator(
    private val context: Context,
    private val llmClient: LLMClient
) {
    companion object {
        private const val TAG = "ScriptValidator"
        private const val SCREENSHOT_DIR = "validation_screenshots"
        private const val DEFAULT_STEP_TIMEOUT_MS = 10000L
    }
    
    // 验证状态
    private val _validationState = MutableStateFlow<ValidationState>(ValidationState.Idle)
    val validationState: StateFlow<ValidationState> = _validationState.asStateFlow()
    
    // 控制标志
    @Volatile private var isPaused = false
    @Volatile private var isCancelled = false
    
    private var validationJob: Job? = null
    private val optimizer by lazy { ScriptOptimizer(context, llmClient) }
    
    /**
     * 开始验证脚本
     * @param script 要验证的脚本
     * @param onStepComplete 每步完成的回调
     * @return ValidationReport 验证报告
     */
    suspend fun startValidation(
        script: SmartScript,
        onStepComplete: (StepResult) -> Unit = {}
    ): ValidationReport = withContext(Dispatchers.Main) {
        // 重置状态
        isPaused = false
        isCancelled = false
        
        val startTime = System.currentTimeMillis()
        val stepResults = mutableListOf<StepResult>()
        val totalSteps = script.flow.steps.size
        
        _validationState.value = ValidationState.Running(0, totalSteps)
        LogManager.i(TAG, "开始验证脚本: ${script.metadata.name}, 共 $totalSteps 步")
        
        try {
            script.flow.steps.forEachIndexed { index, step ->
                // 检查取消
                if (isCancelled) {
                    LogManager.i(TAG, "验证已取消")
                    throw CancellationException("用户取消验证")
                }
                
                // 检查暂停
                while (isPaused && !isCancelled) {
                    _validationState.value = ValidationState.Paused
                    delay(100)
                }
                
                _validationState.value = ValidationState.Running(index + 1, totalSteps)
                
                // 执行步骤
                val stepResult = executeStep(step, script)
                stepResults.add(stepResult)
                onStepComplete(stepResult)
                
                // 步骤间延迟
                delay(500)
            }
            
            val executionTime = System.currentTimeMillis() - startTime
            val successCount = stepResults.count { it.success }
            val failedCount = stepResults.count { !it.success }
            
            val report = ValidationReport(
                scriptId = script.id,
                scriptName = script.metadata.name,
                totalSteps = totalSteps,
                successSteps = successCount,
                failedSteps = failedCount,
                executionTimeMs = executionTime,
                stepResults = stepResults
            )
            
            _validationState.value = ValidationState.Completed(report)
            LogManager.i(TAG, "验证完成: 成功 $successCount, 失败 $failedCount")
            
            report
        } catch (e: CancellationException) {
            val executionTime = System.currentTimeMillis() - startTime
            ValidationReport(
                scriptId = script.id,
                scriptName = script.metadata.name,
                totalSteps = totalSteps,
                successSteps = stepResults.count { it.success },
                failedSteps = stepResults.count { !it.success },
                executionTimeMs = executionTime,
                stepResults = stepResults,
                cancelled = true
            )
        } catch (e: Exception) {
            LogManager.e(TAG, "验证失败", e)
            _validationState.value = ValidationState.Failed(e.message ?: "未知错误")
            throw e
        }
    }

    
    /**
     * 暂停验证
     */
    fun pauseValidation() {
        isPaused = true
        LogManager.i(TAG, "验证已暂停")
    }
    
    /**
     * 恢复验证
     */
    fun resumeValidation() {
        isPaused = false
        LogManager.i(TAG, "验证已恢复")
    }
    
    /**
     * 取消验证
     */
    fun cancelValidation() {
        isCancelled = true
        validationJob?.cancel()
        _validationState.value = ValidationState.Idle
        LogManager.i(TAG, "验证已取消")
    }
    
    /**
     * 执行单个步骤
     */
    private suspend fun executeStep(step: SmartStep, script: SmartScript): StepResult {
        val stepStartTime = System.currentTimeMillis()
        var screenshotPath: String? = null
        var optimizationSuggestion: OptimizationSuggestion? = null
        
        try {
            val service = CoreAccessibilityService.getInstance()
            if (service == null) {
                return StepResult(
                    stepId = step.id,
                    stepDescription = getStepDescription(step),
                    success = false,
                    errorMessage = "无障碍服务未启动",
                    executionTimeMs = System.currentTimeMillis() - stepStartTime
                )
            }
            
            // 根据步骤类型执行
            val success = when (step.type) {
                StepType.ACTION -> executeAction(service, step, script)
                StepType.CONDITION -> evaluateCondition(service, step)
                StepType.DELAY -> {
                    val delayMs = step.value?.toLongOrNull() ?: 1000L
                    delay(delayMs)
                    true
                }
                StepType.LOOP -> true // Loop 由外部控制
            }
            
            val executionTime = System.currentTimeMillis() - stepStartTime
            
            if (!success) {
                // 失败时截图并分析
                val screenshot = captureScreen()
                if (screenshot != null) {
                    screenshotPath = saveScreenshot(screenshot, step.id)
                    // AI 分析错误
                    optimizationSuggestion = optimizer.analyzeError(
                        step = step,
                        screenshot = screenshot,
                        errorMessage = "步骤执行失败"
                    )
                }
            }
            
            return StepResult(
                stepId = step.id,
                stepDescription = getStepDescription(step),
                success = success,
                errorMessage = if (!success) "步骤执行失败" else null,
                screenshotPath = screenshotPath,
                executionTimeMs = executionTime,
                optimizationSuggestion = optimizationSuggestion
            )
        } catch (e: Exception) {
            LogManager.e(TAG, "执行步骤失败: ${step.id}", e)
            
            // 异常时也尝试截图
            val screenshot = captureScreen()
            if (screenshot != null) {
                screenshotPath = saveScreenshot(screenshot, step.id)
                optimizationSuggestion = optimizer.analyzeError(step, screenshot, e.message ?: "未知错误")
            }
            
            return StepResult(
                stepId = step.id,
                stepDescription = getStepDescription(step),
                success = false,
                errorMessage = e.message ?: "执行异常",
                screenshotPath = screenshotPath,
                executionTimeMs = System.currentTimeMillis() - stepStartTime,
                optimizationSuggestion = optimizationSuggestion
            )
        }
    }
    
    private suspend fun executeAction(
        service: CoreAccessibilityService,
        step: SmartStep,
        script: SmartScript
    ): Boolean {
        val action = step.action ?: return false
        val target = step.target
        val value = resolveVariable(step.value, script.variables)
        
        return when (action.uppercase()) {
            "CLICK" -> {
                if (target != null) {
                    service.findAndClick(target)
                } else false
            }
            "INPUT" -> {
                if (value != null) {
                    service.inputText(value)
                } else false
            }
            "SCROLL" -> {
                val direction = value ?: "DOWN"
                val (width, height) = service.getScreenSize()
                val startX = width / 2f
                when (direction.uppercase()) {
                    "UP" -> service.swipeAsync(startX, height * 0.7f, startX, height * 0.3f)
                    "DOWN" -> service.swipeAsync(startX, height * 0.3f, startX, height * 0.7f)
                    "LEFT" -> service.swipeAsync(width * 0.8f, height / 2f, width * 0.2f, height / 2f)
                    "RIGHT" -> service.swipeAsync(width * 0.2f, height / 2f, width * 0.8f, height / 2f)
                    else -> false
                }
            }
            "BACK" -> {
                service.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
            }
            "HOME" -> {
                service.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME)
            }
            else -> {
                LogManager.w(TAG, "未知动作类型: $action")
                false
            }
        }
    }
    
    private fun evaluateCondition(service: CoreAccessibilityService, step: SmartStep): Boolean {
        val condition = step.condition ?: return true
        
        return when (condition.type) {
            ConditionType.ELEMENT_EXISTS -> {
                // 使用 getTextElements 查找包含指定文本的元素
                service.getTextElements().any { it.text.contains(condition.pattern, ignoreCase = true) }
            }
            ConditionType.TEXT_CONTAINS -> {
                val screenText = service.getTextElements().joinToString(" ") { it.text }
                screenText.contains(condition.pattern, ignoreCase = true)
            }
            ConditionType.APP_IN_FOREGROUND -> {
                val currentPackage = service.getCurrentPackageName()
                currentPackage == condition.targetApp
            }
        }
    }
    
    private fun resolveVariable(value: String?, variables: Map<String, String>): String? {
        if (value == null) return null
        if (!value.startsWith("$")) return value
        
        val varName = value.substring(1)
        return variables[varName] ?: value
    }
    
    private fun getStepDescription(step: SmartStep): String {
        return when (step.type) {
            StepType.ACTION -> "${step.action} ${step.target ?: step.value ?: ""}"
            StepType.CONDITION -> "条件判断: ${step.condition?.pattern}"
            StepType.DELAY -> "等待 ${step.value}ms"
            StepType.LOOP -> "循环"
        }
    }
    
    /**
     * 截取屏幕
     */
    private suspend fun captureScreen(): Bitmap? {
        return try {
            CoreAccessibilityService.getInstance()?.takeScreenshotAsync()
        } catch (e: Exception) {
            LogManager.e(TAG, "截图失败", e)
            null
        }
    }
    
    /**
     * 保存截图
     */
    private fun saveScreenshot(bitmap: Bitmap, stepId: String): String? {
        return try {
            val dir = File(context.cacheDir, SCREENSHOT_DIR)
            if (!dir.exists()) dir.mkdirs()
            
            val fileName = "step_${stepId}_${System.currentTimeMillis()}.png"
            val file = File(dir, fileName)
            
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 90, out)
            }
            
            file.absolutePath
        } catch (e: Exception) {
            LogManager.e(TAG, "保存截图失败", e)
            null
        }
    }
    
    /**
     * 清理验证截图缓存
     */
    fun clearScreenshotCache() {
        try {
            val dir = File(context.cacheDir, SCREENSHOT_DIR)
            if (dir.exists()) {
                dir.deleteRecursively()
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "清理截图缓存失败", e)
        }
    }
}

// ==================== 验证状态 ====================

sealed class ValidationState {
    object Idle : ValidationState()
    data class Running(val currentStep: Int, val totalSteps: Int) : ValidationState()
    object Paused : ValidationState()
    data class Completed(val report: ValidationReport) : ValidationState()
    data class Failed(val error: String) : ValidationState()
}

// ==================== 验证报告 ====================

data class ValidationReport(
    val scriptId: String,
    val scriptName: String,
    val totalSteps: Int,
    val successSteps: Int,
    val failedSteps: Int,
    val executionTimeMs: Long,
    val stepResults: List<StepResult>,
    val timestamp: Long = System.currentTimeMillis(),
    val cancelled: Boolean = false
) {
    val successRate: Float get() = if (totalSteps > 0) successSteps.toFloat() / totalSteps else 0f
    val hasFailures: Boolean get() = failedSteps > 0
}

data class StepResult(
    val stepId: String,
    val stepDescription: String,
    val success: Boolean,
    val errorMessage: String? = null,
    val screenshotPath: String? = null,
    val executionTimeMs: Long,
    val optimizationSuggestion: OptimizationSuggestion? = null
)
