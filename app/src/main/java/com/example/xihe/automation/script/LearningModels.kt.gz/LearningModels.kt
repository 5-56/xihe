package com.example.xihe.automation.script

import kotlinx.serialization.Serializable

// ==================== 脚本解析数据模型 ====================

/**
 * 🎯 操作类型枚举
 * 定义脚本步骤支持的所有操作类型
 */
enum class ActionType {
    LAUNCH_APP,      // 启动应用
    CLICK,           // 点击
    INPUT,           // 输入文本
    SCROLL,          // 滚动
    LONG_PRESS,      // 长按
    DOUBLE_CLICK,    // 双击
    DRAG,            // 拖拽
    SYSTEM_BACK,     // 系统返回
    SYSTEM_HOME,     // 系统主页
    SYSTEM_RECENTS,  // 最近任务
    WAIT,            // 等待
    CONDITION,       // 条件判断
    SCREENSHOT,      // 截图
    UNKNOWN          // 未知类型
}

/**
 * 📝 解析错误
 */
@Serializable
data class ParseError(
    val field: String,
    val message: String,
    val line: Int? = null
)

/**
 * 🎯 解析结果密封类
 */
sealed class ParseResult {
    data class Success(val script: ParsedScript) : ParseResult()
    data class Error(val errors: List<ParseError>) : ParseResult()
}

/**
 * 📜 解析后的脚本
 * 包含完整的脚本结构信息
 */
@Serializable
data class ParsedScript(
    val metadata: ParsedScriptMetadata,
    val steps: List<ParsedStep>,
    val potentialIssues: List<PotentialIssue> = emptyList(),
    val notes: List<String> = emptyList()
) {
    /**
     * 验证脚本是否有效
     */
    fun isValid(): Boolean = metadata.name.isNotBlank() && steps.isNotEmpty()
}

/**
 * 📋 脚本元数据
 */
@Serializable
data class ParsedScriptMetadata(
    val name: String,
    val description: String = "",
    val targetPlatform: String = "Android",
    val estimatedTime: String = "",
    val difficulty: String = "",
    val version: Int = 1,
    val author: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * 🚶 解析后的步骤
 */
@Serializable
data class ParsedStep(
    val id: Int,
    val phase: String = "",
    val actionType: ActionType,
    val description: String,
    val targetElement: TargetElement? = null,
    val inputValue: String? = null,
    val expectedResult: String = "",
    val waitBefore: Long = 0,
    val waitAfter: Long = 1000,
    val errorHandling: ErrorHandling = ErrorHandling(),
    val canPause: Boolean = true
) {
    /**
     * 验证步骤是否有效
     */
    fun isValid(): Boolean = actionType != ActionType.UNKNOWN && description.isNotBlank()
}

/**
 * 🎯 目标元素
 * 描述操作的目标 UI 元素
 */
@Serializable
data class TargetElement(
    val description: String = "",
    val position: String? = null,
    val text: String? = null,
    val resourceId: String? = null,
    val contentDescription: String? = null,
    val className: String? = null,
    val bounds: ElementBounds? = null
) {
    /**
     * 检查是否有有效的定位信息
     */
    fun hasValidLocator(): Boolean = 
        !text.isNullOrBlank() || 
        !resourceId.isNullOrBlank() || 
        !contentDescription.isNullOrBlank() ||
        bounds != null
}

/**
 * 📐 元素边界
 */
@Serializable
data class ElementBounds(
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int
) {
    val centerX: Int get() = (left + right) / 2
    val centerY: Int get() = (top + bottom) / 2
    val width: Int get() = right - left
    val height: Int get() = bottom - top
}

/**
 * ⚠️ 错误处理配置
 */
@Serializable
data class ErrorHandling(
    val strategy: ErrorStrategy = ErrorStrategy.RETRY,
    val maxRetries: Int = 2,
    val retryInterval: Long = 1000,
    val onFailure: FailureAction = FailureAction.STOP
)

/**
 * 错误处理策略
 */
enum class ErrorStrategy {
    RETRY,           // 重试
    SKIP,            // 跳过
    STOP,            // 停止
    FALLBACK,        // 使用备选方案
    ASK_USER         // 询问用户
}

/**
 * 失败后的动作
 */
enum class FailureAction {
    STOP,            // 停止执行
    CONTINUE,        // 继续下一步
    ROLLBACK,        // 回滚
    NOTIFY           // 通知用户
}

/**
 * 🔍 潜在问题
 */
@Serializable
data class PotentialIssue(
    val id: Int,
    val description: String,
    val category: IssueCategory,
    val severity: IssueSeverity,
    val solution: String = "",
    val prevention: String = ""
)

/**
 * 问题类别
 */
enum class IssueCategory {
    NETWORK,         // 网络问题
    UI,              // 界面问题
    SYSTEM,          // 系统问题
    APP,             // 应用问题
    DATA,            // 数据问题
    SECURITY,        // 安全问题
    PERFORMANCE,     // 性能问题
    OTHER            // 其他
}

/**
 * 问题严重程度
 */
enum class IssueSeverity {
    MINOR,           // 轻微
    MEDIUM,          // 中等
    MAJOR,           // 重大
    FATAL            // 致命
}


// ==================== 执行相关数据模型 ====================

/**
 * ❌ 失败类型枚举
 */
enum class FailureType {
    ELEMENT_NOT_FOUND,    // 元素未找到
    TIMEOUT,              // 超时
    WRONG_SCREEN,         // 错误的界面
    POPUP_INTERFERENCE,   // 弹窗干扰
    PERMISSION_DENIED,    // 权限不足
    APP_CRASH,            // 应用崩溃
    APP_NOT_FOUND,        // 应用未安装
    NETWORK_ERROR,        // 网络错误
    INPUT_FAILED,         // 输入失败
    GESTURE_FAILED,       // 手势执行失败
    VALIDATION_FAILED,    // 验证失败
    UNKNOWN               // 未知错误
}

/**
 * 📊 执行状态
 */
enum class ExecutionStatus {
    PENDING,              // 等待执行
    RUNNING,              // 执行中
    PAUSED,               // 已暂停
    SUCCESS,              // 成功
    FAILED,               // 失败
    SKIPPED,              // 已跳过
    CANCELLED,            // 已取消
    RETRYING              // 重试中
}

/**
 * ❌ 步骤错误
 */
@Serializable
data class StepError(
    val type: FailureType,
    val message: String,
    val details: String? = null,
    val recoverable: Boolean = true,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * 📈 执行进度
 */
data class ExecutionProgress(
    val currentStep: Int,
    val totalSteps: Int,
    val stepDescription: String,
    val status: ExecutionStatus,
    val elapsedTime: Long = 0,
    val retryCount: Int = 0
) {
    val progressPercent: Float get() = 
        if (totalSteps > 0) currentStep.toFloat() / totalSteps else 0f
}

/**
 * 📋 步骤执行结果
 */
@Serializable
data class StepExecutionResult(
    val stepId: Int,
    val stepDescription: String,
    val success: Boolean,
    val error: StepError? = null,
    val beforeScreenshotPath: String? = null,
    val afterScreenshotPath: String? = null,
    val duration: Long = 0,
    val retryCount: Int = 0,
    val optimizationsApplied: List<String> = emptyList(),
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * 📊 执行结果
 */
@Serializable
data class ExecutionResult(
    val sessionId: String,
    val scriptName: String,
    val stepResults: List<StepExecutionResult>,
    val overallSuccess: Boolean,
    val successRate: Float,
    val totalDuration: Long,
    val optimizationsApplied: Int = 0,
    val startTime: Long,
    val endTime: Long,
    val needsManualIntervention: Boolean = false,
    val failedStepIds: List<Int> = emptyList()
) {
    companion object {
        /**
         * 计算成功率
         */
        fun calculateSuccessRate(results: List<StepExecutionResult>): Float {
            if (results.isEmpty()) return 0f
            return results.count { it.success }.toFloat() / results.size
        }
    }
}

/**
 * ✅ 验证结果密封类
 */
sealed class ValidationResult {
    object Success : ValidationResult()
    
    data class Failure(
        val type: FailureType,
        val message: String,
        val details: List<String> = emptyList()
    ) : ValidationResult()
}

/**
 * 🖼️ 屏幕状态
 * 用于执行前后的屏幕对比
 */
data class ScreenState(
    val packageName: String?,
    val activityName: String?,
    val elements: List<ScreenElementInfo>,
    val screenshotPath: String?,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * 📱 屏幕元素信息
 */
@Serializable
data class ScreenElementInfo(
    val text: String,
    val resourceId: String?,
    val className: String,
    val bounds: ElementBounds?,
    val isClickable: Boolean,
    val isEditable: Boolean,
    val contentDescription: String?
)


// ==================== 优化相关数据模型 ====================

/**
 * 🔧 优化类型
 */
enum class OptimizationType {
    SWITCH_LOCATOR,       // 切换定位策略
    INCREASE_WAIT,        // 增加等待时间
    DECREASE_WAIT,        // 减少等待时间
    ADJUST_COORDINATES,   // 调整坐标
    HANDLE_POPUP,         // 处理弹窗
    CHANGE_ACTION,        // 更改操作类型
    ADD_PRECONDITION,     // 添加前置条件
    AI_REANALYZE          // AI 重新分析
}

/**
 * 💡 脚本优化建议
 * 用于 AI 自学习脚本系统
 */
@Serializable
data class ScriptOptimizationSuggestion(
    val type: OptimizationType,
    val changes: Map<String, String>,
    val description: String,
    val confidence: Float = 0.8f,
    val reason: String = "",
    val timestamp: Long = System.currentTimeMillis()
) {
    /**
     * 检查建议是否有效
     */
    fun isValid(): Boolean = changes.isNotEmpty() && confidence > 0
}

/**
 * 📝 优化记录
 */
@Serializable
data class OptimizationRecord(
    val timestamp: Long,
    val stepId: Int,
    val optimizationType: OptimizationType,
    val originalParams: Map<String, String>,
    val optimizedParams: Map<String, String>,
    val reason: String,
    val success: Boolean,
    val retryNumber: Int = 0
)

/**
 * 🔍 失败分析结果
 */
data class FailureAnalysis(
    val failureType: FailureType,
    val possibleCauses: List<String>,
    val suggestedActions: List<OptimizationType>,
    val confidence: Float,
    val aiAnalysis: String? = null
)


// ==================== 学习会话数据模型 ====================

/**
 * 📊 会话状态
 */
enum class SessionStatus {
    IN_PROGRESS,          // 进行中
    COMPLETED_SUCCESS,    // 完全成功
    COMPLETED_PARTIAL,    // 部分成功
    COMPLETED_FAILED,     // 完全失败
    CANCELLED,            // 已取消
    PAUSED,               // 已暂停
    WAITING_INPUT         // 等待用户输入
}

/**
 * 📝 执行日志
 */
@Serializable
data class ExecutionLog(
    val timestamp: Long,
    val stepId: Int,
    val action: String,
    val result: String,
    val screenshotPath: String? = null,
    val details: String? = null,
    val level: LogLevel = LogLevel.INFO
)

/**
 * 日志级别
 */
enum class LogLevel {
    DEBUG,
    INFO,
    WARNING,
    ERROR
}

/**
 * 🎓 学习会话
 * 记录完整的学习-执行-优化过程
 */
@Serializable
data class LearningSession(
    val id: String,
    val scriptName: String,
    val inputScript: String,
    val parsedScript: ParsedScript? = null,
    val startTime: Long,
    var endTime: Long? = null,
    val executionLogs: MutableList<ExecutionLog> = mutableListOf(),
    val optimizationHistory: MutableList<OptimizationRecord> = mutableListOf(),
    val stepResults: MutableList<StepExecutionResult> = mutableListOf(),
    var status: SessionStatus = SessionStatus.IN_PROGRESS,
    var currentStepIndex: Int = 0,
    var totalRetries: Int = 0,
    var successfulSteps: Int = 0,
    var failedSteps: Int = 0
) {
    /**
     * 添加执行日志
     */
    fun addLog(stepId: Int, action: String, result: String, level: LogLevel = LogLevel.INFO) {
        executionLogs.add(ExecutionLog(
            timestamp = System.currentTimeMillis(),
            stepId = stepId,
            action = action,
            result = result,
            level = level
        ))
    }
    
    /**
     * 添加优化记录
     */
    fun addOptimization(record: OptimizationRecord) {
        optimizationHistory.add(record)
    }
    
    /**
     * 计算成功率
     */
    fun getSuccessRate(): Float {
        val total = successfulSteps + failedSteps
        return if (total > 0) successfulSteps.toFloat() / total else 0f
    }
    
    /**
     * 获取会话持续时间
     */
    fun getDuration(): Long {
        val end = endTime ?: System.currentTimeMillis()
        return end - startTime
    }
    
    /**
     * 检查会话是否完成
     */
    fun isCompleted(): Boolean = status in listOf(
        SessionStatus.COMPLETED_SUCCESS,
        SessionStatus.COMPLETED_PARTIAL,
        SessionStatus.COMPLETED_FAILED,
        SessionStatus.CANCELLED
    )
    
    /**
     * 生成执行结果
     */
    fun toExecutionResult(): ExecutionResult {
        return ExecutionResult(
            sessionId = id,
            scriptName = scriptName,
            stepResults = stepResults.toList(),
            overallSuccess = status == SessionStatus.COMPLETED_SUCCESS,
            successRate = getSuccessRate(),
            totalDuration = getDuration(),
            optimizationsApplied = optimizationHistory.size,
            startTime = startTime,
            endTime = endTime ?: System.currentTimeMillis(),
            needsManualIntervention = status == SessionStatus.WAITING_INPUT,
            failedStepIds = stepResults.filter { !it.success }.map { it.stepId }
        )
    }
}

/**
 * 🎓 学习结果密封类
 */
sealed class LearnResult {
    data class Success(val executableScript: ExecutableScript) : LearnResult()
    data class Error(val message: String, val details: String? = null) : LearnResult()
}

/**
 * 📜 可执行脚本
 * 经过学习器处理后可以直接执行的脚本
 */
@Serializable
data class ExecutableScript(
    val metadata: ParsedScriptMetadata,
    val steps: List<ExecutableStep>,
    val globalErrorHandlers: List<GlobalErrorHandler> = emptyList()
)

/**
 * 🚶 可执行步骤
 */
@Serializable
data class ExecutableStep(
    val originalStep: ParsedStep,
    val locatorStrategies: List<LocatorStrategyConfig>,
    val intent: StepIntent,
    val validators: List<ValidatorConfig>,
    val optimizedParams: MutableMap<String, String> = mutableMapOf()
)

/**
 * 🎯 定位策略配置
 */
@Serializable
data class LocatorStrategyConfig(
    val type: LocatorType,
    val value: String,
    val priority: Int = 0,
    val fallbackValue: String? = null
)

/**
 * 定位类型
 */
enum class LocatorType {
    TEXT,              // 文本匹配
    RESOURCE_ID,       // Resource ID
    CONTENT_DESC,      // Content Description
    POSITION,          // 位置坐标
    CLASS_NAME,        // 类名
    AI_DYNAMIC         // AI 动态定位
}

/**
 * 🎯 步骤意图
 */
@Serializable
data class StepIntent(
    val primaryAction: ActionType,
    val targetApp: String? = null,
    val targetScreen: String? = null,
    val expectedOutcome: String = ""
)

/**
 * ✅ 验证器配置
 */
@Serializable
data class ValidatorConfig(
    val type: ValidatorType,
    val expectedValue: String,
    val timeout: Long = 5000
)

/**
 * 验证器类型
 */
enum class ValidatorType {
    ELEMENT_EXISTS,        // 元素存在
    ELEMENT_NOT_EXISTS,    // 元素不存在
    TEXT_CONTAINS,         // 文本包含
    SCREEN_CHANGED,        // 屏幕变化
    APP_IN_FOREGROUND,     // 应用在前台
    CUSTOM                 // 自定义
}

/**
 * 🛡️ 全局错误处理器
 */
@Serializable
data class GlobalErrorHandler(
    val triggerCondition: String,
    val action: ErrorHandlerAction,
    val priority: Int = 0
)

/**
 * 错误处理器动作
 */
enum class ErrorHandlerAction {
    DISMISS_POPUP,         // 关闭弹窗
    GRANT_PERMISSION,      // 授予权限
    RETRY_STEP,            // 重试步骤
    SKIP_STEP,             // 跳过步骤
    STOP_EXECUTION,        // 停止执行
    NOTIFY_USER            // 通知用户
}
