package com.example.xihe

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.Manifest
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.content.pm.PackageManager
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.xihe.core.EngineStateManager
import com.example.xihe.core.EmotionSystem
import com.example.xihe.core.ModuleCoordinator
import com.example.xihe.core.AutomationEngine
import com.example.xihe.core.model.ChatMessageDisplay
import com.example.xihe.ui.components.AnimatedMessageBubble
import com.example.xihe.ui.theme.DeepSpaceBlue
import com.example.xihe.ui.theme.NeonCyan
import com.example.xihe.ui.theme.StatusColors
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.roundToInt

/**
 * 🫧 悬浮窗服务
 * 
 * 提供系统级悬浮气泡，可以在其他应用上方显示
 * 支持拖拽、展开/收起、实时对话等功能
 */
class OverlayService : Service(), LifecycleOwner, SavedStateRegistryOwner {

    companion object {
        private const val TAG = "OverlayService"
        private const val CHANNEL_ID = "overlay_service_channel"
        private const val NOTIFICATION_ID = 1001

        // 实时对话模式请求
        private val _callModeRequest = MutableStateFlow(false)
        val callModeRequest = _callModeRequest.asStateFlow()

        fun requestCallMode() {
            _callModeRequest.value = true
        }

        fun dismissCallMode() {
            _callModeRequest.value = false
        }
    }

    private var windowManager: WindowManager? = null
    private var floatingView: ComposeView? = null

    private lateinit var lifecycleRegistry: LifecycleRegistry
    private lateinit var savedStateRegistryController: SavedStateRegistryController

    override val lifecycle: Lifecycle
        get() = lifecycleRegistry

    override val savedStateRegistry: SavedStateRegistry
        get() = savedStateRegistryController.savedStateRegistry

    override fun onCreate() {
        super.onCreate()
        LogManager.d(TAG, "OverlayService 创建")

        lifecycleRegistry = LifecycleRegistry(this)
        savedStateRegistryController = SavedStateRegistryController.create(this)

        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.currentState = Lifecycle.State.CREATED

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, createNotification())

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showFloatingBubble()

        lifecycleRegistry.currentState = Lifecycle.State.STARTED
        lifecycleRegistry.currentState = Lifecycle.State.RESUMED
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        LogManager.d(TAG, "OverlayService 启动命令")
        
        // 检查是否需要启动通话模式
        if (intent?.getBooleanExtra("start_call_mode", false) == true) {
            requestCallMode()
        }
        
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        LogManager.d(TAG, "OverlayService 销毁")

        lifecycleRegistry.currentState = Lifecycle.State.DESTROYED

        floatingView?.let {
            try {
                windowManager?.removeView(it)
            } catch (e: Exception) {
                LogManager.e(TAG, "移除悬浮窗失败", e)
            }
        }
        floatingView = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "羲和悬浮窗服务",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "用于显示悬浮窗的后台服务"
            }

            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("羲和 AI 助手")
            .setContentText("悬浮窗服务运行中")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun showFloatingBubble() {
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 300
        }

        floatingView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@OverlayService)
            setViewTreeSavedStateRegistryOwner(this@OverlayService)

            setContent {
                FloatingBubble(
                    onDrag = { deltaX, deltaY ->
                        params.x += deltaX.roundToInt()
                        params.y += deltaY.roundToInt()
                        windowManager?.updateViewLayout(this, params)
                    },
                    onClose = {
                        stopSelf()
                    },
                    onExpandChange = { expanded ->
                        // 展开时允许键盘焦点，收起时禁用焦点
                        params.flags = if (expanded) {
                            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        } else {
                            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        }
                        try {
                            windowManager?.updateViewLayout(this, params)
                        } catch (e: Exception) {
                            LogManager.w(TAG, "更新窗口焦点状态失败", e)
                        }
                    }
                )
            }
        }

        try {
            windowManager?.addView(floatingView, params)
            LogManager.d(TAG, "悬浮窗添加成功")
        } catch (e: Exception) {
            LogManager.e(TAG, "添加悬浮窗失败", e)
        }
    }
}

/**
 * 🫧 悬浮气泡组件
 */
@Composable
fun FloatingBubble(
    onDrag: (Float, Float) -> Unit,
    onClose: () -> Unit,
    onExpandChange: (Boolean) -> Unit = {}
) {
    var isExpanded by remember { mutableStateOf(false) }
    var inputText by remember { mutableStateOf("") }

    // 状态
    val messages by EngineStateManager.messages.collectAsStateWithLifecycle()
    val status by EngineStateManager.status.collectAsStateWithLifecycle()
    val taskProgress by EngineStateManager.taskProgress.collectAsStateWithLifecycle()
    val currentMood by EmotionSystem.currentMood.collectAsStateWithLifecycle()

    // 通话模式
    val callModeRequested by OverlayService.callModeRequest.collectAsStateWithLifecycle()

    // 展开状态改变时通知父组件
    LaunchedEffect(isExpanded) {
        onExpandChange(isExpanded)
    }

    LaunchedEffect(callModeRequested) {
        if (callModeRequested) {
            isExpanded = true
        }
    }

    val context = LocalContext.current

    Box(
        modifier = Modifier
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    if (!isExpanded) {
                        onDrag(dragAmount.x, dragAmount.y)
                    }
                }
            }
    ) {
        AnimatedContent(
            targetState = isExpanded,
            transitionSpec = {
                fadeIn(animationSpec = tween(300)) togetherWith
                        fadeOut(animationSpec = tween(300))
            },
            label = "bubble_expand"
        ) { expanded ->
            if (expanded) {
                // 展开状态 - 完整聊天界面
                ExpandedChatPanel(
                    messages = messages,
                    status = status,
                    inputText = inputText,
                    onInputChange = { inputText = it },
                    onSend = {
                        if (inputText.isNotBlank()) {
                            AutomationEngine.start(inputText, context)
                            inputText = ""
                        }
                    },
                    onCollapse = { 
                        isExpanded = false
                        OverlayService.dismissCallMode()
                    },
                    onClose = onClose
                )
            } else {
                // 收起状态 - 小气泡
                CollapsedBubble(
                    mood = currentMood.name.lowercase(),
                    status = status,
                    progress = if (taskProgress.totalSteps > 0) 
                        taskProgress.currentStep.toFloat() / taskProgress.totalSteps else 0f,
                    onClick = { isExpanded = true }
                )
            }
        }
    }
}

/**
 * 🔵 收起状态的小气泡
 */
@Composable
fun CollapsedBubble(
    mood: String,
    status: String,
    progress: Float,
    onClick: () -> Unit
) {
    val moodColor = when (mood.uppercase()) {
        "EXCITED" -> Color(0xFFFFD700)
        "HAPPY" -> Color(0xFF00E676)
        "PROUD" -> NeonCyan.Primary
        "TIRED" -> Color(0xFFFF9800)
        "SAD" -> Color(0xFF9E9E9E)
        "WORRIED" -> Color(0xFFFF5722)
        else -> NeonCyan.Primary
    }

    val isWorking = status != "Idle" && status != "完成" && status != "就绪"

    // 脉冲动画
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isWorking) 1.1f else 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isWorking) 500 else 2000),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Box(
        modifier = Modifier
            .size((56 * scale).dp)
            .shadow(8.dp, CircleShape)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    colors = listOf(moodColor.copy(alpha = 0.9f), moodColor.copy(alpha = 0.6f))
                )
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (isWorking && progress > 0) {
            // 显示进度
            CircularProgressIndicator(
                progress = { progress },
                modifier = Modifier.size(48.dp),
                color = Color.White,
                strokeWidth = 3.dp,
                trackColor = Color.White.copy(alpha = 0.3f)
            )
            Text(
                text = "${(progress * 100).toInt()}%",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        } else {
            // 显示表情
            Text(
                text = when (mood.uppercase()) {
                    "EXCITED" -> "✨"
                    "HAPPY" -> "😊"
                    "PROUD" -> "😎"
                    "TIRED" -> "😴"
                    "SAD" -> "😢"
                    "WORRIED" -> "😟"
                    else -> "🤖"
                },
                fontSize = 24.sp
            )
        }
    }
}

/**
 * 📱 展开状态的聊天面板
 */
@Composable
fun ExpandedChatPanel(
    messages: List<ChatMessageDisplay>,
    status: String,
    inputText: String,
    onInputChange: (String) -> Unit,
    onSend: () -> Unit,
    onCollapse: () -> Unit,
    onClose: () -> Unit
) {
    val listState = rememberLazyListState()
    val displayedMessages = remember(messages) { messages.takeLast(15) }
    var isRealTimeDialogue by remember { mutableStateOf(false) }
    val context = LocalContext.current

    LaunchedEffect(displayedMessages.size) {
        if (displayedMessages.isNotEmpty()) {
            listState.animateScrollToItem(displayedMessages.size - 1)
        }
    }

    Card(
        modifier = Modifier
            .width(320.dp)
            .height(420.dp)
            .shadow(24.dp, RoundedCornerShape(24.dp)),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = DeepSpaceBlue.Primary),
        border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan.Primary.copy(alpha = 0.2f))
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // 顶部状态栏 (霓虹渐变)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(DeepSpaceBlue.Secondary, DeepSpaceBlue.Tertiary)
                        )
                    )
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Surface(shape = CircleShape, color = NeonCyan.Primary.copy(alpha = 0.1f), modifier = Modifier.size(32.dp)) {
                            Box(contentAlignment = Alignment.Center) { Text("🤖", fontSize = 16.sp) }
                        }
                        Column {
                            Text("羲和助手", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text(status, fontSize = 9.sp, color = NeonCyan.Primary, maxLines = 1)
                        }
                    }

                    Row {
                        IconButton(
                            onClick = {
                                val hasPermission = ContextCompat.checkSelfPermission(
                                    context,
                                    Manifest.permission.RECORD_AUDIO
                                ) == PackageManager.PERMISSION_GRANTED

                                if (!hasPermission) {
                                    Toast.makeText(context, "请先授予录音权限", Toast.LENGTH_SHORT).show()
                                    return@IconButton
                                }

                                if (!ModuleCoordinator.isModuleAvailable("Voice")) {
                                    Toast.makeText(context, "语音模块未初始化", Toast.LENGTH_SHORT).show()
                                    return@IconButton
                                }

                                val enable = !isRealTimeDialogue
                                isRealTimeDialogue = enable
                                if (enable) {
                                    ModuleCoordinator.startContinuousVoiceRecognition()
                                } else {
                                    ModuleCoordinator.stopContinuousVoiceRecognition()
                                }
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = if (isRealTimeDialogue) Icons.Default.Stop else Icons.Default.Mic,
                                contentDescription = if (isRealTimeDialogue) "关闭实时对话" else "开启实时对话",
                                tint = NeonCyan.Primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        IconButton(onClick = onCollapse, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Remove, "收起", tint = Color.White.copy(alpha = 0.7f), modifier = Modifier.size(18.dp))
                        }
                        IconButton(onClick = onClose, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Close, "关闭", tint = StatusColors.Error.copy(alpha = 0.7f), modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            // 🚀 核心优化：使用与主 App 完全一致的动画气泡组件
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(bottom = 12.dp)
            ) {
                items(displayedMessages) { message ->
                    AnimatedMessageBubble(
                        message = message.content,
                        isUser = message.isUser,
                        showTypingEffect = false, // 悬浮窗追求即时性，不显示打字机
                        thinkingContent = message.thinkingContent
                    )
                }
            }

            // 输入区域 (紧凑版)
            Surface(
                color = DeepSpaceBlue.Secondary,
                tonalElevation = 4.dp
            ) {
                Row(
                    modifier = Modifier.padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = inputText,
                        onValueChange = onInputChange,
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("命令...", color = Color.Gray, fontSize = 12.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = NeonCyan.Primary,
                            unfocusedBorderColor = Color.Transparent,
                            focusedContainerColor = DeepSpaceBlue.Light,
                            unfocusedContainerColor = DeepSpaceBlue.Light
                        ),
                        shape = RoundedCornerShape(20.dp),
                        singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { onSend() })
                    )

                    FloatingActionButton(
                        onClick = onSend,
                        modifier = Modifier.size(40.dp),
                        containerColor = NeonCyan.Primary,
                        shape = CircleShape
                    ) {
                        Icon(Icons.Default.Send, "发送", tint = Color.Black, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}
