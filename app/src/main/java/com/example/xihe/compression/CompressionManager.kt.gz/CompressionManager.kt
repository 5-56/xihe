package com.example.xihe.compression

import android.content.Context
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.*
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * 🗜️ 文件压缩管理器
 * 提供ZIP压缩和解压功能
 */
class CompressionManager private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "CompressionManager"
        private const val BUFFER_SIZE = 8192
        
        @Volatile
        private var instance: CompressionManager? = null
        
        fun getInstance(context: Context): CompressionManager {
            return instance ?: synchronized(this) {
                instance ?: CompressionManager(context.applicationContext).also { instance = it }
            }
        }
    }
    
    /**
     * 压缩结果
     */
    data class CompressionResult(
        val success: Boolean,
        val outputPath: String? = null,
        val originalSize: Long = 0,
        val compressedSize: Long = 0,
        val compressionRatio: Float = 0f,
        val errorMessage: String? = null
    ) {
        fun getCompressionRatioFormatted(): String {
            return "${"%.1f".format(compressionRatio)}%"
        }
    }
    
    /**
     * 解压结果
     */
    data class ExtractionResult(
        val success: Boolean,
        val extractedFiles: Int = 0,
        val outputDir: String? = null,
        val errorMessage: String? = null
    )
    
    // ==================== 压缩功能 ====================
    
    /**
     * 🗜️ 压缩文件
     */
    suspend fun compressFile(
        inputPath: String,
        outputPath: String? = null
    ): CompressionResult = withContext(Dispatchers.IO) {
        try {
            val inputFile = File(inputPath)
            if (!inputFile.exists()) {
                return@withContext CompressionResult(false, errorMessage = "输入文件不存在")
            }
            
            val actualOutputPath = outputPath ?: "${inputPath}.zip"
            val outputFile = File(actualOutputPath)
            
            val originalSize = inputFile.length()
            
            ZipOutputStream(BufferedOutputStream(FileOutputStream(outputFile))).use { zos ->
                if (inputFile.isDirectory) {
                    compressDirectory(inputFile, inputFile.name, zos)
                } else {
                    compressFileToZip(inputFile, inputFile.name, zos)
                }
            }
            
            val compressedSize = outputFile.length()
            val ratio = if (originalSize > 0) {
                ((originalSize - compressedSize).toFloat() / originalSize) * 100
            } else 0f
            
            LogManager.i(TAG, "✅ 压缩完成: $inputPath -> $actualOutputPath")
            CompressionResult(
                success = true,
                outputPath = actualOutputPath,
                originalSize = originalSize,
                compressedSize = compressedSize,
                compressionRatio = ratio
            )
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 压缩失败", e)
            CompressionResult(false, errorMessage = e.message)
        }
    }
    
    /**
     * 🗜️ 压缩多个文件
     */
    suspend fun compressFiles(
        inputPaths: List<String>,
        outputPath: String
    ): CompressionResult = withContext(Dispatchers.IO) {
        try {
            val outputFile = File(outputPath)
            var totalOriginalSize = 0L
            
            ZipOutputStream(BufferedOutputStream(FileOutputStream(outputFile))).use { zos ->
                inputPaths.forEach { path ->
                    val file = File(path)
                    if (file.exists()) {
                        totalOriginalSize += file.length()
                        if (file.isDirectory) {
                            compressDirectory(file, file.name, zos)
                        } else {
                            compressFileToZip(file, file.name, zos)
                        }
                    }
                }
            }
            
            val compressedSize = outputFile.length()
            val ratio = if (totalOriginalSize > 0) {
                ((totalOriginalSize - compressedSize).toFloat() / totalOriginalSize) * 100
            } else 0f
            
            LogManager.i(TAG, "✅ 压缩${inputPaths.size}个文件完成: $outputPath")
            CompressionResult(
                success = true,
                outputPath = outputPath,
                originalSize = totalOriginalSize,
                compressedSize = compressedSize,
                compressionRatio = ratio
            )
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 压缩多个文件失败", e)
            CompressionResult(false, errorMessage = e.message)
        }
    }
    
    /**
     * 📁 压缩目录
     */
    private fun compressDirectory(dir: File, basePath: String, zos: ZipOutputStream) {
        val files = dir.listFiles() ?: return
        
        files.forEach { file ->
            val entryName = "$basePath/${file.name}"
            if (file.isDirectory) {
                compressDirectory(file, entryName, zos)
            } else {
                compressFileToZip(file, entryName, zos)
            }
        }
    }
    
    /**
     * 📄 压缩单个文件到ZIP
     */
    private fun compressFileToZip(file: File, entryName: String, zos: ZipOutputStream) {
        try {
            val entry = ZipEntry(entryName)
            zos.putNextEntry(entry)
            
            BufferedInputStream(FileInputStream(file), BUFFER_SIZE).use { bis ->
                val buffer = ByteArray(BUFFER_SIZE)
                var count: Int
                while (bis.read(buffer).also { count = it } != -1) {
                    zos.write(buffer, 0, count)
                }
            }
            
            zos.closeEntry()
        } catch (e: Exception) {
            LogManager.e(TAG, "压缩文件失败: ${file.name}", e)
        }
    }
    
    // ==================== 解压功能 ====================
    
    /**
     * 📦 解压ZIP文件
     */
    suspend fun extractZip(
        zipPath: String,
        outputDir: String? = null
    ): ExtractionResult = withContext(Dispatchers.IO) {
        try {
            val zipFile = File(zipPath)
            if (!zipFile.exists()) {
                return@withContext ExtractionResult(false, errorMessage = "ZIP文件不存在")
            }
            
            val actualOutputDir = outputDir ?: zipFile.parent ?: context.filesDir.absolutePath
            val outputDirectory = File(actualOutputDir)
            if (!outputDirectory.exists()) {
                outputDirectory.mkdirs()
            }
            
            var extractedCount = 0
            
            ZipInputStream(BufferedInputStream(FileInputStream(zipFile))).use { zis ->
                var entry: ZipEntry?
                while (zis.nextEntry.also { entry = it } != null) {
                    val currentEntry = entry ?: continue
                    val entryName = currentEntry.name
                    
                    // 防止路径遍历攻击
                    val destFile = File(outputDirectory, entryName)
                    val destDirPath = outputDirectory.canonicalPath
                    val destFilePath = destFile.canonicalPath
                    
                    if (!destFilePath.startsWith(destDirPath + File.separator)) {
                        LogManager.w(TAG, "⚠️ 检测到可疑的ZIP条目: $entryName")
                        continue
                    }
                    
                    if (currentEntry.isDirectory) {
                        destFile.mkdirs()
                    } else {
                        destFile.parentFile?.mkdirs()
                        extractFile(zis, destFile)
                        extractedCount++
                    }
                    
                    zis.closeEntry()
                }
            }
            
            LogManager.i(TAG, "✅ 解压完成: $zipPath -> $actualOutputDir ($extractedCount 个文件)")
            ExtractionResult(
                success = true,
                extractedFiles = extractedCount,
                outputDir = actualOutputDir
            )
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 解压失败", e)
            ExtractionResult(false, errorMessage = e.message)
        }
    }
    
    /**
     * 📄 解压单个文件
     */
    private fun extractFile(zis: ZipInputStream, destFile: File) {
        BufferedOutputStream(FileOutputStream(destFile), BUFFER_SIZE).use { bos ->
            val buffer = ByteArray(BUFFER_SIZE)
            var count: Int
            while (zis.read(buffer).also { count = it } != -1) {
                bos.write(buffer, 0, count)
            }
        }
    }
    
    /**
     * 📋 列出ZIP文件内容
     */
    suspend fun listZipContents(zipPath: String): List<ZipFileInfo> = withContext(Dispatchers.IO) {
        try {
            val zipFile = File(zipPath)
            if (!zipFile.exists()) {
                return@withContext emptyList()
            }
            
            val contents = mutableListOf<ZipFileInfo>()
            
            ZipInputStream(BufferedInputStream(FileInputStream(zipFile))).use { zis ->
                var entry: ZipEntry?
                while (zis.nextEntry.also { entry = it } != null) {
                    val currentEntry = entry ?: continue
                    contents.add(
                        ZipFileInfo(
                            name = currentEntry.name,
                            size = currentEntry.size,
                            compressedSize = currentEntry.compressedSize,
                            isDirectory = currentEntry.isDirectory,
                            time = currentEntry.time
                        )
                    )
                    zis.closeEntry()
                }
            }
            
            LogManager.d(TAG, "📋 ZIP文件包含${contents.size}个条目")
            contents
        } catch (e: Exception) {
            LogManager.e(TAG, "列出ZIP内容失败", e)
            emptyList()
        }
    }
    
    data class ZipFileInfo(
        val name: String,
        val size: Long,
        val compressedSize: Long,
        val isDirectory: Boolean,
        val time: Long
    ) {
        fun getSizeFormatted(): String {
            val kb = size / 1024.0
            val mb = kb / 1024.0
            return when {
                mb >= 1 -> "%.2f MB".format(mb)
                kb >= 1 -> "%.2f KB".format(kb)
                else -> "$size B"
            }
        }
        
        fun getCompressionRatio(): Float {
            return if (size > 0) {
                ((size - compressedSize).toFloat() / size) * 100
            } else 0f
        }
    }
    
    /**
     * 🔍 检查文件是否为ZIP格式
     */
    fun isZipFile(filePath: String): Boolean {
        return try {
            val file = File(filePath)
            if (!file.exists() || file.length() < 4) {
                return false
            }
            
            FileInputStream(file).use { fis ->
                val header = ByteArray(4)
                fis.read(header)
                // ZIP文件的魔数是 0x504B0304
                header[0] == 0x50.toByte() &&
                header[1] == 0x4B.toByte() &&
                header[2] == 0x03.toByte() &&
                header[3] == 0x04.toByte()
            }
        } catch (e: Exception) {
            false
        }
    }
    
    /**
     * 📊 获取ZIP文件信息
     */
    suspend fun getZipInfo(zipPath: String): ZipInfo? = withContext(Dispatchers.IO) {
        try {
            val zipFile = File(zipPath)
            if (!zipFile.exists()) {
                return@withContext null
            }
            
            val contents = listZipContents(zipPath)
            val totalSize = contents.sumOf { it.size }
            val fileCount = contents.count { !it.isDirectory }
            val dirCount = contents.count { it.isDirectory }
            
            ZipInfo(
                filePath = zipPath,
                fileSize = zipFile.length(),
                totalUncompressedSize = totalSize,
                fileCount = fileCount,
                directoryCount = dirCount,
                compressionRatio = if (totalSize > 0) {
                    ((totalSize - zipFile.length()).toFloat() / totalSize) * 100
                } else 0f
            )
        } catch (e: Exception) {
            LogManager.e(TAG, "获取ZIP信息失败", e)
            null
        }
    }
    
    data class ZipInfo(
        val filePath: String,
        val fileSize: Long,
        val totalUncompressedSize: Long,
        val fileCount: Int,
        val directoryCount: Int,
        val compressionRatio: Float
    ) {
        fun getFileSizeFormatted(): String {
            val kb = fileSize / 1024.0
            val mb = kb / 1024.0
            return when {
                mb >= 1 -> "%.2f MB".format(mb)
                kb >= 1 -> "%.2f KB".format(kb)
                else -> "$fileSize B"
            }
        }
    }
}
