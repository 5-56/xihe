package com.example.xihe

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.example.xihe.core.AutomationEngine
import com.example.xihe.ui.screens.MainScreen
import com.example.xihe.ui.OnboardingScreen
import kotlinx.coroutines.launch
import com.example.xihe.utils.LogManager

class MainActivity : ComponentActivity() {
    
    // 权限请求启动器
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        permissions.entries.forEach {
            LogManager.d("MainActivity", "权限 ${it.key} = ${it.value}")
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        LogManager.d("MainActivity", "🚀 MainActivity 启动 (核心初始化已交由 XiheApplication 处理)")
        
        // 🚀 初始化核心引擎
        // (注意: 虽然XiheApplication已经初始化，但这里再次确认以防覆盖安装等情况)
        AutomationEngine.init(applicationContext)
        
        // 🆕 初始化全自动智能代理
        com.example.xihe.automation.flow.IntelligentTaskAgent.initialize(applicationContext)
        
        // 🔒 首次运行时请求必要权限（后续不打扰）
        // 使用同步方式读取SharedPreferences
        val prefs = getSharedPreferences("onboarding_prefs", Context.MODE_PRIVATE)
        val onboardingDone = prefs.getBoolean("onboarding_done", false)
        
        if (!onboardingDone) {
            requestNecessaryPermissions()
        }
        
        setContent {
            var isOnboardingDone by remember { mutableStateOf(onboardingDone) }
            
            if (!isOnboardingDone) {
                OnboardingScreen(
                    onComplete = {
                        prefs.edit().putBoolean("onboarding_done", true).apply()
                        isOnboardingDone = true
                    },
                    onSkip = {
                        prefs.edit().putBoolean("onboarding_done", true).apply()
                        isOnboardingDone = true
                    }
                )
            } else {
                MainScreen()
            }
        }
    }
    
    override fun onPause() {
        super.onPause()
        // 💾 应用暂停时自动保存当前对话
        lifecycleScope.launch {
            try {
                AutomationEngine.saveCurrentConversation(applicationContext)
                LogManager.d("MainActivity", "✅ 对话已自动保存")
            } catch (e: Exception) {
                LogManager.e("MainActivity", "保存对话失败", e)
            }
        }
    }
    
    override fun onStop() {
        super.onStop()
        // 💾 应用停止时也保存一次（双重保险）
        lifecycleScope.launch {
            try {
                AutomationEngine.saveCurrentConversation(applicationContext)
            } catch (e: Exception) {
                LogManager.e("MainActivity", "保存对话失败", e)
            }
        }
    }
    
    /**
     * 请求必要的权限
     */
    private fun requestNecessaryPermissions() {
        val permissionsToRequest = mutableListOf<String>()
        
        // Android 13+ 需要通知权限
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    android.Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                permissionsToRequest.add(android.Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        
        // Android 10 以下需要外部存储权限
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                permissionsToRequest.add(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
            }
        }
        
        // 🎤 语音权限
        if (ContextCompat.checkSelfPermission(
                this,
                android.Manifest.permission.RECORD_AUDIO
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            permissionsToRequest.add(android.Manifest.permission.RECORD_AUDIO)
        }
        
        // 📍 定位权限
        if (ContextCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            permissionsToRequest.add(android.Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (ContextCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            permissionsToRequest.add(android.Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        
        // 请求权限
        if (permissionsToRequest.isNotEmpty()) {
            permissionLauncher.launch(permissionsToRequest.toTypedArray())
        }
        
        // 检查悬浮窗权限
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                LogManager.w("MainActivity", "悬浮窗权限未授予，引导用户授权")
            }
        }
    }
}