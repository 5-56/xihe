package com.example.xihe.camera

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.hardware.camera2.*
import android.media.Image
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.util.Size
import android.view.Surface
import androidx.core.content.ContextCompat
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * 📸 相机管理器
 * 提供拍照、切换摄像头、闪光灯控制等功能
 */
class CameraManager private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "CameraManager"
        
        @Volatile
        private var instance: CameraManager? = null
        
        fun getInstance(context: Context): CameraManager {
            return instance ?: synchronized(this) {
                instance ?: CameraManager(context.applicationContext).also { instance = it }
            }
        }
    }
    
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as android.hardware.camera2.CameraManager
    
    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var imageReader: ImageReader? = null
    
    private val backgroundThread = HandlerThread("CameraBackground").apply { start() }
    private val backgroundHandler = Handler(backgroundThread.looper)
    
    /**
     * 相机配置
     */
    data class CameraConfig(
        val facing: CameraFacing = CameraFacing.BACK,
        val flashMode: FlashMode = FlashMode.OFF,
        val quality: ImageQuality = ImageQuality.HIGH
    )
    
    enum class CameraFacing {
        FRONT,  // 前置
        BACK    // 后置
    }
    
    enum class FlashMode {
        OFF,    // 关闭
        ON,     // 开启
        AUTO    // 自动
    }
    
    enum class ImageQuality {
        LOW,    // 低质量 (640x480)
        MEDIUM, // 中等质量 (1280x720)
        HIGH    // 高质量 (1920x1080)
    }
    
    /**
     * 拍照结果
     */
    data class CaptureResult(
        val success: Boolean,
        val filePath: String? = null,
        val bitmap: Bitmap? = null,
        val errorMessage: String? = null
    )
    
    /**
     * 📷 拍照
     */
    suspend fun takePicture(
        config: CameraConfig = CameraConfig(),
        saveToFile: Boolean = true
    ): CaptureResult {
        return try {
            if (!checkCameraPermission()) {
                return CaptureResult(false, errorMessage = "没有相机权限")
            }
            
            LogManager.i(TAG, "📸 开始拍照 (${config.facing}, ${config.flashMode}, ${config.quality})")
            
            // 1. 打开相机
            openCamera(config.facing)
            
            // 2. 创建捕获会话
            val size = getImageSize(config.quality)
            setupCaptureSession(size)
            
            // 3. 执行拍照
            val bitmap = captureImage(config.flashMode)
            
            // 4. 保存文件
            val filePath = if (saveToFile && bitmap != null) {
                saveImage(bitmap)
            } else null
            
            // 5. 关闭相机
            closeCamera()
            
            LogManager.i(TAG, "✅ 拍照成功: $filePath")
            CaptureResult(true, filePath, bitmap)
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 拍照失败", e)
            closeCamera()
            CaptureResult(false, errorMessage = e.message)
        }
    }
    
    /**
     * 🎥 快速拍照 (使用默认配置)
     */
    suspend fun quickCapture(): CaptureResult {
        return takePicture()
    }
    
    /**
     * 🤳 自拍模式
     */
    suspend fun takeSelfie(): CaptureResult {
        return takePicture(CameraConfig(facing = CameraFacing.FRONT))
    }
    
    /**
     * 🔦 检查闪光灯是否可用
     */
    fun isFlashAvailable(): Boolean {
        return try {
            cameraManager.cameraIdList.any { id ->
                val characteristics = cameraManager.getCameraCharacteristics(id)
                characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        } catch (e: Exception) {
            false
        }
    }
    
    /**
     * 🎬 获取可用摄像头列表
     */
    fun getAvailableCameras(): List<CameraInfo> {
        return try {
            cameraManager.cameraIdList.map { id ->
                val characteristics = cameraManager.getCameraCharacteristics(id)
                val facing = characteristics.get(CameraCharacteristics.LENS_FACING)
                CameraInfo(
                    id = id,
                    facing = when (facing) {
                        CameraCharacteristics.LENS_FACING_FRONT -> CameraFacing.FRONT
                        else -> CameraFacing.BACK
                    },
                    hasFlash = characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                )
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "获取摄像头列表失败", e)
            emptyList()
        }
    }
    
    data class CameraInfo(
        val id: String,
        val facing: CameraFacing,
        val hasFlash: Boolean
    )
    
    /**
     * 🔓 打开相机
     */
    private suspend fun openCamera(facing: CameraFacing) = suspendCancellableCoroutine { cont ->
        try {
            val cameraId = getCameraId(facing)
            if (cameraId == null) {
                cont.resumeWithException(Exception("未找到指定摄像头"))
                return@suspendCancellableCoroutine
            }
            
            cameraManager.openCamera(cameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    cameraDevice = camera
                    cont.resume(Unit)
                }
                
                override fun onDisconnected(camera: CameraDevice) {
                    camera.close()
                    cameraDevice = null
                    cont.resumeWithException(Exception("相机连接断开"))
                }
                
                override fun onError(camera: CameraDevice, error: Int) {
                    camera.close()
                    cameraDevice = null
                    cont.resumeWithException(Exception("相机打开失败: $error"))
                }
            }, backgroundHandler)
            
        } catch (e: Exception) {
            cont.resumeWithException(e)
        }
    }
    
    /**
     * 🎯 获取相机ID
     */
    private fun getCameraId(facing: CameraFacing): String? {
        return try {
            cameraManager.cameraIdList.firstOrNull { id ->
                val characteristics = cameraManager.getCameraCharacteristics(id)
                val lensFacing = characteristics.get(CameraCharacteristics.LENS_FACING)
                when (facing) {
                    CameraFacing.FRONT -> lensFacing == CameraCharacteristics.LENS_FACING_FRONT
                    CameraFacing.BACK -> lensFacing == CameraCharacteristics.LENS_FACING_BACK
                }
            }
        } catch (e: Exception) {
            null
        }
    }
    
    /**
     * 📐 获取图片尺寸
     */
    private fun getImageSize(quality: ImageQuality): Size {
        return when (quality) {
            ImageQuality.LOW -> Size(640, 480)
            ImageQuality.MEDIUM -> Size(1280, 720)
            ImageQuality.HIGH -> Size(1920, 1080)
        }
    }
    
    /**
     * 🎬 设置捕获会话
     */
    private suspend fun setupCaptureSession(size: Size) = suspendCancellableCoroutine { cont ->
        try {
            val device = cameraDevice ?: throw Exception("相机设备未初始化")
            
            val reader = ImageReader.newInstance(size.width, size.height, ImageFormat.JPEG, 1)
            imageReader = reader
            
            val surface = reader.surface
            
            device.createCaptureSession(
                listOf(surface),
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(session: CameraCaptureSession) {
                        captureSession = session
                        cont.resume(Unit)
                    }
                    
                    override fun onConfigureFailed(session: CameraCaptureSession) {
                        cont.resumeWithException(Exception("捕获会话配置失败"))
                    }
                },
                backgroundHandler
            )
            
        } catch (e: Exception) {
            cont.resumeWithException(e)
        }
    }
    
    /**
     * 📸 执行拍照
     */
    private suspend fun captureImage(flashMode: FlashMode): Bitmap? = suspendCancellableCoroutine { cont ->
        try {
            val device = cameraDevice ?: throw Exception("相机设备未初始化")
            val session = captureSession ?: throw Exception("捕获会话未初始化")
            val reader = imageReader ?: throw Exception("ImageReader未初始化")
            
            // 设置图片监听器
            reader.setOnImageAvailableListener({ imgReader ->
                val image = imgReader.acquireLatestImage()
                val bitmap = imageToBitmap(image)
                image.close()
                cont.resume(bitmap)
            }, backgroundHandler)
            
            // 创建捕获请求
            val captureBuilder = device.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
            captureBuilder.addTarget(reader.surface)
            
            // 设置闪光灯模式
            captureBuilder.set(CaptureRequest.CONTROL_AE_MODE, when (flashMode) {
                FlashMode.OFF -> CaptureRequest.CONTROL_AE_MODE_ON
                FlashMode.ON -> CaptureRequest.CONTROL_AE_MODE_ON_ALWAYS_FLASH
                FlashMode.AUTO -> CaptureRequest.CONTROL_AE_MODE_ON_AUTO_FLASH
            })
            
            // 设置图片旋转
            captureBuilder.set(CaptureRequest.JPEG_ORIENTATION, 90)
            
            // 执行捕获
            session.capture(captureBuilder.build(), object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureFailed(
                    session: CameraCaptureSession,
                    request: CaptureRequest,
                    failure: CaptureFailure
                ) {
                    cont.resumeWithException(Exception("拍照失败"))
                }
            }, backgroundHandler)
            
        } catch (e: Exception) {
            cont.resumeWithException(e)
        }
    }
    
    /**
     * 🖼️ Image转Bitmap
     */
    private fun imageToBitmap(image: Image): Bitmap? {
        return try {
            val buffer = image.planes[0].buffer
            val bytes = ByteArray(buffer.remaining())
            buffer.get(bytes)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (e: Exception) {
            LogManager.e(TAG, "Image转Bitmap失败", e)
            null
        }
    }
    
    /**
     * 💾 保存图片
     */
    private fun saveImage(bitmap: Bitmap): String? {
        return try {
            val picturesDir = File(context.getExternalFilesDir(null), "Pictures")
            if (!picturesDir.exists()) {
                picturesDir.mkdirs()
            }
            
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val file = File(picturesDir, "IMG_$timestamp.jpg")
            
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
            }
            
            file.absolutePath
        } catch (e: Exception) {
            LogManager.e(TAG, "保存图片失败", e)
            null
        }
    }
    
    /**
     * 🔒 关闭相机
     */
    private fun closeCamera() {
        try {
            captureSession?.close()
            captureSession = null
            
            cameraDevice?.close()
            cameraDevice = null
            
            imageReader?.close()
            imageReader = null
        } catch (e: Exception) {
            LogManager.e(TAG, "关闭相机失败", e)
        }
    }
    
    /**
     * ✅ 检查相机权限
     */
    private fun checkCameraPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED
    }
    
    /**
     * 🧹 清理资源
     */
    fun cleanup() {
        closeCamera()
        backgroundThread.quitSafely()
    }
}
