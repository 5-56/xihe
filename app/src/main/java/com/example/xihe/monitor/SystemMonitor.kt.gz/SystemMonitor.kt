package com.example.xihe.monitor

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Debug
import android.os.SystemClock
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * 📊 系统监控器
 * 监控系统性能、资源使用、错误率等关键指标
 */
class SystemMonitor(private val context: Context) {
    
    companion object {
        private const val TAG = "SystemMonitor"
        private const val MONITOR_INTERVAL_MS = 5000L // 5秒监控间隔
        private const val MAX_METRICS_HISTORY = 100
        
        @Volatile
        private var instance: SystemMonitor? = null
        
        fun getInstance(context: Context): SystemMonitor {
            return instance ?: synchronized(this) {
                instance ?: SystemMonitor(context.applicationContext).also { instance = it }
            }
        }
    }
    
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var monitorJob: Job? = null
    
    // 监控状态
    private val _isMonitoring = MutableStateFlow(false)
    val isMonitoring: StateFlow<Boolean> = _isMonitoring
    
    // 当前系统状态
    private val _currentHealth = MutableStateFlow(SystemHealth.HEALTHY)
    val currentHealth: StateFlow<SystemHealth> = _currentHealth
    
    // 性能指标
    private val _currentMetrics = MutableStateFlow<PerformanceMetrics?>(null)
    val currentMetrics: StateFlow<PerformanceMetrics?> = _currentMetrics
    
    // 指标历史
    private val metricsHistory = ConcurrentLinkedQueue<PerformanceMetrics>()
    
    // 操作统计
    private var totalOperations = 0
    private var successfulOperations = 0
    private var failedOperations = 0
    private var totalLatencyMs = 0L
    
    // ==================== 📊 数据类 ====================
    
    /**
     * 🏥 系统健康状态
     */
    enum class SystemHealth {
        HEALTHY,        // 健康
        WARNING,        // 警告
        CRITICAL,       // 危急
        UNKNOWN         // 未知
    }
    
    /**
     * 📈 性能指标
     */
    data class PerformanceMetrics(
        val timestamp: Long,
        val memoryUsageMB: Float,
        val memoryTotalMB: Float,
        val memoryUsagePercent: Float,
        val cpuUsagePercent: Float,
        val operationsPerMinute: Float,
        val successRate: Float,
        val averageLatencyMs: Long,
        val uptimeMinutes: Long,
        val health: SystemHealth
    )
    
    /**
     * ⚠️ 系统警告
     */
    data class SystemAlert(
        val timestamp: Long,
        val type: AlertType,
        val severity: AlertSeverity,
        val message: String,
        val details: Map<String, Any> = emptyMap()
    )
    
    /**
     * 🔔 警告类型
     */
    enum class AlertType {
        HIGH_MEMORY_USAGE,      // 内存使用过高
        HIGH_CPU_USAGE,         // CPU使用过高
        LOW_SUCCESS_RATE,       // 成功率过低
        HIGH_LATENCY,           // 延迟过高
        SERVICE_UNAVAILABLE,    // 服务不可用
        FREQUENT_ERRORS         // 频繁错误
    }
    
    /**
     * ⚡ 警告严重程度
     */
    enum class AlertSeverity {
        INFO,       // 信息
        WARNING,    // 警告
        ERROR,      // 错误
        CRITICAL    // 危急
    }
    
    /**
     * 📊 系统报告
     */
    data class SystemReport(
        val generatedAt: Long,
        val uptimeMinutes: Long,
        val totalOperations: Int,
        val successRate: Float,
        val averageLatencyMs: Long,
        val peakMemoryUsageMB: Float,
        val averageMemoryUsageMB: Float,
        val healthHistory: List<Pair<Long, SystemHealth>>,
        val alerts: List<SystemAlert>,
        val recommendations: List<String>
    )
    
    // ==================== 🚀 监控控制 ====================
    
    /**
     * ▶️ 开始监控
     */
    fun startMonitoring() {
        if (_isMonitoring.value) return
        
        LogManager.i(TAG, "▶️ 开始系统监控")
        _isMonitoring.value = true
        
        monitorJob = scope.launch {
            while (isActive) {
                try {
                    collectMetrics()
                    checkHealth()
                } catch (e: Exception) {
                    LogManager.e(TAG, "监控异常: ${e.message}")
                }
                delay(MONITOR_INTERVAL_MS)
            }
        }
    }
    
    /**
     * ⏹️ 停止监控
     */
    fun stopMonitoring() {
        LogManager.i(TAG, "⏹️ 停止系统监控")
        monitorJob?.cancel()
        monitorJob = null
        _isMonitoring.value = false
    }
    
    // ==================== 📊 指标收集 ====================
    
    /**
     * 📊 收集性能指标
     */
    private fun collectMetrics() {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        
        val runtime = Runtime.getRuntime()
        val usedMemory = (runtime.totalMemory() - runtime.freeMemory()) / (1024f * 1024f)
        val totalMemory = runtime.maxMemory() / (1024f * 1024f)
        val memoryPercent = (usedMemory / totalMemory) * 100
        
        // CPU 使用率（简化估算）
        val cpuUsage = estimateCpuUsage()
        
        // 操作统计
        val opsPerMinute = if (totalOperations > 0) {
            val uptimeMinutes = SystemClock.elapsedRealtime() / 60000f
            if (uptimeMinutes > 0) totalOperations / uptimeMinutes else 0f
        } else 0f
        
        val successRate = if (totalOperations > 0) {
            successfulOperations.toFloat() / totalOperations
        } else 1f
        
        val avgLatency = if (totalOperations > 0) {
            totalLatencyMs / totalOperations
        } else 0L
        
        // 确定健康状态
        val health = determineHealth(memoryPercent, cpuUsage, successRate)
        
        val metrics = PerformanceMetrics(
            timestamp = System.currentTimeMillis(),
            memoryUsageMB = usedMemory,
            memoryTotalMB = totalMemory,
            memoryUsagePercent = memoryPercent,
            cpuUsagePercent = cpuUsage,
            operationsPerMinute = opsPerMinute,
            successRate = successRate,
            averageLatencyMs = avgLatency,
            uptimeMinutes = SystemClock.elapsedRealtime() / 60000,
            health = health
        )
        
        _currentMetrics.value = metrics
        _currentHealth.value = health
        
        // 保存历史
        metricsHistory.offer(metrics)
        while (metricsHistory.size > MAX_METRICS_HISTORY) {
            metricsHistory.poll()
        }
    }
    
    /**
     * 💻 估算CPU使用率
     */
    private fun estimateCpuUsage(): Float {
        return try {
            val pid = android.os.Process.myPid()
            val statFile = java.io.File("/proc/$pid/stat")
            if (statFile.exists()) {
                val stat = statFile.readText().split(" ")
                if (stat.size > 14) {
                    val utime = stat[13].toLongOrNull() ?: 0
                    val stime = stat[14].toLongOrNull() ?: 0
                    val totalTime = utime + stime
                    // 简化计算
                    (totalTime % 100).toFloat()
                } else 0f
            } else 0f
        } catch (e: Exception) {
            0f
        }
    }
    
    /**
     * 🏥 确定健康状态
     */
    private fun determineHealth(
        memoryPercent: Float,
        cpuPercent: Float,
        successRate: Float
    ): SystemHealth {
        return when {
            memoryPercent > 90 || successRate < 0.5f -> SystemHealth.CRITICAL
            memoryPercent > 80 || cpuPercent > 80 || successRate < 0.7f -> SystemHealth.WARNING
            else -> SystemHealth.HEALTHY
        }
    }
    
    /**
     * 🔍 检查健康状态
     */
    private fun checkHealth() {
        val metrics = _currentMetrics.value ?: return
        
        // 检查各项指标
        if (metrics.memoryUsagePercent > 85) {
            LogManager.w(TAG, "⚠️ 内存使用过高: ${metrics.memoryUsagePercent}%")
        }
        
        if (metrics.successRate < 0.8f && totalOperations > 10) {
            LogManager.w(TAG, "⚠️ 成功率过低: ${metrics.successRate * 100}%")
        }
        
        if (metrics.averageLatencyMs > 5000 && totalOperations > 5) {
            LogManager.w(TAG, "⚠️ 平均延迟过高: ${metrics.averageLatencyMs}ms")
        }
    }
    
    // ==================== 📝 操作记录 ====================
    
    /**
     * ✅ 记录成功操作
     */
    fun recordSuccess(latencyMs: Long) {
        totalOperations++
        successfulOperations++
        totalLatencyMs += latencyMs
    }
    
    /**
     * ❌ 记录失败操作
     */
    fun recordFailure(latencyMs: Long) {
        totalOperations++
        failedOperations++
        totalLatencyMs += latencyMs
    }
    
    /**
     * 📊 记录操作
     */
    fun recordOperation(success: Boolean, latencyMs: Long) {
        if (success) {
            recordSuccess(latencyMs)
        } else {
            recordFailure(latencyMs)
        }
    }
    
    // ==================== 📋 报告生成 ====================
    
    /**
     * 📋 生成系统报告
     */
    fun generateReport(): SystemReport {
        val history = metricsHistory.toList()
        
        val peakMemory = history.maxOfOrNull { it.memoryUsageMB } ?: 0f
        val avgMemory = if (history.isNotEmpty()) {
            history.map { it.memoryUsageMB }.average().toFloat()
        } else 0f
        
        val healthHistory = history.map { it.timestamp to it.health }
        
        val recommendations = generateRecommendations(history)
        
        return SystemReport(
            generatedAt = System.currentTimeMillis(),
            uptimeMinutes = SystemClock.elapsedRealtime() / 60000,
            totalOperations = totalOperations,
            successRate = if (totalOperations > 0) successfulOperations.toFloat() / totalOperations else 1f,
            averageLatencyMs = if (totalOperations > 0) totalLatencyMs / totalOperations else 0,
            peakMemoryUsageMB = peakMemory,
            averageMemoryUsageMB = avgMemory,
            healthHistory = healthHistory,
            alerts = emptyList(),
            recommendations = recommendations
        )
    }
    
    /**
     * 💡 生成优化建议
     */
    private fun generateRecommendations(history: List<PerformanceMetrics>): List<String> {
        val recommendations = mutableListOf<String>()
        
        if (history.isEmpty()) return recommendations
        
        val avgMemory = history.map { it.memoryUsagePercent }.average()
        if (avgMemory > 70) {
            recommendations.add("内存使用较高，建议减少缓存或清理临时数据")
        }
        
        val successRate = if (totalOperations > 0) {
            successfulOperations.toFloat() / totalOperations
        } else 1f
        
        if (successRate < 0.8f && totalOperations > 10) {
            recommendations.add("操作成功率较低，建议检查网络连接和应用兼容性")
        }
        
        val avgLatency = if (totalOperations > 0) totalLatencyMs / totalOperations else 0
        if (avgLatency > 3000) {
            recommendations.add("操作延迟较高，建议优化操作流程或检查设备性能")
        }
        
        if (recommendations.isEmpty()) {
            recommendations.add("系统运行正常，所有指标都在健康范围内")
        }
        
        return recommendations
    }
    
    // ==================== 🔍 健康检查 ====================
    
    /**
     * 🔍 执行健康检查
     */
    fun performHealthCheck(): HealthCheckResult {
        val checks = mutableListOf<HealthCheckItem>()
        
        // 1. 内存检查
        val metrics = _currentMetrics.value
        val memoryOk = (metrics?.memoryUsagePercent ?: 0f) < 85
        checks.add(HealthCheckItem(
            name = "内存使用",
            passed = memoryOk,
            details = "当前使用: ${metrics?.memoryUsagePercent?.toInt() ?: 0}%"
        ))
        
        // 2. 成功率检查
        val successRate = if (totalOperations > 0) {
            successfulOperations.toFloat() / totalOperations
        } else 1f
        val successOk = successRate >= 0.7f || totalOperations < 5
        checks.add(HealthCheckItem(
            name = "操作成功率",
            passed = successOk,
            details = "成功率: ${(successRate * 100).toInt()}%"
        ))
        
        // 3. 延迟检查
        val avgLatency = if (totalOperations > 0) totalLatencyMs / totalOperations else 0
        val latencyOk = avgLatency < 5000 || totalOperations < 5
        checks.add(HealthCheckItem(
            name = "平均延迟",
            passed = latencyOk,
            details = "平均: ${avgLatency}ms"
        ))
        
        val allPassed = checks.all { it.passed }
        
        return HealthCheckResult(
            timestamp = System.currentTimeMillis(),
            overallHealth = if (allPassed) SystemHealth.HEALTHY else SystemHealth.WARNING,
            checks = checks,
            summary = if (allPassed) "所有检查通过" else "部分检查未通过"
        )
    }
    
    /**
     * 🧹 重置统计
     */
    fun resetStatistics() {
        totalOperations = 0
        successfulOperations = 0
        failedOperations = 0
        totalLatencyMs = 0
        metricsHistory.clear()
        LogManager.d(TAG, "🧹 统计数据已重置")
    }
    
    /**
     * 🛑 销毁
     */
    fun destroy() {
        stopMonitoring()
        scope.cancel()
    }
}

/**
 * ✅ 健康检查项
 */
data class HealthCheckItem(
    val name: String,
    val passed: Boolean,
    val details: String
)

/**
 * 📋 健康检查结果
 */
data class HealthCheckResult(
    val timestamp: Long,
    val overallHealth: SystemMonitor.SystemHealth,
    val checks: List<HealthCheckItem>,
    val summary: String
)
