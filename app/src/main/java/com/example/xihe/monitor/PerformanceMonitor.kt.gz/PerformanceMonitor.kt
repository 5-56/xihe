package com.example.xihe.monitor

import android.content.Context
import android.os.Debug
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/**
 * 性能监控器
 * 监控应用性能指标
 */
class PerformanceMonitor(private val context: Context) {
    
    companion object {
        private const val TAG = "PerformanceMonitor"
        private const val MONITOR_INTERVAL = 1000L // 1秒
        
        @Volatile
        private var instance: PerformanceMonitor? = null
        
        fun getInstance(context: Context): PerformanceMonitor {
            return instance ?: synchronized(this) {
                instance ?: PerformanceMonitor(context.applicationContext).also { instance = it }
            }
        }
    }
    
    private var monitorJob: Job? = null
    private val performanceData = mutableListOf<PerformanceSnapshot>()
    
    private val _isMonitoring = MutableStateFlow(false)
    val isMonitoring = _isMonitoring.asStateFlow()
    
    private val _currentSnapshot = MutableStateFlow<PerformanceSnapshot?>(null)
    val currentSnapshot = _currentSnapshot.asStateFlow()
    
    /**
     * 开始监控
     */
    fun startMonitoring() {
        if (_isMonitoring.value) {
            LogManager.d(TAG, "已经在监控中")
            return
        }
        
        _isMonitoring.value = true
        performanceData.clear()
        
        monitorJob = CoroutineScope(Dispatchers.Default).launch {
            while (isActive && _isMonitoring.value) {
                try {
                    val snapshot = captureSnapshot()
                    performanceData.add(snapshot)
                    _currentSnapshot.value = snapshot
                    
                    // 保持最近100条记录
                    if (performanceData.size > 100) {
                        performanceData.removeAt(0)
                    }
                    
                    delay(MONITOR_INTERVAL)
                } catch (e: Exception) {
                    LogManager.e(TAG, "监控失败", e)
                }
            }
        }
        
        LogManager.i(TAG, "开始性能监控")
    }
    
    /**
     * 停止监控
     */
    fun stopMonitoring() {
        _isMonitoring.value = false
        monitorJob?.cancel()
        monitorJob = null
        
        LogManager.i(TAG, "停止性能监控")
    }
    
    /**
     * 捕获性能快照
     */
    private fun captureSnapshot(): PerformanceSnapshot {
        val runtime = Runtime.getRuntime()
        
        // 内存信息
        val totalMemory = runtime.totalMemory()
        val freeMemory = runtime.freeMemory()
        val usedMemory = totalMemory - freeMemory
        val maxMemory = runtime.maxMemory()
        
        // Native内存
        val nativeHeapSize = Debug.getNativeHeapSize()
        val nativeHeapAllocated = Debug.getNativeHeapAllocatedSize()
        val nativeHeapFree = Debug.getNativeHeapFreeSize()
        
        // CPU时间
        val threadCpuTime = Debug.threadCpuTimeNanos()
        
        // 存储信息
        val storageInfo = getStorageInfo()
        
        return PerformanceSnapshot(
            timestamp = System.currentTimeMillis(),
            // Java堆内存
            totalMemory = totalMemory,
            usedMemory = usedMemory,
            freeMemory = freeMemory,
            maxMemory = maxMemory,
            memoryUsagePercent = (usedMemory.toFloat() / maxMemory * 100).toInt(),
            // Native内存
            nativeHeapSize = nativeHeapSize,
            nativeHeapAllocated = nativeHeapAllocated,
            nativeHeapFree = nativeHeapFree,
            // CPU
            threadCpuTime = threadCpuTime,
            // 存储
            totalStorage = storageInfo.first,
            freeStorage = storageInfo.second,
            usedStorage = storageInfo.first - storageInfo.second,
            storageUsagePercent = ((storageInfo.first - storageInfo.second).toFloat() / storageInfo.first * 100).toInt()
        )
    }
    
    /**
     * 获取存储信息
     */
    private fun getStorageInfo(): Pair<Long, Long> {
        return try {
            val dataDir = context.filesDir
            val totalSpace = dataDir.totalSpace
            val freeSpace = dataDir.freeSpace
            Pair(totalSpace, freeSpace)
        } catch (e: Exception) {
            LogManager.e(TAG, "获取存储信息失败", e)
            Pair(0L, 0L)
        }
    }
    
    /**
     * 获取性能统计
     */
    fun getPerformanceStatistics(): PerformanceStatistics {
        if (performanceData.isEmpty()) {
            return PerformanceStatistics(
                averageMemoryUsage = 0,
                peakMemoryUsage = 0,
                averageCpuUsage = 0,
                dataPoints = 0
            )
        }
        
        val avgMemory = performanceData.map { it.memoryUsagePercent }.average().toInt()
        val peakMemory = performanceData.maxOfOrNull { it.memoryUsagePercent } ?: 0
        val avgCpu = performanceData.map { it.threadCpuTime }.average().toLong()
        
        return PerformanceStatistics(
            averageMemoryUsage = avgMemory,
            peakMemoryUsage = peakMemory,
            averageCpuUsage = avgCpu,
            dataPoints = performanceData.size
        )
    }
    
    /**
     * 获取历史数据
     */
    fun getHistoryData(): List<PerformanceSnapshot> {
        return performanceData.toList()
    }
    
    /**
     * 检测性能问题
     */
    fun detectPerformanceIssues(): List<PerformanceIssue> {
        val issues = mutableListOf<PerformanceIssue>()
        
        if (performanceData.isEmpty()) return issues
        
        val latest = performanceData.last()
        
        // 检测内存问题
        if (latest.memoryUsagePercent > 90) {
            issues.add(PerformanceIssue(
                type = IssueType.HIGH_MEMORY,
                severity = IssueSeverity.CRITICAL,
                message = "内存使用率过高: ${latest.memoryUsagePercent}%",
                value = latest.memoryUsagePercent.toFloat()
            ))
        } else if (latest.memoryUsagePercent > 75) {
            issues.add(PerformanceIssue(
                type = IssueType.HIGH_MEMORY,
                severity = IssueSeverity.WARNING,
                message = "内存使用率较高: ${latest.memoryUsagePercent}%",
                value = latest.memoryUsagePercent.toFloat()
            ))
        }
        
        // 检测存储问题
        if (latest.storageUsagePercent > 95) {
            issues.add(PerformanceIssue(
                type = IssueType.LOW_STORAGE,
                severity = IssueSeverity.CRITICAL,
                message = "存储空间不足: ${latest.storageUsagePercent}%已使用",
                value = latest.storageUsagePercent.toFloat()
            ))
        } else if (latest.storageUsagePercent > 85) {
            issues.add(PerformanceIssue(
                type = IssueType.LOW_STORAGE,
                severity = IssueSeverity.WARNING,
                message = "存储空间较少: ${latest.storageUsagePercent}%已使用",
                value = latest.storageUsagePercent.toFloat()
            ))
        }
        
        // 检测内存泄漏
        if (performanceData.size >= 10) {
            val recent10 = performanceData.takeLast(10)
            val memoryTrend = recent10.last().usedMemory - recent10.first().usedMemory
            if (memoryTrend > 50 * 1024 * 1024) { // 增长超过50MB
                issues.add(PerformanceIssue(
                    type = IssueType.MEMORY_LEAK,
                    severity = IssueSeverity.WARNING,
                    message = "可能存在内存泄漏，内存持续增长",
                    value = (memoryTrend / 1024f / 1024f)
                ))
            }
        }
        
        return issues
    }
    
    /**
     * 导出性能报告
     */
    fun exportPerformanceReport(): String {
        val sb = StringBuilder()
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        
        sb.appendLine("性能监控报告")
        sb.appendLine("=".repeat(50))
        sb.appendLine("生成时间: ${dateFormat.format(Date())}")
        sb.appendLine("监控状态: ${if (_isMonitoring.value) "运行中" else "已停止"}")
        sb.appendLine("数据点数: ${performanceData.size}")
        sb.appendLine()
        
        // 统计信息
        val stats = getPerformanceStatistics()
        sb.appendLine("统计信息:")
        sb.appendLine("  平均内存使用: ${stats.averageMemoryUsage}%")
        sb.appendLine("  峰值内存使用: ${stats.peakMemoryUsage}%")
        sb.appendLine()
        
        // 当前状态
        val current = _currentSnapshot.value
        if (current != null) {
            sb.appendLine("当前状态:")
            sb.appendLine("  时间: ${dateFormat.format(Date(current.timestamp))}")
            sb.appendLine("  内存使用: ${current.usedMemory / 1024 / 1024}MB / ${current.maxMemory / 1024 / 1024}MB (${current.memoryUsagePercent}%)")
            sb.appendLine("  Native堆: ${current.nativeHeapAllocated / 1024 / 1024}MB / ${current.nativeHeapSize / 1024 / 1024}MB")
            sb.appendLine("  存储使用: ${current.usedStorage / 1024 / 1024 / 1024}GB / ${current.totalStorage / 1024 / 1024 / 1024}GB (${current.storageUsagePercent}%)")
            sb.appendLine()
        }
        
        // 性能问题
        val issues = detectPerformanceIssues()
        if (issues.isNotEmpty()) {
            sb.appendLine("检测到的问题:")
            for (issue in issues) {
                sb.appendLine("  [${issue.severity}] ${issue.message}")
            }
            sb.appendLine()
        }
        
        // 历史数据（最近10条）
        sb.appendLine("最近10条记录:")
        performanceData.takeLast(10).forEach { snapshot ->
            sb.appendLine("  ${dateFormat.format(Date(snapshot.timestamp))}: 内存${snapshot.memoryUsagePercent}% 存储${snapshot.storageUsagePercent}%")
        }
        
        return sb.toString()
    }
    
    /**
     * 清除历史数据
     */
    fun clearHistory() {
        performanceData.clear()
        LogManager.i(TAG, "清除历史数据")
    }
    
    // ============ 数据类型 ============
    
    /**
     * 性能快照
     */
    data class PerformanceSnapshot(
        val timestamp: Long,
        // Java堆内存
        val totalMemory: Long,
        val usedMemory: Long,
        val freeMemory: Long,
        val maxMemory: Long,
        val memoryUsagePercent: Int,
        // Native内存
        val nativeHeapSize: Long,
        val nativeHeapAllocated: Long,
        val nativeHeapFree: Long,
        // CPU
        val threadCpuTime: Long,
        // 存储
        val totalStorage: Long,
        val freeStorage: Long,
        val usedStorage: Long,
        val storageUsagePercent: Int
    )
    
    /**
     * 📊 性能统计
     */
    data class PerformanceStatistics(
        val averageMemoryUsage: Int,
        val peakMemoryUsage: Int,
        val averageCpuUsage: Long,
        val dataPoints: Int
    )
    
    /**
     * ⚠️ 性能问题
     */
    data class PerformanceIssue(
        val type: IssueType,
        val severity: IssueSeverity,
        val message: String,
        val value: Float
    )
    
    /**
     * 🏷️ 问题类型
     */
    enum class IssueType {
        HIGH_MEMORY,        // 高内存使用
        MEMORY_LEAK,        // 内存泄漏
        LOW_STORAGE,        // 存储空间不足
        HIGH_CPU            // 高CPU使用
    }
    
    /**
     * 🚨 问题严重程度
     */
    enum class IssueSeverity {
        INFO,               // 信息
        WARNING,            // 警告
        CRITICAL            // 严重
    }
}
