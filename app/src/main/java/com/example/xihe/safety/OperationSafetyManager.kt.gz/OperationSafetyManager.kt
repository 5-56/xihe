package com.example.xihe.safety

import android.content.Context
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * 🛡️ 操作安全管理器
 * 提供危险操作防护、操作审计、风险评估等安全功能
 */
class OperationSafetyManager(private val context: Context) {
    
    companion object {
        private const val TAG = "OperationSafetyManager"
        private const val MAX_AUDIT_LOG_SIZE = 500
        private const val AUDIT_LOG_FILE = "audit_log.json"
        private const val AUDIT_DIR = "xihe_audit"
        
        @Volatile
        private var instance: OperationSafetyManager? = null
        
        fun getInstance(context: Context): OperationSafetyManager {
            return instance ?: synchronized(this) {
                instance ?: OperationSafetyManager(context.applicationContext).also { instance = it }
            }
        }
    }
    
    // 🆕 JSON 解析器
    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
    }
    
    // 🆕 协程作用域
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    
    // 🆕 审计日志目录
    private val auditDir: File by lazy {
        File(context.filesDir, AUDIT_DIR).apply {
            if (!exists()) mkdirs()
        }
    }
    
    // 审计日志
    private val auditLog = ConcurrentLinkedQueue<AuditEntry>()
    
    init {
        // 启动时加载持久化的审计日志
        loadAuditLog()
    }
    
    // 待确认的操作
    private val _pendingConfirmation = MutableStateFlow<PendingOperation?>(null)
    val pendingConfirmation: StateFlow<PendingOperation?> = _pendingConfirmation
    
    // 危险应用包名
    private val sensitiveApps = setOf(
        "com.android.vending",              // Google Play
        "com.eg.android.AlipayGphone",      // 支付宝
        "com.tencent.mm",                   // 微信 (支付)
        "com.android.settings",             // 系统设置
        "com.android.packageinstaller"      // 应用安装器
    )
    
    // 危险关键词
    private val dangerousKeywords = setOf(
        "支付", "付款", "转账", "汇款", "pay", "payment",
        "删除", "卸载", "清除", "格式化", "delete", "remove", "uninstall",
        "密码", "验证码", "身份证", "银行卡", "password",
        "授权", "权限", "允许", "permission",
        "发送", "确认", "提交", "confirm", "submit"
    )
    
    // ==================== 数据类 ====================
    
    /**
     * 风险等级
     */
    enum class RiskLevel {
        SAFE,           // 安全
        LOW,            // 低风险
        MEDIUM,         // 中等风险
        HIGH,           // 高风险
        CRITICAL        // 危险
    }
    
    /**
     * 风险评估结果
     */
    data class RiskAssessment(
        val level: RiskLevel,
        val score: Int,             // 0-100 风险分数
        val reasons: List<String>,
        val requireConfirmation: Boolean,
        val suggestedAction: String
    )
    
    /**
     * 待确认的操作
     */
    data class PendingOperation(
        val id: String,
        val operationType: OperationType,
        val description: String,
        val riskAssessment: RiskAssessment,
        val timestamp: Long = System.currentTimeMillis(),
        val targetApp: String? = null,
        val additionalInfo: Map<String, String> = emptyMap()
    )
    
    /**
     * 操作类型
     */
    enum class OperationType {
        CLICK,              // 点击
        INPUT,              // 输入
        SCROLL,             // 滑动
        APP_LAUNCH,         // 启动应用
        PAYMENT,            // 支付
        DELETE,             // 删除
        SEND_MESSAGE,       // 发送消息
        PERMISSION_GRANT,   // 授权
        INSTALL,            // 安装
        UNINSTALL,          // 卸载
        SYSTEM_SETTING,     // 系统设置
        OTHER               // 其他
    }
    
    /**
     * 审计条目
     * 添加 @Serializable 支持持久化
     */
    @Serializable
    data class AuditEntry(
        val timestamp: Long,
        val operationType: String,  // 用字符串存储枚举以支持序列化
        val description: String,
        val targetApp: String?,
        val riskLevel: String,      // 用字符串存储枚举
        val outcome: String,        // 用字符串存储枚举
        val userConfirmed: Boolean = false,
        val details: Map<String, String> = emptyMap()
    )
    
    /**
     * 操作结果
     */
    enum class OperationOutcome {
        SUCCESS,            // 成功
        FAILED,             // 失败
        BLOCKED,            // 被阻止
        CANCELLED,          // 被取消
        TIMEOUT             // 超时
    }
    
    // ==================== 风险评估 ====================
    
    /**
     * 评估操作风险
     */
    fun assessRisk(
        operationType: OperationType,
        targetApp: String?,
        actionDescription: String,
        screenText: String = ""
    ): RiskAssessment {
        var score = 0
        val reasons = mutableListOf<String>()
        
        // 1. 操作类型风险
        val typeRisk = getOperationTypeRisk(operationType)
        score += typeRisk.first
        if (typeRisk.first > 0) {
            reasons.add(typeRisk.second)
        }
        
        // 2. 目标应用风险
        if (targetApp != null && sensitiveApps.contains(targetApp)) {
            score += 30
            reasons.add("操作涉及敏感应用")
        }
        
        // 3. 关键词风险检测
        val keywordRisk = detectKeywordRisk(actionDescription + " " + screenText)
        score += keywordRisk.first
        if (keywordRisk.second.isNotEmpty()) {
            reasons.addAll(keywordRisk.second)
        }
        
        // 4. 确定风险等级
        val level = when {
            score >= 80 -> RiskLevel.CRITICAL
            score >= 60 -> RiskLevel.HIGH
            score >= 40 -> RiskLevel.MEDIUM
            score >= 20 -> RiskLevel.LOW
            else -> RiskLevel.SAFE
        }
        
        // 5. 确定是否需要确认
        val requireConfirmation = level >= RiskLevel.HIGH ||
            operationType in listOf(
                OperationType.PAYMENT,
                OperationType.DELETE,
                OperationType.UNINSTALL,
                OperationType.PERMISSION_GRANT
            )
        
        // 6. 建议操作
        val suggestedAction = when (level) {
            RiskLevel.CRITICAL -> "强烈建议取消此操作"
            RiskLevel.HIGH -> "请仔细确认后再执行"
            RiskLevel.MEDIUM -> "请确认是否继续"
            else -> "可以安全执行"
        }
        
        LogManager.d(TAG, "风险评估: type=$operationType, level=$level, score=$score")
        
        return RiskAssessment(
            level = level,
            score = score.coerceIn(0, 100),
            reasons = reasons,
            requireConfirmation = requireConfirmation,
            suggestedAction = suggestedAction
        )
    }
    
    /**
     * 获取操作类型风险
     */
    private fun getOperationTypeRisk(type: OperationType): Pair<Int, String> {
        return when (type) {
            OperationType.PAYMENT -> 50 to "支付操作风险较高"
            OperationType.DELETE -> 40 to "删除操作不可逆"
            OperationType.UNINSTALL -> 40 to "卸载应用不可逆"
            OperationType.PERMISSION_GRANT -> 35 to "授权操作需谨慎"
            OperationType.INSTALL -> 30 to "安装应用需谨慎"
            OperationType.SYSTEM_SETTING -> 30 to "修改系统设置"
            OperationType.SEND_MESSAGE -> 20 to "发送消息操作"
            OperationType.INPUT -> 10 to "输入敏感信息"
            else -> 0 to ""
        }
    }
    
    /**
     * 检测关键词风险
     */
    private fun detectKeywordRisk(text: String): Pair<Int, List<String>> {
        var score = 0
        val reasons = mutableListOf<String>()
        val lowerText = text.lowercase()
        
        for (keyword in dangerousKeywords) {
            if (lowerText.contains(keyword.lowercase())) {
                when {
                    keyword in listOf("支付", "付款", "转账", "汇款", "pay", "payment") -> {
                        score += 30
                        reasons.add("检测到支付相关内容")
                    }
                    keyword in listOf("删除", "卸载", "清除", "格式化", "delete", "remove", "uninstall") -> {
                        score += 25
                        reasons.add("检测到删除相关内容")
                    }
                    keyword in listOf("密码", "验证码", "身份证", "银行卡", "password") -> {
                        score += 20
                        reasons.add("检测到敏感信息内容")
                    }
                    else -> {
                        score += 10
                    }
                }
                break // 只计算一次
            }
        }
        
        return score to reasons
    }
    
    // ==================== 操作确认 ====================
    
    /**
     * 请求用户确认
     */
    fun requestConfirmation(
        operationType: OperationType,
        description: String,
        riskAssessment: RiskAssessment,
        targetApp: String? = null
    ): PendingOperation {
        val pending = PendingOperation(
            id = java.util.UUID.randomUUID().toString(),
            operationType = operationType,
            description = description,
            riskAssessment = riskAssessment,
            targetApp = targetApp
        )
        
        _pendingConfirmation.value = pending
        LogManager.d(TAG, "等待用户确认: ${pending.description}")
        
        return pending
    }
    
    /**
     * 确认操作
     */
    fun confirmOperation(operationId: String): Boolean {
        val pending = _pendingConfirmation.value
        if (pending?.id == operationId) {
            _pendingConfirmation.value = null
            recordAudit(
                operationType = pending.operationType,
                description = pending.description,
                targetApp = pending.targetApp,
                riskLevel = pending.riskAssessment.level,
                outcome = OperationOutcome.SUCCESS,
                userConfirmed = true
            )
            LogManager.d(TAG, "用户确认操作: ${pending.description}")
            return true
        }
        return false
    }
    
    /**
     * 取消操作
     */
    fun cancelOperation(operationId: String): Boolean {
        val pending = _pendingConfirmation.value
        if (pending?.id == operationId) {
            _pendingConfirmation.value = null
            recordAudit(
                operationType = pending.operationType,
                description = pending.description,
                targetApp = pending.targetApp,
                riskLevel = pending.riskAssessment.level,
                outcome = OperationOutcome.CANCELLED,
                userConfirmed = false
            )
            LogManager.d(TAG, "用户取消操作: ${pending.description}")
            return true
        }
        return false
    }
    
    // ==================== 审计日志 ====================
    
    /**
     * 记录审计日志
     */
    fun recordAudit(
        operationType: OperationType,
        description: String,
        targetApp: String?,
        riskLevel: RiskLevel,
        outcome: OperationOutcome,
        userConfirmed: Boolean = false,
        details: Map<String, String> = emptyMap()
    ) {
        // 将枚举转换为字符串以支持序列化
        val entry = AuditEntry(
            timestamp = System.currentTimeMillis(),
            operationType = operationType.name,
            description = description,
            targetApp = targetApp,
            riskLevel = riskLevel.name,
            outcome = outcome.name,
            userConfirmed = userConfirmed,
            details = details
        )
        
        auditLog.offer(entry)
        
        // 限制日志大小
        while (auditLog.size > MAX_AUDIT_LOG_SIZE) {
            auditLog.poll()
        }
        
        LogManager.d(TAG, "审计记录: type=$operationType, outcome=$outcome, risk=$riskLevel")
        
        // 异步保存到文件
        saveAuditLogAsync()
    }
    
    /**
     * 获取审计日志
     */
    fun getAuditLog(): List<AuditEntry> = auditLog.toList()
    
    /**
     * 获取风险统计
     */
    fun getRiskStatistics(): RiskStatistics {
        val logs = auditLog.toList()
        return RiskStatistics(
            totalOperations = logs.size,
            highRiskOperations = logs.count { it.riskLevel == RiskLevel.HIGH.name || it.riskLevel == RiskLevel.CRITICAL.name },
            blockedOperations = logs.count { it.outcome == OperationOutcome.BLOCKED.name },
            cancelledOperations = logs.count { it.outcome == OperationOutcome.CANCELLED.name },
            userConfirmedRisky = logs.count { it.userConfirmed && (it.riskLevel == RiskLevel.MEDIUM.name || it.riskLevel == RiskLevel.HIGH.name) }
        )
    }
    
    /**
     * 清空审计日志
     */
    fun clearAuditLog() {
        auditLog.clear()
        // 同时清除持久化文件
        scope.launch {
            try {
                val logFile = File(auditDir, AUDIT_LOG_FILE)
                if (logFile.exists()) {
                    logFile.delete()
                }
            } catch (e: Exception) {
                LogManager.e(TAG, "清除审计日志文件失败", e)
            }
        }
        LogManager.d(TAG, "审计日志已清空")
    }
    
    // ==================== 持久化方法 ====================
    
    /**
     * 加载审计日志
     */
    private fun loadAuditLog() {
        scope.launch {
            try {
                val logFile = File(auditDir, AUDIT_LOG_FILE)
                if (logFile.exists()) {
                    val content = logFile.readText()
                    val entries = json.decodeFromString<List<AuditEntry>>(content)
                    auditLog.clear()
                    auditLog.addAll(entries)
                    LogManager.d(TAG, "✅ 加载审计日志: ${entries.size} 条")
                }
            } catch (e: Exception) {
                LogManager.e(TAG, "加载审计日志失败", e)
            }
        }
    }
    
    /**
     * 🆕 异步保存审计日志
     */
    private fun saveAuditLogAsync() {
        scope.launch {
            try {
                val logFile = File(auditDir, AUDIT_LOG_FILE)
                val entries = auditLog.toList()
                logFile.writeText(json.encodeToString(entries))
                LogManager.d(TAG, "✅ 审计日志已保存: ${entries.size} 条")
            } catch (e: Exception) {
                LogManager.e(TAG, "保存审计日志失败", e)
            }
        }
    }
}

/**
 * 📊 风险统计
 */
data class RiskStatistics(
    val totalOperations: Int,
    val highRiskOperations: Int,
    val blockedOperations: Int,
    val cancelledOperations: Int,
    val userConfirmedRisky: Int
)
