package com.example.xihe

import android.content.Intent
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import com.example.xihe.utils.LogManager
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.annotation.RequiresApi
import com.example.xihe.core.ModuleIntegration
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import java.lang.ref.WeakReference
import kotlin.coroutines.resume

class CoreAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    
    // 事件限流机制
    private var lastContentChangeTime = 0L
    private val contentChangeThrottleMs = 100L // 100ms内最多处理一次内容变化事件
    private var eventCounter = 0
    private var lastCounterResetTime = System.currentTimeMillis()

    companion object {
        private const val TAG = "CoreAccessService"
        
        private val _isConnected = MutableStateFlow(false)
        val isConnected = _isConnected.asStateFlow()
        
        // 使用 WeakReference 避免内存泄漏
        private var instanceRef: WeakReference<CoreAccessibilityService>? = null
        
        /**
         * 获取服务实例（可能为 null）
         */
        fun getInstance(): CoreAccessibilityService? = instanceRef?.get()
        
        // 向后兼容的属性访问器
        @Deprecated("Use getInstance() instead", ReplaceWith("getInstance()"))
        @get:JvmName("getInstanceProperty")
        var instance: CoreAccessibilityService?
            get() = getInstance()
            private set(value) {
                instanceRef = value?.let { WeakReference(it) }
            }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        LogManager.d(TAG, "Service Connected")
        instanceRef = WeakReference(this)
        _isConnected.value = true
        
        // 🔗 初始化增强执行器
        try {
            ModuleIntegration.initializeExecutor(this, applicationContext)
            LogManager.d(TAG, "✅ 增强执行器已初始化")
        } catch (e: Exception) {
            LogManager.w(TAG, "增强执行器初始化失败", e)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        
        // 事件计数器，每秒重置
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastCounterResetTime > 1000) {
            if (eventCounter > 100) {
                LogManager.w(TAG, "High event rate: $eventCounter events/sec")
            }
            eventCounter = 0
            lastCounterResetTime = currentTime
        }
        eventCounter++
        
        // 限制事件处理频率，防止过载
        if (eventCounter > 200) {
            return // 丢弃过多的事件
        }
        
        // 🛡️ 事件过滤：只处理关键事件，防止 Binder 缓冲区溢出
        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                // 窗口切换事件 - 用于跟踪当前应用
                LogManager.i(TAG, "Window Changed: ${event.packageName}")
            }
            AccessibilityEvent.TYPE_VIEW_CLICKED -> {
                // 点击事件 - 用于操作确认
                LogManager.d(TAG, "View Clicked: ${event.className}")
            }
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
                // 内容变化事件 - 严格限流
                val now = System.currentTimeMillis()
                if (now - lastContentChangeTime < contentChangeThrottleMs) {
                    return // 丢弃过于频繁的事件
                }
                lastContentChangeTime = now
                
                // 跳过系统 UI 和我们自己的应用的频繁更新
                val packageName = event.packageName?.toString() ?: ""
                if (packageName == "com.android.systemui" || 
                    packageName == "com.example.xihe" ||
                    packageName.isEmpty()) {
                    return
                }
                
                // 只处理有实际内容变化的事件
                if (event.contentChangeTypes == 0) {
                    return // 忽略没有实际内容变化的事件
                }
            }
            else -> {
                // 其他事件忽略
                return
            }
        }
    }

    override fun onInterrupt() {
        LogManager.w(TAG, "Service Interrupted")
        _isConnected.value = false
        instanceRef?.clear()
        instanceRef = null
    }

    override fun onDestroy() {
        super.onDestroy()
        LogManager.d(TAG, "Service Destroyed")
        _isConnected.value = false
        
        // 清理 WeakReference
        instanceRef?.clear()
        instanceRef = null
        
        // 取消协程作用域
        serviceScope.cancel()
    }

    // --- Action Primitives ---

    fun performClick(x: Float, y: Float) {
        val path = Path()
        path.moveTo(x, y)
        val builder = GestureDescription.Builder()
        val stroke = GestureDescription.StrokeDescription(path, 0, 50)
        builder.addStroke(stroke)
        dispatchGesture(builder.build(), null, null)
        LogManager.d(TAG, "Performed Click at ($x, $y)")
    }
    
    fun performScroll(startX: Float, startY: Float, endX: Float, endY: Float) {
        val path = Path()
        path.moveTo(startX, startY)
        path.lineTo(endX, endY)
        val builder = GestureDescription.Builder()
        val stroke = GestureDescription.StrokeDescription(path, 0, 300) // 300ms swipe duration
        builder.addStroke(stroke)
        dispatchGesture(builder.build(), null, null)
        LogManager.d(TAG, "Performed Scroll from ($startX, $startY) to ($endX, $endY)")
    }
    
    fun performGlobalBack() {
        performGlobalAction(GLOBAL_ACTION_BACK)
    }
    
    fun performGlobalHome() {
        performGlobalAction(GLOBAL_ACTION_HOME)
    }
    
    /**
     * 执行长按操作
     * @param x X坐标
     * @param y Y坐标
     * @param duration 长按时长（毫秒），默认800ms
     */
    fun performLongPress(x: Float, y: Float, duration: Long = 800) {
        val path = Path()
        path.moveTo(x, y)
        val builder = GestureDescription.Builder()
        val stroke = GestureDescription.StrokeDescription(path, 0, duration)
        builder.addStroke(stroke)
        dispatchGesture(builder.build(), null, null)
        LogManager.d(TAG, "Performed Long Press at ($x, $y) for ${duration}ms")
    }
    
    /**
     * 执行双击操作
     * @param x X坐标
     * @param y Y坐标
     */
    fun performDoubleClick(x: Float, y: Float) {
        val path1 = Path()
        path1.moveTo(x, y)
        
        val path2 = Path()
        path2.moveTo(x, y)
        
        val builder = GestureDescription.Builder()
        
        // 第一次点击
        val stroke1 = GestureDescription.StrokeDescription(path1, 0, 50)
        builder.addStroke(stroke1)
        
        // 第二次点击（间隔100ms）
        val stroke2 = GestureDescription.StrokeDescription(path2, 150, 50)
        builder.addStroke(stroke2)
        
        dispatchGesture(builder.build(), null, null)
        LogManager.d(TAG, "Performed Double Click at ($x, $y)")
    }
    
    /**
     * 执行拖拽操作
     * @param startX 起始X坐标
     * @param startY 起始Y坐标
     * @param endX 结束X坐标
     * @param endY 结束Y坐标
     * @param duration 拖拽时长（毫秒），默认500ms
     */
    fun performDrag(startX: Float, startY: Float, endX: Float, endY: Float, duration: Long = 500) {
        val path = Path()
        path.moveTo(startX, startY)
        path.lineTo(endX, endY)
        val builder = GestureDescription.Builder()
        val stroke = GestureDescription.StrokeDescription(path, 0, duration)
        builder.addStroke(stroke)
        dispatchGesture(builder.build(), null, null)
        LogManager.d(TAG, "Performed Drag from ($startX, $startY) to ($endX, $endY)")
    }
    
    /**
     * 执行缩放手势（双指）
     * @param centerX 中心X坐标
     * @param centerY 中心Y坐标
     * @param scaleIn true为缩小，false为放大
     */
    fun performPinch(centerX: Float, centerY: Float, scaleIn: Boolean = false) {
        val distance = if (scaleIn) 400f else 100f
        val endDistance = if (scaleIn) 100f else 400f
        
        val path1 = Path()
        val path2 = Path()
        
        if (scaleIn) {
            // 从外向内
            path1.moveTo(centerX - distance, centerY)
            path1.lineTo(centerX - endDistance, centerY)
            
            path2.moveTo(centerX + distance, centerY)
            path2.lineTo(centerX + endDistance, centerY)
        } else {
            // 从内向外
            path1.moveTo(centerX - distance, centerY)
            path1.lineTo(centerX - endDistance, centerY)
            
            path2.moveTo(centerX + distance, centerY)
            path2.lineTo(centerX + endDistance, centerY)
        }
        
        val builder = GestureDescription.Builder()
        val stroke1 = GestureDescription.StrokeDescription(path1, 0, 300)
        val stroke2 = GestureDescription.StrokeDescription(path2, 0, 300)
        
        builder.addStroke(stroke1)
        builder.addStroke(stroke2)
        
        dispatchGesture(builder.build(), null, null)
        LogManager.d(TAG, "Performed Pinch at ($centerX, $centerY), scaleIn=$scaleIn")
    }
    
    // ==================== 🆕 挂起函数（可等待完成） ====================
    
    /**
     * 🎯 点击指定坐标（挂起函数，等待完成）
     */
    suspend fun tapAsync(x: Float, y: Float): Boolean = suspendCancellableCoroutine { cont ->
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .build()
        
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                LogManager.d(TAG, "✅ Tap completed at ($x, $y)")
                cont.resume(true)
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                LogManager.w(TAG, "❌ Tap cancelled at ($x, $y)")
                cont.resume(false)
            }
        }, null)
    }
    
    /**
     * 🎯 长按指定坐标（挂起函数）
     */
    suspend fun longPressAsync(x: Float, y: Float, durationMs: Long = 2000): Boolean = 
        suspendCancellableCoroutine { cont ->
            val path = Path().apply { moveTo(x, y) }
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
                .build()
            
            dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    LogManager.d(TAG, "✅ Long press completed at ($x, $y)")
                    cont.resume(true)
                }
                override fun onCancelled(gestureDescription: GestureDescription?) {
                    LogManager.w(TAG, "❌ Long press cancelled at ($x, $y)")
                    cont.resume(false)
                }
            }, null)
        }
    
    /**
     * 🎯 滑动操作（挂起函数）
     */
    suspend fun swipeAsync(
        startX: Float, startY: Float, 
        endX: Float, endY: Float, 
        durationMs: Long = 300
    ): Boolean = suspendCancellableCoroutine { cont ->
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                LogManager.d(TAG, "✅ Swipe completed from ($startX,$startY) to ($endX,$endY)")
                cont.resume(true)
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                LogManager.w(TAG, "❌ Swipe cancelled")
                cont.resume(false)
            }
        }, null)
    }
    
    // ==================== 🆕 文本输入 ====================
    
    /**
     * 📝 在当前焦点元素输入文本
     */
    fun inputText(text: String): Boolean {
        val focusedNode = findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: run {
            LogManager.w(TAG, "❌ No focused input field")
            return false
        }
        
        val arguments = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        
        val result = focusedNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
        
        LogManager.d(TAG, if (result) "✅ Text input success" else "❌ Text input failed")
        return result
    }
    
    // ==================== 🆕 应用启动 ====================
    
    /**
     * 🚀 启动应用
     */
    fun launchApp(packageName: String): Boolean {
        return try {
            val intent = packageManager.getLaunchIntentForPackage(packageName)
            intent?.let {
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                startActivity(it)
                LogManager.d(TAG, "✅ Launched app: $packageName")
                true
            } ?: run {
                LogManager.w(TAG, "❌ App not found: $packageName")
                false
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ Launch app failed", e)
            false
        }
    }
    
    // ==================== 🆕 屏幕信息 ====================
    
    /**
     * 📱 获取当前前台应用包名
     */
    fun getCurrentPackageName(): String? = rootInActiveWindow?.packageName?.toString()
    
    /**
     * 📱 获取屏幕尺寸
     */
    fun getScreenSize(): Pair<Int, Int> {
        val metrics = resources.displayMetrics
        return Pair(metrics.widthPixels, metrics.heightPixels)
    }
    
    // ==================== 🆕 截图功能 (Android 11+) ====================
    
    /**
     * 📸 截取屏幕（Android 11+）
     */
    @RequiresApi(Build.VERSION_CODES.R)
    suspend fun takeScreenshotAsync(): Bitmap? = suspendCancellableCoroutine { cont ->
        takeScreenshot(
            Display.DEFAULT_DISPLAY,
            mainExecutor,
            object : TakeScreenshotCallback {
                override fun onSuccess(screenshot: ScreenshotResult) {
                    val bitmap = Bitmap.wrapHardwareBuffer(
                        screenshot.hardwareBuffer, 
                        screenshot.colorSpace
                    )?.copy(Bitmap.Config.ARGB_8888, false)
                    screenshot.hardwareBuffer.close()
                    LogManager.d(TAG, "✅ Screenshot success: ${bitmap?.width}x${bitmap?.height}")
                    cont.resume(bitmap)
                }
                
                override fun onFailure(errorCode: Int) {
                    LogManager.e(TAG, "❌ Screenshot failed: errorCode=$errorCode")
                    cont.resume(null)
                }
            }
        )
    }
    
    /**
     * 📸 检查是否支持截图
     */
    fun canTakeScreenshot(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R
    
    // ==================== 🆕 屏幕元素分析 ====================
    
    /**
     * 📱 获取当前屏幕所有可点击元素
     * @return 可点击元素列表，包含文本、位置等信息
     */
    fun getClickableElements(): List<ScreenElement> {
        val elements = mutableListOf<ScreenElement>()
        val rootNode = rootInActiveWindow ?: return elements
        
        traverseNode(rootNode, elements) { node ->
            node.isClickable || node.isLongClickable || node.isCheckable
        }
        
        return elements
    }
    
    /**
     * 📱 获取当前屏幕所有文本元素
     */
    fun getTextElements(): List<ScreenElement> {
        val elements = mutableListOf<ScreenElement>()
        val rootNode = rootInActiveWindow ?: return elements
        
        traverseNode(rootNode, elements) { node ->
            !node.text.isNullOrBlank() || !node.contentDescription.isNullOrBlank()
        }
        
        return elements
    }
    
    /**
     * 📱 获取当前屏幕所有输入框
     */
    fun getInputFields(): List<ScreenElement> {
        val elements = mutableListOf<ScreenElement>()
        val rootNode = rootInActiveWindow ?: return elements
        
        traverseNode(rootNode, elements) { node ->
            node.isEditable
        }
        
        return elements
    }
    
    /**
     * 🔍 根据文本查找元素并点击
     * @param text 要查找的文本
     * @return 是否成功
     */
    suspend fun findAndClick(text: String): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val targetNode = findNodeByText(rootNode, text)
        
        if (targetNode != null) {
            val rect = android.graphics.Rect()
            targetNode.getBoundsInScreen(rect)
            val centerX = rect.centerX().toFloat()
            val centerY = rect.centerY().toFloat()
            return tapAsync(centerX, centerY)
        }
        
        return false
    }
    
    /**
     * 🔍 根据文本查找元素并长按
     */
    suspend fun findAndLongPress(text: String, durationMs: Long = 2000): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val targetNode = findNodeByText(rootNode, text)
        
        if (targetNode != null) {
            val rect = android.graphics.Rect()
            targetNode.getBoundsInScreen(rect)
            val centerX = rect.centerX().toFloat()
            val centerY = rect.centerY().toFloat()
            return longPressAsync(centerX, centerY, durationMs)
        }
        
        return false
    }
    
    /**
     * 📝 根据文本查找输入框并输入
     */
    fun findAndInput(hint: String, text: String): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val targetNode = findEditableNode(rootNode, hint)
        
        if (targetNode != null) {
            val arguments = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            }
            val result = targetNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
            return result
        }
        
        return false
    }
    
    /**
     * 📱 获取屏幕元素树的 JSON 描述（供 AI 分析）
     */
    fun getScreenElementsJson(): String {
        val elements = getClickableElements() + getTextElements()
        val uniqueElements = elements.distinctBy { "${it.bounds}" }
        
        val jsonArray = uniqueElements.take(50).map { element ->
            """{"text":"${element.text.replace("\"", "\\\"")}","type":"${element.className}","bounds":[${element.bounds.left},${element.bounds.top},${element.bounds.right},${element.bounds.bottom}],"clickable":${element.isClickable}}"""
        }
        
        return "[${jsonArray.joinToString(",")}]"
    }
    
    // ==================== 私有辅助方法 ====================
    
    private fun traverseNode(
        node: AccessibilityNodeInfo,
        elements: MutableList<ScreenElement>,
        filter: (AccessibilityNodeInfo) -> Boolean
    ) {
        if (filter(node)) {
            val rect = android.graphics.Rect()
            node.getBoundsInScreen(rect)
            
            // 过滤掉不可见或太小的元素
            if (rect.width() > 10 && rect.height() > 10) {
                elements.add(ScreenElement(
                    text = node.text?.toString() ?: node.contentDescription?.toString() ?: "",
                    className = node.className?.toString() ?: "",
                    bounds = rect,
                    isClickable = node.isClickable,
                    isEditable = node.isEditable,
                    viewId = node.viewIdResourceName ?: ""
                ))
            }
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            traverseNode(child, elements, filter)
        }
    }
    
    private fun findNodeByText(node: AccessibilityNodeInfo, text: String): AccessibilityNodeInfo? {
        val nodeText = node.text?.toString() ?: node.contentDescription?.toString() ?: ""
        if (nodeText.contains(text, ignoreCase = true)) {
            return node
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findNodeByText(child, text)
            if (found != null) return found
        }
        
        return null
    }
    
    private fun findEditableNode(node: AccessibilityNodeInfo, hint: String): AccessibilityNodeInfo? {
        if (node.isEditable) {
            val nodeText = node.text?.toString() ?: node.contentDescription?.toString() ?: ""
            if (hint.isBlank() || nodeText.contains(hint, ignoreCase = true)) {
                return node
            }
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findEditableNode(child, hint)
            if (found != null) return found
        }
        
        return null
    }
}

/**
 * 📱 屏幕元素数据类
 */
data class ScreenElement(
    val text: String,
    val className: String,
    val bounds: android.graphics.Rect,
    val isClickable: Boolean,
    val isEditable: Boolean,
    val viewId: String
)
