package com.example.xihe.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.xihe.utils.LogManager
import com.example.xihe.service.XiheBackgroundService
import com.example.xihe.service.KeepAliveService

/**
 * 🚀 开机自启动接收器
 * 
 * 功能：
 * - 手机开机后自动启动后台服务
 * - 启动保活服务
 * - 确保羲和AI持续守护
 */
class BootReceiver : BroadcastReceiver() {
    
    companion object {
        private const val TAG = "BootReceiver"
    }
    
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_LOCKED_BOOT_COMPLETED,
            "android.intent.action.QUICKBOOT_POWERON" -> {
                val prefs = context.getSharedPreferences("xihe_settings", Context.MODE_PRIVATE)
                val enableBackgroundWake = prefs.getBoolean("enable_background_wake", false)
                if (!enableBackgroundWake) {
                    LogManager.d(TAG, "ℹ️ 后台唤醒未开启，跳过开机自动拉起")
                    return
                }

                LogManager.d(TAG, "📱 检测到开机，启动后台保活服务...")
                
                try {
                    // 启动保活服务（优先）
                    KeepAliveService.start(context)
                    LogManager.d(TAG, "✅ 保活服务启动成功")
                    
                    // 启动后台服务
                    XiheBackgroundService.start(context)
                    LogManager.d(TAG, "✅ 后台服务启动成功")
                } catch (e: Exception) {
                    LogManager.i(TAG, "❌ 服务启动失败: ${e.message}", e)
                }
            }
        }
    }
}
