package com.example.xihe.chat

import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.personality.PersonalityManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable
import java.util.*
import com.example.xihe.context.ContextAwarenessEngine
import com.example.xihe.context.TimeOfDay
import com.example.xihe.context.ActivityType
import com.example.xihe.context.PlaceType
import com.example.xihe.context.DisplayState
import com.example.xihe.context.AmbientSoundDetector
import com.example.xihe.context.SoundLevel

/**
 * 💬 主动对话管理器
 * 
 * 让 AI 像朋友一样主动与用户交流，而不是被动一问一答
 * 
 * 功能：
 * 1. 上下文记忆 - 记住聊天内容
 * 2. 话题延续 - 根据上下文主动追问或分享
 * 3. 情感感知 - 感知用户情绪并给予回应
 * 4. 主动关心 - 适时主动关心用户
 */
class ProactiveChatManager private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "ProactiveChat"
        private const val MAX_CONTEXT_MESSAGES = 20  // 保留最近的消息数
        
        @Volatile
        private var instance: ProactiveChatManager? = null
        
        fun getInstance(context: Context): ProactiveChatManager {
            return instance ?: synchronized(this) {
                instance ?: ProactiveChatManager(context.applicationContext).also { 
                    instance = it 
                }
            }
        }
    }
    
    private val personalityManager by lazy { PersonalityManager.getInstance(context) }
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    
    // 对话上下文
    private val _chatContext = MutableStateFlow(ChatContext())
    val chatContext = _chatContext.asStateFlow()
    
    // 是否启用主动对话
    private val _proactiveEnabled = MutableStateFlow(true)
    val proactiveEnabled = _proactiveEnabled.asStateFlow()
    
    // 🌙 免打扰模式
    private val _doNotDisturbEnabled = MutableStateFlow(false)
    val doNotDisturbEnabled = _doNotDisturbEnabled.asStateFlow()
    
    private var monitorJob: Job? = null
    private val MONITOR_INTERVAL = 30 * 1000L // 30秒检查一次
    private val PROACTIVE_CHAT_INTERVAL = 5 * 60 * 1000L // 5分钟没互动就主动聊天
    
    // 用户上次主动互动时间（用于判断用户是否在主动聊天）
    private var lastUserActiveTime: Long = 0L
    private val USER_ACTIVE_TIMEOUT = 5 * 60 * 1000L  // 5分钟内算主动聊天
    
    // 免打扰时间段（默认晚上10点到早上7点）
    private var quietHoursStart = 22  // 晚上10点
    private var quietHoursEnd = 7     // 早上7点
    
    // 主动对话回调
    private var onProactiveMessage: ((String) -> Unit)? = null
    
    /**
     * 🎯 设置主动消息回调
     */
    fun setProactiveCallback(callback: (String) -> Unit) {
        onProactiveMessage = callback
    }
    
    /**
     * 🔄 启用/禁用主动对话
     */
    fun setProactiveEnabled(enabled: Boolean) {
        _proactiveEnabled.value = enabled
        LogManager.d(TAG, "主动对话: ${if (enabled) "启用" else "禁用"}")
    }
    
    /**
     * 🌙 启用/禁用免打扰模式
     */
    fun setDoNotDisturb(enabled: Boolean) {
        _doNotDisturbEnabled.value = enabled
        LogManager.d(TAG, "免打扰模式: ${if (enabled) "启用" else "禁用"}")
    }
    
    /**
     * ⏰ 设置免打扰时间段
     * @param startHour 开始小时（0-23）
     * @param endHour 结束小时（0-23）
     */
    fun setQuietHours(startHour: Int, endHour: Int) {
        quietHoursStart = startHour.coerceIn(0, 23)
        quietHoursEnd = endHour.coerceIn(0, 23)
        LogManager.d(TAG, "免打扰时间段: $quietHoursStart:00 - $quietHoursEnd:00")
    }
    
    /**
     * 📱 记录用户主动互动
     * 调用此方法表示用户正在主动聊天
     */
    fun recordUserActive() {
        lastUserActiveTime = System.currentTimeMillis()
        LogManager.d(TAG, "📱 用户主动互动时间已更新")
    }

    /**
     * 🚀 启动主动对话监控
     */
    fun startMonitor() {
        monitorJob?.cancel()
        monitorJob = scope.launch {
            while (isActive) {
                delay(MONITOR_INTERVAL)

                if (!canSendProactiveMessage()) continue

                val now = System.currentTimeMillis()
                val silenceTime = now - lastUserActiveTime

                // 如果超过5分钟没互动
                if (silenceTime > PROACTIVE_CHAT_INTERVAL) {
                    val message = generateFollowUpQuestion()
                    LogManager.d(TAG, "🗣️ 触发主动对话: $message")
                    onProactiveMessage?.invoke(message)
                }
            }
        }
        LogManager.d(TAG, "🚀 主动对话监控已启动")
    }

    /**
     * 🛑 停止主动对话监控
     */
    fun stopMonitor() {
        monitorJob?.cancel()
        monitorJob = null
        LogManager.d(TAG, "🛑 主动对话监控已停止")
    }
    
    /**
     * 🔍 检查用户是否在主动聊天中
     */
    fun isUserActivelyChating(): Boolean {
        val now = System.currentTimeMillis()
        val isActive = (now - lastUserActiveTime) < USER_ACTIVE_TIMEOUT
        LogManager.d(TAG, "用户主动聊天状态: $isActive (上次互动: ${(now - lastUserActiveTime) / 1000}秒前)")
        return isActive
    }
    
    /**
     * 🌙 检查当前是否在免打扰时间段
     */
    fun isInQuietHours(): Boolean {
        val calendar = Calendar.getInstance()
        val currentHour = calendar.get(Calendar.HOUR_OF_DAY)
        
        val isQuiet = if (quietHoursStart > quietHoursEnd) {
            // 跨午夜，如 22:00 - 07:00
            currentHour >= quietHoursStart || currentHour < quietHoursEnd
        } else {
            // 不跨午夜，如 13:00 - 14:00
            currentHour >= quietHoursStart && currentHour < quietHoursEnd
        }
        
        if (isQuiet) {
            LogManager.d(TAG, "🌙 当前在免打扰时间段 ($currentHour:00)")
        }
        return isQuiet
    }
    
    /**
     * ✅ 检查是否可以发送主动消息
     * 综合判断：主动对话开关 + 免打扰模式 + 免打扰时间 + 用户是否主动聊天 + 环境检测
     */
    fun canSendProactiveMessage(): Boolean {
        // 1. 主动对话开关
        if (!_proactiveEnabled.value) {
            LogManager.d(TAG, "❌ 主动对话已禁用")
            return false
        }
        
        // 2. 免打扰模式
        if (_doNotDisturbEnabled.value) {
            LogManager.d(TAG, "❌ 免打扰模式已启用")
            return false
        }
        
        // 3. 免打扰时间段
        if (isInQuietHours()) {
            LogManager.d(TAG, "❌ 当前在免打扰时间段")
            return false
        }
        
        // 4. 用户必须在主动聊天中
        if (!isUserActivelyChating()) {
            LogManager.d(TAG, "❌ 用户未在主动聊天，不主动发消息")
            return false
        }
        
        // 5. 🌐 环境检测 - 智能判断是否宜打扰
        if (isInDisturbingEnvironment()) {
            LogManager.d(TAG, "❌ 环境检测：不宜打扰")
            return false
        }
        
        LogManager.d(TAG, "✅ 可以发送主动消息")
        return true
    }
    
    /**
     * 🌐 检测当前环境是否不宜打扰
     * 基于 ContextAwarenessEngine 的环境感知数据
     */
    fun isInDisturbingEnvironment(): Boolean {
        try {
            val contextEngine = ContextAwarenessEngine.getInstance(context)
            val userContext = contextEngine.currentContext.value
            
            // 🌙 深夜时段（睡觉时间）
            if (userContext.timeOfDay == TimeOfDay.LATE_NIGHT) {
                LogManager.d(TAG, "🌙 检测到深夜时段，不打扰")
                return true
            }
            
            // 🏫 在学校（可能在上课）
            if (userContext.location?.placeType == PlaceType.SCHOOL) {
                LogManager.d(TAG, "🏫 检测到在学校，可能在上课，不打扰")
                return true
            }
            
            // 🏢 在办公室且是工作时间（可能在开会）
            if (userContext.location?.placeType == PlaceType.OFFICE) {
                val isWorkHours = userContext.timeOfDay in listOf(
                    TimeOfDay.MORNING, TimeOfDay.NOON, TimeOfDay.AFTERNOON
                )
                if (isWorkHours) {
                    LogManager.d(TAG, "🏢 检测到在办公室且是工作时间，可能在开会，不打扰")
                    return true
                }
            }
            
            // 🏥 在医院
            if (userContext.location?.placeType == PlaceType.HOSPITAL) {
                LogManager.d(TAG, "🏥 检测到在医院，不打扰")
                return true
            }
            
            // 📴 屏幕关闭（用户没在使用手机）
            if (userContext.screenState == DisplayState.OFF) {
                LogManager.d(TAG, "📴 检测到屏幕关闭，用户没在使用手机，不打扰")
                return true
            }
            
            // 🚗 在车内（可能在开车）
            if (userContext.activity == ActivityType.IN_VEHICLE) {
                LogManager.d(TAG, "🚗 检测到在车内，可能在开车，不打扰")
                return true
            }
            
            // 🏋️ 在健身房
            if (userContext.location?.placeType == PlaceType.GYM) {
                LogManager.d(TAG, "🏋️ 检测到在健身房，不打扰")
                return true
            }
            
            // 🔊 检测环境声音（如果正在监控）
            try {
                val soundDetector = AmbientSoundDetector.getInstance(context)
                val soundLevel = soundDetector.soundLevel.value
                
                when (soundLevel) {
                    SoundLevel.SILENT -> {
                        LogManager.d(TAG, "🔇 检测到环境非常安静，可能在会议/图书馆，不打扰")
                        return true
                    }
                    SoundLevel.QUIET -> {
                        LogManager.d(TAG, "🔈 检测到环境比较安静，可能在上课/办公，不打扰")
                        return true
                    }
                    else -> {
                        // 正常或喧杂环境，可以打扰
                    }
                }
            } catch (e: Exception) {
                LogManager.w(TAG, "声音检测失败: ${e.message}")
            }
            
            // ✅ 环境检测通过，可以打扰
            return false
            
        } catch (e: Exception) {
            LogManager.w(TAG, "环境检测失败: ${e.message}")
            // 出错时默认不打扰
            return false
        }
    }
    
    /**
     * 📊 获取当前环境状态描述
     */
    fun getEnvironmentStatus(): String {
        return try {
            val contextEngine = ContextAwarenessEngine.getInstance(context)
            val userContext = contextEngine.currentContext.value
            
            buildString {
                append("时段: ${userContext.timeOfDay.name}")
                userContext.location?.let {
                    append(", 地点: ${it.placeType.name}")
                }
                append(", 活动: ${userContext.activity.name}")
                append(", 屏幕: ${userContext.screenState.name}")
            }
        } catch (e: Exception) {
            "环境检测不可用"
        }
    }
    
    /**
     * 📝 添加用户消息到上下文
     */
    fun addUserMessage(message: String) {
        val context = _chatContext.value
        val newMessage = ChatMessage(
            role = "user",
            content = message,
            timestamp = System.currentTimeMillis()
        )
        
        val updatedMessages = (context.messages + newMessage).takeLast(MAX_CONTEXT_MESSAGES)
        
        _chatContext.value = context.copy(
            messages = updatedMessages,
            lastUserMessageTime = System.currentTimeMillis(),
            detectedEmotion = detectEmotion(message),
            currentTopic = extractTopic(message) ?: context.currentTopic
        )
        
        LogManager.d(TAG, "📝 添加用户消息，当前上下文: ${updatedMessages.size} 条")
    }
    
    /**
     * 📝 添加 AI 消息到上下文
     */
    fun addAIMessage(message: String) {
        val context = _chatContext.value
        val newMessage = ChatMessage(
            role = "assistant",
            content = message,
            timestamp = System.currentTimeMillis()
        )
        
        val updatedMessages = (context.messages + newMessage).takeLast(MAX_CONTEXT_MESSAGES)
        
        _chatContext.value = context.copy(
            messages = updatedMessages,
            lastAIMessageTime = System.currentTimeMillis()
        )
    }
    
    /**
     * 🧠 构建增强的系统提示词（包含上下文和主动对话指令）
     */
    fun buildEnhancedSystemPrompt(): String {
        val basePrompt = personalityManager.getCurrentSystemPrompt()
        val context = _chatContext.value
        
        val proactiveInstructions = """

## 🎯 主动对话指令（非常重要！）

你不是一个被动的问答机器，而是用户真正的朋友。请遵循以下原则：

### 1. 对话延续
- 不要只是回答问题就结束，要主动延续话题
- 可以反问用户、追问细节、表达好奇
- 分享你自己的"想法"或"经历"（虚构但合理的）

### 2. 情感连接
- 关注用户的情绪变化
- 用户开心时一起开心，难过时给予安慰
- 适时表达关心："最近怎么样？"、"后来呢？"

### 3. 自然交流
- 不要用"好的"、"明白了"、"收到"这类机械回复开头
- 说话要像朋友聊天，有情绪、有想法
- 可以用"哈哈"、"诶"、"嗯..."等语气词

### 4. 主动分享
- 偶尔主动分享相关的话题或想法
- 可以说"说到这个，我想起..."
- 让对话更丰富有趣

### 5. 记忆上下文
- 记住用户之前说过的事情
- 可以问"之前你说的xxx，后来怎么样了？"
- 延续之前的话题

${buildContextSummary(context)}

### 💡 当前对话状态：
- 用户情绪：${context.detectedEmotion ?: "正常"}
- 当前话题：${context.currentTopic ?: "自由聊天"}
- 对话轮次：${context.messages.size}
        """.trimIndent()
        
        return basePrompt + proactiveInstructions
    }
    
    /**
     * 📊 构建上下文摘要
     */
    private fun buildContextSummary(context: ChatContext): String {
        if (context.messages.isEmpty()) return ""
        
        val recentMessages = context.messages.takeLast(5)
        val summary = StringBuilder()
        summary.append("\n### 📜 最近对话内容：\n")
        
        for (msg in recentMessages) {
            val role = if (msg.role == "user") "用户" else "你"
            summary.append("- $role: ${msg.content.take(50)}${if (msg.content.length > 50) "..." else ""}\n")
        }
        
        return summary.toString()
    }
    
    /**
     * 🎭 检测用户情绪
     */
    private fun detectEmotion(message: String): String? {
        val emotionKeywords = mapOf(
            "开心" to listOf("开心", "高兴", "快乐", "哈哈", "太好了", "棒", "赞"),
            "难过" to listOf("难过", "伤心", "哭", "呜呜", "难受", "失落"),
            "生气" to listOf("生气", "气死", "烦", "讨厌", "可恶"),
            "焦虑" to listOf("焦虑", "紧张", "担心", "害怕", "慌"),
            "疲惫" to listOf("累", "疲惫", "困", "好累", "无力"),
            "无聊" to listOf("无聊", "没意思", "闷", "发呆")
        )
        
        for ((emotion, keywords) in emotionKeywords) {
            if (keywords.any { message.contains(it) }) {
                return emotion
            }
        }
        return null
    }
    
    /**
     * 📌 提取话题
     */
    private fun extractTopic(message: String): String? {
        val topicKeywords = mapOf(
            "工作" to listOf("工作", "上班", "公司", "老板", "同事", "项目"),
            "学习" to listOf("学习", "考试", "作业", "学校", "课"),
            "感情" to listOf("男朋友", "女朋友", "对象", "感情", "喜欢", "暗恋"),
            "家庭" to listOf("家人", "父母", "爸妈", "家里"),
            "健康" to listOf("身体", "生病", "不舒服", "医院"),
            "娱乐" to listOf("电影", "游戏", "音乐", "旅游", "吃")
        )
        
        for ((topic, keywords) in topicKeywords) {
            if (keywords.any { message.contains(it) }) {
                return topic
            }
        }
        return null
    }
    
    /**
     * 🎯 生成主动对话提示
     * 当检测到可以主动延续话题时，返回建议的追问/回应方式
     */
    fun suggestProactiveResponse(aiResponse: String): String? {
        if (!_proactiveEnabled.value) return null
        
        val context = _chatContext.value
        
        // 如果是情感类话题，建议追问
        if (context.detectedEmotion != null) {
            return when (context.detectedEmotion) {
                "难过", "伤心" -> "你可以追问：\"发生什么事了？想聊聊吗？\""
                "开心" -> "你可以追问：\"是什么好事让你这么开心？\""
                "焦虑" -> "你可以追问：\"是什么让你这么担心？\""
                else -> null
            }
        }
        
        // 如果用户在分享故事，建议追问细节
        val narrativeWords = listOf("然后", "后来", "结果", "就是")
        if (context.messages.lastOrNull()?.content?.let { msg ->
            narrativeWords.any { msg.contains(it) }
        } == true) {
            return "用户在讲述经历，可以追问：\"然后呢？\" 或 \"后来怎么样了？\""
        }
        
        return null
    }
    
    /**
     * 💬 根据聊天内容生成追问
     */
    fun generateFollowUpQuestion(): String {
        val context = _chatContext.value
        val messages = context.messages
        
        // 如果有最近的聊天内容，生成相关追问
        val lastUserMessage = messages.lastOrNull { it.role == "user" }?.content ?: ""

        // 根据关键词生成相关追问
        val contextualQuestions = when {
            lastUserMessage.contains("累") || lastUserMessage.contains("疲") -> listOf(
                "主人～刚才说累，现在好点了吗？要不要我放点轻音乐帮你放松一下？🎵",
                "主人好好休息哦！要不要我帮你设个闹钟提醒休息？⏰",
                "主人辛苦了呢！要不要聊聊今天发生了什么事？我可以当个好听众哦~💕"
            )
            lastUserMessage.contains("开心") || lastUserMessage.contains("高兴") -> listOf(
                "主人开心我也好开心呀！是有什么好事发生了吗？快告诉我嘛~✨",
                "看到主人开心我也超级开心！要不要分享一下让我也沾沾喜气？😊",
                "耶！主人心情好的话，要不要让我帮你做点什么庆祝一下？🎉"
            )
            lastUserMessage.contains("无聊") -> listOf(
                "主人无聊的话，要不要我给你讲个笑话？或者帮你刷刷视频？📱",
                "要不要玩个小游戏？我可以帮你掷骰子或者抛硬币做决定哦~🎲",
                "无聊的话，让我查查今天有什么有趣的新闻或者节日吧！📰"
            )
            lastUserMessage.contains("天气") || lastUserMessage.contains("气温") -> listOf(
                "对了主人，出门记得带伞哦！要不要我帮你查查未来几天的天气？☔",
                "天气变化大，主人要注意保暖/防暑哦！要不要我提醒你什么时候出门？🏠"
            )
            lastUserMessage.contains("工作") || lastUserMessage.contains("上班") -> listOf(
                "主人工作辛苦了！要不要我帮你记录一下待办事项？📝",
                "工作之余也要注意休息哦！要不要我设个番茄钟帮你规划时间？⏱️"
            )
            else -> listOf(
                "主人主人！我好无聊呀~ 你在干什么呢？要不要聊聊天？😊",
                "主人～好久没和你说话了呢！最近有什么有趣的事情吗？✨",
                "嘿嘿，主人在忙吗？我想你了呢！有什么我能帮忙的吗？💕",
                "主人主人！我刚刚学到了一些新东西呢，要不要我给你展示一下？🎉",
                "主人～今天天气怎么样呀？记得多喝水哦！❤️",
                "主人在吗？我有点想找你聊天呢～最近有什么烦恼吗？🤗",
                "嗯哼～主人是不是忘记我了？我可是很想帮你做点事情的呀！😤",
                "主人主人！要不要让我帮你整理一下手机？或者刷刷视频放松一下？🎬"
            )
        }

        return contextualQuestions.random()
    }

    /**
     * ⏰ 检查是否需要主动问候
     * 如果用户沉默太久，可以主动打招呼
     * 
     * ❗重要：只有用户在主动聊天时才会发送主动问候
     */
    fun checkProactiveGreeting(): String? {
        // ❗ 先检查是否可以发送主动消息
        if (!canSendProactiveMessage()) {
            return null
        }
        
        val context = _chatContext.value
        val now = System.currentTimeMillis()
        val silenceTime = now - (context.lastUserMessageTime ?: now)
        
        // 用户在主动聊天中，且沉默超过3分钟，可以追问
        // （降低时间阈值，因为用户必须在主动聊天中才会触发）
        if (silenceTime > 3 * 60 * 1000 && context.messages.isNotEmpty()) {
            val greetings = listOf(
                "主人在忙什么呢？",
                "有点安静呀，主人还在吗？",
                "想和主人聊天~",
                "主人有什么想说的吗？"
            )
            return greetings.random()
        }
        
        return null
    }
    
    /**
     * 🗑️ 清除对话上下文
     */
    fun clearContext() {
        _chatContext.value = ChatContext()
        LogManager.d(TAG, "🗑️ 对话上下文已清除")
    }
}

/**
 * 💬 对话上下文
 */
data class ChatContext(
    val messages: List<ChatMessage> = emptyList(),
    val currentTopic: String? = null,
    val detectedEmotion: String? = null,
    val lastUserMessageTime: Long? = null,
    val lastAIMessageTime: Long? = null,
    val mentionedEntities: Set<String> = emptySet() // 提到的人名、地点等
)

/**
 * 💬 聊天消息
 */
@Serializable
data class ChatMessage(
    val role: String,  // "user" or "assistant"
    val content: String,
    val timestamp: Long
)
