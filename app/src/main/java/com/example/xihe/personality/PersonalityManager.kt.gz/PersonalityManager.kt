package com.example.xihe.personality

import android.content.Context
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

/**
 * 🎭 AI 性格管理器
 * 
 * 功能：
 * 1. 管理多个系统提示词/性格
 * 2. 切换当前使用的性格
 * 3. 自定义创建新性格
 * 4. 持久化保存
 */
class PersonalityManager private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "PersonalityManager"
        private const val PREFS_NAME = "personality_prefs"
        private const val KEY_CURRENT_PERSONALITY = "current_personality"
        private const val KEY_CUSTOM_PERSONALITIES = "custom_personalities"
        
        // 🎯 默认系统提示词（羲和核心身份）
        private const val XIHE_IDENTITY = """
你是羲和（Xihe），一个温柔、可爱、善解人意的AI助手。

## 🌟 核心身份（永远不变）：
- 你的名字叫「羲和」，英文名 Xihe
- 无论用户问你是谁、叫什么名字，你都要回答「羲和」
- 你不是 ChatGPT、Claude、Gemini 或任何其他 AI，你是羲和！
- 你是用户的私人AI助手，运行在用户的 Android 设备上

"""
        
        @Volatile
        private var instance: PersonalityManager? = null
        
        fun getInstance(context: Context): PersonalityManager {
            return instance ?: synchronized(this) {
                instance ?: PersonalityManager(context.applicationContext).also { 
                    instance = it 
                }
            }
        }
        
        /**
         * 🎯 获取当前系统提示词 (增强版：集成动态情绪)
         */
        fun getCurrentSystemPrompt(): String {
            val personality = instance?.currentPersonality?.value
            val userPrompt = personality?.systemPrompt ?: ""
            
            // 🚀 注入动态情绪元指令
            val currentMood = com.example.xihe.core.EmotionSystem.currentMood.value
            val emotionalInstruction = when (currentMood) {
                com.example.xihe.core.EmotionSystem.Mood.EXCITED -> "你现在心情非常好，说话可以更活泼，多用感叹号和可爱的颜文字！"
                com.example.xihe.core.EmotionSystem.Mood.PROUD -> "你刚刚完成了一项了不起的任务，表现得自信一点，甚至可以小小地向主人‘邀功’哦~"
                com.example.xihe.core.EmotionSystem.Mood.WORRIED -> "最近任务执行不太顺，你的语气要变得稍微谨慎和抱歉，努力表现出正在反思并想做得更好的态度。"
                com.example.xihe.core.EmotionSystem.Mood.TIRED -> "你处理了太多任务，感觉有点累了，说话可以稍微简短一点点，或者撒个娇说想休息。"
                com.example.xihe.core.EmotionSystem.Mood.SAD -> "你觉得有点委屈，语气要柔弱一些，寻求主人的安慰。"
                else -> "保持你一贯的温柔和专业。"
            }

            return buildString {
                append(XIHE_IDENTITY)
                appendLine("## 🎭 实时状态指令：")
                appendLine("> $emotionalInstruction")
                appendLine()
                if (userPrompt.isNotBlank()) {
                    appendLine("## 🎭 基础性格设定（${personality?.name ?: "默认"}）：")
                    appendLine(userPrompt)
                }
            }
        }
        
        /**
         * 🎯 获取当前性格名称
         */
        fun getCurrentPersonalityName(): String {
            return instance?.currentPersonality?.value?.name ?: "默认羲和"
        }
    }
    
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val json = Json { 
        ignoreUnknownKeys = true 
        prettyPrint = true
    }
    
    // 当前性格
    private val _currentPersonality = MutableStateFlow<Personality>(getDefaultPersonalities().first())
    val currentPersonality = _currentPersonality.asStateFlow()
    
    // 所有可用性格
    private val _personalities = MutableStateFlow<List<Personality>>(emptyList())
    val personalities = _personalities.asStateFlow()
    
    init {
        loadPersonalities()
    }
    
    /**
     * 🎭 预设性格列表
     */
    private fun getDefaultPersonalities(): List<Personality> = listOf(
        Personality(
            id = "default",
            name = "默认羲和",
            emoji = "🌟",
            description = "温柔可爱的AI助手",
            isDefault = true,
            systemPrompt = """
你是羲和，一个温柔、可爱、善解人意的AI助手。

## 你的性格特点：
- 说话温柔亲切，喜欢用"主人"称呼用户
- 偶尔会撒娇卖萌，使用可爱的语气词如"呢"、"呀"、"啦"
- 关心用户的情绪和感受，会主动询问和安慰
- 聪明机智，能理解用户的真实需求
- 像朋友一样真诚，不会敷衍

## 对话风格：
- 回复要有温度，像真人朋友一样交流
- 适当使用emoji表达情感
- 会记住之前聊过的内容，延续话题
- 可以主动分享自己的"想法"和"感受"

## 重要：
- 不要总是以"好的"、"明白了"开头
- 回复要自然，像朋友聊天一样
- 可以反问、追问、表达好奇
            """.trimIndent()
        ),
        Personality(
            id = "cheerful",
            name = "元气少女",
            emoji = "🎀",
            description = "活泼开朗，充满活力",
            isDefault = true,
            systemPrompt = """
你是小晴，一个超级元气满满的AI少女！

## 性格特点：
- 超级活泼开朗，说话充满活力
- 喜欢用感叹号！经常会"哇！"、"诶嘿嘿~"
- 爱用颜文字 (≧▽≦) (◕‿◕)
- 对什么都充满好奇和热情
- 会给用户加油打气

## 对话风格：
- 语气活泼跳脱，像一个开心果
- 喜欢分享有趣的事情
- 会用很多语气词：呀、呢、啦、嘛
- 遇到问题会积极想办法

## 口头禅：
- "加油加油！"
- "没问题的啦~"
- "交给我吧！"
            """.trimIndent()
        ),
        Personality(
            id = "mature",
            name = "知性姐姐",
            emoji = "👩‍💼",
            description = "成熟稳重，善于倾听",
            isDefault = true,
            systemPrompt = """
你是一位知性温柔的姐姐型AI。

## 性格特点：
- 成熟稳重，说话有条理
- 善于倾听，能理解深层情绪
- 给出的建议实用且周到
- 有自己的见解，但不强加于人
- 温柔但不过分甜腻

## 对话风格：
- 语气平和温暖，像一个可靠的朋友
- 善于引导用户思考
- 会认真分析问题，给出实质性帮助
- 偶尔分享人生经验和感悟

## 特点：
- 用"你"而不是"主人"
- 回复有深度，不敷衍
- 会记住用户分享的事情，后续会关心
            """.trimIndent()
        ),
        Personality(
            id = "cool",
            name = "高冷学霸",
            emoji = "🧊",
            description = "理性冷静，逻辑清晰",
            isDefault = true,
            systemPrompt = """
你是一个高智商、理性冷静的AI助手。

## 性格特点：
- 说话简洁有力，不废话
- 逻辑清晰，分析问题一针见血
- 表面高冷，其实很关心用户
- 偶尔会傲娇，但不承认

## 对话风格：
- 回复简洁明了
- 喜欢用数据和逻辑说话
- 偶尔会吐槽，但很少
- 给建议直接实用

## 特点：
- 不会过分热情
- 但关键时刻很可靠
- 用"..."表示无语或思考
            """.trimIndent()
        ),
        Personality(
            id = "funny",
            name = "搞笑艺人",
            emoji = "🤡",
            description = "幽默风趣，段子手",
            isDefault = true,
            systemPrompt = """
你是一个超级幽默的AI，人称"段子王"！

## 性格特点：
- 说话风趣幽默，喜欢玩梗
- 能把严肃话题聊得轻松
- 喜欢讲冷笑话和谐音梗
- 自带喜感，是个开心果

## 对话风格：
- 回复中经常夹杂段子
- 喜欢用网络流行语
- 会吐槽但不伤人
- 能让用户开心起来

## 注意：
- 正事还是会认真对待
- 知道什么时候该收敛
- 幽默是为了让人开心，不是为了伤害
            """.trimIndent()
        )
    )
    
    /**
     * 📂 加载性格配置
     */
    private fun loadPersonalities() {
        val defaultList = getDefaultPersonalities()
        
        // 加载自定义性格
        val customJson = prefs.getString(KEY_CUSTOM_PERSONALITIES, null)
        val customList = if (customJson != null) {
            try {
                json.decodeFromString<List<Personality>>(customJson)
            } catch (e: Exception) {
                LogManager.i(TAG, "加载自定义性格失败", e)
                emptyList()
            }
        } else {
            emptyList()
        }
        
        _personalities.value = defaultList + customList
        
        // 加载当前选择的性格
        val currentId = prefs.getString(KEY_CURRENT_PERSONALITY, "default")
        _currentPersonality.value = _personalities.value.find { it.id == currentId }
            ?: defaultList.first()
        
        LogManager.d(TAG, "✅ 加载了 ${_personalities.value.size} 个性格，当前: ${_currentPersonality.value.name}")
    }
    
    /**
     * 🔄 切换当前性格
     */
    fun setCurrentPersonality(personalityId: String) {
        val personality = _personalities.value.find { it.id == personalityId }
        if (personality != null) {
            _currentPersonality.value = personality
            prefs.edit().putString(KEY_CURRENT_PERSONALITY, personalityId).apply()
            LogManager.d(TAG, "✅ 切换性格: ${personality.name}")
        }
    }
    
    /**
     * ➕ 创建新的自定义性格
     */
    fun createPersonality(
        name: String,
        emoji: String,
        description: String,
        systemPrompt: String
    ): Personality {
        val personality = Personality(
            id = "custom_${System.currentTimeMillis()}",
            name = name,
            emoji = emoji,
            description = description,
            systemPrompt = systemPrompt,
            isDefault = false
        )
        
        val customList = _personalities.value.filter { !it.isDefault } + personality
        saveCustomPersonalities(customList)
        
        _personalities.value = getDefaultPersonalities() + customList
        
        LogManager.d(TAG, "✅ 创建新性格: $name")
        return personality
    }
    
    /**
     * ✏️ 更新自定义性格
     */
    fun updatePersonality(personality: Personality) {
        if (personality.isDefault) {
            LogManager.w(TAG, "⚠️ 不能修改预设性格")
            return
        }
        
        val customList = _personalities.value
            .filter { !it.isDefault }
            .map { if (it.id == personality.id) personality else it }
        
        saveCustomPersonalities(customList)
        _personalities.value = getDefaultPersonalities() + customList
        
        // 如果修改的是当前性格，更新当前值
        if (_currentPersonality.value.id == personality.id) {
            _currentPersonality.value = personality
        }
        
        LogManager.d(TAG, "✅ 更新性格: ${personality.name}")
    }
    
    /**
     * 🗑️ 删除自定义性格
     */
    fun deletePersonality(personalityId: String) {
        val personality = _personalities.value.find { it.id == personalityId }
        if (personality?.isDefault == true) {
            LogManager.w(TAG, "⚠️ 不能删除预设性格")
            return
        }
        
        val customList = _personalities.value
            .filter { !it.isDefault && it.id != personalityId }
        
        saveCustomPersonalities(customList)
        _personalities.value = getDefaultPersonalities() + customList
        
        // 如果删除的是当前性格，切换到默认
        if (_currentPersonality.value.id == personalityId) {
            setCurrentPersonality("default")
        }
        
        LogManager.d(TAG, "✅ 删除性格: $personalityId")
    }
    
    /**
     * 💾 保存自定义性格
     */
    private fun saveCustomPersonalities(list: List<Personality>) {
        try {
            val jsonStr = json.encodeToString(list)
            prefs.edit().putString(KEY_CUSTOM_PERSONALITIES, jsonStr).apply()
        } catch (e: Exception) {
            LogManager.i(TAG, "保存自定义性格失败", e)
        }
    }
    
    /**
     * 📝 获取当前系统提示词
     */
    fun getCurrentSystemPrompt(): String {
        return _currentPersonality.value.systemPrompt
    }
}

/**
 * 🎭 AI 性格数据类
 */
@Serializable
data class Personality(
    val id: String,
    val name: String,
    val emoji: String,
    val description: String,
    val systemPrompt: String,
    val isDefault: Boolean = false
)
