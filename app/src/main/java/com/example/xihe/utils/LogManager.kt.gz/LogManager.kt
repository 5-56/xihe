package com.example.xihe.utils

import android.util.Log
import com.example.xihe.BuildConfig

/**
 * 📝 统一日志管理器
 * 
 * 在Release版本自动关闭Debug日志，提升性能
 * 支持日志级别控制和日志缓存
 */
object LogManager {
    
    // 是否为Debug模式
    private val isDebug: Boolean = BuildConfig.DEBUG
    
    // 日志级别
    enum class Level { VERBOSE, DEBUG, INFO, WARN, ERROR }
    
    // 当前最小日志级别
    var minLevel: Level = if (isDebug) Level.VERBOSE else Level.WARN
    
    // 日志缓存（用于错误报告）
    private val logBuffer = mutableListOf<LogEntry>()
    private const val MAX_BUFFER_SIZE = 100
    
    data class LogEntry(
        val level: Level,
        val tag: String,
        val message: String,
        val timestamp: Long = System.currentTimeMillis()
    )
    
    /**
     * 📗 Verbose 日志
     */
    fun v(tag: String, message: String) {
        if (shouldLog(Level.VERBOSE)) {
            Log.v(tag, message)
            addToBuffer(Level.VERBOSE, tag, message)
        }
    }
    
    /**
     * 📘 Debug 日志
     */
    fun d(tag: String, message: String, throwable: Throwable? = null) {
        if (shouldLog(Level.DEBUG)) {
            if (throwable != null) {
                Log.d(tag, message, throwable)
            } else {
                Log.d(tag, message)
            }
            addToBuffer(Level.DEBUG, tag, message)
        }
    }
    
    /**
     * 📙 Info 日志
     */
    fun i(tag: String, message: String, throwable: Throwable? = null) {
        if (shouldLog(Level.INFO)) {
            if (throwable != null) {
                Log.i(tag, message, throwable)
            } else {
                Log.i(tag, message)
            }
            addToBuffer(Level.INFO, tag, message)
        }
    }
    
    /**
     * 📕 Warn 日志
     */
    fun w(tag: String, message: String, throwable: Throwable? = null) {
        if (shouldLog(Level.WARN)) {
            if (throwable != null) {
                Log.w(tag, message, throwable)
            } else {
                Log.w(tag, message)
            }
            addToBuffer(Level.WARN, tag, message)
        }
    }
    
    /**
     * 📕 Error 日志
     */
    fun e(tag: String, message: String, throwable: Throwable? = null) {
        // Error日志始终输出
        if (throwable != null) {
            Log.e(tag, message, throwable)
        } else {
            Log.e(tag, message)
        }
        addToBuffer(Level.ERROR, tag, message)
    }
    
    /**
     * 🔍 检查是否应该输出日志
     */
    private fun shouldLog(level: Level): Boolean {
        return level.ordinal >= minLevel.ordinal
    }
    
    /**
     * 💾 添加到缓存
     */
    private fun addToBuffer(level: Level, tag: String, message: String) {
        synchronized(logBuffer) {
            logBuffer.add(LogEntry(level, tag, message))
            if (logBuffer.size > MAX_BUFFER_SIZE) {
                logBuffer.removeAt(0)
            }
        }
    }
    
    /**
     * 📋 获取最近的日志
     */
    fun getRecentLogs(count: Int = 50): List<LogEntry> {
        synchronized(logBuffer) {
            return logBuffer.takeLast(count)
        }
    }
    
    /**
     * 📤 导出日志为文本
     */
    fun exportLogs(): String {
        return synchronized(logBuffer) {
            logBuffer.joinToString("\n") { entry ->
                val time = java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.getDefault())
                    .format(java.util.Date(entry.timestamp))
                "[$time] [${entry.level}] ${entry.tag}: ${entry.message}"
            }
        }
    }
    
    /**
     * 🧹 清空日志缓存
     */
    fun clearBuffer() {
        synchronized(logBuffer) {
            logBuffer.clear()
        }
    }
}

/**
 * 🔧 扩展函数 - 便捷日志调用
 */
fun Any.logD(message: String) = LogManager.d(this::class.java.simpleName, message)
fun Any.logI(message: String) = LogManager.i(this::class.java.simpleName, message)
fun Any.logW(message: String) = LogManager.w(this::class.java.simpleName, message)
fun Any.logE(message: String, t: Throwable? = null) = LogManager.e(this::class.java.simpleName, message, t)
