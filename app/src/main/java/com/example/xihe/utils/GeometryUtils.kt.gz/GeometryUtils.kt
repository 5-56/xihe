package com.example.xihe.utils

import android.graphics.Rect
import kotlin.math.sqrt

/**
 * 📐 几何计算工具类
 * 
 * 提供常用的几何计算方法，消除代码重复
 * 用于屏幕分析、OCR、语音交互等模块
 */
object GeometryUtils {
    
    /**
     * 计算两点间的欧几里得距离
     * 
     * @param x1 第一个点的X坐标
     * @param y1 第一个点的Y坐标
     * @param x2 第二个点的X坐标
     * @param y2 第二个点的Y坐标
     * @return 两点间的距离
     */
    fun calculateDistance(x1: Int, y1: Int, x2: Int, y2: Int): Double {
        val dx = (x2 - x1).toDouble()
        val dy = (y2 - y1).toDouble()
        return sqrt(dx * dx + dy * dy)
    }
    
    /**
     * 计算两点间的欧几里得距离（Float版本）
     */
    fun calculateDistance(x1: Float, y1: Float, x2: Float, y2: Float): Double {
        val dx = (x2 - x1).toDouble()
        val dy = (y2 - y1).toDouble()
        return sqrt(dx * dx + dy * dy)
    }
    
    /**
     * 计算两点间的曼哈顿距离
     * 
     * @param x1 第一个点的X坐标
     * @param y1 第一个点的Y坐标
     * @param x2 第二个点的X坐标
     * @param y2 第二个点的Y坐标
     * @return 曼哈顿距离
     */
    fun calculateManhattanDistance(x1: Int, y1: Int, x2: Int, y2: Int): Int {
        return kotlin.math.abs(x2 - x1) + kotlin.math.abs(y2 - y1)
    }
    
    /**
     * 计算两个矩形的重叠面积
     * 
     * @param rect1 第一个矩形
     * @param rect2 第二个矩形
     * @return 重叠面积，如果不重叠则返回0
     */
    fun calculateOverlap(rect1: Rect, rect2: Rect): Int {
        val overlapLeft = maxOf(rect1.left, rect2.left)
        val overlapTop = maxOf(rect1.top, rect2.top)
        val overlapRight = minOf(rect1.right, rect2.right)
        val overlapBottom = minOf(rect1.bottom, rect2.bottom)
        
        val overlapWidth = overlapRight - overlapLeft
        val overlapHeight = overlapBottom - overlapTop
        
        return if (overlapWidth > 0 && overlapHeight > 0) {
            overlapWidth * overlapHeight
        } else {
            0
        }
    }
    
    /**
     * 判断点是否在矩形内
     * 
     * @param x 点的X坐标
     * @param y 点的Y坐标
     * @param rect 矩形
     * @return 如果点在矩形内（包括边界）返回true
     */
    fun isPointInRect(x: Int, y: Int, rect: Rect): Boolean {
        return x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom
    }
    
    /**
     * 判断点是否在矩形内（Float版本）
     */
    fun isPointInRect(x: Float, y: Float, rect: Rect): Boolean {
        return x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom
    }
    
    /**
     * 计算矩形的中心点
     * 
     * @param rect 矩形
     * @return 中心点坐标 (x, y)
     */
    fun getRectCenter(rect: Rect): Pair<Int, Int> {
        return Pair(rect.centerX(), rect.centerY())
    }
    
    /**
     * 计算矩形的中心点（Float版本）
     */
    fun getRectCenterF(rect: Rect): Pair<Float, Float> {
        return Pair(rect.exactCenterX(), rect.exactCenterY())
    }
    
    /**
     * 计算矩形的面积
     * 
     * @param rect 矩形
     * @return 面积
     */
    fun calculateArea(rect: Rect): Int {
        return rect.width() * rect.height()
    }
    
    /**
     * 判断两个矩形是否相交
     * 
     * @param rect1 第一个矩形
     * @param rect2 第二个矩形
     * @return 如果相交返回true
     */
    fun isIntersecting(rect1: Rect, rect2: Rect): Boolean {
        return Rect.intersects(rect1, rect2)
    }
    
    /**
     * 判断一个矩形是否完全包含另一个矩形
     * 
     * @param outer 外部矩形
     * @param inner 内部矩形
     * @return 如果outer完全包含inner返回true
     */
    fun contains(outer: Rect, inner: Rect): Boolean {
        return outer.contains(inner)
    }
    
    /**
     * 计算点到矩形的最短距离
     * 
     * @param x 点的X坐标
     * @param y 点的Y坐标
     * @param rect 矩形
     * @return 最短距离，如果点在矩形内返回0
     */
    fun distanceToRect(x: Int, y: Int, rect: Rect): Double {
        if (isPointInRect(x, y, rect)) return 0.0
        
        val nearestX = x.coerceIn(rect.left, rect.right)
        val nearestY = y.coerceIn(rect.top, rect.bottom)
        
        return calculateDistance(x, y, nearestX, nearestY)
    }
    
    /**
     * 扩展矩形边界
     * 
     * @param rect 原始矩形
     * @param padding 扩展的像素数
     * @return 扩展后的新矩形
     */
    fun expandRect(rect: Rect, padding: Int): Rect {
        return Rect(
            rect.left - padding,
            rect.top - padding,
            rect.right + padding,
            rect.bottom + padding
        )
    }
    
    /**
     * 计算两个矩形中心点之间的距离
     * 
     * @param rect1 第一个矩形
     * @param rect2 第二个矩形
     * @return 中心点之间的距离
     */
    fun distanceBetweenRects(rect1: Rect, rect2: Rect): Double {
        val (x1, y1) = getRectCenter(rect1)
        val (x2, y2) = getRectCenter(rect2)
        return calculateDistance(x1, y1, x2, y2)
    }
}
