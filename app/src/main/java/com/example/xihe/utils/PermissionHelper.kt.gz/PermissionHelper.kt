package com.example.xihe.utils

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.example.xihe.CoreAccessibilityService

/**
 * 🔐 权限管理辅助类
 *
 * 统一管理应用所需的各种权限请求和检查
 * 从 MainActivity 中分离权限处理逻辑，遵循单一职责原则
 */
object PermissionHelper {

    private const val TAG = "PermissionHelper"

    // ==================== 权限常量 ====================

    /**
     * 基础权限列表
     */
    val BASIC_PERMISSIONS = buildList {
        // 网络权限（不需要运行时请求）
        // android.permission.INTERNET

        // 录音权限（语音输入）
        add(Manifest.permission.RECORD_AUDIO)

        // Android 13+ 需要通知权限
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }.toTypedArray()

    /**
     * 位置权限（用于天气等功能）
     */
    val LOCATION_PERMISSIONS = arrayOf(
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION
    )

    /**
     * 存储权限（Android 12 及以下）
     */
    val STORAGE_PERMISSIONS = if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.S_V2) {
        arrayOf(
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        )
    } else {
        emptyArray()
    }

    /**
     * 相机权限
     */
    val CAMERA_PERMISSION = arrayOf(Manifest.permission.CAMERA)

    /**
     * 联系人权限
     */
    val CONTACTS_PERMISSION = arrayOf(Manifest.permission.READ_CONTACTS)

    /**
     * 活动识别权限（Android 10+）
     */
    val ACTIVITY_RECOGNITION_PERMISSION = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        arrayOf(Manifest.permission.ACTIVITY_RECOGNITION)
    } else {
        emptyArray()
    }

    // ==================== 权限状态数据类 ====================

    /**
     * 权限状态汇总
     */
    data class PermissionStatus(
        val hasAccessibilityPermission: Boolean = false,
        val hasOverlayPermission: Boolean = false,
        val hasNotificationPermission: Boolean = false,
        val hasMicrophonePermission: Boolean = false,
        val hasLocationPermission: Boolean = false,
        val hasStoragePermission: Boolean = false,
        val hasCameraPermission: Boolean = false,
        val hasContactsPermission: Boolean = false,
        val hasBatteryOptimizationExemption: Boolean = false
    ) {
        /**
         * 检查核心权限是否都已授予
         */
        val hasCorePermissions: Boolean
            get() = hasAccessibilityPermission && hasOverlayPermission

        /**
         * 检查所有推荐权限是否都已授予
         */
        val hasAllRecommendedPermissions: Boolean
            get() = hasCorePermissions && hasNotificationPermission && hasMicrophonePermission

        /**
         * 获取缺失的权限列表
         */
        fun getMissingPermissions(): List<String> = buildList {
            if (!hasAccessibilityPermission) add("无障碍服务")
            if (!hasOverlayPermission) add("悬浮窗权限")
            if (!hasNotificationPermission) add("通知权限")
            if (!hasMicrophonePermission) add("麦克风权限")
        }
    }

    // ==================== 权限检查 ====================

    /**
     * 获取完整的权限状态
     */
    fun getPermissionStatus(context: Context): PermissionStatus {
        return PermissionStatus(
            hasAccessibilityPermission = isAccessibilityServiceEnabled(context),
            hasOverlayPermission = hasOverlayPermission(context),
            hasNotificationPermission = hasNotificationPermission(context),
            hasMicrophonePermission = hasPermission(context, Manifest.permission.RECORD_AUDIO),
            hasLocationPermission = hasLocationPermission(context),
            hasStoragePermission = hasStoragePermission(context),
            hasCameraPermission = hasPermission(context, Manifest.permission.CAMERA),
            hasContactsPermission = hasPermission(context, Manifest.permission.READ_CONTACTS),
            hasBatteryOptimizationExemption = isBatteryOptimizationExempt(context)
        )
    }

    /**
     * 检查单个权限
     */
    fun hasPermission(context: Context, permission: String): Boolean {
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * 检查多个权限
     */
    fun hasPermissions(context: Context, permissions: Array<String>): Boolean {
        return permissions.all { hasPermission(context, it) }
    }

    /**
     * 检查无障碍服务是否已启用
     */
    fun isAccessibilityServiceEnabled(context: Context): Boolean {
        // 方法1：通过 StateFlow 检查（如果服务已注册）
        if (CoreAccessibilityService.isConnected.value) {
            return true
        }

        // 方法2：通过系统 API 检查
        val accessibilityManager = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager
        val enabledServices = accessibilityManager?.getEnabledAccessibilityServiceList(
            AccessibilityServiceInfo.FEEDBACK_ALL_MASK
        )

        val packageName = context.packageName
        return enabledServices?.any {
            it.resolveInfo.serviceInfo.packageName == packageName
        } == true
    }

    /**
     * 检查悬浮窗权限
     */
    fun hasOverlayPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else {
            true
        }
    }

    /**
     * 检查通知权限
     */
    fun hasNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            hasPermission(context, Manifest.permission.POST_NOTIFICATIONS)
        } else {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            notificationManager?.areNotificationsEnabled() ?: true
        }
    }

    /**
     * 检查位置权限
     */
    fun hasLocationPermission(context: Context): Boolean {
        return hasPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ||
                hasPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION)
    }

    /**
     * 检查存储权限
     */
    fun hasStoragePermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Android 13+ 使用媒体权限
            true // 使用 PhotoPicker 不需要权限
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // Android 11-12 使用 Scoped Storage
            true
        } else {
            hasPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    /**
     * 检查是否已豁免电池优化
     */
    fun isBatteryOptimizationExempt(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            powerManager?.isIgnoringBatteryOptimizations(context.packageName) ?: false
        } else {
            true
        }
    }

    // ==================== 权限请求 ====================

    /**
     * 打开无障碍服务设置页面
     */
    fun openAccessibilitySettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            LogManager.d(TAG, "打开无障碍服务设置")
        } catch (e: Exception) {
            LogManager.e(TAG, "打开无障碍设置失败", e)
            // 回退到系统设置
            openAppSettings(context)
        }
    }

    /**
     * 请求悬浮窗权限
     */
    fun requestOverlayPermission(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:${context.packageName}")
                )
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                LogManager.d(TAG, "打开悬浮窗权限设置")
            } catch (e: Exception) {
                LogManager.e(TAG, "打开悬浮窗权限设置失败", e)
                openAppSettings(context)
            }
        }
    }

    /**
     * 请求悬浮窗权限（带结果回调）
     */
    fun requestOverlayPermissionWithLauncher(
        activity: ComponentActivity,
        launcher: ActivityResultLauncher<Intent>
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${activity.packageName}")
            )
            launcher.launch(intent)
        }
    }

    /**
     * 请求电池优化豁免
     */
    fun requestBatteryOptimizationExemption(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                intent.data = Uri.parse("package:${context.packageName}")
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                LogManager.d(TAG, "请求电池优化豁免")
            } catch (e: Exception) {
                LogManager.e(TAG, "请求电池优化豁免失败", e)
                // 回退到电池设置页面
                openBatterySettings(context)
            }
        }
    }

    /**
     * 打开应用详情设置页面
     */
    fun openAppSettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            intent.data = Uri.parse("package:${context.packageName}")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            LogManager.d(TAG, "打开应用设置")
        } catch (e: Exception) {
            LogManager.e(TAG, "打开应用设置失败", e)
        }
    }

    /**
     * 打开通知设置页面
     */
    fun openNotificationSettings(context: Context) {
        try {
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                    putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                }
            } else {
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.parse("package:${context.packageName}")
                }
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            LogManager.d(TAG, "打开通知设置")
        } catch (e: Exception) {
            LogManager.e(TAG, "打开通知设置失败", e)
            openAppSettings(context)
        }
    }

    /**
     * 打开电池设置页面
     */
    fun openBatterySettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (e: Exception) {
            LogManager.e(TAG, "打开电池设置失败", e)
            openAppSettings(context)
        }
    }

    /**
     * 打开位置服务设置
     */
    fun openLocationSettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (e: Exception) {
            LogManager.e(TAG, "打开位置设置失败", e)
        }
    }

    // ==================== 辅助方法 ====================

    /**
     * 获取需要请求的运行时权限
     */
    fun getPermissionsToRequest(context: Context, permissions: Array<String>): Array<String> {
        return permissions.filter { !hasPermission(context, it) }.toTypedArray()
    }

    /**
     * 检查是否应该显示权限说明
     */
    fun shouldShowRationale(activity: Activity, permission: String): Boolean {
        return activity.shouldShowRequestPermissionRationale(permission)
    }

    /**
     * 获取权限的用户友好名称
     */
    fun getPermissionDisplayName(permission: String): String {
        return when (permission) {
            Manifest.permission.RECORD_AUDIO -> "麦克风"
            Manifest.permission.CAMERA -> "相机"
            Manifest.permission.ACCESS_FINE_LOCATION -> "精确位置"
            Manifest.permission.ACCESS_COARSE_LOCATION -> "大致位置"
            Manifest.permission.READ_CONTACTS -> "联系人"
            Manifest.permission.READ_EXTERNAL_STORAGE -> "存储读取"
            Manifest.permission.WRITE_EXTERNAL_STORAGE -> "存储写入"
            Manifest.permission.POST_NOTIFICATIONS -> "通知"
            Manifest.permission.ACTIVITY_RECOGNITION -> "活动识别"
            else -> permission.substringAfterLast(".")
        }
    }

    /**
     * 获取权限的说明文字
     */
    fun getPermissionRationale(permission: String): String {
        return when (permission) {
            Manifest.permission.RECORD_AUDIO ->
                "需要麦克风权限来使用语音输入和唤醒词功能"
            Manifest.permission.CAMERA ->
                "需要相机权限来拍照识别和视觉分析"
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION ->
                "需要位置权限来获取当地天气和提供位置相关服务"
            Manifest.permission.READ_CONTACTS ->
                "需要联系人权限来快速发送消息给联系人"
            Manifest.permission.POST_NOTIFICATIONS ->
                "需要通知权限来显示任务进度和提醒"
            Manifest.permission.ACTIVITY_RECOGNITION ->
                "需要活动识别权限来检测您的运动状态，提供智能建议"
            else -> "此权限用于应用的正常功能"
        }
    }

    /**
     * 创建权限请求启动器
     */
    fun createPermissionLauncher(
        activity: ComponentActivity,
        onResult: (Map<String, Boolean>) -> Unit
    ): ActivityResultLauncher<Array<String>> {
        return activity.registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { permissions ->
            LogManager.d(TAG, "权限请求结果: $permissions")
            onResult(permissions)
        }
    }

    /**
     * 创建单个权限请求启动器
     */
    fun createSinglePermissionLauncher(
        activity: ComponentActivity,
        onResult: (Boolean) -> Unit
    ): ActivityResultLauncher<String> {
        return activity.registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted ->
            LogManager.d(TAG, "权限请求结果: $isGranted")
            onResult(isGranted)
        }
    }

    /**
     * 创建系统设置启动器
     */
    fun createSettingsLauncher(
        activity: ComponentActivity,
        onResult: () -> Unit
    ): ActivityResultLauncher<Intent> {
        return activity.registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) {
            LogManager.d(TAG, "从设置页面返回")
            onResult()
        }
    }
}
