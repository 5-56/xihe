package com.example.xihe.utils

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
// LogManager imported in same package

/**
 * 🗺️ 导航助手
 * 
 * 支持多种地图应用进行导航
 */
object NavigationHelper {
    
    private const val TAG = "NavigationHelper"
    
    // 支持的地图应用
    private val MAP_APPS = listOf(
        MapApp("高德地图", "com.autonavi.minimap", "amapuri://route/plan/?"),
        MapApp("百度地图", "com.baidu.BaiduMap", "baidumap://map/direction?"),
        MapApp("腾讯地图", "com.tencent.map", "qqmap://map/routeplan?"),
        MapApp("Google地图", "com.google.android.apps.maps", "google.navigation:q=")
    )
    
    /**
     * 🚀 启动导航
     * @param context 上下文
     * @param destination 目的地
     * @return 导航结果
     */
    fun startNavigation(context: Context, destination: String): NavigationResult {
        LogManager.w(TAG, "🗺️ 开始导航到: $destination")
        
        // 1. 查找已安装的地图应用
        val installedMapApp = findInstalledMapApp(context)
        
        if (installedMapApp != null) {
            return launchMapApp(context, installedMapApp, destination)
        }
        
        // 2. 如果没有安装地图应用，使用浏览器打开
        return openInBrowser(context, destination)
    }
    
    /**
     * 🔍 查找已安装的地图应用
     */
    private fun findInstalledMapApp(context: Context): MapApp? {
        val pm = context.packageManager
        
        for (app in MAP_APPS) {
            try {
                pm.getPackageInfo(app.packageName, PackageManager.GET_ACTIVITIES)
                LogManager.w(TAG, "✅ 找到地图应用: ${app.name}")
                return app
            } catch (e: PackageManager.NameNotFoundException) {
                // 应用未安装
            }
        }
        
        return null
    }
    
    /**
     * 🚀 启动地图应用导航
     */
    private fun launchMapApp(context: Context, mapApp: MapApp, destination: String): NavigationResult {
        return try {
            val intent = when (mapApp.packageName) {
                "com.autonavi.minimap" -> {
                    // 高德地图
                    Intent(Intent.ACTION_VIEW, Uri.parse(
                        "amapuri://route/plan/?sourceApplication=羲和AI&dname=${Uri.encode(destination)}&dev=0&t=0"
                    )).apply {
                        setPackage(mapApp.packageName)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                }
                "com.baidu.BaiduMap" -> {
                    // 百度地图
                    Intent(Intent.ACTION_VIEW, Uri.parse(
                        "baidumap://map/direction?destination=name:${Uri.encode(destination)}&mode=driving&coord_type=gcj02"
                    )).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                }
                "com.tencent.map" -> {
                    // 腾讯地图
                    Intent(Intent.ACTION_VIEW, Uri.parse(
                        "qqmap://map/routeplan?type=drive&to=${Uri.encode(destination)}&referer=羲和AI"
                    )).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                }
                "com.google.android.apps.maps" -> {
                    // Google地图
                    Intent(Intent.ACTION_VIEW, Uri.parse(
                        "google.navigation:q=${Uri.encode(destination)}"
                    )).apply {
                        setPackage(mapApp.packageName)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                }
                else -> null
            }
            
            if (intent != null) {
                context.startActivity(intent)
                LogManager.w(TAG, "✅ 已启动 ${mapApp.name} 导航")
                NavigationResult.Success("已使用${mapApp.name}开始导航到「$destination」")
            } else {
                NavigationResult.Failure("不支持的地图应用")
            }
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 启动地图应用失败", e)
            // 尝试使用浏览器
            openInBrowser(context, destination)
        }
    }
    
    /**
     * 🌐 使用浏览器打开地图
     */
    private fun openInBrowser(context: Context, destination: String): NavigationResult {
        return try {
            // 使用高德网页版
            val url = "https://uri.amap.com/navigation?to=${Uri.encode(destination)}&mode=car&src=羲和AI"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            LogManager.w(TAG, "✅ 已在浏览器中打开导航")
            NavigationResult.Success("已在浏览器中打开导航到「$destination」")
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 打开浏览器导航失败", e)
            NavigationResult.Failure("无法打开导航: ${e.message}")
        }
    }
    
    /**
     * 📍 搜索地点
     */
    fun searchLocation(context: Context, query: String): NavigationResult {
        return try {
            val installedMapApp = findInstalledMapApp(context)
            
            val intent = if (installedMapApp != null) {
                when (installedMapApp.packageName) {
                    "com.autonavi.minimap" -> Intent(Intent.ACTION_VIEW, Uri.parse(
                        "amapuri://poi/search/keyword?keyword=${Uri.encode(query)}"
                    )).apply { setPackage(installedMapApp.packageName) }
                    
                    "com.baidu.BaiduMap" -> Intent(Intent.ACTION_VIEW, Uri.parse(
                        "baidumap://map/place/search?query=${Uri.encode(query)}"
                    ))
                    
                    else -> Intent(Intent.ACTION_VIEW, Uri.parse(
                        "geo:0,0?q=${Uri.encode(query)}"
                    ))
                }
            } else {
                Intent(Intent.ACTION_VIEW, Uri.parse(
                    "https://www.amap.com/search?query=${Uri.encode(query)}"
                ))
            }
            
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            NavigationResult.Success("正在搜索「$query」")
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 搜索地点失败", e)
            NavigationResult.Failure("搜索失败: ${e.message}")
        }
    }
}

/**
 * 🗺️ 地图应用信息
 */
data class MapApp(
    val name: String,
    val packageName: String,
    val uriScheme: String
)

/**
 * 📍 导航结果
 */
sealed class NavigationResult {
    data class Success(val message: String) : NavigationResult()
    data class Failure(val message: String) : NavigationResult()
}
