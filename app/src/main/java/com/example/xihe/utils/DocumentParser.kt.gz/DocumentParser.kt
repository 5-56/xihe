package com.example.xihe.utils

import android.content.Context
import android.net.Uri
// LogManager imported in same package
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream

/**
 * 📄 文档解析器
 * 支持解析 PDF、Word、Excel、TXT 等格式的文档
 */
object DocumentParser {
    private const val TAG = "DocumentParser"
    
    /**
     * 解析文档并提取文本内容
     * @param context Android Context
     * @param uri 文档 URI
     * @param fileName 文件名（用于判断文件类型）
     * @param mimeType MIME 类型
     * @return 提取的文本内容
     */
    suspend fun parseDocument(
        context: Context,
        uri: Uri,
        fileName: String?,
        mimeType: String?
    ): DocumentResult = withContext(Dispatchers.IO) {
        try {
            LogManager.d(TAG, "📄 开始解析文档: fileName=$fileName, mimeType=$mimeType")
            
            val inputStream = context.contentResolver.openInputStream(uri)
                ?: return@withContext DocumentResult.Error("无法打开文件")
            
            val result = when {
                // PDF 文件
                mimeType?.contains("pdf") == true || 
                fileName?.endsWith(".pdf", ignoreCase = true) == true -> {
                    parsePDF(inputStream)
                }
                
                // Word 文档 (.docx)
                mimeType?.contains("wordprocessingml") == true ||
                fileName?.endsWith(".docx", ignoreCase = true) == true -> {
                    parseDocx(inputStream)
                }
                
                // Word 文档 (.doc) - 旧格式
                mimeType?.contains("msword") == true ||
                fileName?.endsWith(".doc", ignoreCase = true) == true -> {
                    parseDoc(inputStream)
                }
                
                // Excel 文档 (.xlsx)
                mimeType?.contains("spreadsheetml") == true ||
                fileName?.endsWith(".xlsx", ignoreCase = true) == true -> {
                    parseXlsx(inputStream)
                }
                
                // Excel 文档 (.xls) - 旧格式
                mimeType?.contains("ms-excel") == true ||
                fileName?.endsWith(".xls", ignoreCase = true) == true -> {
                    parseXls(inputStream)
                }
                
                // 纯文本文件
                mimeType?.startsWith("text/") == true ||
                fileName?.endsWith(".txt", ignoreCase = true) == true ||
                fileName?.endsWith(".md", ignoreCase = true) == true ||
                fileName?.endsWith(".json", ignoreCase = true) == true ||
                fileName?.endsWith(".xml", ignoreCase = true) == true ||
                fileName?.endsWith(".csv", ignoreCase = true) == true -> {
                    parseText(inputStream)
                }
                
                // 未知格式，尝试作为文本读取
                else -> {
                    LogManager.w(TAG, "⚠️ 未知文件格式，尝试作为文本读取")
                    parseText(inputStream)
                }
            }
            
            inputStream.close()
            result
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 文档解析失败", e)
            DocumentResult.Error("解析失败: ${e.message}")
        }
    }
    
    /**
     * 解析 PDF 文件
     */
    private fun parsePDF(inputStream: InputStream): DocumentResult {
        return try {
            LogManager.d(TAG, "📄 解析 PDF 文件...")
            
            val pdfReader = com.itextpdf.kernel.pdf.PdfReader(inputStream)
            val pdfDocument = com.itextpdf.kernel.pdf.PdfDocument(pdfReader)
            
            val textBuilder = StringBuilder()
            val pageCount = pdfDocument.numberOfPages
            
            LogManager.d(TAG, "📄 PDF 共 $pageCount 页")
            
            for (i in 1..pageCount) {
                val page = pdfDocument.getPage(i)
                val text = com.itextpdf.kernel.pdf.canvas.parser.PdfTextExtractor.getTextFromPage(page)
                textBuilder.append("--- 第 $i 页 ---\n")
                textBuilder.append(text)
                textBuilder.append("\n\n")
            }
            
            pdfDocument.close()
            
            val content = textBuilder.toString().trim()
            LogManager.d(TAG, "✅ PDF 解析成功，提取 ${content.length} 字符")
            
            if (content.isBlank()) {
                DocumentResult.Error("PDF 文件没有可提取的文本内容（可能是扫描版）")
            } else {
                DocumentResult.Success(content, "pdf", pageCount)
            }
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ PDF 解析失败", e)
            DocumentResult.Error("PDF 解析失败: ${e.message}")
        }
    }
    
    /**
     * 解析 Word 文档 (.docx)
     */
    private fun parseDocx(inputStream: InputStream): DocumentResult {
        return try {
            LogManager.d(TAG, "📄 解析 DOCX 文件...")
            
            val document = org.apache.poi.xwpf.usermodel.XWPFDocument(inputStream)
            val textBuilder = StringBuilder()
            
            // 提取段落文本
            for (paragraph in document.paragraphs) {
                val text = paragraph.text
                if (text.isNotBlank()) {
                    textBuilder.append(text)
                    textBuilder.append("\n")
                }
            }
            
            // 提取表格内容
            for (table in document.tables) {
                textBuilder.append("\n[表格]\n")
                for (row in table.rows) {
                    val rowText = row.tableCells.joinToString(" | ") { it.text }
                    textBuilder.append(rowText)
                    textBuilder.append("\n")
                }
                textBuilder.append("\n")
            }
            
            document.close()
            
            val content = textBuilder.toString().trim()
            LogManager.d(TAG, "✅ DOCX 解析成功，提取 ${content.length} 字符")
            
            if (content.isBlank()) {
                DocumentResult.Error("Word 文档没有可提取的文本内容")
            } else {
                DocumentResult.Success(content, "docx")
            }
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ DOCX 解析失败", e)
            DocumentResult.Error("Word 文档解析失败: ${e.message}")
        }
    }
    
    /**
     * 解析 Word 文档 (.doc) - 旧格式
     */
    private fun parseDoc(inputStream: InputStream): DocumentResult {
        return try {
            LogManager.d(TAG, "📄 解析 DOC 文件...")
            
            val document = org.apache.poi.hwpf.HWPFDocument(inputStream)
            val extractor = org.apache.poi.hwpf.extractor.WordExtractor(document)
            val content = extractor.text.trim()
            
            extractor.close()
            document.close()
            
            LogManager.d(TAG, "✅ DOC 解析成功，提取 ${content.length} 字符")
            
            if (content.isBlank()) {
                DocumentResult.Error("Word 文档没有可提取的文本内容")
            } else {
                DocumentResult.Success(content, "doc")
            }
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ DOC 解析失败", e)
            DocumentResult.Error("Word 文档解析失败: ${e.message}")
        }
    }
    
    /**
     * 解析 Excel 文档 (.xlsx)
     */
    private fun parseXlsx(inputStream: InputStream): DocumentResult {
        return try {
            LogManager.d(TAG, "📄 解析 XLSX 文件...")
            
            val workbook = org.apache.poi.xssf.usermodel.XSSFWorkbook(inputStream)
            val textBuilder = StringBuilder()
            
            for (sheetIndex in 0 until workbook.numberOfSheets) {
                val sheet = workbook.getSheetAt(sheetIndex)
                textBuilder.append("=== 工作表: ${sheet.sheetName} ===\n\n")
                
                for (row in sheet) {
                    val rowText = mutableListOf<String>()
                    for (cell in row) {
                        val cellValue = getCellValueAsString(cell)
                        rowText.add(cellValue)
                    }
                    textBuilder.append(rowText.joinToString("\t"))
                    textBuilder.append("\n")
                }
                textBuilder.append("\n")
            }
            
            workbook.close()
            
            val content = textBuilder.toString().trim()
            LogManager.d(TAG, "✅ XLSX 解析成功，提取 ${content.length} 字符")
            
            if (content.isBlank()) {
                DocumentResult.Error("Excel 文档没有可提取的内容")
            } else {
                DocumentResult.Success(content, "xlsx", workbook.numberOfSheets)
            }
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ XLSX 解析失败", e)
            DocumentResult.Error("Excel 文档解析失败: ${e.message}")
        }
    }
    
    /**
     * 解析 Excel 文档 (.xls) - 旧格式
     */
    private fun parseXls(inputStream: InputStream): DocumentResult {
        return try {
            LogManager.d(TAG, "📄 解析 XLS 文件...")
            
            val workbook = org.apache.poi.hssf.usermodel.HSSFWorkbook(inputStream)
            val textBuilder = StringBuilder()
            
            for (sheetIndex in 0 until workbook.numberOfSheets) {
                val sheet = workbook.getSheetAt(sheetIndex)
                textBuilder.append("=== 工作表: ${sheet.sheetName} ===\n\n")
                
                for (row in sheet) {
                    val rowText = mutableListOf<String>()
                    for (cell in row) {
                        val cellValue = getCellValueAsString(cell)
                        rowText.add(cellValue)
                    }
                    textBuilder.append(rowText.joinToString("\t"))
                    textBuilder.append("\n")
                }
                textBuilder.append("\n")
            }
            
            val sheetCount = workbook.numberOfSheets
            workbook.close()
            
            val content = textBuilder.toString().trim()
            LogManager.d(TAG, "✅ XLS 解析成功，提取 ${content.length} 字符")
            
            if (content.isBlank()) {
                DocumentResult.Error("Excel 文档没有可提取的内容")
            } else {
                DocumentResult.Success(content, "xls", sheetCount)
            }
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ XLS 解析失败", e)
            DocumentResult.Error("Excel 文档解析失败: ${e.message}")
        }
    }
    
    /**
     * 解析纯文本文件
     */
    private fun parseText(inputStream: InputStream): DocumentResult {
        return try {
            LogManager.d(TAG, "📄 解析纯文本文件...")
            
            val content = inputStream.bufferedReader().readText().trim()
            
            LogManager.d(TAG, "✅ 文本解析成功，提取 ${content.length} 字符")
            
            if (content.isBlank()) {
                DocumentResult.Error("文件内容为空")
            } else {
                DocumentResult.Success(content, "text")
            }
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 文本解析失败", e)
            DocumentResult.Error("文本解析失败: ${e.message}")
        }
    }
    
    /**
     * 获取单元格的字符串值
     */
    private fun getCellValueAsString(cell: org.apache.poi.ss.usermodel.Cell): String {
        return try {
            when (cell.cellType) {
                org.apache.poi.ss.usermodel.CellType.STRING -> cell.stringCellValue
                org.apache.poi.ss.usermodel.CellType.NUMERIC -> {
                    if (org.apache.poi.ss.usermodel.DateUtil.isCellDateFormatted(cell)) {
                        cell.dateCellValue.toString()
                    } else {
                        cell.numericCellValue.toString()
                    }
                }
                org.apache.poi.ss.usermodel.CellType.BOOLEAN -> cell.booleanCellValue.toString()
                org.apache.poi.ss.usermodel.CellType.FORMULA -> {
                    try {
                        cell.stringCellValue
                    } catch (e: Exception) {
                        cell.numericCellValue.toString()
                    }
                }
                else -> ""
            }
        } catch (e: Exception) {
            ""
        }
    }
}

/**
 * 文档解析结果
 */
sealed class DocumentResult {
    data class Success(
        val content: String,
        val fileType: String,
        val pageCount: Int = 1
    ) : DocumentResult()
    
    data class Error(val message: String) : DocumentResult()
}
