package com.example.xihe.utils

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.AlarmClock
// LogManager imported in same package
import androidx.core.app.NotificationCompat
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.*

/**
 * ⏰ 提醒助手
 * 
 * 支持设置闹钟、提醒和日程
 */
object ReminderHelper {
    
    private const val TAG = "ReminderHelper"
    private const val REMINDERS_FILE = "xihe_reminders.json"
    private const val CHANNEL_ID = "xihe_reminder_channel"
    private const val CHANNEL_NAME = "羲和提醒"
    
    private val json = Json { 
        prettyPrint = true
        ignoreUnknownKeys = true 
    }
    
    /**
     * ⏰ 设置闹钟
     * 
     * @param context 上下文
     * @param hour 小时 (0-23)
     * @param minute 分钟 (0-59)
     * @param message 闹钟标签
     * @return 设置结果
     */
    fun setAlarm(context: Context, hour: Int, minute: Int, message: String): ReminderResult {
        LogManager.d(TAG, "⏰ 设置闹钟: $hour:$minute - $message")
        
        return try {
            // 使用系统闹钟应用
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                putExtra(AlarmClock.EXTRA_MESSAGE, message)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)  // 显示闹钟UI
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            
            context.startActivity(intent)
            LogManager.d(TAG, "✅ 闹钟设置成功")
            
            // 同时保存到本地记录
            saveReminder(context, Reminder(
                id = UUID.randomUUID().toString(),
                type = ReminderType.ALARM,
                title = message,
                time = formatTime(hour, minute),
                timestamp = calculateTimestamp(hour, minute),
                isActive = true
            ))
            
            ReminderResult.Success("已设置 ${formatTime(hour, minute)} 的闹钟「$message」")
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 设置闹钟失败", e)
            ReminderResult.Failure("设置闹钟失败: ${e.message}")
        }
    }
    
    /**
     * 🔔 设置提醒
     * 
     * @param context 上下文
     * @param delayMinutes 延迟分钟数
     * @param message 提醒内容
     * @return 设置结果
     */
    fun setReminder(context: Context, delayMinutes: Int, message: String): ReminderResult {
        LogManager.d(TAG, "🔔 设置提醒: $delayMinutes 分钟后 - $message")
        
        return try {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            
            val reminderId = UUID.randomUUID().toString()
            val triggerTime = System.currentTimeMillis() + (delayMinutes * 60 * 1000L)
            
            // 创建提醒Intent
            val intent = Intent(context, ReminderReceiver::class.java).apply {
                putExtra("reminder_id", reminderId)
                putExtra("reminder_message", message)
            }
            
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                reminderId.hashCode(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            
            // 设置提醒
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerTime,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    triggerTime,
                    pendingIntent
                )
            }
            
            // 保存提醒记录
            val reminder = Reminder(
                id = reminderId,
                type = ReminderType.REMINDER,
                title = message,
                time = "$delayMinutes 分钟后",
                timestamp = triggerTime,
                isActive = true
            )
            saveReminder(context, reminder)
            
            LogManager.d(TAG, "✅ 提醒设置成功")
            ReminderResult.Success("已设置 $delayMinutes 分钟后的提醒「$message」")
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 设置提醒失败", e)
            ReminderResult.Failure("设置提醒失败: ${e.message}")
        }
    }
    
    /**
     * 📅 设置日程提醒（指定时间）
     */
    fun setScheduledReminder(
        context: Context,
        hour: Int,
        minute: Int,
        message: String
    ): ReminderResult {
        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            
            // 如果时间已过，设置为明天
            if (before(now)) {
                add(Calendar.DAY_OF_MONTH, 1)
            }
        }
        
        val delayMinutes = ((target.timeInMillis - now.timeInMillis) / 60000).toInt()
        
        return if (delayMinutes > 0) {
            setReminder(context, delayMinutes, message)
        } else {
            ReminderResult.Failure("设置的时间已过")
        }
    }
    
    /**
     * 📋 获取所有提醒
     */
    fun getReminders(context: Context): List<Reminder> {
        return try {
            val file = File(context.filesDir, REMINDERS_FILE)
            if (file.exists()) {
                json.decodeFromString(file.readText())
            } else {
                emptyList()
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "读取提醒列表失败", e)
            emptyList()
        }
    }
    
    /**
     * 🗑️ 删除提醒
     */
    fun deleteReminder(context: Context, reminderId: String): Boolean {
        return try {
            val reminders = getReminders(context).toMutableList()
            val removed = reminders.removeAll { it.id == reminderId }
            
            if (removed) {
                saveReminders(context, reminders)
                
                // 取消AlarmManager中的提醒
                val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val intent = Intent(context, ReminderReceiver::class.java)
                val pendingIntent = PendingIntent.getBroadcast(
                    context,
                    reminderId.hashCode(),
                    intent,
                    PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
                )
                pendingIntent?.let { alarmManager.cancel(it) }
                
                LogManager.d(TAG, "✅ 删除提醒成功: $reminderId")
            }
            removed
        } catch (e: Exception) {
            LogManager.e(TAG, "删除提醒失败", e)
            false
        }
    }
    
    /**
     * 💾 保存提醒
     */
    private fun saveReminder(context: Context, reminder: Reminder) {
        val reminders = getReminders(context).toMutableList()
        reminders.add(reminder)
        saveReminders(context, reminders)
    }
    
    /**
     * 💾 保存提醒列表
     */
    private fun saveReminders(context: Context, reminders: List<Reminder>) {
        try {
            val file = File(context.filesDir, REMINDERS_FILE)
            file.writeText(json.encodeToString(reminders))
        } catch (e: Exception) {
            LogManager.e(TAG, "保存提醒列表失败", e)
        }
    }
    
    /**
     * 🔔 创建通知渠道
     */
    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "羲和AI提醒通知"
                enableVibration(true)
                enableLights(true)
            }
            
            val notificationManager = context.getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }
    
    /**
     * 🔔 显示提醒通知
     */
    fun showReminderNotification(context: Context, reminderId: String, message: String) {
        createNotificationChannel(context)
        
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("⏰ 羲和提醒")
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setVibrate(longArrayOf(0, 500, 200, 500))
            .build()
        
        notificationManager.notify(reminderId.hashCode(), notification)
        
        // 标记提醒已触发
        markReminderTriggered(context, reminderId)
    }
    
    /**
     * 📝 标记提醒已触发
     */
    private fun markReminderTriggered(context: Context, reminderId: String) {
        val reminders = getReminders(context).map {
            if (it.id == reminderId) it.copy(isActive = false) else it
        }
        saveReminders(context, reminders)
    }
    
    private fun formatTime(hour: Int, minute: Int): String {
        return String.format(Locale.getDefault(), "%02d:%02d", hour, minute)
    }
    
    private fun calculateTimestamp(hour: Int, minute: Int): Long {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            
            if (before(Calendar.getInstance())) {
                add(Calendar.DAY_OF_MONTH, 1)
            }
        }
        return calendar.timeInMillis
    }
}

/**
 * 📻 提醒广播接收器
 */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val reminderId = intent.getStringExtra("reminder_id") ?: return
        val message = intent.getStringExtra("reminder_message") ?: "提醒时间到了"
        
        LogManager.d("ReminderReceiver", "收到提醒: $message")
        ReminderHelper.showReminderNotification(context, reminderId, message)
    }
}

/**
 * ⏰ 提醒数据类
 */
@Serializable
data class Reminder(
    val id: String,
    val type: ReminderType,
    val title: String,
    val time: String,
    val timestamp: Long,
    val isActive: Boolean = true
)

/**
 * 📋 提醒类型
 */
@Serializable
enum class ReminderType {
    ALARM,      // 闹钟
    REMINDER,   // 提醒
    SCHEDULE    // 日程
}

/**
 * 📍 提醒结果
 */
sealed class ReminderResult {
    data class Success(val message: String) : ReminderResult()
    data class Failure(val message: String) : ReminderResult()
}
