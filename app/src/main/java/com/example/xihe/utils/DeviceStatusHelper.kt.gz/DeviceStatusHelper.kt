package com.example.xihe.utils

import android.app.ActivityManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
// LogManager imported in same package
import java.io.BufferedReader
import java.io.FileReader
import java.io.RandomAccessFile

/**
 * 📱 设备状态助手
 * 
 * 获取设备的各种状态信息
 */
object DeviceStatusHelper {
    
    private const val TAG = "DeviceStatusHelper"
    
    // ==================== 电池状态 ====================
    
    /**
     * 🔋 获取电池电量 (0-100)
     */
    fun getBatteryLevel(context: Context): Int {
        return try {
            val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        } catch (e: Exception) {
            LogManager.d(TAG, "获取电池电量失败", e)
            // 备用方法
            getBatteryLevelFromIntent(context)
        }
    }
    
    /**
     * 从广播Intent获取电池电量（备用方法）
     */
    private fun getBatteryLevelFromIntent(context: Context): Int {
        return try {
            val intentFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val batteryStatus = context.registerReceiver(null, intentFilter)
            
            val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            
            if (level >= 0 && scale > 0) {
                (level * 100 / scale)
            } else {
                -1
            }
        } catch (e: Exception) {
            LogManager.d(TAG, "从Intent获取电池电量失败", e)
            -1
        }
    }
    
    /**
     * 是否正在充电
     */
    fun isCharging(context: Context): Boolean {
        return try {
            val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            batteryManager.isCharging
        } catch (e: Exception) {
            LogManager.d(TAG, "获取充电状态失败", e)
            // 备用方法
            isChargingFromIntent(context)
        }
    }
    
    /**
     * 从广播Intent获取充电状态（备用方法）
     */
    private fun isChargingFromIntent(context: Context): Boolean {
        return try {
            val intentFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val batteryStatus = context.registerReceiver(null, intentFilter)
            
            val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL
        } catch (e: Exception) {
            LogManager.d(TAG, "从Intent获取充电状态失败", e)
            false
        }
    }
    
    /**
     * 获取充电类型
     */
    fun getChargingType(context: Context): ChargingType {
        return try {
            val intentFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val batteryStatus = context.registerReceiver(null, intentFilter)
            
            val plugged = batteryStatus?.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1) ?: -1
            
            when (plugged) {
                BatteryManager.BATTERY_PLUGGED_AC -> ChargingType.AC
                BatteryManager.BATTERY_PLUGGED_USB -> ChargingType.USB
                BatteryManager.BATTERY_PLUGGED_WIRELESS -> ChargingType.WIRELESS
                else -> ChargingType.NOT_CHARGING
            }
        } catch (e: Exception) {
            LogManager.d(TAG, "获取充电类型失败", e)
            ChargingType.UNKNOWN
        }
    }
    
    // ==================== 屏幕状态 ====================
    
    /**
     * 屏幕是否点亮
     */
    fun isScreenOn(context: Context): Boolean {
        return try {
            val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            powerManager.isInteractive
        } catch (e: Exception) {
            LogManager.d(TAG, "获取屏幕状态失败", e)
            true // 默认返回true
        }
    }
    
    /**
     * 设备是否处于空闲模式（Doze）
     */
    fun isDeviceIdle(context: Context): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
                powerManager.isDeviceIdleMode
            } else {
                false
            }
        } catch (e: Exception) {
            LogManager.d(TAG, "获取空闲模式状态失败", e)
            false
        }
    }
    
    // ==================== CPU 状态 ====================
    
    /**
     * 获取 CPU 使用率 (0-100)
     * 
     * 使用 /proc/stat 计算 CPU 使用率
     * 注意：此方法为suspend函数，使用协程delay替代Thread.sleep
     */
    suspend fun getCpuUsage(): Int {
        return try {
            // 第一次读取
            val stat1 = readCpuStat()
            kotlinx.coroutines.delay(100) // 使用协程delay替代Thread.sleep
            // 第二次读取
            val stat2 = readCpuStat()
            
            if (stat1 != null && stat2 != null) {
                val totalDiff = stat2.total - stat1.total
                val idleDiff = stat2.idle - stat1.idle
                
                if (totalDiff > 0) {
                    ((totalDiff - idleDiff) * 100 / totalDiff).toInt().coerceIn(0, 100)
                } else {
                    0
                }
            } else {
                -1
            }
        } catch (e: Exception) {
            LogManager.d(TAG, "获取CPU使用率失败", e)
            -1
        }
    }
    
    /**
     * 读取 /proc/stat 中的 CPU 统计信息
     */
    private fun readCpuStat(): CpuStat? {
        return try {
            val reader = BufferedReader(FileReader("/proc/stat"))
            val line = reader.readLine()
            reader.close()
            
            if (line != null && line.startsWith("cpu ")) {
                val parts = line.split("\\s+".toRegex())
                if (parts.size >= 8) {
                    val user = parts[1].toLong()
                    val nice = parts[2].toLong()
                    val system = parts[3].toLong()
                    val idle = parts[4].toLong()
                    val iowait = parts[5].toLong()
                    val irq = parts[6].toLong()
                    val softirq = parts[7].toLong()
                    
                    val total = user + nice + system + idle + iowait + irq + softirq
                    CpuStat(total, idle)
                } else {
                    null
                }
            } else {
                null
            }
        } catch (e: Exception) {
            LogManager.d(TAG, "读取CPU统计失败", e)
            null
        }
    }
    
    // ==================== 内存状态 ====================
    
    /**
     * 获取可用内存 (MB)
     */
    fun getAvailableMemoryMB(context: Context): Long {
        return try {
            val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memoryInfo = ActivityManager.MemoryInfo()
            activityManager.getMemoryInfo(memoryInfo)
            
            memoryInfo.availMem / (1024 * 1024)
        } catch (e: Exception) {
            LogManager.d(TAG, "获取可用内存失败", e)
            -1
        }
    }
    
    /**
     * 获取总内存 (MB)
     */
    fun getTotalMemoryMB(context: Context): Long {
        return try {
            val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memoryInfo = ActivityManager.MemoryInfo()
            activityManager.getMemoryInfo(memoryInfo)
            
            memoryInfo.totalMem / (1024 * 1024)
        } catch (e: Exception) {
            LogManager.d(TAG, "获取总内存失败", e)
            -1
        }
    }
    
    /**
     * 获取内存使用率 (0-100)
     */
    fun getMemoryUsagePercent(context: Context): Int {
        val available = getAvailableMemoryMB(context)
        val total = getTotalMemoryMB(context)
        
        return if (total > 0) {
            ((total - available) * 100 / total).toInt()
        } else {
            -1
        }
    }
    
    /**
     * 是否处于低内存状态
     */
    fun isLowMemory(context: Context): Boolean {
        return try {
            val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memoryInfo = ActivityManager.MemoryInfo()
            activityManager.getMemoryInfo(memoryInfo)
            
            memoryInfo.lowMemory
        } catch (e: Exception) {
            LogManager.d(TAG, "获取低内存状态失败", e)
            false
        }
    }
    
    // ==================== 前台应用 ====================
    
    /**
     * 获取当前前台应用包名
     */
    fun getCurrentForegroundApp(context: Context): String? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
                val endTime = System.currentTimeMillis()
                val startTime = endTime - 1000 * 60 // 最近1分钟
                
                val usageStats = usageStatsManager.queryUsageStats(
                    UsageStatsManager.INTERVAL_DAILY,
                    startTime,
                    endTime
                )
                
                usageStats
                    ?.filter { it.lastTimeUsed > 0 }
                    ?.maxByOrNull { it.lastTimeUsed }
                    ?.packageName
            } else {
                null
            }
        } catch (e: Exception) {
            LogManager.d(TAG, "获取前台应用失败", e)
            null
        }
    }
    
    // ==================== 综合状态 ====================
    
    /**
     * 获取完整设备状态
     */
    fun getFullDeviceStatus(context: Context): DeviceStatus {
        return DeviceStatus(
            batteryLevel = getBatteryLevel(context),
            isCharging = isCharging(context),
            chargingType = getChargingType(context),
            isScreenOn = isScreenOn(context),
            isDeviceIdle = isDeviceIdle(context),
            cpuUsage = -1, // CPU使用率需要在协程中获取
            memoryUsagePercent = getMemoryUsagePercent(context),
            isLowMemory = isLowMemory(context),
            foregroundApp = getCurrentForegroundApp(context)
        )
    }
}

/**
 * 📊 CPU 统计信息
 */
private data class CpuStat(
    val total: Long,
    val idle: Long
)

/**
 * ⚡ 充电类型
 */
enum class ChargingType {
    NOT_CHARGING,   // 未充电
    AC,             // 交流电（快充）
    USB,            // USB
    WIRELESS,       // 无线充电
    UNKNOWN         // 未知
}

/**
 * 📱 设备完整状态
 */
data class DeviceStatus(
    val batteryLevel: Int,
    val isCharging: Boolean,
    val chargingType: ChargingType,
    val isScreenOn: Boolean,
    val isDeviceIdle: Boolean,
    val cpuUsage: Int,
    val memoryUsagePercent: Int,
    val isLowMemory: Boolean,
    val foregroundApp: String?
)
