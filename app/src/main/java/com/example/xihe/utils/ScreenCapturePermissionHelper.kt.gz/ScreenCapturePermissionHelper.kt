package com.example.xihe.utils

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import androidx.activity.result.ActivityResultLauncher
import com.example.xihe.vision.ScreenCaptureService

object ScreenCapturePermissionHelper {
    fun createRequestIntent(context: Context): Intent {
        val projectionManager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as? MediaProjectionManager
            ?: throw IllegalStateException("MediaProjectionManager unavailable")
        return projectionManager.createScreenCaptureIntent()
    }

    fun launchRequest(context: Context, launcher: ActivityResultLauncher<Intent>) {
        try {
            launcher.launch(createRequestIntent(context))
        } catch (e: Exception) {
            LogManager.e("ScreenCapturePermission", "Launch screen capture request failed", e)
        }
    }

    fun handleResult(context: Context, resultCode: Int, data: Intent?) {
        if (resultCode != Activity.RESULT_OK || data == null) {
            LogManager.w("ScreenCapturePermission", "Screen capture permission denied")
            return
        }
        val intent = Intent(context, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_START_CAPTURE
            putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(ScreenCaptureService.EXTRA_DATA, data)
        }
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        } catch (e: Exception) {
            LogManager.e("ScreenCapturePermission", "Start screen capture service failed", e)
        }
    }
}
