package com.example.xihe.utils

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
// LogManager imported in same package
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

/**
 * 🔋 电池优化设置助手
 * 
 * 帮助用户配置电池优化豁免，确保应用能够持续后台运行
 */
object BatteryOptimizationHelper {
    
    private const val TAG = "BatteryOptimization"
    
    /**
     * 检查是否已忽略电池优化
     */
    fun isIgnoringBatteryOptimizations(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            powerManager.isIgnoringBatteryOptimizations(context.packageName)
        } else {
            true  // Android 6.0 以下版本不需要
        }
    }
    
    /**
     * 请求忽略电池优化
     */
    fun requestIgnoreBatteryOptimizations(activity: ComponentActivity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!isIgnoringBatteryOptimizations(activity)) {
                try {
                    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                        data = Uri.parse("package:${activity.packageName}")
                    }
                    activity.startActivity(intent)
                    LogManager.i(TAG, "🔋 请求电池优化豁免")
                } catch (e: Exception) {
                    LogManager.e(TAG, "请求电池优化豁免失败", e)
                    // 备选方案：打开电池优化设置页面
                    openBatteryOptimizationSettings(activity)
                }
            }
        }
    }
    
    /**
     * 打开电池优化设置页面
     */
    fun openBatteryOptimizationSettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
            context.startActivity(intent)
            LogManager.i(TAG, "🔋 打开电池优化设置页面")
        } catch (e: Exception) {
            LogManager.e(TAG, "打开电池优化设置页面失败", e)
        }
    }
    
    /**
     * 打开应用详情页（用于手动设置）
     */
    fun openAppDetails(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:${context.packageName}")
            }
            context.startActivity(intent)
            LogManager.i(TAG, "📱 打开应用详情页")
        } catch (e: Exception) {
            LogManager.e(TAG, "打开应用详情页失败", e)
        }
    }
    
    /**
     * 获取电池优化状态说明文本
     */
    fun getBatteryOptimizationStatusText(context: Context): String {
        return if (isIgnoringBatteryOptimizations(context)) {
            "✅ 已关闭电池优化，应用可以持续后台运行"
        } else {
            "⚠️ 电池优化未关闭，建议关闭以确保自动训练功能正常"
        }
    }
    
    /**
     * 获取完整的保活设置指南
     */
    fun getKeepAliveGuide(manufacturer: String = Build.MANUFACTURER.lowercase()): String {
        val baseGuide = """
            📱 保活设置指南
            
            🔋 步骤 1: 关闭电池优化
            - 设置 → 应用 → 羲和 → 电池
            - 选择"不限制"或"无限制"
            
            🚀 步骤 2: 允许自启动
            - 设置 → 应用 → 自启动管理
            - 找到羲和并开启
            
            📢 步骤 3: 允许后台运行
            - 设置 → 应用 → 羲和 → 权限
            - 允许后台活动
        """.trimIndent()
        
        // 根据手机厂商添加特定说明
        val manufacturerGuide = when {
            manufacturer.contains("xiaomi") || manufacturer.contains("redmi") -> """
                
                📱 小米/红米特别设置：
                - 设置 → 应用设置 → 应用管理 → 羲和
                - 省电策略 → 无限制
                - 自启动 → 允许
                - 后台弹出界面 → 允许
                - 显示悬浮窗 → 允许
            """.trimIndent()
            
            manufacturer.contains("huawei") || manufacturer.contains("honor") -> """
                
                📱 华为/荣耀特别设置：
                - 设置 → 应用 → 应用启动管理 → 羲和
                - 改为手动管理
                - 全部勾选（自动启动、后台活动、关联启动）
                - 设置 → 电池 → 应用启动管理 → 羲和 → 手动管理
            """.trimIndent()
            
            manufacturer.contains("oppo") -> """
                
                📱 OPPO特别设置：
                - 设置 → 电池 → 耗电保护 → 关闭
                - 设置 → 应用管理 → 羲和 → 允许自启动
                - 设置 → 应用管理 → 羲和 → 允许关联启动
            """.trimIndent()
            
            manufacturer.contains("vivo") -> """
                
                📱 VIVO特别设置：
                - i管家 → 应用管理 → 权限管理 → 自启动 → 羲和 → 允许
                - i管家 → 省电管理 → 后台高耗电 → 羲和 → 允许
            """.trimIndent()
            
            manufacturer.contains("samsung") -> """
                
                📱 三星特别设置：
                - 设置 → 设备维护 → 电池 → 应用电源管理
                - 找到羲和，设置为"不优化"
                - 休眠应用 → 确保羲和不在列表中
            """.trimIndent()
            
            else -> ""
        }
        
        return baseGuide + manufacturerGuide
    }
}
