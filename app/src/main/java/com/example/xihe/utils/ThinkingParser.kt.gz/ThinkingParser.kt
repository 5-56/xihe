package com.example.xihe.utils

import com.example.xihe.utils.LogManager
import kotlin.text.RegexOption

/**
 * 🧠 思考内容解析器
 * 用于解析 LLM 响应中的思考过程标签
 */
object ThinkingParser {
    private const val TAG = "ThinkingParser"

    /**
     * 🧠 解析 LLM 响应中的思考内容
     * 支持多种格式：<think>...</think>, <thinking>...</thinking>, <reasoning>...</reasoning>
     * 
     * @param response LLM 原始响应
     * @return Pair<思考内容, 实际回复内容>
     */
    fun parse(response: String): Pair<String?, String> {
        // 支持的思考标签格式
        val thinkingPatterns = listOf(
            Regex("<think>(.*?)</think>", RegexOption.DOT_MATCHES_ALL),
            Regex("<thinking>(.*?)</thinking>", RegexOption.DOT_MATCHES_ALL),
            Regex("<reasoning>(.*?)</reasoning>", RegexOption.DOT_MATCHES_ALL),
            Regex("【思考】(.*?)【/思考】", RegexOption.DOT_MATCHES_ALL),
            Regex("\\[思考\\](.*?)\\[/思考\\]", RegexOption.DOT_MATCHES_ALL)
        )
        
        var thinkingContent: String? = null
        var cleanedResponse = response
        
        // 尝试匹配各种思考标签
        for (pattern in thinkingPatterns) {
            val match = pattern.find(response)
            if (match != null) {
                thinkingContent = match.groupValues[1].trim()
                // 从响应中移除思考内容
                cleanedResponse = response.replace(match.value, "").trim()
                LogManager.d(TAG, "🧠 检测到思考内容 (${thinkingContent.length} 字符)")
                break
            }
        }
        
        // 清理可能的 <answer> 标签
        val answerPattern = Regex("<answer>(.*?)</answer>", RegexOption.DOT_MATCHES_ALL)
        val answerMatch = answerPattern.find(cleanedResponse)
        if (answerMatch != null) {
            cleanedResponse = answerMatch.groupValues[1].trim()
        }
        
        return Pair(thinkingContent, cleanedResponse)
    }

    /**
     * 🔊 获取用于 TTS 播报的内容（移除思考过程）
     */
    fun getContentForTTS(response: String): String {
        val (_, cleanContent) = parse(response)
        return cleanContent
    }
}
