package com.example.xihe.utils

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.io.IOException
import java.security.GeneralSecurityException
import java.util.regex.Pattern

object ApiKeyHelper {
    private const val TAG = "ApiKeyHelper"
    private const val PREFS_NAME = "xihe_api_keys"

    private const val KEY_OPENAI = "api_key_openai"
    private const val KEY_DEEPSEEK = "api_key_deepseek"
    private const val KEY_DEEPSEEK_OCR = "api_key_deepseek_ocr"
    private const val KEY_MOONSHOT = "api_key_moonshot"
    private const val KEY_ZHIPU = "api_key_zhipu"
    private const val KEY_GOOGLE = "api_key_google"
    private const val KEY_GITCODE = "api_key_gitcode"
    private const val KEY_CUSTOM = "api_key_custom"
    private const val KEY_PROVIDER_PREFIX = "api_key_provider_"
    private const val KEY_SELECTED_PROVIDER = "selected_provider"

    enum class Provider(val displayName: String, val keyPrefix: String) {
        OPENAI("OpenAI", "sk-"),
        DEEPSEEK("DeepSeek", "sk-"),
        MOONSHOT("Moonshot", "sk-"),
        ZHIPU("Zhipu", ""),
        GOOGLE("Google Gemini", ""),
        GITCODE("GitCode AI", ""),
        CUSTOM("Custom", "")
    }

    sealed class ValidationResult {
        data object Valid : ValidationResult()
        data class Invalid(val reason: String) : ValidationResult()
        data object Empty : ValidationResult()
    }

    private fun getSecurePrefs(context: Context): SharedPreferences {
        return try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()

            EncryptedSharedPreferences.create(
                context,
                PREFS_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: GeneralSecurityException) {
            LogManager.w(TAG, "Encrypted preferences init failed, falling back to plain prefs", e)
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        } catch (e: IOException) {
            LogManager.w(TAG, "Encrypted preferences init failed, falling back to plain prefs", e)
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        } catch (e: RuntimeException) {
            LogManager.w(TAG, "Encrypted preferences init failed, falling back to plain prefs", e)
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        }
    }

    fun saveApiKey(context: Context, provider: Provider, apiKey: String): Boolean {
        return try {
            getSecurePrefs(context).edit()
                .putString(getKeyForProvider(provider), apiKey.trim())
                .apply()
            LogManager.i(TAG, "Saved API key for ${provider.displayName}")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "Failed to save API key", e)
            false
        }
    }

    fun getApiKey(context: Context, provider: Provider): String {
        return try {
            getSecurePrefs(context).getString(getKeyForProvider(provider), "") ?: ""
        } catch (e: Exception) {
            LogManager.e(TAG, "Failed to read API key", e)
            ""
        }
    }

    fun clearApiKey(context: Context, provider: Provider): Boolean {
        return try {
            getSecurePrefs(context).edit().remove(getKeyForProvider(provider)).apply()
            LogManager.i(TAG, "Cleared API key for ${provider.displayName}")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "Failed to clear API key", e)
            false
        }
    }

    fun saveApiKey(context: Context, providerId: String, apiKey: String): Boolean {
        val normalizedProviderId = normalizeProviderId(providerId)
        val mappedProvider = toKnownProvider(normalizedProviderId)
        return if (mappedProvider != null) {
            saveApiKey(context, mappedProvider, apiKey)
        } else {
            try {
                getSecurePrefs(context).edit()
                    .putString(getKeyForProviderId(normalizedProviderId), apiKey.trim())
                    .apply()
                true
            } catch (e: Exception) {
                LogManager.e(TAG, "Failed to save API key", e)
                false
            }
        }
    }

    fun getApiKey(context: Context, providerId: String): String {
        val normalizedProviderId = normalizeProviderId(providerId)
        val mappedProvider = toKnownProvider(normalizedProviderId)
        return if (mappedProvider != null) {
            getApiKey(context, mappedProvider)
        } else {
            try {
                getSecurePrefs(context).getString(getKeyForProviderId(normalizedProviderId), "") ?: ""
            } catch (e: Exception) {
                LogManager.e(TAG, "Failed to read API key", e)
                ""
            }
        }
    }

    fun clearApiKey(context: Context, providerId: String): Boolean {
        val normalizedProviderId = normalizeProviderId(providerId)
        val mappedProvider = toKnownProvider(normalizedProviderId)
        return if (mappedProvider != null) {
            clearApiKey(context, mappedProvider)
        } else {
            try {
                getSecurePrefs(context).edit().remove(getKeyForProviderId(normalizedProviderId)).apply()
                true
            } catch (e: Exception) {
                LogManager.e(TAG, "Failed to clear API key", e)
                false
            }
        }
    }

    fun clearAllApiKeys(context: Context): Boolean {
        return try {
            getSecurePrefs(context).edit().clear().apply()
            LogManager.i(TAG, "Cleared all API keys")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "Failed to clear all API keys", e)
            false
        }
    }

    fun validateApiKey(apiKey: String, provider: Provider): ValidationResult {
        if (apiKey.isBlank()) {
            return ValidationResult.Empty
        }

        val trimmed = apiKey.trim()
        if (trimmed.length < 8) {
            return ValidationResult.Invalid("API key is too short")
        }

        if (!Pattern.matches("^[A-Za-z0-9_\\-.]+$", trimmed)) {
            return ValidationResult.Invalid("API key contains invalid characters")
        }

        return when (provider) {
            Provider.OPENAI -> validateOpenAIKey(trimmed)
            Provider.DEEPSEEK -> validateDeepSeekKey(trimmed)
            Provider.MOONSHOT -> validateMoonshotKey(trimmed)
            Provider.ZHIPU -> validateZhipuKey(trimmed)
            Provider.GOOGLE -> validateGoogleKey(trimmed)
            Provider.GITCODE, Provider.CUSTOM -> ValidationResult.Valid
        }
    }

    private fun validateOpenAIKey(apiKey: String): ValidationResult {
        return when {
            !apiKey.startsWith("sk-") -> ValidationResult.Invalid("OpenAI API key must start with sk-")
            apiKey.length < 20 -> ValidationResult.Invalid("OpenAI API key is too short")
            else -> ValidationResult.Valid
        }
    }

    private fun validateDeepSeekKey(apiKey: String): ValidationResult {
        return when {
            !apiKey.startsWith("sk-") -> ValidationResult.Invalid("DeepSeek API key must start with sk-")
            apiKey.length < 20 -> ValidationResult.Invalid("DeepSeek API key is too short")
            else -> ValidationResult.Valid
        }
    }

    private fun validateMoonshotKey(apiKey: String): ValidationResult {
        return when {
            !apiKey.startsWith("sk-") -> ValidationResult.Invalid("Moonshot API key must start with sk-")
            apiKey.length < 20 -> ValidationResult.Invalid("Moonshot API key is too short")
            else -> ValidationResult.Valid
        }
    }

    private fun validateZhipuKey(apiKey: String): ValidationResult {
        return when {
            apiKey.length < 30 -> ValidationResult.Invalid("Zhipu API key is too short")
            !apiKey.contains(".") -> ValidationResult.Invalid("Zhipu API key format is invalid")
            else -> ValidationResult.Valid
        }
    }

    private fun validateGoogleKey(apiKey: String): ValidationResult {
        return if (apiKey.length < 20) {
            ValidationResult.Invalid("Google API key is too short")
        } else {
            ValidationResult.Valid
        }
    }

    fun isConfigured(context: Context, provider: Provider): Boolean {
        val apiKey = getApiKey(context, provider)
        return apiKey.isNotBlank() && validateApiKey(apiKey, provider) == ValidationResult.Valid
    }

    fun hasAnyApiKey(context: Context): Boolean {
        return Provider.entries.any { isConfigured(context, it) }
    }

    fun getConfiguredProviders(context: Context): List<Provider> {
        return Provider.entries.filter { isConfigured(context, it) }
    }

    fun getSelectedProvider(context: Context): Provider {
        val providerName = getSecurePrefs(context).getString(KEY_SELECTED_PROVIDER, Provider.OPENAI.name)
        return try {
            Provider.valueOf(providerName ?: Provider.OPENAI.name)
        } catch (e: Exception) {
            Provider.OPENAI
        }
    }

    fun setSelectedProvider(context: Context, provider: Provider) {
        getSecurePrefs(context).edit().putString(KEY_SELECTED_PROVIDER, provider.name).apply()
        LogManager.d(TAG, "Selected provider: ${provider.displayName}")
    }

    private fun getKeyForProvider(provider: Provider): String {
        return when (provider) {
            Provider.OPENAI -> KEY_OPENAI
            Provider.DEEPSEEK -> KEY_DEEPSEEK
            Provider.MOONSHOT -> KEY_MOONSHOT
            Provider.ZHIPU -> KEY_ZHIPU
            Provider.GOOGLE -> KEY_GOOGLE
            Provider.GITCODE -> KEY_GITCODE
            Provider.CUSTOM -> KEY_CUSTOM
        }
    }

    private fun normalizeProviderId(providerId: String): String {
        return providerId.trim().lowercase().ifBlank { "openai" }
    }

    private fun toKnownProvider(providerId: String): Provider? {
        return when (providerId) {
            "openai" -> Provider.OPENAI
            "deepseek" -> Provider.DEEPSEEK
            "moonshot" -> Provider.MOONSHOT
            "zhipu" -> Provider.ZHIPU
            "google", "google_openai" -> Provider.GOOGLE
            "gitcode" -> Provider.GITCODE
            else -> null
        }
    }

    private fun getKeyForProviderId(providerId: String): String {
        val normalizedProviderId = normalizeProviderId(providerId)
        return "$KEY_PROVIDER_PREFIX${normalizedProviderId.replace(Regex("[^a-z0-9_]"), "_")}"
    }

    fun getMaskedApiKey(apiKey: String): String {
        if (apiKey.length <= 8) {
            return "****"
        }
        val prefix = apiKey.take(4)
        val suffix = apiKey.takeLast(4)
        val maskLength = (apiKey.length - 8).coerceAtMost(8)
        return "$prefix${"*".repeat(maskLength)}$suffix"
    }

    fun getConfigurationSummary(context: Context): String {
        val configured = getConfiguredProviders(context)
        return if (configured.isEmpty()) {
            "No API keys configured"
        } else {
            val selected = getSelectedProvider(context)
            val providerList = configured.joinToString { it.displayName }
            "Configured: $providerList\nSelected: ${selected.displayName}"
        }
    }

    fun getDeepSeekOcrApiKey(context: Context): String {
        val ocrKey = getSecurePrefs(context).getString(KEY_DEEPSEEK_OCR, "") ?: ""
        if (ocrKey.isNotBlank()) {
            return ocrKey
        }
        return getApiKey(context, Provider.DEEPSEEK)
    }

    fun saveDeepSeekOcrApiKey(context: Context, apiKey: String): Boolean {
        return try {
            getSecurePrefs(context).edit().putString(KEY_DEEPSEEK_OCR, apiKey.trim()).apply()
            LogManager.i(TAG, "Saved DeepSeek OCR API key")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "Failed to save DeepSeek OCR API key", e)
            false
        }
    }
}
