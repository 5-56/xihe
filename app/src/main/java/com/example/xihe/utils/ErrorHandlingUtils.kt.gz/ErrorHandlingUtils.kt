package com.example.xihe.utils

import com.google.gson.JsonSyntaxException
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

/**
 * ⚠️ 错误处理工具类
 * 
 * 提供统一的错误分类、转换和日志记录功能
 */
object ErrorHandlingUtils {
    
    private const val TAG = "ErrorHandling"
    
    /**
     * 应用错误密封类
     * 
     * 将各种异常统一为应用级错误类型
     */
    sealed class AppError(
        open val message: String,
        open val cause: Throwable? = null,
        open val retryable: Boolean = false,
        open val errorCode: String? = null
    ) {
        /**
         * 网络错误（通常可重试）
         */
        data class NetworkError(
            override val message: String,
            override val cause: Throwable? = null,
            override val retryable: Boolean = true,
            val httpCode: Int? = null
        ) : AppError(message, cause, retryable, "NETWORK_ERROR")
        
        /**
         * 解析错误（不可重试）
         */
        data class ParseError(
            override val message: String,
            override val cause: Throwable? = null,
            val rawData: String? = null
        ) : AppError(message, cause, false, "PARSE_ERROR")
        
        /**
         * 验证错误（不可重试）
         */
        data class ValidationError(
            override val message: String,
            val field: String? = null,
            val invalidValue: Any? = null
        ) : AppError(message, null, false, "VALIDATION_ERROR")
        
        /**
         * 权限错误（不可重试）
         */
        data class PermissionError(
            override val message: String,
            val permission: String? = null
        ) : AppError(message, null, false, "PERMISSION_ERROR")
        
        /**
         * 资源未找到错误（不可重试）
         */
        data class NotFoundError(
            override val message: String,
            val resourceType: String? = null,
            val resourceId: String? = null
        ) : AppError(message, null, false, "NOT_FOUND_ERROR")
        
        /**
         * 超时错误（可重试）
         */
        data class TimeoutError(
            override val message: String,
            override val cause: Throwable? = null,
            val timeoutMs: Long? = null
        ) : AppError(message, cause, true, "TIMEOUT_ERROR")
        
        /**
         * 配置错误（不可重试）
         */
        data class ConfigurationError(
            override val message: String,
            val configKey: String? = null
        ) : AppError(message, null, false, "CONFIG_ERROR")
        
        /**
         * 未知错误（不可重试）
         */
        data class UnexpectedError(
            override val message: String,
            override val cause: Throwable? = null
        ) : AppError(message, cause, false, "UNEXPECTED_ERROR")
        
        /**
         * 转换为异常
         */
        fun toException(): Exception {
            return AppException(this)
        }
        
        /**
         * 获取用户友好的错误消息
         */
        fun getUserMessage(): String = when (this) {
            is NetworkError -> "网络连接失败，请检查网络设置"
            is ParseError -> "数据解析失败，请稍后重试"
            is ValidationError -> field?.let { "输入验证失败: $it" } ?: "输入验证失败"
            is PermissionError -> permission?.let { "缺少权限: $it" } ?: "权限不足"
            is NotFoundError -> resourceType?.let { "未找到$it" } ?: "资源未找到"
            is TimeoutError -> "请求超时，请稍后重试"
            is ConfigurationError -> "配置错误，请检查设置"
            is UnexpectedError -> "发生未知错误，请稍后重试"
        }
    }
    
    /**
     * 应用异常包装类
     */
    class AppException(
        val appError: AppError
    ) : Exception(appError.message, appError.cause)

    
    /**
     * 将异常转换为 AppError
     * 
     * @param exception 原始异常
     * @param context 上下文描述
     * @return 对应的 AppError
     */
    fun toAppError(exception: Exception, context: String = ""): AppError {
        val contextPrefix = if (context.isNotEmpty()) "$context: " else ""
        
        return when (exception) {
            // 网络相关异常
            is SocketTimeoutException -> AppError.TimeoutError(
                message = "${contextPrefix}请求超时",
                cause = exception
            )
            is UnknownHostException -> AppError.NetworkError(
                message = "${contextPrefix}无法解析主机",
                cause = exception
            )
            is IOException -> AppError.NetworkError(
                message = "${contextPrefix}网络错误: ${exception.message}",
                cause = exception
            )
            
            // 解析相关异常
            is JsonSyntaxException -> AppError.ParseError(
                message = "${contextPrefix}JSON解析失败: ${exception.message}",
                cause = exception
            )
            is NumberFormatException -> AppError.ParseError(
                message = "${contextPrefix}数字格式错误: ${exception.message}",
                cause = exception
            )
            
            // 验证相关异常
            is IllegalArgumentException -> AppError.ValidationError(
                message = "${contextPrefix}${exception.message ?: "参数无效"}"
            )
            is IllegalStateException -> AppError.ConfigurationError(
                message = "${contextPrefix}${exception.message ?: "状态无效"}"
            )
            
            // 权限相关异常
            is SecurityException -> AppError.PermissionError(
                message = "${contextPrefix}权限被拒绝: ${exception.message}"
            )
            
            // 已经是 AppException
            is AppException -> exception.appError
            
            // 其他异常
            else -> AppError.UnexpectedError(
                message = "${contextPrefix}${exception.message ?: "未知错误"}",
                cause = exception
            )
        }
    }
    
    /**
     * 记录错误并返回 AppError
     * 
     * @param tag 日志标签
     * @param exception 原始异常
     * @param context 上下文信息
     * @return AppError
     */
    fun logAndWrap(
        tag: String,
        exception: Exception,
        context: Map<String, Any> = emptyMap()
    ): AppError {
        val appError = toAppError(exception)
        
        // 构建日志消息
        val logMessage = buildString {
            append("❌ ${appError.errorCode ?: "ERROR"}: ${appError.message}")
            if (context.isNotEmpty()) {
                append("\n上下文:")
                context.forEach { (key, value) ->
                    append("\n  - $key: $value")
                }
            }
            append("\n可重试: ${appError.retryable}")
        }
        
        // 根据错误类型选择日志级别
        when (appError) {
            is AppError.UnexpectedError -> LogManager.e(tag, logMessage, exception)
            is AppError.NetworkError, is AppError.TimeoutError -> LogManager.w(tag, logMessage)
            else -> LogManager.e(tag, logMessage)
        }
        
        return appError
    }
    
    /**
     * 安全执行操作，捕获异常并转换为 AppError
     * 
     * @param context 上下文描述
     * @param block 要执行的操作
     * @return Result 包装的结果
     */
    inline fun <T> runCatching(
        context: String = "",
        block: () -> T
    ): Result<T> {
        return try {
            Result.success(block())
        } catch (e: Exception) {
            Result.failure(toAppError(e, context).toException())
        }
    }
    
    /**
     * 安全执行挂起操作
     */
    suspend inline fun <T> runCatchingSuspend(
        context: String = "",
        crossinline block: suspend () -> T
    ): Result<T> {
        return try {
            Result.success(block())
        } catch (e: Exception) {
            Result.failure(toAppError(e, context).toException())
        }
    }
    
    /**
     * 从 Result 中提取 AppError
     */
    fun <T> Result<T>.getAppError(): AppError? {
        val exception = exceptionOrNull() ?: return null
        return if (exception is AppException) {
            exception.appError
        } else {
            toAppError(exception as? Exception ?: Exception(exception))
        }
    }
    
    /**
     * 判断错误是否可重试
     */
    fun isRetryable(exception: Exception): Boolean {
        return toAppError(exception).retryable
    }
    
    /**
     * 创建带有HTTP状态码的网络错误
     */
    fun httpError(code: Int, message: String): AppError.NetworkError {
        val retryable = code in 500..599 || code == 429
        return AppError.NetworkError(
            message = "HTTP $code: $message",
            httpCode = code,
            retryable = retryable
        )
    }
    
    /**
     * 创建验证错误
     */
    fun validationError(field: String, message: String, value: Any? = null): AppError.ValidationError {
        return AppError.ValidationError(
            message = "$field: $message",
            field = field,
            invalidValue = value
        )
    }
    
    /**
     * 创建配置错误
     */
    fun configError(key: String, message: String): AppError.ConfigurationError {
        return AppError.ConfigurationError(
            message = message,
            configKey = key
        )
    }
}
