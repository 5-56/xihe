package com.example.xihe.utils

import android.content.Context
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * 🚀 懒加载初始化工具类
 *
 * 用于优化应用启动性能，将非关键模块的初始化延迟到需要时或后台空闲时执行
 *
 * 特性：
 * - 支持延迟初始化（首次访问时初始化）
 * - 支持后台异步初始化（应用启动后空闲时初始化）
 * - 支持优先级排序
 * - 线程安全
 * - 提供初始化状态监控
 *
 * @author Xihe AI Team
 */
object LazyInitializer {

    private const val TAG = "LazyInitializer"

    /**
     * 初始化优先级
     */
    enum class Priority(val value: Int) {
        CRITICAL(0),    // 关键：必须立即初始化
        HIGH(1),        // 高：尽快初始化
        NORMAL(2),      // 普通：正常优先级
        LOW(3),         // 低：可延迟初始化
        IDLE(4)         // 空闲：等系统空闲时初始化
    }

    /**
     * 初始化状态
     */
    enum class InitState {
        NOT_INITIALIZED,    // 未初始化
        INITIALIZING,       // 初始化中
        INITIALIZED,        // 已初始化
        FAILED              // 初始化失败
    }

    /**
     * 初始化任务
     */
    data class InitTask(
        val name: String,
        val priority: Priority,
        val initializer: suspend (Context) -> Unit,
        val onError: ((Exception) -> Unit)? = null
    )

    /**
     * 初始化结果
     */
    data class InitResult(
        val name: String,
        val state: InitState,
        val duration: Long,
        val error: String? = null
    )

    // ==================== 状态管理 ====================

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private val initStates = ConcurrentHashMap<String, InitState>()
    private val initResults = ConcurrentHashMap<String, InitResult>()
    private val pendingTasks = ConcurrentHashMap<String, InitTask>()

    private val _totalTasks = AtomicInteger(0)
    private val _completedTasks = AtomicInteger(0)
    private val _isInitializing = AtomicBoolean(false)

    private val _initProgress = MutableStateFlow(0f)
    val initProgress: StateFlow<Float> = _initProgress.asStateFlow()

    private val _initStatus = MutableStateFlow("")
    val initStatus: StateFlow<String> = _initStatus.asStateFlow()

    // 懒加载实例缓存
    private val lazyInstances = ConcurrentHashMap<String, Any>()
    private val lazyLocks = ConcurrentHashMap<String, Any>()
    
    // 异步懒加载的 Mutex 缓存
    private val lazyMutexes = ConcurrentHashMap<String, Mutex>()

    // ==================== 注册任务 ====================

    /**
     * 注册初始化任务
     */
    fun register(task: InitTask) {
        if (initStates[task.name] == InitState.INITIALIZED) {
            LogManager.d(TAG, "任务 ${task.name} 已初始化，跳过注册")
            return
        }
        pendingTasks[task.name] = task
        initStates[task.name] = InitState.NOT_INITIALIZED
        _totalTasks.incrementAndGet()
        LogManager.d(TAG, "📝 注册初始化任务: ${task.name} (优先级: ${task.priority})")
    }

    /**
     * 注册简单初始化任务
     */
    fun register(
        name: String,
        priority: Priority = Priority.NORMAL,
        initializer: suspend (Context) -> Unit
    ) {
        register(InitTask(name, priority, initializer))
    }

    // ==================== 执行初始化 ====================

    /**
     * 执行所有初始化任务（按优先级顺序）
     */
    suspend fun initializeAll(context: Context) {
        if (_isInitializing.getAndSet(true)) {
            LogManager.w(TAG, "初始化已在进行中")
            return
        }

        val startTime = System.currentTimeMillis()
        LogManager.i(TAG, "🚀 开始执行所有初始化任务...")
        _initStatus.value = "正在初始化..."

        try {
            // 按优先级排序
            val sortedTasks = pendingTasks.values.sortedBy { it.priority.value }

            for (task in sortedTasks) {
                if (initStates[task.name] == InitState.INITIALIZED) continue

                executeTask(context, task)
                updateProgress()
            }

            val duration = System.currentTimeMillis() - startTime
            LogManager.i(TAG, "✅ 所有初始化任务完成，耗时: ${duration}ms")
            _initStatus.value = "初始化完成"

        } finally {
            _isInitializing.set(false)
        }
    }

    /**
     * 仅执行关键和高优先级任务（启动时调用）
     */
    suspend fun initializeCritical(context: Context) {
        LogManager.i(TAG, "🚀 执行关键初始化任务...")

        val criticalTasks = pendingTasks.values.filter {
            it.priority == Priority.CRITICAL || it.priority == Priority.HIGH
        }.sortedBy { it.priority.value }

        for (task in criticalTasks) {
            if (initStates[task.name] == InitState.INITIALIZED) continue
            executeTask(context, task)
        }

        LogManager.i(TAG, "✅ 关键初始化任务完成")
    }

    /**
     * 后台初始化非关键任务（启动后调用）
     */
    fun initializeInBackground(context: Context) {
        scope.launch {
            // 等待一段时间，让UI先稳定
            delay(2000)

            LogManager.d(TAG, "🔄 开始后台初始化...")

            val backgroundTasks = pendingTasks.values.filter {
                it.priority == Priority.NORMAL ||
                it.priority == Priority.LOW ||
                it.priority == Priority.IDLE
            }.filter {
                initStates[it.name] != InitState.INITIALIZED
            }.sortedBy { it.priority.value }

            for (task in backgroundTasks) {
                executeTask(context, task)
                updateProgress()

                // 低优先级任务之间增加延迟，避免影响前台性能
                if (task.priority == Priority.LOW || task.priority == Priority.IDLE) {
                    delay(100)
                }
            }

            LogManager.d(TAG, "✅ 后台初始化完成")
        }
    }

    /**
     * 执行单个任务
     */
    private suspend fun executeTask(context: Context, task: InitTask) {
        if (initStates[task.name] == InitState.INITIALIZED) return

        val startTime = System.currentTimeMillis()
        initStates[task.name] = InitState.INITIALIZING
        _initStatus.value = "正在初始化: ${task.name}"

        try {
            withContext(Dispatchers.Default) {
                task.initializer(context)
            }

            val duration = System.currentTimeMillis() - startTime
            initStates[task.name] = InitState.INITIALIZED
            initResults[task.name] = InitResult(
                name = task.name,
                state = InitState.INITIALIZED,
                duration = duration
            )
            pendingTasks.remove(task.name)
            _completedTasks.incrementAndGet()

            LogManager.d(TAG, "✅ ${task.name} 初始化完成 (${duration}ms)")

        } catch (e: Exception) {
            val duration = System.currentTimeMillis() - startTime
            initStates[task.name] = InitState.FAILED
            initResults[task.name] = InitResult(
                name = task.name,
                state = InitState.FAILED,
                duration = duration,
                error = e.message
            )
            _completedTasks.incrementAndGet()

            LogManager.e(TAG, "❌ ${task.name} 初始化失败", e)
            task.onError?.invoke(e)
        }
    }

    /**
     * 更新进度
     */
    private fun updateProgress() {
        val total = _totalTasks.get()
        val completed = _completedTasks.get()
        _initProgress.value = if (total > 0) completed.toFloat() / total else 1f
    }

    // ==================== 懒加载支持 ====================

    /**
     * 获取或创建懒加载实例
     * 线程安全的单例模式
     */
    @Suppress("UNCHECKED_CAST")
    fun <T : Any> getOrCreate(key: String, creator: () -> T): T {
        // 快速路径：已存在直接返回
        lazyInstances[key]?.let { return it as T }

        // 获取或创建锁对象
        val lock = lazyLocks.getOrPut(key) { Any() }

        // 双重检查锁定
        return synchronized(lock) {
            lazyInstances[key]?.let { return@synchronized it as T }

            val instance = creator()
            lazyInstances[key] = instance
            LogManager.d(TAG, "🔧 懒加载创建实例: $key")
            instance
        }
    }

    /**
     * 获取或创建懒加载实例（带 Context）
     */
    @Suppress("UNCHECKED_CAST")
    fun <T : Any> getOrCreate(key: String, context: Context, creator: (Context) -> T): T {
        lazyInstances[key]?.let { return it as T }

        val lock = lazyLocks.getOrPut(key) { Any() }

        return synchronized(lock) {
            lazyInstances[key]?.let { return@synchronized it as T }

            val instance = creator(context.applicationContext)
            lazyInstances[key] = instance
            LogManager.d(TAG, "🔧 懒加载创建实例: $key")
            instance
        }
    }

    /**
     * 异步获取或创建实例
     * 使用 Mutex 替代 synchronized + runBlocking，避免阻塞
     */
    suspend fun <T : Any> getOrCreateAsync(key: String, creator: suspend () -> T): T {
        @Suppress("UNCHECKED_CAST")
        lazyInstances[key]?.let { return it as T }

        // 获取或创建该 key 对应的 Mutex
        val mutex = lazyMutexes.getOrPut(key) { Mutex() }
        
        return mutex.withLock {
            @Suppress("UNCHECKED_CAST")
            lazyInstances[key]?.let { return@withLock it as T }

            val instance = creator()
            lazyInstances[key] = instance
            LogManager.d(TAG, "🔧 懒加载创建实例: $key")
            instance
        }
    }

    /**
     * 检查实例是否已创建
     */
    fun isCreated(key: String): Boolean = lazyInstances.containsKey(key)

    /**
     * 移除懒加载实例
     */
    fun remove(key: String) {
        lazyInstances.remove(key)
        lazyLocks.remove(key)
    }

    // ==================== 状态查询 ====================

    /**
     * 获取任务初始化状态
     */
    fun getState(name: String): InitState {
        return initStates[name] ?: InitState.NOT_INITIALIZED
    }

    /**
     * 检查是否已初始化
     */
    fun isInitialized(name: String): Boolean {
        return initStates[name] == InitState.INITIALIZED
    }

    /**
     * 等待任务初始化完成
     */
    suspend fun awaitInitialized(name: String, timeoutMs: Long = 10000): Boolean {
        val startTime = System.currentTimeMillis()

        while (System.currentTimeMillis() - startTime < timeoutMs) {
            if (initStates[name] == InitState.INITIALIZED) {
                return true
            }
            if (initStates[name] == InitState.FAILED) {
                return false
            }
            delay(50)
        }

        LogManager.w(TAG, "等待 $name 初始化超时")
        return false
    }

    /**
     * 获取所有初始化结果
     */
    fun getResults(): Map<String, InitResult> = initResults.toMap()

    /**
     * 获取初始化统计信息
     */
    fun getStatistics(): Map<String, Any> {
        val results = initResults.values.toList()
        val total: Any = _totalTasks.get()
        val completed: Any = _completedTasks.get()
        val pending: Any = pendingTasks.size
        val succeeded: Any = results.count { it.state == InitState.INITIALIZED }
        val failed: Any = results.count { it.state == InitState.FAILED }
        val totalDuration: Any = results.sumOf { it.duration }
        val averageDuration: Any = if (results.isNotEmpty()) results.sumOf { it.duration } / results.size else 0L
        val lazyInstancesCount: Any = lazyInstances.size
        
        return mapOf(
            "total" to total,
            "completed" to completed,
            "pending" to pending,
            "succeeded" to succeeded,
            "failed" to failed,
            "totalDuration" to totalDuration,
            "averageDuration" to averageDuration,
            "lazyInstances" to lazyInstancesCount
        )
    }

    // ==================== 重置 ====================

    /**
     * 重置所有状态
     */
    fun reset() {
        initStates.clear()
        initResults.clear()
        pendingTasks.clear()
        lazyInstances.clear()
        lazyLocks.clear()
        lazyMutexes.clear()
        _totalTasks.set(0)
        _completedTasks.set(0)
        _initProgress.value = 0f
        _initStatus.value = ""
        LogManager.d(TAG, "🔄 懒加载初始化器已重置")
    }

    /**
     * 清理资源
     */
    fun cleanup() {
        scope.cancel()
        reset()
        LogManager.d(TAG, "🧹 懒加载初始化器已清理")
    }
}

/**
 * 懒加载委托属性
 * 使用方式: val instance by lazyInit { MyClass() }
 */
fun <T : Any> lazyInit(key: String? = null, creator: () -> T): Lazy<T> {
    return lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        if (key != null) {
            LazyInitializer.getOrCreate(key, creator)
        } else {
            creator()
        }
    }
}

/**
 * 懒加载委托属性（带 Context）
 */
class LazyWithContext<T : Any>(
    private val key: String,
    private val creator: (Context) -> T
) {
    @Volatile
    private var instance: T? = null

    fun get(context: Context): T {
        return instance ?: synchronized(this) {
            instance ?: LazyInitializer.getOrCreate(key, context, creator).also {
                instance = it
            }
        }
    }
}
