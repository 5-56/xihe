package com.example.xihe.utils

import android.Manifest
import android.app.AppOpsManager
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.model.PermissionInfo
import com.example.xihe.model.PermissionStatus
import com.example.xihe.model.PermissionType

/**
 * 权限检查工具类
 */
object PermissionChecker {
    
    /**
     * 检查单个权限状态
     */
    fun checkPermission(context: Context, permissionInfo: PermissionInfo): PermissionStatus {
        val sdkVersion = Build.VERSION.SDK_INT
        if (sdkVersion < permissionInfo.minSdkVersion || sdkVersion > permissionInfo.maxSdkVersion) {
            return PermissionStatus.NotApplicable
        }
        
        return when (permissionInfo.type) {
            PermissionType.RUNTIME -> checkRuntimePermission(context, permissionInfo.permission)
            PermissionType.SPECIAL -> checkSpecialPermission(context, permissionInfo.permission)
            PermissionType.INSTALL_TIME -> PermissionStatus.AutoGranted
        }
    }
    
    private fun checkRuntimePermission(context: Context, permission: String): PermissionStatus {
        return if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) {
            PermissionStatus.Granted
        } else {
            PermissionStatus.Denied
        }
    }
    
    private fun checkSpecialPermission(context: Context, permission: String): PermissionStatus {
        return when (permission) {
            "BIND_ACCESSIBILITY_SERVICE" -> {
                if (isAccessibilityServiceEnabled(context)) PermissionStatus.Granted else PermissionStatus.Denied
            }
            Manifest.permission.SYSTEM_ALERT_WINDOW -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (Settings.canDrawOverlays(context)) PermissionStatus.Granted else PermissionStatus.Denied
                } else {
                    PermissionStatus.Granted
                }
            }
            Manifest.permission.PACKAGE_USAGE_STATS -> {
                if (hasUsageStatsPermission(context)) PermissionStatus.Granted else PermissionStatus.Denied
            }
            Manifest.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
                    if (pm.isIgnoringBatteryOptimizations(context.packageName)) {
                        PermissionStatus.Granted
                    } else {
                        PermissionStatus.Denied
                    }
                } else {
                    PermissionStatus.Granted
                }
            }
            "BIND_NOTIFICATION_LISTENER_SERVICE" -> {
                if (isNotificationListenerEnabled(context)) PermissionStatus.Granted else PermissionStatus.Denied
            }
            Manifest.permission.WRITE_SETTINGS -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (Settings.System.canWrite(context)) PermissionStatus.Granted else PermissionStatus.Denied
                } else {
                    PermissionStatus.Granted
                }
            }
            "MANAGE_EXTERNAL_STORAGE" -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    if (Environment.isExternalStorageManager()) PermissionStatus.Granted else PermissionStatus.Denied
                } else {
                    PermissionStatus.NotApplicable
                }
            }
            else -> PermissionStatus.Denied
        }
    }
    
    private fun isAccessibilityServiceEnabled(context: Context): Boolean {
        return try {
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            
            val componentName = ComponentName(context, CoreAccessibilityService::class.java)
            enabledServices.contains(componentName.flattenToString()) ||
                enabledServices.contains(componentName.flattenToShortString())
        } catch (e: Exception) {
            false
        }
    }
    
    private fun hasUsageStatsPermission(context: Context): Boolean {
        return try {
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    android.os.Process.myUid(),
                    context.packageName
                )
            } else {
                @Suppress("DEPRECATION")
                appOps.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    android.os.Process.myUid(),
                    context.packageName
                )
            }
            mode == AppOpsManager.MODE_ALLOWED
        } catch (e: Exception) {
            false
        }
    }
    
    private fun isNotificationListenerEnabled(context: Context): Boolean {
        return try {
            val enabledListeners = Settings.Secure.getString(
                context.contentResolver,
                "enabled_notification_listeners"
            ) ?: return false
            
            enabledListeners.contains(context.packageName)
        } catch (e: Exception) {
            false
        }
    }
    
    fun getAllPermissionStatuses(
        context: Context, 
        permissions: List<PermissionInfo>
    ): Map<String, PermissionStatus> {
        return permissions.associate { it.permission to checkPermission(context, it) }
    }
    
    fun getPermissionStats(
        context: Context,
        permissions: List<PermissionInfo>
    ): PermissionStats {
        val statuses = getAllPermissionStatuses(context, permissions)
        
        val granted = statuses.count { it.value == PermissionStatus.Granted || it.value == PermissionStatus.AutoGranted }
        val denied = statuses.count { it.value == PermissionStatus.Denied }
        val notApplicable = statuses.count { it.value == PermissionStatus.NotApplicable }
        val total = permissions.size - notApplicable
        
        return PermissionStats(granted, denied, notApplicable, total)
    }
}

data class PermissionStats(
    val granted: Int,
    val denied: Int,
    val notApplicable: Int,
    val total: Int
) {
    val percentage: Float
        get() = if (total > 0) granted.toFloat() / total else 0f
}
