package com.example.xihe.utils

import android.app.ActivityManager
import android.content.Context
import android.os.Debug
import android.os.Process
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ConcurrentHashMap
import kotlin.system.measureTimeMillis

/**
 * 📊 性能监控器
 * 
 * 用于监控应用性能指标，包括：
 * - 内存使用情况
 * - 协程状态
 * - 方法执行时间
 * - UI帧率（可扩展）
 * 
 * ✅ 优化：集中式性能监控，便于发现和解决性能问题
 */
object PerformanceMonitor {
    
    private const val TAG = "PerformanceMonitor"
    private const val DEFAULT_LOG_INTERVAL_MS = 30000L // 30秒
    
    // 内存状态
    data class MemoryStats(
        val usedHeapMB: Long,
        val maxHeapMB: Long,
        val usedNativeMB: Long,
        val totalPSSMB: Long,
        val timestamp: Long = System.currentTimeMillis()
    )
    
    // 协程统计
    data class CoroutineStats(
        val activeJobs: Int = 0,
        val completedJobs: Long = 0,
        val cancelledJobs: Long = 0,
        val failedJobs: Long = 0
    )
    
    // 性能指标状态流
    private val _memoryStats = MutableStateFlow<MemoryStats?>(null)
    val memoryStats: StateFlow<MemoryStats?> = _memoryStats.asStateFlow()
    
    private val _coroutineStats = MutableStateFlow(CoroutineStats())
    val coroutineStats: StateFlow<CoroutineStats> = _coroutineStats.asStateFlow()
    
    // 方法执行时间统计
    private val methodTiming = ConcurrentHashMap<String, MutableList<Long>>()
    
    private var monitoringJob: Job? = null
    private var isMonitoring = false
    
    /**
     * 开始性能监控
     */
    fun startMonitoring(
        context: Context,
        intervalMs: Long = DEFAULT_LOG_INTERVAL_MS
    ) {
        if (isMonitoring) return
        isMonitoring = true
        
        monitoringJob = CoroutineScope(Dispatchers.Default).launch {
            while (isActive) {
                updateMemoryStats(context)
                updateCoroutineStats()
                
                delay(intervalMs)
            }
        }
        
        LogManager.i(TAG, "性能监控已启动，间隔: ${intervalMs}ms")
    }
    
    /**
     * 停止性能监控
     */
    fun stopMonitoring() {
        isMonitoring = false
        monitoringJob?.cancel()
        monitoringJob = null
        LogManager.i(TAG, "性能监控已停止")
    }
    
    /**
     * 更新内存统计
     */
    private fun updateMemoryStats(context: Context) {
        val runtime = Runtime.getRuntime()
        val usedHeap = (runtime.totalMemory() - runtime.freeMemory()) / 1024 / 1024
        val maxHeap = runtime.maxMemory() / 1024 / 1024
        
        // 获取更详细的内存信息
        val memInfo = Debug.MemoryInfo()
        Debug.getMemoryInfo(memInfo)
        val totalPSS = memInfo.totalPss / 1024
        val nativeHeap = Debug.getNativeHeapAllocatedSize() / 1024 / 1024
        
        _memoryStats.value = MemoryStats(
            usedHeapMB = usedHeap,
            maxHeapMB = maxHeap,
            usedNativeMB = nativeHeap,
            totalPSSMB = totalPSS.toLong()
        )
        
        // 内存警告
        if (usedHeap > maxHeap * 0.8) {
            LogManager.w(TAG, "⚠️ 内存使用超过80%: ${usedHeap}MB/${maxHeap}MB")
            suggestMemoryOptimization()
        }
    }
    
    /**
     * 更新协程统计
     */
    private fun updateCoroutineStats() {
        // 这里可以集成更详细的协程监控
        val currentStats = _coroutineStats.value
        _coroutineStats.value = currentStats.copy(
            activeJobs = currentStats.activeJobs // 实际实现中需要跟踪活跃任务
        )
    }
    
    /**
     * 记录方法执行时间
     */
    fun <T> trackExecutionTime(
        methodName: String,
        block: () -> T
    ): T {
        val startTime = System.currentTimeMillis()
        val result = block()
        val duration = System.currentTimeMillis() - startTime
        
        methodTiming.getOrPut(methodName) { mutableListOf() }.add(duration)
        
        // 保留最近100次记录
        val times = methodTiming[methodName]
        if (times != null && times.size > 100) {
            times.removeAt(0)
        }
        
        // 慢操作警告
        if (duration > 1000) {
            LogManager.w(TAG, "⏱️ 慢操作: $methodName 耗时 ${duration}ms")
        }
        
        return result
    }
    
    /**
     * 记录协程任务状态变化
     */
    fun recordJobStarted() {
        val current = _coroutineStats.value
        _coroutineStats.value = current.copy(
            activeJobs = current.activeJobs + 1
        )
    }
    
    fun recordJobCompleted() {
        val current = _coroutineStats.value
        _coroutineStats.value = current.copy(
            activeJobs = (current.activeJobs - 1).coerceAtLeast(0),
            completedJobs = current.completedJobs + 1
        )
    }
    
    fun recordJobCancelled() {
        val current = _coroutineStats.value
        _coroutineStats.value = current.copy(
            activeJobs = (current.activeJobs - 1).coerceAtLeast(0),
            cancelledJobs = current.cancelledJobs + 1
        )
    }
    
    fun recordJobFailed() {
        val current = _coroutineStats.value
        _coroutineStats.value = current.copy(
            activeJobs = (current.activeJobs - 1).coerceAtLeast(0),
            failedJobs = current.failedJobs + 1
        )
    }
    
    /**
     * 记录内存使用（用于标记特定位置）
     */
    fun logMemoryUsage(tag: String) {
        val runtime = Runtime.getRuntime()
        val used = (runtime.totalMemory() - runtime.freeMemory()) / 1024 / 1024
        val max = runtime.maxMemory() / 1024 / 1024
        LogManager.d(TAG, "[$tag] 内存使用: ${used}MB / ${max}MB (${used * 100 / max}%)")
    }
    
    /**
     * 获取方法平均执行时间
     */
    fun getAverageExecutionTime(methodName: String): Double {
        val times = methodTiming[methodName] ?: return 0.0
        return if (times.isEmpty()) 0.0 else times.average()
    }
    
    /**
     * 生成性能报告
     */
    fun generateReport(): String {
        val memStats = _memoryStats.value
        val corStats = _coroutineStats.value
        
        return buildString {
            appendLine("=".repeat(50))
            appendLine("📊 性能报告")
            appendLine("=".repeat(50))
            
            memStats?.let {
                appendLine("\n💾 内存使用:")
                appendLine("  - 堆内存: ${it.usedHeapMB}MB / ${it.maxHeapMB}MB")
                appendLine("  - Native: ${it.usedNativeMB}MB")
                appendLine("  - Total PSS: ${it.totalPSSMB}MB")
            }
            
            appendLine("\n🔄 协程统计:")
            appendLine("  - 活跃任务: ${corStats.activeJobs}")
            appendLine("  - 已完成: ${corStats.completedJobs}")
            appendLine("  - 已取消: ${corStats.cancelledJobs}")
            appendLine("  - 失败: ${corStats.failedJobs}")
            
            if (methodTiming.isNotEmpty()) {
                appendLine("\n⏱️ 方法执行时间:")
                methodTiming.forEach { (name, times) ->
                    val avg = times.average()
                    val max = times.maxOrNull() ?: 0
                    appendLine("  - $name: 平均${avg.toInt()}ms, 最大${max}ms")
                }
            }
            
            appendLine("=".repeat(50))
        }
    }
    
    /**
     * 内存优化建议
     */
    private fun suggestMemoryOptimization() {
        LogManager.d(TAG, "💡 内存优化建议:")
        LogManager.d(TAG, "  1. 调用 EngineStateManager.cleanupOldMessages()")
        LogManager.d(TAG, "  2. 检查是否有大图未释放")
        LogManager.d(TAG, "  3. 触发垃圾回收: System.gc()")
    }
    
    /**
     * 清理统计数据
     */
    fun clearStats() {
        methodTiming.clear()
        _coroutineStats.value = CoroutineStats()
        LogManager.d(TAG, "性能统计数据已清理")
    }
}

/**
 * 协程性能跟踪扩展
 */
fun <T> CoroutineScope.launchWithTracking(
    tag: String,
    block: suspend CoroutineScope.() -> T
): Job {
    PerformanceMonitor.recordJobStarted()
    
    return this.launch {
        try {
            val startTime = System.currentTimeMillis()
            block()
            val duration = System.currentTimeMillis() - startTime
            
            if (duration > 1000) {
                LogManager.w("Coroutine", "[$tag] 协程执行耗时过长: ${duration}ms")
            }
            
            PerformanceMonitor.recordJobCompleted()
        } catch (e: CancellationException) {
            PerformanceMonitor.recordJobCancelled()
            throw e
        } catch (e: Exception) {
            PerformanceMonitor.recordJobFailed()
            LogManager.e("Coroutine", "[$tag] 协程执行失败", e)
            throw e
        }
    }
}
