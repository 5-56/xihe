package com.example.xihe.utils

import java.text.Normalizer

object SanitizationUtils {
    private const val DEFAULT_MAX_LENGTH = 10000

    private val DANGEROUS_CHARS = setOf('<', '>', '"', '\'', '`')
    private val HTML_TAG_PATTERN = Regex("<[^>]*>")
    private val CONTROL_CHAR_PATTERN = Regex("[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F\\x7F]")
    private val EXCESSIVE_WHITESPACE_PATTERN = Regex("\\s{3,}")
    private val WINDOWS_RESERVED_NAMES = setOf(
        "CON", "PRN", "AUX", "NUL",
        "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
        "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9"
    )

    fun sanitizeUserInput(
        input: String,
        maxLength: Int = DEFAULT_MAX_LENGTH,
        removeDangerousChars: Boolean = true
    ): String {
        if (input.isEmpty()) return input

        var result = input.replace(CONTROL_CHAR_PATTERN, "")
        if (removeDangerousChars) {
            result = result.filterNot { it in DANGEROUS_CHARS }
        }
        result = result.replace(EXCESSIVE_WHITESPACE_PATTERN, "  ")
        if (result.length > maxLength) {
            result = result.take(maxLength)
        }
        return result.trim()
    }

    fun sanitizeScreenText(text: String): String {
        if (text.isEmpty()) return text

        return text
            .replace(CONTROL_CHAR_PATTERN, "")
            .replace("\u200B", "")
            .replace("\u200C", "")
            .replace("\u200D", "")
            .replace("\uFEFF", "")
            .replace(EXCESSIVE_WHITESPACE_PATTERN, " ")
            .trim()
    }

    fun stripTags(input: String): String {
        if (input.isEmpty()) return input
        return input.replace(HTML_TAG_PATTERN, "").trim()
    }

    fun escapeHtml(input: String): String {
        if (input.isEmpty()) return input

        return buildString(input.length + 16) {
            for (char in input) {
                when (char) {
                    '<' -> append("&lt;")
                    '>' -> append("&gt;")
                    '&' -> append("&amp;")
                    '"' -> append("&quot;")
                    '\'' -> append("&#39;")
                    else -> append(char)
                }
            }
        }
    }

    fun sanitizeFilename(filename: String): String {
        if (filename.isEmpty()) return "unnamed"

        val illegalChars = setOf('/', '\\', ':', '*', '?', '"', '<', '>', '|', '\u0000')
        val sanitized = filename
            .filterNot { it in illegalChars }
            .replace(Regex("\\s+"), "_")
            .trim()
            .trim('.', ' ')
            .take(255)

        if (sanitized.isEmpty() || sanitized == "." || sanitized == "..") {
            return "unnamed"
        }

        val baseName = sanitized.substringBeforeLast('.', sanitized).uppercase()
        return if (baseName in WINDOWS_RESERVED_NAMES) "_$sanitized" else sanitized
    }

    fun sanitizeJsonValue(input: String): String {
        if (input.isEmpty()) return input

        return buildString(input.length + 16) {
            for (char in input) {
                when (char) {
                    '"' -> append("\\\"")
                    '\\' -> append("\\\\")
                    '\n' -> append("\\n")
                    '\r' -> append("\\r")
                    '\t' -> append("\\t")
                    '\b' -> append("\\b")
                    '\u000C' -> append("\\f")
                    else -> {
                        if (char.code < 32) {
                            append("\\u${char.code.toString(16).padStart(4, '0')}")
                        } else {
                            append(char)
                        }
                    }
                }
            }
        }
    }

    fun sanitizeSqlIdentifier(identifier: String): String {
        if (identifier.isEmpty()) return identifier
        return identifier.filter { it.isLetterOrDigit() || it == '_' }.take(128)
    }

    fun truncateWithEllipsis(
        input: String,
        maxLength: Int,
        ellipsis: String = "..."
    ): String {
        if (input.length <= maxLength) return input
        if (maxLength <= ellipsis.length) return ellipsis.take(maxLength)
        return input.take(maxLength - ellipsis.length) + ellipsis
    }

    fun removeExcessiveRepeats(input: String, maxConsecutive: Int = 5): String {
        if (input.isEmpty() || maxConsecutive < 1) return input

        return buildString {
            var lastChar: Char? = null
            var count = 0

            for (char in input) {
                if (char == lastChar) {
                    count++
                    if (count <= maxConsecutive) {
                        append(char)
                    }
                } else {
                    lastChar = char
                    count = 1
                    append(char)
                }
            }
        }
    }

    fun normalizeUnicode(input: String): String {
        if (input.isEmpty()) return input
        return Normalizer.normalize(input, Normalizer.Form.NFKC)
            .replace('\u3000', ' ')
    }
}
