package com.example.xihe.utils

import kotlinx.coroutines.delay
import java.io.IOException
import kotlin.math.min
import kotlin.math.pow

/**
 * 🔄 重试工具类
 * 
 * 提供指数退避重试机制，用于网络请求等可能失败的操作
 */
object RetryUtils {
    
    /**
     * 重试配置
     * 
     * @param maxRetries 最大重试次数
     * @param initialDelayMs 初始延迟（毫秒）
     * @param maxDelayMs 最大延迟（毫秒）
     * @param multiplier 延迟倍数
     * @param jitterFactor 抖动因子（0-1），用于避免雷群效应
     */
    data class RetryConfig(
        val maxRetries: Int = 3,
        val initialDelayMs: Long = 100,
        val maxDelayMs: Long = 10000,
        val multiplier: Double = 2.0,
        val jitterFactor: Double = 0.1
    ) {
        init {
            require(maxRetries >= 0) { "maxRetries 必须 >= 0" }
            require(initialDelayMs > 0) { "initialDelayMs 必须 > 0" }
            require(maxDelayMs >= initialDelayMs) { "maxDelayMs 必须 >= initialDelayMs" }
            require(multiplier >= 1.0) { "multiplier 必须 >= 1.0" }
            require(jitterFactor in 0.0..1.0) { "jitterFactor 必须在 0-1 之间" }
        }
        
        companion object {
            /** 默认配置：3次重试，100ms起始延迟 */
            val DEFAULT = RetryConfig()
            
            /** 快速重试：3次重试，50ms起始延迟 */
            val FAST = RetryConfig(initialDelayMs = 50, maxDelayMs = 1000)
            
            /** 慢速重试：5次重试，500ms起始延迟 */
            val SLOW = RetryConfig(maxRetries = 5, initialDelayMs = 500, maxDelayMs = 30000)
            
            /** 无重试 */
            val NO_RETRY = RetryConfig(maxRetries = 0)
        }
    }
    
    /**
     * 重试结果
     */
    sealed class RetryResult<T> {
        /**
         * 成功结果
         */
        data class Success<T>(
            val data: T,
            val attempts: Int
        ) : RetryResult<T>()
        
        /**
         * 失败结果
         */
        data class Failure<T>(
            val exception: Exception,
            val attempts: Int,
            val retryable: Boolean,
            val allExceptions: List<Exception> = emptyList()
        ) : RetryResult<T>()
        
        /**
         * 转换为 Kotlin Result
         */
        fun toResult(): Result<T> = when (this) {
            is Success -> Result.success(data)
            is Failure -> Result.failure(exception)
        }
        
        /**
         * 获取数据或抛出异常
         */
        fun getOrThrow(): T = when (this) {
            is Success -> data
            is Failure -> throw exception
        }
        
        /**
         * 获取数据或返回默认值
         */
        fun getOrDefault(default: T): T = when (this) {
            is Success -> data
            is Failure -> default
        }
        
        /**
         * 获取数据或执行回调
         */
        inline fun getOrElse(onFailure: (Failure<T>) -> T): T = when (this) {
            is Success -> data
            is Failure -> onFailure(this)
        }
        
        /**
         * 是否成功
         */
        val isSuccess: Boolean get() = this is Success
        
        /**
         * 是否失败
         */
        val isFailure: Boolean get() = this is Failure
    }

    
    /**
     * 使用指数退避策略执行可重试操作
     * 
     * 延迟计算公式: min(initialDelay * multiplier^attempt, maxDelay) * (1 ± jitter)
     * 
     * @param config 重试配置
     * @param isRetryable 判断异常是否可重试的函数
     * @param onRetry 每次重试前的回调（可选）
     * @param block 要执行的操作
     * @return 重试结果
     */
    suspend fun <T> withRetry(
        config: RetryConfig = RetryConfig.DEFAULT,
        isRetryable: (Exception) -> Boolean = { it is IOException },
        onRetry: (suspend (attempt: Int, exception: Exception, delayMs: Long) -> Unit)? = null,
        block: suspend () -> T
    ): RetryResult<T> {
        val exceptions = mutableListOf<Exception>()
        var attempt = 0
        
        while (true) {
            attempt++
            
            try {
                val result = block()
                return RetryResult.Success(result, attempt)
            } catch (e: Exception) {
                exceptions.add(e)
                
                // 检查是否可重试
                val canRetry = isRetryable(e) && attempt <= config.maxRetries
                
                if (!canRetry) {
                    return RetryResult.Failure(
                        exception = e,
                        attempts = attempt,
                        retryable = isRetryable(e),
                        allExceptions = exceptions.toList()
                    )
                }
                
                // 计算延迟
                val delayMs = calculateDelay(attempt, config)
                
                // 回调
                onRetry?.invoke(attempt, e, delayMs)
                
                // 等待
                delay(delayMs)
            }
        }
    }
    
    /**
     * 简化版重试（返回 Result）
     */
    suspend fun <T> retry(
        maxRetries: Int = 3,
        initialDelayMs: Long = 100,
        isRetryable: (Exception) -> Boolean = { it is IOException },
        block: suspend () -> T
    ): Result<T> {
        return withRetry(
            config = RetryConfig(maxRetries = maxRetries, initialDelayMs = initialDelayMs),
            isRetryable = isRetryable,
            block = block
        ).toResult()
    }
    
    /**
     * 带日志的重试
     */
    suspend fun <T> withRetryLogging(
        tag: String,
        config: RetryConfig = RetryConfig.DEFAULT,
        isRetryable: (Exception) -> Boolean = { it is IOException },
        block: suspend () -> T
    ): RetryResult<T> {
        return withRetry(
            config = config,
            isRetryable = isRetryable,
            onRetry = { attempt, exception, delayMs ->
                LogManager.w(tag, "重试 #$attempt，延迟 ${delayMs}ms，原因: ${exception.message}")
            },
            block = block
        )
    }
    
    /**
     * 计算延迟时间
     */
    private fun calculateDelay(attempt: Int, config: RetryConfig): Long {
        // 指数退避
        val exponentialDelay = config.initialDelayMs * config.multiplier.pow(attempt - 1)
        
        // 限制最大延迟
        val cappedDelay = min(exponentialDelay, config.maxDelayMs.toDouble())
        
        // 添加抖动
        val jitter = if (config.jitterFactor > 0) {
            val jitterRange = cappedDelay * config.jitterFactor
            (Math.random() * 2 - 1) * jitterRange
        } else {
            0.0
        }
        
        return (cappedDelay + jitter).toLong().coerceAtLeast(1)
    }
    
    /**
     * 默认的可重试异常判断
     * 
     * 网络相关异常通常是可重试的
     */
    fun isNetworkException(e: Exception): Boolean {
        return e is IOException ||
               e is java.net.SocketTimeoutException ||
               e is java.net.UnknownHostException ||
               e is java.net.ConnectException ||
               e.cause?.let { isNetworkException(it as? Exception ?: return@let false) } == true
    }
    
    /**
     * 判断HTTP状态码是否可重试
     * 
     * 5xx 服务器错误和 429 限流通常是可重试的
     */
    fun isRetryableHttpCode(code: Int): Boolean {
        return code in 500..599 || code == 429
    }
}
