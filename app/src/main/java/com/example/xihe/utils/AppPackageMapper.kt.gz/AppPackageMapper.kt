package com.example.xihe.utils

/**
 * 📦 统一的应用包名映射工具
 * 
 * 集中管理应用名称到包名的映射，避免在多处维护相同的映射表
 */
object AppPackageMapper {
    
    /**
     * 应用名称到包名的映射表
     * 支持中文名、英文名、简称等多种形式
     */
    private val packageMap = mapOf(
        // 社交通讯
        "微信" to "com.tencent.mm",
        "wechat" to "com.tencent.mm",
        "qq" to "com.tencent.mobileqq",
        "钉钉" to "com.alibaba.android.rimet",
        "dingtalk" to "com.alibaba.android.rimet",
        "飞书" to "com.ss.android.lark",
        "lark" to "com.ss.android.lark",
        "telegram" to "org.telegram.messenger",
        "电报" to "org.telegram.messenger",
        "微博" to "com.sina.weibo",
        "weibo" to "com.sina.weibo",
        
        // 短视频/直播
        "抖音" to "com.ss.android.ugc.aweme",
        "douyin" to "com.ss.android.ugc.aweme",
        "快手" to "com.smile.gifmaker",
        "kuaishou" to "com.smile.gifmaker",
        "哔哩哔哩" to "tv.danmaku.bili",
        "bilibili" to "tv.danmaku.bili",
        "b站" to "tv.danmaku.bili",
        
        // 购物
        "淘宝" to "com.taobao.taobao",
        "taobao" to "com.taobao.taobao",
        "京东" to "com.jingdong.app.mall",
        "jd" to "com.jingdong.app.mall",
        "拼多多" to "com.xunmeng.pinduoduo",
        "pinduoduo" to "com.xunmeng.pinduoduo",
        "小红书" to "com.xingin.xhs",
        "xiaohongshu" to "com.xingin.xhs",
        
        // 支付/金融
        "支付宝" to "com.eg.android.AlipayGphone",
        "alipay" to "com.eg.android.AlipayGphone",
        
        // 外卖/生活
        "美团" to "com.sankuai.meituan",
        "meituan" to "com.sankuai.meituan",
        "饿了么" to "me.ele",
        "eleme" to "me.ele",
        
        // 地图/出行
        "高德地图" to "com.autonavi.minimap",
        "高德" to "com.autonavi.minimap",
        "amap" to "com.autonavi.minimap",
        "百度地图" to "com.baidu.BaiduMap",
        "滴滴" to "com.sdu.didi.psnger",
        "didi" to "com.sdu.didi.psnger",
        
        // 音乐
        "网易云音乐" to "com.netease.cloudmusic",
        "网易云" to "com.netease.cloudmusic",
        "cloudmusic" to "com.netease.cloudmusic",
        "qq音乐" to "com.tencent.qqmusic",
        "qqmusic" to "com.tencent.qqmusic",
        "酷狗音乐" to "com.kugou.android",
        "kugou" to "com.kugou.android",
        
        // 知识/阅读
        "知乎" to "com.zhihu.android",
        "zhihu" to "com.zhihu.android",
        
        // 浏览器
        "chrome" to "com.android.chrome",
        "浏览器" to "com.android.browser",
        
        // 系统应用
        "相机" to "com.android.camera",
        "camera" to "com.android.camera",
        "相册" to "com.android.gallery",
        "gallery" to "com.android.gallery",
        "设置" to "com.android.settings",
        "settings" to "com.android.settings",
        "日历" to "com.android.calendar",
        "calendar" to "com.android.calendar",
        "时钟" to "com.android.deskclock",
        "clock" to "com.android.deskclock",
        "计算器" to "com.android.calculator2",
        "calculator" to "com.android.calculator2",
        "通讯录" to "com.android.contacts",
        "contacts" to "com.android.contacts",
        "短信" to "com.android.mms",
        "sms" to "com.android.mms",
        "电话" to "com.android.dialer",
        "phone" to "com.android.dialer"
    )
    
    /**
     * 根据应用名称获取包名
     * 
     * @param appName 应用名称（支持中文、英文、简称）
     * @return 包名，如果未找到则返回 null
     */
    fun getPackageName(appName: String): String? {
        val normalizedName = appName.lowercase().trim()
        return packageMap[normalizedName] ?: packageMap[appName]
    }
    
    /**
     * 根据应用名称获取包名，如果未找到则返回原始输入
     * 
     * @param appName 应用名称
     * @return 包名或原始输入
     */
    fun getPackageNameOrDefault(appName: String): String {
        return getPackageName(appName) ?: appName
    }
    
    /**
     * 检查是否是已知的应用名称
     */
    fun isKnownApp(appName: String): Boolean {
        val normalizedName = appName.lowercase().trim()
        return packageMap.containsKey(normalizedName) || packageMap.containsKey(appName)
    }
    
    /**
     * 获取所有支持的应用名称列表
     */
    fun getSupportedAppNames(): List<String> {
        return packageMap.keys.toList()
    }
    
    /**
     * 根据包名反查应用名称
     * 
     * @param packageName 包名
     * @return 应用名称（优先返回中文名），如果未找到则返回 null
     */
    fun getAppName(packageName: String): String? {
        // 优先返回中文名
        val chineseNames = packageMap.entries
            .filter { it.value == packageName && !it.key.matches(Regex("[a-zA-Z]+")) }
            .map { it.key }
        
        if (chineseNames.isNotEmpty()) {
            return chineseNames.first()
        }
        
        // 如果没有中文名，返回任意匹配的名称
        return packageMap.entries.firstOrNull { it.value == packageName }?.key
    }
    
    /**
     * 模糊匹配应用名称
     * 
     * @param query 查询字符串
     * @return 匹配的应用名称和包名列表
     */
    fun fuzzyMatch(query: String): List<Pair<String, String>> {
        val normalizedQuery = query.lowercase().trim()
        return packageMap.entries
            .filter { it.key.contains(normalizedQuery) || normalizedQuery.contains(it.key) }
            .map { it.key to it.value }
            .distinctBy { it.second } // 去重（同一个包名可能有多个别名）
    }
}
