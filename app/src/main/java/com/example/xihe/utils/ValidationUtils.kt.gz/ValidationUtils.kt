package com.example.xihe.utils

import java.net.URI

object ValidationUtils {
    data class ValidationResult(
        val isValid: Boolean,
        val errors: List<String> = emptyList()
    ) {
        companion object {
            fun success() = ValidationResult(true)
            fun failure(vararg errors: String) = ValidationResult(false, errors.toList())
            fun failure(errors: List<String>) = ValidationResult(false, errors)
        }

        fun throwIfInvalid() {
            if (!isValid) {
                throw IllegalArgumentException(errors.joinToString("; "))
            }
        }
    }

    data class ValidationError(
        val field: String,
        val message: String,
        val value: Any? = null
    ) {
        override fun toString(): String = "$field: $message"
    }

    fun validateApiConfig(
        baseUrl: String,
        apiKey: String,
        modelName: String
    ): ValidationResult {
        val errors = mutableListOf<String>()

        if (baseUrl.isBlank()) {
            errors.add("baseUrl: cannot be blank")
        } else if (!isValidUrl(baseUrl)) {
            errors.add("baseUrl: must be a valid http or https URL")
        }

        if (apiKey.isBlank() && !isLocalUrl(baseUrl)) {
            errors.add("apiKey: cannot be blank")
        }

        if (modelName.isBlank()) {
            errors.add("modelName: cannot be blank")
        }

        return if (errors.isEmpty()) ValidationResult.success() else ValidationResult.failure(errors)
    }

    fun isValidUrl(url: String): Boolean {
        if (url.isBlank()) return false

        val uri = try {
            URI(url.trim())
        } catch (e: Exception) {
            return false
        }

        val scheme = uri.scheme?.lowercase() ?: return false
        if (scheme != "http" && scheme != "https") {
            return false
        }

        val host = uri.host?.trim()?.trimEnd('.') ?: return false
        if (host.isBlank()) {
            return false
        }

        return uri.userInfo.isNullOrBlank()
    }

    fun isLocalUrl(url: String): Boolean {
        val host = try {
            URI(url.trim()).host?.lowercase()
        } catch (e: Exception) {
            null
        } ?: return false

        return host == "localhost" ||
            host == "127.0.0.1" ||
            host == "0.0.0.0" ||
            host == "::1"
    }

    fun requireNotBlank(value: String, fieldName: String): String {
        if (value.isBlank()) {
            throw IllegalArgumentException("$fieldName: cannot be blank")
        }
        return value
    }

    fun validateNotBlank(value: String, fieldName: String): ValidationResult {
        return if (value.isBlank()) {
            ValidationResult.failure("$fieldName: cannot be blank")
        } else {
            ValidationResult.success()
        }
    }

    fun validateLength(
        value: String,
        fieldName: String,
        minLength: Int = 0,
        maxLength: Int = Int.MAX_VALUE
    ): ValidationResult {
        return when {
            value.length < minLength -> ValidationResult.failure("$fieldName: length must be at least $minLength")
            value.length > maxLength -> ValidationResult.failure("$fieldName: length must be at most $maxLength")
            else -> ValidationResult.success()
        }
    }

    fun validateRange(
        value: Int,
        fieldName: String,
        min: Int = Int.MIN_VALUE,
        max: Int = Int.MAX_VALUE
    ): ValidationResult {
        return when {
            value < min -> ValidationResult.failure("$fieldName: must be >= $min")
            value > max -> ValidationResult.failure("$fieldName: must be <= $max")
            else -> ValidationResult.success()
        }
    }

    fun validateRange(
        value: Long,
        fieldName: String,
        min: Long = Long.MIN_VALUE,
        max: Long = Long.MAX_VALUE
    ): ValidationResult {
        return when {
            value < min -> ValidationResult.failure("$fieldName: must be >= $min")
            value > max -> ValidationResult.failure("$fieldName: must be <= $max")
            else -> ValidationResult.success()
        }
    }

    fun validatePattern(
        value: String,
        fieldName: String,
        pattern: Regex,
        errorMessage: String? = null
    ): ValidationResult {
        return if (pattern.matches(value)) {
            ValidationResult.success()
        } else {
            ValidationResult.failure(errorMessage ?: "$fieldName: invalid format")
        }
    }

    fun combine(vararg results: ValidationResult): ValidationResult {
        val allErrors = results.flatMap { it.errors }
        return if (allErrors.isEmpty()) ValidationResult.success() else ValidationResult.failure(allErrors)
    }

    fun validateEmail(email: String, fieldName: String = "email"): ValidationResult {
        val emailPattern = Regex("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")
        return validatePattern(email, fieldName, emailPattern, "$fieldName: invalid email format")
    }

    fun validatePhoneNumber(phone: String, fieldName: String = "phone"): ValidationResult {
        val phonePattern = Regex("^1[3-9]\\d{9}$")
        return validatePattern(phone, fieldName, phonePattern, "$fieldName: invalid phone number format")
    }
}
