package com.example.xihe.utils

import kotlinx.coroutines.*
import kotlin.coroutines.CoroutineContext
import kotlin.coroutines.EmptyCoroutineContext

/**
 * 🔄 协程工具类
 * 
 * 提供安全的协程操作，替代 runBlocking 和 Thread.sleep
 */
object CoroutineUtils {
    
    /**
     * 🔧 创建带有异常处理的协程作用域
     */
    fun createSafeScope(
        dispatcher: CoroutineDispatcher = Dispatchers.Default,
        exceptionHandler: ((Throwable) -> Unit)? = null
    ): CoroutineScope {
        val handler = CoroutineExceptionHandler { _, throwable ->
            LogManager.e("CoroutineUtils", "协程异常: ${throwable.message}", throwable)
            exceptionHandler?.invoke(throwable)
        }
        return CoroutineScope(SupervisorJob() + dispatcher + handler)
    }
    
    /**
     * 🚀 安全启动协程（带异常捕获）
     */
    fun CoroutineScope.launchSafe(
        context: CoroutineContext = EmptyCoroutineContext,
        start: CoroutineStart = CoroutineStart.DEFAULT,
        onError: ((Throwable) -> Unit)? = null,
        block: suspend CoroutineScope.() -> Unit
    ): Job {
        return launch(context, start) {
            try {
                block()
            } catch (e: CancellationException) {
                throw e // 不捕获取消异常
            } catch (e: Exception) {
                LogManager.e("CoroutineUtils", "协程执行异常: ${e.message}", e)
                onError?.invoke(e)
            }
        }
    }
    
    /**
     * ⏱️ 安全的非阻塞延迟（替代 Thread.sleep）
     */
    suspend fun safeSleep(millis: Long) {
        delay(millis)
    }
    
    /**
     * 🔄 带超时的操作
     */
    suspend fun <T> withTimeoutSafe(
        timeMillis: Long,
        defaultValue: T,
        block: suspend () -> T
    ): T {
        return try {
            withTimeout(timeMillis) {
                block()
            }
        } catch (e: TimeoutCancellationException) {
            LogManager.w("CoroutineUtils", "操作超时: ${timeMillis}ms")
            defaultValue
        }
    }
    
    /**
     * 🔄 带重试的操作
     */
    suspend fun <T> withRetry(
        times: Int = 3,
        initialDelay: Long = 100,
        maxDelay: Long = 1000,
        factor: Double = 2.0,
        block: suspend () -> T
    ): T {
        var currentDelay = initialDelay
        repeat(times - 1) { attempt ->
            try {
                return block()
            } catch (e: Exception) {
                LogManager.w("CoroutineUtils", "重试 ${attempt + 1}/$times: ${e.message}")
            }
            delay(currentDelay)
            currentDelay = (currentDelay * factor).toLong().coerceAtMost(maxDelay)
        }
        return block() // 最后一次尝试
    }
    
    /**
     * 🔄 在IO线程执行
     */
    suspend fun <T> onIO(block: suspend CoroutineScope.() -> T): T {
        return withContext(Dispatchers.IO, block)
    }
    
    /**
     * 🔄 在主线程执行
     */
    suspend fun <T> onMain(block: suspend CoroutineScope.() -> T): T {
        return withContext(Dispatchers.Main, block)
    }
    
    /**
     * 🔄 在计算线程执行
     */
    suspend fun <T> onDefault(block: suspend CoroutineScope.() -> T): T {
        return withContext(Dispatchers.Default, block)
    }
}

/**
 * 🔧 扩展函数
 */
suspend fun <T> retryWithDelay(
    times: Int = 3,
    delay: Long = 1000,
    block: suspend () -> T
): T = CoroutineUtils.withRetry(times, delay, block = block)
