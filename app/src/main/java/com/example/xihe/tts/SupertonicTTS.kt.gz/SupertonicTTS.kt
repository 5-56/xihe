package com.example.xihe.tts

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.example.xihe.utils.LogManager
import ai.onnxruntime.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * 🎤 Supertonic TTS - 超快速本地语音合成
 * 基于ONNX Runtime实现
 * 
 * 特点：
 * - ⚡ 167x实时速度
 * - 🪶 66M参数，超轻量
 * - 🔒 完全离线，零隐私顾虑
 * - 🎨 支持4种语音风格
 */
class SupertonicTTS(private val context: Context) {
    
    private val TAG = "SupertonicTTS"
    
    // ONNX环境和会话
    private val ortEnvironment = OrtEnvironment.getEnvironment()
    private var textEncoderSession: OrtSession? = null
    private var durationPredictorSession: OrtSession? = null
    private var vectorEstimatorSession: OrtSession? = null
    private var vocoderSession: OrtSession? = null
    
    // 初始化状态
    private var isInitialized = false
    
    // 音频播放器
    private var audioTrack: AudioTrack? = null
    
    /**
     * 初始化TTS引擎
     * 优先使用本地ONNX模型，只有真正失败时才回退到系统TTS
     */
    suspend fun initialize(): Boolean = withContext(Dispatchers.IO) {
        try {
            if (isInitialized) {
                LogManager.d(TAG, "✅ Supertonic TTS已经初始化")
                return@withContext true
            }
            
            LogManager.d(TAG, "🚀 开始初始化Supertonic TTS（本地模型优先）...")
            
            // 显示内存状态（仅供参考，不作为限制条件）
            val runtime = Runtime.getRuntime()
            val maxMemory = runtime.maxMemory() / 1024 / 1024 // MB
            val usedMemory = (runtime.totalMemory() - runtime.freeMemory()) / 1024 / 1024
            val freeMemory = maxMemory - usedMemory
            
            LogManager.d(TAG, "📊 内存状态: 最大=${maxMemory}MB, 已用=${usedMemory}MB, 可用=${freeMemory}MB")
            
            // 检查模型文件是否存在
            val modelFiles = listOf(
                "model/onnx/text_encoder.onnx",
                "model/onnx/duration_predictor.onnx",
                "model/onnx/vector_estimator.onnx",
                "model/onnx/vocoder.onnx"
            )
            
            for (modelFile in modelFiles) {
                try {
                    context.assets.open(modelFile).close()
                } catch (e: Exception) {
                    LogManager.e(TAG, "❌ 模型文件不存在: $modelFile", e)
                    LogManager.e(TAG, "💡 请将model文件夹中的ONNX模型复制到app/src/main/assets/目录")
                    return@withContext false
                }
            }
            
            LogManager.d(TAG, "✅ 模型文件检查通过，开始加载模型...")
            
            // 🚀 实际加载模型
            try {
                LogManager.d(TAG, "📦 加载 text_encoder.onnx...")
                textEncoderSession = loadModel("model/onnx/text_encoder.onnx")
                
                LogManager.d(TAG, "📦 加载 duration_predictor.onnx...")
                durationPredictorSession = loadModel("model/onnx/duration_predictor.onnx")
                
                // 🔍 验证模型输入格式
                val dpInputNames = durationPredictorSession?.inputNames ?: emptySet()
                LogManager.d(TAG, "📋 duration_predictor 输入参数: $dpInputNames")
                
                if (!dpInputNames.contains("text") && dpInputNames.contains("text_ids")) {
                    LogManager.w(TAG, "⚠️ 模型输入格式不兼容 (期望: text, 实际: $dpInputNames)")
                    LogManager.w(TAG, "💡 当前 Supertonic TTS 模型需要特殊处理，暂时禁用")
                    releaseModels()
                    return@withContext false
                }
                
                LogManager.d(TAG, "📦 加载 vector_estimator.onnx...")
                vectorEstimatorSession = loadModel("model/onnx/vector_estimator.onnx")
                
                LogManager.d(TAG, "📦 加载 vocoder.onnx...")
                vocoderSession = loadModel("model/onnx/vocoder.onnx")
                
                isInitialized = true
                LogManager.d(TAG, "🎉 Supertonic TTS 本地模型加载成功！")
                true
            } catch (e: OutOfMemoryError) {
                LogManager.e(TAG, "❌ 内存不足，模型加载失败", e)
                LogManager.w(TAG, "💡 将回退到系统TTS")
                releaseModels()
                false
            }
        } catch (e: OutOfMemoryError) {
            LogManager.e(TAG, "❌ 内存溢出！", e)
            LogManager.w(TAG, "💡 自动回退到系统TTS")
            releaseModels()
            false
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ Supertonic TTS初始化失败", e)
            releaseModels()
            false
        }
    }
    
    /**
     * 🧹 释放已加载的模型（用于OOM恢复）
     */
    private fun releaseModels() {
        try {
            textEncoderSession?.close()
            durationPredictorSession?.close()
            vectorEstimatorSession?.close()
            vocoderSession?.close()
        } catch (e: Exception) {
            LogManager.w(TAG, "释放模型时出错", e)
        }
        textEncoderSession = null
        durationPredictorSession = null
        vectorEstimatorSession = null
        vocoderSession = null
        isInitialized = false
    }
    
    /**
     * 加载ONNX模型
     * 优化：先复制到内部存储，然后使用文件路径加载，避免OOM
     * ONNX Runtime 使用内存映射加载文件，不会占用 Java heap
     */
    private fun loadModel(assetPath: String): OrtSession {
        // 获取模型文件名
        val fileName = assetPath.substringAfterLast("/")
        val modelFile = java.io.File(context.filesDir, "tts_models/$fileName")
        
        // 如果文件不存在，从 assets 复制
        if (!modelFile.exists()) {
            LogManager.d(TAG, "📂 复制模型到内部存储: $fileName")
            modelFile.parentFile?.mkdirs()
            
            context.assets.open(assetPath).use { input ->
                modelFile.outputStream().use { output ->
                    val buffer = ByteArray(8192)
                    var read: Int
                    while (input.read(buffer).also { read = it } != -1) {
                        output.write(buffer, 0, read)
                    }
                }
            }
            LogManager.d(TAG, "✅ 模型复制完成: ${modelFile.length() / 1024 / 1024}MB")
        }
        
        // 使用文件路径加载，ONNX Runtime 会使用内存映射，大幅减少内存占用
        val sessionOptions = OrtSession.SessionOptions().apply {
            // 使用较少的线程以减少内存
            setIntraOpNumThreads(2)
            // 启用内存优化
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.BASIC_OPT)
        }
        
        return ortEnvironment.createSession(modelFile.absolutePath, sessionOptions)
    }
    
    /**
     * 文字转语音
     * @param text 要合成的文字
     * @param voiceStyle 语音风格 ("F1", "F2", "M1", "M2")
     * @param speed 语速 (0.5 - 2.0)
     * @return 是否成功
     */
    suspend fun speak(
        text: String,
        voiceStyle: String = "F1",
        speed: Float = 1.0f
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            if (!isInitialized) {
                LogManager.e(TAG, "❌ TTS未初始化，请先调用initialize()")
                return@withContext false
            }
            
            if (text.isEmpty()) {
                LogManager.w(TAG, "⚠️ 文本为空，跳过合成")
                return@withContext false
            }
            
            LogManager.d(TAG, "🎵 开始合成语音: \"$text\" (风格: $voiceStyle, 速度: $speed)")
            
            // 1. 文本预处理
            val processedText = preprocessText(text)
            if (processedText.isEmpty()) {
                LogManager.w(TAG, "⚠️ 文本预处理后为空")
                return@withContext false
            }
            
            // 2. 文本编码
            val textEncoding = encodeText(processedText)
            if (textEncoding == null) {
                LogManager.e(TAG, "❌ 文本编码失败")
                return@withContext false
            }
            
            // 3. 时长预测
            val duration = predictDuration(textEncoding)
            if (duration == null) {
                LogManager.e(TAG, "❌ 时长预测失败")
                return@withContext false
            }
            
            // 4. 向量估计
            val latentVector = estimateVector(textEncoding, duration, voiceStyle)
            if (latentVector == null) {
                LogManager.e(TAG, "❌ 向量估计失败")
                return@withContext false
            }
            
            // 5. 声码器合成
            val audioData = synthesizeAudio(latentVector, speed)
            if (audioData == null) {
                LogManager.e(TAG, "❌ 音频合成失败")
                return@withContext false
            }
            
            // 6. 播放音频
            playAudio(audioData)
            
            LogManager.d(TAG, "✅ 语音合成并播放成功")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 语音合成失败", e)
            false
        }
    }
    
    /**
     * 文字转语音（返回音频数据）
     * @param text 要合成的文字
     * @param voiceStyle 语音风格
     * @param speed 语速
     * @return WAV音频数据
     */
    suspend fun synthesize(
        text: String,
        voiceStyle: String = "F1",
        speed: Float = 1.0f
    ): ByteArray? = withContext(Dispatchers.IO) {
        try {
            if (!isInitialized) {
                LogManager.e(TAG, "❌ TTS未初始化")
                return@withContext null
            }
            
            LogManager.d(TAG, "🎵 合成语音数据: \"$text\"")
            
            // 执行完整的TTS流程
            val processedText = preprocessText(text)
            val textEncoding = encodeText(processedText) ?: return@withContext null
            val duration = predictDuration(textEncoding) ?: return@withContext null
            val latentVector = estimateVector(textEncoding, duration, voiceStyle) ?: return@withContext null
            val audioData = synthesizeAudio(latentVector, speed)
            
            audioData
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 音频合成失败", e)
            null
        }
    }
    
    /**
     * 播放音频数据（非阻塞，使用协程）
     */
    private suspend fun playAudio(audioData: ByteArray) {
        try {
            LogManager.d(TAG, "🔊 开始播放音频，数据大小: ${audioData.size} bytes")
            
            val sampleRate = 22050 // Supertonic默认采样率
            val channelConfig = AudioFormat.CHANNEL_OUT_MONO
            val audioFormat = AudioFormat.ENCODING_PCM_16BIT
            
            val bufferSize = AudioTrack.getMinBufferSize(sampleRate, channelConfig, audioFormat)
            LogManager.d(TAG, "🔊 AudioTrack bufferSize: $bufferSize")
            
            if (bufferSize <= 0) {
                LogManager.e(TAG, "❌ AudioTrack bufferSize 无效: $bufferSize")
                return
            }
            
            audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(sampleRate)
                        .setChannelMask(channelConfig)
                        .setEncoding(audioFormat)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(bufferSize, audioData.size))
                .build()
            
            LogManager.d(TAG, "🔊 AudioTrack 创建成功，状态: ${audioTrack?.state}")
            
            audioTrack?.play()
            val written = audioTrack?.write(audioData, 0, audioData.size) ?: 0
            LogManager.d(TAG, "🔊 已写入音频数据: $written bytes")
            
            // 使用协程 delay 替代 Thread.sleep（非阻塞）
            val durationMs = (audioData.size.toLong() * 1000) / (sampleRate * 2) // 16bit = 2 bytes
            kotlinx.coroutines.delay(durationMs + 100)
            
            audioTrack?.stop()
            audioTrack?.release()
            audioTrack = null
            
            LogManager.d(TAG, "✅ 音频播放完成")
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 音频播放失败: ${e.message}", e)
        }
    }
    
    /**
     * 停止播放
     */
    fun stop() {
        audioTrack?.stop()
        audioTrack?.release()
        audioTrack = null
    }
    
    // ==================== TTS推理辅助方法 ====================
    
    /**
     * 文本预处理
     */
    private fun preprocessText(text: String): String {
        // 1. 移除emoji和特殊字符
        var processed = text.replace(Regex("[\uD83C-\uDBFF\uDC00-\uDFFF]+"), "")
        
        // 2. 规范化空白
        processed = processed.replace(Regex("\\s+"), " ").trim()
        
        // 3. 限制长度（避免过长）
        if (processed.length > 500) {
            processed = processed.substring(0, 500)
            LogManager.w(TAG, "⚠️ 文本过长，截断到500字符")
        }
        
        return processed
    }
    
    /**
     * 文本编码
     */
    private fun encodeText(text: String): OnnxTensor? {
        return try {
            // 将文本转换为Unicode编码
            val unicodeArray = text.map { it.code.toLong() }.toLongArray()
            
            // 创建ONNX输入tensor
            val shape = longArrayOf(1, unicodeArray.size.toLong())
            OnnxTensor.createTensor(ortEnvironment, 
                java.nio.LongBuffer.wrap(unicodeArray), shape)
        } catch (e: Exception) {
            LogManager.e(TAG, "文本编码失败", e)
            null
        }
    }
    
    /**
     * 时长预测
     */
    private fun predictDuration(textEncoding: OnnxTensor): OnnxTensor? {
        return try {
            val inputs = mapOf("text" to textEncoding)
            val results = durationPredictorSession?.run(inputs)
            results?.get(0)?.value as? OnnxTensor
        } catch (e: Exception) {
            LogManager.e(TAG, "时长预测失败", e)
            null
        }
    }
    
    /**
     * 向量估计
     */
    private fun estimateVector(
        textEncoding: OnnxTensor,
        duration: OnnxTensor,
        voiceStyle: String
    ): OnnxTensor? {
        return try {
            // 加载语音风格数据
            val styleData = loadVoiceStyle(voiceStyle)
            
            val inputs = mapOf(
                "text" to textEncoding,
                "duration" to duration,
                "style" to styleData
            )
            
            val results = vectorEstimatorSession?.run(inputs)
            results?.get(0)?.value as? OnnxTensor
        } catch (e: Exception) {
            LogManager.e(TAG, "向量估计失败", e)
            null
        }
    }
    
    /**
     * 声码器合成
     */
    private fun synthesizeAudio(
        latentVector: OnnxTensor,
        speed: Float
    ): ByteArray? {
        return try {
            val inputs = mapOf(
                "latent" to latentVector,
                "speed" to createSpeedTensor(speed)
            )
            
            val results = vocoderSession?.run(inputs)
            val audioTensor = results?.get(0)?.value as? OnnxTensor
            
            // 转换为PCM数据
            audioTensor?.let { convertTensorToAudio(it) }
        } catch (e: Exception) {
            LogManager.e(TAG, "声码器合成失败", e)
            null
        }
    }
    
    /**
     * 加载语音风格
     */
    private fun loadVoiceStyle(style: String): OnnxTensor {
        // 简化实现：创建默认风格向量
        val styleVector = FloatArray(256) { 0.0f }
        val shape = longArrayOf(1, 256)
        return OnnxTensor.createTensor(ortEnvironment,
            java.nio.FloatBuffer.wrap(styleVector), shape)
    }
    
    /**
     * 创建速度tensor
     */
    private fun createSpeedTensor(speed: Float): OnnxTensor {
        val speedArray = floatArrayOf(speed)
        val shape = longArrayOf(1)
        return OnnxTensor.createTensor(ortEnvironment,
            java.nio.FloatBuffer.wrap(speedArray), shape)
    }
    
    /**
     * 转换tensor为音频数据
     */
    private fun convertTensorToAudio(tensor: OnnxTensor): ByteArray {
        val floatBuffer = tensor.floatBuffer
        val audioData = ByteArray(floatBuffer.remaining() * 2)
        
        var index = 0
        while (floatBuffer.hasRemaining()) {
            val sample = (floatBuffer.get() * 32767).toInt().coerceIn(-32768, 32767)
            audioData[index++] = (sample and 0xFF).toByte()
            audioData[index++] = ((sample shr 8) and 0xFF).toByte()
        }
        
        return audioData
    }
    
    /**
     * 释放资源
     */
    fun release() {
        stop()
        
        textEncoderSession?.close()
        durationPredictorSession?.close()
        vectorEstimatorSession?.close()
        vocoderSession?.close()
        
        textEncoderSession = null
        durationPredictorSession = null
        vectorEstimatorSession = null
        vocoderSession = null
        
        isInitialized = false
        LogManager.d(TAG, "🔒 Supertonic TTS资源已释放")
    }
    
    /**
     * 检查是否已初始化
     */
    fun isReady(): Boolean = isInitialized
}
