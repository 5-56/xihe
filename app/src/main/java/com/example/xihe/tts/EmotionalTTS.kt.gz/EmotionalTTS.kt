package com.example.xihe.tts

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.xihe.utils.LogManager
import com.example.xihe.intelligence.EmotionRecognizer
import com.example.xihe.intelligence.Emotion
import java.util.*

/**
 * 🎤 情绪化语音合成
 * 根据用户情绪调整TTS参数，让语音更有感情
 */
class EmotionalTTS(
    private val context: Context,
    private val emotionRecognizer: EmotionRecognizer
) {
    
    companion object {
        private const val TAG = "EmotionalTTS"
    }
    
    private var tts: TextToSpeech? = null
    private var isInitialized = false
    
    // TTS回调
    private var onStart: (() -> Unit)? = null
    private var onDone: (() -> Unit)? = null
    private var onError: (() -> Unit)? = null
    
    /**
     * 🚀 初始化
     */
    fun initialize(
        onInitialized: ((Boolean) -> Unit)? = null
    ) {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.CHINA
                isInitialized = true
                LogManager.i(TAG, "✅ 情绪化TTS初始化成功")
                onInitialized?.invoke(true)
                
                // 设置监听器
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        onStart?.invoke()
                    }
                    
                    override fun onDone(utteranceId: String?) {
                        onDone?.invoke()
                    }
                    
                    override fun onError(utteranceId: String?) {
                        onError?.invoke()
                    }
                })
            } else {
                LogManager.e(TAG, "❌ TTS初始化失败")
                onInitialized?.invoke(false)
            }
        }
    }
    
    /**
     * 🎭 根据情绪播报
     */
    fun speak(
        text: String,
        emotion: Emotion? = null,
        onStartCallback: (() -> Unit)? = null,
        onDoneCallback: (() -> Unit)? = null
    ) {
        if (!isInitialized) {
            LogManager.w(TAG, "⚠️ TTS未初始化")
            return
        }
        
        this.onStart = onStartCallback
        this.onDone = onDoneCallback
        
        // 获取当前情绪（如果没有指定）
        val currentEmotion = emotion ?: emotionRecognizer.currentEmotion.value.emotion
        
        // 根据情绪调整TTS参数
        val params = getEmotionalParams(currentEmotion)
        
        // 应用参数
        tts?.setPitch(params.pitch)
        tts?.setSpeechRate(params.speed)
        
        LogManager.d(TAG, "🎭 情绪化播报: $currentEmotion - 音高:${params.pitch} 语速:${params.speed}")
        LogManager.d(TAG, "📢 内容: $text")
        
        // 播报
        val bundle = android.os.Bundle()
        bundle.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, params.volume)
        
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, bundle, UUID.randomUUID().toString())
    }
    
    /**
     * 🎯 获取情绪化参数
     */
    private fun getEmotionalParams(emotion: Emotion): TTSParams {
        return when (emotion) {
            Emotion.HAPPY -> TTSParams(
                pitch = 1.15f,      // 音高提高15%
                speed = 1.1f,       // 语速加快10%
                volume = 0.9f,      // 音量正常偏高
                description = "轻快活泼"
            )
            
            Emotion.EXCITED -> TTSParams(
                pitch = 1.25f,      // 音高提高25%
                speed = 1.15f,      // 语速加快15%
                volume = 1.0f,      // 音量最大
                description = "兴奋激动"
            )
            
            Emotion.SAD -> TTSParams(
                pitch = 0.85f,      // 音高降低15%
                speed = 0.9f,       // 语速放慢10%
                volume = 0.7f,      // 音量降低
                description = "低沉温柔"
            )
            
            Emotion.ANXIOUS, Emotion.STRESSED -> TTSParams(
                pitch = 1.05f,      // 音高略微提高
                speed = 0.95f,      // 语速略微放慢
                volume = 0.75f,     // 音量降低
                description = "舒缓平和"
            )
            
            Emotion.TIRED -> TTSParams(
                pitch = 0.9f,       // 音高降低10%
                speed = 0.9f,       // 语速放慢10%
                volume = 0.75f,     // 音量降低
                description = "温柔轻声"
            )
            
            Emotion.ANGRY -> TTSParams(
                pitch = 0.95f,      // 音高略微降低
                speed = 1.0f,       // 语速正常
                volume = 0.8f,      // 音量适中
                description = "平和冷静"
            )
            
            Emotion.ANNOYED -> TTSParams(
                pitch = 1.0f,       // 音高正常
                speed = 1.05f,      // 语速略快
                volume = 0.85f,     // 音量适中
                description = "自然平稳"
            )
            
            Emotion.CALM -> TTSParams(
                pitch = 1.0f,       // 音高正常
                speed = 0.95f,      // 语速略慢
                volume = 0.8f,      // 音量适中
                description = "平静舒缓"
            )
            
            Emotion.NEUTRAL -> TTSParams(
                pitch = 1.0f,       // 音高正常
                speed = 1.0f,       // 语速正常
                volume = 0.85f,     // 音量正常
                description = "自然亲切"
            )
        }
    }
    
    /**
     * 🎵 预设情绪播报示例
     */
    fun speakWithPreset(preset: EmotionalPreset) {
        val (text, emotion) = when (preset) {
            EmotionalPreset.HAPPY_GREETING -> 
                "太好了！主人真棒！" to Emotion.HAPPY
            
            EmotionalPreset.SAD_COMFORT -> 
                "别难过...一切都会好起来的" to Emotion.SAD
            
            EmotionalPreset.EXCITED_CELEBRATION -> 
                "哇！太棒啦！" to Emotion.EXCITED
            
            EmotionalPreset.CALM_REMINDER -> 
                "主人，温馨提醒一下..." to Emotion.CALM
            
            EmotionalPreset.TIRED_CONCERN -> 
                "主人，看起来有点累了呢..." to Emotion.TIRED
            
            EmotionalPreset.STRESS_RELIEF -> 
                "深呼吸，放松一下..." to Emotion.CALM
        }
        
        speak(text, emotion)
    }
    
    /**
     * 🎤 设置回调
     */
    fun setCallbacks(
        onStart: (() -> Unit)? = null,
        onDone: (() -> Unit)? = null,
        onError: (() -> Unit)? = null
    ) {
        this.onStart = onStart
        this.onDone = onDone
        this.onError = onError
    }
    
    /**
     * 🛑 停止播报
     */
    fun stop() {
        tts?.stop()
    }
    
    /**
     * 🔇 检查是否正在播报
     */
    fun isSpeaking(): Boolean {
        return tts?.isSpeaking ?: false
    }
    
    /**
     * 🗑️ 释放资源
     */
    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        isInitialized = false
        LogManager.d(TAG, "🗑️ 情绪化TTS已释放")
    }
}

/**
 * 🎯 TTS参数
 */
data class TTSParams(
    val pitch: Float,           // 音高 (0.5-2.0, 1.0为正常)
    val speed: Float,           // 语速 (0.5-2.0, 1.0为正常)
    val volume: Float,          // 音量 (0.0-1.0)
    val description: String     // 描述
)

/**
 * 🎭 情绪预设
 */
enum class EmotionalPreset {
    HAPPY_GREETING,         // 开心问候
    SAD_COMFORT,            // 悲伤安慰
    EXCITED_CELEBRATION,    // 兴奋庆祝
    CALM_REMINDER,          // 平静提醒
    TIRED_CONCERN,          // 疲惫关心
    STRESS_RELIEF          // 压力舒缓
}

/**
 * 🎨 情绪化文本生成器
 */
object EmotionalTextGenerator {
    
    /**
     * 根据情绪生成问候语
     */
    fun generateGreeting(emotion: Emotion): String {
        return when (emotion) {
            Emotion.HAPPY -> 
                listOf("主人，心情不错呀！", "主人看起来很开心呢~", "嘿嘿，主人今天好开心！").random()
            
            Emotion.SAD -> 
                listOf("主人，不开心了吗？", "主人，怎么了呢？", "主人，需要陪你聊聊吗？").random()
            
            Emotion.TIRED -> 
                listOf("主人，看起来有点累呢...", "主人，要不要休息一下？", "主人，辛苦了").random()
            
            Emotion.STRESSED -> 
                listOf("主人，感觉压力有点大？", "主人，放松一下吧", "主人，深呼吸~").random()
            
            else -> 
                listOf("主人，我在呢~", "主人好！", "主人，有什么可以帮你的吗？").random()
        }
    }
    
    /**
     * 根据情绪生成回应
     */
    fun generateResponse(emotion: Emotion, context: String): String {
        return when (emotion) {
            Emotion.HAPPY -> when (context) {
                "success" -> listOf("太棒了！", "真厉害！", "做得好！").random()
                "thanks" -> listOf("不客气呀~", "能帮到你真好！", "这是我应该做的！").random()
                else -> "好的！"
            }
            
            Emotion.SAD -> when (context) {
                "comfort" -> listOf("别难过...", "一切都会好起来的", "我陪着你呢").random()
                "encourage" -> listOf("主人加油！", "相信自己！", "你一定可以的！").random()
                else -> "嗯..."
            }
            
            Emotion.TIRED -> when (context) {
                "rest" -> listOf("好好休息吧", "早点睡哦", "不要太累了").random()
                "concern" -> listOf("要注意身体呀", "劳逸结合", "健康最重要").random()
                else -> "好..."
            }
            
            else -> "好的！"
        }
    }
    
    /**
     * 添加情绪化修饰词
     */
    fun addEmotionalModifier(text: String, emotion: Emotion): String {
        val prefix = when (emotion) {
            Emotion.HAPPY -> listOf("", "嘿嘿，", "太好了！", "").random()
            Emotion.SAD -> listOf("唉，", "", "哎...").random()
            Emotion.EXCITED -> listOf("哇！", "太棒了！", "").random()
            Emotion.TIRED -> listOf("", "嗯...", "").random()
            else -> ""
        }
        
        val suffix = when (emotion) {
            Emotion.HAPPY -> listOf("~", "！", "😊").random()
            Emotion.SAD -> listOf("...", "", "").random()
            Emotion.EXCITED -> listOf("！！", "🎉", "").random()
            Emotion.TIRED -> listOf("...", "", "").random()
            else -> ""
        }
        
        return "$prefix$text$suffix"
    }
}
