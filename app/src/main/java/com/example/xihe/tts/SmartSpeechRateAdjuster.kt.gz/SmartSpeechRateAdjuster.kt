package com.example.xihe.tts

import com.example.xihe.utils.LogManager

/**
 * 🎯 智能语速调节器
 * 根据文本内容、长度、类型等自动调整语速
 */
object SmartSpeechRateAdjuster {
    
    private const val TAG = "SmartSpeechRate"
    
    // 基础语速范围
    private const val MIN_SPEED = 0.7f
    private const val MAX_SPEED = 1.5f
    private const val DEFAULT_SPEED = 1.0f
    
    /**
     * 文本类型
     */
    enum class TextType {
        CASUAL_CHAT,        // 日常聊天
        INFORMATION,        // 信息播报
        INSTRUCTION,        // 指令说明
        STORY,              // 故事叙述
        URGENT,             // 紧急通知
        TECHNICAL,          // 技术内容
        POETRY              // 诗歌朗诵
    }
    
    /**
     * 语速调节策略
     */
    data class SpeechRateStrategy(
        val baseSpeed: Float = DEFAULT_SPEED,
        val enableLengthAdjustment: Boolean = true,
        val enableContentAnalysis: Boolean = true,
        val enablePunctuationPause: Boolean = true,
        val userPreferenceMultiplier: Float = 1.0f  // 用户偏好倍数
    )
    
    /**
     * 智能计算语速
     * @param text 要播报的文本
     * @param textType 文本类型
     * @param strategy 调节策略
     * @return 建议的语速值
     */
    fun calculateSpeechRate(
        text: String,
        textType: TextType = TextType.CASUAL_CHAT,
        strategy: SpeechRateStrategy = SpeechRateStrategy()
    ): Float {
        var speed = strategy.baseSpeed
        
        // 1. 根据文本类型调整基础语速
        speed *= getTypeSpeedMultiplier(textType)
        
        // 2. 根据文本长度调整
        if (strategy.enableLengthAdjustment) {
            speed *= getLengthSpeedMultiplier(text)
        }
        
        // 3. 根据内容特征调整
        if (strategy.enableContentAnalysis) {
            speed *= getContentSpeedMultiplier(text)
        }
        
        // 4. 应用用户偏好
        speed *= strategy.userPreferenceMultiplier
        
        // 5. 限制在合理范围内
        val finalSpeed = speed.coerceIn(MIN_SPEED, MAX_SPEED)
        
        LogManager.d(TAG, "📊 智能语速: 文本长度=${text.length}, 类型=$textType, 计算语速=$finalSpeed")
        
        return finalSpeed
    }
    
    /**
     * 根据文本类型获取语速倍数
     */
    private fun getTypeSpeedMultiplier(type: TextType): Float {
        return when (type) {
            TextType.CASUAL_CHAT -> 1.0f        // 正常语速
            TextType.INFORMATION -> 0.95f       // 稍慢，确保信息清晰
            TextType.INSTRUCTION -> 0.85f       // 较慢，便于理解步骤
            TextType.STORY -> 0.9f              // 稍慢，营造氛围
            TextType.URGENT -> 1.3f             // 较快，传达紧迫感
            TextType.TECHNICAL -> 0.8f          // 慢速，便于理解专业术语
            TextType.POETRY -> 0.85f            // 慢速，体现韵律
        }
    }
    
    /**
     * 根据文本长度获取语速倍数
     * 短文本可以快一点，长文本需要慢一点避免疲劳
     */
    private fun getLengthSpeedMultiplier(text: String): Float {
        val length = text.length
        return when {
            length < 10 -> 1.1f         // 很短，可以快一点
            length < 30 -> 1.05f        // 短，稍快
            length < 100 -> 1.0f        // 中等，正常
            length < 200 -> 0.95f       // 较长，稍慢
            length < 500 -> 0.9f        // 长，慢一点
            else -> 0.85f               // 很长，明显慢下来
        }
    }
    
    /**
     * 根据内容特征获取语速倍数
     */
    private fun getContentSpeedMultiplier(text: String): Float {
        var multiplier = 1.0f
        
        // 检查是否包含数字（数字需要慢一点）
        if (text.contains(Regex("\\d+"))) {
            multiplier *= 0.95f
        }
        
        // 检查是否包含英文（英文需要慢一点）
        if (text.contains(Regex("[a-zA-Z]+"))) {
            multiplier *= 0.95f
        }
        
        // 检查标点符号密度（标点多说明内容复杂）
        val punctuationCount = text.count { it in "，。！？；：、" }
        val punctuationDensity = punctuationCount.toFloat() / text.length
        if (punctuationDensity > 0.1f) {
            multiplier *= 0.9f
        }
        
        // 检查是否包含专业术语（通过长词判断）
        val hasLongWords = text.split(Regex("[，。！？；：、\\s]+"))
            .any { it.length > 6 }
        if (hasLongWords) {
            multiplier *= 0.95f
        }
        
        // 检查是否包含问句（问句可以稍快）
        if (text.contains("？") || text.contains("吗") || text.contains("呢")) {
            multiplier *= 1.05f
        }
        
        return multiplier
    }
    
    /**
     * 自动检测文本类型
     */
    fun detectTextType(text: String): TextType {
        return when {
            // 紧急通知
            text.contains(Regex("紧急|警告|注意|危险|错误")) -> TextType.URGENT
            
            // 技术内容
            text.contains(Regex("API|HTTP|JSON|代码|函数|变量|配置")) -> TextType.TECHNICAL
            
            // 指令说明
            text.contains(Regex("第[一二三四五六七八九十]步|首先|然后|接着|最后|步骤")) -> TextType.INSTRUCTION
            
            // 信息播报
            text.contains(Regex("天气|温度|时间|日期|新闻|通知")) -> TextType.INFORMATION
            
            // 诗歌
            text.contains(Regex("[，。]{2,}")) && text.length < 100 -> TextType.POETRY
            
            // 故事
            text.contains(Regex("从前|很久以前|有一天|后来|最后")) -> TextType.STORY
            
            // 默认为日常聊天
            else -> TextType.CASUAL_CHAT
        }
    }
    
    /**
     * 根据情绪调整语速
     */
    fun adjustSpeedByEmotion(baseSpeed: Float, emotion: String): Float {
        val emotionMultiplier = when (emotion.lowercase()) {
            "excited", "happy" -> 1.15f      // 兴奋/开心 - 快一点
            "sad", "tired" -> 0.85f          // 难过/疲惫 - 慢一点
            "angry" -> 1.1f                  // 生气 - 稍快
            "worried" -> 0.9f                // 担心 - 稍慢
            else -> 1.0f                     // 中性 - 正常
        }
        
        return (baseSpeed * emotionMultiplier).coerceIn(MIN_SPEED, MAX_SPEED)
    }
    
    /**
     * 分析文本并给出完整的语速建议
     */
    fun analyzeSpeechRate(
        text: String,
        userBaseSpeed: Float = DEFAULT_SPEED,
        emotion: String? = null
    ): SpeechRateAnalysis {
        // 自动检测文本类型
        val detectedType = detectTextType(text)
        
        // 创建策略
        val strategy = SpeechRateStrategy(
            baseSpeed = userBaseSpeed,
            userPreferenceMultiplier = 1.0f
        )
        
        // 计算基础语速
        var recommendedSpeed = calculateSpeechRate(text, detectedType, strategy)
        
        // 根据情绪调整
        if (emotion != null) {
            recommendedSpeed = adjustSpeedByEmotion(recommendedSpeed, emotion)
        }
        
        return SpeechRateAnalysis(
            originalSpeed = userBaseSpeed,
            recommendedSpeed = recommendedSpeed,
            detectedType = detectedType,
            textLength = text.length,
            adjustmentReason = buildAdjustmentReason(text, detectedType, userBaseSpeed, recommendedSpeed)
        )
    }
    
    /**
     * 语速分析结果
     */
    data class SpeechRateAnalysis(
        val originalSpeed: Float,
        val recommendedSpeed: Float,
        val detectedType: TextType,
        val textLength: Int,
        val adjustmentReason: String
    )
    
    /**
     * 构建调整原因说明
     */
    private fun buildAdjustmentReason(
        text: String,
        type: TextType,
        originalSpeed: Float,
        recommendedSpeed: Float
    ): String {
        val reasons = mutableListOf<String>()
        
        if (type != TextType.CASUAL_CHAT) {
            reasons.add("检测到${type.name}类型内容")
        }
        
        when {
            text.length > 200 -> reasons.add("文本较长")
            text.length < 10 -> reasons.add("文本很短")
        }
        
        if (text.contains(Regex("\\d+"))) {
            reasons.add("包含数字")
        }
        
        if (text.contains(Regex("[a-zA-Z]+"))) {
            reasons.add("包含英文")
        }
        
        val speedChange = ((recommendedSpeed - originalSpeed) / originalSpeed * 100).toInt()
        if (speedChange > 5) {
            reasons.add("建议加快${speedChange}%")
        } else if (speedChange < -5) {
            reasons.add("建议放慢${-speedChange}%")
        }
        
        return if (reasons.isEmpty()) {
            "使用默认语速"
        } else {
            reasons.joinToString("，")
        }
    }
}
