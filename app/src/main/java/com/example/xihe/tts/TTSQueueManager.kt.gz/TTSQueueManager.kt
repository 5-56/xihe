package com.example.xihe.tts

import android.content.Context
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * 🎵 TTS播放队列管理器
 * 
 * 功能：
 * 1. 管理语音播放队列，支持排队播放
 * 2. 支持优先级播放（紧急消息插队）
 * 3. 提供播放状态监控
 * 4. 支持中断当前播放
 * 5. 防止重复播放相同内容
 */
class TTSQueueManager private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "TTSQueueManager"

        @Volatile
        private var instance: TTSQueueManager? = null

        fun getInstance(context: Context): TTSQueueManager {
            return instance ?: synchronized(this) {
                instance ?: TTSQueueManager(context.applicationContext).also { instance = it }
            }
        }
    }
    
    /**
     * 播放项
     */
    data class TTSItem(
        val text: String,
        val priority: Priority = Priority.NORMAL,
        val emotion: Emotion = Emotion.NEUTRAL,
        val onStart: (() -> Unit)? = null,
        val onComplete: (() -> Unit)? = null,
        val timestamp: Long = System.currentTimeMillis(),
        val customSpeed: Float? = null  // 自定义语速，null则使用智能调节
    )
    
    /**
     * 播放优先级
     */
    enum class Priority {
        LOW,        // 低优先级（如提示音）
        NORMAL,     // 普通优先级（AI回复）
        HIGH,       // 高优先级（重要通知）
        URGENT      // 紧急（立即中断当前播放）
    }
    
    /**
     * 情绪类型
     */
    enum class Emotion {
        NEUTRAL,    // 中性
        HAPPY,      // 开心
        SAD,        // 难过
        EXCITED,    // 兴奋
        CALM,       // 平静
        TIRED       // 疲惫
    }
    
    /**
     * 播放状态
     */
    enum class PlayState {
        IDLE,       // 空闲
        PLAYING,    // 播放中
        PAUSED,     // 暂停
        QUEUED      // 有排队内容
    }
    
    // 播放队列
    private val normalQueue = ConcurrentLinkedQueue<TTSItem>()
    private val highPriorityQueue = ConcurrentLinkedQueue<TTSItem>()
    
    // 状态
    private val _playState = MutableStateFlow(PlayState.IDLE)
    val playState = _playState.asStateFlow()
    
    private val _currentItem = MutableStateFlow<TTSItem?>(null)
    val currentItem = _currentItem.asStateFlow()
    
    private val _queueSize = MutableStateFlow(0)
    val queueSize = _queueSize.asStateFlow()
    
    // 最近播放记录（用于去重）
    private val recentPlayedTexts = mutableListOf<String>()
    private val MAX_RECENT_TEXTS = 10
    private val DEDUP_TIME_MS = 5000L // 5秒内相同内容不重复播放
    private val lastPlayTime = mutableMapOf<String, Long>()
    
    // 协程作用域
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var playJob: Job? = null
    
    // TTS引擎回调（增加语速参数）
    private var onSpeakCallback: ((String, Emotion, Float, () -> Unit) -> Unit)? = null
    
    // 智能语速调节配置
    private var enableSmartSpeed = true
    private var userBaseSpeed = 1.0f
    
    /**
     * 设置TTS播放回调
     */
    fun setTTSCallback(callback: ((String, Emotion, Float, () -> Unit) -> Unit)?) {
        onSpeakCallback = callback
    }
    
    /**
     * 设置智能语速开关
     */
    fun setSmartSpeedEnabled(enabled: Boolean) {
        enableSmartSpeed = enabled
        LogManager.d(TAG, "🎯 智能语速调节: ${if (enabled) "开启" else "关闭"}")
    }
    
    /**
     * 设置用户基础语速
     */
    fun setUserBaseSpeed(speed: Float) {
        userBaseSpeed = speed.coerceIn(0.5f, 2.0f)
        LogManager.d(TAG, "🎚️ 用户基础语速设置为: $userBaseSpeed")
    }
    
    /**
     * 添加到播放队列
     */
    fun enqueue(
        text: String,
        priority: Priority = Priority.NORMAL,
        emotion: Emotion = Emotion.NEUTRAL,
        onStart: (() -> Unit)? = null,
        onComplete: (() -> Unit)? = null,
        customSpeed: Float? = null
    ): Boolean {
        // 空文本检查
        if (text.isBlank()) {
            LogManager.w(TAG, "⚠️ 空文本，跳过入队")
            return false
        }
        
        // 去重检查
        if (isDuplicate(text)) {
            LogManager.d(TAG, "🔇 重复内容，跳过: ${text.take(20)}...")
            return false
        }
        
        val item = TTSItem(text, priority, emotion, onStart, onComplete, customSpeed = customSpeed)
        
        when (priority) {
            Priority.URGENT -> {
                // 紧急消息：中断当前播放，立即播放
                LogManager.i(TAG, "🚨 紧急消息入队: ${text.take(30)}...")
                stopCurrent()
                highPriorityQueue.offer(item)
            }
            Priority.HIGH -> {
                // 高优先级：加入高优先级队列
                LogManager.d(TAG, "⚡ 高优先级消息入队: ${text.take(30)}...")
                highPriorityQueue.offer(item)
            }
            else -> {
                // 普通/低优先级：加入普通队列
                LogManager.d(TAG, "📝 消息入队: ${text.take(30)}...")
                normalQueue.offer(item)
            }
        }
        
        updateQueueSize()
        
        // 如果当前空闲，开始播放
        if (_playState.value == PlayState.IDLE) {
            startPlayback()
        }
        
        return true
    }
    
    /**
     * 快捷方法：普通播放
     */
    fun speak(text: String, emotion: Emotion = Emotion.NEUTRAL, onComplete: (() -> Unit)? = null): Boolean {
        return enqueue(text, Priority.NORMAL, emotion, onComplete = onComplete)
    }
    
    /**
     * 快捷方法：紧急播放（中断当前）
     */
    fun speakUrgent(text: String, emotion: Emotion = Emotion.NEUTRAL, onComplete: (() -> Unit)? = null): Boolean {
        return enqueue(text, Priority.URGENT, emotion, onComplete = onComplete)
    }
    
    /**
     * 检查是否重复内容
     */
    private fun isDuplicate(text: String): Boolean {
        val normalizedText = text.trim().lowercase()
        val now = System.currentTimeMillis()
        
        // 检查最近是否播放过
        val lastTime = lastPlayTime[normalizedText]
        if (lastTime != null && now - lastTime < DEDUP_TIME_MS) {
            return true
        }
        
        return false
    }
    
    /**
     * 记录播放内容
     */
    private fun recordPlayed(text: String) {
        val normalizedText = text.trim().lowercase()
        lastPlayTime[normalizedText] = System.currentTimeMillis()
        
        // 维护最近播放列表
        recentPlayedTexts.add(normalizedText)
        if (recentPlayedTexts.size > MAX_RECENT_TEXTS) {
            val removed = recentPlayedTexts.removeAt(0)
            lastPlayTime.remove(removed)
        }
    }
    
    /**
     * 开始播放队列
     */
    private fun startPlayback() {
        if (playJob?.isActive == true) return
        
        playJob = scope.launch {
            while (isActive) {
                // 优先从高优先级队列取
                val item = highPriorityQueue.poll() ?: normalQueue.poll()
                
                if (item == null) {
                    _playState.value = PlayState.IDLE
                    _currentItem.value = null
                    break
                }
                
                _playState.value = PlayState.PLAYING
                _currentItem.value = item
                updateQueueSize()
                
                // 记录播放
                recordPlayed(item.text)
                
                // 调用开始回调
                item.onStart?.invoke()
                
                // 🎯 计算智能语速
                val speed = calculateSpeed(item)
                
                // 等待播放完成
                val completed = CompletableDeferred<Unit>()
                
                withContext(Dispatchers.Main) {
                    onSpeakCallback?.invoke(item.text, item.emotion, speed) {
                        completed.complete(Unit)
                    } ?: completed.complete(Unit)
                }
                
                try {
                    completed.await()
                } catch (e: CancellationException) {
                    LogManager.d(TAG, "🛑 播放被取消")
                }
                
                // 调用完成回调
                item.onComplete?.invoke()
                
                // 短暂延迟，避免连续播放太紧凑
                delay(300)
            }
            playJob = null
        }
    }
    
    /**
     * 停止当前播放
     */
    fun stopCurrent() {
        playJob?.cancel()
        playJob = null
        _playState.value = PlayState.IDLE
        _currentItem.value = null
        LogManager.d(TAG, "🛑 当前播放已停止")
    }
    
    /**
     * 清空队列
     */
    fun clearQueue() {
        normalQueue.clear()
        highPriorityQueue.clear()
        updateQueueSize()
        LogManager.d(TAG, "🗑️ 队列已清空")
    }
    
    /**
     * 停止所有播放并清空队列
     */
    fun stopAll() {
        stopCurrent()
        clearQueue()
        LogManager.i(TAG, "🛑 所有播放已停止，队列已清空")
    }
    
    /**
     * 暂停播放
     */
    fun pause() {
        if (_playState.value == PlayState.PLAYING) {
            playJob?.cancel()
            playJob = null
            _playState.value = PlayState.PAUSED
            LogManager.d(TAG, "⏸️ 播放已暂停")
        }
    }
    
    /**
     * 恢复播放
     */
    fun resume() {
        if (_playState.value == PlayState.PAUSED) {
            startPlayback()
            LogManager.d(TAG, "▶️ 播放已恢复")
        }
    }
    
    /**
     * 跳过当前，播放下一个
     */
    fun skipCurrent() {
        stopCurrent()
        startPlayback()
        LogManager.d(TAG, "⏭️ 跳过当前，播放下一个")
    }
    
    /**
     * 更新队列大小
     */
    private fun updateQueueSize() {
        _queueSize.value = normalQueue.size + highPriorityQueue.size
    }
    
    /**
     * 获取队列中的所有待播放文本
     */
    fun getQueuedTexts(): List<String> {
        return (highPriorityQueue.toList() + normalQueue.toList()).map { it.text }
    }
    
    /**
     * 检查是否正在播放
     */
    fun isPlaying(): Boolean = _playState.value == PlayState.PLAYING
    
    /**
     * 检查队列是否为空
     */
    fun isQueueEmpty(): Boolean = normalQueue.isEmpty() && highPriorityQueue.isEmpty()
    
    /**
     * 释放资源
     */
    fun release() {
        onSpeakCallback = null
        stopAll()
        normalQueue.clear()
        highPriorityQueue.clear()
        recentPlayedTexts.clear()
        lastPlayTime.clear()
        _currentItem.value = null
        _playState.value = PlayState.IDLE
        _queueSize.value = 0
        playJob = null
        scope.cancel()
        instance = null
        LogManager.d(TAG, "🔒 TTSQueueManager已释放")
    }
    
    /**
     * 🎯 计算智能语速
     */
    private fun calculateSpeed(item: TTSItem): Float {
        // 如果指定了自定义语速，直接使用
        if (item.customSpeed != null) {
            LogManager.d(TAG, "🎚️ 使用自定义语速: ${item.customSpeed}")
            return item.customSpeed
        }
        
        // 如果关闭了智能语速，使用用户基础语速
        if (!enableSmartSpeed) {
            return userBaseSpeed
        }
        
        // 使用智能语速调节器
        val emotionName = when (item.emotion) {
            Emotion.HAPPY -> "happy"
            Emotion.SAD -> "sad"
            Emotion.EXCITED -> "excited"
            Emotion.CALM -> "neutral"
            Emotion.TIRED -> "tired"
            else -> "neutral"
        }
        
        val analysis = SmartSpeechRateAdjuster.analyzeSpeechRate(
            text = item.text,
            userBaseSpeed = userBaseSpeed,
            emotion = emotionName
        )
        
        LogManager.d(TAG, "🎯 智能语速分析:")
        LogManager.d(TAG, "  - 文本长度: ${analysis.textLength}")
        LogManager.d(TAG, "  - 检测类型: ${analysis.detectedType}")
        LogManager.d(TAG, "  - 原始语速: ${analysis.originalSpeed}")
        LogManager.d(TAG, "  - 推荐语速: ${analysis.recommendedSpeed}")
        LogManager.d(TAG, "  - 调整原因: ${analysis.adjustmentReason}")
        
        return analysis.recommendedSpeed
    }
}

