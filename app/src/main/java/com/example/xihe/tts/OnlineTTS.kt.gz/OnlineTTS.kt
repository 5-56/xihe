package com.example.xihe.tts

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * 🌐 在线 TTS - 通过 API 调用在线语音合成服务
 * 
 * 支持多种在线 TTS 服务:
 * - 自定义 API 端点
 * - 可配置的请求格式
 */
class OnlineTTS(private val context: Context) {
    
    companion object {
        private const val TAG = "OnlineTTS"
        
        // TTS 引擎类型
        const val ENGINE_CUSTOM = "custom"
        const val ENGINE_EDGE = "edge"
    }
    
    // OkHttp 客户端
    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(10, TimeUnit.SECONDS)
        .build()
    
    // 配置
    private var apiUrl: String = ""
    private var apiKey: String = ""
    private var engineType: String = ENGINE_CUSTOM
    private var voiceId: String = "zh-CN-XiaoxiaoNeural" // 默认微软 Edge 语音
    
    // 状态
    private var isInitialized = false
    private var mediaPlayer: MediaPlayer? = null
    
    // 回调
    private var onStartCallback: (() -> Unit)? = null
    private var onDoneCallback: (() -> Unit)? = null
    private var onErrorCallback: ((String) -> Unit)? = null
    
    /**
     * 🚀 初始化
     */
    fun initialize(): Boolean {
        val prefs = context.getSharedPreferences("voice_settings", Context.MODE_PRIVATE)
        apiUrl = prefs.getString("online_tts_url", "") ?: ""
        apiKey = prefs.getString("online_tts_key", "") ?: ""
        engineType = prefs.getString("online_tts_engine", ENGINE_CUSTOM) ?: ENGINE_CUSTOM
        voiceId = prefs.getString("online_tts_voice", "zh-CN-XiaoxiaoNeural") ?: "zh-CN-XiaoxiaoNeural"
        
        isInitialized = apiUrl.isNotEmpty()
        
        if (isInitialized) {
            LogManager.i(TAG, "✅ 在线TTS初始化成功: $engineType")
        } else {
            LogManager.w(TAG, "⚠️ 在线TTS未配置API地址")
        }
        
        return isInitialized
    }
    
    /**
     * 🔧 配置 API
     */
    fun configure(url: String, key: String = "", engine: String = ENGINE_CUSTOM, voice: String = "zh-CN-XiaoxiaoNeural") {
        apiUrl = url
        apiKey = key
        engineType = engine
        voiceId = voice
        isInitialized = url.isNotEmpty()
        
        // 保存配置
        val prefs = context.getSharedPreferences("voice_settings", Context.MODE_PRIVATE)
        prefs.edit()
            .putString("online_tts_url", url)
            .putString("online_tts_key", key)
            .putString("online_tts_engine", engine)
            .putString("online_tts_voice", voice)
            .apply()
        
        LogManager.i(TAG, "🔧 在线TTS配置已更新: $engine -> $url")
    }
    
    /**
     * 🎤 语音合成
     */
    suspend fun speak(
        text: String,
        speed: Float = 1.0f,
        pitch: Float = 1.0f,
        onStart: (() -> Unit)? = null,
        onDone: (() -> Unit)? = null,
        onError: ((String) -> Unit)? = null
    ): Boolean = withContext(Dispatchers.IO) {
        if (!isInitialized || apiUrl.isEmpty()) {
            LogManager.e(TAG, "❌ 在线TTS未初始化或未配置")
            onError?.invoke("在线TTS未配置")
            return@withContext false
        }
        
        onStartCallback = onStart
        onDoneCallback = onDone
        onErrorCallback = onError
        
        try {
            LogManager.d(TAG, "🎤 开始在线语音合成: $text")
            
            // 构建请求
            val audioData = requestTTS(text, speed, pitch)
            
            if (audioData != null && audioData.isNotEmpty()) {
                // 播放音频
                withContext(Dispatchers.Main) {
                    onStart?.invoke()
                }
                playAudio(audioData)
                return@withContext true
            } else {
                LogManager.e(TAG, "❌ 在线TTS返回空数据")
                withContext(Dispatchers.Main) {
                    onError?.invoke("语音合成失败")
                }
                return@withContext false
            }
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 在线TTS错误", e)
            withContext(Dispatchers.Main) {
                onError?.invoke(e.message ?: "未知错误")
            }
            return@withContext false
        }
    }
    
    /**
     * 🌐 请求 TTS API
     */
    private fun requestTTS(text: String, speed: Float, pitch: Float): ByteArray? {
        val requestBody = when (engineType) {
            ENGINE_EDGE -> buildEdgeRequest(text, speed, pitch)
            else -> buildCustomRequest(text, speed, pitch)
        }
        
        val requestBuilder = Request.Builder()
            .url(apiUrl)
            .post(requestBody)
            .addHeader("Content-Type", "application/json")
        
        // 添加 API Key
        if (apiKey.isNotEmpty()) {
            requestBuilder.addHeader("Authorization", "Bearer $apiKey")
        }
        
        val request = requestBuilder.build()
        
        okHttpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IOException("TTS请求失败: ${response.code} ${response.message}")
            }
            
            val contentType = response.header("Content-Type") ?: ""
            
            return if (contentType.contains("audio") || contentType.contains("octet-stream")) {
                // 直接返回音频数据
                response.body?.bytes()
            } else {
                // JSON 响应，需要解析
                val jsonStr = response.body?.string() ?: ""
                parseAudioFromJson(jsonStr)
            }
        }
    }
    
    /**
     * 构建自定义请求
     */
    private fun buildCustomRequest(text: String, speed: Float, pitch: Float): RequestBody {
        val json = JSONObject().apply {
            put("text", text)
            put("speed", speed)
            put("pitch", pitch)
            put("voice", voiceId)
        }
        return json.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
    }
    
    /**
     * 构建 Edge TTS 请求
     */
    private fun buildEdgeRequest(text: String, speed: Float, pitch: Float): RequestBody {
        val speedPercent = ((speed - 1.0f) * 100).toInt()
        val pitchPercent = ((pitch - 1.0f) * 50).toInt()
        
        val json = JSONObject().apply {
            put("text", text)
            put("voice", voiceId)
            put("rate", "${if (speedPercent >= 0) "+" else ""}${speedPercent}%")
            put("pitch", "${if (pitchPercent >= 0) "+" else ""}${pitchPercent}Hz")
        }
        return json.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
    }
    
    /**
     * 从 JSON 响应解析音频
     */
    private fun parseAudioFromJson(jsonStr: String): ByteArray? {
        try {
            val json = JSONObject(jsonStr)
            
            // 尝试多种可能的字段名
            val audioBase64 = json.optString("audio")
                .ifEmpty { json.optString("data") }
                .ifEmpty { json.optString("audioContent") }
                .ifEmpty { json.optString("speech") }
            
            if (audioBase64.isNotEmpty()) {
                return android.util.Base64.decode(audioBase64, android.util.Base64.DEFAULT)
            }
            
            // 检查是否有 URL
            val audioUrl = json.optString("url")
                .ifEmpty { json.optString("audioUrl") }
            
            if (audioUrl.isNotEmpty()) {
                return downloadAudio(audioUrl)
            }
            
        } catch (e: Exception) {
            LogManager.e(TAG, "解析JSON响应失败", e)
        }
        return null
    }
    
    /**
     * 下载音频文件
     */
    private fun downloadAudio(url: String): ByteArray? {
        val request = Request.Builder().url(url).get().build()
        okHttpClient.newCall(request).execute().use { response ->
            if (response.isSuccessful) {
                return response.body?.bytes()
            }
        }
        return null
    }
    
    /**
     * 🔊 播放音频
     */
    private suspend fun playAudio(audioData: ByteArray) {
        withContext(Dispatchers.IO) {
            try {
                // 保存到临时文件
                val tempFile = File(context.cacheDir, "tts_temp_${System.currentTimeMillis()}.mp3")
                FileOutputStream(tempFile).use { fos ->
                    fos.write(audioData)
                }
                
                // 使用 MediaPlayer 播放
                withContext(Dispatchers.Main) {
                    mediaPlayer?.release()
                    mediaPlayer = MediaPlayer().apply {
                        setDataSource(tempFile.absolutePath)
                        setAudioAttributes(
                            AudioAttributes.Builder()
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                                .build()
                        )
                        
                        setOnCompletionListener {
                            LogManager.d(TAG, "✅ 在线TTS播放完成")
                            onDoneCallback?.invoke()
                            tempFile.delete()
                        }
                        
                        setOnErrorListener { _, what, extra ->
                            LogManager.e(TAG, "❌ MediaPlayer错误: what=$what, extra=$extra")
                            onErrorCallback?.invoke("播放错误")
                            tempFile.delete()
                            true
                        }
                        
                        prepare()
                        start()
                        LogManager.d(TAG, "🔊 开始播放在线TTS音频")
                    }
                }
                
            } catch (e: Exception) {
                LogManager.e(TAG, "❌ 播放音频失败", e)
                withContext(Dispatchers.Main) {
                    onErrorCallback?.invoke(e.message ?: "播放失败")
                }
            }
        }
    }
    
    /**
     * 🛑 停止播放
     */
    fun stop() {
        mediaPlayer?.let {
            if (it.isPlaying) {
                it.stop()
            }
            it.release()
        }
        mediaPlayer = null
    }
    
    /**
     * 🔍 是否就绪
     */
    fun isReady(): Boolean = isInitialized && apiUrl.isNotEmpty()
    
    /**
     * 📊 获取当前配置
     */
    fun getConfig(): TTSConfig = TTSConfig(
        apiUrl = apiUrl,
        apiKey = apiKey,
        engineType = engineType,
        voiceId = voiceId
    )
    
    /**
     * 🧹 释放资源
     */
    fun release() {
        stop()
        LogManager.d(TAG, "🧹 在线TTS资源已释放")
    }
    
    data class TTSConfig(
        val apiUrl: String,
        val apiKey: String,
        val engineType: String,
        val voiceId: String
    )
}
