package com.example.xihe.tts

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.TextToSpeech.OnInitListener
import android.speech.tts.UtteranceProgressListener
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.withLock
import java.util.Locale
import java.util.UUID

/**
 * 🎤 统一 TTS 管理器
 * 
 * 职责：
 * 1. 统一管理 Android 系统 TextToSpeech 实例（单例，避免多个 TTS 实例冲突）
 * 2. 提供清晰的 API 供 TTSQueueManager、EmotionalTTS 等模块使用
 * 3. 支持语音中断、状态监听
 * 4. 自动处理音频焦点（与音乐/系统语音共存）
 * 
 * 设计原则：
 * - 只管理一个 TextToSpeech 实例（Android 限制）
 * - 所有 TTS 调用通过此管理器路由
 * - 支持语音中断当前播放
 */
class UnifiedTTSManager private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "UnifiedTTSManager"
        
        @Volatile
        private var instance: UnifiedTTSManager? = null
        
        fun getInstance(context: Context): UnifiedTTSManager {
            return instance ?: synchronized(this) {
                instance ?: UnifiedTTSManager(context.applicationContext).also { instance = it }
            }
        }
    }
    
    // ==================== TTS 实例 ====================
    
    private var tts: TextToSpeech? = null
    private var ttsInitialized = false
    private val initMutex = Mutex()
    
    // ==================== 状态管理 ====================
    
    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()
    
    private val _currentUtterance = MutableStateFlow<String?>(null)
    val currentUtterance: StateFlow<String?> = _currentUtterance.asStateFlow()
    
    // ==================== 配置 ====================
    
    private var defaultLanguage = Locale.CHINA
    private var defaultPitch = 1.0f
    private var defaultSpeechRate = 1.0f
    
    // ==================== 回调 ====================
    
    private var onStartCallback: ((String) -> Unit)? = null
    private var onDoneCallback: ((String) -> Unit)? = null
    private var onErrorCallback: ((String, Exception?) -> Unit)? = null
    
    // ==================== 初始化 ====================
    
    /**
     * 初始化 TTS 引擎（线程安全，可重复调用）
     */
    suspend fun initialize(): Boolean = initMutex.withLock {
        if (ttsInitialized) return true
        
        return withContext(Dispatchers.IO) {
            try {
                tts = TextToSpeech(context.applicationContext) { status ->
                    if (status == TextToSpeech.SUCCESS) {
                        initTtsSettings()
                    }
                }
                
                // 等待 TTS 初始化完成（最多 3 秒）
                val started = initWaiter(3000L)
                if (started) {
                    ttsInitialized = true
                    LogManager.i(TAG, "✅ TTS 引擎初始化成功 (语言: ${defaultLanguage})")
                    true
                } else {
                    LogManager.e(TAG, "❌ TTS 初始化超时")
                    false
                }
            } catch (e: Exception) {
                LogManager.e(TAG, "❌ TTS 初始化失败", e)
                false
            }
        }
    }
    
    private fun initTtsSettings() {
        tts?.language = defaultLanguage
        tts?.setPitch(defaultPitch)
        tts?.setSpeechRate(defaultSpeechRate)
        
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                _isSpeaking.value = true
                _currentUtterance.value = utteranceId?.takeIf { it.isNotEmpty() }
                    ?: _currentUtterance.value
                onStartCallback?.invoke(utteranceId ?: "")
            }
            
            override fun onDone(utteranceId: String?) {
                if (!_isSpeaking.value) return
                _isSpeaking.value = false
                _currentUtterance.value = null
                onDoneCallback?.invoke(utteranceId ?: "")
            }
            
            override fun onError(utteranceId: String?) {
                _isSpeaking.value = false
                _currentUtterance.value = null
                onErrorCallback?.invoke(utteranceId ?: "", null)
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                _isSpeaking.value = false
                _currentUtterance.value = null
                onErrorCallback?.invoke(utteranceId ?: "", Exception("TTS error code: $errorCode"))
            }
        })
    }
    
    /**
     * 等待 TTS 初始化完成的简易实现
     */
    private suspend fun initWaiter(timeoutMs: Long): Boolean {
        val start = System.currentTimeMillis()
        while (System.currentTimeMillis() - start < timeoutMs) {
            if (tts != null) {
                // 通过 speak 一个小测试来确认 TTS 可用
                try {
                    tts?.speak("", TextToSpeech.QUEUE_FLUSH, null, "test")
                    return true
                } catch (_: Exception) {
                }
            }
            delay(100)
        }
        return false
    }
    
    // ==================== 语音播报 ====================
    
    /**
     * 播报文本（直接播报，不入队）
     * @return utteranceId 用于后续追踪
     */
    fun speak(
        text: String,
        pitch: Float = defaultPitch,
        rate: Float = defaultSpeechRate,
        utteranceId: String = UUID.randomUUID().toString()
    ): Boolean {
        if (text.isBlank()) {
            LogManager.w(TAG, "⚠️ 空文本，跳过播报")
            return false
        }
        
        val ttsInstance = tts ?: run {
            LogManager.w(TAG, "⚠️ TTS 未初始化")
            return false
        }
        
        ttsInstance.setPitch(pitch)
        ttsInstance.setSpeechRate(rate)
        
        val bundle = android.os.Bundle().apply {
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
        }
        
        try {
            ttsInstance.speak(text, TextToSpeech.QUEUE_FLUSH, bundle, utteranceId)
            LogManager.d(TAG, "🔊 开始播报: \"$text\" (utteranceId: $utteranceId)")
            return true
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 播报失败", e)
            onErrorCallback?.invoke(utteranceId, e)
            return false
        }
    }
    
    /**
     * 追加到播放队列
     */
    fun enqueue(
        text: String,
        pitch: Float = defaultPitch,
        rate: Float = defaultSpeechRate,
        utteranceId: String = UUID.randomUUID().toString()
    ): Boolean {
        if (text.isBlank()) return false
        
        val ttsInstance = tts ?: run {
            LogManager.w(TAG, "⚠️ TTS 未初始化")
            return false
        }
        
        ttsInstance.setPitch(pitch)
        ttsInstance.setSpeechRate(rate)
        
        val bundle = android.os.Bundle().apply {
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
        }
        
        try {
            ttsInstance.speak(text, TextToSpeech.QUEUE_ADD, bundle, utteranceId)
            LogManager.d(TAG, "📝 加入队列: \"$text\"")
            return true
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 入队失败", e)
            return false
        }
    }
    
    /**
     * 停止当前播报（清空队列）
     */
    fun stop() {
        tts?.stop()
        _isSpeaking.value = false
        _currentUtterance.value = null
        LogManager.d(TAG, "🛑 播报已停止")
    }
    
    /**
     * 检查是否正在播报
     */
    fun isCurrentlySpeaking(): Boolean = _isSpeaking.value
    
    // ==================== 配置管理 ====================
    
    fun setLanguage(locale: Locale) {
        defaultLanguage = locale
        tts?.language = locale
        LogManager.d(TAG, "🌐 语言设置为: ${locale}")
    }
    
    fun setPitch(pitch: Float) {
        defaultPitch = pitch.coerceIn(0.5f, 2.0f)
        tts?.setPitch(defaultPitch)
        LogManager.d(TAG, "🎵 默认音高设置为: $defaultPitch")
    }
    
    fun setSpeechRate(rate: Float) {
        defaultSpeechRate = rate.coerceIn(0.1f, 3.0f)
        tts?.setSpeechRate(defaultSpeechRate)
        LogManager.d(TAG, "🗣️ 默认语速设置为: $defaultSpeechRate")
    }
    
    // ==================== 回调设置 ====================
    
    fun setCallbacks(
        onStart: ((String) -> Unit)? = null,
        onDone: ((String) -> Unit)? = null,
        onError: ((String, Exception?) -> Unit)? = null
    ) {
        onStartCallback = onStart
        onDoneCallback = onDone
        onErrorCallback = onError
    }
    
    // ==================== 资源释放 ====================
    
    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        ttsInitialized = false
        _isSpeaking.value = false
        _currentUtterance.value = null
        LogManager.d(TAG, "🗑️ TTS 管理器已释放")
    }
}

/**
 * 简易的 TTS 初始化等待辅助类
 * 用于替代已废弃的等待方式
 */
@Suppress("DEPRECATION")
private class InitWaiter(
    private val onInitListener: OnInitListener
) : OnInitListener {
    private var completed = false
    
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            onInitListener.onInit(status)
        }
        completed = true
    }
    
    fun isCompleted(): Boolean = completed
}
