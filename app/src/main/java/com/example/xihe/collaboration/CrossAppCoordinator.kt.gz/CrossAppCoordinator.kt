package com.example.xihe.collaboration

import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.ai.TaskPlanner
import com.example.xihe.screen.ScreenAnalyzer
import com.example.xihe.service.EnhancedAccessibilityService
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable

/**
 * 跨应用协作协调器
 * 实现多个应用之间的智能协作和数据传递
 */
class CrossAppCoordinator(private val context: Context) {
    
    companion object {
        private const val TAG = "CrossAppCoordinator"
        private const val MAX_APP_SWITCHES = 10 // 最大应用切换次数
        private const val APP_SWITCH_TIMEOUT = 5000L // 应用切换超时时间
    }
    
    /**
     * 跨应用任务
     */
    @Serializable
    data class CrossAppTask(
        val id: String,
        val name: String,
        val apps: List<String>,  // 涉及的应用列表
        val workflow: List<AppAction>,
        val dataFlow: Map<String, DataTransfer>,
        val priority: Int = 5,
        val estimatedTime: Long = 0
    )
    
    /**
     * 应用动作
     */
    @Serializable
    data class AppAction(
        val app: String,
        val action: String,
        val parameters: Map<String, String> = emptyMap(),
        val expectedResult: String? = null,
        val timeout: Long = 10000L
    )
    
    /**
     * 数据传输
     */
    @Serializable
    data class DataTransfer(
        val sourceApp: String,
        val targetApp: String,
        val dataType: DataType,
        val data: String,
        val transferMethod: TransferMethod
    )
    
    /**
     * 数据类型
     */
    enum class DataType {
        TEXT,
        IMAGE,
        FILE,
        URL,
        CONTACT,
        LOCATION,
        STRUCTURED_DATA
    }
    
    /**
     * 传输方式
     */
    enum class TransferMethod {
        CLIPBOARD,      // 剪贴板
        SHARE_INTENT,   // 分享意图
        FILE_TRANSFER,  // 文件传输
        DIRECT_INPUT,   // 直接输入
        QR_CODE,        // 二维码
        DEEP_LINK       // 深度链接
    }
    
    /**
     * 协作状态
     */
    enum class CoordinationState {
        IDLE,
        PLANNING,
        EXECUTING,
        SWITCHING_APP,
        TRANSFERRING_DATA,
        WAITING,
        COMPLETED,
        FAILED
    }
    
    /**
     * 执行结果
     */
    data class ExecutionResult(
        val success: Boolean,
        val completedSteps: Int,
        val totalSteps: Int,
        val results: Map<String, Any> = emptyMap(),
        val errors: List<String> = emptyList(),
        val executionTime: Long = 0
    )
    
    // 预定义的跨应用工作流
    private val predefinedWorkflows = mapOf(
        "share_to_social" to CrossAppTask(
            id = "workflow_share_social",
            name = "分享到社交平台",
            apps = listOf("com.tencent.mm", "com.sina.weibo", "com.tencent.mobileqq"),
            workflow = listOf(
                AppAction("source_app", "copy_content"),
                AppAction("com.tencent.mm", "share", mapOf("type" to "moment")),
                AppAction("com.sina.weibo", "post"),
                AppAction("com.tencent.mobileqq", "share", mapOf("type" to "qzone"))
            ),
            dataFlow = mapOf(
                "content" to DataTransfer(
                    sourceApp = "source_app",
                    targetApp = "all",
                    dataType = DataType.TEXT,
                    data = "",
                    transferMethod = TransferMethod.CLIPBOARD
                )
            )
        ),
        
        "shopping_compare" to CrossAppTask(
            id = "workflow_shopping",
            name = "比价购物",
            apps = listOf("com.taobao.taobao", "com.jingdong.app.mall", "com.xunmeng.pinduoduo"),
            workflow = listOf(
                AppAction("com.taobao.taobao", "search_product"),
                AppAction("com.taobao.taobao", "get_price"),
                AppAction("com.jingdong.app.mall", "search_product"),
                AppAction("com.jingdong.app.mall", "get_price"),
                AppAction("com.xunmeng.pinduoduo", "search_product"),
                AppAction("com.xunmeng.pinduoduo", "get_price")
            ),
            dataFlow = emptyMap()
        ),
        
        "document_workflow" to CrossAppTask(
            id = "workflow_document",
            name = "文档处理流程",
            apps = listOf("com.microsoft.office.word", "com.adobe.scan", "com.tencent.mm"),
            workflow = listOf(
                AppAction("com.adobe.scan", "scan_document"),
                AppAction("com.microsoft.office.word", "edit_document"),
                AppAction("com.tencent.mm", "send_file")
            ),
            dataFlow = mapOf(
                "scanned_doc" to DataTransfer(
                    sourceApp = "com.adobe.scan",
                    targetApp = "com.microsoft.office.word",
                    dataType = DataType.FILE,
                    data = "",
                    transferMethod = TransferMethod.FILE_TRANSFER
                )
            )
        )
    )
    
    // 状态管理
    private val _currentState = MutableStateFlow(CoordinationState.IDLE)
    val currentState = _currentState.asStateFlow()
    
    private val _currentTask = MutableStateFlow<CrossAppTask?>(null)
    val currentTask = _currentTask.asStateFlow()
    
    // 执行上下文
    private var executionScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private val dataStore = mutableMapOf<String, Any>()
    private val appStateHistory = mutableListOf<AppState>()
    
    /**
     * 应用状态
     */
    data class AppState(
        val packageName: String,
        val activityName: String,
        val timestamp: Long,
        val screenState: ScreenAnalyzer.ScreenState?
    )
    
    /**
     * 执行跨应用任务
     */
    suspend fun executeTask(
        taskName: String,
        parameters: Map<String, String> = emptyMap()
    ): ExecutionResult {
        LogManager.i(TAG, "开始执行跨应用任务: $taskName")
        
        // 获取任务定义
        val task = predefinedWorkflows[taskName] ?: createCustomTask(taskName, parameters)
        
        _currentTask.value = task
        _currentState.value = CoordinationState.PLANNING
        
        val startTime = System.currentTimeMillis()
        var completedSteps = 0
        val errors = mutableListOf<String>()
        
        try {
            // 验证应用可用性
            if (!verifyAppsAvailable(task.apps)) {
                return ExecutionResult(
                    success = false,
                    completedSteps = 0,
                    totalSteps = task.workflow.size,
                    errors = listOf("部分应用未安装或不可用")
                )
            }
            
            // 执行工作流
            for ((index, action) in task.workflow.withIndex()) {
                _currentState.value = CoordinationState.EXECUTING
                LogManager.i(TAG, "执行步骤 ${index + 1}/${task.workflow.size}: ${action.action}")
                
                // 切换到目标应用
                if (action.app != getCurrentApp()) {
                    _currentState.value = CoordinationState.SWITCHING_APP
                    val switchSuccess = switchToApp(action.app)
                    if (!switchSuccess) {
                        errors.add("无法切换到应用: ${action.app}")
                        break
                    }
                }
                
                // 执行动作
                val actionResult = executeAppAction(action)
                if (!actionResult.success) {
                    errors.add("动作执行失败: ${action.action}")
                    if (action.expectedResult != null) {
                        break // 必须成功的步骤失败，终止执行
                    }
                }
                
                // 处理数据传输
                task.dataFlow.values
                    .filter { it.sourceApp == action.app }
                    .forEach { transfer ->
                        _currentState.value = CoordinationState.TRANSFERRING_DATA
                        transferData(transfer)
                    }
                
                completedSteps++
                
                // 延迟等待UI更新
                delay(500)
            }
            
            _currentState.value = CoordinationState.COMPLETED
            
            return ExecutionResult(
                success = errors.isEmpty(),
                completedSteps = completedSteps,
                totalSteps = task.workflow.size,
                results = dataStore.toMap(),
                errors = errors,
                executionTime = System.currentTimeMillis() - startTime
            )
            
        } catch (e: Exception) {
            LogManager.e(TAG, "任务执行异常", e)
            _currentState.value = CoordinationState.FAILED
            
            return ExecutionResult(
                success = false,
                completedSteps = completedSteps,
                totalSteps = task.workflow.size,
                errors = errors + listOf(e.message ?: "未知错误"),
                executionTime = System.currentTimeMillis() - startTime
            )
        } finally {
            _currentTask.value = null
            _currentState.value = CoordinationState.IDLE
        }
    }
    
    /**
     * 创建应用间数据管道
     */
    fun createDataPipeline(
        sourceApp: String,
        targetApp: String,
        dataType: DataType,
        transformFunction: ((Any) -> Any)? = null
    ): DataPipeline {
        return DataPipeline(
            source = sourceApp,
            target = targetApp,
            dataType = dataType,
            transformer = transformFunction
        )
    }
    
    /**
     * 数据管道
     */
    inner class DataPipeline(
        val source: String,
        val target: String,
        val dataType: DataType,
        val transformer: ((Any) -> Any)?
    ) {
        suspend fun transfer(data: Any): Boolean {
            try {
                // 从源应用获取数据
                val sourceData = extractDataFromApp(source, dataType, data)
                
                // 转换数据
                val transformedData = transformer?.invoke(sourceData) ?: sourceData
                
                // 传输到目标应用
                return injectDataToApp(target, dataType, transformedData)
            } catch (e: Exception) {
                LogManager.e(TAG, "数据管道传输失败", e)
                return false
            }
        }
    }
    
    /**
     * 智能场景编排
     */
    fun orchestrateScenario(scenario: String): ScenarioOrchestration {
        return when (scenario) {
            "morning_routine" -> createMorningRoutineScenario()
            "travel_planning" -> createTravelPlanningScenario()
            "work_productivity" -> createWorkProductivityScenario()
            else -> createCustomScenario(scenario)
        }
    }
    
    /**
     * 场景编排
     */
    data class ScenarioOrchestration(
        val name: String,
        val description: String,
        val steps: List<ScenarioStep>,
        val triggers: List<Trigger>,
        val conditions: List<Condition>
    )
    
    /**
     * 场景步骤
     */
    data class ScenarioStep(
        val order: Int,
        val action: String,
        val app: String,
        val waitForCompletion: Boolean = true,
        val fallbackAction: String? = null
    )
    
    /**
     * 触发器
     */
    sealed class Trigger {
        data class Time(val hour: Int, val minute: Int) : Trigger()
        data class Location(val latitude: Double, val longitude: Double, val radius: Float) : Trigger()
        data class Event(val eventName: String) : Trigger()
        data class AppState(val app: String, val state: String) : Trigger()
    }
    
    /**
     * 条件
     */
    sealed class Condition {
        data class Battery(val minLevel: Int) : Condition()
        data class Network(val type: String) : Condition()
        data class TimeRange(val start: Int, val end: Int) : Condition()
        data class AppInstalled(val packageName: String) : Condition()
    }
    
    // ==================== 私有方法 ====================
    
    /**
     * 验证应用可用性
     */
    private fun verifyAppsAvailable(apps: List<String>): Boolean {
        return apps.all { app ->
            try {
                context.packageManager.getPackageInfo(app, 0)
                true
            } catch (e: Exception) {
                LogManager.w(TAG, "应用未安装: $app")
                false
            }
        }
    }
    
    /**
     * 获取当前应用
     */
    private fun getCurrentApp(): String {
        val accessibilityService = EnhancedAccessibilityService.getInstance()
        return accessibilityService?.rootInActiveWindow?.packageName?.toString() ?: ""
    }
    
    /**
     * 切换到应用
     */
    private suspend fun switchToApp(packageName: String): Boolean {
        return withTimeoutOrNull(APP_SWITCH_TIMEOUT) {
            val accessibilityService = EnhancedAccessibilityService.getInstance()
            accessibilityService?.launchApp(packageName) ?: false
        } ?: false
    }
    
    /**
     * 执行应用动作
     */
    private suspend fun executeAppAction(action: AppAction): ActionResult {
        val accessibilityService = EnhancedAccessibilityService.getInstance()
            ?: return ActionResult(false, "无障碍服务不可用")
        
        return try {
            withTimeout(action.timeout) {
                when (action.action) {
                    "copy_content" -> {
                        // 复制内容到剪贴板
                        copyToClipboard(action.parameters["content"] ?: "")
                        ActionResult(true)
                    }
                    
                    "search_product" -> {
                        val query = action.parameters["query"] ?: ""
                        accessibilityService.smartClick("搜索")
                        delay(1000)
                        accessibilityService.smartInputText(query)
                        delay(500)
                        accessibilityService.smartClick("搜索")
                        ActionResult(true)
                    }
                    
                    "get_price" -> {
                        // 获取价格信息
                        val priceElement = findPriceElement()
                        if (priceElement != null) {
                            dataStore["price_${action.app}"] = priceElement
                            ActionResult(true, priceElement)
                        } else {
                            ActionResult(false, "未找到价格信息")
                        }
                    }
                    
                    "share" -> {
                        val shareType = action.parameters["type"] ?: "default"
                        accessibilityService.smartClick("分享")
                        delay(1000)
                        when (shareType) {
                            "moment" -> accessibilityService.smartClick("朋友圈")
                            "qzone" -> accessibilityService.smartClick("QQ空间")
                            else -> accessibilityService.smartClick("发送")
                        }
                        ActionResult(true)
                    }
                    
                    else -> {
                        // 通用动作处理
                        ActionResult(false, "未知动作: ${action.action}")
                    }
                }
            }
        } catch (e: TimeoutCancellationException) {
            ActionResult(false, "动作超时")
        } catch (e: Exception) {
            ActionResult(false, e.message ?: "执行失败")
        }
    }
    
    /**
     * 动作结果
     */
    data class ActionResult(
        val success: Boolean,
        val data: String? = null
    )
    
    /**
     * 传输数据
     */
    private suspend fun transferData(transfer: DataTransfer) {
        LogManager.i(TAG, "传输数据: ${transfer.sourceApp} -> ${transfer.targetApp}")
        
        when (transfer.transferMethod) {
            TransferMethod.CLIPBOARD -> {
                // 通过剪贴板传输
                copyToClipboard(transfer.data)
                delay(500)
                pasteFromClipboard()
            }
            
            TransferMethod.SHARE_INTENT -> {
                // 通过分享意图传输
                shareViaIntent(transfer.data, transfer.dataType)
            }
            
            TransferMethod.FILE_TRANSFER -> {
                // 文件传输
                transferFile(transfer.data)
            }
            
            TransferMethod.DIRECT_INPUT -> {
                // 直接输入
                val accessibilityService = EnhancedAccessibilityService.getInstance()
                accessibilityService?.smartInputText(transfer.data)
            }
            
            TransferMethod.QR_CODE -> {
                // 二维码传输
                generateAndScanQR(transfer.data)
            }
            
            TransferMethod.DEEP_LINK -> {
                // 深度链接
                openDeepLink(transfer.data)
            }
        }
    }
    
    /**
     * 创建自定义任务
     */
    private fun createCustomTask(
        taskName: String,
        parameters: Map<String, String>
    ): CrossAppTask {
        // 根据任务名称和参数动态创建任务
        return CrossAppTask(
            id = "custom_${System.currentTimeMillis()}",
            name = taskName,
            apps = parameters["apps"]?.split(",") ?: emptyList(),
            workflow = parseWorkflow(parameters["workflow"] ?: ""),
            dataFlow = emptyMap()
        )
    }
    
    /**
     * 解析工作流
     */
    private fun parseWorkflow(workflowString: String): List<AppAction> {
        // 简单的工作流解析
        return workflowString.split(";").map { step ->
            val parts = step.split(":")
            AppAction(
                app = parts.getOrNull(0) ?: "",
                action = parts.getOrNull(1) ?: "",
                parameters = parseParameters(parts.getOrNull(2))
            )
        }
    }
    
    /**
     * 解析参数
     */
    private fun parseParameters(paramString: String?): Map<String, String> {
        if (paramString == null) return emptyMap()
        
        return paramString.split(",").associate { param ->
            val kv = param.split("=")
            kv[0] to kv.getOrElse(1) { "" }
        }
    }
    
    /**
     * 从应用提取数据
     */
    private suspend fun extractDataFromApp(
        app: String,
        dataType: DataType,
        identifier: Any
    ): Any {
        // 实现数据提取逻辑
        return when (dataType) {
            DataType.TEXT -> extractText(app, identifier.toString())
            DataType.IMAGE -> extractImage(app, identifier.toString())
            DataType.FILE -> extractFile(app, identifier.toString())
            else -> identifier
        }
    }
    
    /**
     * 向应用注入数据
     */
    private suspend fun injectDataToApp(
        app: String,
        dataType: DataType,
        data: Any
    ): Boolean {
        // 实现数据注入逻辑
        return try {
            switchToApp(app)
            delay(1000)
            
            when (dataType) {
                DataType.TEXT -> {
                    val accessibilityService = EnhancedAccessibilityService.getInstance()
                    accessibilityService?.smartInputText(data.toString()) ?: false
                }
                else -> false
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "数据注入失败", e)
            false
        }
    }
    
    /**
     * 创建早晨例程场景
     */
    private fun createMorningRoutineScenario(): ScenarioOrchestration {
        return ScenarioOrchestration(
            name = "早晨例程",
            description = "自动执行早晨的常规任务",
            steps = listOf(
                ScenarioStep(1, "check_weather", "com.android.weather", true),
                ScenarioStep(2, "read_news", "com.tencent.news", false),
                ScenarioStep(3, "check_calendar", "com.google.android.calendar", true),
                ScenarioStep(4, "play_music", "com.netease.cloudmusic", false)
            ),
            triggers = listOf(
                Trigger.Time(7, 0),
                Trigger.Event("alarm_dismissed")
            ),
            conditions = listOf(
                Condition.Battery(30),
                Condition.TimeRange(6, 9)
            )
        )
    }
    
    /**
     * 创建旅行规划场景
     */
    private fun createTravelPlanningScenario(): ScenarioOrchestration {
        return ScenarioOrchestration(
            name = "旅行规划",
            description = "协调多个应用完成旅行规划",
            steps = listOf(
                ScenarioStep(1, "search_flights", "com.ctrip.app", true),
                ScenarioStep(2, "book_hotel", "com.booking", true),
                ScenarioStep(3, "plan_route", "com.google.android.apps.maps", true),
                ScenarioStep(4, "save_to_calendar", "com.google.android.calendar", true)
            ),
            triggers = listOf(
                Trigger.Event("travel_planning_requested")
            ),
            conditions = listOf(
                Condition.Network("wifi"),
                Condition.Battery(50)
            )
        )
    }
    
    /**
     * 创建工作效率场景
     */
    private fun createWorkProductivityScenario(): ScenarioOrchestration {
        return ScenarioOrchestration(
            name = "工作效率",
            description = "优化工作流程",
            steps = listOf(
                ScenarioStep(1, "check_emails", "com.google.android.gm", true),
                ScenarioStep(2, "update_tasks", "com.todoist", true),
                ScenarioStep(3, "sync_documents", "com.google.android.apps.docs", false),
                ScenarioStep(4, "start_focus_mode", "com.focuskeeper", true)
            ),
            triggers = listOf(
                Trigger.Time(9, 0),
                Trigger.Location(0.0, 0.0, 100f) // 办公室位置
            ),
            conditions = listOf(
                Condition.TimeRange(9, 18),
                Condition.Battery(20)
            )
        )
    }
    
    /**
     * 创建自定义场景
     */
    private fun createCustomScenario(scenario: String): ScenarioOrchestration {
        return ScenarioOrchestration(
            name = scenario,
            description = "自定义场景",
            steps = emptyList(),
            triggers = emptyList(),
            conditions = emptyList()
        )
    }
    
    // ==================== 辅助方法 ====================
    
    private fun copyToClipboard(text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        val clip = android.content.ClipData.newPlainText("AI Assistant", text)
        clipboard.setPrimaryClip(clip)
    }
    
    private suspend fun pasteFromClipboard() {
        val accessibilityService = EnhancedAccessibilityService.getInstance()
        accessibilityService?.performGlobalAction(
            android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK // 使用BACK代替PASTE，因为PASTE在某些Android版本不可用
        )
    }
    
    private fun shareViaIntent(data: String, dataType: DataType) {
        try {
            val intent = android.content.Intent().apply {
                action = android.content.Intent.ACTION_SEND
                when (dataType) {
                    DataType.TEXT, DataType.URL -> {
                        type = "text/plain"
                        putExtra(android.content.Intent.EXTRA_TEXT, data)
                    }
                    DataType.IMAGE -> {
                        type = "image/*"
                        val uri = android.net.Uri.parse(data)
                        putExtra(android.content.Intent.EXTRA_STREAM, uri)
                    }
                    DataType.FILE -> {
                        type = "*/*"
                        val uri = android.net.Uri.parse(data)
                        putExtra(android.content.Intent.EXTRA_STREAM, uri)
                    }
                    DataType.CONTACT -> {
                        type = "text/x-vcard"
                        putExtra(android.content.Intent.EXTRA_TEXT, data)
                    }
                    DataType.LOCATION -> {
                        type = "text/plain"
                        putExtra(android.content.Intent.EXTRA_TEXT, data)
                    }
                    DataType.STRUCTURED_DATA -> {
                        type = "application/json"
                        putExtra(android.content.Intent.EXTRA_TEXT, data)
                    }
                }
                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val chooser = android.content.Intent.createChooser(intent, "分享到...").apply {
                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
            LogManager.i(TAG, "✅ 通过Intent分享成功: type=$dataType")
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 分享失败", e)
        }
    }
    
    private fun transferFile(filePath: String) {
        try {
            val file = java.io.File(filePath)
            if (!file.exists()) {
                LogManager.e(TAG, "❌ 文件不存在: $filePath")
                return
            }
            
            val uri = androidx.core.content.FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            
            val intent = android.content.Intent().apply {
                action = android.content.Intent.ACTION_SEND
                type = getMimeType(filePath)
                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            
            val chooser = android.content.Intent.createChooser(intent, "传输文件到...").apply {
                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
            LogManager.i(TAG, "✅ 文件传输启动: $filePath")
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 文件传输失败", e)
        }
    }
    
    private fun getMimeType(filePath: String): String {
        val extension = filePath.substringAfterLast('.', "").lowercase()
        return when (extension) {
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "gif" -> "image/gif"
            "pdf" -> "application/pdf"
            "doc", "docx" -> "application/msword"
            "xls", "xlsx" -> "application/vnd.ms-excel"
            "txt" -> "text/plain"
            "mp3" -> "audio/mpeg"
            "mp4" -> "video/mp4"
            "zip" -> "application/zip"
            else -> "*/*"
        }
    }
    
    private fun generateAndScanQR(data: String) {
        try {
            // 尝试调用系统或第三方二维码扫描器
            val scanIntent = android.content.Intent("com.google.zxing.client.android.SCAN").apply {
                putExtra("SCAN_MODE", "QR_CODE_MODE")
            }
            
            // 检查是否有可用的扫描器
            val resolveInfo = context.packageManager.resolveActivity(
                scanIntent, 
                android.content.pm.PackageManager.MATCH_DEFAULT_ONLY
            )
            
            if (resolveInfo != null) {
                scanIntent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(scanIntent)
                LogManager.i(TAG, "✅ 启动二维码扫描器")
            } else {
                // 没有扫描器，将数据复制到剪贴板并提示用户
                copyToClipboard(data)
                LogManager.i(TAG, "⚠️ 未找到二维码扫描器，数据已复制到剪贴板: $data")
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 二维码操作失败", e)
            // 降级处理：复制到剪贴板
            copyToClipboard(data)
        }
    }
    
    private fun openDeepLink(link: String) {
        try {
            val uri = android.net.Uri.parse(link)
            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, uri).apply {
                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            
            // 检查是否有应用可以处理这个链接
            val resolveInfo = context.packageManager.resolveActivity(
                intent,
                android.content.pm.PackageManager.MATCH_DEFAULT_ONLY
            )
            
            if (resolveInfo != null) {
                context.startActivity(intent)
                LogManager.i(TAG, "✅ 打开深度链接成功: $link")
            } else {
                // 没有应用可以处理，尝试用浏览器打开
                val browserIntent = android.content.Intent(android.content.Intent.ACTION_VIEW, uri).apply {
                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    setPackage("com.android.chrome") // 尝试使用Chrome
                }
                try {
                    context.startActivity(browserIntent)
                } catch (e: Exception) {
                    // Chrome不可用，使用默认浏览器
                    browserIntent.setPackage(null)
                    context.startActivity(browserIntent)
                }
                LogManager.i(TAG, "✅ 通过浏览器打开链接: $link")
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 打开深度链接失败: $link", e)
        }
    }
    
    private fun findPriceElement(): String? {
        try {
            val accessibilityService = EnhancedAccessibilityService.getInstance()
            val rootNode = accessibilityService?.rootInActiveWindow ?: return null
            
            // 查找包含价格特征的文本节点
            val pricePatterns = listOf(
                Regex("¥\\s*\\d+(\\.\\d{1,2})?"),
                Regex("￥\\s*\\d+(\\.\\d{1,2})?"),
                Regex("\\d+\\.\\d{2}\\s*元"),
                Regex("\$\\s*\\d+(\\.\\d{1,2})?"),
                Regex("价格[:：]?\\s*\\d+")
            )
            
            fun searchNode(node: android.view.accessibility.AccessibilityNodeInfo): String? {
                val text = node.text?.toString() ?: ""
                val desc = node.contentDescription?.toString() ?: ""
                
                for (pattern in pricePatterns) {
                    pattern.find(text)?.let { return it.value }
                    pattern.find(desc)?.let { return it.value }
                }
                
                for (i in 0 until node.childCount) {
                    node.getChild(i)?.let { child ->
                        searchNode(child)?.let { return it }
                        child.recycle()
                    }
                }
                return null
            }
            
            val result = searchNode(rootNode)
            rootNode.recycle()
            return result
        } catch (e: Exception) {
            LogManager.e(TAG, "查找价格元素失败", e)
            return null
        }
    }
    
    private fun extractText(app: String, identifier: String): String {
        try {
            val accessibilityService = EnhancedAccessibilityService.getInstance()
            val rootNode = accessibilityService?.rootInActiveWindow ?: return ""
            
            fun searchNode(node: android.view.accessibility.AccessibilityNodeInfo): String? {
                // 检查节点ID或文本是否匹配
                val viewId = node.viewIdResourceName ?: ""
                val text = node.text?.toString() ?: ""
                val desc = node.contentDescription?.toString() ?: ""
                
                if (viewId.contains(identifier, ignoreCase = true) ||
                    text.contains(identifier, ignoreCase = true) ||
                    desc.contains(identifier, ignoreCase = true)) {
                    return text.ifEmpty { desc }
                }
                
                for (i in 0 until node.childCount) {
                    node.getChild(i)?.let { child ->
                        searchNode(child)?.let { return it }
                        child.recycle()
                    }
                }
                return null
            }
            
            val result = searchNode(rootNode) ?: ""
            rootNode.recycle()
            LogManager.i(TAG, "提取文本[$identifier]: $result")
            return result
        } catch (e: Exception) {
            LogManager.e(TAG, "提取文本失败: $identifier", e)
            return ""
        }
    }
    
    private fun extractImage(app: String, identifier: String): ByteArray {
        try {
            // 图片提取需要截图功能配合
            // 这里返回空数组，实际应该与ScreenCaptureService配合
            LogManager.i(TAG, "图片提取请求: app=$app, identifier=$identifier")
            LogManager.w(TAG, "⚠️ 图片提取需要截图权限，请确保已启用MediaProjection")
            return ByteArray(0)
        } catch (e: Exception) {
            LogManager.e(TAG, "提取图片失败", e)
            return ByteArray(0)
        }
    }
    
    private fun extractFile(app: String, identifier: String): String {
        try {
            // 尝试从常见目录查找文件
            val searchDirs = listOf(
                android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS),
                android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOCUMENTS),
                android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_PICTURES),
                context.getExternalFilesDir(null)
            )
            
            for (dir in searchDirs) {
                if (dir == null || !dir.exists()) continue
                
                val files = dir.listFiles { file ->
                    file.name.contains(identifier, ignoreCase = true)
                } ?: continue
                
                if (files.isNotEmpty()) {
                    val foundFile = files.first()
                    LogManager.i(TAG, "✅ 找到文件: ${foundFile.absolutePath}")
                    return foundFile.absolutePath
                }
            }
            
            LogManager.w(TAG, "⚠️ 未找到匹配的文件: $identifier")
            return ""
        } catch (e: Exception) {
            LogManager.e(TAG, "提取文件路径失败", e)
            return ""
        }
    }
    
    /**
     * 释放资源
     */
    fun release() {
        executionScope.cancel()
        dataStore.clear()
        appStateHistory.clear()
        LogManager.i(TAG, "跨应用协调器已释放")
    }
}
