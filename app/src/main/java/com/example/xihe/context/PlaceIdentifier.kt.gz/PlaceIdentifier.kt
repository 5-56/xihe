package com.example.xihe.context

import android.content.Context
import android.location.Address
import android.location.Geocoder
import android.location.Location
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.*

/**
 * 🏢 地点识别器
 * 使用地理编码和POI数据库识别用户所在位置类型
 */
class PlaceIdentifier(private val context: Context) {
    
    companion object {
        private const val TAG = "PlaceIdentifier"
    }
    
    private val geocoder = if (Geocoder.isPresent()) {
        Geocoder(context, Locale.getDefault())
    } else {
        null
    }
    
    /**
     * 🔍 识别地点类型
     */
    suspend fun identifyPlace(location: Location): PlaceIdentificationResult = withContext(Dispatchers.IO) {
        try {
            // 1. 使用地理编码获取地址信息
            val addresses = geocoder?.getFromLocation(
                location.latitude,
                location.longitude,
                1
            )
            
            if (addresses.isNullOrEmpty()) {
                LogManager.w(TAG, "⚠️ 无法获取地址信息")
                return@withContext PlaceIdentificationResult(
                    placeType = PlaceType.UNKNOWN,
                    placeName = null,
                    address = null
                )
            }
            
            val address = addresses[0]
            val fullAddress = buildFullAddress(address)
            
            LogManager.w(TAG, "📍 地址: $fullAddress")
            
            // 2. 根据地址信息推断地点类型
            val placeType = inferPlaceType(address)
            val placeName = extractPlaceName(address)
            
            LogManager.w(TAG, "✅ 识别结果: $placeType - $placeName")
            
            PlaceIdentificationResult(
                placeType = placeType,
                placeName = placeName,
                address = fullAddress
            )
        } catch (e: Exception) {
            LogManager.w(TAG, "❌ 地点识别失败", e)
            PlaceIdentificationResult(
                placeType = PlaceType.UNKNOWN,
                placeName = null,
                address = null
            )
        }
    }
    
    /**
     * 🧠 推断地点类型
     */
    private fun inferPlaceType(address: Address): PlaceType {
        val featureName = address.featureName?.lowercase() ?: ""
        val thoroughfare = address.thoroughfare?.lowercase() ?: ""
        val subThoroughfare = address.subThoroughfare?.lowercase() ?: ""
        val premises = address.premises?.lowercase() ?: ""
        
        // 组合所有地址信息用于分析
        val combinedInfo = "$featureName $thoroughfare $subThoroughfare $premises"
        
        LogManager.w(TAG, "🔍 分析地址: $combinedInfo")
        
        // 机场关键词
        val airportKeywords = listOf(
            "airport", "机场", "航站楼", "terminal", "t1", "t2", "t3",
            "首都国际机场", "浦东机场", "虹桥机场", "白云机场"
        )
        if (airportKeywords.any { combinedInfo.contains(it) }) {
            return PlaceType.AIRPORT
        }
        
        // 火车站关键词
        val trainStationKeywords = listOf(
            "railway", "station", "火车站", "高铁站", "动车站",
            "北京站", "上海站", "广州站", "南站", "西站", "东站"
        )
        if (trainStationKeywords.any { combinedInfo.contains(it) }) {
            return PlaceType.TRAIN_STATION
        }
        
        // 医院关键词
        val hospitalKeywords = listOf(
            "hospital", "医院", "诊所", "clinic", "卫生院",
            "人民医院", "中医院", "妇幼", "儿童医院"
        )
        if (hospitalKeywords.any { combinedInfo.contains(it) }) {
            return PlaceType.HOSPITAL
        }
        
        // 学校关键词
        val schoolKeywords = listOf(
            "school", "university", "college", "学校", "大学",
            "中学", "小学", "幼儿园", "kindergarten"
        )
        if (schoolKeywords.any { combinedInfo.contains(it) }) {
            return PlaceType.SCHOOL
        }
        
        // 购物中心关键词
        val mallKeywords = listOf(
            "mall", "shopping", "商场", "购物中心", "百货",
            "万达", "银泰", "大悦城"
        )
        if (mallKeywords.any { combinedInfo.contains(it) }) {
            return PlaceType.SHOPPING_MALL
        }
        
        // 健身房关键词
        val gymKeywords = listOf(
            "gym", "fitness", "健身", "健身房", "健身中心",
            "运动", "体育馆", "游泳馆"
        )
        if (gymKeywords.any { combinedInfo.contains(it) }) {
            return PlaceType.GYM
        }
        
        // 餐厅关键词
        val restaurantKeywords = listOf(
            "restaurant", "餐厅", "饭店", "食堂", "美食",
            "火锅", "烧烤", "快餐"
        )
        if (restaurantKeywords.any { combinedInfo.contains(it) }) {
            return PlaceType.RESTAURANT
        }
        
        // 公园关键词
        val parkKeywords = listOf(
            "park", "公园", "森林公园", "湿地", "广场"
        )
        if (parkKeywords.any { combinedInfo.contains(it) }) {
            return PlaceType.PARK
        }
        
        // 办公楼关键词
        val officeKeywords = listOf(
            "office", "building", "tower", "大厦", "写字楼",
            "科技园", "产业园", "商务中心"
        )
        if (officeKeywords.any { combinedInfo.contains(it) }) {
            return PlaceType.OFFICE
        }
        
        // 默认根据地址类型判断
        return when {
            address.maxAddressLineIndex >= 0 -> {
                // 有详细地址，可能是住宅或办公
                if (combinedInfo.contains("小区") || combinedInfo.contains("号楼")) {
                    PlaceType.HOME
                } else {
                    PlaceType.UNKNOWN
                }
            }
            else -> PlaceType.UNKNOWN
        }
    }
    
    /**
     * 📝 提取地点名称
     */
    private fun extractPlaceName(address: Address): String? {
        // 优先使用featureName（POI名称）
        address.featureName?.let {
            if (it.isNotBlank() && it != address.thoroughfare) {
                return it
            }
        }
        
        // 其次使用premises（建筑物名称）
        address.premises?.let {
            if (it.isNotBlank()) {
                return it
            }
        }
        
        // 最后使用道路名称
        address.thoroughfare?.let {
            if (it.isNotBlank()) {
                return it
            }
        }
        
        return null
    }
    
    /**
     * 📝 构建完整地址
     */
    private fun buildFullAddress(address: Address): String {
        val parts = mutableListOf<String>()
        
        // 城市
        address.locality?.let { parts.add(it) }
        
        // 区域
        address.subLocality?.let { parts.add(it) }
        
        // 道路
        address.thoroughfare?.let { parts.add(it) }
        
        // 门牌号
        address.subThoroughfare?.let { parts.add(it) }
        
        // 建筑物
        address.premises?.let { parts.add(it) }
        
        // POI名称
        address.featureName?.let {
            if (it != address.thoroughfare && it != address.premises) {
                parts.add(it)
            }
        }
        
        return parts.joinToString(" ")
    }
    
    /**
     * 🏠 检查是否在家（需要用户预设家的位置）
     */
    fun isAtHome(location: Location, homeLocation: Location?, radiusMeters: Float = 100f): Boolean {
        homeLocation ?: return false
        
        val distance = location.distanceTo(homeLocation)
        return distance <= radiusMeters
    }
    
    /**
     * 🏢 检查是否在办公室（需要用户预设办公室位置）
     */
    fun isAtOffice(location: Location, officeLocation: Location?, radiusMeters: Float = 100f): Boolean {
        officeLocation ?: return false
        
        val distance = location.distanceTo(officeLocation)
        return distance <= radiusMeters
    }
}

/**
 * 📊 地点识别结果
 */
data class PlaceIdentificationResult(
    val placeType: PlaceType,
    val placeName: String?,
    val address: String?
)
