package com.example.xihe.context

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import com.example.xihe.utils.LogManager
import com.google.android.gms.location.ActivityRecognition
import com.google.android.gms.location.ActivityTransition
import com.google.android.gms.location.ActivityTransitionRequest
import com.google.android.gms.location.DetectedActivity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * 🚶 活动识别管理器
 * 使用Google Play Services的Activity Recognition API识别用户活动状态
 */
class ActivityRecognitionManager(private val context: Context) {
    
    companion object {
        private const val TAG = "ActivityRecognition"
        private const val ACTION_ACTIVITY_TRANSITION = "com.example.xihe.ACTIVITY_TRANSITION"
        
        @Volatile
        private var instance: ActivityRecognitionManager? = null
        
        fun getInstance(context: Context): ActivityRecognitionManager {
            return instance ?: synchronized(this) {
                instance ?: ActivityRecognitionManager(context.applicationContext).also { 
                    instance = it 
                }
            }
        }
    }
    
    // 当前活动状态
    private val _currentActivity = MutableStateFlow<ActivityType>(ActivityType.UNKNOWN)
    val currentActivity = _currentActivity.asStateFlow()
    
    // 活动置信度
    private val _confidence = MutableStateFlow(0)
    val confidence = _confidence.asStateFlow()
    
    // 是否正在监控
    private var isMonitoring = false
    
    // 广播接收器
    private val activityReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == ACTION_ACTIVITY_TRANSITION) {
                handleActivityUpdate(intent)
            }
        }
    }
    
    /**
     * 🚀 启动活动识别
     */
    fun startActivityRecognition() {
        if (isMonitoring) {
            LogManager.w(TAG, "⚠️ 活动识别已在运行")
            return
        }
        
        try {
            LogManager.w(TAG, "🚀 启动活动识别")
            
            // 注册广播接收器
            val filter = IntentFilter(ACTION_ACTIVITY_TRANSITION)
            context.registerReceiver(activityReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            
            // 请求活动更新
            requestActivityUpdates()
            
            isMonitoring = true
            LogManager.w(TAG, "✅ 活动识别已启动")
        } catch (e: Exception) {
            LogManager.w(TAG, "❌ 启动活动识别失败", e)
        }
    }
    
    /**
     * 🛑 停止活动识别
     */
    fun stopActivityRecognition() {
        if (!isMonitoring) return
        
        try {
            LogManager.w(TAG, "🛑 停止活动识别")
            
            // 取消注册广播接收器
            context.unregisterReceiver(activityReceiver)
            
            // 移除活动更新
            removeActivityUpdates()
            
            isMonitoring = false
            LogManager.w(TAG, "✅ 活动识别已停止")
        } catch (e: Exception) {
            LogManager.w(TAG, "❌ 停止活动识别失败", e)
        }
    }
    
    /**
     * 📡 请求活动更新
     */
    private fun requestActivityUpdates() {
        try {
            val client = ActivityRecognition.getClient(context)
            val intent = Intent(ACTION_ACTIVITY_TRANSITION)
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            
            // 请求活动转换更新
            val transitions = buildTransitionList()
            val request = ActivityTransitionRequest(transitions)
            
            client.requestActivityTransitionUpdates(request, pendingIntent)
                .addOnSuccessListener {
                    LogManager.w(TAG, "✅ 活动转换监听已启动")
                }
                .addOnFailureListener { e ->
                    LogManager.w(TAG, "❌ 启动活动转换监听失败", e)
                    // 降级到定期更新模式
                    requestPeriodicUpdates(client, pendingIntent)
                }
        } catch (e: Exception) {
            LogManager.w(TAG, "❌ 请求活动更新失败", e)
        }
    }
    
    /**
     * 📡 请求定期更新（降级方案）
     */
    private fun requestPeriodicUpdates(
        client: com.google.android.gms.location.ActivityRecognitionClient,
        pendingIntent: PendingIntent
    ) {
        try {
            // 每30秒更新一次
            client.requestActivityUpdates(30_000, pendingIntent)
                .addOnSuccessListener {
                    LogManager.w(TAG, "✅ 定期活动更新已启动")
                }
                .addOnFailureListener { e ->
                    LogManager.w(TAG, "❌ 启动定期更新失败", e)
                }
        } catch (e: Exception) {
            LogManager.w(TAG, "❌ 请求定期更新失败", e)
        }
    }
    
    /**
     * 🗑️ 移除活动更新
     */
    private fun removeActivityUpdates() {
        try {
            val client = ActivityRecognition.getClient(context)
            val intent = Intent(ACTION_ACTIVITY_TRANSITION)
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            
            client.removeActivityTransitionUpdates(pendingIntent)
                .addOnSuccessListener {
                    LogManager.w(TAG, "✅ 活动转换监听已移除")
                }
                .addOnFailureListener { e ->
                    LogManager.w(TAG, "❌ 移除活动转换监听失败", e)
                }
        } catch (e: Exception) {
            LogManager.w(TAG, "❌ 移除活动更新失败", e)
        }
    }
    
    /**
     * 🔨 构建活动转换列表
     */
    private fun buildTransitionList(): List<ActivityTransition> {
        val transitions = mutableListOf<ActivityTransition>()
        
        val activities = listOf(
            DetectedActivity.STILL,
            DetectedActivity.WALKING,
            DetectedActivity.RUNNING,
            DetectedActivity.ON_BICYCLE,
            DetectedActivity.IN_VEHICLE
        )
        
        for (activity in activities) {
            transitions.add(
                ActivityTransition.Builder()
                    .setActivityType(activity)
                    .setActivityTransition(ActivityTransition.ACTIVITY_TRANSITION_ENTER)
                    .build()
            )
            
            transitions.add(
                ActivityTransition.Builder()
                    .setActivityType(activity)
                    .setActivityTransition(ActivityTransition.ACTIVITY_TRANSITION_EXIT)
                    .build()
            )
        }
        
        return transitions
    }
    
    /**
     * 🎯 处理活动更新
     */
    private fun handleActivityUpdate(intent: Intent) {
        try {
            // 尝试解析活动结果
            if (intent.hasExtra("activity_type")) {
                val activityType = intent.getIntExtra("activity_type", DetectedActivity.UNKNOWN)
                val confidence = intent.getIntExtra("confidence", 0)
                
                val mappedActivity = mapDetectedActivity(activityType)
                
                LogManager.w(TAG, "📊 活动更新: $mappedActivity (置信度: $confidence%)")
                
                _currentActivity.value = mappedActivity
                _confidence.value = confidence
            }
        } catch (e: Exception) {
            LogManager.w(TAG, "❌ 处理活动更新失败", e)
        }
    }
    
    /**
     * 🗺️ 映射检测到的活动类型
     */
    private fun mapDetectedActivity(activityType: Int): ActivityType {
        return when (activityType) {
            DetectedActivity.STILL -> ActivityType.STILL
            DetectedActivity.WALKING -> ActivityType.WALKING
            DetectedActivity.RUNNING -> ActivityType.RUNNING
            DetectedActivity.ON_BICYCLE -> ActivityType.CYCLING
            DetectedActivity.IN_VEHICLE -> ActivityType.IN_VEHICLE
            else -> ActivityType.UNKNOWN
        }
    }
    
    /**
     * 📊 手动更新活动（用于测试或模拟）
     */
    fun updateActivity(activityType: ActivityType, confidence: Int) {
        LogManager.w(TAG, "🔄 手动更新活动: $activityType (置信度: $confidence%)")
        _currentActivity.value = activityType
        _confidence.value = confidence
    }
}
