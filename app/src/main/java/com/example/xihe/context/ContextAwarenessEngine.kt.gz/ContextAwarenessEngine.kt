package com.example.xihe.context

import android.Manifest
import android.app.ActivityManager
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import com.example.xihe.utils.LogManager
import androidx.core.app.ActivityCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.*

/**
 * 🧠 情境感知引擎
 * 检测用户所处的环境、位置、时间等信息，为主动对话提供依据
 */
class ContextAwarenessEngine(private val context: Context) {
    
    companion object {
        private const val TAG = "ContextAwareness"
        
        @Volatile
        private var instance: ContextAwarenessEngine? = null
        
        fun getInstance(context: Context): ContextAwarenessEngine {
            return instance ?: synchronized(this) {
                instance ?: ContextAwarenessEngine(context.applicationContext).also { instance = it }
            }
        }
    }
    
    // 🆕 增强的检测工具
    private val placeIdentifier = PlaceIdentifier(context)
    private val activityRecognition = ActivityRecognitionManager.getInstance(context)
    
    // 🌍 当前情境状态
    private val _currentContext = MutableStateFlow<UserContext>(UserContext())
    val currentContext = _currentContext.asStateFlow()
    
    // 🎯 情境变化监听器
    private val contextChangeListeners = mutableListOf<(UserContext) -> Unit>()
    
    // 🔄 监控任务
    private var monitoringJob: Job? = null
    private var isMonitoring = false
    
    // 📊 历史记录
    private val contextHistory = mutableListOf<ContextSnapshot>()
    private val maxHistorySize = 100
    
    // 💡 光线传感器
    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private val lightSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_LIGHT)
    private var currentLightLevel = 0f
    private val lightSensorListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent?) {
            event?.let {
                currentLightLevel = it.values[0]
            }
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }
    
    /**
     * 🚀 启动情境监控
     */
    fun startMonitoring() {
        if (isMonitoring) {
            LogManager.w(TAG, "⚠️ 情境监控已在运行中")
            return
        }
        
        LogManager.i(TAG, "🚀 启动情境感知引擎")
        isMonitoring = true
        
        // 🆕 启动活动识别
        try {
            activityRecognition.startActivityRecognition()
            LogManager.d(TAG, "✅ 活动识别已启动")
        } catch (e: Exception) {
            LogManager.e(TAG, "⚠️ 活动识别启动失败", e)
        }
        
        monitoringJob = CoroutineScope(Dispatchers.Default).launch {
            while (isActive && isMonitoring) {
                try {
                    // 更新情境信息
                    updateContext()
                    
                    // 每30秒检查一次
                    delay(30_000)
                } catch (e: Exception) {
                    LogManager.e(TAG, "❌ 情境更新失败", e)
                    delay(60_000) // 出错后延长间隔
                }
            }
        }
    }
    
    /**
     * 🛑 停止情境监控
     */
    fun stopMonitoring() {
        LogManager.i(TAG, "🛑 停止情境感知引擎")
        isMonitoring = false
        monitoringJob?.cancel()
        monitoringJob = null
        
        // 🛑 停止活动识别
        try {
            activityRecognition.stopActivityRecognition()
            LogManager.d(TAG, "✅ 活动识别已停止")
        } catch (e: Exception) {
            LogManager.e(TAG, "⚠️ 活动识别停止失败", e)
        }
    }
    
    /**
     * 🔄 更新当前情境
     */
    private suspend fun updateContext() = withContext(Dispatchers.Default) {
        val newContext = UserContext(
            timestamp = System.currentTimeMillis(),
            location = detectLocation(),
            timeOfDay = detectTimeOfDay(),
            activity = detectActivity(),
            batteryLevel = detectBatteryLevel(),
            isCharging = detectIsCharging(),
            networkType = detectNetworkType(),
            foregroundApp = detectForegroundApp(),
            screenState = detectScreenState(),
            ambientLight = detectAmbientLight()
        )
        
        val oldContext = _currentContext.value
        _currentContext.value = newContext
        
        // 保存到历史记录
        contextHistory.add(ContextSnapshot(newContext))
        if (contextHistory.size > maxHistorySize) {
            contextHistory.removeAt(0)
        }
        
        // 检测重要变化
        if (hasSignificantChange(oldContext, newContext)) {
            LogManager.d(TAG, "📊 检测到重要情境变化: ${describeChange(oldContext, newContext)}")
            notifyContextChange(newContext)
        }
    }
    
    /**
     * 📍 检测位置信息 (🆕 使用增强的地点识别)
     */
    private suspend fun detectLocation(): LocationInfo? {
        try {
            if (ActivityCompat.checkSelfPermission(
                    context,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                LogManager.d(TAG, "⚠️ 未授予定位权限")
                return null
            }
            
            val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            val lastLocation = locationManager?.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                ?: locationManager?.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            
            return lastLocation?.let { location ->
                // 🆕 使用增强的地点识别器
                val identification = placeIdentifier.identifyPlace(location)
                
                LocationInfo(
                    latitude = location.latitude,
                    longitude = location.longitude,
                    accuracy = location.accuracy,
                    placeType = identification.placeType,
                    placeName = identification.placeName
                )
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "定位检测失败", e)
            return null
        }
    }
    
    /**
     * ⏰ 检测时段
     */
    private fun detectTimeOfDay(): TimeOfDay {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when (hour) {
            in 0..5 -> TimeOfDay.LATE_NIGHT
            in 6..8 -> TimeOfDay.EARLY_MORNING
            in 9..11 -> TimeOfDay.MORNING
            in 12..13 -> TimeOfDay.NOON
            in 14..17 -> TimeOfDay.AFTERNOON
            in 18..20 -> TimeOfDay.EVENING
            in 21..23 -> TimeOfDay.NIGHT
            else -> TimeOfDay.UNKNOWN
        }
    }
    
    /**
     * 🚶 检测用户活动 (🆕 使用Activity Recognition API)
     */
    private fun detectActivity(): ActivityType {
        return try {
            activityRecognition.currentActivity.value
        } catch (e: Exception) {
            LogManager.e(TAG, "活动检测失败", e)
            ActivityType.UNKNOWN
        }
    }
    
    /**
     * 🔋 检测电量
     */
    private fun detectBatteryLevel(): Int {
        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        return batteryManager?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
    }
    
    /**
     * 🔌 检测充电状态
     */
    private fun detectIsCharging(): Boolean {
        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        return batteryManager?.isCharging ?: false
    }
    
    /**
     * 🌐 检测网络类型
     */
    private fun detectNetworkType(): NetworkType {
        try {
            val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                ?: return NetworkType.UNKNOWN
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val network = connectivityManager.activeNetwork ?: return NetworkType.NO_NETWORK
                val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return NetworkType.NO_NETWORK
                
                return when {
                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> NetworkType.WIFI
                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> {
                        // 尝试检测5G/4G/3G
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            // Android 10+ 可以检测下行带宽来推断
                            val downlink = capabilities.linkDownstreamBandwidthKbps
                            when {
                                downlink > 10000 -> NetworkType.MOBILE_5G  // >10Mbps 可能是5G
                                downlink > 1000 -> NetworkType.MOBILE_4G   // >1Mbps 可能是4G
                                else -> NetworkType.MOBILE_3G
                            }
                        } else {
                            NetworkType.MOBILE_4G // 默认4G
                        }
                    }
                    else -> NetworkType.UNKNOWN
                }
            } else {
                // Android 6.0 以下的兼容处理
                @Suppress("DEPRECATION")
                val networkInfo = connectivityManager.activeNetworkInfo
                return if (networkInfo?.isConnected == true) {
                    when (networkInfo.type) {
                        android.net.ConnectivityManager.TYPE_WIFI -> NetworkType.WIFI
                        android.net.ConnectivityManager.TYPE_MOBILE -> NetworkType.MOBILE_4G
                        else -> NetworkType.UNKNOWN
                    }
                } else {
                    NetworkType.NO_NETWORK
                }
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "检测网络类型失败", e)
            return NetworkType.UNKNOWN
        }
    }
    
    /**
     * 📱 检测前台应用
     */
    private fun detectForegroundApp(): String? {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
                    ?: return null
                
                val currentTime = System.currentTimeMillis()
                // 获取过去1秒内的应用使用统计
                val stats = usageStatsManager.queryUsageStats(
                    UsageStatsManager.INTERVAL_DAILY,
                    currentTime - 1000,
                    currentTime
                )
                
                // 找到最近使用的应用
                val recentApp = stats?.maxByOrNull { it.lastTimeUsed }
                return recentApp?.packageName
            } else {
                // Android 5.0 以下使用 ActivityManager (已废弃但可用)
                @Suppress("DEPRECATION")
                val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
                @Suppress("DEPRECATION")
                val tasks = activityManager?.getRunningTasks(1)
                @Suppress("DEPRECATION")
                return tasks?.firstOrNull()?.topActivity?.packageName
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "检测前台应用失败", e)
            return null
        }
    }
    
    /**
     * 📺 检测屏幕状态
     */
    private fun detectScreenState(): DisplayState {
        try {
            val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
                ?: return DisplayState.ON
            
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT_WATCH) {
                if (powerManager.isInteractive) DisplayState.ON else DisplayState.OFF
            } else {
                @Suppress("DEPRECATION")
                if (powerManager.isScreenOn) DisplayState.ON else DisplayState.OFF
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "检测屏幕状态失败", e)
            return DisplayState.ON
        }
    }
    
    /**
     * 💡 检测环境光线
     */
    private fun detectAmbientLight(): AmbientLight {
        try {
            // 如果没有光线传感器，返回正常
            if (lightSensor == null) {
                return AmbientLight.NORMAL
            }
            
            // 根据光线强度判断 (单位: lux)
            return when {
                currentLightLevel < 10 -> AmbientLight.DARK      // <10 lux: 黑暗
                currentLightLevel < 100 -> AmbientLight.DIM      // <100 lux: 暗
                currentLightLevel < 1000 -> AmbientLight.NORMAL  // <1000 lux: 正常
                else -> AmbientLight.BRIGHT                       // >=1000 lux: 明亮
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "检测环境光线失败", e)
            return AmbientLight.NORMAL
        }
    }
    
    /**
     * 🎆 启动光线传感器
     */
    fun startLightSensor() {
        lightSensor?.let {
            sensorManager?.registerListener(
                lightSensorListener,
                it,
                SensorManager.SENSOR_DELAY_NORMAL
            )
            LogManager.d(TAG, "💡 光线传感器已启动")
        }
    }
    
    /**
     * 🚫 停止光线传感器
     */
    fun stopLightSensor() {
        sensorManager?.unregisterListener(lightSensorListener)
        LogManager.d(TAG, "🚫 光线传感器已停止")
    }
    
    /**
     * 🔍 检测是否有重要变化 (🆕 增强版)
     */
    private fun hasSignificantChange(old: UserContext, new: UserContext): Boolean {
        // 位置变化
        if (old.location?.placeType != new.location?.placeType) {
            LogManager.d(TAG, "📍 地点变化: ${old.location?.placeType} → ${new.location?.placeType}")
            return true
        }
        
        // 时段变化
        if (old.timeOfDay != new.timeOfDay) {
            LogManager.d(TAG, "⏰ 时段变化: ${old.timeOfDay} → ${new.timeOfDay}")
            return true
        }
        
        // 活动变化 (🆕 增强)
        if (old.activity != new.activity && new.activity != ActivityType.UNKNOWN) {
            LogManager.d(TAG, "🚶 活动变化: ${old.activity} → ${new.activity}")
            return true
        }
        
        // 电量低
        if (new.batteryLevel in 1..20 && old.batteryLevel > 20) {
            LogManager.d(TAG, "🔋 电量低: ${old.batteryLevel}% → ${new.batteryLevel}%")
            return true
        }
        
        // 开始/停止充电
        if (old.isCharging != new.isCharging) {
            LogManager.d(TAG, "🔌 充电状态变化: ${old.isCharging} → ${new.isCharging}")
            return true
        }
        
        return false
    }
    
    /**
     * 📝 描述情境变化
     */
    private fun describeChange(old: UserContext, new: UserContext): String {
        val changes = mutableListOf<String>()
        
        if (old.location?.placeType != new.location?.placeType) {
            changes.add("地点: ${old.location?.placeType} → ${new.location?.placeType}")
        }
        
        if (old.timeOfDay != new.timeOfDay) {
            changes.add("时段: ${old.timeOfDay} → ${new.timeOfDay}")
        }
        
        if (old.activity != new.activity) {
            changes.add("活动: ${old.activity} → ${new.activity}")
        }
        
        if (old.batteryLevel > 20 && new.batteryLevel <= 20) {
            changes.add("电量低: ${new.batteryLevel}%")
        }
        
        if (old.isCharging != new.isCharging) {
            changes.add("充电: ${if (new.isCharging) "开始" else "停止"}")
        }
        
        return changes.joinToString(", ")
    }
    
    /**
     * 📢 通知情境变化
     */
    private fun notifyContextChange(newContext: UserContext) {
        contextChangeListeners.forEach { listener ->
            try {
                listener(newContext)
            } catch (e: Exception) {
                LogManager.e(TAG, "情境变化通知失败", e)
            }
        }
    }
    
    /**
     * 📝 添加情境变化监听器
     */
    fun addContextChangeListener(listener: (UserContext) -> Unit) {
        contextChangeListeners.add(listener)
    }
    
    /**
     * 🗑️ 移除情境变化监听器
     */
    fun removeContextChangeListener(listener: (UserContext) -> Unit) {
        contextChangeListeners.remove(listener)
    }
    
    /**
     * 📊 获取情境历史
     */
    fun getContextHistory(minutes: Int = 60): List<ContextSnapshot> {
        val cutoffTime = System.currentTimeMillis() - (minutes * 60 * 1000)
        return contextHistory.filter { it.timestamp >= cutoffTime }
    }
}

// ========== 数据类 ==========

/**
 * 👤 用户情境
 */
data class UserContext(
    val timestamp: Long = System.currentTimeMillis(),
    val location: LocationInfo? = null,
    val timeOfDay: TimeOfDay = TimeOfDay.UNKNOWN,
    val activity: ActivityType = ActivityType.UNKNOWN,
    val batteryLevel: Int = -1,
    val isCharging: Boolean = false,
    val networkType: NetworkType = NetworkType.UNKNOWN,
    val foregroundApp: String? = null,
    val screenState: DisplayState = DisplayState.ON,
    val ambientLight: AmbientLight = AmbientLight.NORMAL
)

/**
 * 📍 位置信息
 */
data class LocationInfo(
    val latitude: Double,
    val longitude: Double,
    val accuracy: Float,
    val placeType: PlaceType,
    val placeName: String?
)

/**
 * 📸 情境快照
 */
data class ContextSnapshot(
    val context: UserContext,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * 🏢 地点类型
 */
enum class PlaceType {
    HOME,           // 家
    OFFICE,         // 办公室
    AIRPORT,        // 机场
    TRAIN_STATION,  // 火车站
    RESTAURANT,     // 餐厅
    SHOPPING_MALL,  // 商场
    GYM,            // 健身房
    HOSPITAL,       // 医院
    SCHOOL,         // 学校
    PARK,           // 公园
    TRANSPORT,      // 交通工具中
    UNKNOWN         // 未知
}

/**
 * ⏰ 时段
 */
enum class TimeOfDay {
    LATE_NIGHT,      // 深夜 (0-5)
    EARLY_MORNING,   // 清晨 (6-8)
    MORNING,         // 上午 (9-11)
    NOON,            // 中午 (12-13)
    AFTERNOON,       // 下午 (14-17)
    EVENING,         // 傍晚 (18-20)
    NIGHT,           // 晚上 (21-23)
    UNKNOWN
}

/**
 * 🚶 活动类型
 */
enum class ActivityType {
    STILL,          // 静止
    WALKING,        // 步行
    RUNNING,        // 跑步
    CYCLING,        // 骑行
    IN_VEHICLE,     // 在车内
    UNKNOWN
}

/**
 * 🌐 网络类型
 */
enum class NetworkType {
    WIFI,
    MOBILE_4G,
    MOBILE_5G,
    MOBILE_3G,
    NO_NETWORK,
    UNKNOWN
}

/**
 * 📺 屏幕电源状态
 */
enum class DisplayState {
    ON,
    OFF
}

/**
 * 💡 环境光线
 */
enum class AmbientLight {
    DARK,       // 黑暗
    DIM,        // 昏暗
    NORMAL,     // 正常
    BRIGHT      // 明亮
}
