package com.example.xihe.context

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import com.example.xihe.utils.LogManager
import androidx.core.app.ActivityCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * 环境声音检测器
 * 检测周围环境的声音特征，智能判断用户所处环境
 * 
 * 功能：
 * 1. 检测环境音量大小（安静/正常/嘈杂）
 * 2. 识别环境类型（会议室/教室/户外等）
 * 3. 判断是否适合打扰用户
 */
class AmbientSoundDetector(private val context: Context) {
    
    companion object {
        private const val TAG = "AmbientSoundDetector"
        private const val SAMPLE_RATE = 16000
        private const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
        private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
        
        // 音量阈值 (分贝)
        private const val SILENCE_THRESHOLD = 30.0    // 安静 (<30dB)
        private const val NORMAL_THRESHOLD = 50.0    // 正常 (30-50dB)
        private const val LOUD_THRESHOLD = 70.0      // 嘈杂 (50-70dB)
        // >70dB 非常嘈杂
        
        @Volatile
        private var instance: AmbientSoundDetector? = null
        
        fun getInstance(context: Context): AmbientSoundDetector {
            return instance ?: synchronized(this) {
                instance ?: AmbientSoundDetector(context.applicationContext).also { 
                    instance = it 
                }
            }
        }
    }
    
    // 当前环境声音状态
    private val _soundLevel = MutableStateFlow(SoundLevel.UNKNOWN)
    val soundLevel = _soundLevel.asStateFlow()
    
    // 当前分贝值
    private val _decibelLevel = MutableStateFlow(0.0)
    val decibelLevel = _decibelLevel.asStateFlow()
    
    // 环境类型推测
    private val _environmentType = MutableStateFlow(SoundEnvironment.UNKNOWN)
    val environmentType = _environmentType.asStateFlow()
    
    // 音频录制
    private var audioRecord: AudioRecord? = null
    private var isMonitoring = false
    private val monitoringScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    
    // 历史数据（用于平滑和分析）
    private val decibelHistory = mutableListOf<Double>()
    private val maxHistorySize = 30  // 保留最近30次测量
    
    /**
     * 开始监控环境声音
     */
    fun startMonitoring() {
        if (isMonitoring) {
            LogManager.w(TAG, "声音监控已在运行")
            return
        }
        
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) 
            != PackageManager.PERMISSION_GRANTED) {
            LogManager.w(TAG, "未授予录音权限")
            return
        }
        
        try {
            val bufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT)
            
            // 🎤 优先使用 VOICE_COMMUNICATION 音频源
            // 自动启用回声消除(AEC)和噪音抑制(NS)，避免捕获系统播放的声音
            audioRecord = try {
                AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                    SAMPLE_RATE,
                    CHANNEL_CONFIG,
                    AUDIO_FORMAT,
                    bufferSize
                )
            } catch (e: Exception) {
                LogManager.w(TAG, "VOICE_COMMUNICATION 不可用，回退到 MIC")
                AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    SAMPLE_RATE,
                    CHANNEL_CONFIG,
                    AUDIO_FORMAT,
                    bufferSize
                )
            }
            
            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                LogManager.w(TAG, "AudioRecord 初始化失败")
                return
            }
            
            audioRecord?.startRecording()
            isMonitoring = true
            
            LogManager.w(TAG, "开始环境声音监控")
            
            // 启动监控协程
            monitoringScope.launch {
                val buffer = ShortArray(bufferSize)
                
                while (isActive && isMonitoring) {
                    try {
                        val readSize = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                        
                        if (readSize > 0) {
                            val decibel = calculateDecibel(buffer, readSize)
                            updateSoundLevel(decibel)
                        }
                        
                        // 每秒检测一次
                        delay(1000)
                        
                    } catch (e: Exception) {
                        LogManager.w(TAG, "声音采样失败", e)
                        delay(2000)
                    }
                }
            }
            
        } catch (e: Exception) {
            LogManager.w(TAG, "启动声音监控失败", e)
        }
    }
    
    /**
     * 停止监控
     */
    fun stopMonitoring() {
        if (!isMonitoring) return
        
        LogManager.w(TAG, "停止环境声音监控")
        isMonitoring = false
        
        try {
            audioRecord?.stop()
            audioRecord?.release()
            audioRecord = null
        } catch (e: Exception) {
            LogManager.w(TAG, "停止声音监控失败", e)
        }
    }
    
    /**
     * 计算分贝值
     */
    private fun calculateDecibel(buffer: ShortArray, readSize: Int): Double {
        var sum = 0.0
        for (i in 0 until readSize) {
            sum += buffer[i] * buffer[i]
        }
        
        val amplitude = kotlin.math.sqrt(sum / readSize)
        
        // 转换为分贝 (使用参考值 32767，即 16位音频的最大值)
        val decibel = if (amplitude > 0) {
            20 * kotlin.math.log10(amplitude / 32767.0) + 90  // 偏移到合理范围
        } else {
            0.0
        }
        
        return decibel.coerceIn(0.0, 120.0)
    }
    
    /**
     * 更新声音等级
     */
    private fun updateSoundLevel(decibel: Double) {
        _decibelLevel.value = decibel
        
        // 添加到历史记录
        decibelHistory.add(decibel)
        if (decibelHistory.size > maxHistorySize) {
            decibelHistory.removeAt(0)
        }
        
        // 计算平均值（平滑处理）
        val avgDecibel = if (decibelHistory.isNotEmpty()) {
            decibelHistory.average()
        } else {
            decibel
        }
        
        // 判断声音等级
        val level = when {
            avgDecibel < SILENCE_THRESHOLD -> SoundLevel.SILENT
            avgDecibel < NORMAL_THRESHOLD -> SoundLevel.QUIET
            avgDecibel < LOUD_THRESHOLD -> SoundLevel.NORMAL
            else -> SoundLevel.LOUD
        }
        
        if (_soundLevel.value != level) {
            LogManager.w(TAG, "环境声音变化: ${_soundLevel.value} -> $level (${avgDecibel.toInt()}dB)")
            _soundLevel.value = level
            
            // 更新环境类型推测
            updateEnvironmentType(level, avgDecibel)
        }
    }
    
    /**
     * 更新环境类型推测
     */
    private fun updateEnvironmentType(level: SoundLevel, decibel: Double) {
        val envType = when (level) {
            SoundLevel.SILENT -> {
                // 非常安静：可能在图书馆、深夜、或者正在开会
                SoundEnvironment.LIBRARY_OR_MEETING
            }
            SoundLevel.QUIET -> {
                // 比较安静：可能在办公室、教室听课
                SoundEnvironment.OFFICE_OR_CLASSROOM
            }
            SoundLevel.NORMAL -> {
                // 正常音量：可能在家里、咖啡厅
                SoundEnvironment.HOME_OR_CAFE
            }
            SoundLevel.LOUD -> {
                // 嘈杂：可能在户外、商场、餐厅
                SoundEnvironment.OUTDOOR_OR_PUBLIC
            }
            SoundLevel.UNKNOWN -> SoundEnvironment.UNKNOWN
        }
        
        _environmentType.value = envType
    }
    
    /**
     * 获取单次声音检测结果（不需要持续监控）
     */
    suspend fun detectOnce(): SoundDetectionResult {
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) 
            != PackageManager.PERMISSION_GRANTED) {
            return SoundDetectionResult(
                success = false,
                decibel = 0.0,
                level = SoundLevel.UNKNOWN,
                environment = SoundEnvironment.UNKNOWN,
                shouldDisturb = true,  // 无法检测时默认可以打扰
                reason = "未授予录音权限"
            )
        }
        
        return withContext(Dispatchers.IO) {
            try {
                val bufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT)
                val tempRecorder = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    SAMPLE_RATE,
                    CHANNEL_CONFIG,
                    AUDIO_FORMAT,
                    bufferSize
                )
                
                if (tempRecorder.state != AudioRecord.STATE_INITIALIZED) {
                    return@withContext SoundDetectionResult(
                        success = false,
                        decibel = 0.0,
                        level = SoundLevel.UNKNOWN,
                        environment = SoundEnvironment.UNKNOWN,
                        shouldDisturb = true,
                        reason = "AudioRecord初始化失败"
                    )
                }
                
                tempRecorder.startRecording()
                
                // 采集3秒数据
                val samples = mutableListOf<Double>()
                val buffer = ShortArray(bufferSize)
                
                repeat(3) {
                    val readSize = tempRecorder.read(buffer, 0, buffer.size)
                    if (readSize > 0) {
                        samples.add(calculateDecibel(buffer, readSize))
                    }
                    delay(1000)
                }
                
                tempRecorder.stop()
                tempRecorder.release()
                
                val avgDecibel = if (samples.isNotEmpty()) samples.average() else 0.0
                
                val level = when {
                    avgDecibel < SILENCE_THRESHOLD -> SoundLevel.SILENT
                    avgDecibel < NORMAL_THRESHOLD -> SoundLevel.QUIET
                    avgDecibel < LOUD_THRESHOLD -> SoundLevel.NORMAL
                    else -> SoundLevel.LOUD
                }
                
                val environment = when (level) {
                    SoundLevel.SILENT -> SoundEnvironment.LIBRARY_OR_MEETING
                    SoundLevel.QUIET -> SoundEnvironment.OFFICE_OR_CLASSROOM
                    SoundLevel.NORMAL -> SoundEnvironment.HOME_OR_CAFE
                    SoundLevel.LOUD -> SoundEnvironment.OUTDOOR_OR_PUBLIC
                    SoundLevel.UNKNOWN -> SoundEnvironment.UNKNOWN
                }
                
                // 判断是否适合打扰
                val shouldDisturb = when (level) {
                    SoundLevel.SILENT -> false  // 非常安静，可能在会议/图书馆
                    SoundLevel.QUIET -> false   // 比较安静，可能在上课/办公
                    SoundLevel.NORMAL -> true   // 正常环境，可以打扰
                    SoundLevel.LOUD -> true     // 嘈杂环境，可以打扰（反正听不到）
                    SoundLevel.UNKNOWN -> true
                }
                
                val reason = when (level) {
                    SoundLevel.SILENT -> "检测到环境非常安静(${avgDecibel.toInt()}dB)，可能在会议室或图书馆"
                    SoundLevel.QUIET -> "检测到环境比较安静(${avgDecibel.toInt()}dB)，可能在上课或办公"
                    SoundLevel.NORMAL -> "检测到环境正常(${avgDecibel.toInt()}dB)，适合交流"
                    SoundLevel.LOUD -> "检测到环境嘈杂(${avgDecibel.toInt()}dB)"
                    SoundLevel.UNKNOWN -> "无法检测环境声音"
                }
                
                LogManager.w(TAG, "单次声音检测: $level, ${avgDecibel.toInt()}dB, 可打扰=$shouldDisturb")
                
                SoundDetectionResult(
                    success = true,
                    decibel = avgDecibel,
                    level = level,
                    environment = environment,
                    shouldDisturb = shouldDisturb,
                    reason = reason
                )
                
            } catch (e: Exception) {
                LogManager.w(TAG, "单次声音检测失败", e)
                SoundDetectionResult(
                    success = false,
                    decibel = 0.0,
                    level = SoundLevel.UNKNOWN,
                    environment = SoundEnvironment.UNKNOWN,
                    shouldDisturb = true,
                    reason = "检测失败: ${e.message}"
                )
            }
        }
    }
    
    /**
     * 🔍 快速检测是否适合打扰（基于当前监控数据或单次检测）
     */
    suspend fun shouldDisturbUser(): Boolean {
        // 如果正在监控，使用已有数据
        if (isMonitoring) {
            val level = _soundLevel.value
            return when (level) {
                SoundLevel.SILENT, SoundLevel.QUIET -> false
                else -> true
            }
        }
        
        // 否则进行单次检测
        val result = detectOnce()
        return result.shouldDisturb
    }
}

/**
 * 🔊 声音等级
 */
enum class SoundLevel {
    SILENT,     // 安静 (<30dB) - 图书馆、深夜、会议
    QUIET,      // 较静 (30-50dB) - 办公室、教室
    NORMAL,     // 正常 (50-70dB) - 家里、咖啡厅
    LOUD,       // 嘈杂 (>70dB) - 户外、商场
    UNKNOWN
}

/**
 * 🏢 声音环境类型推测
 */
enum class SoundEnvironment {
    LIBRARY_OR_MEETING,     // 图书馆或会议室
    OFFICE_OR_CLASSROOM,    // 办公室或教室
    HOME_OR_CAFE,           // 家里或咖啡厅
    OUTDOOR_OR_PUBLIC,      // 户外或公共场所
    UNKNOWN
}

/**
 * 📊 声音检测结果
 */
data class SoundDetectionResult(
    val success: Boolean,
    val decibel: Double,
    val level: SoundLevel,
    val environment: SoundEnvironment,
    val shouldDisturb: Boolean,
    val reason: String
)
