package com.example.xihe.context

import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * 🔔 智能通知监听器
 * 监听重要通知（如航班延误、快递到达等）并触发主动对话
 */
class SmartNotificationListener : NotificationListenerService() {
    
    companion object {
        private const val TAG = "SmartNotification"
        
        // 通知事件流
        private val _notificationEvent = MutableStateFlow<NotificationEvent?>(null)
        val notificationEvent = _notificationEvent.asStateFlow()
        
        @Volatile
        private var instance: SmartNotificationListener? = null
        
        fun getInstance(): SmartNotificationListener? = instance
    }
    
    override fun onCreate() {
        super.onCreate()
        instance = this
        LogManager.i(TAG, "✅ 智能通知监听器已创建")
    }
    
    override fun onDestroy() {
        super.onDestroy()
        instance = null
        LogManager.i(TAG, "🛑 智能通知监听器已销毁")
    }
    
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        
        sbn ?: return
        
        try {
            analyzeNotification(sbn)
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 分析通知失败", e)
        }
    }
    
    /**
     * 🔍 分析通知内容
     */
    private fun analyzeNotification(sbn: StatusBarNotification) {
        val packageName = sbn.packageName
        val notification = sbn.notification ?: return
        
        val title = notification.extras.getString("android.title") ?: ""
        val text = notification.extras.getString("android.text") ?: ""
        val bigText = notification.extras.getString("android.bigText") ?: text
        
        val content = "$title $bigText".lowercase()
        
        LogManager.d(TAG, "📨 收到通知 [$packageName]: $title")
        
        // 检测航班相关通知
        if (detectFlightNotification(packageName, content, title, bigText)) {
            return
        }
        
        // 检测快递相关通知
        if (detectDeliveryNotification(packageName, content, title, bigText)) {
            return
        }
        
        // 检测天气预警
        if (detectWeatherAlert(packageName, content, title, bigText)) {
            return
        }
        
        // 检测日程提醒
        if (detectScheduleReminder(packageName, content, title, bigText)) {
            return
        }
    }
    
    /**
     * ✈️ 检测航班通知
     */
    private fun detectFlightNotification(
        packageName: String,
        content: String,
        title: String,
        text: String
    ): Boolean {
        // 航班相关应用
        val flightApps = listOf(
            "ctrip", "qunar", "fliggy", "携程", "去哪儿", "飞猪",
            "航班管家", "航旅纵横", "航班"
        )
        
        if (!flightApps.any { packageName.contains(it, ignoreCase = true) }) {
            return false
        }
        
        // 航班延误关键词
        val delayKeywords = listOf(
            "延误", "delay", "晚点", "推迟", "取消", "cancelled"
        )
        
        if (delayKeywords.any { content.contains(it) }) {
            LogManager.i(TAG, "✈️ 检测到航班延误通知")
            
            _notificationEvent.value = NotificationEvent(
                type = NotificationType.FLIGHT_DELAY,
                title = title,
                content = text,
                timestamp = System.currentTimeMillis(),
                metadata = mapOf(
                    "source" to packageName
                )
            )
            
            return true
        }
        
        // 登机提醒
        val boardingKeywords = listOf(
            "登机", "boarding", "起飞", "departure", "check-in"
        )
        
        if (boardingKeywords.any { content.contains(it) }) {
            LogManager.i(TAG, "✈️ 检测到登机提醒")
            
            _notificationEvent.value = NotificationEvent(
                type = NotificationType.BOARDING_REMINDER,
                title = title,
                content = text,
                timestamp = System.currentTimeMillis(),
                metadata = mapOf(
                    "source" to packageName
                )
            )
            
            return true
        }
        
        return false
    }
    
    /**
     * 📦 检测快递通知
     */
    private fun detectDeliveryNotification(
        packageName: String,
        content: String,
        title: String,
        text: String
    ): Boolean {
        val deliveryKeywords = listOf(
            "快递", "派送", "配送", "送达", "到达",
            "delivery", "shipping", "包裹", "package"
        )
        
        if (!deliveryKeywords.any { content.contains(it) }) {
            return false
        }
        
        // 到达提醒
        val arrivedKeywords = listOf(
            "已到", "已送达", "已签收", "到达", "arrived", "delivered"
        )
        
        if (arrivedKeywords.any { content.contains(it) }) {
            LogManager.i(TAG, "📦 检测到快递到达通知")
            
            _notificationEvent.value = NotificationEvent(
                type = NotificationType.DELIVERY_ARRIVED,
                title = title,
                content = text,
                timestamp = System.currentTimeMillis(),
                metadata = mapOf(
                    "source" to packageName
                )
            )
            
            return true
        }
        
        return false
    }
    
    /**
     * 🌦️ 检测天气预警
     */
    private fun detectWeatherAlert(
        packageName: String,
        content: String,
        title: String,
        text: String
    ): Boolean {
        val weatherKeywords = listOf(
            "暴雨", "台风", "大雾", "霾", "雷电", "冰雹",
            "预警", "alert", "warning", "天气", "weather"
        )
        
        if (weatherKeywords.any { content.contains(it) }) {
            LogManager.i(TAG, "🌦️ 检测到天气预警")
            
            _notificationEvent.value = NotificationEvent(
                type = NotificationType.WEATHER_ALERT,
                title = title,
                content = text,
                timestamp = System.currentTimeMillis(),
                metadata = mapOf(
                    "source" to packageName
                )
            )
            
            return true
        }
        
        return false
    }
    
    /**
     * 📅 检测日程提醒
     */
    private fun detectScheduleReminder(
        packageName: String,
        content: String,
        title: String,
        text: String
    ): Boolean {
        val scheduleKeywords = listOf(
            "会议", "meeting", "日程", "schedule", "提醒", "reminder",
            "即将开始", "starting soon", "待办", "todo"
        )
        
        if (scheduleKeywords.any { content.contains(it) }) {
            LogManager.i(TAG, "📅 检测到日程提醒")
            
            _notificationEvent.value = NotificationEvent(
                type = NotificationType.SCHEDULE_REMINDER,
                title = title,
                content = text,
                timestamp = System.currentTimeMillis(),
                metadata = mapOf(
                    "source" to packageName
                )
            )
            
            return true
        }
        
        return false
    }
    
    /**
     * ✅ 确认通知已处理
     */
    fun acknowledgeNotification() {
        _notificationEvent.value = null
    }
}

/**
 * 📨 通知事件
 */
data class NotificationEvent(
    val type: NotificationType,
    val title: String,
    val content: String,
    val timestamp: Long,
    val metadata: Map<String, String> = emptyMap()
)

/**
 * 🏷️ 通知类型
 */
enum class NotificationType {
    FLIGHT_DELAY,           // 航班延误
    BOARDING_REMINDER,      // 登机提醒
    DELIVERY_ARRIVED,       // 快递到达
    WEATHER_ALERT,          // 天气预警
    SCHEDULE_REMINDER,      // 日程提醒
    URGENT_MESSAGE,         // 紧急消息
    UNKNOWN                 // 未知类型
}
