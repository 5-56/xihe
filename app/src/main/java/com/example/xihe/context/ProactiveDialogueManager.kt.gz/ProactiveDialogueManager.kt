package com.example.xihe.context

import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.intelligence.EmotionRecognizer
import com.example.xihe.intelligence.MemorySystem
import com.example.xihe.intelligence.Emotion
import com.example.xihe.intelligence.HabitFrequency
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.TimeUnit

/**
 * 主动对话管理器
 * 根据情境感知自动触发主动对话，提供智能建议和关怀
 */
class ProactiveDialogueManager(private val context: Context) {
    
    companion object {
        private const val TAG = "ProactiveDialogue"
        
        // 主动对话配置
        private const val SILENCE_THRESHOLD_MS = 180_000L  // 3分钟无对话
        private const val MIN_INTERVAL_BETWEEN_PROACTIVE_MS = 600_000L  // 两次主动对话最少间隔10分钟
        private const val MAX_PROACTIVE_PER_HOUR = 3  // 每小时最多3次主动对话
        
        @Volatile
        private var instance: ProactiveDialogueManager? = null
        
        fun getInstance(context: Context): ProactiveDialogueManager {
            return instance ?: synchronized(this) {
                instance ?: ProactiveDialogueManager(context.applicationContext).also { instance = it }
            }
        }
    }
    
    // 情境感知引擎
    private val contextEngine = ContextAwarenessEngine.getInstance(context)
    
    // 通知监听
    private var notificationListenerJob: Job? = null
    
    // 情绪识别系统
    private val emotionRecognizer = EmotionRecognizer.getInstance(context)
    
    // 记忆系统
    private val memorySystem = MemorySystem.getInstance(context)
    
    // 个性化推荐系统
    private val personalizedRecommender by lazy { 
        com.example.xihe.intelligence.PersonalizedRecommender.getInstance(context) 
    }
    
    // 健康管理系统
    private val healthManager by lazy {
        com.example.xihe.health.HealthManager.getInstance(context)
    }
    
    // 多模态交互管理器
    private val multimodalManager by lazy {
        com.example.xihe.multimodal.MultimodalInteractionManager.getInstance(context)
    }
    
    // 跨设备协同管理器
    private val syncManager by lazy {
        com.example.xihe.sync.CrossDeviceSyncManager.getInstance(context)
    }
    
    // 主动对话触发状态
    private val _proactiveTrigger = MutableStateFlow<ProactiveTrigger?>(null)
    val proactiveTrigger = _proactiveTrigger.asStateFlow()
    
    // 对话状态跟踪
    private var lastUserSpeechTime: Long = 0
    private var lastProactiveTime: Long = 0
    private val proactiveHistory = mutableListOf<ProactiveRecord>()
    
    // 配置
    private var isEnabled = false
    private var inRealTimeMode = false
    
    // 监控任务
    private var monitoringJob: Job? = null
    
    /**
     * 启动主动对话系统
     */
    fun start() {
        if (isEnabled) {
            LogManager.d(TAG, "主动对话系统已在运行")
            return
        }
        
        LogManager.i(TAG, "启动主动对话系统")
        isEnabled = true
        
        // 启动情境监控
        contextEngine.startMonitoring()
        
        // 监听情境变化
        contextEngine.addContextChangeListener { newContext ->
            onContextChanged(newContext)
        }
        
        // 启动静默检测
        startSilenceMonitoring()
        
        // 监听通知事件
        startNotificationMonitoring()
        
        // 启动情绪识别
        emotionRecognizer.start()
        LogManager.d(TAG, "情绪识别系统已启动")
        
        // 启动情绪和记忆监控
        startEmotionAndMemoryMonitoring()
        
        // 启动健康管理
        healthManager.start()
        LogManager.d(TAG, "健康管理系统已启动")
        
        // 初始化多模态交互
        multimodalManager.initialize()
        LogManager.d(TAG, "多模态交互已初始化")
        
        // 启动跨设备协同
        syncManager.start()
        LogManager.d(TAG, "跨设备协同已启动")
    }
    
    /**
     * 监控情绪和记忆
     */
    private fun startEmotionAndMemoryMonitoring() {
        CoroutineScope(Dispatchers.Default).launch {
            while (isActive && isEnabled) {
                try {
                    delay(60_000) // 每分钟检查一次
                    
                    // 检查情绪状态
                    checkEmotionTriggers()
                    
                    // 检查记忆触发
                    checkMemoryTriggers()
                    
                } catch (e: Exception) {
                    LogManager.e(TAG, "情绪和记忆监控失败", e)
                }
            }
        }
    }
    
    /**
     * 检查情绪触发
     */
    private fun checkEmotionTriggers() {
        val emotion = emotionRecognizer.currentEmotion.value
        
        // 压力预警
        if (emotionRecognizer.detectStressAlert()) {
            if (canTriggerProactive()) {
                triggerProactiveDialogue(
                    ProactiveTrigger(
                        type = TriggerType.EMOTION_BASED,
                        priority = Priority.HIGH,
                        message = "主人，最近压力有点大呢。要不要听首舒缓的音乐放松一下？",
                        context = "压力预警",
                        suggestions = listOf("播放音乐", "不需要")
                    )
                )
            }
            return
        }
        
        // 高强度情绪关怀
        when (emotion.emotion) {
            Emotion.STRESSED, Emotion.ANXIOUS -> {
                if (emotion.intensity > 0.7f && canTriggerProactive()) {
                    triggerProactiveDialogue(
                        ProactiveTrigger(
                            type = TriggerType.EMOTION_BASED,
                            priority = Priority.MEDIUM,
                            message = "主人，感觉有点紧张？深呼吸，放松一下",
                            context = "焦虑情绪",
                            suggestions = listOf("播放冥想音乐", "不需要")
                        )
                    )
                }
            }
            
            Emotion.SAD -> {
                if (emotion.intensity > 0.7f && canTriggerProactive()) {
                    triggerProactiveDialogue(
                        ProactiveTrigger(
                            type = TriggerType.EMOTION_BASED,
                            priority = Priority.MEDIUM,
                            message = "主人，不开心了吗？需要陪你聊聊天吗？",
                            context = "悲伤情绪",
                            suggestions = listOf("聊聊天", "播放音乐", "不需要")
                        )
                    )
                }
            }
            
            Emotion.TIRED -> {
                if (emotion.intensity > 0.7f && canTriggerProactive()) {
                    triggerProactiveDialogue(
                        ProactiveTrigger(
                            type = TriggerType.EMOTION_BASED,
                            priority = Priority.MEDIUM,
                            message = "主人，看起来有点累了呢，要不要休息一下？",
                            context = "疲惫状态",
                            suggestions = listOf("设置提醒", "不需要")
                        )
                    )
                }
            }
            
            else -> {}
        }
    }
    
    /**
     * 检查记忆触发
     */
    private fun checkMemoryTriggers() {
        val profile = memorySystem.userProfile.value
        val now = java.time.LocalTime.now()
        val today = java.time.LocalDate.now().dayOfWeek
        
        // 检查习惯触发
        profile.habits.forEach { habit ->
            when (habit.frequency) {
                HabitFrequency.DAILY -> {
                    habit.time?.let { habitTime ->
                        val parts = habitTime.split(":")
                        if (parts.size == 2) {
                            val habitHour = parts[0].toIntOrNull()
                            if (habitHour != null && now.hour == habitHour && canTriggerProactive()) {
                                triggerProactiveDialogue(
                                    ProactiveTrigger(
                                        type = TriggerType.HABIT_BASED,
                                        priority = Priority.MEDIUM,
                                        message = "主人，按照您的习惯，该${habit.description}了哦",
                                        context = "习惯提醒",
                                        suggestions = listOf("好的", "稍后")
                                    )
                                )
                            }
                        }
                    }
                }
                
                HabitFrequency.WEEKLY -> {
                    habit.dayOfWeek?.let { dayOfWeek ->
                        if (today.name.equals(dayOfWeek, ignoreCase = true) && canTriggerProactive()) {
                            triggerProactiveDialogue(
                                ProactiveTrigger(
                                    type = TriggerType.HABIT_BASED,
                                    priority = Priority.LOW,
                                    message = "主人，今天是${habit.description}的日子哦",
                                    context = "周期习惯",
                                    suggestions = listOf("知道了", "设置提醒")
                                )
                            )
                        }
                    }
                }
                
                else -> {}
            }
        }
        
        // 检查重要日期
        profile.importantDates.forEach { date ->
            if (date.reminder && canTriggerProactive()) {
                checkImportantDate(date)
            }
        }
    }
    
    /**
     * 检查重要日期并触发提醒
     */
    private fun checkImportantDate(date: com.example.xihe.intelligence.ImportantDate) {
        try {
            val today = java.util.Calendar.getInstance()
            val currentMonth = today.get(java.util.Calendar.MONTH) + 1
            val currentDay = today.get(java.util.Calendar.DAY_OF_MONTH)
            
            // 解析日期字符串，支持多种格式
            val parsedDate = parseDate(date.date)
            if (parsedDate == null) return
            
            val (targetMonth, targetDay) = parsedDate
            val daysUntil = calculateDaysUntil(currentMonth, currentDay, targetMonth, targetDay)
            
            when {
                daysUntil == 0 -> {
                    // 今天就是重要日期！
                    triggerProactiveDialogue(
                        ProactiveTrigger(
                            type = TriggerType.HABIT_BASED,
                            priority = Priority.HIGH,
                            message = "主人！今天是${date.name}哦！",
                            context = "重要日期",
                            suggestions = listOf("谢谢提醒", "帮我发祝福", "设置明年提醒")
                        )
                    )
                }
                daysUntil in 1..3 -> {
                    // 提前提醒
                    triggerProactiveDialogue(
                        ProactiveTrigger(
                            type = TriggerType.HABIT_BASED,
                            priority = Priority.MEDIUM,
                            message = "主人，还有 $daysUntil 天就是${date.name}啦~",
                            context = "日期提醒",
                            suggestions = listOf("知道了", "帮我准备礼物", "设置提醒")
                        )
                    )
                }
                daysUntil == 7 -> {
                    // 提前一周提醒
                    triggerProactiveDialogue(
                        ProactiveTrigger(
                            type = TriggerType.HABIT_BASED,
                            priority = Priority.LOW,
                            message = "主人，下周就是${date.name}了，要提前准备吗？",
                            context = "日期提醒",
                            suggestions = listOf("好的", "暂时不用")
                        )
                    )
                }
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "检查重要日期失败: ${date.name}", e)
        }
    }
    
    /**
     * 解析日期字符串
     * 支持格式: "MM-DD", "M月D日", "MM/DD"
     */
    private fun parseDate(dateStr: String): Pair<Int, Int>? {
        return try {
            // 尝试 "MM-DD" 格式
            if (dateStr.contains("-")) {
                val parts = dateStr.split("-")
                if (parts.size >= 2) {
                    val month = parts[0].toIntOrNull()
                    val day = parts[1].toIntOrNull()
                    if (month != null && day != null) {
                        return Pair(month, day)
                    }
                }
            }
            
            // 尝试 "M月D日" 格式
            val chinesePattern = "(\\d+)月(\\d+)日?".toRegex()
            chinesePattern.find(dateStr)?.let { match ->
                val month = match.groupValues[1].toIntOrNull()
                val day = match.groupValues[2].toIntOrNull()
                if (month != null && day != null) {
                    return Pair(month, day)
                }
            }
            
            // 尝试 "MM/DD" 格式
            if (dateStr.contains("/")) {
                val parts = dateStr.split("/")
                if (parts.size >= 2) {
                    val month = parts[0].toIntOrNull()
                    val day = parts[1].toIntOrNull()
                    if (month != null && day != null) {
                        return Pair(month, day)
                    }
                }
            }
            
            null
        } catch (e: Exception) {
            null
        }
    }
    
    /**
     * 计算距离目标日期的天数
     */
    private fun calculateDaysUntil(currentMonth: Int, currentDay: Int, targetMonth: Int, targetDay: Int): Int {
        val today = java.util.Calendar.getInstance()
        val target = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.MONTH, targetMonth - 1)
            set(java.util.Calendar.DAY_OF_MONTH, targetDay)
            
            // 如果目标日期已过，设置为明年
            if (before(today)) {
                add(java.util.Calendar.YEAR, 1)
            }
        }
        
        val diffMillis = target.timeInMillis - today.timeInMillis
        return (diffMillis / (1000 * 60 * 60 * 24)).toInt()
    }
    
    /**
     * 停止主动对话系统
     */
    fun stop() {
        LogManager.i(TAG, "停止主动对话系统")
        isEnabled = false
        monitoringJob?.cancel()
        monitoringJob = null
        notificationListenerJob?.cancel()
        notificationListenerJob = null
        
        // 停止情绪识别
        emotionRecognizer.stop()
        
        // 保存记忆
        memorySystem.saveMemory()
        LogManager.d(TAG, "情绪识别已停止，记忆已保存")
        
        // 停止健康管理
        healthManager.stop()
        
        // 停止跨设备协同
        syncManager.stop()
        LogManager.d(TAG, "健康管理和跨设备协同已停止")
    }
    
    /**
     * 设置实时对话模式
     */
    fun setRealTimeMode(enabled: Boolean) {
        inRealTimeMode = enabled
        LogManager.d(TAG, "实时对话模式: $enabled")
        
        if (enabled) {
            // 进入实时对话模式时，更新最后对话时间
            updateLastSpeechTime()
        }
    }
    
    /**
     * 更新用户发言时间
     */
    fun updateLastSpeechTime() {
        lastUserSpeechTime = System.currentTimeMillis()
        LogManager.d(TAG, "用户发言时间已更新")
    }
    
    /**
     * 启动静默检测
     */
    private fun startSilenceMonitoring() {
        monitoringJob = CoroutineScope(Dispatchers.Default).launch {
            while (isActive && isEnabled) {
                try {
                    delay(30_000) // 每30秒检查一次
                    
                    // 只在实时对话模式下检测静默
                    if (inRealTimeMode) {
                        checkSilenceTimeout()
                    }
                } catch (e: Exception) {
                    LogManager.e(TAG, "静默检测失败", e)
                }
            }
        }
    }
    
    /**
     * 检查静默超时
     */
    private fun checkSilenceTimeout() {
        if (lastUserSpeechTime == 0L) return
        
        val silenceDuration = System.currentTimeMillis() - lastUserSpeechTime
        
        if (silenceDuration >= SILENCE_THRESHOLD_MS) {
            LogManager.d(TAG, "检测到长时间静默: ${silenceDuration / 1000}秒")
            
            // 检查是否可以触发
            if (canTriggerProactive()) {
                val currentContext = contextEngine.currentContext.value
                generateSilenceProactive(currentContext, silenceDuration)
            }
        }
    }
    
    /**
     * 情境变化处理
     */
    private fun onContextChanged(newContext: UserContext) {
        if (!isEnabled) return
        
        LogManager.d(TAG, "检测到情境变化")
        
        // 检查是否可以触发
        if (!canTriggerProactive()) {
            LogManager.d(TAG, "暂时不能触发主动对话（频率限制）")
            return
        }
        
        // 分析情境并生成主动对话
        val trigger = analyzeContextAndGenerate(newContext)
        
        if (trigger != null) {
            triggerProactiveDialogue(trigger)
        }
    }
    
    /**
     * 分析情境并生成主动对话
     */
    private fun analyzeContextAndGenerate(context: UserContext): ProactiveTrigger? {
        // 1. 检测特殊地点
        context.location?.let { location ->
            when (location.placeType) {
                PlaceType.AIRPORT -> {
                    return ProactiveTrigger(
                        type = TriggerType.LOCATION_BASED,
                        priority = Priority.HIGH,
                        message = "主人，检测到您在机场呢！需要我帮您查看航班信息或者找找附近的休息室吗？",
                        context = "在机场",
                        suggestions = listOf("查看航班信息", "查找休息室", "查找餐厅", "不需要")
                    )
                }
                
                PlaceType.TRAIN_STATION -> {
                    return ProactiveTrigger(
                        type = TriggerType.LOCATION_BASED,
                        priority = Priority.MEDIUM,
                        message = "主人，您在火车站呢！要不要我帮您查看车次信息？",
                        context = "在火车站",
                        suggestions = listOf("查看车次", "查找候车室", "不需要")
                    )
                }
                
                PlaceType.HOSPITAL -> {
                    return ProactiveTrigger(
                        type = TriggerType.LOCATION_BASED,
                        priority = Priority.HIGH,
                        message = "主人，检测到您在医院，希望一切都好！需要我记录什么信息或者帮您找医生吗？",
                        context = "在医院",
                        suggestions = listOf("记录病历", "查找医生", "设置提醒", "不需要")
                    )
                }
                
                PlaceType.GYM -> {
                    return ProactiveTrigger(
                        type = TriggerType.LOCATION_BASED,
                        priority = Priority.LOW,
                        message = "主人，准备健身啦！要不要我帮您播放运动音乐或者记录运动数据呢？",
                        context = "在健身房",
                        suggestions = listOf("播放音乐", "开始记录", "不需要")
                    )
                }
                
                else -> {}
            }
        }
        
        // 2. 检测时段相关
        when (context.timeOfDay) {
            TimeOfDay.EARLY_MORNING -> {
                if (!hasProactiveInLast(TimeUnit.HOURS.toMillis(12))) {
                    return ProactiveTrigger(
                        type = TriggerType.TIME_BASED,
                        priority = Priority.LOW,
                        message = "早上好，主人！新的一天开始了，今天有什么安排吗？",
                        context = "早晨问候",
                        suggestions = listOf("查看日程", "播报天气", "不需要")
                    )
                }
            }
            
            TimeOfDay.NIGHT -> {
                if (context.batteryLevel in 1..20 && !context.isCharging) {
                    return ProactiveTrigger(
                        type = TriggerType.DEVICE_STATUS,
                        priority = Priority.MEDIUM,
                        message = "主人，手机电量只剩${context.batteryLevel}%了，该充电休息啦~",
                        context = "低电量提醒",
                        suggestions = listOf("设置充电提醒", "不需要")
                    )
                }
            }
            
            else -> {}
        }
        
        // 3. 检测活动状态
        when (context.activity) {
            ActivityType.IN_VEHICLE -> {
                return ProactiveTrigger(
                    type = TriggerType.ACTIVITY_BASED,
                    priority = Priority.MEDIUM,
                    message = "主人，您在路上呢！需要我帮您播放音乐或者查看实时路况吗？",
                    context = "在车内",
                    suggestions = listOf("播放音乐", "查看路况", "不需要")
                )
            }
            
            else -> {}
        }
        
        // 4. 检测设备状态
        if (context.batteryLevel in 1..10 && !context.isCharging) {
            return ProactiveTrigger(
                type = TriggerType.DEVICE_STATUS,
                priority = Priority.HIGH,
                message = "主人，电量严重不足（${context.batteryLevel}%），请尽快充电！",
                context = "电量严重不足",
                suggestions = listOf("开启省电模式", "知道了")
            )
        }
        
        return null
    }
    
    /**
     * 监听通知事件
     */
    private fun startNotificationMonitoring() {
        notificationListenerJob = CoroutineScope(Dispatchers.Default).launch {
            SmartNotificationListener.notificationEvent.collect { event ->
                if (event != null && isEnabled) {
                    LogManager.i(TAG, "收到通知事件: ${event.type}")
                    handleNotificationEvent(event)
                }
            }
        }
    }
    
    /**
     * 处理通知事件
     */
    private fun handleNotificationEvent(event: NotificationEvent) {
        if (!canTriggerProactive()) {
            LogManager.d(TAG, "暂时不能触发主动对话（频率限制）")
            return
        }
        
        val trigger = when (event.type) {
            NotificationType.FLIGHT_DELAY -> {
                ProactiveTrigger(
                    type = TriggerType.NOTIFICATION,
                    priority = Priority.HIGH,
                    message = "主人，航班延误了！要不要我帮你改签或者找个附近的休息室？",
                    context = "航班延误通知",
                    suggestions = listOf("帮我改签", "查找休息室", "查找餐厅", "不需要")
                )
            }
            
            NotificationType.BOARDING_REMINDER -> {
                ProactiveTrigger(
                    type = TriggerType.NOTIFICATION,
                    priority = Priority.HIGH,
                    message = "主人，马上要登机了！需要我帮你查看登机口或者设置提醒吗？",
                    context = "登机提醒",
                    suggestions = listOf("查看登机口", "设置提醒", "不需要")
                )
            }
            
            NotificationType.DELIVERY_ARRIVED -> {
                ProactiveTrigger(
                    type = TriggerType.NOTIFICATION,
                    priority = Priority.MEDIUM,
                    message = "主人，您的快递已经到达了！需要我记录一下取件信息吗？",
                    context = "快递到达",
                    suggestions = listOf("记录信息", "不需要")
                )
            }
            
            NotificationType.WEATHER_ALERT -> {
                ProactiveTrigger(
                    type = TriggerType.NOTIFICATION,
                    priority = Priority.HIGH,
                    message = "主人，收到天气预警！${event.content} 要不要我提醒你带伞？",
                    context = "天气预警",
                    suggestions = listOf("设置提醒", "查看天气", "不需要")
                )
            }
            
            NotificationType.SCHEDULE_REMINDER -> {
                ProactiveTrigger(
                    type = TriggerType.NOTIFICATION,
                    priority = Priority.MEDIUM,
                    message = "主人，您有日程提醒：${event.title} 需要我帮你准备什么吗？",
                    context = "日程提醒",
                    suggestions = listOf("查看详情", "设置提醒", "不需要")
                )
            }
            
            else -> null
        }
        
        if (trigger != null) {
            triggerProactiveDialogue(trigger)
            // 确认通知已处理
            SmartNotificationListener.getInstance()?.acknowledgeNotification()
        }
    }
    
    /**
     * 生成静默时的主动对话
     */
    private fun generateSilenceProactive(context: UserContext, silenceDuration: Long) {
        val minutesSilent = silenceDuration / 60_000
        
        val messages = listOf(
            "主人，您已经${minutesSilent}分钟没有说话了，还在吗？有什么需要帮助的吗？",
            "主人，好久没听到您的声音了呢~ 是在忙吗？",
            "主人，休息够了吗？有什么我可以帮您的吗？",
            "主人，需要我做些什么吗？我一直在这里哦~"
        )
        
        val trigger = ProactiveTrigger(
            type = TriggerType.SILENCE,
            priority = Priority.LOW,
            message = messages.random(),
            context = "长时间静默",
            suggestions = listOf("没事", "帮我做点事", "结束对话")
        )
        
        triggerProactiveDialogue(trigger)
    }
    
    /**
     * 触发主动对话
     */
    private fun triggerProactiveDialogue(trigger: ProactiveTrigger) {
        LogManager.i(TAG, "触发主动对话: ${trigger.type} - ${trigger.message}")
        
        // 更新触发时间
        lastProactiveTime = System.currentTimeMillis()
        
        // 记录到历史
        proactiveHistory.add(
            ProactiveRecord(
                trigger = trigger,
                timestamp = System.currentTimeMillis()
            )
        )
        
        // 清理旧记录（只保留最近24小时的）
        val cutoffTime = System.currentTimeMillis() - TimeUnit.HOURS.toMillis(24)
        proactiveHistory.removeAll { it.timestamp < cutoffTime }
        
        // 发送触发事件
        _proactiveTrigger.value = trigger
    }
    
    /**
     * 确认主动对话已处理
     */
    fun acknowledgeProactive() {
        _proactiveTrigger.value = null
    }
    
    /**
     * 检查是否可以触发主动对话
     */
    private fun canTriggerProactive(): Boolean {
        // 1. 检查最小间隔
        val timeSinceLastProactive = System.currentTimeMillis() - lastProactiveTime
        if (timeSinceLastProactive < MIN_INTERVAL_BETWEEN_PROACTIVE_MS) {
            LogManager.d(TAG, "距离上次主动对话时间过短: ${timeSinceLastProactive / 1000}秒")
            return false
        }
        
        // 2. 检查每小时频率
        val oneHourAgo = System.currentTimeMillis() - TimeUnit.HOURS.toMillis(1)
        val recentCount = proactiveHistory.count { it.timestamp > oneHourAgo }
        if (recentCount >= MAX_PROACTIVE_PER_HOUR) {
            LogManager.d(TAG, "本小时主动对话次数已达上限: $recentCount")
            return false
        }
        
        return true
    }
    
    /**
     * 📊 检查最近是否有主动对话
     */
    private fun hasProactiveInLast(milliseconds: Long): Boolean {
        val cutoffTime = System.currentTimeMillis() - milliseconds
        return proactiveHistory.any { it.timestamp > cutoffTime }
    }
    
    /**
     * 📈 获取统计信息
     */
    fun getStatistics(): ProactiveStatistics {
        val now = System.currentTimeMillis()
        val oneHourAgo = now - TimeUnit.HOURS.toMillis(1)
        val oneDayAgo = now - TimeUnit.HOURS.toMillis(24)
        
        return ProactiveStatistics(
            totalProactiveToday = proactiveHistory.count { it.timestamp > oneDayAgo },
            proactiveLastHour = proactiveHistory.count { it.timestamp > oneHourAgo },
            lastProactiveTime = if (lastProactiveTime > 0) lastProactiveTime else null,
            isEnabled = isEnabled,
            inRealTimeMode = inRealTimeMode
        )
    }
}

// ========== 数据类 ==========

/**
 * 🎯 主动对话触发器
 */
data class ProactiveTrigger(
    val type: TriggerType,
    val priority: Priority,
    val message: String,
    val context: String,
    val suggestions: List<String> = emptyList(),
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * 📝 主动对话记录
 */
data class ProactiveRecord(
    val trigger: ProactiveTrigger,
    val timestamp: Long
)

/**
 * 📊 主动对话统计
 */
data class ProactiveStatistics(
    val totalProactiveToday: Int,
    val proactiveLastHour: Int,
    val lastProactiveTime: Long?,
    val isEnabled: Boolean,
    val inRealTimeMode: Boolean
)

/**
 * 🏷️ 触发类型
 */
enum class TriggerType {
    SILENCE,           // 长时间静默
    LOCATION_BASED,    // 基于位置
    TIME_BASED,        // 基于时间
    ACTIVITY_BASED,    // 基于活动
    DEVICE_STATUS,     // 设备状态
    NOTIFICATION,      // 通知触发
    CONTEXT_CHANGE,    // 情境变化
    EMOTION_BASED,     // 基于情绪
    HABIT_BASED        // 基于习惯
}

/**
 * ⚡ 优先级
 */
enum class Priority {
    LOW,
    MEDIUM,
    HIGH,
    URGENT
}
