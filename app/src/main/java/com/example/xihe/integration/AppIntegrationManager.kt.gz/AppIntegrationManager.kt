package com.example.xihe.integration

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * 🤖 应用深度集成管理器
 * 提供微信、支付宝、淘宝等常用应用的深度操作
 */
class AppIntegrationManager private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "AppIntegrationManager"
        
        @Volatile
        private var instance: AppIntegrationManager? = null
        
        fun getInstance(context: Context): AppIntegrationManager {
            return instance ?: synchronized(this) {
                instance ?: AppIntegrationManager(context.applicationContext).also { instance = it }
            }
        }
        
        // 常用应用包名
        const val PKG_WECHAT = "com.tencent.mm"
        const val PKG_ALIPAY = "com.eg.android.AlipayGphone"
        const val PKG_TAOBAO = "com.taobao.taobao"
        const val PKG_JD = "com.jingdong.app.mall"
        const val PKG_MEITUAN = "com.sankuai.meituan"
        const val PKG_ELEME = "me.ele"
    }
    
    // ==================== 微信集成 ====================
    
    /**
     * 💬 打开微信
     */
    fun openWeChat(): Boolean {
        return launchApp(PKG_WECHAT)
    }
    
    /**
     * 💬 打开微信扫一扫
     */
    fun openWeChatScan(): Boolean {
        return try {
            val intent = Intent()
            intent.component = ComponentName(PKG_WECHAT, "com.tencent.mm.plugin.scanner.ui.BaseScanUI")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            LogManager.d(TAG, "✅ 打开微信扫一扫")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "打开微信扫一扫失败", e)
            false
        }
    }
    
    /**
     * 💰 打开微信支付
     */
    fun openWeChatPay(): Boolean {
        return try {
            val intent = Intent()
            intent.component = ComponentName(PKG_WECHAT, "com.tencent.mm.plugin.offline.ui.WalletOfflineCoinPurseUI")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            LogManager.d(TAG, "✅ 打开微信支付")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "打开微信支付失败", e)
            openWeChat()
            false
        }
    }
    
    /**
     * 👥 打开微信朋友圈
     */
    fun openWeChatMoments(): Boolean {
        return try {
            val intent = Intent()
            intent.component = ComponentName(PKG_WECHAT, "com.tencent.mm.plugin.sns.ui.SnsTimeLineUI")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            LogManager.d(TAG, "✅ 打开微信朋友圈")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "打开微信朋友圈失败", e)
            openWeChat()
            false
        }
    }
    
    // ==================== 支付宝集成 ====================
    
    /**
     * 💳 打开支付宝
     */
    fun openAlipay(): Boolean {
        return launchApp(PKG_ALIPAY)
    }
    
    /**
     * 📷 打开支付宝扫一扫
     */
    fun openAlipayScan(): Boolean {
        return try {
            val intent = Intent()
            intent.action = "android.intent.action.VIEW"
            intent.data = Uri.parse("alipayqr://platformapi/startapp?saId=10000007")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            LogManager.d(TAG, "✅ 打开支付宝扫一扫")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "打开支付宝扫一扫失败", e)
            openAlipay()
            false
        }
    }
    
    /**
     * 💰 打开支付宝付款码
     */
    fun openAlipayPaymentCode(): Boolean {
        return try {
            val intent = Intent()
            intent.action = "android.intent.action.VIEW"
            intent.data = Uri.parse("alipayqr://platformapi/startapp?saId=20000056")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            LogManager.d(TAG, "✅ 打开支付宝付款码")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "打开支付宝付款码失败", e)
            openAlipay()
            false
        }
    }
    
    /**
     * 📊 打开支付宝账单
     */
    fun openAlipayBill(): Boolean {
        return try {
            val intent = Intent()
            intent.action = "android.intent.action.VIEW"
            intent.data = Uri.parse("alipayqr://platformapi/startapp?appId=20000003")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            LogManager.d(TAG, "✅ 打开支付宝账单")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "打开支付宝账单失败", e)
            openAlipay()
            false
        }
    }
    
    // ==================== 淘宝/天猫集成 ====================
    
    /**
     * 🛒 打开淘宝
     */
    fun openTaobao(): Boolean {
        return launchApp(PKG_TAOBAO)
    }
    
    /**
     * 🔍 淘宝搜索商品
     */
    fun searchOnTaobao(keyword: String): Boolean {
        return try {
            val intent = Intent()
            intent.action = "android.intent.action.VIEW"
            intent.data = Uri.parse("taobao://s.taobao.com/search?q=$keyword")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            LogManager.d(TAG, "✅ 淘宝搜索: $keyword")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "淘宝搜索失败", e)
            openTaobao()
            false
        }
    }
    
    /**
     * 🛒 打开淘宝购物车
     */
    fun openTaobaoCart(): Boolean {
        return try {
            val intent = Intent()
            intent.action = "android.intent.action.VIEW"
            intent.data = Uri.parse("taobao://cart.taobao.com/cart.htm")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            LogManager.d(TAG, "✅ 打开淘宝购物车")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "打开淘宝购物车失败", e)
            openTaobao()
            false
        }
    }
    
    // ==================== 京东集成 ====================
    
    /**
     * 🛒 打开京东
     */
    fun openJD(): Boolean {
        return launchApp(PKG_JD)
    }
    
    /**
     * 🔍 京东搜索商品
     */
    fun searchOnJD(keyword: String): Boolean {
        return try {
            val intent = Intent()
            intent.action = "android.intent.action.VIEW"
            intent.data = Uri.parse("openapp.jdmobile://virtual?params={\"category\":\"jump\",\"des\":\"productList\",\"keyWord\":\"$keyword\"}")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            LogManager.d(TAG, "✅ 京东搜索: $keyword")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "京东搜索失败", e)
            openJD()
            false
        }
    }
    
    // ==================== 美团集成 ====================
    
    /**
     * 🍔 打开美团
     */
    fun openMeituan(): Boolean {
        return launchApp(PKG_MEITUAN)
    }
    
    /**
     * 🍔 美团外卖搜索
     */
    fun searchOnMeituan(keyword: String): Boolean {
        return try {
            val intent = Intent()
            intent.action = "android.intent.action.VIEW"
            intent.data = Uri.parse("imeituan://www.meituan.com/search?q=$keyword")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            LogManager.d(TAG, "✅ 美团搜索: $keyword")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "美团搜索失败", e)
            openMeituan()
            false
        }
    }
    
    // ==================== 饿了么集成 ====================
    
    /**
     * 🍜 打开饿了么
     */
    fun openEleme(): Boolean {
        return launchApp(PKG_ELEME)
    }
    
    // ==================== 通用方法 ====================
    
    /**
     * 📱 启动应用
     */
    private fun launchApp(packageName: String): Boolean {
        return try {
            val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                LogManager.d(TAG, "✅ 启动应用: $packageName")
                true
            } else {
                LogManager.w(TAG, "⚠️ 应用未安装: $packageName")
                false
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "启动应用失败: $packageName", e)
            false
        }
    }
    
    /**
     * ✅ 检查应用是否安装
     */
    fun isAppInstalled(packageName: String): Boolean {
        return try {
            context.packageManager.getPackageInfo(packageName, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }
    
    /**
     * 📋 获取已安装的常用应用
     */
    fun getInstalledCommonApps(): List<AppInfo> {
        val apps = listOf(
            AppInfo("微信", PKG_WECHAT, "社交"),
            AppInfo("支付宝", PKG_ALIPAY, "支付"),
            AppInfo("淘宝", PKG_TAOBAO, "购物"),
            AppInfo("京东", PKG_JD, "购物"),
            AppInfo("美团", PKG_MEITUAN, "外卖"),
            AppInfo("饿了么", PKG_ELEME, "外卖")
        )
        
        return apps.filter { isAppInstalled(it.packageName) }
    }
    
    data class AppInfo(
        val name: String,
        val packageName: String,
        val category: String
    )
    
    /**
     * 🌐 在浏览器中打开URL
     */
    fun openInBrowser(url: String): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            LogManager.d(TAG, "✅ 在浏览器中打开: $url")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "在浏览器中打开失败", e)
            false
        }
    }
    
    /**
     * 📧 发送邮件
     */
    fun sendEmail(to: String, subject: String? = null, body: String? = null): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:$to")
                subject?.let { putExtra(Intent.EXTRA_SUBJECT, it) }
                body?.let { putExtra(Intent.EXTRA_TEXT, it) }
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            LogManager.d(TAG, "✅ 发送邮件: $to")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "发送邮件失败", e)
            false
        }
    }
    
    /**
     * 📍 在地图中打开位置
     */
    fun openInMap(latitude: Double, longitude: Double, label: String? = null): Boolean {
        return try {
            val uri = if (label != null) {
                "geo:$latitude,$longitude?q=$latitude,$longitude($label)"
            } else {
                "geo:$latitude,$longitude"
            }
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uri))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            LogManager.d(TAG, "✅ 在地图中打开位置: $latitude, $longitude")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "在地图中打开位置失败", e)
            false
        }
    }
    
    /**
     * 🎵 播放音乐
     */
    fun playMusic(filePath: String): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(Uri.parse(filePath), "audio/*")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            LogManager.d(TAG, "✅ 播放音乐: $filePath")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "播放音乐失败", e)
            false
        }
    }
    
    /**
     * 🎬 播放视频
     */
    fun playVideo(filePath: String): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(Uri.parse(filePath), "video/*")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            LogManager.d(TAG, "✅ 播放视频: $filePath")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "播放视频失败", e)
            false
        }
    }
}
