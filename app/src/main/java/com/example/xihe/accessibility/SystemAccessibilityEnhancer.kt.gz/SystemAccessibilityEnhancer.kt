package com.example.xihe.accessibility

import android.accessibilityservice.AccessibilityService
import android.app.NotificationManager
import android.content.Context
import android.media.AudioManager
import android.os.Build
import android.provider.Settings
import android.service.notification.StatusBarNotification
import com.example.xihe.utils.LogManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.annotation.RequiresApi

/**
 * 🔧 系统无障碍功能增强器
 * 提供系统级操作能力（通知、音量、亮度等）
 */
class SystemAccessibilityEnhancer(
    private val context: Context,
    private val service: AccessibilityService?
) {
    
    companion object {
        private const val TAG = "SystemAccessibilityEnhancer"
    }
    
    private val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    
    // ============ 通知栏操作 ============
    
    /**
     * 📬 获取所有活动通知
     */
    @RequiresApi(Build.VERSION_CODES.M)
    fun getActiveNotifications(): List<NotificationInfo> {
        return try {
            val notifications = notificationManager.activeNotifications
            notifications.map { notification ->
                NotificationInfo(
                    id = notification.id,
                    packageName = notification.packageName,
                    title = notification.notification.extras.getString("android.title") ?: "",
                    text = notification.notification.extras.getString("android.text")?.toString() ?: "",
                    time = notification.postTime,
                    isClearable = notification.isClearable,
                    key = notification.key
                )
            }
        } catch (e: Exception) {
            LogManager.i(TAG, "❌ 获取通知失败", e)
            emptyList()
        }
    }
    
    /**
     * 🗑️ 清除指定通知
     */
    fun dismissNotification(key: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP && service != null) {
                // 使用反射调用 cancelNotification 方法
                val method = service.javaClass.getMethod("cancelNotification", String::class.java)
                method.invoke(service, key)
                LogManager.i(TAG, "🗑️ 已清除通知: $key")
                true
            } else {
                false
            }
        } catch (e: Exception) {
            LogManager.i(TAG, "❌ 清除通知失败", e)
            false
        }
    }
    
    /**
     * 🗑️ 清除所有通知
     */
    fun dismissAllNotifications(): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && service != null) {
                val notifications = notificationManager.activeNotifications
                val method = service.javaClass.getMethod("cancelNotification", String::class.java)
                notifications.forEach { notification ->
                    method.invoke(service, notification.key)
                }
                LogManager.i(TAG, "🗑️ 已清除所有通知")
                true
            } else {
                false
            }
        } catch (e: Exception) {
            LogManager.i(TAG, "❌ 清除通知失败", e)
            false
        }
    }
    
    /**
     * 👆 点击通知（打开应用）
     */
    fun clickNotification(key: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val notifications = notificationManager.activeNotifications
                val notification = notifications.find { it.key == key }
                
                if (notification != null) {
                    notification.notification.contentIntent?.send()
                    LogManager.i(TAG, "👆 已点击通知: $key")
                    true
                } else {
                    false
                }
            } else {
                false
            }
        } catch (e: Exception) {
            LogManager.i(TAG, "❌ 点击通知失败", e)
            false
        }
    }
    
    // ============ 音量控制 ============
    
    /**
     * 🔊 获取当前音量
     */
    fun getCurrentVolume(streamType: VolumeStreamType = VolumeStreamType.MUSIC): Int {
        val stream = when (streamType) {
            VolumeStreamType.MUSIC -> AudioManager.STREAM_MUSIC
            VolumeStreamType.RING -> AudioManager.STREAM_RING
            VolumeStreamType.ALARM -> AudioManager.STREAM_ALARM
            VolumeStreamType.NOTIFICATION -> AudioManager.STREAM_NOTIFICATION
            VolumeStreamType.SYSTEM -> AudioManager.STREAM_SYSTEM
        }
        return audioManager.getStreamVolume(stream)
    }
    
    /**
     * 🔊 获取最大音量
     */
    fun getMaxVolume(streamType: VolumeStreamType = VolumeStreamType.MUSIC): Int {
        val stream = when (streamType) {
            VolumeStreamType.MUSIC -> AudioManager.STREAM_MUSIC
            VolumeStreamType.RING -> AudioManager.STREAM_RING
            VolumeStreamType.ALARM -> AudioManager.STREAM_ALARM
            VolumeStreamType.NOTIFICATION -> AudioManager.STREAM_NOTIFICATION
            VolumeStreamType.SYSTEM -> AudioManager.STREAM_SYSTEM
        }
        return audioManager.getStreamMaxVolume(stream)
    }
    
    /**
     * 🔊 设置音量
     */
    fun setVolume(
        volume: Int,
        streamType: VolumeStreamType = VolumeStreamType.MUSIC,
        showUI: Boolean = true
    ): Boolean {
        return try {
            val stream = when (streamType) {
                VolumeStreamType.MUSIC -> AudioManager.STREAM_MUSIC
                VolumeStreamType.RING -> AudioManager.STREAM_RING
                VolumeStreamType.ALARM -> AudioManager.STREAM_ALARM
                VolumeStreamType.NOTIFICATION -> AudioManager.STREAM_NOTIFICATION
                VolumeStreamType.SYSTEM -> AudioManager.STREAM_SYSTEM
            }
            
            val maxVolume = audioManager.getStreamMaxVolume(stream)
            val targetVolume = volume.coerceIn(0, maxVolume)
            
            val flags = if (showUI) AudioManager.FLAG_SHOW_UI else 0
            audioManager.setStreamVolume(stream, targetVolume, flags)
            
            LogManager.i(TAG, "🔊 音量已设置: $targetVolume/$maxVolume")
            true
        } catch (e: Exception) {
            LogManager.i(TAG, "❌ 设置音量失败", e)
            false
        }
    }
    
    /**
     * 🔇 静音/取消静音
     */
    fun setMute(mute: Boolean, streamType: VolumeStreamType = VolumeStreamType.MUSIC): Boolean {
        return try {
            val stream = when (streamType) {
                VolumeStreamType.MUSIC -> AudioManager.STREAM_MUSIC
                VolumeStreamType.RING -> AudioManager.STREAM_RING
                VolumeStreamType.ALARM -> AudioManager.STREAM_ALARM
                VolumeStreamType.NOTIFICATION -> AudioManager.STREAM_NOTIFICATION
                VolumeStreamType.SYSTEM -> AudioManager.STREAM_SYSTEM
            }
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val direction = if (mute) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE
                audioManager.adjustStreamVolume(stream, direction, 0)
            } else {
                @Suppress("DEPRECATION")
                audioManager.setStreamMute(stream, mute)
            }
            
            LogManager.i(TAG, "🔇 静音状态: $mute")
            true
        } catch (e: Exception) {
            LogManager.i(TAG, "❌ 设置静音失败", e)
            false
        }
    }
    
    /**
     * 🔊 增大音量
     */
    fun volumeUp(streamType: VolumeStreamType = VolumeStreamType.MUSIC): Boolean {
        return try {
            val stream = when (streamType) {
                VolumeStreamType.MUSIC -> AudioManager.STREAM_MUSIC
                VolumeStreamType.RING -> AudioManager.STREAM_RING
                VolumeStreamType.ALARM -> AudioManager.STREAM_ALARM
                VolumeStreamType.NOTIFICATION -> AudioManager.STREAM_NOTIFICATION
                VolumeStreamType.SYSTEM -> AudioManager.STREAM_SYSTEM
            }
            
            audioManager.adjustStreamVolume(stream, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            LogManager.i(TAG, "🔊 音量增大")
            true
        } catch (e: Exception) {
            LogManager.i(TAG, "❌ 增大音量失败", e)
            false
        }
    }
    
    /**
     * 🔉 减小音量
     */
    fun volumeDown(streamType: VolumeStreamType = VolumeStreamType.MUSIC): Boolean {
        return try {
            val stream = when (streamType) {
                VolumeStreamType.MUSIC -> AudioManager.STREAM_MUSIC
                VolumeStreamType.RING -> AudioManager.STREAM_RING
                VolumeStreamType.ALARM -> AudioManager.STREAM_ALARM
                VolumeStreamType.NOTIFICATION -> AudioManager.STREAM_NOTIFICATION
                VolumeStreamType.SYSTEM -> AudioManager.STREAM_SYSTEM
            }
            
            audioManager.adjustStreamVolume(stream, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            LogManager.i(TAG, "🔉 音量减小")
            true
        } catch (e: Exception) {
            LogManager.i(TAG, "❌ 减小音量失败", e)
            false
        }
    }
    
    // ============ 亮度控制 ============
    
    /**
     * ☀️ 获取当前亮度（0-255）
     */
    fun getCurrentBrightness(): Int {
        return try {
            Settings.System.getInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS
            )
        } catch (e: Exception) {
            LogManager.i(TAG, "❌ 获取亮度失败", e)
            -1
        }
    }
    
    /**
     * ☀️ 设置亮度（0-255）
     * 注意：需要 WRITE_SETTINGS 权限
     */
    fun setBrightness(brightness: Int): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (!Settings.System.canWrite(context)) {
                    LogManager.i(TAG, "⚠️ 没有修改系统设置权限")
                    return false
                }
            }
            
            val targetBrightness = brightness.coerceIn(0, 255)
            
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS,
                targetBrightness
            )
            
            LogManager.i(TAG, "☀️ 亮度已设置: $targetBrightness")
            true
        } catch (e: Exception) {
            LogManager.i(TAG, "❌ 设置亮度失败", e)
            false
        }
    }
    
    /**
     * ☀️ 设置自动亮度
     */
    fun setAutoBrightness(enable: Boolean): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (!Settings.System.canWrite(context)) {
                    LogManager.i(TAG, "⚠️ 没有修改系统设置权限")
                    return false
                }
            }
            
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                if (enable) Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
                else Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            )
            
            LogManager.i(TAG, "☀️ 自动亮度: $enable")
            true
        } catch (e: Exception) {
            LogManager.i(TAG, "❌ 设置自动亮度失败", e)
            false
        }
    }
    
    // ============ 快捷设置 ============
    
    /**
     * 📱 打开快捷设置面板
     */
    fun openQuickSettings(): Boolean {
        return try {
            service?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
            LogManager.i(TAG, "📱 打开快捷设置")
            true
        } catch (e: Exception) {
            LogManager.i(TAG, "❌ 打开快捷设置失败", e)
            false
        }
    }
    
    /**
     * 🔔 打开通知栏
     */
    fun openNotificationShade(): Boolean {
        return try {
            service?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            LogManager.i(TAG, "🔔 打开通知栏")
            true
        } catch (e: Exception) {
            LogManager.i(TAG, "❌ 打开通知栏失败", e)
            false
        }
    }
    
    /**
     * 🏠 返回主屏幕
     */
    fun goHome(): Boolean {
        return try {
            service?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            LogManager.i(TAG, "🏠 返回主屏幕")
            true
        } catch (e: Exception) {
            LogManager.i(TAG, "❌返回主屏幕失败", e)
            false
        }
    }
    
    /**
     * 🔙 返回上一页
     */
    fun goBack(): Boolean {
        return try {
            service?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            LogManager.i(TAG, "🔙 返回上一页")
            true
        } catch (e: Exception) {
            LogManager.i(TAG, "❌ 返回失败", e)
            false
        }
    }
    
    /**
     * 📱 打开最近任务
     */
    fun openRecentApps(): Boolean {
        return try {
            service?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
            LogManager.i(TAG, "📱 打开最近任务")
            true
        } catch (e: Exception) {
            LogManager.i(TAG, "❌ 打开最近任务失败", e)
            false
        }
    }
    
    /**
     * 🔒 锁屏
     */
    @RequiresApi(Build.VERSION_CODES.P)
    fun lockScreen(): Boolean {
        return try {
            service?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
            LogManager.i(TAG, "🔒 锁屏")
            true
        } catch (e: Exception) {
            LogManager.i(TAG, "❌ 锁屏失败", e)
            false
        }
    }
    
    /**
     * 📸 截屏
     */
    @RequiresApi(Build.VERSION_CODES.P)
    fun takeScreenshot(): Boolean {
        return try {
            service?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
            LogManager.i(TAG, "📸 截屏")
            true
        } catch (e: Exception) {
            LogManager.i(TAG, "❌ 截屏失败", e)
            false
        }
    }
    
    /**
     * 💬 打开语音助手
     */
    @RequiresApi(Build.VERSION_CODES.S)
    fun openVoiceAssistant(): Boolean {
        return try {
            service?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_ACCESSIBILITY_ALL_APPS)
            LogManager.i(TAG, "💬 打开语音助手")
            true
        } catch (e: Exception) {
            LogManager.i(TAG, "❌ 打开语音助手失败", e)
            false
        }
    }
    
    // ============ 数据类型 ============
    
    /**
     * 📬 通知信息
     */
    data class NotificationInfo(
        val id: Int,
        val packageName: String,
        val title: String,
        val text: String,
        val time: Long,
        val isClearable: Boolean,
        val key: String
    )
    
    /**
     * 🔊 音量类型
     */
    enum class VolumeStreamType {
        MUSIC,          // 媒体音量
        RING,           // 铃声音量
        ALARM,          // 闹钟音量
        NOTIFICATION,   // 通知音量
        SYSTEM          // 系统音量
    }
}
