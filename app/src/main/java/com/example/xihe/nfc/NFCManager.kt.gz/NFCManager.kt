package com.example.xihe.nfc

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.nfc.NfcAdapter
import android.nfc.NfcManager as SystemNfcManager
import android.nfc.Tag
import android.nfc.tech.*
import android.os.Build
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException

/**
 * 📲 NFC管理器
 * 提供NFC读取、写入、模拟等功能
 */
class NFCManager private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "NFCManager"
        
        @Volatile
        private var instance: NFCManager? = null
        
        fun getInstance(context: Context): NFCManager {
            return instance ?: synchronized(this) {
                instance ?: NFCManager(context.applicationContext).also { instance = it }
            }
        }
    }
    
    private val systemNfcManager = context.getSystemService(Context.NFC_SERVICE) as? SystemNfcManager
    private val nfcAdapter: NfcAdapter? = systemNfcManager?.defaultAdapter
    
    /**
     * NFC标签信息
     */
    data class NFCTagInfo(
        val id: String,
        val techList: List<String>,
        val type: String,
        val data: String? = null
    )
    
    /**
     * NDEF消息
     */
    data class NDEFMessage(
        val records: List<NDEFRecord>
    )
    
    data class NDEFRecord(
        val type: String,
        val payload: String
    )
    
    /**
     * 📲 检查NFC是否可用
     */
    fun isNFCAvailable(): Boolean {
        return nfcAdapter != null
    }
    
    /**
     * 📲 检查NFC是否开启
     */
    fun isNFCEnabled(): Boolean {
        return nfcAdapter?.isEnabled == true
    }
    
    /**
     * ⚙️ 打开NFC设置
     */
    fun openNFCSettings(): Boolean {
        return try {
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                Intent(android.provider.Settings.ACTION_NFC_SETTINGS)
            } else {
                Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS)
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "打开NFC设置失败", e)
            false
        }
    }
    
    /**
     * 📖 读取NFC标签
     */
    suspend fun readTag(tag: Tag): NFCTagInfo = withContext(Dispatchers.IO) {
        try {
            val id = bytesToHexString(tag.id)
            val techList = tag.techList.toList()
            
            // 尝试读取NDEF数据
            val data = readNDEFData(tag)
            
            val type = when {
                techList.contains(Ndef::class.java.name) -> "NDEF"
                techList.contains(NfcA::class.java.name) -> "NFC-A"
                techList.contains(NfcB::class.java.name) -> "NFC-B"
                techList.contains(NfcF::class.java.name) -> "NFC-F"
                techList.contains(NfcV::class.java.name) -> "NFC-V"
                techList.contains(IsoDep::class.java.name) -> "ISO-DEP"
                techList.contains(MifareClassic::class.java.name) -> "Mifare Classic"
                techList.contains(MifareUltralight::class.java.name) -> "Mifare Ultralight"
                else -> "Unknown"
            }
            
            LogManager.i(TAG, "📖 读取NFC标签: ID=$id, Type=$type")
            NFCTagInfo(id, techList, type, data)
        } catch (e: Exception) {
            LogManager.e(TAG, "读取NFC标签失败", e)
            NFCTagInfo("", emptyList(), "Error", e.message)
        }
    }
    
    /**
     * 📖 读取NDEF数据
     */
    private fun readNDEFData(tag: Tag): String? {
        return try {
            val ndef = Ndef.get(tag) ?: return null
            ndef.connect()
            
            val ndefMessage = ndef.ndefMessage
            if (ndefMessage != null) {
                val records = ndefMessage.records
                val sb = StringBuilder()
                
                records.forEach { record ->
                    val payload = String(record.payload, Charsets.UTF_8)
                    sb.append(payload).append("\n")
                }
                
                ndef.close()
                sb.toString().trim()
            } else {
                ndef.close()
                null
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "读取NDEF数据失败", e)
            null
        }
    }
    
    /**
     * ✍️ 写入NDEF数据
     */
    suspend fun writeNDEF(tag: Tag, text: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val ndef = Ndef.get(tag)
            if (ndef == null) {
                LogManager.w(TAG, "⚠️ 标签不支持NDEF")
                return@withContext false
            }
            
            ndef.connect()
            
            if (!ndef.isWritable) {
                LogManager.w(TAG, "⚠️ 标签不可写")
                ndef.close()
                return@withContext false
            }
            
            // 创建NDEF记录
            val textRecord = createTextRecord(text)
            val ndefMessage = android.nfc.NdefMessage(arrayOf(textRecord))
            
            // 检查容量
            val size = ndefMessage.toByteArray().size
            if (ndef.maxSize < size) {
                LogManager.w(TAG, "⚠️ 数据太大，超过标签容量")
                ndef.close()
                return@withContext false
            }
            
            // 写入数据
            ndef.writeNdefMessage(ndefMessage)
            ndef.close()
            
            LogManager.i(TAG, "✍️ 写入NDEF数据成功")
            true
        } catch (e: IOException) {
            LogManager.e(TAG, "写入NDEF数据失败", e)
            false
        }
    }
    
    /**
     * 🏷️ 创建文本记录
     */
    private fun createTextRecord(text: String): android.nfc.NdefRecord {
        val langBytes = Charsets.US_ASCII.encode("en")
        val textBytes = Charsets.UTF_8.encode(text)
        
        val utfBit: Byte = 0
        val status = (utfBit + langBytes.remaining()).toByte()
        
        val data = ByteArray(1 + langBytes.remaining() + textBytes.remaining())
        data[0] = status
        
        langBytes.get(data, 1, langBytes.remaining())
        textBytes.get(data, 1 + langBytes.remaining(), textBytes.remaining())
        
        return android.nfc.NdefRecord(
            android.nfc.NdefRecord.TNF_WELL_KNOWN,
            android.nfc.NdefRecord.RTD_TEXT,
            ByteArray(0),
            data
        )
    }
    
    /**
     * 📖 读取Mifare Classic卡
     */
    suspend fun readMifareClassic(tag: Tag, sector: Int = 0): String? = withContext(Dispatchers.IO) {
        try {
            val mfc = MifareClassic.get(tag) ?: return@withContext null
            mfc.connect()
            
            // 使用默认密钥认证
            val authenticated = mfc.authenticateSectorWithKeyA(sector, MifareClassic.KEY_DEFAULT)
            if (!authenticated) {
                LogManager.w(TAG, "⚠️ Mifare Classic认证失败")
                mfc.close()
                return@withContext null
            }
            
            // 读取第一个块
            val block = mfc.sectorToBlock(sector)
            val data = mfc.readBlock(block)
            
            mfc.close()
            
            bytesToHexString(data)
        } catch (e: Exception) {
            LogManager.e(TAG, "读取Mifare Classic失败", e)
            null
        }
    }
    
    /**
     * ✍️ 写入Mifare Classic卡
     */
    suspend fun writeMifareClassic(tag: Tag, sector: Int, data: ByteArray): Boolean = withContext(Dispatchers.IO) {
        try {
            val mfc = MifareClassic.get(tag) ?: return@withContext false
            mfc.connect()
            
            val authenticated = mfc.authenticateSectorWithKeyA(sector, MifareClassic.KEY_DEFAULT)
            if (!authenticated) {
                LogManager.w(TAG, "⚠️ Mifare Classic认证失败")
                mfc.close()
                return@withContext false
            }
            
            val block = mfc.sectorToBlock(sector)
            
            // 确保数据长度为16字节
            val blockData = if (data.size < 16) {
                data + ByteArray(16 - data.size)
            } else {
                data.copyOf(16)
            }
            
            mfc.writeBlock(block, blockData)
            mfc.close()
            
            LogManager.i(TAG, "✍️ 写入Mifare Classic成功")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "写入Mifare Classic失败", e)
            false
        }
    }
    
    /**
     * 📱 获取NFC适配器信息
     */
    fun getNFCAdapterInfo(): NFCAdapterInfo? {
        return try {
            if (nfcAdapter == null) return null
            
            NFCAdapterInfo(
                isEnabled = nfcAdapter.isEnabled,
                isAvailable = true
            )
        } catch (e: Exception) {
            null
        }
    }
    
    data class NFCAdapterInfo(
        val isEnabled: Boolean,
        val isAvailable: Boolean
    )
    
    /**
     * 🔧 字节数组转十六进制字符串
     */
    private fun bytesToHexString(bytes: ByteArray): String {
        val hexChars = "0123456789ABCDEF"
        val result = StringBuilder(bytes.size * 2)
        
        bytes.forEach { byte ->
            val i = byte.toInt()
            result.append(hexChars[i shr 4 and 0x0F])
            result.append(hexChars[i and 0x0F])
        }
        
        return result.toString()
    }
    
    /**
     * 🔧 十六进制字符串转字节数组
     */
    fun hexStringToBytes(hex: String): ByteArray {
        val len = hex.length
        val data = ByteArray(len / 2)
        
        var i = 0
        while (i < len) {
            data[i / 2] = ((Character.digit(hex[i], 16) shl 4) + Character.digit(hex[i + 1], 16)).toByte()
            i += 2
        }
        
        return data
    }
    
    /**
     * 📊 获取标签类型描述
     */
    fun getTagTypeDescription(type: String): String {
        return when (type) {
            "NDEF" -> "NDEF格式标签，可存储结构化数据"
            "NFC-A" -> "NFC-A类型标签（ISO 14443-3A）"
            "NFC-B" -> "NFC-B类型标签（ISO 14443-3B）"
            "NFC-F" -> "NFC-F类型标签（JIS 6319-4）"
            "NFC-V" -> "NFC-V类型标签（ISO 15693）"
            "ISO-DEP" -> "ISO-DEP标签（ISO 14443-4）"
            "Mifare Classic" -> "Mifare Classic卡片"
            "Mifare Ultralight" -> "Mifare Ultralight卡片"
            else -> "未知类型标签"
        }
    }
}
