package com.example.xihe.ui.components

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.xihe.core.AutomationEngine
import com.example.xihe.utils.LogManager

@Composable
fun InputBar(
    onSend: (String) -> Unit,
    onAttachImage: (() -> Unit)? = null,
    onAttachFile: (() -> Unit)? = null,
    attachedImageUri: Uri? = null,
    attachedFileName: String? = null,
    onClearAttachment: (() -> Unit)? = null
) {
    var text by remember { mutableStateOf("") }
    var isListening by remember { mutableStateOf(false) }
    var showAttachMenu by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val status by AutomationEngine.status.collectAsStateWithLifecycle()
    val context = LocalContext.current

    Surface(
        color = MaterialTheme.colorScheme.background,
        tonalElevation = 3.dp
    ) {
        Column {
            // 📎 附件预览区域
            if (attachedImageUri != null || attachedFileName != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        if (attachedImageUri != null) Icons.Default.Image else Icons.Default.Description,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = attachedFileName ?: "已选择图片",
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 12.sp,
                        modifier = Modifier.weight(1f),
                        maxLines = 1
                    )
                    IconButton(
                        onClick = { onClearAttachment?.invoke() },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            Icons.Default.Close,
                            contentDescription = "移除附件",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
            
            Row(
                modifier = Modifier
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = { Text("告诉羲和...", color = MaterialTheme.colorScheme.onSurfaceVariant) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        unfocusedBorderColor = Color.Transparent,
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                        focusedTextColor = MaterialTheme.colorScheme.onSurface,
                        unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                    )
                )
                
                Spacer(modifier = Modifier.width(8.dp))
                
                // 麦克风按钮 - 使用离线语音识别
                IconButton(
                    onClick = {
                        isListening = !isListening
                        if (isListening) {
                            LogManager.d("InputBar", "点击麦克风，启动语音识别...")
                            com.example.xihe.core.ModuleCoordinator.startVoiceRecognition { result ->
                                LogManager.d("InputBar", "收到语音识别结果: $result")
                                if (result.isNotBlank()) {
                                    onSend(result)
                                }
                            }
                        } else {
                            com.example.xihe.core.ModuleCoordinator.stopVoiceRecognition()
                            LogManager.d("InputBar", "🛑 停止语音识别")
                        }
                    },
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        if (isListening) Icons.Default.Stop else Icons.Default.Mic,
                        contentDescription = if (isListening) "停止录音" else "开始录音",
                        tint = if (isListening) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                }
                
                Spacer(modifier = Modifier.width(4.dp))
                
                // ➕ 添加附件按钮
                Box {
                    IconButton(
                        onClick = { showAttachMenu = true },
                        modifier = Modifier.size(44.dp)
                    ) {
                        Icon(
                            Icons.Default.Add,
                            contentDescription = "添加图片或文件",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                    
                    DropdownMenu(
                        expanded = showAttachMenu,
                        onDismissRequest = { showAttachMenu = false },
                        modifier = Modifier.background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        DropdownMenuItem(
                            text = { 
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Image, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text("选择图片", color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp)
                                }
                            },
                            onClick = {
                                showAttachMenu = false
                                onAttachImage?.invoke()
                            }
                        )
                        DropdownMenuItem(
                            text = { 
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Description, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text("选择文件", color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp)
                                }
                            },
                            onClick = {
                                showAttachMenu = false
                                onAttachFile?.invoke()
                            }
                        )
                    }
                }
                
                Spacer(modifier = Modifier.width(4.dp))
                
                // 📤 发送/停止按钮
                val isAIResponding = status.contains("AI回复") || status.contains("生成") || status.contains("处理中") || status.contains("分析")
                
                FloatingActionButton(
                    onClick = { 
                        if (isAIResponding) {
                            AutomationEngine.stopCurrentTask()
                        } else if (text.isNotBlank() || attachedImageUri != null || attachedFileName != null) {
                            onSend(text)
                            text = ""
                        }
                    },
                    containerColor = if (isAIResponding) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        if (isAIResponding) Icons.Default.Stop else Icons.Default.Send,
                        contentDescription = if (isAIResponding) "停止回复" else "发送",
                        tint = if (isAIResponding) {
                            MaterialTheme.colorScheme.onError
                        } else {
                            MaterialTheme.colorScheme.onPrimary
                        }
                    )
                }
            }
        }
    }
}
