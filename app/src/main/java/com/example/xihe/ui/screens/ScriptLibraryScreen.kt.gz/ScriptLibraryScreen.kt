package com.example.xihe.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.xihe.automation.script.SmartScriptManager
import com.example.xihe.automation.script.SmartScript
import com.example.xihe.ui.theme.DeepSpaceBlue
import kotlinx.coroutines.launch

/**
 * 📚 智能脚本库界面
 * 展示并管理 AI 学习到和用户自定义的脚本
 * 支持导入、导出、删除、批量管理和验证功能
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ScriptLibraryScreen(
    onBack: () -> Unit,
    onEditScript: (String) -> Unit,
    onValidateScript: ((String) -> Unit)? = null
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    var scripts by remember { mutableStateOf(SmartScriptManager.getAllScripts()) }
    var searchQuery by remember { mutableStateOf("") }
    
    // 批量管理状态
    var isBatchMode by remember { mutableStateOf(false) }
    var selectedScripts by remember { mutableStateOf(setOf<String>()) }
    
    // 对话框状态
    var showDeleteDialog by remember { mutableStateOf(false) }
    var scriptToDelete by remember { mutableStateOf<SmartScript?>(null) }
    var showImportConflictDialog by remember { mutableStateOf(false) }
    var conflictScript by remember { mutableStateOf<Pair<SmartScript, SmartScript>?>(null) }
    var pendingImportJson by remember { mutableStateOf<String?>(null) }
    
    // 文件选择器
    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            scope.launch {
                when (val result = SmartScriptManager.importScript(context, it)) {
                    is SmartScriptManager.ImportResult.Success -> {
                        scripts = SmartScriptManager.getAllScripts()
                        Toast.makeText(context, "导入成功: ${result.script.metadata.name}", Toast.LENGTH_SHORT).show()
                    }
                    is SmartScriptManager.ImportResult.Conflict -> {
                        conflictScript = result.existingScript to result.newScript
                        showImportConflictDialog = true
                    }
                    is SmartScriptManager.ImportResult.Error -> {
                        Toast.makeText(context, "导入失败: ${result.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }
    
    // 刷新脚本列表
    fun refreshScripts() {
        scripts = if (searchQuery.isBlank()) {
            SmartScriptManager.getAllScripts()
        } else {
            SmartScriptManager.searchScripts(searchQuery)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(if (isBatchMode) "已选择 ${selectedScripts.size} 项" else "智能脚本库") 
                },
                navigationIcon = {
                    IconButton(onClick = {
                        if (isBatchMode) {
                            isBatchMode = false
                            selectedScripts = emptySet()
                        } else {
                            onBack()
                        }
                    }) {
                        Icon(
                            if (isBatchMode) Icons.Default.Close else Icons.Default.ArrowBack, 
                            "返回"
                        )
                    }
                },
                actions = {
                    if (isBatchMode) {
                        // 批量模式操作
                        IconButton(
                            onClick = {
                                selectedScripts = if (selectedScripts.size == scripts.size) {
                                    emptySet()
                                } else {
                                    scripts.map { it.id }.toSet()
                                }
                            }
                        ) {
                            Icon(
                                if (selectedScripts.size == scripts.size) Icons.Default.CheckBox 
                                else Icons.Default.CheckBoxOutlineBlank,
                                "全选"
                            )
                        }
                        IconButton(
                            onClick = {
                                if (selectedScripts.isNotEmpty()) {
                                    scope.launch {
                                        val result = SmartScriptManager.exportScripts(context, selectedScripts.toList())
                                        when (result) {
                                            is SmartScriptManager.ExportResult.Success -> {
                                                Toast.makeText(context, "导出成功: ${result.fileName}", Toast.LENGTH_SHORT).show()
                                            }
                                            is SmartScriptManager.ExportResult.Error -> {
                                                Toast.makeText(context, "导出失败: ${result.message}", Toast.LENGTH_LONG).show()
                                            }
                                        }
                                    }
                                }
                            },
                            enabled = selectedScripts.isNotEmpty()
                        ) {
                            Icon(Icons.Default.Share, "批量导出")
                        }
                        IconButton(
                            onClick = {
                                if (selectedScripts.isNotEmpty()) {
                                    showDeleteDialog = true
                                }
                            },
                            enabled = selectedScripts.isNotEmpty()
                        ) {
                            Icon(Icons.Default.Delete, "批量删除", tint = Color.Red.copy(alpha = 0.8f))
                        }
                    } else {
                        // 普通模式操作
                        IconButton(onClick = { isBatchMode = true }) {
                            Icon(Icons.Default.Checklist, "批量管理")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DeepSpaceBlue.Primary
                )
            )
        },
        floatingActionButton = {
            if (!isBatchMode) {
                FloatingActionButton(
                    onClick = { importLauncher.launch(arrayOf("application/json")) },
                    containerColor = DeepSpaceBlue.Accent
                ) {
                    Icon(Icons.Default.Add, "导入脚本")
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(DeepSpaceBlue.Secondary)
        ) {
            // 搜索框
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { 
                    searchQuery = it 
                    refreshScripts()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                placeholder = { Text("搜索脚本...", color = Color.Gray) },
                leadingIcon = { Icon(Icons.Default.Search, null, tint = Color.Gray) },
                shape = RoundedCornerShape(12.dp)
            )

            if (scripts.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.FolderOpen,
                            contentDescription = null,
                            modifier = Modifier.size(64.dp),
                            tint = Color.Gray
                        )
                        Spacer(Modifier.height(16.dp))
                        Text("暂无脚本", color = Color.Gray)
                        Spacer(Modifier.height(8.dp))
                        Text("点击右下角按钮导入脚本", color = Color.Gray, fontSize = 12.sp)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(scripts, key = { it.id }) { script ->
                        ScriptItemCard(
                            script = script,
                            isSelected = selectedScripts.contains(script.id),
                            isBatchMode = isBatchMode,
                            onClick = {
                                if (isBatchMode) {
                                    selectedScripts = if (selectedScripts.contains(script.id)) {
                                        selectedScripts - script.id
                                    } else {
                                        selectedScripts + script.id
                                    }
                                } else {
                                    onEditScript(script.id)
                                }
                            },
                            onLongClick = {
                                if (!isBatchMode) {
                                    isBatchMode = true
                                    selectedScripts = setOf(script.id)
                                }
                            },
                            onValidate = onValidateScript?.let { { it(script.id) } },
                            onExport = {
                                scope.launch {
                                    val result = SmartScriptManager.exportScript(context, script.id)
                                    when (result) {
                                        is SmartScriptManager.ExportResult.Success -> {
                                            Toast.makeText(context, "导出成功: ${result.fileName}", Toast.LENGTH_SHORT).show()
                                        }
                                        is SmartScriptManager.ExportResult.Error -> {
                                            Toast.makeText(context, "导出失败: ${result.message}", Toast.LENGTH_LONG).show()
                                        }
                                    }
                                }
                            },
                            onDelete = {
                                scriptToDelete = script
                                showDeleteDialog = true
                            }
                        )
                    }
                }
            }
        }
    }
    
    // 删除确认对话框
    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { 
                showDeleteDialog = false
                scriptToDelete = null
            },
            title = { Text("确认删除") },
            text = {
                Text(
                    if (isBatchMode && selectedScripts.size > 1) {
                        "确定要删除选中的 ${selectedScripts.size} 个脚本吗？此操作不可撤销。"
                    } else {
                        "确定要删除脚本「${scriptToDelete?.metadata?.name}」吗？此操作不可撤销。"
                    }
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (isBatchMode && selectedScripts.size > 1) {
                            val count = SmartScriptManager.deleteScripts(context, selectedScripts.toList())
                            Toast.makeText(context, "已删除 $count 个脚本", Toast.LENGTH_SHORT).show()
                            selectedScripts = emptySet()
                            isBatchMode = false
                        } else {
                            scriptToDelete?.let {
                                if (SmartScriptManager.deleteScript(context, it.id)) {
                                    Toast.makeText(context, "已删除", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                        refreshScripts()
                        showDeleteDialog = false
                        scriptToDelete = null
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = Color.Red)
                ) {
                    Text("删除")
                }
            },
            dismissButton = {
                TextButton(onClick = { 
                    showDeleteDialog = false
                    scriptToDelete = null
                }) {
                    Text("取消")
                }
            }
        )
    }
    
    // 导入冲突对话框
    if (showImportConflictDialog && conflictScript != null) {
        AlertDialog(
            onDismissRequest = { 
                showImportConflictDialog = false
                conflictScript = null
            },
            title = { Text("脚本已存在") },
            text = {
                Column {
                    Text("已存在同名脚本「${conflictScript?.first?.metadata?.name}」")
                    Spacer(Modifier.height(8.dp))
                    Text("现有版本: v${conflictScript?.first?.metadata?.version}", fontSize = 12.sp, color = Color.Gray)
                    Text("导入版本: v${conflictScript?.second?.metadata?.version}", fontSize = 12.sp, color = Color.Gray)
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        scope.launch {
                            conflictScript?.second?.let { newScript ->
                                SmartScriptManager.saveScript(context, newScript)
                                refreshScripts()
                                Toast.makeText(context, "已覆盖", Toast.LENGTH_SHORT).show()
                            }
                        }
                        showImportConflictDialog = false
                        conflictScript = null
                    }
                ) {
                    Text("覆盖")
                }
            },
            dismissButton = {
                TextButton(onClick = { 
                    showImportConflictDialog = false
                    conflictScript = null
                }) {
                    Text("取消")
                }
            }
        )
    }
}


@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ScriptItemCard(
    script: SmartScript,
    isSelected: Boolean = false,
    isBatchMode: Boolean = false,
    onClick: () -> Unit,
    onLongClick: () -> Unit = {},
    onValidate: (() -> Unit)? = null,
    onExport: (() -> Unit)? = null,
    onDelete: (() -> Unit)? = null
) {
    var showMenu by remember { mutableStateOf(false) }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            ),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) {
                DeepSpaceBlue.Accent.copy(alpha = 0.2f)
            } else {
                Color.White.copy(alpha = 0.05f)
            }
        )
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 批量模式下显示复选框
            if (isBatchMode) {
                Checkbox(
                    checked = isSelected,
                    onCheckedChange = { onClick() },
                    colors = CheckboxDefaults.colors(
                        checkedColor = DeepSpaceBlue.Accent
                    )
                )
                Spacer(Modifier.width(8.dp))
            }
            
            Surface(
                color = DeepSpaceBlue.Accent.copy(alpha = 0.2f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.size(48.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        if (script.metadata.intent == "AUTO_GENERATED") Icons.Default.AutoFixHigh else Icons.Default.Description,
                        contentDescription = null,
                        tint = DeepSpaceBlue.Accent
                    )
                }
            }

            Spacer(Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = script.metadata.name,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Text(
                    text = script.metadata.description,
                    color = Color.Gray,
                    fontSize = 12.sp,
                    maxLines = 1
                )
                Row(
                    modifier = Modifier.padding(top = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "v${script.metadata.version}",
                        color = Color.Gray.copy(alpha = 0.7f),
                        fontSize = 10.sp
                    )
                    Text(
                        text = "${script.flow.steps.size} 步骤",
                        color = Color.Gray.copy(alpha = 0.7f),
                        fontSize = 10.sp
                    )
                }
            }

            if (!isBatchMode) {
                Box {
                    IconButton(onClick = { showMenu = true }) {
                        Icon(Icons.Default.MoreVert, null, tint = Color.Gray)
                    }
                    
                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        if (onValidate != null) {
                            DropdownMenuItem(
                                text = { Text("验证脚本") },
                                onClick = {
                                    showMenu = false
                                    onValidate()
                                },
                                leadingIcon = { Icon(Icons.Default.PlayArrow, null) }
                            )
                        }
                        if (onExport != null) {
                            DropdownMenuItem(
                                text = { Text("导出") },
                                onClick = {
                                    showMenu = false
                                    onExport()
                                },
                                leadingIcon = { Icon(Icons.Default.Share, null) }
                            )
                        }
                        if (onDelete != null) {
                            DropdownMenuItem(
                                text = { Text("删除", color = Color.Red.copy(alpha = 0.8f)) },
                                onClick = {
                                    showMenu = false
                                    onDelete()
                                },
                                leadingIcon = { Icon(Icons.Default.Delete, null, tint = Color.Red.copy(alpha = 0.8f)) }
                            )
                        }
                    }
                }
            }
        }
    }
}
