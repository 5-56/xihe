package com.example.xihe.ui.animation

import androidx.compose.animation.core.*
import androidx.compose.ui.unit.dp

/**
 * ✨ 动画常量定义
 * 统一管理所有动画参数，确保一致的动画体验
 */

object AnimationDurations {
    // 快速动画（按钮点击等）
    const val Fast = 150
    
    // 标准动画（大多数UI变化）
    const val Normal = 300
    
    // 慢速动画（页面切换等）
    const val Slow = 500
    
    // 超慢动画（特殊效果）
    const val VerySlow = 800
}

object AnimationDelays {
    const val None = 0
    const val Short = 50
    const val Medium = 100
    const val Long = 200
}

object AnimationSpecs {
    // 弹簧动画 - 用于有弹性的效果
    val bouncy = spring<Float>(
        dampingRatio = Spring.DampingRatioMediumBouncy,
        stiffness = Spring.StiffnessLow
    )
    
    val mediumBouncy = spring<Float>(
        dampingRatio = Spring.DampingRatioMediumBouncy,
        stiffness = Spring.StiffnessMedium
    )
    
    val lowBouncy = spring<Float>(
        dampingRatio = Spring.DampingRatioLowBouncy,
        stiffness = Spring.StiffnessLow
    )
    
    // Tween动画 - 用于平滑过渡
    val fastTween = tween<Float>(
        durationMillis = AnimationDurations.Fast,
        easing = FastOutSlowInEasing
    )
    
    val normalTween = tween<Float>(
        durationMillis = AnimationDurations.Normal,
        easing = FastOutSlowInEasing
    )
    
    val slowTween = tween<Float>(
        durationMillis = AnimationDurations.Slow,
        easing = FastOutSlowInEasing
    )
    
    // 缓动函数
    val emphasizedEasing = CubicBezierEasing(0.2f, 0.0f, 0.0f, 1.0f)
    val standardEasing = FastOutSlowInEasing
    val accelerateEasing = FastOutLinearInEasing
    val decelerateEasing = LinearOutSlowInEasing
}

object AnimationValues {
    // 缩放值
    const val ScaleNormal = 1f
    const val ScalePressed = 0.95f
    const val ScaleExpanded = 1.1f
    const val ScaleLarge = 1.2f
    
    // 透明度
    const val AlphaVisible = 1f
    const val AlphaHidden = 0f
    const val AlphaDim = 0.6f
    const val AlphaLight = 0.3f
    
    // 偏移量
    val OffsetSmall = 8.dp
    val OffsetMedium = 16.dp
    val OffsetLarge = 32.dp
    
    // 旋转角度
    const val RotationNone = 0f
    const val RotationQuarter = 90f
    const val RotationHalf = 180f
    const val RotationFull = 360f
}

// 预定义的动画组合
object AnimationPresets {
    // 淡入淡出
    fun <T> fadeInOut(durationMillis: Int = AnimationDurations.Normal) = tween<T>(
        durationMillis = durationMillis,
        easing = LinearEasing
    )
    
    // 滑入滑出
    fun <T> slideInOut(durationMillis: Int = AnimationDurations.Normal) = tween<T>(
        durationMillis = durationMillis,
        easing = AnimationSpecs.emphasizedEasing
    )
    
    // 弹跳效果
    fun <T> bounce() = spring<T>(
        dampingRatio = Spring.DampingRatioMediumBouncy,
        stiffness = Spring.StiffnessLow
    )
    
    // 脉冲效果（无限循环）
    fun pulse() = infiniteRepeatable<Float>(
        animation = tween(
            durationMillis = 1000,
            easing = LinearEasing
        ),
        repeatMode = RepeatMode.Reverse
    )
}
