package com.example.xihe.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.xihe.data.ConversationDataManager
import kotlinx.coroutines.launch

/**
 * 📝 自定义训练数据界面
 * 
 * 功能：
 * 1. 手动添加训练对话
 * 2. 预设常用对话模板
 * 3. 批量导入数据
 * 4. 查看已添加的数据
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomDataScreen(
    onBack: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    
    val dataManager = remember { ConversationDataManager.getInstance(context) }
    
    var userInput by remember { mutableStateOf("") }
    var assistantResponse by remember { mutableStateOf("") }
    var showTemplates by remember { mutableStateOf(false) }
    var customDataList by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("📝 添加训练数据") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "返回")
                    }
                },
                actions = {
                    IconButton(onClick = { showTemplates = !showTemplates }) {
                        Icon(
                            if (showTemplates) Icons.Default.Close else Icons.Default.LibraryBooks,
                            "模板"
                        )
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (showTemplates) {
                // 模板选择界面
                TemplateSection(
                    onSelectTemplate = { template ->
                        userInput = template.first
                        assistantResponse = template.second
                        showTemplates = false
                    }
                )
            } else {
                // 主界面
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // 说明卡片
                    CustomInfoCard()
                    
                    // 输入区域
                    InputSection(
                        userInput = userInput,
                        assistantResponse = assistantResponse,
                        onUserInputChange = { userInput = it },
                        onAssistantResponseChange = { assistantResponse = it },
                        onAdd = {
                            if (userInput.isNotBlank() && assistantResponse.isNotBlank()) {
                                customDataList = customDataList + (userInput to assistantResponse)
                                scope.launch {
                                    val record = com.example.xihe.data.ConversationRecord(
                                        userInput = userInput,
                                        systemResponse = assistantResponse,
                                        timestamp = System.currentTimeMillis()
                                    )
                                    dataManager.recordConversation(record)
                                    snackbarHostState.showSnackbar("✅ 已添加训练数据")
                                }
                                userInput = ""
                                assistantResponse = ""
                            }
                        },
                        onClear = {
                            userInput = ""
                            assistantResponse = ""
                        }
                    )
                    
                    // 已添加的数据列表
                    if (customDataList.isNotEmpty()) {
                        AddedDataSection(
                            dataList = customDataList,
                            onRemove = { index ->
                                customDataList = customDataList.filterIndexed { i, _ -> i != index }
                            }
                        )
                    }
                    
                    // 快速操作
                    QuickActionsSection(
                        onSaveAll = {
                            scope.launch {
                                snackbarHostState.showSnackbar("✅ 已保存 ${customDataList.size} 条数据")
                            }
                        },
                        onClearAll = {
                            customDataList = emptyList()
                        }
                    )
                }
            }
        }
    }
}

/**
 * ℹ️ 说明卡片
 */
@Composable
fun CustomInfoCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "💡 添加训练数据说明",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            Divider()
            
            Text(
                text = """
                    • 输入您希望羲和学习的对话
                    • 用户输入：您对羲和说的话
                    • 助手回复：羲和应该如何回答
                    • 添加越多数据，羲和越懂您
                    • 建议添加 100+ 条对话效果更好
                """.trimIndent(),
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

/**
 * ✏️ 输入区域
 */
@Composable
fun InputSection(
    userInput: String,
    assistantResponse: String,
    onUserInputChange: (String) -> Unit,
    onAssistantResponseChange: (String) -> Unit,
    onAdd: () -> Unit,
    onClear: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "✏️ 创建对话",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            Divider()
            
            // 用户输入
            OutlinedTextField(
                value = userInput,
                onValueChange = onUserInputChange,
                label = { Text("👤 用户输入") },
                placeholder = { Text("例如: 打开微信") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )
            
            // 助手回复
            OutlinedTextField(
                value = assistantResponse,
                onValueChange = onAssistantResponseChange,
                label = { Text("🤖 羲和回复") },
                placeholder = { Text("例如: 好的，正在为您打开微信") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )
            
            // 操作按钮
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onClear,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Clear, null)
                    Spacer(Modifier.width(4.dp))
                    Text("清空")
                }
                
                Button(
                    onClick = onAdd,
                    modifier = Modifier.weight(1f),
                    enabled = userInput.isNotBlank() && assistantResponse.isNotBlank()
                ) {
                    Icon(Icons.Default.Add, null)
                    Spacer(Modifier.width(4.dp))
                    Text("添加")
                }
            }
        }
    }
}

/**
 * 📚 模板区域
 */
@Composable
fun TemplateSection(
    onSelectTemplate: (Pair<String, String>) -> Unit
) {
    val templates = remember {
        listOf(
            // 应用操作
            "打开微信" to "好的，正在为您打开微信",
            "打开淘宝" to "好的，正在为您打开淘宝",
            "关闭所有应用" to "好的，正在关闭所有后台应用",
            
            // 消息发送
            "给张三发消息说明天开会" to "好的，正在给张三发送消息：明天开会",
            "告诉李四我马上到" to "好的，正在告诉李四：我马上到",
            "回复王五说收到" to "好的，正在回复王五：收到",
            
            // 搜索查询
            "搜索附近的餐厅" to "好的，正在为您搜索附近的餐厅",
            "查找最近的加油站" to "好的，正在为您查找最近的加油站",
            "搜索今天的新闻" to "好的，正在为您搜索今天的新闻",
            
            // 导航定位
            "导航到公司" to "好的，正在为您规划到公司的路线",
            "带我回家" to "好的，正在为您规划回家的路线",
            "去最近的超市" to "好的，正在为您导航到最近的超市",
            
            // 提醒设置
            "明天早上8点叫我起床" to "好的，已为您设置明天早上8点的闹钟",
            "提醒我下午3点开会" to "好的，已为您设置下午3点的会议提醒",
            "一小时后提醒我" to "好的，已为您设置一小时后的提醒",
            
            // 信息查询
            "今天天气怎么样" to "好的，正在查询今天的天气情况",
            "明天会下雨吗" to "好的，正在查询明天的天气预报",
            "现在几点了" to "现在是{当前时间}",
            
            // 娱乐控制
            "播放音乐" to "好的，正在为您播放音乐",
            "暂停播放" to "好的，已暂停播放",
            "下一首" to "好的，正在切换到下一首",
            
            // 电话通讯
            "拨打电话给张三" to "好的，正在拨打电话给张三",
            "给李四打电话" to "好的，正在拨打电话给李四",
            "挂断电话" to "好的，正在挂断电话",
            
            // 系统设置
            "调高音量" to "好的，已为您调高音量",
            "打开手电筒" to "好的，已为您打开手电筒",
            "关闭蓝牙" to "好的，已为您关闭蓝牙",
            
            // 智能问答
            "你是谁" to "我是羲和，您的AI智能助手",
            "你能做什么" to "我可以帮您打开应用、发送消息、查询信息、设置提醒等等",
            "谢谢" to "不客气，很高兴能帮到您！"
        )
    }
    
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text(
                text = "📚 常用对话模板",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            
            Text(
                text = "点击任意模板快速填充",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 16.dp)
            )
        }
        
        items(templates) { template ->
            TemplateCard(
                userInput = template.first,
                assistantResponse = template.second,
                onClick = { onSelectTemplate(template) }
            )
        }
    }
}

/**
 * 📋 模板卡片
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TemplateCard(
    userInput: String,
    assistantResponse: String,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text("👤", style = MaterialTheme.typography.bodyMedium)
                Text(
                    text = userInput,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text("🤖", style = MaterialTheme.typography.bodyMedium)
                Text(
                    text = assistantResponse,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

/**
 * 📝 已添加数据区域
 */
@Composable
fun AddedDataSection(
    dataList: List<Pair<String, String>>,
    onRemove: (Int) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "📝 已添加 ${dataList.size} 条",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            Divider()
            
            dataList.forEachIndexed { index, data ->
                DataItemCard(
                    userInput = data.first,
                    assistantResponse = data.second,
                    onRemove = { onRemove(index) }
                )
            }
        }
    }
}

/**
 * 📄 数据项卡片
 */
@Composable
fun DataItemCard(
    userInput: String,
    assistantResponse: String,
    onRemove: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "👤 $userInput",
                    style = MaterialTheme.typography.bodySmall
                )
                Text(
                    text = "🤖 $assistantResponse",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            
            IconButton(onClick = onRemove) {
                Icon(
                    Icons.Default.Delete,
                    "删除",
                    tint = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}

/**
 * ⚡ 快速操作区域
 */
@Composable
fun QuickActionsSection(
    onSaveAll: () -> Unit,
    onClearAll: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "⚡ 快速操作",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onClearAll,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.DeleteSweep, null)
                    Spacer(Modifier.width(4.dp))
                    Text("清空全部")
                }
                
                Button(
                    onClick = onSaveAll,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Save, null)
                    Spacer(Modifier.width(4.dp))
                    Text("保存全部")
                }
            }
        }
    }
}
