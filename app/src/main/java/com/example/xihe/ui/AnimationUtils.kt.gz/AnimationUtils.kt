package com.example.xihe.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback

/**
 * 🎨 动画工具类
 * 提供各种UI动画效果
 */
object AnimationUtils {
    
    /**
     * ✨ 淡入淡出动画
     */
    @Composable
    fun <T> CrossfadeTransition(
        targetState: T,
        content: @Composable (T) -> Unit
    ) {
        Crossfade(
            targetState = targetState,
            animationSpec = tween(durationMillis = 300)
        ) { state ->
            content(state)
        }
    }
    
    /**
     * 📊 滑动过渡动画
     */
    @Composable
    fun SlideTransition(
        visible: Boolean,
        direction: SlideDirection = SlideDirection.START,
        content: @Composable () -> Unit
    ) {
        AnimatedVisibility(
            visible = visible,
            enter = when (direction) {
                SlideDirection.START -> slideInHorizontally(
                    initialOffsetX = { -it },
                    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)
                ) + fadeIn()
                SlideDirection.END -> slideInHorizontally(
                    initialOffsetX = { it },
                    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)
                ) + fadeIn()
                SlideDirection.UP -> slideInVertically(
                    initialOffsetY = { it },
                    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)
                ) + fadeIn()
                SlideDirection.DOWN -> slideInVertically(
                    initialOffsetY = { -it },
                    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)
                ) + fadeIn()
            },
            exit = when (direction) {
                SlideDirection.START -> slideOutHorizontally(
                    targetOffsetX = { -it }
                ) + fadeOut()
                SlideDirection.END -> slideOutHorizontally(
                    targetOffsetX = { it }
                ) + fadeOut()
                SlideDirection.UP -> slideOutVertically(
                    targetOffsetY = { -it }
                ) + fadeOut()
                SlideDirection.DOWN -> slideOutVertically(
                    targetOffsetY = { it }
                ) + fadeOut()
            }
        ) {
            content()
        }
    }
    
    /**
     * 🔄 旋转动画
     */
    @Composable
    fun RotatingIcon(
        isRotating: Boolean,
        content: @Composable () -> Unit
    ) {
        val rotation by animateFloatAsState(
            targetValue = if (isRotating) 360f else 0f,
            animationSpec = infiniteRepeatable(
                animation = tween(1000, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "rotation"
        )
        
        androidx.compose.foundation.layout.Box(
            modifier = Modifier.graphicsLayer(rotationZ = rotation)
        ) {
            content()
        }
    }
    
    /**
     * 💫 脉冲动画
     */
    @Composable
    fun PulsingIcon(
        isPulsing: Boolean,
        content: @Composable () -> Unit
    ) {
        val scale by animateFloatAsState(
            targetValue = if (isPulsing) 1.2f else 1.0f,
            animationSpec = infiniteRepeatable(
                animation = tween(800, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "pulse"
        )
        
        androidx.compose.foundation.layout.Box(
            modifier = Modifier.scale(scale)
        ) {
            content()
        }
    }
    
    /**
     * 🌊 波纹扩散动画
     */
    @Composable
    fun rememberRippleAnimation(): Animatable<Float, AnimationVector1D> {
        val rippleAnimation = remember { Animatable(0f) }
        
        LaunchedEffect(Unit) {
            rippleAnimation.animateTo(
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(2000, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart
                )
            )
        }
        
        return rippleAnimation
    }
    
    /**
     * ✨ 展开/折叠动画
     */
    @Composable
    fun ExpandableContent(
        expanded: Boolean,
        content: @Composable () -> Unit
    ) {
        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically(
                animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy)
            ) + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            content()
        }
    }
}

/**
 * 🎯 滑动方向
 */
enum class SlideDirection {
    START, END, UP, DOWN
}

/**
 * 🎭 点击效果扩展
 */
fun Modifier.clickableWithScale(
    onClick: () -> Unit
): Modifier = composed {
    var isPressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.95f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "clickScale"
    )
    
    this
        .scale(scale)
        .pointerInput(Unit) {
            detectTapGestures(
                onPress = {
                    isPressed = true
                    tryAwaitRelease()
                    isPressed = false
                },
                onTap = { onClick() }
            )
        }
}

/**
 * 📳 触觉反馈扩展
 */
fun Modifier.clickableWithHaptic(
    onClick: () -> Unit
): Modifier = composed {
    val haptic = LocalHapticFeedback.current
    
    this.pointerInput(Unit) {
        detectTapGestures(
            onTap = {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onClick()
            }
        )
    }
}

/**
 * 🎨 组合动画效果
 */
fun Modifier.clickableWithEffects(
    onClick: () -> Unit
): Modifier = composed {
    var isPressed by remember { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current
    
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.92f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "scale"
    )
    
    this
        .scale(scale)
        .pointerInput(Unit) {
            detectTapGestures(
                onPress = {
                    isPressed = true
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    tryAwaitRelease()
                    isPressed = false
                },
                onTap = { onClick() }
            )
        }
}

/**
 * 🌈 渐变色动画
 */
@Composable
fun rememberColorAnimation(
    colors: List<androidx.compose.ui.graphics.Color>
): State<androidx.compose.ui.graphics.Color> {
    val infiniteTransition = rememberInfiniteTransition(label = "color")
    
    return infiniteTransition.animateColor(
        initialValue = colors.first(),
        targetValue = colors.last(),
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "colorAnimation"
    )
}

/**
 * 💫 闪烁动画
 */
@Composable
fun rememberBlinkAnimation(): State<Float> {
    val infiniteTransition = rememberInfiniteTransition(label = "blink")
    
    return infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 0.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "blinkAlpha"
    )
}

/**
 * 🎪 摇晃动画
 */
@Composable
fun rememberShakeAnimation(trigger: Boolean): Float {
    val shakeOffset = remember { Animatable(0f) }
    
    LaunchedEffect(trigger) {
        if (trigger) {
            for (i in 0..5) {
                shakeOffset.animateTo(
                    targetValue = if (i % 2 == 0) 10f else -10f,
                    animationSpec = tween(50)
                )
            }
            shakeOffset.animateTo(0f, animationSpec = tween(50))
        }
    }
    
    return shakeOffset.value
}

/**
 * 🎯 弹跳进入动画
 */
fun Modifier.bounceIn(): Modifier = composed {
    var isVisible by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "bounceIn"
    )
    
    LaunchedEffect(Unit) {
        isVisible = true
    }
    
    this.scale(scale)
}

/**
 * 📊 进度条动画
 */
@Composable
fun animateProgressAsState(
    targetProgress: Float,
    durationMillis: Int = 1000
): State<Float> {
    return animateFloatAsState(
        targetValue = targetProgress,
        animationSpec = tween(
            durationMillis = durationMillis,
            easing = FastOutSlowInEasing
        ),
        label = "progress"
    )
}
