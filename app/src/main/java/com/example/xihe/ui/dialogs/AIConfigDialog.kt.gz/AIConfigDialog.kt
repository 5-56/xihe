package com.example.xihe.ui.dialogs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.xihe.core.AutomationEngine
import com.example.xihe.core.PreferencesManager
import com.example.xihe.core.ProviderConfig
import com.example.xihe.core.ProviderRegistry
import com.example.xihe.ui.utils.rememberHapticFeedback
import com.example.xihe.ui.AddCustomProviderDialog
import com.example.xihe.ui.EditCustomProviderDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 🤖 AI配置对话框
 * 
 * 从 SettingsDialogs.kt 中提取
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AIConfigDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val haptic = rememberHapticFeedback()
    
    // 初始化时加载当前活动的提供商
    val currentProviderId: String = remember { PreferencesManager.getCurrentProviderId(context) }
    val initialProvider: ProviderConfig = remember { 
        ProviderRegistry.getProviderById(currentProviderId) ?: ProviderRegistry.providers.first()
    }
    
    // 状态管理
    var selectedProvider by remember { mutableStateOf(initialProvider) }
    var baseUrl by remember { mutableStateOf(AutomationEngine.baseUrl) }
    var apiKey by remember { mutableStateOf(AutomationEngine.apiKey) }
    var selectedModel by remember { mutableStateOf(AutomationEngine.modelName) }
    var useManualModelInput by remember { mutableStateOf(false) }
    
    var availableModels by remember { mutableStateOf<List<String>>(emptyList()) }
    var isFetchingModels by remember { mutableStateOf(false) }
    var isTesting by remember { mutableStateOf(false) }
    var testResult by remember { mutableStateOf<String?>(null) }
    var fetchError by remember { mutableStateOf<String?>(null) }
    var expandedProvider by remember { mutableStateOf(false) }
    var expandedModel by remember { mutableStateOf(false) }
    
    // 自定义提供商对话框
    var showAddProviderDialog by remember { mutableStateOf(false) }
    var showEditProviderDialog by remember { mutableStateOf<ProviderConfig?>(null) }
    var providerToDelete by remember { mutableStateOf<ProviderConfig?>(null) }
    
    // 当提供商切换时，自动加载该提供商的独立配置
    LaunchedEffect(selectedProvider) {
        val savedConfig = PreferencesManager.getProviderConfig(context, selectedProvider.id)
        
        if (savedConfig != null) {
            baseUrl = savedConfig.baseUrl
            apiKey = savedConfig.apiKey
            selectedModel = savedConfig.modelName
        } else {
            baseUrl = selectedProvider.defaultBaseUrl
            apiKey = ""
            selectedModel = ""
        }
        
        availableModels = emptyList()
        testResult = null
        fetchError = null
    }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { 
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("🤖 AI 配置", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
                IconButton(onClick = { 
                    haptic.lightTap()
                    showAddProviderDialog = true 
                }) {
                    Icon(
                        Icons.Default.Add,
                        contentDescription = "添加自定义提供商",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                // 提供商选择
                ProviderSelector(
                    selectedProvider = selectedProvider,
                    onProviderSelected = { provider ->
                        selectedProvider = provider
                        availableModels = emptyList()
                        useManualModelInput = false
                    },
                    onEditProvider = { showEditProviderDialog = it },
                    onDeleteProvider = { providerToDelete = it },
                    expanded = expandedProvider,
                    onExpandedChange = { expandedProvider = it }
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                // Base URL
                ConfigTextField(
                    label = "基础链接 (Base URL)",
                    value = baseUrl,
                    onValueChange = { baseUrl = it },
                    placeholder = "https://api.example.com/v1/"
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // API Key
                ConfigTextField(
                    label = "API 密钥",
                    value = apiKey,
                    onValueChange = { apiKey = it },
                    placeholder = "sk-..."
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // 测试连接按钮
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            if (apiKey.isNotEmpty() && baseUrl.isNotEmpty()) {
                                haptic.lightTap()
                                scope.launch {
                                    isTesting = true
                                    testResult = null
                                    try {
                                        withContext(Dispatchers.IO) {
                                            AutomationEngine.fetchModels(apiKey, baseUrl, selectedProvider.id)
                                        }
                                        testResult = "✅ 连接成功！"
                                    } catch (e: Exception) {
                                        testResult = "❌ 连接失败: ${e.message}"
                                    } finally {
                                        isTesting = false
                                    }
                                }
                            }
                        },
                        modifier = Modifier.weight(1f),
                        enabled = !isTesting && !isFetchingModels && apiKey.isNotEmpty() && baseUrl.isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                    ) {
                        if (isTesting) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = MaterialTheme.colorScheme.onSecondary)
                        } else {
                            Text("🔍 测试连接")
                        }
                    }
                    
                    Button(
                        onClick = {
                            if (apiKey.isNotEmpty() && baseUrl.isNotEmpty()) {
                                haptic.lightTap()
                                scope.launch {
                                    isFetchingModels = true
                                    fetchError = null
                                    try {
                                        val models = withContext(Dispatchers.IO) {
                                            AutomationEngine.fetchModels(apiKey, baseUrl, selectedProvider.id)
                                        }
                                        availableModels = models
                                        if (models.isNotEmpty() && selectedModel.isEmpty()) {
                                            selectedModel = models.first()
                                        }
                                    } catch (e: Exception) {
                                        fetchError = e.message
                                    } finally {
                                        isFetchingModels = false
                                    }
                                }
                            }
                        },
                        modifier = Modifier.weight(1f),
                        enabled = !isFetchingModels && !isTesting && apiKey.isNotEmpty() && baseUrl.isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        if (isFetchingModels) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = MaterialTheme.colorScheme.onPrimary)
                        } else {
                            Text("📋 获取模型")
                        }
                    }
                }
                
                // 测试结果
                testResult?.let { result ->
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        result,
                        color = if (result.startsWith("✅")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                        fontSize = 12.sp
                    )
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // 模型选择
                Text("模型", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                if (availableModels.isNotEmpty() && !useManualModelInput) {
                    ExposedDropdownMenuBox(
                        expanded = expandedModel,
                        onExpandedChange = { expandedModel = !expandedModel }
                    ) {
                        OutlinedTextField(
                            value = selectedModel,
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedModel) },
                            modifier = Modifier.menuAnchor().fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = MaterialTheme.colorScheme.onSurface,
                                unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                        )
                        ExposedDropdownMenu(
                            expanded = expandedModel,
                            onDismissRequest = { expandedModel = false }
                        ) {
                            availableModels.forEach { model ->
                                DropdownMenuItem(
                                    text = { Text(model) },
                                    onClick = {
                                        selectedModel = model
                                        expandedModel = false
                                    }
                                )
                            }
                        }
                    }
                } else {
                    OutlinedTextField(
                        value = selectedModel,
                        onValueChange = { selectedModel = it },
                        placeholder = { Text("gpt-4o-mini") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = MaterialTheme.colorScheme.onSurface,
                            unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    haptic.lightTap()
                    // 保存配置
                    AutomationEngine.updateConfig(
                        selectedProvider.id, baseUrl, apiKey, selectedModel, context
                    )
                    PreferencesManager.saveProviderConfig(
                        context, selectedProvider.id, baseUrl, apiKey, selectedModel
                    )
                    PreferencesManager.saveCurrentProviderId(context, selectedProvider.id)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text("保存")
            }
        },
        dismissButton = {
            TextButton(onClick = { 
                haptic.lightTap()
                onDismiss() 
            }) {
                Text("取消", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        containerColor = MaterialTheme.colorScheme.surface
    )
    
    // 添加自定义提供商对话框
    if (showAddProviderDialog) {
        AddCustomProviderDialog(
            onDismiss = { showAddProviderDialog = false },
            onConfirm = { name, defaultUrl ->
                ProviderRegistry.addCustomProvider(context, name, defaultUrl)
                showAddProviderDialog = false
            }
        )
    }
    
    // 编辑自定义提供商对话框
    showEditProviderDialog?.let { provider ->
        EditCustomProviderDialog(
            provider = provider,
            onDismiss = { showEditProviderDialog = null },
            onConfirm = { id, newName, newUrl ->
                ProviderRegistry.updateCustomProvider(context, id, newName, newUrl)
                showEditProviderDialog = null
            }
        )
    }
    
    // 删除确认对话框
    providerToDelete?.let { provider ->
        AlertDialog(
            onDismissRequest = { providerToDelete = null },
            title = { Text("删除提供商", color = MaterialTheme.colorScheme.onSurface) },
            text = { Text("确定要删除 ${provider.name} 吗？", color = MaterialTheme.colorScheme.onSurface) },
            confirmButton = {
                Button(
                    onClick = {
                        ProviderRegistry.deleteCustomProvider(context, provider.id)
                        if (selectedProvider.id == provider.id) {
                            selectedProvider = ProviderRegistry.providers.first()
                        }
                        providerToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("删除")
                }
            },
            dismissButton = {
                TextButton(onClick = { providerToDelete = null }) {
                    Text("取消", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            containerColor = MaterialTheme.colorScheme.surface
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProviderSelector(
    selectedProvider: ProviderConfig,
    onProviderSelected: (ProviderConfig) -> Unit,
    onEditProvider: (ProviderConfig) -> Unit,
    onDeleteProvider: (ProviderConfig) -> Unit,
    expanded: Boolean,
    onExpandedChange: (Boolean) -> Unit
) {
    val haptic = rememberHapticFeedback()
    
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("提供商", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.weight(1f))
        if (selectedProvider.isCustom) {
            IconButton(
                onClick = { 
                    haptic.lightTap()
                    onEditProvider(selectedProvider) 
                },
                modifier = Modifier.size(32.dp)
            ) {
                Icon(Icons.Default.Edit, contentDescription = "编辑", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
            }
            IconButton(
                onClick = { 
                    haptic.lightTap()
                    onDeleteProvider(selectedProvider) 
                },
                modifier = Modifier.size(32.dp)
            ) {
                Icon(Icons.Default.Delete, contentDescription = "删除", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
            }
        }
    }
    
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { onExpandedChange(!expanded) }) {
        OutlinedTextField(
            value = selectedProvider.name,
            onValueChange = {},
            readOnly = true,
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = MaterialTheme.colorScheme.onSurface,
                unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { onExpandedChange(false) }) {
            ProviderRegistry.providers.forEach { provider ->
                DropdownMenuItem(
                    text = { 
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(provider.name)
                            if (provider.isCustom) {
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("✨", fontSize = 10.sp)
                            }
                        }
                    },
                    onClick = {
                        onProviderSelected(provider)
                        onExpandedChange(false)
                    }
                )
            }
        }
    }
}

@Composable
private fun ConfigTextField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String
) {
    Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        placeholder = { Text(placeholder) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = MaterialTheme.colorScheme.onSurface,
            unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    )
}
