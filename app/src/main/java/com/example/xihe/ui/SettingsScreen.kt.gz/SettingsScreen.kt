package com.example.xihe.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.xihe.ui.utils.rememberHapticFeedback
import com.example.xihe.ai.IntentFeedbackSystem
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onNavigateToAIConfig: () -> Unit,
    onNavigateToPermissions: () -> Unit,
    onNavigateToPersonality: () -> Unit,
    onNavigateToPrivacy: () -> Unit,
    onNavigateToVoiceSettings: () -> Unit,
    onNavigateToTools: () -> Unit,
    onNavigateToExperimental: () -> Unit,
    onNavigateToThemeSettings: () -> Unit = {},
    onStartOverlay: () -> Unit = {},
    onBack: () -> Unit = {}
) {
    val haptic = rememberHapticFeedback()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("设置", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            SettingsMenuItemLocal(
                icon = Icons.Default.Info,
                title = "AI 配置",
                onClick = {
                    haptic.lightTap()
                    onNavigateToAIConfig()
                }
            )
            HorizontalDivider(color = Color.Gray.copy(alpha = 0.3f))
            SettingsMenuItemLocal(
                icon = Icons.Default.Lock,
                title = "系统权限管理",
                onClick = {
                    haptic.lightTap()
                    onNavigateToPermissions()
                }
            )
            HorizontalDivider(color = Color.Gray.copy(alpha = 0.3f))
            SettingsMenuItemLocal(
                icon = Icons.Default.Security,
                title = "🔐 隐私权限设置",
                onClick = {
                    haptic.lightTap()
                    onNavigateToPrivacy()
                }
            )
            HorizontalDivider(color = Color.Gray.copy(alpha = 0.3f))
            SettingsMenuItemLocal(
                icon = Icons.Default.Face,
                title = "🎭 系统性格",
                onClick = {
                    haptic.lightTap()
                    onNavigateToPersonality()
                }
            )
            HorizontalDivider(color = Color.Gray.copy(alpha = 0.3f))
            SettingsMenuItemLocal(
                icon = Icons.Default.Palette,
                title = "🎨 主题设置",
                onClick = {
                    haptic.lightTap()
                    onNavigateToThemeSettings()
                }
            )
            HorizontalDivider(color = Color.Gray.copy(alpha = 0.3f))
            SettingsMenuItemLocal(
                icon = Icons.Default.Mic,
                title = "🎤 语音设置",
                onClick = {
                    haptic.lightTap()
                    onNavigateToVoiceSettings()
                }
            )
            HorizontalDivider(color = Color.Gray.copy(alpha = 0.3f))
            SettingsMenuItemLocal(
                icon = Icons.Default.Build,
                title = "工具与插件",
                onClick = {
                    haptic.lightTap()
                    onNavigateToTools()
                }
            )
            HorizontalDivider(color = Color.Gray.copy(alpha = 0.3f))
            SettingsMenuItemLocal(
                icon = Icons.Default.Star,
                title = "实验性功能",
                onClick = {
                    haptic.lightTap()
                    onNavigateToExperimental()
                }
            )

            HorizontalDivider(color = Color.Gray.copy(alpha = 0.3f))
            SettingsMenuItemLocal(
                icon = Icons.Default.Aod,
                title = "🫧 启动悬浮窗",
                onClick = {
                    haptic.lightTap()
                    onStartOverlay()
                }
            )
            HorizontalDivider(color = Color.Gray.copy(alpha = 0.3f))

            // 🎯 意图理解打分开关
            val feedbackEnabled by IntentFeedbackSystem.feedbackEnabled.collectAsState()
            SettingsSwitchItem(
                icon = Icons.Default.ThumbUp,
                title = "🎯 理解反馈",
                subtitle = "任务/对话结束后显示打分弹窗，帮助羲和学习",
                checked = feedbackEnabled,
                onCheckedChange = {
                    haptic.lightTap()
                    IntentFeedbackSystem.setFeedbackEnabled(it)
                }
            )
        }
    }
}

@Composable
private fun SettingsMenuItemLocal(
    icon: ImageVector,
    title: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = title,
            fontSize = 16.sp,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.weight(1f))
        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun SettingsSwitchItem(
    icon: ImageVector,
    title: String,
    subtitle: String? = null,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = MaterialTheme.colorScheme.primary,
                checkedTrackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
            )
        )
    }
}
