package com.example.xihe.ui.screens

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts.OpenDocument
import androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.core.EngineStateManager
import com.example.xihe.core.ConversationManager
import com.example.xihe.core.Conversation
import com.example.xihe.core.AutomationEngine
import com.example.xihe.ui.AppNavigation
import com.example.xihe.ui.clickableWithScale
import com.example.xihe.ui.components.*
import com.example.xihe.ui.rememberThemeState
import com.example.xihe.ui.XiheTheme
import kotlinx.coroutines.launch
import com.example.xihe.utils.LogManager

@Composable
fun MainScreen() {
    val context = LocalContext.current
    val isServiceConnected by CoreAccessibilityService.isConnected.collectAsStateWithLifecycle()
    val conversationHistory by ConversationManager.getConversations(context).collectAsStateWithLifecycle(initialValue = emptyList())
    
    // 🧭 导航控制器
    val navController = rememberNavController()
    // 获取当前路由
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: "chat"
    
    // 使用新的触觉反馈系统
    val haptic = com.example.xihe.ui.utils.rememberHapticFeedback()
    
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    
    // 移除旧的弹窗状态，现在由 AppNavigation 管理
    var showEditDialog by remember { mutableStateOf<Conversation?>(null) }
    var showRealTimeChat by remember { mutableStateOf(false) } // 📞 实时对话界面
    
    // 📸 图片/文件附件状态
    var attachedImageUri by remember { mutableStateOf<Uri?>(null) }
    var attachedFileName by remember { mutableStateOf<String?>(null) }
    
    // 🖼️ 图片选择器
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = PickVisualMedia()
    ) { uri ->
        uri?.let {
            attachedImageUri = it
            attachedFileName = null
            LogManager.d("MainScreen", "📸 已选择图片: $it")
        }
    }
    
    // 📄 文件选择器
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = OpenDocument()
    ) { uri ->
        uri?.let {
            attachedImageUri = null
            // 获取文件名
            val cursor = context.contentResolver.query(it, null, null, null, null)
            val fileName = cursor?.use { c ->
                if (c.moveToFirst()) {
                    val nameIndex = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (nameIndex >= 0) c.getString(nameIndex) else "文件"
                } else "文件"
            } ?: "文件"
            attachedFileName = fileName
            attachedImageUri = it  // 复用 uri 存储
            LogManager.d("MainScreen", "📄 已选择文件: $fileName")
        }
    }
    
    // 使用新的主题系统
    val themeState = rememberThemeState()
    
    // 🔙 双击退出计时器
    var lastBackPressTime by remember { mutableStateOf(0L) }
    
    // 🏠 主页面列表（底部导航栏的三个页面）
    val mainRoutes = listOf("chat", "training_hub", "settings")
    
    XiheTheme(themeState = themeState) {
        // 🔙 返回键处理：优先级从高到低
        BackHandler(enabled = true) {
            when {
                // 1. 侧边栏打开时，先关闭侧边栏
                drawerState.isOpen -> {
                    scope.launch { drawerState.close() }
                }
                // 2. 实时对话界面打开时，关闭它
                showRealTimeChat -> {
                    showRealTimeChat = false
                    com.example.xihe.core.ModuleCoordinator.stopContinuousVoiceRecognition()
                }
                // 3. 编辑对话弹窗打开时，关闭它
                showEditDialog != null -> {
                    showEditDialog = null
                }
                // 4. 在子页面时（非主页面），返回上一页
                currentRoute !in mainRoutes -> {
                    navController.popBackStack()
                }
                // 5. 在训练或设置主页面时，返回聊天主页面
                currentRoute in listOf("training_hub", "settings") -> {
                    navController.navigate("chat") {
                        popUpTo("chat") { inclusive = true }
                        launchSingleTop = true
                    }
                }
                // 6. 在聊天主页面，双击退出
                else -> {
                    val currentTime = System.currentTimeMillis()
                    if (currentTime - lastBackPressTime < 2000) {
                        // 双击退出 - 通过 Activity 的 finish
                        (context as? android.app.Activity)?.finish()
                    } else {
                        lastBackPressTime = currentTime
                        Toast.makeText(context, "再按一次退出应用", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
        
        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet(
                    drawerContainerColor = MaterialTheme.colorScheme.surface,
                    drawerContentColor = MaterialTheme.colorScheme.onSurface
                ) {
                    DrawerHeader()
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    Spacer(modifier = Modifier.height(16.dp))

                    // New Chat Button with animation
                    Button(
                        onClick = {
                            haptic.mediumTap()
                            scope.launch {
                                // Save current conversation before starting new one
                                val currentMessages = EngineStateManager.messages.value
                                val currentId = AutomationEngine.currentConversationId.value

                                // Always save current conversation if it has any messages
                                if (currentMessages.isNotEmpty()) {
                                    // Generate title from messages
                                    val firstUserMsg = currentMessages.firstOrNull { it.isUser }?.content
                                    val firstAIMsg = currentMessages.firstOrNull { !it.isUser }?.content
                                    
                                    val title = when {
                                        firstUserMsg != null -> {
                                            if (firstUserMsg.length > 30) firstUserMsg.take(30) + "..." 
                                            else firstUserMsg
                                        }
                                        firstAIMsg != null -> {
                                            if (firstAIMsg.length > 30) firstAIMsg.take(30) + "..."
                                            else firstAIMsg
                                        }
                                        else -> "对话 - ${java.text.SimpleDateFormat("HH:mm").format(java.util.Date())}"
                                    }
                                    
                                    val conversation = Conversation(
                                        id = currentId,
                                        title = title,
                                        timestamp = System.currentTimeMillis(),
                                        messages = currentMessages
                                    )
                                    
                                    // Save conversation and wait for completion
                                    ConversationManager.saveConversation(context, conversation)
                                    
                                    // Add a small delay to ensure save is processed
                                    kotlinx.coroutines.delay(100)
                                }
                                
                                // Start new conversation
                                AutomationEngine.newConversation()
                                
                                // Close drawer
                                drawerState.close()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .clickableWithScale { }, // 添加点击缩放效果
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("新建对话", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold)
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    // Conversation History
                    Text(
                        "聊天历史",
                        modifier = Modifier.padding(horizontal = 16.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    // History items
                    LazyColumn(modifier = Modifier.weight(1f)) {
                        items(conversationHistory) { conversation ->
                            com.example.xihe.ui.components.ConversationHistoryItem(
                                conversation = conversation,
                                onLoad = {
                                    AutomationEngine.loadConversation(conversation)
                                    scope.launch { drawerState.close() }
                                },
                                onEdit = {
                                    showEditDialog = conversation
                                },
                                onDelete = {
                                    scope.launch {
                                        ConversationManager.deleteConversation(context, conversation.id)
                                    }
                                }
                            )
                        }
                    }
                }
            }
    ) {
        Scaffold(
            topBar = {
                // 只在对话页面显示TopBar
                if (currentRoute == "chat") {
                    TopBar(isServiceConnected, 
                        onToggleService = {
                            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                            context.startActivity(intent)
                        },
                        onOpenDrawer = {
                            scope.launch { drawerState.open() }
                        },
                        onShowVision = {
                             // 现在由 AppNavigation 处理，这里暂时保留或移除
                        },
                        onStartRealTimeChat = {
                            LogManager.d("MainScreen", "点击了实时对话按钮")
                            haptic.lightTap()
                            showRealTimeChat = true
                            LogManager.d("MainScreen", "进入主界面实时对话模式")
                        }
                    )
                }
            },
            bottomBar = {
                // 在主要页面显示底部导航，深层页面（如二级设置）隐藏，以提供沉浸感
                val mainRoutes = listOf("chat", "training_hub", "settings")
                if (currentRoute in mainRoutes) {
                    NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 8.dp
                        ) {
                            NavigationBarItem(
                                icon = { Icon(Icons.Default.Chat, "对话") },
                                label = { Text("对话") },
                                selected = currentRoute == "chat",
                                onClick = { 
                                    haptic.lightTap()
                                    if (currentRoute != "chat") {
                                        navController.navigate("chat") {
                                            popUpTo("chat") { inclusive = true }
                                            launchSingleTop = true
                                        }
                                    }
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MaterialTheme.colorScheme.primary,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                            
                            NavigationBarItem(
                                icon = { Icon(Icons.Default.School, "训练") },
                                label = { Text("训练") },
                                selected = currentRoute == "training_hub",
                                onClick = { 
                                    haptic.lightTap()
                                    if (currentRoute != "training_hub") {
                                        navController.navigate("training_hub") {
                                            popUpTo("chat") { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    }
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MaterialTheme.colorScheme.primary,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                            
                            NavigationBarItem(
                                icon = { Icon(Icons.Default.Settings, "设置") },
                                label = { Text("设置") },
                                selected = currentRoute == "settings",
                                onClick = { 
                                    haptic.lightTap()
                                    if (currentRoute != "settings") {
                                        navController.navigate("settings") {
                                            popUpTo("chat") { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    }
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MaterialTheme.colorScheme.primary,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                }
            }
        ) { padding ->
            // 🧭 导航主机 - 使用 AppNavigation
            AppNavigation(
                navController = navController,
                paddingValues = padding
            )
        }
        
        showEditDialog?.let { conversation ->
            com.example.xihe.ui.components.EditConversationTitleDialog(
                conversation = conversation,
                onDismiss = { showEditDialog = null },
                onSave = { newTitle ->
                    scope.launch {
                        ConversationManager.updateConversationTitle(context, conversation.id, newTitle)
                        showEditDialog = null
                    }
                }
            )
        }
        
        // 📞 实时对话界面（全屏）
        if (showRealTimeChat) {
            RealTimeChatScreen(
                onDismiss = {
                    showRealTimeChat = false
                    // 停止持续监听
                    com.example.xihe.core.ModuleCoordinator.stopContinuousVoiceRecognition()
                }
            )
        }
        
        // 🔐 隐私权限弹窗（全局监听）
        PrivacyPermissionDialogHost()
        
        // 🎯 意图理解打分弹窗（任务/对话结束后显示）
        com.example.xihe.ui.components.IntentFeedbackDialog(onDismiss = {})
    }
    }
}
