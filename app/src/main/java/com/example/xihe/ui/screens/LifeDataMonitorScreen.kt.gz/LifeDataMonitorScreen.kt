package com.example.xihe.ui.screens

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.xihe.collector.LifeDataCollector
import com.example.xihe.service.XiheBackgroundService
import com.example.xihe.training.AutoTrainingScheduler
import com.example.xihe.ui.components.PermissionPromptDialog
import com.example.xihe.ui.utils.PermissionHelper
import kotlinx.coroutines.launch

/**
 * 📊 生活数据监控界面
 * 
 * 功能：
 * 1. 显示后台服务状态
 * 2. 显示数据收集统计
 * 3. 显示训练状态
 * 4. 控制开关
 * 5. 数据管理
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LifeDataMonitorScreen(
    onBack: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    val collector = remember { LifeDataCollector.getInstance(context) }
    val scheduler = remember { AutoTrainingScheduler.getInstance(context) }
    
    val isServiceRunning by XiheBackgroundService.isRunningFlow.collectAsStateWithLifecycle()
    val stats by collector.collectionStatsFlow.collectAsStateWithLifecycle()
    val colorScheme = MaterialTheme.colorScheme
    val collectionItems = remember(colorScheme) {
        getCollectionItems(colorScheme)
    }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var pendingPermission by remember { mutableStateOf<PermissionHelper.PermissionType?>(null) }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("生活数据监控") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "返回")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 服务状态卡片
            item {
                ServiceStatusCard(
                    isRunning = isServiceRunning,
                    onToggle = {
                        // 启动/停止后台服务前，确保必要权限
                        if (!PermissionHelper.isGranted(context, PermissionHelper.PermissionType.USAGE_STATS)) {
                            pendingPermission = PermissionHelper.PermissionType.USAGE_STATS
                            return@ServiceStatusCard
                        }
                        if (!PermissionHelper.isGranted(context, PermissionHelper.PermissionType.ACCESSIBILITY)) {
                            pendingPermission = PermissionHelper.PermissionType.ACCESSIBILITY
                            return@ServiceStatusCard
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                            !PermissionHelper.isGranted(context, PermissionHelper.PermissionType.OVERLAY)) {
                            pendingPermission = PermissionHelper.PermissionType.OVERLAY
                            return@ServiceStatusCard
                        }
                        // 定位可选，如需天气/位置收集时提示
                        if (!PermissionHelper.isGranted(context, PermissionHelper.PermissionType.LOCATION_COARSE)) {
                            pendingPermission = PermissionHelper.PermissionType.LOCATION_COARSE
                            return@ServiceStatusCard
                        }
                        if (!PermissionHelper.isGranted(context, PermissionHelper.PermissionType.LOCATION_FINE)) {
                            pendingPermission = PermissionHelper.PermissionType.LOCATION_FINE
                            return@ServiceStatusCard
                        }

                        if (isServiceRunning) {
                            XiheBackgroundService.stop(context)
                        } else {
                            XiheBackgroundService.start(context)
                        }
                    }
                )
            }
            
            // 数据统计卡片
            item {
                DataStatsCard(stats)
            }
            
            // 收集项目列表
            item {
                Text(
                    text = "收集项目",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            
            items(collectionItems) { item ->
                CollectionItemCard(item)
            }
            
            // 数据管理
            item {
                DataManagementCard(
                    onExport = {
                        scope.launch {
                            // 导出数据到文件
                            try {
                                val exportData = collector.exportData()
                                val fileName = "xihe_life_data_${System.currentTimeMillis()}.json"
                                val file = java.io.File(context.getExternalFilesDir(null), fileName)
                                file.writeText(exportData)
                                android.widget.Toast.makeText(
                                    context, 
                                    "数据已导出到: ${file.absolutePath}", 
                                    android.widget.Toast.LENGTH_LONG
                                ).show()
                            } catch (e: Exception) {
                                com.example.xihe.utils.LogManager.e("LifeDataMonitor", "导出失败: ${e.message}")
                                android.widget.Toast.makeText(
                                    context, 
                                    "导出失败: ${e.message}", 
                                    android.widget.Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    },
                    onDelete = {
                        showDeleteDialog = true
                    }
                )
            }
            
            // 提示信息
            item {
                InfoCard()
            }
        }
    }
    
    // 删除确认对话框
    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("确认删除") },
            text = { Text("确定要删除所有收集的数据吗？此操作不可恢复！") },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            collector.clearAllData()
                            showDeleteDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Text("删除", color = MaterialTheme.colorScheme.onError)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text("取消")
                }
            }
        )
    }

    // 权限提示（服务启动前）
    pendingPermission?.let { perm ->
        PermissionPromptDialog(
            permissionType = perm,
            onOpenSettings = {
                PermissionHelper.openSettings(context, perm)
                pendingPermission = null
            },
            onDismiss = { pendingPermission = null }
        )
    }
}

/**
 * 🔧 服务状态卡片
 */
@Composable
fun ServiceStatusCard(
    isRunning: Boolean,
    onToggle: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (isRunning) {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
            } else {
                MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f)
            }
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = if (isRunning) "后台服务运行中" else "后台服务已停止",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = if (isRunning) 
                        "正在持续收集您的生活数据..." 
                    else 
                        "点击开关启动后台服务",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            
            Switch(
                checked = isRunning,
                onCheckedChange = { onToggle() },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = MaterialTheme.colorScheme.primary,
                    checkedTrackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                )
            )
        }
    }
}

/**
 * 📊 数据统计卡片
 */
@Composable
fun DataStatsCard(stats: com.example.xihe.collector.CollectionStats) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.Assessment,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    text = "数据统计",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            
            Spacer(Modifier.height(16.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                LifeDataStatItem("总记录", "${stats.totalRecords}", Icons.Default.Storage)
                LifeDataStatItem("今日记录", "${stats.todayRecords}", Icons.Default.Today)
                LifeDataStatItem("收集率", "${(stats.collectionRate * 100).toInt()}%", Icons.Default.TrendingUp)
            }
        }
    }
}

/**
 * 📋 收集项目卡片
 */
@Composable
fun CollectionItemCard(item: CollectionItem) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                item.icon,
                contentDescription = null,
                tint = item.color,
                modifier = Modifier.size(24.dp)
            )
            Spacer(Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.title,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Medium
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = item.description,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Icon(
                Icons.Default.CheckCircle,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

/**
 * 🛠️ 数据管理卡片
 */
@Composable
fun DataManagementCard(
    onExport: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            Text(
                text = "数据管理",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            
            Spacer(Modifier.height(16.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onExport,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Icon(Icons.Default.FileDownload, "导出", Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("导出数据")
                }
                
                OutlinedButton(
                    onClick = onDelete,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Icon(Icons.Default.Delete, "删除", Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("删除数据")
                }
            }
        }
    }
}

/**
 * ℹ️ 提示信息卡片
 */
@Composable
fun InfoCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                Icons.Default.Info,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
            Spacer(Modifier.width(12.dp))
            Column {
                Text(
                    text = "隐私保护说明",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "• 所有数据仅保存在您的手机本地\n" +
                           "• 不会上传到任何服务器\n" +
                           "• 您可以随时删除所有数据\n" +
                           "• 数据仅用于训练个性化AI",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 20.sp
                )
            }
        }
    }
}

// ==================== 辅助函数 ====================

@Composable
private fun LifeDataStatItem(label: String, value: String, icon: ImageVector) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(24.dp)
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = value,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = label,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

fun getCollectionItems(colorScheme: ColorScheme): List<CollectionItem> {
    return listOf(
        CollectionItem("应用使用", "记录应用使用时长和操作", Icons.Default.Apps, colorScheme.primary),
        CollectionItem("消息记录", "记录发送的消息内容", Icons.Default.Message, colorScheme.secondary),
        CollectionItem("位置轨迹", "记录常去的地点", Icons.Default.LocationOn, colorScheme.error),
        CollectionItem("购物记录", "记录购买的商品", Icons.Default.ShoppingCart, colorScheme.tertiary),
        CollectionItem("饮食记录", "记录喜欢的食物", Icons.Default.Restaurant, colorScheme.secondary),
        CollectionItem("娱乐偏好", "记录看的视频、听的音乐", Icons.Default.Videocam, colorScheme.tertiary),
        CollectionItem("作息规律", "记录睡眠和活动时间", Icons.Default.Schedule, colorScheme.primary),
        CollectionItem("行为习惯", "记录日常操作习惯", Icons.Default.TouchApp, colorScheme.secondary),
        CollectionItem("社交关系", "记录联系人和社交圈", Icons.Default.People, colorScheme.tertiary),
        CollectionItem("兴趣爱好", "记录浏览和搜索内容", Icons.Default.Explore, colorScheme.primary)
    )
}

data class CollectionItem(
    val title: String,
    val description: String,
    val icon: ImageVector,
    val color: Color
)

