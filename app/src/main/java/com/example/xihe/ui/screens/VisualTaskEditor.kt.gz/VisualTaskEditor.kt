package com.example.xihe.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.xihe.ui.theme.DeepSpaceBlue
import kotlinx.coroutines.launch
import com.example.xihe.utils.LogManager

/**
 * 📝 可视化任务编辑器
 * 
 * 功能:
 * 1. 拖拽式步骤编辑
 * 2. 流程图展示
 * 3. 步骤参数配置
 * 4. 保存为模板
 * 5. 测试执行
 * 
 * 优化点:
 * - 从纯文本 -> 可视化编辑
 * - 直观的流程展示
 * - 易于修改和调试
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VisualTaskEditor(
    taskTemplate: TaskTemplate? = null,
    onSave: (TaskTemplate) -> Unit = {},
    onBack: () -> Unit = {}
) {
    var taskName by remember { mutableStateOf(taskTemplate?.name ?: "") }
    var taskDescription by remember { mutableStateOf(taskTemplate?.description ?: "") }
    var steps by remember { mutableStateOf(taskTemplate?.steps ?: listOf(createStartStep())) }
    var showAddStepDialog by remember { mutableStateOf(false) }
    var editingStep by remember { mutableStateOf<TaskStep?>(null) }
    
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(if (taskTemplate == null) "新建任务" else "编辑任务") 
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "返回")
                    }
                },
                actions = {
                    // 保存按钮
                    IconButton(
                        onClick = {
                            if (taskName.isNotBlank() && steps.size > 1) {
                                val template = TaskTemplate(
                                    id = taskTemplate?.id ?: java.util.UUID.randomUUID().toString(),
                                    name = taskName,
                                    description = taskDescription,
                                    steps = steps,
                                    createdTime = taskTemplate?.createdTime ?: System.currentTimeMillis(),
                                    modifiedTime = System.currentTimeMillis()
                                )
                                onSave(template)
                                onBack()
                            }
                        },
                        enabled = taskName.isNotBlank() && steps.size > 1
                    ) {
                        Icon(Icons.Default.Save, "保存")
                    }
                    
                    // 测试按钮
                    IconButton(
                        onClick = {
                            if (steps.size > 1) {
                                scope.launch {
                                    // 执行测试任务
                                    testExecuteTask(context, steps)
                                }
                            }
                        }
                    ) {
                        Icon(Icons.Default.PlayArrow, "测试")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DeepSpaceBlue.Primary
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddStepDialog = true },
                containerColor = DeepSpaceBlue.Accent
            ) {
                Icon(Icons.Default.Add, "添加步骤")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(DeepSpaceBlue.Secondary)
        ) {
            // 任务基本信息
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DeepSpaceBlue.Primary)
                    .padding(16.dp)
            ) {
                OutlinedTextField(
                    value = taskName,
                    onValueChange = { taskName = it },
                    label = { Text("任务名称") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = DeepSpaceBlue.Accent,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.3f),
                        focusedLabelColor = DeepSpaceBlue.Accent,
                        unfocusedLabelColor = Color.White.copy(alpha = 0.6f)
                    )
                )
                
                Spacer(Modifier.height(12.dp))
                
                OutlinedTextField(
                    value = taskDescription,
                    onValueChange = { taskDescription = it },
                    label = { Text("任务描述 (可选)") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = DeepSpaceBlue.Accent,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.3f),
                        focusedLabelColor = DeepSpaceBlue.Accent,
                        unfocusedLabelColor = Color.White.copy(alpha = 0.6f)
                    )
                )
            }
            
            HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
            
            // 步骤流程图
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(steps) { index, step ->
                    TaskStepCard(
                        step = step,
                        index = index,
                        totalSteps = steps.size,
                        onEdit = { editingStep = step },
                        onDelete = {
                            steps = steps.filter { it.id != step.id }
                        },
                        onMoveUp = {
                            if (index > 0) {
                                steps = steps.toMutableList().apply {
                                    val temp = this[index]
                                    this[index] = this[index - 1]
                                    this[index - 1] = temp
                                }
                            }
                        },
                        onMoveDown = {
                            if (index < steps.size - 1) {
                                steps = steps.toMutableList().apply {
                                    val temp = this[index]
                                    this[index] = this[index + 1]
                                    this[index + 1] = temp
                                }
                            }
                        }
                    )
                    
                    // 连接线
                    if (index < steps.size - 1) {
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .height(20.dp)
                                .background(DeepSpaceBlue.Accent.copy(alpha = 0.3f))
                                .padding(start = 40.dp)
                        )
                    }
                }
            }
        }
    }
    
    // 添加步骤对话框
    if (showAddStepDialog) {
        AddStepDialog(
            onDismiss = { showAddStepDialog = false },
            onConfirm = { newStep ->
                steps = steps + newStep
                showAddStepDialog = false
            }
        )
    }
    
    // 编辑步骤对话框
    editingStep?.let { step ->
        EditStepDialog(
            step = step,
            onDismiss = { editingStep = null },
            onConfirm = { updatedStep ->
                steps = steps.map { if (it.id == updatedStep.id) updatedStep else it }
                editingStep = null
            }
        )
    }
}

/**
 * 📋 任务步骤卡片
 */
@Composable
fun TaskStepCard(
    step: TaskStep,
    index: Int,
    totalSteps: Int,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }
    
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color.White.copy(alpha = 0.08f)
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onEdit)
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 步骤图标
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(getStepColor(step.actionType).copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    getStepIcon(step.actionType),
                    contentDescription = null,
                    tint = getStepColor(step.actionType),
                    modifier = Modifier.size(20.dp)
                )
            }
            
            Spacer(Modifier.width(12.dp))
            
            // 步骤内容
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = step.description,
                    fontSize = 15.sp,
                    color = Color.White,
                    fontWeight = FontWeight.Medium
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = getActionTypeText(step.actionType),
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.5f)
                )
            }
            
            // 更多菜单
            Box {
                IconButton(onClick = { showMenu = true }) {
                    Icon(
                        Icons.Default.MoreVert,
                        contentDescription = "更多",
                        tint = Color.White.copy(alpha = 0.6f)
                    )
                }
                
                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false }
                ) {
                    if (index > 0) {
                        DropdownMenuItem(
                            text = { Text("上移") },
                            leadingIcon = { Icon(Icons.Default.ArrowUpward, null) },
                            onClick = {
                                onMoveUp()
                                showMenu = false
                            }
                        )
                    }
                    
                    if (index < totalSteps - 1) {
                        DropdownMenuItem(
                            text = { Text("下移") },
                            leadingIcon = { Icon(Icons.Default.ArrowDownward, null) },
                            onClick = {
                                onMoveDown()
                                showMenu = false
                            }
                        )
                    }
                    
                    DropdownMenuItem(
                        text = { Text("编辑") },
                        leadingIcon = { Icon(Icons.Default.Edit, null) },
                        onClick = {
                            onEdit()
                            showMenu = false
                        }
                    )
                    
                    DropdownMenuItem(
                        text = { Text("删除") },
                        leadingIcon = { Icon(Icons.Default.Delete, null) },
                        onClick = {
                            onDelete()
                            showMenu = false
                        }
                    )
                }
            }
        }
    }
}

/**
 * ➕ 添加步骤对话框
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddStepDialog(
    onDismiss: () -> Unit,
    onConfirm: (TaskStep) -> Unit
) {
    var selectedAction by remember { mutableStateOf(StepActionType.CLICK) }
    var description by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("") }
    var value by remember { mutableStateOf("") }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("添加步骤") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // 动作类型选择
                Text("动作类型", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StepActionType.values().forEach { actionType ->
                        FilterChip(
                            selected = selectedAction == actionType,
                            onClick = { selectedAction = actionType },
                            label = { Text(getActionTypeText(actionType), fontSize = 12.sp) },
                            leadingIcon = {
                                Icon(
                                    getStepIcon(actionType),
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        )
                    }
                }
                
                // 描述
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("步骤描述") },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("例如: 点击发送按钮") }
                )
                
                // 目标（根据动作类型显示）
                if (selectedAction in listOf(
                        StepActionType.CLICK,
                        StepActionType.LONG_CLICK,
                        StepActionType.INPUT
                    )) {
                    OutlinedTextField(
                        value = target,
                        onValueChange = { target = it },
                        label = { Text("目标元素") },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("例如: 发送按钮") }
                    )
                }
                
                // 值（输入、滚动等需要）
                if (selectedAction in listOf(
                        StepActionType.INPUT,
                        StepActionType.WAIT
                    )) {
                    OutlinedTextField(
                        value = value,
                        onValueChange = { value = it },
                        label = { Text(if (selectedAction == StepActionType.WAIT) "等待时间(秒)" else "输入内容") },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text(if (selectedAction == StepActionType.WAIT) "1" else "要输入的文字") }
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val newStep = TaskStep(
                        id = java.util.UUID.randomUUID().toString(),
                        actionType = selectedAction,
                        description = description.ifBlank { getActionTypeText(selectedAction) },
                        target = target.ifBlank { null },
                        value = value.ifBlank { null },
                        waitAfter = 500
                    )
                    onConfirm(newStep)
                },
                enabled = description.isNotBlank()
            ) {
                Text("添加")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("取消")
            }
        }
    )
}

/**
 * ✏️ 编辑步骤对话框
 */
@Composable
fun EditStepDialog(
    step: TaskStep,
    onDismiss: () -> Unit,
    onConfirm: (TaskStep) -> Unit
) {
    var description by remember { mutableStateOf(step.description) }
    var target by remember { mutableStateOf(step.target ?: "") }
    var value by remember { mutableStateOf(step.value ?: "") }
    var waitAfter by remember { mutableStateOf(step.waitAfter.toString()) }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("编辑步骤") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("步骤描述") },
                    modifier = Modifier.fillMaxWidth()
                )
                
                OutlinedTextField(
                    value = target,
                    onValueChange = { target = it },
                    label = { Text("目标元素 (可选)") },
                    modifier = Modifier.fillMaxWidth()
                )
                
                OutlinedTextField(
                    value = value,
                    onValueChange = { value = it },
                    label = { Text("值 (可选)") },
                    modifier = Modifier.fillMaxWidth()
                )
                
                OutlinedTextField(
                    value = waitAfter,
                    onValueChange = { waitAfter = it },
                    label = { Text("等待时间(ms)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val updated = step.copy(
                        description = description,
                        target = target.ifBlank { null },
                        value = value.ifBlank { null },
                        waitAfter = waitAfter.toLongOrNull() ?: 500
                    )
                    onConfirm(updated)
                }
            ) {
                Text("保存")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("取消")
            }
        }
    )
}

// ==================== 辅助函数 ====================

fun getStepIcon(actionType: StepActionType): ImageVector {
    return when (actionType) {
        StepActionType.CLICK -> Icons.Default.TouchApp
        StepActionType.LONG_CLICK -> Icons.Default.TouchApp
        StepActionType.INPUT -> Icons.Default.Keyboard
        StepActionType.SCROLL -> Icons.Default.SwipeVertical
        StepActionType.SWIPE -> Icons.Default.Swipe
        StepActionType.LAUNCH_APP -> Icons.Default.Apps
        StepActionType.BACK -> Icons.Default.ArrowBack
        StepActionType.HOME -> Icons.Default.Home
        StepActionType.WAIT -> Icons.Default.Timer
        StepActionType.SCREENSHOT -> Icons.Default.Screenshot
        StepActionType.CHECK -> Icons.Default.CheckCircle
    }
}

fun getStepColor(actionType: StepActionType): Color {
    return when (actionType) {
        StepActionType.CLICK, StepActionType.LONG_CLICK -> Color(0xFF2196F3)
        StepActionType.INPUT -> Color(0xFF4CAF50)
        StepActionType.SCROLL, StepActionType.SWIPE -> Color(0xFFFF9800)
        StepActionType.LAUNCH_APP -> Color(0xFF9C27B0)
        StepActionType.BACK, StepActionType.HOME -> Color(0xFF607D8B)
        StepActionType.WAIT -> Color(0xFF795548)
        StepActionType.SCREENSHOT, StepActionType.CHECK -> Color(0xFF00BCD4)
    }
}

fun getActionTypeText(actionType: StepActionType): String {
    return when (actionType) {
        StepActionType.CLICK -> "点击"
        StepActionType.LONG_CLICK -> "长按"
        StepActionType.INPUT -> "输入"
        StepActionType.SCROLL -> "滚动"
        StepActionType.SWIPE -> "滑动"
        StepActionType.LAUNCH_APP -> "启动应用"
        StepActionType.BACK -> "返回"
        StepActionType.HOME -> "回主页"
        StepActionType.WAIT -> "等待"
        StepActionType.SCREENSHOT -> "截图"
        StepActionType.CHECK -> "检查"
    }
}

fun createStartStep(): TaskStep {
    return TaskStep(
        id = "start",
        actionType = StepActionType.LAUNCH_APP,
        description = "开始任务",
        target = null,
        value = null,
        waitAfter = 0
    )
}

// ==================== 数据类 ====================

/**
 * 📝 任务模板
 */
data class TaskTemplate(
    val id: String,
    val name: String,
    val description: String,
    val steps: List<TaskStep>,
    val createdTime: Long,
    val modifiedTime: Long,
    val category: String = "自定义",
    val tags: List<String> = emptyList(),
    val isPublic: Boolean = false
)

/**
 * 🎯 任务步骤
 */
data class TaskStep(
    val id: String,
    val actionType: StepActionType,
    val description: String,
    val target: String?,
    val value: String?,
    val waitAfter: Long = 500,
    val retryCount: Int = 3,
    val skipOnError: Boolean = false
)

/**
 * 🎬 步骤动作类型
 */
enum class StepActionType {
    CLICK,          // 点击
    LONG_CLICK,     // 长按
    INPUT,          // 输入
    SCROLL,         // 滚动
    SWIPE,          // 滑动
    LAUNCH_APP,     // 启动应用
    BACK,           // 返回
    HOME,           // 主页
    WAIT,           // 等待
    SCREENSHOT,     // 截图
    CHECK           // 检查
}

/**
 * 🧪 测试执行任务
 */
suspend fun testExecuteTask(context: android.content.Context, steps: List<TaskStep>) {
    val service = com.example.xihe.CoreAccessibilityService.instance
    if (service == null) {
        android.widget.Toast.makeText(context, "请先开启无障碍服务", android.widget.Toast.LENGTH_SHORT).show()
        return
    }
    
    android.widget.Toast.makeText(context, "开始测试执行 ${steps.size} 个步骤", android.widget.Toast.LENGTH_SHORT).show()
    
    for ((index, step) in steps.withIndex()) {
        if (step.actionType == StepActionType.LAUNCH_APP && step.description == "开始任务") {
            continue  // 跳过起始步骤
        }
        
        LogManager.d("VisualTaskEditor", "执行步骤 ${index + 1}: ${step.description}")
        
        try {
            when (step.actionType) {
                StepActionType.CLICK -> {
                    // 通过文本查找并点击
                    step.target?.let { target ->
                        val rootNode = service.rootInActiveWindow
                        val nodes = rootNode?.findAccessibilityNodeInfosByText(target)
                        if (!nodes.isNullOrEmpty()) {
                            nodes.first().performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK)
                        }
                        rootNode?.recycle()
                    }
                }
                StepActionType.LONG_CLICK -> {
                    step.target?.let { target ->
                        val rootNode = service.rootInActiveWindow
                        val nodes = rootNode?.findAccessibilityNodeInfosByText(target)
                        if (!nodes.isNullOrEmpty()) {
                            nodes.first().performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_LONG_CLICK)
                        }
                        rootNode?.recycle()
                    }
                }
                StepActionType.INPUT -> {
                    step.value?.let { text ->
                        val rootNode = service.rootInActiveWindow
                        // 查找可编辑的输入框
                        val editableNode = findEditableNode(rootNode)
                        editableNode?.let {
                            val bundle = android.os.Bundle()
                            bundle.putCharSequence(android.view.accessibility.AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
                            it.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_SET_TEXT, bundle)
                        }
                        rootNode?.recycle()
                    }
                }
                StepActionType.SCROLL -> {
                    val direction = step.value ?: "DOWN"
                    val displayMetrics = service.resources.displayMetrics
                    val width = displayMetrics.widthPixels.toFloat()
                    val height = displayMetrics.heightPixels.toFloat()
                    
                    val (startX, startY, endX, endY) = when (direction.uppercase()) {
                        "UP" -> listOf(width / 2, height * 0.7f, width / 2, height * 0.3f)
                        "DOWN" -> listOf(width / 2, height * 0.3f, width / 2, height * 0.7f)
                        "LEFT" -> listOf(width * 0.7f, height / 2, width * 0.3f, height / 2)
                        "RIGHT" -> listOf(width * 0.3f, height / 2, width * 0.7f, height / 2)
                        else -> listOf(width / 2, height * 0.7f, width / 2, height * 0.3f)
                    }
                    service.performScroll(startX, startY, endX, endY)
                }
                StepActionType.BACK -> {
                    service.performGlobalBack()
                }
                StepActionType.HOME -> {
                    service.performGlobalHome()
                }
                StepActionType.WAIT -> {
                    val waitTime = step.value?.toLongOrNull() ?: 1000L
                    kotlinx.coroutines.delay(waitTime)
                }
                StepActionType.LAUNCH_APP -> {
                    step.target?.let { packageName ->
                        val intent = context.packageManager.getLaunchIntentForPackage(packageName)
                        intent?.let { context.startActivity(it) }
                    }
                }
                else -> {}
            }
            
            // 步骤间等待
            kotlinx.coroutines.delay(step.waitAfter)
            
        } catch (e: Exception) {
            LogManager.e("VisualTaskEditor", "步骤 ${index + 1} 执行失败: ${e.message}")
            if (!step.skipOnError) {
                android.widget.Toast.makeText(context, "步骤 ${index + 1} 失败: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
                break
            }
        }
    }
    
    android.widget.Toast.makeText(context, "测试执行完成", android.widget.Toast.LENGTH_SHORT).show()
}

/**
 * 🔍 查找可编辑节点
 */
private fun findEditableNode(node: android.view.accessibility.AccessibilityNodeInfo?): android.view.accessibility.AccessibilityNodeInfo? {
    if (node == null) return null
    
    if (node.isEditable) return node
    
    for (i in 0 until node.childCount) {
        val child = node.getChild(i)
        val result = findEditableNode(child)
        if (result != null) return result
    }
    
    return null
}

