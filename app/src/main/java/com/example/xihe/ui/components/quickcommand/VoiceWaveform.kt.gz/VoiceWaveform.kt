package com.example.xihe.ui.components.quickcommand

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.sin
import kotlin.random.Random

/**
 * 🎤 语音波形可视化组件
 *
 * 功能：
 * 1. 实时波形显示 - 展示语音输入的动态效果
 * 2. 多种波形样式 - 条形、波浪、圆形等
 * 3. 状态指示 - 监听中、处理中、静默
 * 4. 流畅动画 - 平滑的动画过渡
 */

// ==================== 波形状态 ====================

enum class VoiceWaveformState {
    IDLE,           // 空闲
    LISTENING,      // 正在监听
    PROCESSING,     // 处理中
    SPEAKING        // AI正在说话
}

// ==================== 波形样式 ====================

enum class WaveformStyle {
    BARS,           // 条形波形
    WAVE,           // 波浪线
    CIRCLE,         // 圆形脉动
    DOTS            // 点阵波形
}

// ==================== 主组件 ====================

/**
 * 🎤 语音波形可视化
 *
 * @param state 当前状态
 * @param style 波形样式
 * @param amplitudes 振幅数据（0-1之间）
 * @param modifier Modifier
 * @param primaryColor 主颜色
 * @param secondaryColor 次要颜色
 */
@Composable
fun VoiceWaveform(
    state: VoiceWaveformState,
    modifier: Modifier = Modifier,
    style: WaveformStyle = WaveformStyle.BARS,
    amplitudes: List<Float> = emptyList(),
    primaryColor: Color = Color.Unspecified,
    secondaryColor: Color = Color.Unspecified,
    barCount: Int = 5
) {
    val resolvedPrimaryColor = if (primaryColor != Color.Unspecified) primaryColor else MaterialTheme.colorScheme.primary
    val resolvedSecondaryColor = if (secondaryColor != Color.Unspecified) secondaryColor else MaterialTheme.colorScheme.primaryContainer

    when (style) {
        WaveformStyle.BARS -> BarsWaveform(
            state = state,
            amplitudes = amplitudes,
            primaryColor = resolvedPrimaryColor,
            secondaryColor = resolvedSecondaryColor,
            barCount = barCount,
            modifier = modifier
        )
        WaveformStyle.WAVE -> WaveLineWaveform(
            state = state,
            primaryColor = resolvedPrimaryColor,
            secondaryColor = resolvedSecondaryColor,
            modifier = modifier
        )
        WaveformStyle.CIRCLE -> CirclePulseWaveform(
            state = state,
            primaryColor = resolvedPrimaryColor,
            secondaryColor = resolvedSecondaryColor,
            modifier = modifier
        )
        WaveformStyle.DOTS -> DotsWaveform(
            state = state,
            primaryColor = resolvedPrimaryColor,
            barCount = barCount,
            modifier = modifier
        )
    }
}

// ==================== 条形波形 ====================

/**
 * 📊 条形波形
 */
@Composable
private fun BarsWaveform(
    state: VoiceWaveformState,
    amplitudes: List<Float>,
    primaryColor: Color,
    secondaryColor: Color,
    barCount: Int,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "barsWaveform")

    // 为每个条形创建独立的动画
    val animatedAmplitudes = (0 until barCount).map { index ->
        infiniteTransition.animateFloat(
            initialValue = 0.3f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(
                    durationMillis = 300 + (index * 100),
                    easing = FastOutSlowInEasing
                ),
                repeatMode = RepeatMode.Reverse
            ),
            label = "bar_$index"
        )
    }

    Row(
        modifier = modifier
            .height(40.dp)
            .padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        animatedAmplitudes.forEachIndexed { index, animatedValue ->
            val amplitude = when (state) {
                VoiceWaveformState.IDLE -> 0.2f
                VoiceWaveformState.LISTENING -> {
                    if (amplitudes.isNotEmpty() && index < amplitudes.size) {
                        amplitudes[index]
                    } else {
                        animatedValue.value
                    }
                }
                VoiceWaveformState.PROCESSING -> animatedValue.value * 0.6f
                VoiceWaveformState.SPEAKING -> animatedValue.value * 0.8f
            }

            Box(
                modifier = Modifier
                    .width(6.dp)
                    .fillMaxHeight(amplitude.coerceIn(0.1f, 1f))
                    .background(
                        brush = Brush.verticalGradient(
                            colors = listOf(primaryColor, secondaryColor)
                        ),
                        shape = RoundedCornerShape(3.dp)
                    )
            )
        }
    }
}

// ==================== 波浪线波形 ====================

/**
 * 🌊 波浪线波形
 */
@Composable
private fun WaveLineWaveform(
    state: VoiceWaveformState,
    primaryColor: Color,
    secondaryColor: Color,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "waveTransition")

    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wavePhase"
    )

    val amplitude by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "waveAmplitude"
    )

    val actualAmplitude = when (state) {
        VoiceWaveformState.IDLE -> 0.1f
        VoiceWaveformState.LISTENING -> amplitude
        VoiceWaveformState.PROCESSING -> amplitude * 0.5f
        VoiceWaveformState.SPEAKING -> amplitude * 0.7f
    }

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(40.dp)
    ) {
        val width = size.width
        val height = size.height
        val centerY = height / 2

        val path = Path()
        val points = 100
        val frequency = 3f

        for (i in 0..points) {
            val x = (i.toFloat() / points) * width
            val y = centerY + sin((i.toFloat() / points) * frequency * Math.PI.toFloat() * 2 + phase) * (height / 2 - 4) * actualAmplitude

            if (i == 0) {
                path.moveTo(x, y)
            } else {
                path.lineTo(x, y)
            }
        }

        drawPath(
            path = path,
            brush = Brush.horizontalGradient(
                colors = listOf(primaryColor, secondaryColor, primaryColor)
            ),
            style = Stroke(width = 3.dp.toPx())
        )
    }
}

// ==================== 圆形脉动波形 ====================

/**
 * ⭕ 圆形脉动波形
 */
@Composable
private fun CirclePulseWaveform(
    state: VoiceWaveformState,
    primaryColor: Color,
    secondaryColor: Color,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "circleTransition")

    val scale1 by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale1"
    )

    val scale2 by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale2"
    )

    val scale3 by infiniteTransition.animateFloat(
        initialValue = 0.7f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale3"
    )

    val baseScale = when (state) {
        VoiceWaveformState.IDLE -> 0.3f
        VoiceWaveformState.LISTENING -> 1f
        VoiceWaveformState.PROCESSING -> 0.6f
        VoiceWaveformState.SPEAKING -> 0.8f
    }

    Canvas(
        modifier = modifier
            .size(60.dp)
    ) {
        val center = Offset(size.width / 2, size.height / 2)
        val maxRadius = size.minDimension / 2

        // 外圈
        drawCircle(
            color = primaryColor.copy(alpha = 0.2f),
            radius = maxRadius * scale3 * baseScale,
            center = center
        )

        // 中圈
        drawCircle(
            color = primaryColor.copy(alpha = 0.4f),
            radius = maxRadius * scale2 * baseScale,
            center = center
        )

        // 内圈
        drawCircle(
            color = primaryColor,
            radius = maxRadius * scale1 * baseScale * 0.5f,
            center = center
        )
    }
}

// ==================== 点阵波形 ====================

/**
 * ⚫ 点阵波形
 */
@Composable
private fun DotsWaveform(
    state: VoiceWaveformState,
    primaryColor: Color,
    barCount: Int,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "dotsTransition")

    val animatedScales = (0 until barCount).map { index ->
        infiniteTransition.animateFloat(
            initialValue = 0.5f,
            targetValue = 1.5f,
            animationSpec = infiniteRepeatable(
                animation = tween(
                    durationMillis = 400,
                    delayMillis = index * 100,
                    easing = FastOutSlowInEasing
                ),
                repeatMode = RepeatMode.Reverse
            ),
            label = "dot_$index"
        )
    }

    Row(
        modifier = modifier
            .height(40.dp)
            .padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        animatedScales.forEach { animatedValue ->
            val scale = when (state) {
                VoiceWaveformState.IDLE -> 0.5f
                VoiceWaveformState.LISTENING -> animatedValue.value
                VoiceWaveformState.PROCESSING -> animatedValue.value * 0.7f
                VoiceWaveformState.SPEAKING -> animatedValue.value * 0.85f
            }

            Box(
                modifier = Modifier
                    .size((8 * scale).dp)
                    .background(
                        color = primaryColor.copy(alpha = 0.5f + scale * 0.3f),
                        shape = RoundedCornerShape(50)
                    )
            )
        }
    }
}

// ==================== 带状态文字的波形组件 ====================

/**
 * 🎤 带状态指示的语音波形
 */
@Composable
fun VoiceWaveformWithStatus(
    state: VoiceWaveformState,
    modifier: Modifier = Modifier,
    style: WaveformStyle = WaveformStyle.BARS,
    primaryColor: Color = Color.Unspecified,
    secondaryColor: Color = Color.Unspecified,
    showStatusText: Boolean = true
) {
    val resolvedPrimaryColor = if (primaryColor != Color.Unspecified) primaryColor else MaterialTheme.colorScheme.primary
    val resolvedSecondaryColor = if (secondaryColor != Color.Unspecified) secondaryColor else MaterialTheme.colorScheme.primaryContainer

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        VoiceWaveform(
            state = state,
            style = style,
            primaryColor = resolvedPrimaryColor,
            secondaryColor = resolvedSecondaryColor,
            modifier = Modifier.height(40.dp)
        )

        if (showStatusText) {
            val (statusText, statusColor) = when (state) {
                VoiceWaveformState.IDLE -> "点击开始" to Color.Gray
                VoiceWaveformState.LISTENING -> "正在聆听..." to resolvedPrimaryColor
                VoiceWaveformState.PROCESSING -> "处理中..." to Color(0xFFFFAB40)
                VoiceWaveformState.SPEAKING -> "羲和说话中..." to Color(0xFF4CAF50)
            }

            Text(
                text = statusText,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = statusColor
            )
        }
    }
}

// ==================== 紧凑型波形指示器 ====================

/**
 * 🔊 紧凑型波形指示器（适合放在输入框旁边）
 */
@Composable
fun CompactVoiceIndicator(
    isActive: Boolean,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified
) {
    val resolvedColor = if (color != Color.Unspecified) color else MaterialTheme.colorScheme.primary
    val infiniteTransition = rememberInfiniteTransition(label = "compactIndicator")

    val scale by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "indicatorScale"
    )

    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "indicatorAlpha"
    )

    Row(
        modifier = modifier.padding(horizontal = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(3) { index ->
            val barScale = if (isActive) {
                when (index) {
                    0 -> scale
                    1 -> 1.3f - scale + 0.5f
                    else -> scale * 0.8f
                }
            } else {
                0.4f
            }

            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height((16 * barScale).dp)
                    .background(
                        color = if (isActive) resolvedColor.copy(alpha = alpha) else Color.Gray,
                        shape = RoundedCornerShape(1.5.dp)
                    )
            )
        }
    }
}

// ==================== 实时振幅数据生成器 ====================

/**
 * 🎚️ 模拟振幅数据生成（实际使用时替换为真实音频数据）
 */
@Composable
fun rememberSimulatedAmplitudes(
    barCount: Int = 5,
    isActive: Boolean = false
): State<List<Float>> {
    val amplitudes = remember { mutableStateOf(List(barCount) { 0.2f }) }

    LaunchedEffect(isActive) {
        while (isActive) {
            amplitudes.value = List(barCount) {
                if (isActive) Random.nextFloat() * 0.7f + 0.3f else 0.2f
            }
            delay(100)
        }

        // 停止时重置
        if (!isActive) {
            amplitudes.value = List(barCount) { 0.2f }
        }
    }

    return amplitudes
}
