package com.example.xihe.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.xihe.security.*
import com.example.xihe.ui.theme.DeepSpaceBlue

/**
 * 🔒 安全审计界面
 * 
 * 功能:
 * 1. 显示操作历史
 * 2. 安全报告统计
 * 3. 权限管理
 * 4. 异常检测提醒
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SecurityAuditScreen(
    onBack: () -> Unit = {}
) {
    val context = LocalContext.current
    val securityManager = remember { EnhancedSecurityManager(context) }
    
    val securityReport = remember {
        securityManager.generateSecurityReport(days = 7)
    }
    
    val auditLogs = remember {
        securityManager.getAuditLogs().takeLast(50).reversed()
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("安全审计") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "返回")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DeepSpaceBlue.Primary
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(DeepSpaceBlue.Secondary)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 安全概览卡片
            item {
                SecurityOverviewCard(securityReport)
            }
            
            // 操作统计
            item {
                OperationStatsCard(securityReport)
            }
            
            // 最近操作日志
            item {
                Text(
                    text = "最近操作",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            
            items(auditLogs) { log ->
                AuditLogCard(log)
            }
        }
    }
}

/**
 * 📊 安全概览卡片
 */
@Composable
fun SecurityOverviewCard(report: SecurityReport) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color.White.copy(alpha = 0.1f)
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.Security,
                    contentDescription = null,
                    tint = DeepSpaceBlue.Accent,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    text = "最近${report.periodDays}天安全概览",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            
            Spacer(Modifier.height(20.dp))
            
            // 成功率
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "成功率",
                    color = Color.White.copy(alpha = 0.7f)
                )
                Text(
                    text = "${(report.successRate * 100).toInt()}%",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (report.successRate > 0.8f) Color(0xFF4CAF50) else Color(0xFFFF9800)
                )
            }
            
            Spacer(Modifier.height(8.dp))
            
            LinearProgressIndicator(
                progress = { report.successRate },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = if (report.successRate > 0.8f) Color(0xFF4CAF50) else Color(0xFFFF9800),
            )
            
            Spacer(Modifier.height(20.dp))
            
            // 统计数字
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                SecurityStatItem("总操作", report.totalOperations.toString(), Icons.Default.Assessment)
                SecurityStatItem("已阻止", report.blockedOperations.toString(), Icons.Default.Block)
                SecurityStatItem("高风险", report.highRiskOperations.toString(), Icons.Default.Warning)
            }
            
            // 建议
            if (report.recommendations.isNotEmpty()) {
                Spacer(Modifier.height(16.dp))
                HorizontalDivider(color = Color.White.copy(alpha = 0.2f))
                Spacer(Modifier.height(12.dp))
                
                Text(
                    text = "安全建议",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = DeepSpaceBlue.Accent
                )
                
                report.recommendations.forEach { recommendation ->
                    Spacer(Modifier.height(8.dp))
                    Row {
                        Icon(
                            Icons.Default.Lightbulb,
                            contentDescription = null,
                            tint = DeepSpaceBlue.Accent,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = recommendation,
                            fontSize = 13.sp,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                    }
                }
            }
        }
    }
}

/**
 * 📈 操作统计卡片
 */
@Composable
fun OperationStatsCard(report: SecurityReport) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color.White.copy(alpha = 0.1f)
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            Text(
                text = "操作分类统计",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            
            Spacer(Modifier.height(16.dp))
            
            StatRow(
                icon = Icons.Default.Payment,
                label = "支付操作",
                count = report.paymentOperations,
                color = Color(0xFFFF9800)
            )
            
            Spacer(Modifier.height(12.dp))
            
            StatRow(
                icon = Icons.Default.Security,
                label = "隐私操作",
                count = report.privacyOperations,
                color = Color(0xFF9C27B0)
            )
            
            Spacer(Modifier.height(12.dp))
            
            StatRow(
                icon = Icons.Default.Error,
                label = "异常检测",
                count = report.anomalyDetections,
                color = Color(0xFFF44336)
            )
        }
    }
}

/**
 * 📝 审计日志卡片
 */
@Composable
fun AuditLogCard(log: AuditLog) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color.White.copy(alpha = 0.05f)
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 状态图标
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(getStatusColor(log.result.status).copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    getStatusIcon(log.result.status),
                    contentDescription = null,
                    tint = getStatusColor(log.result.status),
                    modifier = Modifier.size(20.dp)
                )
            }
            
            Spacer(Modifier.width(12.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = log.operation.description,
                    fontSize = 15.sp,
                    color = Color.White,
                    fontWeight = FontWeight.Medium
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = log.getFormattedTime(),
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.5f)
                )
                
                // 安全级别标签
                log.securityCheck?.let { check ->
                    if (check.level != SecurityLevel.SAFE) {
                        Spacer(Modifier.height(6.dp))
                        SecurityLevelBadge(check.level)
                    }
                }
            }
        }
    }
}

// ==================== 辅助组件 ====================

@Composable
private fun SecurityStatItem(label: String, value: String, icon: ImageVector) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            icon,
            contentDescription = null,
            tint = DeepSpaceBlue.Accent,
            modifier = Modifier.size(24.dp)
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = value,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Text(
            text = label,
            fontSize = 12.sp,
            color = Color.White.copy(alpha = 0.6f)
        )
    }
}

@Composable
fun StatRow(
    icon: ImageVector,
    label: String,
    count: Int,
    color: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(20.dp)
            )
            Spacer(Modifier.width(12.dp))
            Text(
                text = label,
                color = Color.White,
                fontSize = 15.sp
            )
        }
        
        Text(
            text = count.toString(),
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}

@Composable
fun SecurityLevelBadge(level: SecurityLevel) {
    val (text, color) = when (level) {
        SecurityLevel.SAFE -> "安全" to Color(0xFF4CAF50)
        SecurityLevel.LOW_RISK -> "低风险" to Color(0xFF2196F3)
        SecurityLevel.MEDIUM_RISK -> "中风险" to Color(0xFFFF9800)
        SecurityLevel.HIGH_RISK -> "高风险" to Color(0xFFF44336)
        SecurityLevel.CRITICAL -> "危险" to Color(0xFFD32F2F)
    }
    
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = color.copy(alpha = 0.2f)
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            fontSize = 11.sp,
            color = color,
            fontWeight = FontWeight.Bold
        )
    }
}

fun getStatusIcon(status: OperationStatus): ImageVector {
    return when (status) {
        OperationStatus.SUCCESS -> Icons.Default.CheckCircle
        OperationStatus.FAILED -> Icons.Default.Error
        OperationStatus.CANCELLED -> Icons.Default.Cancel
        OperationStatus.TIMEOUT -> Icons.Default.Timer
    }
}

fun getStatusColor(status: OperationStatus): Color {
    return when (status) {
        OperationStatus.SUCCESS -> Color(0xFF4CAF50)
        OperationStatus.FAILED -> Color(0xFFF44336)
        OperationStatus.CANCELLED -> Color(0xFF9E9E9E)
        OperationStatus.TIMEOUT -> Color(0xFFFF9800)
    }
}

