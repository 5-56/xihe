package com.example.xihe.ui

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.example.xihe.ui.theme.DeepSpaceBlue
import com.example.xihe.ui.theme.NeonCyan
import com.example.xihe.ui.theme.AccentColors
import com.example.xihe.ui.theme.StatusColors
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * 🎨 增强版主题管理器
 *
 * 功能：
 * 1. 亮色/暗色/跟随系统 主题切换
 * 2. 动态颜色支持 (Android 12+)
 * 3. 自定义主题色
 * 4. 状态持久化
 * 5. 实时主题预览
 */
class ThemeManager private constructor(private val context: Context) {

    companion object {
        private const val PREFS_NAME = "xihe_theme_prefs"
        private const val KEY_THEME_MODE = "theme_mode"
        private const val KEY_ACCENT_COLOR = "accent_color"
        private const val KEY_USE_DYNAMIC_COLOR = "use_dynamic_color"
        private const val KEY_USE_PURE_BLACK = "use_pure_black"
        private const val KEY_CUSTOM_PRIMARY_COLOR = "custom_primary_color"

        @Volatile
        private var instance: ThemeManager? = null

        fun getInstance(context: Context): ThemeManager {
            return instance ?: synchronized(this) {
                instance ?: ThemeManager(context.applicationContext).also {
                    instance = it
                }
            }
        }
    }

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    // 主题模式
    private val _themeMode = MutableStateFlow(loadThemeMode())
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    // 强调色
    private val _accentColor = MutableStateFlow(loadAccentColor())
    val accentColor: StateFlow<AccentColor> = _accentColor.asStateFlow()

    // 是否使用动态颜色 (Android 12+)
    private val _useDynamicColor = MutableStateFlow(loadUseDynamicColor())
    val useDynamicColor: StateFlow<Boolean> = _useDynamicColor.asStateFlow()

    // 是否使用纯黑背景 (AMOLED)
    private val _usePureBlack = MutableStateFlow(loadUsePureBlack())
    val usePureBlack: StateFlow<Boolean> = _usePureBlack.asStateFlow()

    // 自定义主色
    private val _customPrimaryColor = MutableStateFlow(loadCustomPrimaryColor())
    val customPrimaryColor: StateFlow<Color?> = _customPrimaryColor.asStateFlow()

    // ==================== 主题模式 ====================

    /**
     * 🔄 切换主题模式
     */
    fun toggleTheme() {
        val newMode = when (_themeMode.value) {
            ThemeMode.LIGHT -> ThemeMode.DARK
            ThemeMode.DARK -> ThemeMode.SYSTEM
            ThemeMode.SYSTEM -> ThemeMode.LIGHT
        }
        setThemeMode(newMode)
    }

    /**
     * 🎯 设置主题模式
     */
    fun setThemeMode(mode: ThemeMode) {
        _themeMode.value = mode
        prefs.edit().putString(KEY_THEME_MODE, mode.name).apply()
    }

    private fun loadThemeMode(): ThemeMode {
        val modeName = prefs.getString(KEY_THEME_MODE, ThemeMode.SYSTEM.name)
        return try {
            ThemeMode.valueOf(modeName ?: ThemeMode.SYSTEM.name)
        } catch (e: Exception) {
            ThemeMode.SYSTEM
        }
    }

    // ==================== 强调色 ====================

    /**
     * 🎨 设置强调色
     */
    fun setAccentColor(color: AccentColor) {
        _accentColor.value = color
        prefs.edit().putString(KEY_ACCENT_COLOR, color.name).apply()
    }

    private fun loadAccentColor(): AccentColor {
        val colorName = prefs.getString(KEY_ACCENT_COLOR, AccentColor.CYAN.name)
        return try {
            AccentColor.valueOf(colorName ?: AccentColor.CYAN.name)
        } catch (e: Exception) {
            AccentColor.CYAN
        }
    }

    // ==================== 动态颜色 ====================

    /**
     * 🌈 设置是否使用动态颜色
     */
    fun setUseDynamicColor(use: Boolean) {
        _useDynamicColor.value = use
        prefs.edit().putBoolean(KEY_USE_DYNAMIC_COLOR, use).apply()
    }

    private fun loadUseDynamicColor(): Boolean {
        return prefs.getBoolean(KEY_USE_DYNAMIC_COLOR, false)
    }

    /**
     * 检查设备是否支持动态颜色
     */
    fun isDynamicColorAvailable(): Boolean {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    }

    // ==================== 纯黑模式 ====================

    /**
     * 🖤 设置是否使用纯黑背景
     */
    fun setUsePureBlack(use: Boolean) {
        _usePureBlack.value = use
        prefs.edit().putBoolean(KEY_USE_PURE_BLACK, use).apply()
    }

    private fun loadUsePureBlack(): Boolean {
        return prefs.getBoolean(KEY_USE_PURE_BLACK, false)
    }

    // ==================== 自定义颜色 ====================

    /**
     * 🎨 设置自定义主色
     */
    fun setCustomPrimaryColor(color: Color?) {
        _customPrimaryColor.value = color
        if (color != null) {
            prefs.edit().putLong(KEY_CUSTOM_PRIMARY_COLOR, color.value.toLong()).apply()
        } else {
            prefs.edit().remove(KEY_CUSTOM_PRIMARY_COLOR).apply()
        }
    }

    private fun loadCustomPrimaryColor(): Color? {
        return if (prefs.contains(KEY_CUSTOM_PRIMARY_COLOR)) {
            Color(prefs.getLong(KEY_CUSTOM_PRIMARY_COLOR, 0).toULong())
        } else {
            null
        }
    }

    /**
     * 🔄 重置所有主题设置
     */
    fun resetToDefault() {
        setThemeMode(ThemeMode.SYSTEM)
        setAccentColor(AccentColor.CYAN)
        setUseDynamicColor(false)
        setUsePureBlack(false)
        setCustomPrimaryColor(null)
    }
}

// ==================== 枚举定义 ====================

/**
 * 🎨 主题模式
 */
enum class ThemeMode(val displayName: String, val icon: String) {
    LIGHT("浅色模式", "☀️"),
    DARK("深色模式", "🌙"),
    SYSTEM("跟随系统", "📱")
}

/**
 * 🎨 强调色
 */
enum class AccentColor(
    val displayName: String,
    val primary: Color,
    val primaryVariant: Color,
    val secondary: Color
) {
    CYAN("霓虹青", NeonCyan.Primary, NeonCyan.Dark, NeonCyan.Light),
    PURPLE("魅力紫", AccentColors.Purple, Color(0xFF7C4DFF), Color(0xFFB388FF)),
    PINK("温柔粉", AccentColors.Pink, Color(0xFFE91E63), Color(0xFFF8BBD0)),
    ORANGE("活力橙", AccentColors.Orange, Color(0xFFFF6D00), Color(0xFFFFCC80)),
    GREEN("清新绿", AccentColors.Green, Color(0xFF388E3C), Color(0xFFA5D6A7)),
    BLUE("深邃蓝", AccentColors.Blue, Color(0xFF1976D2), Color(0xFF90CAF9)),
    RED("热情红", Color(0xFFF44336), Color(0xFFD32F2F), Color(0xFFFFCDD2)),
    TEAL("青碧色", Color(0xFF009688), Color(0xFF00796B), Color(0xFFB2DFDB)),
    AMBER("琥珀黄", Color(0xFFFFC107), Color(0xFFFFA000), Color(0xFFFFECB3)),
    INDIGO("靛蓝色", Color(0xFF3F51B5), Color(0xFF303F9F), Color(0xFFC5CAE9))
}

// ==================== Compose 组件 ====================

/**
 * 🎨 主题状态 Composable
 */
@Composable
fun rememberThemeState(): ThemeState {
    val context = LocalContext.current
    val themeManager = remember { ThemeManager.getInstance(context) }

    val themeMode by themeManager.themeMode.collectAsState()
    val accentColor by themeManager.accentColor.collectAsState()
    val useDynamicColor by themeManager.useDynamicColor.collectAsState()
    val usePureBlack by themeManager.usePureBlack.collectAsState()
    val customPrimaryColor by themeManager.customPrimaryColor.collectAsState()

    val isSystemDarkTheme = isSystemInDarkTheme()

    val isDarkTheme = when (themeMode) {
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
        ThemeMode.SYSTEM -> isSystemDarkTheme
    }

    return remember(themeMode, accentColor, useDynamicColor, usePureBlack, customPrimaryColor, isDarkTheme) {
        ThemeState(
            themeManager = themeManager,
            themeMode = themeMode,
            accentColor = accentColor,
            useDynamicColor = useDynamicColor,
            usePureBlack = usePureBlack,
            customPrimaryColor = customPrimaryColor,
            isDarkTheme = isDarkTheme
        )
    }
}

/**
 * 🎨 主题状态数据类
 */
data class ThemeState(
    val themeManager: ThemeManager,
    val themeMode: ThemeMode,
    val accentColor: AccentColor,
    val useDynamicColor: Boolean,
    val usePureBlack: Boolean,
    val customPrimaryColor: Color?,
    val isDarkTheme: Boolean
) {
    val primaryColor: Color
        get() = customPrimaryColor ?: accentColor.primary

    val backgroundColor: Color
        get() = when {
            !isDarkTheme -> Color(0xFFF5F5F5)
            usePureBlack -> Color.Black
            else -> DeepSpaceBlue.Primary
        }

    val surfaceColor: Color
        get() = when {
            !isDarkTheme -> Color.White
            usePureBlack -> Color(0xFF121212)
            else -> DeepSpaceBlue.Secondary
        }
}

/**
 * 🎨 羲和主题 Composable
 */
@Composable
fun XiheTheme(
    themeState: ThemeState = rememberThemeState(),
    content: @Composable () -> Unit
) {
    val context = LocalContext.current

    val colorScheme = when {
        // 动态颜色 (Android 12+)
        themeState.useDynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (themeState.isDarkTheme) {
                dynamicDarkColorScheme(context)
            } else {
                dynamicLightColorScheme(context)
            }
        }
        // 深色主题
        themeState.isDarkTheme -> {
            createDarkColorScheme(
                primary = themeState.primaryColor,
                accentColor = themeState.accentColor,
                usePureBlack = themeState.usePureBlack
            )
        }
        // 浅色主题
        else -> {
            createLightColorScheme(
                primary = themeState.primaryColor,
                accentColor = themeState.accentColor
            )
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography(),
        content = content
    )
}

/**
 * 创建深色配色方案
 */
private fun createDarkColorScheme(
    primary: Color,
    accentColor: AccentColor,
    usePureBlack: Boolean
): ColorScheme {
    val backgroundColor = if (usePureBlack) Color.Black else DeepSpaceBlue.Primary
    val surfaceColor = if (usePureBlack) Color(0xFF121212) else DeepSpaceBlue.Secondary
    val surfaceVariantColor = if (usePureBlack) Color(0xFF1E1E1E) else DeepSpaceBlue.Tertiary

    return darkColorScheme(
        primary = primary,
        onPrimary = Color.Black,
        primaryContainer = accentColor.primaryVariant,
        onPrimaryContainer = Color.White,

        secondary = accentColor.secondary,
        onSecondary = Color.Black,
        secondaryContainer = accentColor.secondary.copy(alpha = 0.3f),
        onSecondaryContainer = Color.White,

        tertiary = AccentColors.Pink,
        onTertiary = Color.White,

        background = backgroundColor,
        onBackground = Color.White,

        surface = surfaceColor,
        onSurface = Color.White,
        surfaceVariant = surfaceVariantColor,
        onSurfaceVariant = Color.White.copy(alpha = 0.7f),

        error = StatusColors.Error,
        onError = Color.White,

        outline = Color.Gray.copy(alpha = 0.3f),
        outlineVariant = Color.Gray.copy(alpha = 0.1f)
    )
}

/**
 * 创建浅色配色方案
 */
private fun createLightColorScheme(
    primary: Color,
    accentColor: AccentColor
): ColorScheme {
    return lightColorScheme(
        primary = primary,
        onPrimary = Color.White,
        primaryContainer = accentColor.secondary.copy(alpha = 0.3f),
        onPrimaryContainer = accentColor.primaryVariant,

        secondary = accentColor.primaryVariant,
        onSecondary = Color.White,
        secondaryContainer = accentColor.secondary.copy(alpha = 0.2f),
        onSecondaryContainer = accentColor.primaryVariant,

        tertiary = AccentColors.Pink,
        onTertiary = Color.White,

        background = Color(0xFFF8F9FA),
        onBackground = Color(0xFF1C1B1F),

        surface = Color.White,
        onSurface = Color(0xFF1C1B1F),
        surfaceVariant = Color(0xFFE7E0EC),
        onSurfaceVariant = Color(0xFF49454F),

        error = StatusColors.Error,
        onError = Color.White,

        outline = Color(0xFF79747E),
        outlineVariant = Color(0xFFCAC4D0)
    )
}

// ==================== 辅助函数 ====================

/**
 * 🎨 羲和情绪颜色
 */
object XiheEmotionColors {
    val Happy = Color(0xFFFFEB3B)      // 开心 - 黄色
    val Sad = Color(0xFF9E9E9E)        // 悲伤 - 灰色
    val Excited = Color(0xFFFF5722)    // 兴奋 - 橙红
    val Calm = Color(0xFF00BCD4)       // 平静 - 青色
    val Tired = Color(0xFF607D8B)      // 疲惫 - 蓝灰
    val Curious = Color(0xFF9C27B0)    // 好奇 - 紫色
    val Angry = Color(0xFFF44336)      // 生气 - 红色
    val Shy = Color(0xFFFF80AB)        // 害羞 - 粉色

    /**
     * 根据情绪名称获取颜色
     */
    fun getColorByName(emotionName: String): Color {
        return when (emotionName.lowercase()) {
            "happy", "开心", "高兴" -> Happy
            "sad", "悲伤", "难过" -> Sad
            "excited", "兴奋", "激动" -> Excited
            "calm", "平静", "放松" -> Calm
            "tired", "疲惫", "累" -> Tired
            "curious", "好奇" -> Curious
            "angry", "生气", "愤怒" -> Angry
            "shy", "害羞" -> Shy
            else -> Calm
        }
    }
}

/**
 * 🎨 健康数据颜色
 */
object XiheHealthColors {
    val Water = Color(0xFF03A9F4)      // 喝水 - 蓝色
    val Exercise = Color(0xFF4CAF50)   // 运动 - 绿色
    val Sleep = Color(0xFF9C27B0)      // 睡眠 - 紫色
    val Heart = Color(0xFFE91E63)      // 心率 - 粉色
    val Steps = Color(0xFFFF9800)      // 步数 - 橙色
    val Calories = Color(0xFFF44336)   // 卡路里 - 红色
}
