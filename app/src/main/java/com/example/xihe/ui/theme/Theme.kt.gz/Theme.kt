package com.example.xihe.ui.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

/**
 * 🌈 羲和AI助手 - 主题定义
 * 提供深色和浅色主题配置
 */

// 深色主题（默认）
val XiheDarkColorScheme = darkColorScheme(
    primary = NeonCyan.Primary,
    onPrimary = Color.Black,
    primaryContainer = NeonCyan.Dark,
    onPrimaryContainer = Color.White,
    
    secondary = AccentColors.Purple,
    onSecondary = Color.White,
    secondaryContainer = AccentColors.Purple.copy(alpha = 0.3f),
    onSecondaryContainer = Color.White,
    
    tertiary = AccentColors.Pink,
    onTertiary = Color.White,
    
    background = DeepSpaceBlue.Primary,
    onBackground = Color.White,
    
    surface = DeepSpaceBlue.Secondary,
    onSurface = Color.White,
    surfaceVariant = DeepSpaceBlue.Tertiary,
    onSurfaceVariant = Color.White.copy(alpha = 0.7f),
    
    error = StatusColors.Error,
    onError = Color.White,
    
    outline = Color.Gray.copy(alpha = 0.3f),
    outlineVariant = Color.Gray.copy(alpha = 0.1f)
)

// 浅色主题（可选）
val XiheLightColorScheme = lightColorScheme(
    primary = NeonCyan.Dark,
    onPrimary = Color.White,
    primaryContainer = NeonCyan.Light,
    onPrimaryContainer = DeepSpaceBlue.Primary,
    
    secondary = AccentColors.Purple,
    onSecondary = Color.White,
    
    background = Color(0xFFF5F5F5),
    onBackground = DeepSpaceBlue.Primary,
    
    surface = Color.White,
    onSurface = DeepSpaceBlue.Primary,
    
    error = StatusColors.Error,
    onError = Color.White
)
