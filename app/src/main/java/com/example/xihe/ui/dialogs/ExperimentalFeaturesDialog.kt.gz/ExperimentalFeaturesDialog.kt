package com.example.xihe.ui.dialogs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.xihe.core.PreferencesManager
import com.example.xihe.ui.theme.DeepSpaceBlue
import com.example.xihe.ui.theme.NeonCyan
import com.example.xihe.ui.utils.rememberHapticFeedback

/**
 * ⚡ 实验性功能对话框
 * 
 * 从 SettingsDialogs.kt 中提取
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExperimentalFeaturesDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val haptic = rememberHapticFeedback()
    
    // 实验性功能状态
    var enableVisionAI by remember { mutableStateOf(PreferencesManager.getBoolean(context, "enable_vision_ai", false)) }
    var enableAutoLearning by remember { mutableStateOf(PreferencesManager.getBoolean(context, "enable_auto_learning", true)) }
    var enableProactiveChat by remember { mutableStateOf(PreferencesManager.getBoolean(context, "enable_proactive_chat", true)) }
    var enableGameAI by remember { mutableStateOf(PreferencesManager.getBoolean(context, "enable_game_ai", true)) }
    var enableTutorialLearning by remember { mutableStateOf(PreferencesManager.getBoolean(context, "enable_tutorial_learning", true)) }
    var enableTrainingDataSave by remember { mutableStateOf(PreferencesManager.getBoolean(context, "enable_training_data_save", true)) }
    var enablePerfMonitor by remember { mutableStateOf(PreferencesManager.getBoolean(context, "enable_perf_monitor", false)) }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { 
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFFFFD700))
                Spacer(modifier = Modifier.width(8.dp))
                Text("⚡ 实验性功能", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    "⚠️ 以下功能仍在开发中，可能不稳定",
                    color = Color(0xFFFFB74D),
                    fontSize = 12.sp
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // 视觉AI
                ExperimentalFeatureItem(
                    icon = Icons.Default.Visibility,
                    title = "🔍 视觉AI分析",
                    description = "使用AI分析屏幕截图，理解界面内容",
                    enabled = enableVisionAI,
                    onToggle = { 
                        enableVisionAI = it
                        PreferencesManager.setBoolean(context, "enable_vision_ai", it)
                    }
                )
                
                HorizontalDivider(color = Color.Gray.copy(alpha = 0.2f))
                
                // 自动学习
                ExperimentalFeatureItem(
                    icon = Icons.Default.School,
                    title = "🎓 自动学习",
                    description = "从用户操作中学习，自动优化执行策略",
                    enabled = enableAutoLearning,
                    onToggle = { 
                        enableAutoLearning = it
                        PreferencesManager.setBoolean(context, "enable_auto_learning", it)
                    }
                )
                
                HorizontalDivider(color = Color.Gray.copy(alpha = 0.2f))
                
                // 主动对话
                ExperimentalFeatureItem(
                    icon = Icons.Default.Chat,
                    title = "💬 主动对话",
                    description = "AI会在适当时机主动与你聊天",
                    enabled = enableProactiveChat,
                    onToggle = { 
                        enableProactiveChat = it
                        PreferencesManager.setBoolean(context, "enable_proactive_chat", it)
                    }
                )
                
                HorizontalDivider(color = Color.Gray.copy(alpha = 0.2f))
                
                // 游戏AI
                ExperimentalFeatureItem(
                    icon = Icons.Default.SportsEsports,
                    title = "🎮 游戏AI",
                    description = "自动玩游戏：五子棋、斗地主、网游等",
                    enabled = enableGameAI,
                    onToggle = { 
                        enableGameAI = it
                        PreferencesManager.setBoolean(context, "enable_game_ai", it)
                    }
                )
                
                HorizontalDivider(color = Color.Gray.copy(alpha = 0.2f))
                
                // 教程学习
                ExperimentalFeatureItem(
                    icon = Icons.Default.Search,
                    title = "📚 教程自学习",
                    description = "不会操作时自动搜索网上教程并学习",
                    enabled = enableTutorialLearning,
                    onToggle = { 
                        enableTutorialLearning = it
                        PreferencesManager.setBoolean(context, "enable_tutorial_learning", it)
                    }
                )
                
                HorizontalDivider(color = Color.Gray.copy(alpha = 0.2f))
                
                // 性能监控
                ExperimentalFeatureItem(
                    icon = Icons.Default.Dashboard,
                    title = "📊 性能仪表盘",
                    description = "在屏幕顶端显示 ASR/LLM 延迟及内存占用",
                    enabled = enablePerfMonitor,
                    onToggle = { 
                        enablePerfMonitor = it
                        PreferencesManager.setBoolean(context, "enable_perf_monitor", it)
                    }
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                haptic.lightTap()
                onDismiss()
            }) {
                Text("关闭", color = NeonCyan.Primary)
            }
        },
        containerColor = DeepSpaceBlue.Secondary
    )
}

@Composable
private fun ExperimentalFeatureItem(
    icon: ImageVector,
    title: String,
    description: String,
    enabled: Boolean,
    onToggle: (Boolean) -> Unit
) {
    val haptic = rememberHapticFeedback()
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            icon,
            contentDescription = null,
            tint = if (enabled) NeonCyan.Primary else Color.Gray,
            modifier = Modifier.size(24.dp)
        )
        
        Spacer(modifier = Modifier.width(12.dp))
        
        Column(modifier = Modifier.weight(1f)) {
            Text(
                title,
                color = Color.White,
                fontWeight = FontWeight.Medium,
                fontSize = 14.sp
            )
            Text(
                description,
                color = Color.Gray,
                fontSize = 12.sp
            )
        }
        
        Switch(
            checked = enabled,
            onCheckedChange = { 
                haptic.lightTap()
                onToggle(it) 
            },
            colors = SwitchDefaults.colors(
                checkedThumbColor = NeonCyan.Primary,
                checkedTrackColor = NeonCyan.Primary.copy(alpha = 0.3f)
            )
        )
    }
}
