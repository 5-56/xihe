package com.example.xihe.ui

import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.xihe.training.*
import kotlinx.coroutines.launch

/**
 * 🌐 API监控设置界面
 * 
 * 功能：
 * 1. 配置监控服务器地址
 * 2. 配置AI API (OpenAI等)
 * 3. 启动/停止监控
 * 4. 查看连接状态和日志
 * 5. 手动触发AI分析
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun APIMonitorSettingsScreen(
    onNavigateBack: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    val monitor = remember { APITrainingMonitor.getInstance(context) }
    val trainer = remember { OptimizedTFLiteTrainer.getInstance(context) }
    val scheduler = remember { AutoTrainingScheduler.getInstance(context) }
    
    val monitorState by monitor.monitorState.collectAsState()
    val connectionStatus by monitor.connectionStatus.collectAsState()
    val lastCommand by monitor.lastCommand.collectAsState()
    
    // 配置状态
    var apiEndpoint by remember { mutableStateOf("") }
    var apiKey by remember { mutableStateOf("") }
    var aiApiEndpoint by remember { mutableStateOf("https://api.openai.com/v1/chat/completions") }
    var aiApiKey by remember { mutableStateOf("") }
    var aiModel by remember { mutableStateOf("gpt-3.5-turbo") }
    var enableRemoteControl by remember { mutableStateOf(true) }
    var reportInterval by remember { mutableStateOf(5) }
    
    // UI状态
    var showApiKey by remember { mutableStateOf(false) }
    var showAiApiKey by remember { mutableStateOf(false) }
    var isAnalyzing by remember { mutableStateOf(false) }
    var analysisResult by remember { mutableStateOf<AIAnalysisResult?>(null) }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("🌐 API训练监控") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, "返回")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 连接状态卡片
            ConnectionStatusCard(
                monitorState = monitorState,
                connectionStatus = connectionStatus,
                onStart = {
                    val config = APIMonitorConfig(
                        apiEndpoint = apiEndpoint,
                        apiKey = apiKey.ifBlank { null },
                        aiApiEndpoint = aiApiEndpoint,
                        aiApiKey = aiApiKey,
                        aiModel = aiModel,
                        enableRemoteControl = enableRemoteControl,
                        reportIntervalMs = reportInterval * 1000L
                    )
                    monitor.configure(config)
                    monitor.startMonitoring(trainer, scheduler)
                },
                onStop = { monitor.stopMonitoring() }
            )
            
            // 监控服务器配置
            ConfigSection(title = "📡 监控服务器") {
                OutlinedTextField(
                    value = apiEndpoint,
                    onValueChange = { apiEndpoint = it },
                    label = { Text("服务器地址") },
                    placeholder = { Text("https://your-server.com/api") },
                    modifier = Modifier.fillMaxWidth(),
                    leadingIcon = { Icon(Icons.Default.Cloud, null) },
                    singleLine = true
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                OutlinedTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it },
                    label = { Text("API Key (可选)") },
                    modifier = Modifier.fillMaxWidth(),
                    leadingIcon = { Icon(Icons.Default.Key, null) },
                    trailingIcon = {
                        IconButton(onClick = { showApiKey = !showApiKey }) {
                            Icon(
                                if (showApiKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                null
                            )
                        }
                    },
                    visualTransformation = if (showApiKey) VisualTransformation.None else PasswordVisualTransformation(),
                    singleLine = true
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("上报间隔 (秒)")
                    Slider(
                        value = reportInterval.toFloat(),
                        onValueChange = { reportInterval = it.toInt() },
                        valueRange = 1f..30f,
                        steps = 28,
                        modifier = Modifier.weight(1f).padding(horizontal = 16.dp)
                    )
                    Text("${reportInterval}s", fontWeight = FontWeight.Bold)
                }
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("远程控制", fontWeight = FontWeight.Medium)
                        Text(
                            "允许通过API控制训练",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                    Switch(
                        checked = enableRemoteControl,
                        onCheckedChange = { enableRemoteControl = it }
                    )
                }
            }
            
            // AI API配置
            ConfigSection(title = "🤖 AI分析API") {
                OutlinedTextField(
                    value = aiApiEndpoint,
                    onValueChange = { aiApiEndpoint = it },
                    label = { Text("API端点") },
                    modifier = Modifier.fillMaxWidth(),
                    leadingIcon = { Icon(Icons.Default.Api, null) },
                    singleLine = true
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                OutlinedTextField(
                    value = aiApiKey,
                    onValueChange = { aiApiKey = it },
                    label = { Text("AI API Key") },
                    modifier = Modifier.fillMaxWidth(),
                    leadingIcon = { Icon(Icons.Default.Key, null) },
                    trailingIcon = {
                        IconButton(onClick = { showAiApiKey = !showAiApiKey }) {
                            Icon(
                                if (showAiApiKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                null
                            )
                        }
                    },
                    visualTransformation = if (showAiApiKey) VisualTransformation.None else PasswordVisualTransformation(),
                    singleLine = true
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                OutlinedTextField(
                    value = aiModel,
                    onValueChange = { aiModel = it },
                    label = { Text("模型名称") },
                    placeholder = { Text("gpt-3.5-turbo / gpt-4") },
                    modifier = Modifier.fillMaxWidth(),
                    leadingIcon = { Icon(Icons.Default.Memory, null) },
                    singleLine = true
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                // AI分析按钮
                Button(
                    onClick = {
                        scope.launch {
                            isAnalyzing = true
                            // 先配置
                            val config = APIMonitorConfig(
                                aiApiEndpoint = aiApiEndpoint,
                                aiApiKey = aiApiKey,
                                aiModel = aiModel
                            )
                            monitor.configure(config)
                            // 请求分析
                            analysisResult = monitor.requestAIAnalysis()
                            isAnalyzing = false
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = aiApiKey.isNotBlank() && !isAnalyzing
                ) {
                    if (isAnalyzing) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = Color.White,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("分析中...")
                    } else {
                        Icon(Icons.Default.Psychology, null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("请求AI分析训练状态")
                    }
                }
            }
            
            // AI分析结果
            analysisResult?.let { result ->
                AIAnalysisResultCard(result = result)
            }
            
            // 最近指令
            lastCommand?.let { command ->
                LastCommandCard(command = command)
            }
            
            // 使用说明
            HelpCard()
        }
    }
}

/**
 * 🔌 连接状态卡片
 */
@Composable
private fun ConnectionStatusCard(
    monitorState: MonitorState,
    connectionStatus: ConnectionStatus,
    onStart: () -> Unit,
    onStop: () -> Unit
) {
    val isConnected = monitorState == MonitorState.CONNECTED
    
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (isConnected) 
                Color(0xFF4CAF50).copy(alpha = 0.1f)
            else 
                MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (isConnected) Icons.Default.CloudDone else Icons.Default.CloudOff,
                        contentDescription = null,
                        tint = if (isConnected) Color(0xFF4CAF50) else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = when (monitorState) {
                                MonitorState.CONNECTED -> "监控已连接"
                                MonitorState.CONNECTING -> "正在连接..."
                                MonitorState.ERROR -> "连接错误"
                                MonitorState.DISCONNECTED -> "未连接"
                            },
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        if (isConnected) {
                            Text(
                                text = "成功上报: ${connectionStatus.successfulReports}次",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                    }
                }
                
                Button(
                    onClick = if (isConnected) onStop else onStart,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isConnected) 
                            Color(0xFFF44336) 
                        else 
                            MaterialTheme.colorScheme.primary
                    )
                ) {
                    Icon(
                        if (isConnected) Icons.Default.Stop else Icons.Default.PlayArrow,
                        null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (isConnected) "停止" else "启动")
                }
            }
            
            // 错误信息
            connectionStatus.lastError?.let { error ->
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "❌ $error",
                    fontSize = 12.sp,
                    color = Color(0xFFF44336)
                )
            }
        }
    }
}

/**
 * 📦 配置区域
 */
@Composable
private fun ConfigSection(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
            content()
        }
    }
}

/**
 * 🤖 AI分析结果卡片
 */
@Composable
private fun AIAnalysisResultCard(result: AIAnalysisResult) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = when (result) {
                is AIAnalysisResult.Success -> Color(0xFF2196F3).copy(alpha = 0.1f)
                is AIAnalysisResult.Error -> Color(0xFFF44336).copy(alpha = 0.1f)
            }
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    when (result) {
                        is AIAnalysisResult.Success -> Icons.Default.CheckCircle
                        is AIAnalysisResult.Error -> Icons.Default.Error
                    },
                    contentDescription = null,
                    tint = when (result) {
                        is AIAnalysisResult.Success -> Color(0xFF2196F3)
                        is AIAnalysisResult.Error -> Color(0xFFF44336)
                    }
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "🤖 AI分析结果",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            when (result) {
                is AIAnalysisResult.Success -> {
                    val analysis = result.analysis
                    
                    Text(
                        text = "状态: ${analysis.status}",
                        fontWeight = FontWeight.Medium
                    )
                    
                    Text(
                        text = if (analysis.shouldContinue) "✅ 建议继续训练" else "⏸️ 建议暂停训练",
                        color = if (analysis.shouldContinue) Color(0xFF4CAF50) else Color(0xFFFF9800)
                    )
                    
                    if (analysis.suggestions.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("💡 建议:", fontWeight = FontWeight.Medium)
                        analysis.suggestions.forEach { suggestion ->
                            Text("  • $suggestion", fontSize = 14.sp)
                        }
                    }
                    
                    if (analysis.warnings.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("⚠️ 警告:", fontWeight = FontWeight.Medium, color = Color(0xFFFF9800))
                        analysis.warnings.forEach { warning ->
                            Text("  • $warning", fontSize = 14.sp, color = Color(0xFFFF9800))
                        }
                    }
                }
                is AIAnalysisResult.Error -> {
                    Text(
                        text = result.message,
                        color = Color(0xFFF44336)
                    )
                }
            }
        }
    }
}

/**
 * 📋 最近指令卡片
 */
@Composable
private fun LastCommandCard(command: RemoteCommand) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Default.Terminal,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.tertiary
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = "最近收到指令",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = command.type.name,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }
        }
    }
}

/**
 * 📖 帮助卡片
 */
@Composable
private fun HelpCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "📖 使用说明",
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            val helps = listOf(
                "📡 监控服务器" to "配置你的训练监控服务器地址，可实时查看训练状态",
                "🤖 AI分析" to "使用OpenAI等API分析训练状态，获取智能建议",
                "🎮 远程控制" to "通过API远程开始/停止训练、调整参数"
            )
            
            helps.forEach { (title, desc) ->
                Row(modifier = Modifier.padding(vertical = 4.dp)) {
                    Text(
                        text = title,
                        fontWeight = FontWeight.Medium,
                        fontSize = 13.sp,
                        modifier = Modifier.width(90.dp)
                    )
                    Text(
                        text = desc,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
            }
        }
    }
}
