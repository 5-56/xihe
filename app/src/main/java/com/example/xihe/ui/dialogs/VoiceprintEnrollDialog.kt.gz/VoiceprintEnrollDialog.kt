package com.example.xihe.ui.dialogs

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.xihe.interaction.VoiceprintManager

/**
 * 🔐 声纹录制对话框
 * 
 * 从 SettingsDialogs.kt 中提取
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceprintEnrollDialog(onDismiss: () -> Unit) {
    var userName by remember { mutableStateOf("主人") }
    var enrollmentStep by remember { mutableStateOf(0) } // 0=输入名称, 1=录制中, 2=完成
    var currentSample by remember { mutableStateOf(0) }
    var totalSamples by remember { mutableStateOf(3) }
    var resultMessage by remember { mutableStateOf("") }
    var isSuccess by remember { mutableStateOf(false) }
    
    AlertDialog(
        onDismissRequest = { if (enrollmentStep != 1) onDismiss() },
        title = { 
            Text(
                when (enrollmentStep) {
                    0 -> "🔐 录制声纹"
                    1 -> "🎤 正在录制..."
                    else -> if (isSuccess) "✅ 录制成功" else "❌ 录制失败"
                },
                color = MaterialTheme.colorScheme.onSurface, 
                fontWeight = FontWeight.Bold
            ) 
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                when (enrollmentStep) {
                    0 -> {
                        // 输入用户名
                        Text("请输入你的称呼：", color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = userName,
                            onValueChange = { userName = it },
                            label = { Text("称呼", color = MaterialTheme.colorScheme.onSurfaceVariant) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                                focusedTextColor = MaterialTheme.colorScheme.onSurface,
                                unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                            ),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            "💡 接下来需要录制3次你说「羲和」的声音",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 12.sp
                        )
                        Text(
                            "🎤 每次录制3秒，请在安静环境下进行",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 12.sp
                        )
                    }
                    1 -> {
                        // 录制进度
                        Text(
                            "请说「羲和」",
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        // 进度指示
                        LinearProgressIndicator(
                            progress = { currentSample.toFloat() / totalSamples },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp),
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "第 $currentSample / $totalSamples 次",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        // 麦克风动画指示
                        Icon(
                            Icons.Default.Mic,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(48.dp)
                        )
                        Text(
                            "🔴 录音中...",
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 12.sp
                        )
                    }
                    else -> {
                        // 结果显示
                        Icon(
                            if (isSuccess) Icons.Default.CheckCircle else Icons.Default.Error,
                            contentDescription = null,
                            tint = if (isSuccess) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            resultMessage,
                            color = if (isSuccess) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                            fontSize = 14.sp
                        )
                        if (isSuccess) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "现在只有你说「羲和」，系统才会响应啦~",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            when (enrollmentStep) {
                0 -> {
                    Button(
                        onClick = {
                            enrollmentStep = 1
                            // 开始录制
                            VoiceprintManager.startEnrollment(
                                userId = java.util.UUID.randomUUID().toString(),
                                userName = userName,
                                onProgress = { current, total ->
                                    currentSample = current
                                    totalSamples = total
                                },
                                onComplete = { success, message ->
                                    isSuccess = success
                                    resultMessage = message
                                    enrollmentStep = 2
                                }
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        enabled = userName.isNotBlank()
                    ) {
                        Text("开始录制", color = MaterialTheme.colorScheme.onPrimary)
                    }
                }
                1 -> {
                    // 录制中不显示按钮
                }
                else -> {
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("完成", color = MaterialTheme.colorScheme.onPrimary)
                    }
                }
            }
        },
        dismissButton = {
            if (enrollmentStep != 1) {
                TextButton(onClick = onDismiss) {
                    Text("取消", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.surface
    )
}
