package com.example.xihe.ui.theme

import android.content.Context
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.*

/**
 * 🎨 主题模式管理
 * 
 * 注意：主要的 ThemeManager 实现在 com.example.xihe.ui.ThemeManager
 * 此文件仅保留辅助函数
 */

/**
 * 🎭 判断是否使用深色模式
 */
@Composable
fun shouldUseDarkTheme(themeMode: com.example.xihe.ui.ThemeMode): Boolean {
    val isSystemDark = isSystemInDarkTheme()
    
    return when (themeMode) {
        com.example.xihe.ui.ThemeMode.LIGHT -> false
        com.example.xihe.ui.ThemeMode.DARK -> true
        com.example.xihe.ui.ThemeMode.SYSTEM -> isSystemDark
    }
}

