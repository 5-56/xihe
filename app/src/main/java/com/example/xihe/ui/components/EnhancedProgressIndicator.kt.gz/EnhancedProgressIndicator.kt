package com.example.xihe.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * 📊 增强任务进度指示器
 * 
 * 功能:
 * 1. 实时进度显示
 * 2. 步骤详情展示
 * 3. 预计剩余时间
 * 4. 动画效果
 * 5. 可取消/暂停
 * 
 * 优化点:
 * - 视觉反馈更明显
 * - 信息更详细
 * - 交互更友好
 */
@Composable
fun EnhancedProgressIndicator(
    taskName: String,
    currentStep: Int,
    totalSteps: Int,
    stepDescription: String,
    progress: Float,
    estimatedTimeSeconds: Int,
    status: TaskStatus = TaskStatus.RUNNING,
    onPause: () -> Unit = {},
    onResume: () -> Unit = {},
    onCancel: () -> Unit = {}
) {
    // 动画
    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "progress"
    )
    
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        ) {
            // 任务名称和状态
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = taskName,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.height(4.dp))
                    TaskStatusChip(status)
                }
                
                // 状态图标
                AnimatedTaskIcon(status)
            }
            
            Spacer(Modifier.height(20.dp))
            
            // 当前步骤
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.PlayCircle,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = stepDescription,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.9f)
                )
            }
            
            Spacer(Modifier.height(16.dp))
            
            // 进度条
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(12.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(animatedProgress)
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(
                                    MaterialTheme.colorScheme.primary,
                                    MaterialTheme.colorScheme.primaryContainer
                                )
                            )
                        )
                )
            }
            
            Spacer(Modifier.height(12.dp))
            
            // 步骤计数和预计时间
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "步骤 $currentStep/$totalSteps",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )
                
                if (estimatedTimeSeconds > 0) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Timer,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = "预计 ${formatTime(estimatedTimeSeconds)}",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                        )
                    }
                }
            }
            
            Spacer(Modifier.height(20.dp))
            
            // 控制按钮
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                when (status) {
                    TaskStatus.RUNNING -> {
                        OutlinedButton(
                            onClick = onPause,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = MaterialTheme.colorScheme.primary
                            )
                        ) {
                            Icon(Icons.Default.Pause, "暂停", Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("暂停")
                        }
                    }
                    
                    TaskStatus.PAUSED -> {
                        Button(
                            onClick = onResume,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary
                            )
                        ) {
                            Icon(Icons.Default.PlayArrow, "继续", Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("继续")
                        }
                    }
                    
                    else -> {}
                }
                
                // 取消按钮
                if (status in listOf(TaskStatus.RUNNING, TaskStatus.PAUSED)) {
                    OutlinedButton(
                        onClick = onCancel,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.error
                        )
                    ) {
                        Icon(Icons.Default.Close, "取消", Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("取消")
                    }
                }
            }
        }
    }
}

/**
 * 🎯 任务状态标签
 */
@Composable
fun TaskStatusChip(status: TaskStatus) {
    val (text, color) = when (status) {
        TaskStatus.RUNNING -> "执行中" to Color(0xFF2196F3)
        TaskStatus.PAUSED -> "已暂停" to Color(0xFFFF9800)
        TaskStatus.COMPLETED -> "已完成" to Color(0xFF4CAF50)
        TaskStatus.FAILED -> "失败" to Color(0xFFF44336)
        TaskStatus.CANCELLED -> "已取消" to Color(0xFF9E9E9E)
    }
    
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = color.copy(alpha = 0.2f)
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            fontSize = 12.sp,
            color = color,
            fontWeight = FontWeight.Bold
        )
    }
}

/**
 * 🎨 动画状态图标
 */
@Composable
fun AnimatedTaskIcon(status: TaskStatus) {
    val infiniteTransition = rememberInfiniteTransition(label = "icon")
    
    when (status) {
        TaskStatus.RUNNING -> {
            val rotation by infiniteTransition.animateFloat(
                initialValue = 0f,
                targetValue = 360f,
                animationSpec = infiniteRepeatable(
                    animation = tween(2000, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart
                ),
                label = "rotation"
            )
            
            Icon(
                Icons.Default.Refresh,
                contentDescription = "运行中",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(32.dp)
            )
        }
        
        TaskStatus.COMPLETED -> {
            Icon(
                Icons.Default.CheckCircle,
                contentDescription = "完成",
                tint = Color(0xFF4CAF50),
                modifier = Modifier.size(32.dp)
            )
        }
        
        TaskStatus.FAILED -> {
            Icon(
                Icons.Default.Error,
                contentDescription = "失败",
                tint = Color(0xFFF44336),
                modifier = Modifier.size(32.dp)
            )
        }
        
        TaskStatus.PAUSED -> {
            Icon(
                Icons.Default.PauseCircle,
                contentDescription = "暂停",
                tint = Color(0xFFFF9800),
                modifier = Modifier.size(32.dp)
            )
        }
        
        TaskStatus.CANCELLED -> {
            Icon(
                Icons.Default.Cancel,
                contentDescription = "取消",
                tint = Color(0xFF9E9E9E),
                modifier = Modifier.size(32.dp)
            )
        }
    }
}

/**
 * ⏱️ 格式化时间
 */
private fun formatTime(seconds: Int): String {
    return when {
        seconds < 60 -> "${seconds}秒"
        seconds < 3600 -> "${seconds / 60}分${seconds % 60}秒"
        else -> "${seconds / 3600}小时${(seconds % 3600) / 60}分"
    }
}

// ==================== 数据类 ====================

/**
 * 📊 任务状态
 */
enum class TaskStatus {
    RUNNING,        // 运行中
    PAUSED,         // 已暂停
    COMPLETED,      // 已完成
    FAILED,         // 失败
    CANCELLED       // 已取消
}

/**
 * 📝 步骤详情
 */
data class StepDetail(
    val stepNumber: Int,
    val description: String,
    val status: StepStatus,
    val duration: Long = 0
)

/**
 * ✅ 步骤状态
 */
enum class StepStatus {
    PENDING,        // 待执行
    RUNNING,        // 执行中
    COMPLETED,      // 已完成
    FAILED,         // 失败
    SKIPPED         // 跳过
}

