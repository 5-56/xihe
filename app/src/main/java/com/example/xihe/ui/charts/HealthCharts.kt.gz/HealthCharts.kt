package com.example.xihe.ui.charts

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * 📊 健康数据图表组件
 */

/**
 * 📈 折线图 - 显示趋势
 */
@Composable
fun LineChart(
    title: String,
    data: List<ChartData>,
    goal: Float? = null,
    modifier: Modifier = Modifier,
    lineColor: Color = Color(0xFF2196F3),
    goalColor: Color = Color(0xFF4CAF50)
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            
            if (data.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("暂无数据", color = Color.Gray)
                }
            } else {
                // 动画进度
                var animationProgress by remember { mutableStateOf(0f) }
                
                LaunchedEffect(data) {
                    animationProgress = 0f
                    animate(
                        initialValue = 0f,
                        targetValue = 1f,
                        animationSpec = tween(durationMillis = 1000)
                    ) { value, _ ->
                        animationProgress = value
                    }
                }
                
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                ) {
                    val width = size.width
                    val height = size.height
                    val padding = 40f
                    
                    val chartWidth = width - padding * 2
                    val chartHeight = height - padding * 2
                    
                    // 计算最大值
                    val maxValue = (data.maxOfOrNull { it.value } ?: 1f).coerceAtLeast(goal ?: 1f)
                    val minValue = 0f
                    
                    // 绘制网格线
                    val gridLines = 5
                    for (i in 0..gridLines) {
                        val y = padding + chartHeight * (i.toFloat() / gridLines)
                        drawLine(
                            color = Color.LightGray.copy(alpha = 0.3f),
                            start = Offset(padding, y),
                            end = Offset(width - padding, y),
                            strokeWidth = 1f
                        )
                    }
                    
                    // 绘制目标线
                    if (goal != null) {
                        val goalY = padding + chartHeight * (1 - goal / maxValue)
                        drawLine(
                            color = goalColor.copy(alpha = 0.5f),
                            start = Offset(padding, goalY),
                            end = Offset(width - padding, goalY),
                            strokeWidth = 2f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f))
                        )
                    }
                    
                    // 绘制折线
                    if (data.size > 1) {
                        val points = data.mapIndexed { index, chartData ->
                            val x = padding + chartWidth * (index.toFloat() / (data.size - 1))
                            val normalizedValue = (chartData.value - minValue) / (maxValue - minValue)
                            val y = padding + chartHeight * (1 - normalizedValue)
                            Offset(x, y)
                        }
                        
                        // 绘制线条（带动画）
                        val path = Path()
                        val animatedPoints = points.take((points.size * animationProgress).toInt().coerceAtLeast(1))
                        
                        animatedPoints.forEachIndexed { index, point ->
                            if (index == 0) {
                                path.moveTo(point.x, point.y)
                            } else {
                                path.lineTo(point.x, point.y)
                            }
                        }
                        
                        drawPath(
                            path = path,
                            color = lineColor,
                            style = Stroke(width = 4f)
                        )
                        
                        // 绘制点
                        animatedPoints.forEach { point ->
                            drawCircle(
                                color = lineColor,
                                radius = 6f,
                                center = point
                            )
                            drawCircle(
                                color = Color.White,
                                radius = 3f,
                                center = point
                            )
                        }
                    }
                }
                
                // 图例
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    data.firstOrNull()?.label?.let {
                        Text(text = it, fontSize = 12.sp, color = Color.Gray)
                    }
                    data.lastOrNull()?.label?.let {
                        Text(text = it, fontSize = 12.sp, color = Color.Gray)
                    }
                }
            }
        }
    }
}

/**
 * 📊 柱状图 - 显示对比
 */
@Composable
fun BarChart(
    title: String,
    data: List<ChartData>,
    goal: Float? = null,
    modifier: Modifier = Modifier,
    barColor: Color = Color(0xFF4CAF50)
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            
            if (data.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("暂无数据", color = Color.Gray)
                }
            } else {
                // 动画进度
                val animationProgress = remember { Animatable(0f) }
                
                LaunchedEffect(data) {
                    animationProgress.snapTo(0f)
                    animationProgress.animateTo(
                        targetValue = 1f,
                        animationSpec = tween(durationMillis = 800)
                    )
                }
                
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                ) {
                    val width = size.width
                    val height = size.height
                    val padding = 40f
                    
                    val chartWidth = width - padding * 2
                    val chartHeight = height - padding * 2
                    
                    val maxValue = (data.maxOfOrNull { it.value } ?: 1f).coerceAtLeast(goal ?: 1f)
                    
                    val barWidth = chartWidth / (data.size * 2)
                    val spacing = barWidth / 2
                    
                    data.forEachIndexed { index, chartData ->
                        val x = padding + index * (barWidth * 2 + spacing)
                        val normalizedValue = chartData.value / maxValue
                        val animatedHeight = chartHeight * normalizedValue * animationProgress.value
                        val y = padding + chartHeight - animatedHeight
                        
                        // 判断是否达标
                        val color = if (goal != null && chartData.value >= goal) {
                            Color(0xFF4CAF50) // 绿色：达标
                        } else {
                            Color(0xFFFF9800) // 橙色：未达标
                        }
                        
                        // 绘制柱子
                        drawRoundRect(
                            color = color,
                            topLeft = Offset(x, y),
                            size = Size(barWidth * 2, animatedHeight),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f)
                        )
                        
                        // 绘制数值
                        drawContext.canvas.nativeCanvas.apply {
                            val text = chartData.value.toInt().toString()
                            val paint = android.graphics.Paint().apply {
                                this.color = android.graphics.Color.WHITE
                                textSize = 24f
                                textAlign = android.graphics.Paint.Align.CENTER
                            }
                            drawText(
                                text,
                                x + barWidth,
                                y + animatedHeight / 2 + 8f,
                                paint
                            )
                        }
                    }
                    
                    // 绘制目标线
                    if (goal != null) {
                        val goalY = padding + chartHeight * (1 - goal / maxValue)
                        drawLine(
                            color = Color(0xFF4CAF50).copy(alpha = 0.5f),
                            start = Offset(padding, goalY),
                            end = Offset(width - padding, goalY),
                            strokeWidth = 2f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f))
                        )
                    }
                }
                
                // 标签
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    data.forEach { chartData ->
                        Text(
                            text = chartData.label,
                            fontSize = 12.sp,
                            color = Color.Gray,
                            modifier = Modifier.width(40.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * 🥧 饼图 - 显示占比
 */
@Composable
fun PieChart(
    title: String,
    data: List<PieData>,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            
            if (data.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("暂无数据", color = Color.Gray)
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // 饼图
                    val animationProgress = remember { Animatable(0f) }
                    
                    LaunchedEffect(data) {
                        animationProgress.snapTo(0f)
                        animationProgress.animateTo(
                            targetValue = 1f,
                            animationSpec = tween(durationMillis = 1000)
                        )
                    }
                    
                    Canvas(
                        modifier = Modifier.size(150.dp)
                    ) {
                        val total = data.sumOf { it.value.toDouble() }.toFloat()
                        var startAngle = -90f
                        
                        data.forEach { pieData ->
                            val sweepAngle = (pieData.value / total * 360f) * animationProgress.value
                            
                            drawArc(
                                color = pieData.color,
                                startAngle = startAngle,
                                sweepAngle = sweepAngle,
                                useCenter = true,
                                size = size
                            )
                            
                            startAngle += sweepAngle
                        }
                        
                        // 绘制中心圆（甜甜圈效果）
                        drawCircle(
                            color = Color.White,
                            radius = size.minDimension * 0.35f
                        )
                    }
                    
                    // 图例
                    Column(
                        modifier = Modifier.padding(start = 16.dp)
                    ) {
                        data.forEach { pieData ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(vertical = 4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .background(pieData.color)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "${pieData.label} (${pieData.value.toInt()})",
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * 🎯 雷达图 - 显示多维度评分
 */
@Composable
fun RadarChart(
    title: String,
    dimensions: List<String>,
    scores: List<Float>,
    modifier: Modifier = Modifier,
    maxScore: Float = 100f,
    fillColor: Color = Color(0xFF2196F3)
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            
            val animationProgress = remember { Animatable(0f) }
            
            LaunchedEffect(scores) {
                animationProgress.snapTo(0f)
                animationProgress.animateTo(
                    targetValue = 1f,
                    animationSpec = tween(durationMillis = 1000)
                )
            }
            
            Canvas(
                modifier = Modifier.size(250.dp)
            ) {
                val center = Offset(size.width / 2, size.height / 2)
                val radius = size.minDimension / 2 * 0.8f
                val angleStep = 360f / dimensions.size
                
                // 绘制背景网格
                for (level in 1..5) {
                    val levelRadius = radius * level / 5
                    val path = Path()
                    
                    for (i in dimensions.indices) {
                        val angle = Math.toRadians((angleStep * i - 90).toDouble())
                        val x = center.x + (levelRadius * cos(angle)).toFloat()
                        val y = center.y + (levelRadius * sin(angle)).toFloat()
                        
                        if (i == 0) {
                            path.moveTo(x, y)
                        } else {
                            path.lineTo(x, y)
                        }
                    }
                    path.close()
                    
                    drawPath(
                        path = path,
                        color = Color.LightGray.copy(alpha = 0.3f),
                        style = Stroke(width = 1f)
                    )
                }
                
                // 绘制轴线
                for (i in dimensions.indices) {
                    val angle = Math.toRadians((angleStep * i - 90).toDouble())
                    val endX = center.x + (radius * cos(angle)).toFloat()
                    val endY = center.y + (radius * sin(angle)).toFloat()
                    
                    drawLine(
                        color = Color.LightGray.copy(alpha = 0.5f),
                        start = center,
                        end = Offset(endX, endY),
                        strokeWidth = 1f
                    )
                }
                
                // 绘制数据区域
                if (scores.size == dimensions.size) {
                    val dataPath = Path()
                    val animatedScores = scores.map { it * animationProgress.value }
                    
                    animatedScores.forEachIndexed { i, score ->
                        val angle = Math.toRadians((angleStep * i - 90).toDouble())
                        val normalizedScore = (score / maxScore).coerceIn(0f, 1f)
                        val pointRadius = radius * normalizedScore
                        val x = center.x + (pointRadius * cos(angle)).toFloat()
                        val y = center.y + (pointRadius * sin(angle)).toFloat()
                        
                        if (i == 0) {
                            dataPath.moveTo(x, y)
                        } else {
                            dataPath.lineTo(x, y)
                        }
                    }
                    dataPath.close()
                    
                    // 填充
                    drawPath(
                        path = dataPath,
                        color = fillColor.copy(alpha = 0.3f)
                    )
                    
                    // 边框
                    drawPath(
                        path = dataPath,
                        color = fillColor,
                        style = Stroke(width = 3f)
                    )
                }
            }
            
            // 维度标签
            Column(
                modifier = Modifier.padding(top = 8.dp)
            ) {
                dimensions.forEachIndexed { index, dimension ->
                    Row(
                        modifier = Modifier.padding(vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = dimension,
                            fontSize = 12.sp,
                            modifier = Modifier.weight(1f)
                        )
                        if (index < scores.size) {
                            Text(
                                text = "${scores[index].toInt()}分",
                                fontSize = 12.sp,
                                color = fillColor
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * 📊 图表数据模型
 */
data class ChartData(
    val label: String,
    val value: Float
)

data class PieData(
    val label: String,
    val value: Float,
    val color: Color
)

// ==================== 健康专用组件 ====================

/**
 * 💓 心率仪表盘
 */
@Composable
fun HeartRateGauge(
    currentBpm: Int,
    minBpm: Int = 60,
    maxBpm: Int = 100,
    modifier: Modifier = Modifier
) {
    val animatedBpm = remember { Animatable(0f) }
    
    LaunchedEffect(currentBpm) {
        animatedBpm.animateTo(
            targetValue = currentBpm.toFloat(),
            animationSpec = tween(durationMillis = 1000)
        )
    }
    
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("💓 心率", style = MaterialTheme.typography.titleMedium)
            
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(180.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val radius = size.minDimension / 2 * 0.85f
                    val center = Offset(size.width / 2, size.height / 2)
                    
                    // 背景弧
                    drawArc(
                        color = Color.LightGray.copy(alpha = 0.3f),
                        startAngle = 135f,
                        sweepAngle = 270f,
                        useCenter = false,
                        topLeft = Offset(center.x - radius, center.y - radius),
                        size = Size(radius * 2, radius * 2),
                        style = Stroke(width = 20f, cap = StrokeCap.Round)
                    )
                    
                    // 数值弧
                    val normalizedValue = ((animatedBpm.value - 40) / 160f).coerceIn(0f, 1f)
                    val sweepAngle = 270f * normalizedValue
                    
                    val color = when {
                        currentBpm < minBpm -> Color(0xFFFF9800) // 偏低 - 橙色
                        currentBpm > maxBpm -> Color(0xFFF44336) // 偏高 - 红色
                        else -> Color(0xFF4CAF50) // 正常 - 绿色
                    }
                    
                    drawArc(
                        color = color,
                        startAngle = 135f,
                        sweepAngle = sweepAngle,
                        useCenter = false,
                        topLeft = Offset(center.x - radius, center.y - radius),
                        size = Size(radius * 2, radius * 2),
                        style = Stroke(width = 20f, cap = StrokeCap.Round)
                    )
                }
                
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "${animatedBpm.value.toInt()}",
                        style = MaterialTheme.typography.headlineLarge,
                        color = when {
                            currentBpm < minBpm -> Color(0xFFFF9800)
                            currentBpm > maxBpm -> Color(0xFFF44336)
                            else -> Color(0xFF4CAF50)
                        }
                    )
                    Text("BPM", fontSize = 14.sp, color = Color.Gray)
                }
            }
            
            // 状态提示
            val status = when {
                currentBpm < minBpm -> "💤 心率偏低"
                currentBpm > maxBpm -> "⚠️ 心率偏高"
                else -> "✅ 心率正常"
            }
            Text(status, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

/**
 * 🚶 步数进度环
 */
@Composable
fun StepsProgressRing(
    steps: Int,
    goal: Int = 10000,
    modifier: Modifier = Modifier
) {
    val animatedProgress = remember { Animatable(0f) }
    
    LaunchedEffect(steps) {
        animatedProgress.animateTo(
            targetValue = (steps.toFloat() / goal).coerceIn(0f, 1f),
            animationSpec = tween(durationMillis = 1500)
        )
    }
    
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("🚶 今日步数", style = MaterialTheme.typography.titleMedium)
            
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(160.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val strokeWidth = 24f
                    val radius = (size.minDimension - strokeWidth) / 2
                    val center = Offset(size.width / 2, size.height / 2)
                    
                    // 背景环
                    drawCircle(
                        color = Color.LightGray.copy(alpha = 0.2f),
                        radius = radius,
                        center = center,
                        style = Stroke(width = strokeWidth)
                    )
                    
                    // 进度环
                    val color = if (steps >= goal) Color(0xFF4CAF50) else Color(0xFF2196F3)
                    drawArc(
                        color = color,
                        startAngle = -90f,
                        sweepAngle = 360f * animatedProgress.value,
                        useCenter = false,
                        topLeft = Offset(center.x - radius, center.y - radius),
                        size = Size(radius * 2, radius * 2),
                        style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                    )
                }
                
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "$steps",
                        style = MaterialTheme.typography.headlineMedium
                    )
                    Text(
                        text = "/ $goal",
                        fontSize = 14.sp,
                        color = Color.Gray
                    )
                }
            }
            
            // 完成百分比
            val percentage = ((steps.toFloat() / goal) * 100).toInt()
            Text(
                text = if (steps >= goal) "🎉 目标达成！" else "$percentage% 完成",
                fontSize = 14.sp,
                color = if (steps >= goal) Color(0xFF4CAF50) else Color.Gray,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}

/**
 * 😴 睡眠质量卡片
 */
@Composable
fun SleepQualityCard(
    deepSleepHours: Float,
    lightSleepHours: Float,
    awakeHours: Float,
    modifier: Modifier = Modifier
) {
    val totalHours = deepSleepHours + lightSleepHours + awakeHours
    
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("😴 睡眠质量", style = MaterialTheme.typography.titleMedium)
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // 睡眠时长条
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(24.dp)
            ) {
                if (totalHours > 0) {
                    // 深睡
                    Box(
                        modifier = Modifier
                            .weight(deepSleepHours / totalHours)
                            .fillMaxHeight()
                            .background(Color(0xFF3F51B5))
                    )
                    // 浅睡
                    Box(
                        modifier = Modifier
                            .weight(lightSleepHours / totalHours)
                            .fillMaxHeight()
                            .background(Color(0xFF7986CB))
                    )
                    // 清醒
                    if (awakeHours > 0) {
                        Box(
                            modifier = Modifier
                                .weight(awakeHours / totalHours)
                                .fillMaxHeight()
                                .background(Color(0xFFFFB74D))
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // 图例
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                SleepLegendItem("深睡", deepSleepHours, Color(0xFF3F51B5))
                SleepLegendItem("浅睡", lightSleepHours, Color(0xFF7986CB))
                SleepLegendItem("清醒", awakeHours, Color(0xFFFFB74D))
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // 总时长
            Text(
                text = "总睡眠: ${String.format("%.1f", totalHours)} 小时",
                fontSize = 14.sp,
                color = Color.Gray,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            
            // 睡眠评分
            val score = calculateSleepScore(deepSleepHours, lightSleepHours, awakeHours)
            Text(
                text = "睡眠评分: $score 分",
                fontSize = 16.sp,
                color = when {
                    score >= 80 -> Color(0xFF4CAF50)
                    score >= 60 -> Color(0xFFFF9800)
                    else -> Color(0xFFF44336)
                },
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(top = 4.dp)
            )
        }
    }
}

@Composable
private fun SleepLegendItem(label: String, hours: Float, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(12.dp)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text("$label ${String.format("%.1f", hours)}h", fontSize = 12.sp)
    }
}

private fun calculateSleepScore(deep: Float, light: Float, awake: Float): Int {
    val total = deep + light + awake
    if (total == 0f) return 0
    
    val deepRatio = deep / total
    val awakeRatio = awake / total
    
    // 基础分：总时长
    var score = when {
        total >= 8 -> 40
        total >= 7 -> 35
        total >= 6 -> 25
        else -> 15
    }
    
    // 深睡占比加分
    score += when {
        deepRatio >= 0.25 -> 35
        deepRatio >= 0.20 -> 30
        deepRatio >= 0.15 -> 20
        else -> 10
    }
    
    // 清醒时间扣分
    score += when {
        awakeRatio <= 0.05 -> 25
        awakeRatio <= 0.10 -> 20
        awakeRatio <= 0.15 -> 10
        else -> 0
    }
    
    return score.coerceIn(0, 100)
}

/**
 * 💪 运动数据卡片
 */
@Composable
fun ExerciseStatsCard(
    caloriesBurned: Int,
    activeMinutes: Int,
    distance: Float,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("💪 今日运动", style = MaterialTheme.typography.titleMedium)
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                ExerciseStatItem("🔥", "$caloriesBurned", "千卡")
                ExerciseStatItem("⏱️", "$activeMinutes", "分钟")
                ExerciseStatItem("📍", String.format("%.1f", distance), "公里")
            }
        }
    }
}

@Composable
private fun ExerciseStatItem(icon: String, value: String, unit: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(icon, fontSize = 24.sp)
        Text(value, style = MaterialTheme.typography.headlineSmall)
        Text(unit, fontSize = 12.sp, color = Color.Gray)
    }
}

/**
 * 💧 水分摄入追踪
 */
@Composable
fun WaterIntakeTracker(
    currentMl: Int,
    goalMl: Int = 2000,
    modifier: Modifier = Modifier
) {
    val animatedProgress = remember { Animatable(0f) }
    
    LaunchedEffect(currentMl) {
        animatedProgress.animateTo(
            targetValue = (currentMl.toFloat() / goalMl).coerceIn(0f, 1f),
            animationSpec = tween(durationMillis = 1000)
        )
    }
    
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("💧 今日饮水", style = MaterialTheme.typography.titleMedium)
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // 水杯可视化
            Box(
                contentAlignment = Alignment.BottomCenter,
                modifier = Modifier.size(100.dp, 140.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val cupWidth = size.width * 0.8f
                    val cupHeight = size.height * 0.85f
                    val cupLeft = (size.width - cupWidth) / 2
                    val cupTop = size.height - cupHeight
                    
                    // 杯子轮廓
                    drawRoundRect(
                        color = Color.LightGray,
                        topLeft = Offset(cupLeft, cupTop),
                        size = Size(cupWidth, cupHeight),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(16f),
                        style = Stroke(width = 4f)
                    )
                    
                    // 水位
                    val waterHeight = cupHeight * animatedProgress.value
                    drawRoundRect(
                        color = Color(0xFF42A5F5),
                        topLeft = Offset(cupLeft + 4f, cupTop + cupHeight - waterHeight + 4f),
                        size = Size(cupWidth - 8f, waterHeight - 8f),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f)
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "$currentMl / $goalMl ml",
                style = MaterialTheme.typography.bodyLarge
            )
            
            val percentage = ((currentMl.toFloat() / goalMl) * 100).toInt()
            Text(
                text = if (currentMl >= goalMl) "🎉 目标达成！" else "$percentage%",
                color = if (currentMl >= goalMl) Color(0xFF4CAF50) else Color.Gray,
                fontSize = 14.sp
            )
        }
    }
}

/**
 * 🏆 健康综合评分卡
 */
@Composable
fun HealthScoreCard(
    overallScore: Int,
    sleepScore: Int,
    exerciseScore: Int,
    nutritionScore: Int,
    stressScore: Int,
    modifier: Modifier = Modifier
) {
    val animatedScore = remember { Animatable(0f) }
    
    LaunchedEffect(overallScore) {
        animatedScore.animateTo(
            targetValue = overallScore.toFloat(),
            animationSpec = tween(durationMillis = 1500)
        )
    }
    
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("🏆 健康综合评分", style = MaterialTheme.typography.titleMedium)
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // 主评分环
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(160.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val strokeWidth = 16f
                    val radius = (size.minDimension - strokeWidth) / 2
                    val center = Offset(size.width / 2, size.height / 2)
                    
                    // 背景环
                    drawCircle(
                        color = Color.LightGray.copy(alpha = 0.2f),
                        radius = radius,
                        center = center,
                        style = Stroke(width = strokeWidth)
                    )
                    
                    // 分数环
                    val scoreColor = when {
                        overallScore >= 80 -> Color(0xFF4CAF50)
                        overallScore >= 60 -> Color(0xFFFF9800)
                        else -> Color(0xFFF44336)
                    }
                    
                    drawArc(
                        color = scoreColor,
                        startAngle = -90f,
                        sweepAngle = 360f * (animatedScore.value / 100f),
                        useCenter = false,
                        topLeft = Offset(center.x - radius, center.y - radius),
                        size = Size(radius * 2, radius * 2),
                        style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                    )
                }
                
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "${animatedScore.value.toInt()}",
                        style = MaterialTheme.typography.headlineLarge,
                        color = when {
                            overallScore >= 80 -> Color(0xFF4CAF50)
                            overallScore >= 60 -> Color(0xFFFF9800)
                            else -> Color(0xFFF44336)
                        }
                    )
                    Text("健康分", fontSize = 14.sp, color = Color.Gray)
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // 分项评分
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                ScoreItem("😴", "睡眠", sleepScore)
                ScoreItem("💪", "运动", exerciseScore)
                ScoreItem("🥗", "营养", nutritionScore)
                ScoreItem("🧘", "压力", stressScore)
            }
        }
    }
}

@Composable
private fun ScoreItem(icon: String, label: String, score: Int) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(icon, fontSize = 20.sp)
        Text(label, fontSize = 12.sp, color = Color.Gray)
        Text(
            text = "$score",
            fontSize = 16.sp,
            color = when {
                score >= 80 -> Color(0xFF4CAF50)
                score >= 60 -> Color(0xFFFF9800)
                else -> Color(0xFFF44336)
            }
        )
    }
}

/**
 * 📅 周期趋势对比
 */
@Composable
fun TrendComparisonCard(
    title: String,
    currentValue: Float,
    previousValue: Float,
    unit: String,
    icon: String = "📊",
    modifier: Modifier = Modifier
) {
    val change = currentValue - previousValue
    val changePercent = if (previousValue > 0) (change / previousValue * 100) else 0f
    val isPositive = change >= 0
    
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(icon, fontSize = 32.sp)
            
            Spacer(modifier = Modifier.width(12.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall)
                Text(
                    text = "${currentValue.toInt()} $unit",
                    style = MaterialTheme.typography.headlineSmall
                )
            }
            
            // 趋势指示
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = if (isPositive) "↑" else "↓",
                    fontSize = 24.sp,
                    color = if (isPositive) Color(0xFF4CAF50) else Color(0xFFF44336)
                )
                Text(
                    text = String.format("%.1f%%", kotlin.math.abs(changePercent)),
                    fontSize = 14.sp,
                    color = if (isPositive) Color(0xFF4CAF50) else Color(0xFFF44336)
                )
                Text(
                    text = "较上周",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }
        }
    }
}
