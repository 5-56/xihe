package com.example.xihe.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.xihe.ui.ThemeManager
import com.example.xihe.ui.ThemeMode
import com.example.xihe.ui.components.GlassmorphicCard
import com.example.xihe.ui.utils.rememberHapticFeedback

/**
 * 🎨 视觉主题设置 (重构优化版)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThemeSettingsScreen(
    onBack: () -> Unit = {}
) {
    val context = LocalContext.current
    val haptic = rememberHapticFeedback()
    val themeManager = remember { ThemeManager.getInstance(context) }
    val themeMode by themeManager.themeMode.collectAsState()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("视觉中枢", fontWeight = FontWeight.ExtraBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "返回", tint = MaterialTheme.colorScheme.primary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // 🤖 效果预览
            SectionHeader("实时渲染预览")
            ThemeLivePreview(themeMode)

            // 🌓 模式切换
            SectionHeader("光影模式")
            GlassmorphicCard {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ModeSelector(
                        title = "核心深色",
                        icon = "🌙",
                        isSelected = themeMode == ThemeMode.DARK,
                        onClick = { themeManager.setThemeMode(ThemeMode.DARK) }
                    )
                    ModeSelector(
                        title = "明亮模式",
                        icon = "☀️",
                        isSelected = themeMode == ThemeMode.LIGHT,
                        onClick = { themeManager.setThemeMode(ThemeMode.LIGHT) }
                    )
                    ModeSelector(
                        title = "系统同步",
                        icon = "⚙️",
                        isSelected = themeMode == ThemeMode.SYSTEM,
                        onClick = { themeManager.setThemeMode(ThemeMode.SYSTEM) }
                    )
                }
            }

            // 🎨 高级属性
            SectionHeader("核心属性")
            GlassmorphicCard {
                val usePureBlack by themeManager.usePureBlack.collectAsState()
                ThemeToggleItem(
                    icon = Icons.Default.BrightnessLow,
                    title = "AMOLED 纯黑",
                    subtitle = "关闭非活动像素，极致省电",
                    checked = usePureBlack,
                    onCheckedChange = { themeManager.setUsePureBlack(it) }
                )
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title.uppercase(),
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
        letterSpacing = 1.5.sp,
        modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
    )
}

@Composable
private fun ThemeLivePreview(mode: ThemeMode) {
    GlassmorphicCard(
        backgroundColor = Color.White.copy(alpha = 0.05f),
        borderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)
    ) {
        Column(modifier = Modifier.height(120.dp), verticalArrangement = Arrangement.Center) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary))
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Box(modifier = Modifier.width(100.dp).height(8.dp).background(Color.White.copy(alpha = 0.6f), CircleShape))
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(modifier = Modifier.width(60.dp).height(6.dp).background(Color.White.copy(alpha = 0.3f), CircleShape))
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    "预览文字：羲和系统的渲染引擎已就绪。",
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(8.dp)
                )
            }
        }
    }
}

@Composable
private fun RowScope.ModeSelector(title: String, icon: String, isSelected: Boolean, onClick: () -> Unit) {
    val haptic = rememberHapticFeedback()
    Box(
        modifier = Modifier
            .weight(1f)
            .height(80.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else Color.White.copy(alpha = 0.05f))
            .border(1.dp, if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent, RoundedCornerShape(12.dp))
            .clickable { 
                haptic.lightTap()
                onClick() 
            },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(icon, fontSize = 24.sp)
            Text(title, fontSize = 10.sp, color = if (isSelected) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.6f))
        }
    }
}

@Composable
private fun ThemeToggleItem(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    val haptic = rememberHapticFeedback()
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp)
        }
        Switch(
            checked = checked, 
            onCheckedChange = { 
                haptic.lightTap()
                onCheckedChange(it) 
            },
            colors = SwitchDefaults.colors(
                checkedThumbColor = MaterialTheme.colorScheme.primary,
                checkedTrackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)
            )
        )
    }
}