package com.example.xihe.ui.utils

import android.Manifest
import android.app.AppOpsManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Binder
import android.os.Build
import android.provider.Settings
import androidx.core.app.ActivityCompat

/**
 * 🔑 权限帮助工具
 * 用于在二次使用某功能时检测权限并引导用户一键跳转到系统设置开启。
 */
object PermissionHelper {

    enum class PermissionType {
        ACCESSIBILITY,      // 无障碍
        OVERLAY,            // 悬浮窗
        USAGE_STATS,        // 使用情况访问
        NOTIFICATION,       // 通知
        RECORD_AUDIO,       // 录音
        LOCATION_FINE,      // 精准定位
        LOCATION_COARSE     // 粗略定位
    }

    /**
     * 检查单个权限是否已授予
     */
    fun isGranted(context: Context, type: PermissionType): Boolean {
        return when (type) {
            PermissionType.ACCESSIBILITY -> isAccessibilityEnabled(context)
            PermissionType.OVERLAY -> Settings.canDrawOverlays(context)
            PermissionType.USAGE_STATS -> hasUsageAccess(context)
            PermissionType.NOTIFICATION -> {
                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.areNotificationsEnabled()
            }
            PermissionType.RECORD_AUDIO -> ActivityCompat.checkSelfPermission(
                context, Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
            PermissionType.LOCATION_FINE -> ActivityCompat.checkSelfPermission(
                context, Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
            PermissionType.LOCATION_COARSE -> ActivityCompat.checkSelfPermission(
                context, Manifest.permission.ACCESS_COARSE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    /**
     * 一键跳转到相应的系统设置页面
     */
    fun openSettings(context: Context, type: PermissionType) {
        val intent = when (type) {
            PermissionType.ACCESSIBILITY -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            PermissionType.OVERLAY -> Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            )
            PermissionType.USAGE_STATS -> Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
            PermissionType.NOTIFICATION -> Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                }
            }
            PermissionType.RECORD_AUDIO,
            PermissionType.LOCATION_FINE,
            PermissionType.LOCATION_COARSE -> Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", context.packageName, null)
            }
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    private fun isAccessibilityEnabled(context: Context): Boolean {
        val enabled = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains(context.packageName)
    }

    private fun hasUsageAccess(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Binder.getCallingUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Binder.getCallingUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }
}

