package com.example.xihe.ui.dialogs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.xihe.core.AutomationEngine
import com.example.xihe.core.ModuleCoordinator

/**
 * 🎤 语音设置对话框
 * 
 * 从 SettingsDialogs.kt 中提取
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceSettingsDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val prefs = context.getSharedPreferences("xihe_settings", android.content.Context.MODE_PRIVATE)
    
    var wakeWord by remember { mutableStateOf("羲和") }
    var enableWakeWord by remember { mutableStateOf(false) }
    var voiceSpeed by remember { mutableStateOf(1.0f) }
    var voicePitch by remember { mutableStateOf(1.0f) }
    var selectedVoiceStyle by remember { mutableStateOf("F1") }
    
    // 🎤 语音识别引擎选择
    var useOfflineRecognizer by remember { mutableStateOf(prefs.getBoolean("use_offline_recognizer", true)) }
    // 🔊 TTS 引擎选择
    var useLocalTTS by remember { mutableStateOf(prefs.getBoolean("use_local_tts", false)) }
    // 🔊 语音播报总开关
    var enableVoiceResponse by remember { mutableStateOf(prefs.getBoolean("enable_voice_response", true)) }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("🎤 语音设置", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // === 语音识别设置 ===
                Text(
                    "🎙️ 语音识别引擎",
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                
                // 识别引擎选择
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("使用离线识别 (Vosk)", color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp)
                        Text(
                            if (useOfflineRecognizer) "✅ 无需网络，完全本地运行" 
                            else "使用系统识别（需要Google服务）",
                            color = MaterialTheme.colorScheme.onSurfaceVariant, 
                            fontSize = 10.sp
                        )
                    }
                    Switch(
                        checked = useOfflineRecognizer,
                        onCheckedChange = { enabled ->
                            useOfflineRecognizer = enabled
                            prefs.edit().putBoolean("use_offline_recognizer", enabled).apply()
                            ModuleCoordinator.setRecognizerType(enabled)
                            android.widget.Toast.makeText(
                                context,
                                if (enabled) "已切换到离线识别" else "已切换到系统识别",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MaterialTheme.colorScheme.primary,
                            checkedTrackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                        )
                    )
                }
                
                // 当前状态
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            if (useOfflineRecognizer) "当前引擎: Vosk 离线识别" else "当前引擎: 系统语音识别",
                            color = MaterialTheme.colorScheme.onSurface, 
                            fontSize = 12.sp
                        )
                        Text("语言: 中文普通话", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
                        if (useOfflineRecognizer) {
                            Text("特点: 完全离线，隐私保护好", color = MaterialTheme.colorScheme.primary, fontSize = 11.sp)
                        } else {
                            Text("特点: 需要网络，准确率较高", color = MaterialTheme.colorScheme.secondary, fontSize = 11.sp)
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // === 🔊 语音播报总开关 ===
                Text(
                    "🔊 语音播报设置",
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                
                // 语音播报总开关
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("启用语音播报", color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text(
                            if (enableVoiceResponse) "✅ AI回复会使用语音播报" else "❌ AI仅文字回复，不播报",
                            color = if (enableVoiceResponse) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 10.sp
                        )
                    }
                    Switch(
                        checked = enableVoiceResponse,
                        onCheckedChange = { enabled ->
                            enableVoiceResponse = enabled
                            prefs.edit().putBoolean("enable_voice_response", enabled).apply()
                            ModuleCoordinator.setEnableTTSResponse(enabled)
                            android.widget.Toast.makeText(
                                context,
                                if (enabled) "✅ 语音播报已启用" else "❌ 语音播报已关闭",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MaterialTheme.colorScheme.primary,
                            checkedTrackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                            uncheckedThumbColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            uncheckedTrackColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f)
                        )
                    )
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // === TTS 语音合成设置 ===
                Text(
                    "🔊 语音合成引擎",
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                
                // 检测系统 TTS 状态
                var systemTTSAvailable by remember { mutableStateOf(true) }
                var systemTTSEngine by remember { mutableStateOf("检测中...") }
                
                LaunchedEffect(Unit) {
                    val tts = android.speech.tts.TextToSpeech(context) { status ->
                        systemTTSAvailable = status == android.speech.tts.TextToSpeech.SUCCESS
                        if (systemTTSAvailable) {
                            systemTTSEngine = "系统TTS已就绪"
                        } else {
                            systemTTSEngine = "系统TTS不可用"
                        }
                    }
                }
                
                // 当前 TTS 状态
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                if (useLocalTTS) "当前: 本地TTS模型" else "当前: 系统TTS",
                                color = MaterialTheme.colorScheme.onSurface, 
                                fontSize = 12.sp
                            )
                            Text(
                                if (systemTTSAvailable) "✅" else "⚠️",
                                fontSize = 14.sp
                            )
                        }
                        Text(
                            systemTTSEngine,
                            color = if (systemTTSAvailable) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary, 
                            fontSize = 11.sp
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                
                // TTS 引擎选择
                val voicePrefs = remember { context.getSharedPreferences("voice_settings", android.content.Context.MODE_PRIVATE) }
                var selectedTTSEngine by remember { 
                    mutableStateOf(voicePrefs.getString("tts_engine_type", "system") ?: "system") 
                }
                
                Text("选择TTS引擎:", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(8.dp))
                
                // 本地模型选项
                TTSEngineOption(
                    title = "🎵 本地模型",
                    description = "Supertonic ONNX，离线快速",
                    isSelected = selectedTTSEngine == "local",
                    onClick = {
                        selectedTTSEngine = "local"
                        voicePrefs.edit().putString("tts_engine_type", "local").apply()
                        ModuleCoordinator.setTTSEngine("local")
                    }
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // 系统TTS选项
                TTSEngineOption(
                    title = "📱 系统TTS",
                    description = "使用系统自带语音合成",
                    isSelected = selectedTTSEngine == "system",
                    onClick = {
                        selectedTTSEngine = "system"
                        voicePrefs.edit().putString("tts_engine_type", "system").apply()
                        ModuleCoordinator.setTTSEngine("system")
                    }
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // 语音风格选择
                Text("语音风格", color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("F1" to "女声1", "F2" to "女声2", "M1" to "男声1", "M2" to "男声2").forEach { (id, name) ->
                        FilterChip(
                            selected = selectedVoiceStyle == id,
                            onClick = { selectedVoiceStyle = id },
                            label = { Text(name, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                
                // 语速调节
                Text("语速: ${String.format("%.1f", voiceSpeed)}x", color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp)
                Slider(
                    value = voiceSpeed,
                    onValueChange = { voiceSpeed = it },
                    valueRange = 0.5f..2.0f,
                    steps = 5,
                    colors = SliderDefaults.colors(
                        thumbColor = MaterialTheme.colorScheme.primary,
                        activeTrackColor = MaterialTheme.colorScheme.primary
                    )
                )
                
                // 音调调节
                Text("音调: ${String.format("%.1f", voicePitch)}x", color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp)
                Slider(
                    value = voicePitch,
                    onValueChange = { voicePitch = it },
                    valueRange = 0.5f..2.0f,
                    steps = 5,
                    colors = SliderDefaults.colors(
                        thumbColor = MaterialTheme.colorScheme.primary,
                        activeTrackColor = MaterialTheme.colorScheme.primary
                    )
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // === 主动对话设置 ===
                Text(
                    "主动对话",
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                
                var enableProactiveChat by remember { mutableStateOf(AutomationEngine.enableProactiveChat) }
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("启用主动对话", color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp)
                        Text("羲和会主动找你聊天", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp)
                    }
                    Switch(
                        checked = enableProactiveChat,
                        onCheckedChange = { 
                            enableProactiveChat = it
                            AutomationEngine.enableProactiveChat = it
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MaterialTheme.colorScheme.primary,
                            checkedTrackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                        )
                    )
                }
                
                if (enableProactiveChat) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "💬 当你5分钟没互动，羲和会主动找你聊天哦~",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 10.sp
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text("保存", color = MaterialTheme.colorScheme.onPrimary)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("取消", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        containerColor = MaterialTheme.colorScheme.surface
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TTSEngineOption(
    title: String,
    description: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = if (isSelected) 
            MaterialTheme.colorScheme.primaryContainer 
        else 
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
        shape = RoundedCornerShape(8.dp),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(
                selected = isSelected,
                onClick = onClick
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(title, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Text(description, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
