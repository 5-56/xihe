package com.example.xihe.ui.utils

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first

/**
 * 🗂️ 首次引导偏好存储
 * 用于判断是否已经完成新手引导和权限提示。
 */
object OnboardingPreferences {

    private val Context.dataStore by preferencesDataStore(name = "xihe_onboarding_prefs")
    private val KEY_ONBOARDING_DONE = booleanPreferencesKey("onboarding_done")

    /**
     * 读取是否已完成引导
     */
    suspend fun isOnboardingDone(context: Context): Boolean {
        val prefs = context.dataStore.data.first()
        return prefs[KEY_ONBOARDING_DONE] ?: false
    }

    /**
     * 设置引导完成状态
     */
    suspend fun setOnboardingDone(context: Context, done: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_ONBOARDING_DONE] = done
        }
    }
}

