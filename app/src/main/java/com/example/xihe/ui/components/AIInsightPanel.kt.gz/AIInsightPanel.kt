package com.example.xihe.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.xihe.ui.theme.StatusColors
import kotlinx.coroutines.delay

/**
 * 🧠 AI 洞察面板
 *
 * 展示 AI 的智能化过程，而非手动配置：
 * 1. 实时思考过程 - AI 正在分析什么
 * 2. 学习到的模式 - AI 从用户行为中学到了什么
 * 3. 智能建议 - 基于上下文的推荐
 * 4. 执行洞察 - 任务执行的智能分析
 *
 * 核心理念：用户无需手动配置，只需观察 AI 如何变得更智能
 */

// ==================== 数据模型 ====================

data class AIThinkingState(
    val isThinking: Boolean = false,
    val currentThought: String = "",
    val thoughtSteps: List<ThoughtStep> = emptyList(),
    val confidence: Float = 0f
)

data class ThoughtStep(
    val id: String,
    val content: String,
    val type: ThoughtType,
    val timestamp: Long = System.currentTimeMillis()
)

enum class ThoughtType(val icon: ImageVector, val color: Color) {
    OBSERVATION(Icons.Default.Visibility, Color(0xFF2196F3)),
    ANALYSIS(Icons.Default.Analytics, Color(0xFF9C27B0)),
    DECISION(Icons.Default.Lightbulb, Color(0xFFFFEB3B)),
    ACTION(Icons.Default.PlayArrow, Color(0xFF4CAF50)),
    LEARNING(Icons.Default.School, Color(0xFFFF9800))
}

data class LearnedPattern(
    val id: String,
    val title: String,
    val description: String,
    val frequency: Int,
    val lastUsed: Long,
    val confidence: Float,
    val category: PatternCategory
)

enum class PatternCategory(val displayName: String, val icon: ImageVector, val color: Color) {
    HABIT("用户习惯", Icons.Default.Schedule, Color(0xFF2196F3)),
    PREFERENCE("偏好设置", Icons.Default.Favorite, Color(0xFFE91E63)),
    SHORTCUT("常用捷径", Icons.Default.Bolt, Color(0xFFFFEB3B)),
    CONTEXT("场景关联", Icons.Default.Place, Color(0xFF4CAF50))
}

data class AISuggestion(
    val id: String,
    val title: String,
    val description: String,
    val command: String,
    val relevance: Float,
    val reason: String,
    val icon: ImageVector = Icons.Default.AutoAwesome
)

// ==================== 主组件 ====================

/**
 * 🧠 AI 洞察面板（可展开收起）
 */
@Composable
fun AIInsightPanel(
    thinkingState: AIThinkingState,
    learnedPatterns: List<LearnedPattern>,
    suggestions: List<AISuggestion>,
    onSuggestionClick: (AISuggestion) -> Unit,
    modifier: Modifier = Modifier
) {
    var isExpanded by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf(InsightTab.THINKING) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .shadow(8.dp, RoundedCornerShape(20.dp)),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column {
            // 头部（始终显示）
            InsightHeader(
                isThinking = thinkingState.isThinking,
                currentThought = thinkingState.currentThought,
                isExpanded = isExpanded,
                onToggle = { isExpanded = !isExpanded }
            )

            // 展开内容
            AnimatedVisibility(
                visible = isExpanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column {
                    // Tab 选择器
                    InsightTabs(
                        selectedTab = selectedTab,
                        onTabSelected = { selectedTab = it },
                        hasThinking = thinkingState.thoughtSteps.isNotEmpty(),
                        patternsCount = learnedPatterns.size,
                        suggestionsCount = suggestions.size
                    )

                    // Tab 内容
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(300.dp)
                    ) {
                        when (selectedTab) {
                            InsightTab.THINKING -> ThinkingContent(thinkingState)
                            InsightTab.PATTERNS -> PatternsContent(learnedPatterns)
                            InsightTab.SUGGESTIONS -> SuggestionsContent(
                                suggestions = suggestions,
                                onSuggestionClick = onSuggestionClick
                            )
                        }
                    }
                }
            }
        }
    }
}

enum class InsightTab(val title: String, val icon: ImageVector) {
    THINKING("思考", Icons.Default.Psychology),
    PATTERNS("学习", Icons.Default.School),
    SUGGESTIONS("建议", Icons.Default.Lightbulb)
}

// ==================== 头部 ====================

@Composable
private fun InsightHeader(
    isThinking: Boolean,
    currentThought: String,
    isExpanded: Boolean,
    onToggle: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "thinking")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val rotationAngle by animateFloatAsState(
        targetValue = if (isExpanded) 180f else 0f,
        animationSpec = spring(dampingRatio = 0.6f),
        label = "rotation"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle)
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // AI 头像
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = if (isThinking) {
                            listOf(
                                MaterialTheme.colorScheme.primary.copy(alpha = pulseAlpha),
                                MaterialTheme.colorScheme.primaryContainer
                            )
                        } else {
                            listOf(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.surfaceVariant)
                        }
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Psychology,
                contentDescription = null,
                tint = if (isThinking) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(24.dp)
            )
        }

        // 状态文字
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = if (isThinking) "🧠 AI 正在思考..." else "🧠 AI 洞察",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            if (currentThought.isNotEmpty()) {
                Text(
                    text = currentThought,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            } else {
                Text(
                    text = "点击展开查看 AI 的学习成果",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // 展开/收起箭头
        Icon(
            imageVector = Icons.Default.ExpandMore,
            contentDescription = if (isExpanded) "收起" else "展开",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier
                .size(24.dp)
                .rotate(rotationAngle)
        )
    }
}

// ==================== Tab 选择器 ====================

@Composable
private fun InsightTabs(
    selectedTab: InsightTab,
    onTabSelected: (InsightTab) -> Unit,
    hasThinking: Boolean,
    patternsCount: Int,
    suggestionsCount: Int
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        InsightTab.values().forEach { tab ->
            val count = when (tab) {
                InsightTab.THINKING -> if (hasThinking) null else null
                InsightTab.PATTERNS -> if (patternsCount > 0) patternsCount else null
                InsightTab.SUGGESTIONS -> if (suggestionsCount > 0) suggestionsCount else null
            }

            InsightTabItem(
                tab = tab,
                isSelected = selectedTab == tab,
                count = count,
                onClick = { onTabSelected(tab) },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun InsightTabItem(
    tab: InsightTab,
    isSelected: Boolean,
    count: Int?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val backgroundColor by animateColorAsState(
        targetValue = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else Color.Transparent,
        label = "tabBg"
    )

    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick),
        color = backgroundColor,
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = tab.icon,
                contentDescription = null,
                tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
            )

            Spacer(modifier = Modifier.width(6.dp))

            Text(
                text = tab.title,
                fontSize = 13.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (count != null) {
                Spacer(modifier = Modifier.width(4.dp))
                Badge(
                    containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                ) {
                    Text(
                        text = count.toString(),
                        fontSize = 10.sp,
                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.surface
                    )
                }
            }
        }
    }
}

// ==================== 思考过程内容 ====================

@Composable
private fun ThinkingContent(state: AIThinkingState) {
    if (state.thoughtSteps.isEmpty()) {
        EmptyStateContent(
            icon = Icons.Default.Psychology,
            title = "AI 待机中",
            description = "当您发出指令时，这里会展示 AI 的思考过程"
        )
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(state.thoughtSteps) { step ->
                ThoughtStepItem(step = step)
            }

            // 置信度指示器
            item {
                ConfidenceIndicator(confidence = state.confidence)
            }
        }
    }
}

@Composable
private fun ThoughtStepItem(step: ThoughtStep) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.Top
    ) {
        // 类型图标
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(step.type.color.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = step.type.icon,
                contentDescription = null,
                tint = step.type.color,
                modifier = Modifier.size(18.dp)
            )
        }

        // 内容
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = step.type.name,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = step.type.color
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = step.content,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.9f),
                lineHeight = 18.sp
            )
        }
    }
}

@Composable
private fun ConfidenceIndicator(confidence: Float) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "决策置信度",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Text(
                text = "${(confidence * 100).toInt()}%",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = when {
                    confidence >= 0.8f -> StatusColors.Success
                    confidence >= 0.5f -> StatusColors.Warning
                    else -> StatusColors.Error
                }
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        LinearProgressIndicator(
            progress = { confidence },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = when {
                confidence >= 0.8f -> StatusColors.Success
                confidence >= 0.5f -> StatusColors.Warning
                else -> StatusColors.Error
            },
            trackColor = MaterialTheme.colorScheme.surfaceVariant
        )
    }
}

// ==================== 学习模式内容 ====================

@Composable
private fun PatternsContent(patterns: List<LearnedPattern>) {
    if (patterns.isEmpty()) {
        EmptyStateContent(
            icon = Icons.Default.School,
            title = "AI 正在学习",
            description = "随着使用，AI 会学习您的习惯和偏好"
        )
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 按类别分组
            PatternCategory.values().forEach { category ->
                val categoryPatterns = patterns.filter { it.category == category }
                if (categoryPatterns.isNotEmpty()) {
                    item {
                        Text(
                            text = "${category.displayName} (${categoryPatterns.size})",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = category.color,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    }

                    items(categoryPatterns) { pattern ->
                        LearnedPatternItem(pattern = pattern)
                    }
                }
            }
        }
    }
}

@Composable
private fun LearnedPatternItem(pattern: LearnedPattern) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = pattern.category.color.copy(alpha = 0.1f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 图标
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(pattern.category.color.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = pattern.category.icon,
                    contentDescription = null,
                    tint = pattern.category.color,
                    modifier = Modifier.size(22.dp)
                )
            }

            // 内容
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = pattern.title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Text(
                    text = pattern.description,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // 频率指示
            Column(
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = "${pattern.frequency}次",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = pattern.category.color
                )

                Text(
                    text = "${(pattern.confidence * 100).toInt()}%",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

// ==================== 智能建议内容 ====================

@Composable
private fun SuggestionsContent(
    suggestions: List<AISuggestion>,
    onSuggestionClick: (AISuggestion) -> Unit
) {
    if (suggestions.isEmpty()) {
        EmptyStateContent(
            icon = Icons.Default.Lightbulb,
            title = "暂无建议",
            description = "AI 会根据上下文智能推荐可能需要的操作"
        )
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(suggestions) { suggestion ->
                SuggestionItem(
                    suggestion = suggestion,
                    onClick = { onSuggestionClick(suggestion) }
                )
            }
        }
    }
}

@Composable
private fun SuggestionItem(
    suggestion: AISuggestion,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 图标
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = suggestion.icon,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // 内容
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = suggestion.title,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Text(
                        text = suggestion.description,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // 相关度
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = "${(suggestion.relevance * 100).toInt()}%",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            // 推荐理由
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(14.dp)
                )

                Text(
                    text = suggestion.reason,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

// ==================== 空状态 ====================

@Composable
private fun EmptyStateContent(
    icon: ImageVector,
    title: String,
    description: String
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = Color.Gray.copy(alpha = 0.5f),
            modifier = Modifier.size(48.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = title,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Gray,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = description,
            fontSize = 13.sp,
            color = Color.Gray.copy(alpha = 0.7f),
            textAlign = TextAlign.Center,
            lineHeight = 18.sp
        )
    }
}

// ==================== 紧凑版洞察指示器 ====================

/**
 * 🧠 紧凑版 AI 洞察指示器（适合放在顶部栏）
 */
@Composable
fun CompactAIIndicator(
    isThinking: Boolean,
    suggestionsCount: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "compact")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(600),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(
                if (isThinking) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                else MaterialTheme.colorScheme.surfaceVariant
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size((if (isThinking) 20 * pulseScale else 20f).dp)
        ) {
            Icon(
                imageVector = Icons.Default.Psychology,
                contentDescription = null,
                tint = if (isThinking) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
            )
        }

        if (isThinking) {
            Text(
                text = "思考中",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.primary
            )
        } else if (suggestionsCount > 0) {
            Badge(
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Text(
                    text = suggestionsCount.toString(),
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onPrimary
                )
            }
        }
    }
}

// ==================== 预览 ====================

@Composable
fun AIInsightPanelPreview() {
    val thinkingState = AIThinkingState(
        isThinking = true,
        currentThought = "正在分析用户意图...",
        thoughtSteps = listOf(
            ThoughtStep("1", "用户说\"帮我发微信给小明\"", ThoughtType.OBSERVATION),
            ThoughtStep("2", "识别意图：发送微信消息", ThoughtType.ANALYSIS),
            ThoughtStep("3", "需要打开微信 → 搜索联系人 → 发送消息", ThoughtType.DECISION),
            ThoughtStep("4", "开始执行任务", ThoughtType.ACTION)
        ),
        confidence = 0.92f
    )

    val patterns = listOf(
        LearnedPattern(
            id = "1",
            title = "每天早上查天气",
            description = "您通常在 7:30 左右询问天气",
            frequency = 23,
            lastUsed = System.currentTimeMillis(),
            confidence = 0.95f,
            category = PatternCategory.HABIT
        ),
        LearnedPattern(
            id = "2",
            title = "偏好简洁回复",
            description = "您喜欢简短直接的回答",
            frequency = 45,
            lastUsed = System.currentTimeMillis(),
            confidence = 0.88f,
            category = PatternCategory.PREFERENCE
        )
    )

    val suggestions = listOf(
        AISuggestion(
            id = "1",
            title = "查看今日天气",
            description = "根据您的习惯推荐",
            command = "今天天气怎么样",
            relevance = 0.95f,
            reason = "您通常这个时间会查天气"
        )
    )

    AIInsightPanel(
        thinkingState = thinkingState,
        learnedPatterns = patterns,
        suggestions = suggestions,
        onSuggestionClick = {}
    )
}
