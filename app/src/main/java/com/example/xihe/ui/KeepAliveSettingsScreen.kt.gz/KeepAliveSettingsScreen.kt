package com.example.xihe.ui

import android.os.Build
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.xihe.utils.BatteryOptimizationHelper
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

/**
 * 🛡️ 保活设置指南界面
 * 
 * 帮助用户配置应用保活设置
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KeepAliveSettingsScreen(
    onBack: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val isIgnoringBatteryOpt = remember {
        mutableStateOf(BatteryOptimizationHelper.isIgnoringBatteryOptimizations(context))
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("🛡️ 保活设置") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "返回")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 电池优化状态卡片
            BatteryOptimizationCard(
                isIgnored = isIgnoringBatteryOpt.value,
                onRequestOptimization = {
                    try {
                        BatteryOptimizationHelper.requestIgnoreBatteryOptimizations(
                            context as androidx.activity.ComponentActivity
                        )
                        // 延迟检查状态
                        scope.launch {
                            delay(1000)
                            isIgnoringBatteryOpt.value =
                                BatteryOptimizationHelper.isIgnoringBatteryOptimizations(context)
                        }
                    } catch (e: Exception) {
                        // 备选方案
                        BatteryOptimizationHelper.openBatteryOptimizationSettings(context)
                    }
                },
                onOpenSettings = {
                    BatteryOptimizationHelper.openAppDetails(context)
                }
            )
            
            // 保活指南卡片
            KeepAliveGuideCard()
            
            // 厂商特定设置卡片
            ManufacturerSpecificCard()
            
            // 当前状态
            CurrentStatusCard(isIgnoringBatteryOpt.value)
        }
    }
}

/**
 * 电池优化卡片
 */
@Composable
fun BatteryOptimizationCard(
    isIgnored: Boolean,
    onRequestOptimization: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (isIgnored) 
                MaterialTheme.colorScheme.primaryContainer 
            else 
                MaterialTheme.colorScheme.errorContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    if (isIgnored) Icons.Default.CheckCircle else Icons.Default.Warning,
                    contentDescription = null,
                    tint = if (isIgnored) 
                        MaterialTheme.colorScheme.primary 
                    else 
                        MaterialTheme.colorScheme.error
                )
                Text(
                    text = "电池优化设置",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            
            Text(
                text = if (isIgnored) {
                    "✅ 已关闭电池优化，应用可以持续后台运行"
                } else {
                    "⚠️ 电池优化未关闭，可能影响自动训练功能"
                },
                style = MaterialTheme.typography.bodyMedium
            )
            
            if (!isIgnored) {
                Button(
                    onClick = onRequestOptimization,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Settings, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("一键设置")
                }
            }
            
            OutlinedButton(
                onClick = onOpenSettings,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Settings, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("打开应用设置")
            }
        }
    }
}

/**
 * 保活指南卡片
 */
@Composable
fun KeepAliveGuideCard() {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "📚 保活设置指南",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            Divider()
            
            GuideStep(
                number = "1",
                title = "关闭电池优化",
                description = "设置 → 应用 → 羲和 → 电池\n选择「不限制」或「无限制」"
            )
            
            GuideStep(
                number = "2",
                title = "允许自启动",
                description = "设置 → 应用 → 自启动管理\n找到羲和并开启"
            )
            
            GuideStep(
                number = "3",
                title = "允许后台运行",
                description = "设置 → 应用 → 羲和 → 权限\n允许后台活动"
            )
        }
    }
}

/**
 * 指南步骤
 */
@Composable
fun GuideStep(
    number: String,
    title: String,
    description: String
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Surface(
            shape = MaterialTheme.shapes.small,
            color = MaterialTheme.colorScheme.primaryContainer,
            modifier = Modifier.size(32.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(
                    text = number,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }
        
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/**
 * 厂商特定设置卡片
 */
@Composable
fun ManufacturerSpecificCard() {
    val manufacturer = Build.MANUFACTURER.lowercase()
    val context = LocalContext.current
    val guide = BatteryOptimizationHelper.getKeepAliveGuide(manufacturer)
    
    // 只显示厂商特定部分
    val manufacturerSpecific = guide.split("📱").getOrNull(2)
    
    if (manufacturerSpecific != null) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.tertiaryContainer
            )
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "📱 ${Build.MANUFACTURER} 特别设置",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                
                Divider()
                
                Text(
                    text = manufacturerSpecific.trim(),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onTertiaryContainer
                )
            }
        }
    }
}

/**
 * 当前状态卡片
 */
@Composable
fun CurrentStatusCard(isOptimizationIgnored: Boolean) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "📊 当前状态",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            Divider()
            
            StatusItem(
                label = "电池优化",
                status = if (isOptimizationIgnored) "已关闭 ✅" else "未关闭 ⚠️",
                isGood = isOptimizationIgnored
            )
            
            StatusItem(
                label = "保活服务",
                status = "运行中 ✅",
                isGood = true
            )
            
            StatusItem(
                label = "开机自启动",
                status = "已配置 ✅",
                isGood = true
            )
        }
    }
}

/**
 * 状态项
 */
@Composable
fun StatusItem(
    label: String,
    status: String,
    isGood: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium
        )
        Text(
            text = status,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = if (isGood) 
                MaterialTheme.colorScheme.primary 
            else 
                MaterialTheme.colorScheme.error
        )
    }
}
