package com.example.xihe.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.OverlayService
import com.example.xihe.core.AutomationEngine
import com.example.xihe.core.EngineStateManager
import com.example.xihe.core.ModuleCoordinator
import com.example.xihe.core.PreferencesManager
import com.example.xihe.core.ProviderConfig
import com.example.xihe.core.ProviderRegistry
import com.example.xihe.core.TaskProgress
import com.example.xihe.core.model.ChatMessageDisplay
import com.example.xihe.core.Conversation
import com.example.xihe.core.ConversationManager
import com.example.xihe.multimodal.LocalImageAnalyzer
import com.example.xihe.ocr.DeepSeekOCRService
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 🧠 主界面 ViewModel
 *
 * 负责管理主界面的 UI 状态和业务逻辑
 * 从 MainActivity 中分离出来，遵循 MVVM 架构
 *
 * ✅ 修复：使用 AndroidViewModel + Application 避免 Context 泄漏
 */
class MainViewModel(
    application: Application
) : AndroidViewModel(application) {

    companion object {
        private const val TAG = "MainViewModel"
    }
    
    /**
     * 安全获取 Application Context
     */
    private val appContext: Application
        get() = getApplication()

    // ==================== UI 状态 ====================

    /**
     * 主界面 UI 状态
     */
    data class MainUiState(
        // 对话相关
        val messages: List<ChatMessageDisplay> = emptyList(),
        val currentInput: String = "",
        val isProcessing: Boolean = false,
        val statusText: String = "待机",

        // 任务进度
        val taskProgress: TaskProgress = TaskProgress(),
        val isPaused: Boolean = false,

        // 权限状态
        val hasAccessibilityPermission: Boolean = false,
        val hasOverlayPermission: Boolean = false,
        val hasNotificationPermission: Boolean = false,

        // 服务状态
        val isAccessibilityServiceConnected: Boolean = false,

        // 设置相关
        val selectedProviderId: String = "openai",
        val isApiConfigured: Boolean = false,

        // UI 控制
        val showSettingsMenu: Boolean = false,
        val showApiConfigDialog: Boolean = false,
        val showPermissionsDialog: Boolean = false,
        val showVoiceSettingsDialog: Boolean = false,

        // 语音相关
        val isVoiceEnabled: Boolean = true,
        val isListening: Boolean = false,

        // 图片相关
        val pendingImageUri: Uri? = null,
        val pendingFileName: String? = null,

        // 错误状态
        val errorMessage: String? = null
    )

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    // ==================== 事件流 ====================

    /**
     * 一次性 UI 事件
     */
    sealed class UiEvent {
        data class ShowToast(val message: String) : UiEvent()
        data class NavigateTo(val route: String) : UiEvent()
        object OpenAccessibilitySettings : UiEvent()
        object OpenOverlaySettings : UiEvent()
        object RequestNotificationPermission : UiEvent()
        data class ShowError(val message: String) : UiEvent()
        object ScrollToBottom : UiEvent()
    }

    private val _uiEvents = MutableSharedFlow<UiEvent>()
    val uiEvents = _uiEvents.asSharedFlow()

    // ==================== 初始化 ====================

    init {
        LogManager.d(TAG, "🚀 MainViewModel 初始化")

        // 观察 AutomationEngine 状态
        observeEngineState()

        // 检查权限和配置
        checkPermissions()
        loadConfiguration()
    }

    /**
     * 观察 AutomationEngine 状态变化
     */
    private fun observeEngineState() {
        viewModelScope.launch {
            // 观察消息列表
            EngineStateManager.messages.collect { messages ->
                _uiState.update { it.copy(messages = messages) }
            }
        }

        viewModelScope.launch {
            // 观察状态文本 (注意：EngineStateManager.status 即状态 Flow)
            EngineStateManager.status.collect { status ->
                _uiState.update {
                    it.copy(
                        statusText = status,
                        isProcessing = status != "待机" && status != "Idle"
                    )
                }
            }
        }

        viewModelScope.launch {
            // 观察任务进度
            EngineStateManager.taskProgress.collect { progress ->
                _uiState.update { it.copy(taskProgress = progress) }
            }
        }

        viewModelScope.launch {
            // 观察暂停状态
            EngineStateManager.isPaused.collect { isPaused ->
                _uiState.update { it.copy(isPaused = isPaused) }
            }
        }

        viewModelScope.launch {
            // 观察无障碍服务连接状态
            CoreAccessibilityService.isConnected.collect { isConnected ->
                _uiState.update {
                    it.copy(
                        isAccessibilityServiceConnected = isConnected,
                        hasAccessibilityPermission = isConnected
                    )
                }
            }
        }
    }

    // ==================== 权限检查 ====================

    /**
     * 检查所有权限
     */
    fun checkPermissions() {
        viewModelScope.launch {
            val hasAccessibility = CoreAccessibilityService.isConnected.value
            val hasOverlay = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Settings.canDrawOverlays(appContext)
            } else true

            _uiState.update {
                it.copy(
                    hasAccessibilityPermission = hasAccessibility,
                    hasOverlayPermission = hasOverlay,
                    isAccessibilityServiceConnected = hasAccessibility
                )
            }

            LogManager.d(TAG, "权限检查: accessibility=$hasAccessibility, overlay=$hasOverlay")
        }
    }

    /**
     * 请求无障碍权限
     */
    fun requestAccessibilityPermission() {
        viewModelScope.launch {
            _uiEvents.emit(UiEvent.OpenAccessibilitySettings)
        }
    }

    /**
     * 请求悬浮窗权限
     */
    fun requestOverlayPermission() {
        viewModelScope.launch {
            _uiEvents.emit(UiEvent.OpenOverlaySettings)
        }
    }

    // ==================== 配置管理 ====================

    /**
     * 加载配置
     */
    private fun loadConfiguration() {
        viewModelScope.launch {
            val config = PreferencesManager.getApiConfig(appContext)
            val isConfigured = config.apiKey.isNotBlank()

            _uiState.update {
                it.copy(
                    selectedProviderId = config.providerId,
                    isApiConfigured = isConfigured
                )
            }

            LogManager.d(TAG, "配置已加载: provider=${config.providerId}, configured=$isConfigured")
        }
    }

    /**
     * 更新 API 配置
     */
    fun updateApiConfig(
        providerId: String,
        baseUrl: String,
        apiKey: String,
        modelName: String
    ) {
        viewModelScope.launch {
            AutomationEngine.updateConfig(providerId, baseUrl, apiKey, modelName, appContext)

            _uiState.update {
                it.copy(
                    selectedProviderId = providerId,
                    isApiConfigured = apiKey.isNotBlank(),
                    showApiConfigDialog = false
                )
            }

            _uiEvents.emit(UiEvent.ShowToast("配置已保存"))
            LogManager.d(TAG, "API 配置已更新: provider=$providerId")
        }
    }

    // ==================== 消息处理 ====================

    /**
     * 更新输入文本
     */
    fun updateInput(text: String) {
        _uiState.update { it.copy(currentInput = text) }
    }

    /**
     * 发送消息
     */
    fun sendMessage(message: String = _uiState.value.currentInput) {
        val trimmedMessage = message.trim()
        if (trimmedMessage.isBlank()) return

        viewModelScope.launch {
            // 清空输入
            _uiState.update { it.copy(currentInput = "", isProcessing = true) }

            // 发送到引擎处理
            AutomationEngine.start(trimmedMessage, appContext)

            // 滚动到底部
            _uiEvents.emit(UiEvent.ScrollToBottom)
        }
    }

    /**
     * 发送带图片的消息
     */
    fun sendMessageWithImage(message: String, imageUri: Uri) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    currentInput = "",
                    isProcessing = true,
                    pendingImageUri = null,
                    pendingFileName = null
                )
            }

            // 添加用户消息（带图片）
            AutomationEngine.addUserMessage(
                text = message.ifBlank { "请帮我分析这张图片" },
                context = appContext,
                imageUri = imageUri.toString()
            )

            // 分析图片
            try {
                val analyzer = LocalImageAnalyzer.getInstance(appContext)
                val result = analyzer.analyzeImage(imageUri, message.ifBlank { null })

                if (result.success) {
                    AutomationEngine.addAIResponse(
                        text = result.extractedText.ifBlank { "图片分析完成" },
                        context = appContext
                    )
                } else {
                    AutomationEngine.addAIResponse(
                        text = "图片分析失败: ${result.error}",
                        context = appContext
                    )
                }
            } catch (e: Exception) {
                LogManager.e(TAG, "图片分析异常", e)
                AutomationEngine.addAIResponse(
                    text = "图片处理出错: ${e.message}",
                    context = appContext
                )
            }

            _uiState.update { it.copy(isProcessing = false) }
            _uiEvents.emit(UiEvent.ScrollToBottom)
        }
    }

    /**
     * 设置待处理的图片
     */
    fun setPendingImage(uri: Uri?, fileName: String? = null) {
        _uiState.update {
            it.copy(
                pendingImageUri = uri,
                pendingFileName = fileName
            )
        }
    }

    /**
     * 清除待处理的图片
     */
    fun clearPendingImage() {
        _uiState.update {
            it.copy(
                pendingImageUri = null,
                pendingFileName = null
            )
        }
    }

    // ==================== 任务控制 ====================

    /**
     * 停止当前任务
     */
    fun stopCurrentTask() {
        AutomationEngine.stop()
        _uiState.update { it.copy(isProcessing = false) }
    }
    
    /**
     * 🔄 重试失败的消息
     */
    fun retryMessage(messageId: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isProcessing = true) }
            AutomationEngine.retryMessage(messageId, appContext)
            _uiEvents.emit(UiEvent.ScrollToBottom)
        }
    }

    /**
     * 暂停任务
     */
    fun pauseTask() {
        AutomationEngine.pause()
    }

    /**
     * 恢复任务
     */
    fun resumeTask() {
        AutomationEngine.resume()
    }

    /**
     * 确认操作
     */
    fun confirmAction() {
        AutomationEngine.confirmAction()
    }

    /**
     * 取消操作
     */
    fun cancelAction() {
        AutomationEngine.cancelAction()
    }

    // ==================== 对话管理 ====================

    /**
     * 新建对话
     */
    fun newConversation() {
        AutomationEngine.newConversation()
        _uiState.update { it.copy(messages = emptyList()) }

        viewModelScope.launch {
            _uiEvents.emit(UiEvent.ShowToast("已创建新对话"))
        }
    }

    /**
     * 加载对话
     */
    fun loadConversation(conversation: Conversation) {
        AutomationEngine.loadConversation(conversation)
    }

    /**
     * 保存当前对话
     */
    fun saveCurrentConversation() {
        viewModelScope.launch {
            try {
                AutomationEngine.saveCurrentConversation(appContext)
                _uiEvents.emit(UiEvent.ShowToast("对话已保存"))
            } catch (e: Exception) {
                LogManager.e(TAG, "保存对话失败", e)
                _uiEvents.emit(UiEvent.ShowError("保存失败: ${e.message}"))
            }
        }
    }

    // ==================== 语音控制 ====================

    /**
     * 切换语音响应
     */
    fun toggleVoiceResponse() {
        val newState = !AutomationEngine.enableVoiceResponse
        AutomationEngine.enableVoiceResponse = newState
        _uiState.update { it.copy(isVoiceEnabled = newState) }

        viewModelScope.launch {
            _uiEvents.emit(UiEvent.ShowToast(if (newState) "语音已开启" else "语音已关闭"))
        }
    }

    /**
     * 开始语音输入
     */
    fun startVoiceInput() {
        viewModelScope.launch {
            _uiState.update { it.copy(isListening = true) }
            // 启动语音输入
        }
    }

    /**
     * 停止语音输入
     */
    fun stopVoiceInput() {
        viewModelScope.launch {
            // 停止语音输入
            _uiState.update { it.copy(isListening = false) }
        }
    }

    // ==================== UI 控制 ====================

    /**
     * 显示/隐藏设置菜单
     */
    fun toggleSettingsMenu() {
        _uiState.update { it.copy(showSettingsMenu = !it.showSettingsMenu) }
    }

    /**
     * 显示 API 配置对话框
     */
    fun showApiConfigDialog() {
        _uiState.update {
            it.copy(
                showApiConfigDialog = true,
                showSettingsMenu = false
            )
        }
    }

    /**
     * 隐藏 API 配置对话框
     */
    fun hideApiConfigDialog() {
        _uiState.update { it.copy(showApiConfigDialog = false) }
    }

    /**
     * 显示权限对话框
     */
    fun showPermissionsDialog() {
        _uiState.update {
            it.copy(
                showPermissionsDialog = true,
                showSettingsMenu = false
            )
        }
    }

    /**
     * 隐藏权限对话框
     */
    fun hidePermissionsDialog() {
        _uiState.update { it.copy(showPermissionsDialog = false) }
    }

    /**
     * 显示语音设置对话框
     */
    fun showVoiceSettingsDialog() {
        _uiState.update {
            it.copy(
                showVoiceSettingsDialog = true,
                showSettingsMenu = false
            )
        }
    }

    /**
     * 隐藏语音设置对话框
     */
    fun hideVoiceSettingsDialog() {
        _uiState.update { it.copy(showVoiceSettingsDialog = false) }
    }

    /**
     * 清除错误信息
     */
    fun clearError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    /**
     * 导航到指定页面
     */
    fun navigateTo(route: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(showSettingsMenu = false) }
            _uiEvents.emit(UiEvent.NavigateTo(route))
        }
    }

    // ==================== 服务控制 ====================

    /**
     * 启动悬浮窗服务
     */
    fun startOverlayService() {
        try {
            val intent = Intent(appContext, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                appContext.startForegroundService(intent)
            } else {
                appContext.startService(intent)
            }
            LogManager.d(TAG, "悬浮窗服务已启动")
        } catch (e: Exception) {
            LogManager.e(TAG, "启动悬浮窗服务失败", e)
        }
    }

    /**
     * 停止悬浮窗服务
     */
    fun stopOverlayService() {
        try {
            val intent = Intent(appContext, OverlayService::class.java)
            appContext.stopService(intent)
            LogManager.d(TAG, "悬浮窗服务已停止")
        } catch (e: Exception) {
            LogManager.e(TAG, "停止悬浮窗服务失败", e)
        }
    }

    // ==================== 生命周期 ====================

    override fun onCleared() {
        super.onCleared()
        LogManager.d(TAG, "MainViewModel 已销毁")
    }

    // ==================== Factory ====================

    /**
     * ✅ 修复：使用 Application 而非 Context 防止内存泄漏
     */
    class Factory(private val application: Application) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
                return MainViewModel(application) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
