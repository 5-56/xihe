package com.example.xihe.ui.components

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import com.example.xihe.ui.utils.PermissionHelper
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext

/**
 * 🔔 权限提示对话框
 * 用于在用户实际使用某功能时，提醒开启所需权限，并提供一键跳转。
 */
@Composable
fun PermissionPromptDialog(
    permissionType: PermissionHelper.PermissionType,
    onOpenSettings: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    val title = when (permissionType) {
        PermissionHelper.PermissionType.ACCESSIBILITY -> "需要开启无障碍权限"
        PermissionHelper.PermissionType.OVERLAY -> "需要开启悬浮窗权限"
        PermissionHelper.PermissionType.USAGE_STATS -> "需要开启使用情况访问"
        PermissionHelper.PermissionType.NOTIFICATION -> "需要开启通知权限"
        PermissionHelper.PermissionType.RECORD_AUDIO -> "需要开启录音权限"
        PermissionHelper.PermissionType.LOCATION_FINE,
        PermissionHelper.PermissionType.LOCATION_COARSE -> "需要开启定位权限"
    }

    val message = "请前往系统设置开启所需权限，以正常使用此功能。"

    // 如果用户在系统设置开启后返回当前界面，可自动关闭对话框
    LaunchedEffect(permissionType) {
        if (PermissionHelper.isGranted(context, permissionType)) {
            onDismiss()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(message) },
        confirmButton = {
            TextButton(onClick = onOpenSettings) {
                Text("去开启")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("稍后再说")
            }
        }
    )
}

