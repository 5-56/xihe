package com.example.xihe.ui

import android.Manifest
import android.os.Build
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.xihe.ui.components.GlassmorphicCard
import com.example.xihe.ui.theme.NeonCyan
import com.example.xihe.ui.theme.DeepSpaceBlue
import com.example.xihe.ui.theme.StatusColors
import com.example.xihe.ui.utils.rememberHapticFeedback
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.utils.PermissionHelper
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner

/**
 * 权限管理矩阵 (重构优化版)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PermissionsManagerScreen(
    onBack: () -> Unit = {}
) {
    val context = LocalContext.current
    val activity = context as? ComponentActivity
    val haptic = rememberHapticFeedback()
    val lifecycleOwner = LocalLifecycleOwner.current
    val isAccessibilityConnected by CoreAccessibilityService.isConnected.collectAsState(initial = false)
    var permissionStatus by remember { mutableStateOf(PermissionHelper.getPermissionStatus(context)) }

    val refreshPermissionStatus: () -> Unit = {
        permissionStatus = PermissionHelper.getPermissionStatus(context)
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                refreshPermissionStatus()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val settingsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        refreshPermissionStatus()
    }

    val singlePermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        refreshPermissionStatus()
    }

    val multiplePermissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        refreshPermissionStatus()
    }

    val isAccessibilityActive = isAccessibilityConnected || permissionStatus.hasAccessibilityPermission

    Scaffold(
        containerColor = DeepSpaceBlue.Primary,
        topBar = {
            TopAppBar(
                title = { Text("授权矩阵", fontWeight = FontWeight.ExtraBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "返回", tint = NeonCyan.Primary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DeepSpaceBlue.Primary,
                    titleContentColor = NeonCyan.Primary
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            SectionHeader("核心权限流")
            
            // 1. 无障碍服务
            PermissionStatusCard(
                title = "无障碍执行引擎",
                subtitle = "自动化点击、滑动及界面感知的核心动力",
                isActive = isAccessibilityActive,
                onClick = {
                    haptic.mediumTap()
                    PermissionHelper.openAccessibilitySettings(context)
                }
            )

            // 2. 悬浮窗
            val isOverlayActive = permissionStatus.hasOverlayPermission
            
            PermissionStatusCard(
                title = "全局悬浮交互",
                subtitle = "支持在其他 App 之上显示助手气泡与视觉反馈",
                isActive = isOverlayActive,
                onClick = {
                    haptic.mediumTap()
                    if (activity != null) {
                        PermissionHelper.requestOverlayPermissionWithLauncher(activity, settingsLauncher)
                    } else {
                        PermissionHelper.requestOverlayPermission(context)
                    }
                }
            )

            SectionHeader("扩展数据权限")
            GlassmorphicCard {
                PermissionToggleItem(
                    icon = Icons.Default.Mic,
                    title = "语音识别输入",
                    checked = permissionStatus.hasMicrophonePermission,
                    onCheckedChange = { shouldEnable ->
                        haptic.lightTap()
                        if (shouldEnable) {
                            if (!permissionStatus.hasMicrophonePermission) {
                                singlePermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        } else {
                            PermissionHelper.openAppSettings(context)
                        }
                    }
                )
                HorizontalDivider(color = Color.White.copy(alpha = 0.05f))
                PermissionToggleItem(
                    icon = Icons.Default.Notifications,
                    title = "通知智能监听",
                    checked = permissionStatus.hasNotificationPermission,
                    onCheckedChange = { shouldEnable ->
                        haptic.lightTap()
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            if (shouldEnable) {
                                if (!permissionStatus.hasNotificationPermission) {
                                    singlePermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                            } else {
                                PermissionHelper.openNotificationSettings(context)
                            }
                        } else {
                            PermissionHelper.openNotificationSettings(context)
                        }
                    }
                )
                HorizontalDivider(color = Color.White.copy(alpha = 0.05f))
                PermissionToggleItem(
                    icon = Icons.Default.LocationOn,
                    title = "地理位置感知",
                    checked = permissionStatus.hasLocationPermission,
                    onCheckedChange = { shouldEnable ->
                        haptic.lightTap()
                        if (shouldEnable) {
                            if (!permissionStatus.hasLocationPermission) {
                                multiplePermissionsLauncher.launch(
                                    arrayOf(
                                        Manifest.permission.ACCESS_FINE_LOCATION,
                                        Manifest.permission.ACCESS_COARSE_LOCATION
                                    )
                                )
                            }
                        } else {
                            PermissionHelper.openAppSettings(context)
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title.uppercase(),
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        color = NeonCyan.Primary.copy(alpha = 0.6f),
        letterSpacing = 1.5.sp,
        modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
    )
}

@Composable
private fun PermissionStatusCard(title: String, subtitle: String, isActive: Boolean, onClick: () -> Unit) {
    GlassmorphicCard(
        borderColor = if (isActive) NeonCyan.Primary.copy(alpha = 0.4f) else StatusColors.Error.copy(alpha = 0.4f),
        borderWidth = 1.5.dp
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(if (isActive) NeonCyan.Primary.copy(alpha = 0.1f) else StatusColors.Error.copy(alpha = 0.1f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (isActive) Icons.Default.Shield else Icons.Default.GppMaybe,
                    null,
                    tint = if (isActive) NeonCyan.Primary else StatusColors.Error
                )
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(subtitle, color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp, lineHeight = 16.sp)
            }
            Button(
                onClick = onClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isActive) Color.White.copy(alpha = 0.1f) else NeonCyan.Primary,
                    contentColor = if (isActive) Color.White else Color.Black
                ),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 12.dp)
            ) {
                Text(if (isActive) "已激活" else "去授权", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun PermissionToggleItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 12.dp)
    ) {
        Icon(icon, null, tint = NeonCyan.Primary, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(16.dp))
        Text(title, color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedThumbColor = NeonCyan.Primary, checkedTrackColor = NeonCyan.Primary.copy(alpha = 0.3f))
        )
    }
}