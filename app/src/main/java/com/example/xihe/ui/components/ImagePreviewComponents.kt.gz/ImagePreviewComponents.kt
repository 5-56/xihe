package com.example.xihe.ui.components

import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import coil.request.ImageRequest

/**
 * 📸 聊天消息中的图片缩略图
 * 点击可展开查看大图
 */
@Composable
fun ChatImageThumbnail(
    imageUri: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit = {}
) {
    val context = LocalContext.current
    
    Box(
        modifier = modifier
            .size(150.dp, 120.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF1E3A5F))
            .clickable { onClick() }
    ) {
        AsyncImage(
            model = ImageRequest.Builder(context)
                .data(Uri.parse(imageUri))
                .crossfade(true)
                .build(),
            contentDescription = "图片",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        
        // 放大图标提示
        Icon(
            Icons.Default.ZoomIn,
            contentDescription = "点击查看大图",
            tint = Color.White.copy(alpha = 0.8f),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(8.dp)
                .size(20.dp)
        )
    }
}

/**
 * 📄 聊天消息中的文件预览
 */
@Composable
fun ChatFileThumbnail(
    fileName: String,
    imageUri: String? = null,
    modifier: Modifier = Modifier,
    onClick: () -> Unit = {}
) {
    val context = LocalContext.current
    val isImage = imageUri != null && (
        fileName.endsWith(".jpg", true) ||
        fileName.endsWith(".jpeg", true) ||
        fileName.endsWith(".png", true) ||
        fileName.endsWith(".gif", true) ||
        fileName.endsWith(".webp", true)
    )
    
    if (isImage && imageUri != null) {
        ChatImageThumbnail(imageUri = imageUri, modifier = modifier, onClick = onClick)
    } else {
        // 文件预览卡片
        Card(
            modifier = modifier
                .width(200.dp)
                .clickable { onClick() },
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E3A5F)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.Description,
                    contentDescription = null,
                    tint = Color(0xFF64FFDA),
                    modifier = Modifier.size(32.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = fileName,
                        color = Color.White,
                        fontSize = 14.sp,
                        maxLines = 2
                    )
                    Text(
                        text = "点击查看",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

/**
 * 🔍 全屏图片预览对话框
 */
@Composable
fun FullScreenImageDialog(
    imageUri: String,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = true
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.95f))
                .clickable { onDismiss() }
        ) {
            // 图片（支持缩放和拖拽）
            AsyncImage(
                model = ImageRequest.Builder(context)
                    .data(Uri.parse(imageUri))
                    .crossfade(true)
                    .build(),
                contentDescription = "图片预览",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offsetX,
                        translationY = offsetY
                    )
                    .pointerInput(Unit) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            scale = (scale * zoom).coerceIn(0.5f, 4f)
                            if (scale > 1f) {
                                offsetX += pan.x
                                offsetY += pan.y
                            } else {
                                offsetX = 0f
                                offsetY = 0f
                            }
                        }
                    }
                    .clickable(enabled = false) { }  // 防止点击穿透
            )
            
            // 顶部工具栏
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .background(Color.Black.copy(alpha = 0.5f))
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "图片预览",
                    color = Color.White,
                    fontSize = 18.sp
                )
                
                Row {
                    // 缩小按钮
                    IconButton(onClick = { scale = (scale - 0.5f).coerceAtLeast(0.5f) }) {
                        Icon(Icons.Default.ZoomOut, "缩小", tint = Color.White)
                    }
                    // 放大按钮
                    IconButton(onClick = { scale = (scale + 0.5f).coerceAtMost(4f) }) {
                        Icon(Icons.Default.ZoomIn, "放大", tint = Color.White)
                    }
                    // 关闭按钮
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, "关闭", tint = Color.White)
                    }
                }
            }
            
            // 底部提示
            Text(
                text = "双指缩放 · 点击空白处关闭",
                color = Color.Gray,
                fontSize = 12.sp,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp)
            )
        }
    }
}

/**
 * 📸 带预览功能的消息图片组件
 */
@Composable
fun MessageImageWithPreview(
    imageUri: String,
    modifier: Modifier = Modifier
) {
    var showFullScreen by remember { mutableStateOf(false) }
    
    ChatImageThumbnail(
        imageUri = imageUri,
        modifier = modifier,
        onClick = { showFullScreen = true }
    )
    
    if (showFullScreen) {
        FullScreenImageDialog(
            imageUri = imageUri,
            onDismiss = { showFullScreen = false }
        )
    }
}

/**
 * 📄 带预览功能的消息文件组件
 */
@Composable
fun MessageFileWithPreview(
    fileName: String,
    fileUri: String,
    modifier: Modifier = Modifier
) {
    var showFullScreen by remember { mutableStateOf(false) }
    
    val isImage = fileName.endsWith(".jpg", true) ||
        fileName.endsWith(".jpeg", true) ||
        fileName.endsWith(".png", true) ||
        fileName.endsWith(".gif", true) ||
        fileName.endsWith(".webp", true)
    
    ChatFileThumbnail(
        fileName = fileName,
        imageUri = if (isImage) fileUri else null,
        modifier = modifier,
        onClick = { 
            if (isImage) {
                showFullScreen = true 
            }
            // TODO: 非图片文件可以用系统应用打开
        }
    )
    
    if (showFullScreen && isImage) {
        FullScreenImageDialog(
            imageUri = fileUri,
            onDismiss = { showFullScreen = false }
        )
    }
}
