package com.example.xihe.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.xihe.ai.IntentFeedbackSystem

/**
 * 🎯 意图理解打分弹窗（简化版）
 * 
 * 功能：
 * 1. 任务/对话结束后自动弹出
 * 2. 简单的好👍/坏👎选择
 * 3. 可在设置中关闭
 */
@Composable
fun IntentFeedbackDialog(
    onDismiss: () -> Unit
) {
    val pendingFeedback by IntentFeedbackSystem.pendingFeedback.collectAsState()
    val showUI by IntentFeedbackSystem.showFeedbackUI.collectAsState()
    val feedbackEnabled by IntentFeedbackSystem.feedbackEnabled.collectAsState()
    
    var showCorrectIntentOptions by remember { mutableStateOf(false) }
    var selectedCorrectIntent by remember { mutableStateOf("") }
    
    // 重置状态
    LaunchedEffect(pendingFeedback?.id) {
        showCorrectIntentOptions = false
        selectedCorrectIntent = ""
    }
    
    AnimatedVisibility(
        visible = showUI && pendingFeedback != null && feedbackEnabled,
        enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
        exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
    ) {
        val record = pendingFeedback ?: return@AnimatedVisibility
        
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF1A2332)
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // 标题栏
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🎯 我理解对了吗？",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    
                    IconButton(
                        onClick = {
                            IntentFeedbackSystem.skipFeedback()
                            onDismiss()
                        },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            Icons.Default.Close,
                            contentDescription = "关闭",
                            tint = Color.Gray,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // 好/坏选择按钮
                if (!showCorrectIntentOptions) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterHorizontally)
                    ) {
                        // 👎 不好
                        Button(
                            onClick = { showCorrectIntentOptions = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFE57373)
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                Icons.Default.ThumbDown,
                                contentDescription = "不好",
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("理解错了", fontSize = 16.sp)
                        }
                        
                        // 👍 好
                        Button(
                            onClick = {
                                IntentFeedbackSystem.submitFeedback(score = 5)
                                onDismiss()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF81C784)
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                Icons.Default.ThumbUp,
                                contentDescription = "好",
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("理解对了", fontSize = 16.sp)
                        }
                    }
                } else {
                    // 显示正确意图选择
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "你想让我做什么？",
                            fontSize = 14.sp,
                            color = Color(0xFFB0BEC5)
                        )
                        
                        Spacer(modifier = Modifier.height(12.dp))
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            CorrectIntentChip(
                                text = "💬 聊天",
                                selected = selectedCorrectIntent == "chat",
                                onClick = { selectedCorrectIntent = "chat" },
                                modifier = Modifier.weight(1f)
                            )
                            CorrectIntentChip(
                                text = "🔧 任务",
                                selected = selectedCorrectIntent == "task",
                                onClick = { selectedCorrectIntent = "task" },
                                modifier = Modifier.weight(1f)
                            )
                            CorrectIntentChip(
                                text = "🔍 查询",
                                selected = selectedCorrectIntent == "query",
                                onClick = { selectedCorrectIntent = "query" },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedButton(
                                onClick = { showCorrectIntentOptions = false },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = Color.Gray
                                )
                            ) {
                                Text("返回")
                            }
                            
                            Button(
                                onClick = {
                                    IntentFeedbackSystem.submitFeedback(
                                        score = 1,
                                        correctIntent = selectedCorrectIntent.takeIf { it.isNotBlank() }
                                    )
                                    onDismiss()
                                },
                                enabled = selectedCorrectIntent.isNotBlank(),
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF64B5F6)
                                )
                            ) {
                                Text("提交")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CorrectIntentChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick),
        color = if (selected) Color(0xFF64B5F6) else Color(0xFF37474F)
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            fontSize = 14.sp,
            color = Color.White,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}
