package com.example.xihe.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.xihe.core.EngineStateManager
import com.example.xihe.core.Conversation
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ChatStream(modifier: Modifier = Modifier) {
    val messages by EngineStateManager.messages.collectAsStateWithLifecycle()
    var showFullScreenImage by remember { mutableStateOf<String?>(null) }
    
    LazyColumn(modifier = modifier.padding(16.dp), reverseLayout = false) {
        item {
            // 使用 AnimatedMessageBubble 组件（来自 AnimatedMessageBubble.kt）
            AnimatedMessageBubble(
                message = "主人好呀！我是羲和，您的专属 AI 小助手！随时准备为您服务哦~ ✨ (开心地转圈圈)",
                isUser = false,
                showTypingEffect = true
            )
        }
        
        items(messages) { msg ->
            // 使用 AnimatedMessageBubble 组件（支持图片显示和思考内容）
            AnimatedMessageBubble(
                message = msg.content,
                isUser = msg.isUser,
                showTypingEffect = !msg.isUser,
                imageUri = msg.imageUri,
                onImageClick = { uri -> showFullScreenImage = uri },
                thinkingContent = msg.thinkingContent  // 🧠 传递思考内容
            )
            if (msg.action != null) {
                ActionCard(status = "已执行", step = msg.action)
            }
        }
    }
    
    // 全屏图片预览
    showFullScreenImage?.let { imageUri ->
        FullScreenImageDialog(
            imageUri = imageUri,
            onDismiss = { showFullScreenImage = null }
        )
    }
}

@Composable
fun ChatBubble(text: String, isUser: Boolean) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Surface(
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 0.dp,
                bottomEnd = if (isUser) 0.dp else 16.dp
            ),
            color = if (isUser) Color(0xFF64FFDA) else Color(0xFF112240),
            modifier = Modifier
                .padding(vertical = 4.dp)
                .widthIn(max = 300.dp)
        ) {
            Text(
                text = text,
                modifier = Modifier.padding(12.dp),
                color = if (isUser) Color.Black else Color.White
            )
        }
    }
}

@Composable
fun ActionCard(status: String, step: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF233554))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = status, color = Color(0xFF64FFDA), fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = step, color = Color.White)
        }
    }
}

@Composable
fun ConversationHistoryItem(
    conversation: Conversation,
    onLoad: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val dateFormat = SimpleDateFormat("MM月dd日 HH:mm", Locale.CHINA)
    val timeStr = dateFormat.format(Date(conversation.timestamp))
    
    Surface(
        onClick = onLoad,
        color = Color.Transparent,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(Color(0xFF64FFDA).copy(alpha = 0.1f), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Outlined.ChatBubbleOutline, 
                    contentDescription = null, 
                    tint = Color(0xFF64FFDA), 
                    modifier = Modifier.size(20.dp)
                )
            }
            
            Spacer(modifier = Modifier.width(12.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    conversation.title, 
                    color = Color.White, 
                    fontSize = 15.sp, 
                    maxLines = 1,
                    fontWeight = FontWeight.Medium,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    timeStr, 
                    color = Color.Gray, 
                    fontSize = 11.sp
                )
            }
            
            // 🚀 优化：增加按钮间距和点击感
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(
                    onClick = onEdit, 
                    modifier = Modifier.size(40.dp)
                ) {
                    Icon(
                        Icons.Default.Edit, 
                        contentDescription = "编辑", 
                        tint = Color.Gray.copy(alpha = 0.6f), 
                        modifier = Modifier.size(20.dp)
                    )
                }
                IconButton(
                    onClick = onDelete, 
                    modifier = Modifier.size(40.dp)
                ) {
                    Icon(
                        Icons.Outlined.Delete, 
                        contentDescription = "删除", 
                        tint = Color.Red.copy(alpha = 0.6f), 
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditConversationTitleDialog(
    conversation: Conversation,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var title by remember { mutableStateOf(conversation.title) }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("修改对话标题", color = Color.White) },
        text = {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedContainerColor = Color(0xFF112240),
                    unfocusedContainerColor = Color(0xFF112240)
                )
            )
        },
        confirmButton = {
            Button(onClick = { onSave(title) }) {
                Text("保存")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("取消")
            }
        },
        containerColor = Color(0xFF112240)
    )
}
