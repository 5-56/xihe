package com.example.xihe.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.os.Build
import com.example.xihe.core.EnhancedAutomationEngine
import com.example.xihe.core.ModuleCoordinator
import com.example.xihe.ui.components.PermissionPromptDialog
import com.example.xihe.ui.utils.PermissionHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * 🎤 浮动语音按钮
 * 提供快速语音输入功能
 */
@Composable
fun FloatingVoiceButton(
    modifier: Modifier = Modifier,
    isExpanded: Boolean = false,
    onVoiceClick: () -> Unit = {},
    onTextModeClick: () -> Unit = {},
    onFeaturesPanelClick: () -> Unit = {}
) {
    var isListening by remember { mutableStateOf(false) }
    var isRealTimeDialogue by remember { mutableStateOf(false) }
    var voiceText by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var pendingPermission by remember { mutableStateOf<PermissionHelper.PermissionType?>(null) }
    
    // 动画
    val scale by animateFloatAsState(
        targetValue = if (isListening) 1.2f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        )
    )
    
    val rippleAlpha by animateFloatAsState(
        targetValue = if (isListening) 0.3f else 0f,
        animationSpec = tween(600)
    )
    
    Box(
        modifier = modifier
            .padding(16.dp),
        contentAlignment = Alignment.BottomEnd
    ) {
        // 展开的快捷操作
        AnimatedVisibility(
            visible = isExpanded && !isListening,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(bottom = 72.dp)
            ) {
                SmallFloatingActionButton(
                    onClick = {
                        if (!PermissionHelper.isGranted(context, PermissionHelper.PermissionType.RECORD_AUDIO)) {
                            pendingPermission = PermissionHelper.PermissionType.RECORD_AUDIO
                            return@SmallFloatingActionButton
                        }

                        if (!ModuleCoordinator.isModuleAvailable("Voice")) {
                            return@SmallFloatingActionButton
                        }

                        val enable = !isRealTimeDialogue
                        isRealTimeDialogue = enable
                        isListening = enable
                        voiceText = ""

                        if (enable) {
                            onVoiceClick()
                            ModuleCoordinator.startContinuousVoiceRecognition()
                        } else {
                            ModuleCoordinator.stopContinuousVoiceRecognition()
                        }
                    },
                    containerColor = if (isRealTimeDialogue) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = if (isRealTimeDialogue) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary
                ) {
                    Icon(
                        if (isRealTimeDialogue) Icons.Default.StopCircle else Icons.Default.RecordVoiceOver,
                        contentDescription = if (isRealTimeDialogue) "关闭实时对话" else "开启实时对话",
                        modifier = Modifier.size(20.dp)
                    )
                }

                SmallFloatingActionButton(
                    onClick = onFeaturesPanelClick,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = MaterialTheme.colorScheme.primary
                ) {
                    Icon(
                        Icons.Default.Dashboard,
                        contentDescription = "功能面板",
                        modifier = Modifier.size(20.dp)
                    )
                }
                
                // 文字输入按钮
                SmallFloatingActionButton(
                    onClick = onTextModeClick,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = MaterialTheme.colorScheme.primary
                ) {
                    Icon(
                        Icons.Default.Keyboard,
                        contentDescription = "文字输入",
                        modifier = Modifier.size(20.dp)
                    )
                }
                
                // 学习模式按钮
                SmallFloatingActionButton(
                    onClick = {
                        EnhancedAutomationEngine.setExecutionMode(
                            EnhancedAutomationEngine.ExecutionMode.LEARNING
                        )
                    },
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = MaterialTheme.colorScheme.primary
                ) {
                    Icon(
                        Icons.Default.School,
                        contentDescription = "学习模式",
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
        
        // 语音波纹效果
        if (isListening) {
            repeat(3) { index ->
                Box(
                    modifier = Modifier
                        .size(56.dp + (index * 20).dp)
                        .clip(CircleShape)
                        .background(
                            MaterialTheme.colorScheme.primary.copy(
                                alpha = rippleAlpha * (1f - index * 0.3f)
                            )
                        )
                )
            }
        }
        
        // 主语音按钮
        FloatingActionButton(
            onClick = {
                if (isListening) {
                    // 停止监听
                    isListening = false

                    if (ModuleCoordinator.isModuleAvailable("Voice")) {
                        if (isRealTimeDialogue) {
                            isRealTimeDialogue = false
                            ModuleCoordinator.stopContinuousVoiceRecognition()
                        } else {
                            ModuleCoordinator.stopVoiceRecognition(disableContinuous = false)
                        }
                    }
                } else {
                    // 权限检查：录音
                    if (PermissionHelper.isGranted(context, PermissionHelper.PermissionType.RECORD_AUDIO)) {
                        // 开始监听
                        isListening = true
                        onVoiceClick()
                        
                        // 启动语音识别
                        if (ModuleCoordinator.isModuleAvailable("Voice")) {
                            ModuleCoordinator.startVoiceRecognition { recognizedText ->
                                voiceText = recognizedText
                                isListening = false
                                isRealTimeDialogue = false
                                
                                // 处理识别结果
                                scope.launch {
                                    EnhancedAutomationEngine.processUserInput(recognizedText)
                                }
                            }
                        } else {
                            // 如果语音模块不可用，使用原始方式
                            EnhancedAutomationEngine.startVoiceInput()
                            
                            // 模拟3秒后自动停止
                            scope.launch {
                                delay(3000)
                                isListening = false
                            }
                        }
                    } else {
                        pendingPermission = PermissionHelper.PermissionType.RECORD_AUDIO
                    }
                }
            },
            containerColor = if (isListening) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
            modifier = Modifier
                .size(56.dp)
                .scale(scale)
                .shadow(
                    elevation = if (isListening) 12.dp else 6.dp,
                    shape = CircleShape
                )
        ) {
            Icon(
                if (isListening) Icons.Default.Stop else Icons.Default.Mic,
                contentDescription = if (isListening) "停止录音" else "开始录音",
                tint = if (isListening) MaterialTheme.colorScheme.onError else MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(28.dp)
            )
        }
        
        // 显示识别的文字
        AnimatedVisibility(
            visible = voiceText.isNotEmpty(),
            enter = slideInVertically() + fadeIn(),
            exit = slideOutVertically() + fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 80.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                ),
                shape = MaterialTheme.shapes.medium
            ) {
                Text(
                    text = voiceText,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(12.dp),
                    fontSize = 14.sp
                )
            }
        }
    }

    // 录音权限提示
    pendingPermission?.let { perm ->
        PermissionPromptDialog(
            permissionType = perm,
            onOpenSettings = {
                PermissionHelper.openSettings(context, perm)
                pendingPermission = null
            },
            onDismiss = { pendingPermission = null }
        )
    }
}

/**
 * 🎯 快捷命令浮动按钮
 * 提供常用命令的快速访问
 */
@Composable
fun QuickCommandButton(
    modifier: Modifier = Modifier
) {
    var showCommands by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var pendingPermission by remember { mutableStateOf<PermissionHelper.PermissionType?>(null) }
    
    // 预定义的快捷命令
    val quickCommands = listOf(
        QuickCommand("截图", Icons.Default.Screenshot) {
            scope.launch {
                EnhancedAutomationEngine.processUserInput("请截图")
            }
        },
        QuickCommand("返回", Icons.Default.ArrowBack) {
            scope.launch {
                EnhancedAutomationEngine.processUserInput("返回上一页")
            }
        },
        QuickCommand("主页", Icons.Default.Home) {
            scope.launch {
                EnhancedAutomationEngine.processUserInput("回到主页")
            }
        },
        QuickCommand("分享", Icons.Default.Share) {
            scope.launch {
                EnhancedAutomationEngine.processUserInput("分享当前内容")
            }
        }
    )
    
    Box(
        modifier = modifier.padding(16.dp),
        contentAlignment = Alignment.BottomStart
    ) {
        // 命令列表
        AnimatedVisibility(
            visible = showCommands,
            enter = expandVertically(expandFrom = Alignment.Bottom) + fadeIn(),
            exit = shrinkVertically(shrinkTowards = Alignment.Bottom) + fadeOut()
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(bottom = 72.dp)
            ) {
        quickCommands.forEach { command ->
                    SmallFloatingActionButton(
                        onClick = {
                    // 自动化命令需要无障碍 & 悬浮窗
                    when {
                        !PermissionHelper.isGranted(context, PermissionHelper.PermissionType.ACCESSIBILITY) -> {
                            pendingPermission = PermissionHelper.PermissionType.ACCESSIBILITY
                        }
                        Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                            !PermissionHelper.isGranted(context, PermissionHelper.PermissionType.OVERLAY) -> {
                            pendingPermission = PermissionHelper.PermissionType.OVERLAY
                        }
                        else -> {
                            command.action()
                            showCommands = false
                        }
                    }
                        },
                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = MaterialTheme.colorScheme.primary
                    ) {
                        Icon(
                            command.icon,
                            contentDescription = command.name,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
        
        // 主按钮
        SmallFloatingActionButton(
            onClick = { showCommands = !showCommands },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary
        ) {
            Icon(
                if (showCommands) Icons.Default.Close else Icons.Default.FlashOn,
                contentDescription = "快捷命令",
                modifier = Modifier.size(20.dp)
            )
        }
    }

    // 权限提示（无障碍/悬浮窗）
    pendingPermission?.let { perm ->
        PermissionPromptDialog(
            permissionType = perm,
            onOpenSettings = {
                PermissionHelper.openSettings(context, perm)
                pendingPermission = null
            },
            onDismiss = { pendingPermission = null }
        )
    }
}

/**
 * 快捷命令数据类
 */
private data class QuickCommand(
    val name: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val action: () -> Unit
)

/**
 * 🔊 语音状态指示器
 * 显示语音识别状态
 */
@Composable
fun VoiceStatusIndicator(
    isListening: Boolean,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = isListening,
        enter = fadeIn() + slideInVertically(),
        exit = fadeOut() + slideOutVertically(),
        modifier = modifier
    ) {
        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.95f)
            ),
            shape = MaterialTheme.shapes.large,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 动画波形
                repeat(5) { index ->
                    val animatedHeight by animateFloatAsState(
                        targetValue = if (isListening) {
                            (20 + kotlin.random.Random.nextInt(40)).dp.value
                        } else 20f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(
                                durationMillis = 300 + index * 100,
                                easing = LinearEasing
                            ),
                            repeatMode = RepeatMode.Reverse
                        )
                    )
                    
                    Box(
                        modifier = Modifier
                            .width(4.dp)
                            .height(animatedHeight.dp)
                            .background(
                                MaterialTheme.colorScheme.primary,
                                shape = MaterialTheme.shapes.small
                            )
                    )
                    
                    if (index < 4) {
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                }
                
                Spacer(modifier = Modifier.width(16.dp))
                
                Text(
                    "正在聆听...",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 14.sp
                )
            }
        }
    }
}
