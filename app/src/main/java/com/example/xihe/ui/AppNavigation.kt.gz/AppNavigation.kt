package com.example.xihe.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Stop
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.xihe.ui.components.EnhancedChatInterface
import com.example.xihe.ui.screens.PersonalitySettingsScreen
import com.example.xihe.ui.screens.PrivacySettingsScreen
import com.example.xihe.ui.screens.ThemeSettingsScreen
import com.example.xihe.ui.utils.rememberHapticFeedback
import com.example.xihe.OverlayService
import android.content.Intent
import android.os.Build

/**
 * Main Navigation Graph for the App
 */
@Composable
fun AppNavigation(
    navController: NavHostController,
    paddingValues: PaddingValues
) {
    val context = LocalContext.current
    val haptic = rememberHapticFeedback()

    // Dialog States
    var showVoiceSettings by remember { mutableStateOf(false) }
    var showTools by remember { mutableStateOf(false) }
    var showExperimental by remember { mutableStateOf(false) }

    // 图片选择器
    val imagePickerLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        uri?.let {
            // 将选择的图片通知引擎
            com.example.xihe.core.AutomationEngine.setAttachedImage(it.toString())
            com.example.xihe.utils.LogManager.d("AppNavigation", "已选择图片: $it")
        }
    }

    // We wrap NavHost in a Box to allow Dialogs to be shown on top
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(paddingValues)
            .background(MaterialTheme.colorScheme.background)
    ) {
        NavHost(
            navController = navController,
            startDestination = "chat"
        ) {
            // Chat Screen
            composable("chat") {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background)
                ) {
                    EnhancedChatInterface(
                        modifier = Modifier.fillMaxSize(),
                        onSendMessage = { message ->
                            com.example.xihe.core.AutomationEngine.start(message, context)
                        },
                        onVoiceInput = {
                            com.example.xihe.core.ModuleCoordinator.startVoiceRecognition { result ->
                                com.example.xihe.core.AutomationEngine.start(result, context)
                            }
                        },
                        onImagePick = {
                            imagePickerLauncher.launch(
                                androidx.activity.result.PickVisualMediaRequest(
                                    androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia.ImageOnly
                                )
                            )
                        },
                        onStopTask = {
                            com.example.xihe.core.AutomationEngine.stop()
                        },
                        onRetryMessage = { messageId ->
                            com.example.xihe.core.AutomationEngine.retryMessage(messageId, context)
                        }
                    )

                    val isSpeaking by com.example.xihe.core.ModuleCoordinator.isSpeakingFlow.collectAsStateWithLifecycle()

                    if (isSpeaking) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(bottom = 80.dp, end = 16.dp)
                        ) {
                            FloatingActionButton(
                                onClick = {
                                    haptic.lightTap()
                                    com.example.xihe.core.ModuleCoordinator.stopSpeaking()
                                    android.widget.Toast.makeText(
                                        context,
                                        " 已停止语音播报",
                                        android.widget.Toast.LENGTH_SHORT
                                    ).show()
                                },
                                containerColor = MaterialTheme.colorScheme.error,
                                contentColor = MaterialTheme.colorScheme.onError,
                                modifier = Modifier.size(56.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Stop,
                                    contentDescription = "停止播报",
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Training Hub
            composable("training_hub") {
                TrainingHub(
                    navController = navController,
                    onBack = {
                        navController.navigate("chat") {
                            popUpTo("chat") { inclusive = true }
                        }
                    }
                )
            }

            // Settings Screen (New Independent Screen)
            composable("settings") {
                SettingsScreen(
                    onNavigateToAIConfig = { navController.navigate("api_config") },
                    onNavigateToPermissions = { navController.navigate("permissions_manager") },
                    onNavigateToPersonality = { navController.navigate("personality_settings") },
                    onNavigateToPrivacy = { navController.navigate("privacy_settings") },
                    onNavigateToVoiceSettings = { showVoiceSettings = true },
                    onNavigateToTools = { showTools = true },
                    onNavigateToExperimental = { showExperimental = true },
                    onNavigateToThemeSettings = { navController.navigate("theme_settings") },
                    onStartOverlay = {
                        val intent = Intent(context, OverlayService::class.java)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            context.startForegroundService(intent)
                        } else {
                            context.startService(intent)
                        }
                    },
                    onBack = {
                        navController.navigate("chat") {
                            popUpTo("chat") { inclusive = true }
                        }
                    }
                )
            }

            // Sub-screens
            composable("training_control") {
                TrainingControlScreen(
                    onBack = { navController.popBackStack() },
                    onManageData = { navController.navigate("training_data_manager") },
                    onKeepAliveSettings = { navController.navigate("keep_alive_settings") }
                )
            }
            composable("training_data_manager") {
                TrainingDataManagerScreen(
                    onBack = { navController.popBackStack() }
                )
            }
            composable("keep_alive_settings") {
                KeepAliveSettingsScreen(
                    onBack = { navController.popBackStack() }
                )
            }
            composable("custom_data") {
                CustomDataScreen(
                    onBack = { navController.popBackStack() }
                )
            }
            composable("training_monitor") {
                TrainingMonitorScreen(
                    onBack = { navController.popBackStack() }
                )
            }
            composable("data_management") {
                DataManagementScreen(
                    onBack = { navController.popBackStack() }
                )
            }
            composable("training_settings") {
                TrainingSettingsScreen(
                    onBack = { navController.popBackStack() }
                )
            }
            composable("api_config") {
                ApiConfigScreen(
                    onBack = { navController.popBackStack() }
                )
            }
            composable("permissions_manager") {
                PermissionsManagerScreen(
                    onBack = { navController.popBackStack() }
                )
            }
            composable("personality_settings") {
                PersonalitySettingsScreen(
                    onBack = { navController.popBackStack() }
                )
            }
            composable("privacy_settings") {
                PrivacySettingsScreen(
                    onBackClick = { navController.popBackStack() }
                )
            }

            // 主题设置
            composable("theme_settings") {
                ThemeSettingsScreen(
                    onBack = { navController.popBackStack() }
                )
            }

            // 数据清洗工具
            composable("data_cleaner") {
                DataCleanerScreen(
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // API训练监控
            composable("api_monitor") {
                APIMonitorSettingsScreen(
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // 智能脚本库
            composable("script_library") {
                com.example.xihe.ui.screens.ScriptLibraryScreen(
                    onBack = { navController.popBackStack() },
                    onEditScript = { id -> navController.navigate("script_editor/$id") }
                )
            }

            // 脚本编辑器
            composable("script_editor/{scriptId}") { backStackEntry ->
                val scriptId = backStackEntry.arguments?.getString("scriptId") ?: ""
                com.example.xihe.ui.screens.ScriptEditorScreen(
                    scriptId = scriptId,
                    onBack = { navController.popBackStack() },
                    onSave = { navController.popBackStack() }
                )
            }

            // 可视化任务编辑器
            composable("visual_task_editor") {
                com.example.xihe.ui.screens.VisualTaskEditor(
                    onBack = { navController.popBackStack() }
                )
            }
        }

        // Global Dialogs
        if (showVoiceSettings) {
            VoiceSettingsDialog(onDismiss = { showVoiceSettings = false })
        }
        if (showTools) {
            com.example.xihe.ui.dialogs.ToolsAndPluginsDialog(onDismiss = { showTools = false })
        }
        if (showExperimental) {
            com.example.xihe.ui.dialogs.ExperimentalFeaturesDialog(onDismiss = { showExperimental = false })
        }
    }
}
