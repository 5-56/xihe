package com.example.xihe.ui.animation

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.graphicsLayer

/**
 * 💫 动画扩展函数
 * 提供便捷的Modifier扩展，快速添加动画效果
 */

/**
 * 点击缩放效果
 * 点击时按钮会缩小，释放时恢复
 */
fun Modifier.clickableWithScale(
    enabled: Boolean = true,
    scaleDown: Float = AnimationValues.ScalePressed,
    onClick: () -> Unit
) = composed {
    val interactionSource = remember { MutableInteractionSource() }
    var isPressed by remember { mutableStateOf(false) }
    
    val scale by animateFloatAsState(
        targetValue = if (isPressed) scaleDown else AnimationValues.ScaleNormal,
        animationSpec = AnimationSpecs.bouncy,
        label = "clickScale"
    )
    
    this
        .scale(scale)
        .clickable(
            interactionSource = interactionSource,
            indication = null,
            enabled = enabled
        ) {
            onClick()
        }
}

/**
 * 脉冲呼吸效果
 * 持续的缩放动画，用于吸引注意力
 */
fun Modifier.pulseEffect(
    minScale: Float = 0.95f,
    maxScale: Float = 1.05f,
    durationMillis: Int = 1000
) = composed {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    
    val scale by infiniteTransition.animateFloat(
        initialValue = minScale,
        targetValue = maxScale,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )
    
    this.scale(scale)
}

/**
 * 悬浮效果
 * 鼠标悬停或触摸时轻微上浮
 */
fun Modifier.hoverEffect(
    hoverScale: Float = 1.05f,
    hoverTranslationY: Float = -4f
) = composed {
    var isHovered by remember { mutableStateOf(false) }
    
    val scale by animateFloatAsState(
        targetValue = if (isHovered) hoverScale else 1f,
        animationSpec = AnimationSpecs.mediumBouncy,
        label = "hoverScale"
    )
    
    val translationY by animateFloatAsState(
        targetValue = if (isHovered) hoverTranslationY else 0f,
        animationSpec = AnimationSpecs.mediumBouncy,
        label = "hoverTranslation"
    )
    
    this.graphicsLayer {
        scaleX = scale
        scaleY = scale
        this.translationY = translationY
    }
}

/**
 * 摇晃效果
 * 用于错误提示或引起注意
 */
fun Modifier.shakeEffect(
    trigger: Boolean,
    onShakeComplete: () -> Unit = {}
) = composed {
    var offsetX by remember { mutableStateOf(0f) }
    
    LaunchedEffect(trigger) {
        if (trigger) {
            // 摇晃动画序列
            val shakeValues = listOf(0f, -10f, 10f, -10f, 10f, -5f, 5f, 0f)
            shakeValues.forEach { value ->
                offsetX = value
                kotlinx.coroutines.delay(50)
            }
            onShakeComplete()
        }
    }
    
    this.graphicsLayer {
        translationX = offsetX
    }
}

/**
 * 旋转效果
 * 持续旋转动画
 */
fun Modifier.rotateEffect(
    durationMillis: Int = 1000
) = composed {
    val infiniteTransition = rememberInfiniteTransition(label = "rotate")
    
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )
    
    this.graphicsLayer {
        rotationZ = rotation
    }
}

/**
 * 闪烁效果
 * 透明度变化动画
 */
fun Modifier.blinkEffect(
    minAlpha: Float = 0.3f,
    maxAlpha: Float = 1f,
    durationMillis: Int = 500
) = composed {
    val infiniteTransition = rememberInfiniteTransition(label = "blink")
    
    val alpha by infiniteTransition.animateFloat(
        initialValue = minAlpha,
        targetValue = maxAlpha,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "blinkAlpha"
    )
    
    this.graphicsLayer {
        this.alpha = alpha
    }
}

/**
 * 波纹扩散效果
 * 从中心向外扩散的动画
 */
@Composable
fun rememberRippleAnimation(
    trigger: Boolean
): Float {
    val scale = remember { Animatable(1f) }
    
    LaunchedEffect(trigger) {
        if (trigger) {
            scale.animateTo(
                targetValue = 1.5f,
                animationSpec = tween(
                    durationMillis = AnimationDurations.Slow,
                    easing = FastOutSlowInEasing
                )
            )
            scale.snapTo(1f)
        }
    }
    
    return scale.value
}
