package com.example.xihe.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.xihe.ui.animation.AnimationSpecs

/**
 * 💓 脉冲按钮组件
 * 带有呼吸动画效果的按钮，用于吸引注意力
 */
@Composable
fun PulsingButton(
    onClick: () -> Unit,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    containerColor: Color = Color.Unspecified,
    contentColor: Color = Color.Unspecified,
    size: Dp = 56.dp,
    pulseEnabled: Boolean = true
) {
    val resolvedContainerColor = if (containerColor != Color.Unspecified) containerColor else MaterialTheme.colorScheme.primary
    val resolvedContentColor = if (contentColor != Color.Unspecified) contentColor else MaterialTheme.colorScheme.onPrimary

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (pulseEnabled) 1.1f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 1000,
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )
    
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.7f,
        targetValue = if (pulseEnabled) 1f else 0.7f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 1000,
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )
    
    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        // 外层光晕
        if (pulseEnabled) {
            Box(
                modifier = Modifier
                    .size(size * scale)
                    .clip(CircleShape)
                    .background(resolvedContainerColor.copy(alpha = alpha * 0.3f))
            )
        }
        
        // 主按钮
        FloatingActionButton(
            onClick = onClick,
            containerColor = resolvedContainerColor,
            contentColor = resolvedContentColor,
            modifier = Modifier
                .size(size)
                .scale(if (pulseEnabled) scale else 1f)
                .shadow(
                    elevation = if (pulseEnabled) (8 + scale * 4).dp else 6.dp,
                    shape = CircleShape
                )
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(size * 0.5f)
            )
        }
    }
}

/**
 * 🎯 带涟漪效果的按钮
 * 点击时产生涟漪扩散效果
 */
@Composable
fun RippleEffectButton(
    onClick: () -> Unit,
    text: String,
    modifier: Modifier = Modifier,
    containerColor: Color = Color.Unspecified,
    contentColor: Color = Color.Unspecified
) {
    val resolvedContainerColor = if (containerColor != Color.Unspecified) containerColor else MaterialTheme.colorScheme.primary
    val resolvedContentColor = if (contentColor != Color.Unspecified) contentColor else MaterialTheme.colorScheme.onPrimary

    var rippleTriggered by remember { mutableStateOf(false) }
    
    val rippleScale by animateFloatAsState(
        targetValue = if (rippleTriggered) 2f else 1f,
        animationSpec = tween(
            durationMillis = 600,
            easing = FastOutSlowInEasing
        ),
        finishedListener = {
            rippleTriggered = false
        },
        label = "ripple"
    )
    
    val rippleAlpha by animateFloatAsState(
        targetValue = if (rippleTriggered) 0f else 0.3f,
        animationSpec = tween(600),
        label = "rippleAlpha"
    )
    
    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        // 涟漪效果
        if (rippleTriggered) {
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .scale(rippleScale)
                    .clip(CircleShape)
                    .background(resolvedContainerColor.copy(alpha = rippleAlpha))
            )
        }
        
        // 主按钮
        Button(
            onClick = {
                rippleTriggered = true
                onClick()
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = resolvedContainerColor,
                contentColor = resolvedContentColor
            )
        ) {
            androidx.compose.material3.Text(text)
        }
    }
}
