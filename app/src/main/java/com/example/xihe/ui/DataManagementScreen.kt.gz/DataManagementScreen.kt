package com.example.xihe.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.xihe.data.ConversationDataManager
import com.example.xihe.data.DataStatistics
import kotlinx.coroutines.launch
import java.io.File

/**
 * 📚 对话数据管理界面
 * 查看统计、导出数据、管理训练集
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DataManagementScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val dataManager = remember { ConversationDataManager.getInstance(context) }
    val scope = rememberCoroutineScope()
    
    var statistics by remember { mutableStateOf(DataStatistics()) }
    var isLoading by remember { mutableStateOf(true) }
    var showExportDialog by remember { mutableStateOf(false) }
    var exportResult by remember { mutableStateOf<String?>(null) }
    
    // 加载统计数据
    LaunchedEffect(Unit) {
        scope.launch {
            statistics = dataManager.getDataStatistics()
            isLoading = false
        }
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("对话数据管理") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "返回")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground,
                    navigationIconContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 数据统计卡片
            DataStatisticsCard(statistics = statistics, isLoading = isLoading)
            
            // 数据说明
            DataInfoCard()
            
            // 操作按钮
            ActionButtons(
                onExport = { showExportDialog = true },
                onRefresh = {
                    scope.launch {
                        isLoading = true
                        statistics = dataManager.getDataStatistics()
                        isLoading = false
                    }
                },
                onClear = {
                    scope.launch {
                        dataManager.clearAllData()
                        statistics = DataStatistics()
                    }
                }
            )
            
            // 导出结果
            exportResult?.let { result ->
                ResultCard(result) { exportResult = null }
            }
        }
    }
    
    // 导出对话框
    if (showExportDialog) {
        ExportDialog(
            onDismiss = { showExportDialog = false },
            onConfirm = { targetPath ->
                scope.launch {
                    val targetDir = File(targetPath)
                    val file = dataManager.exportTrainingData(targetDir)
                    exportResult = if (file != null) {
                        "✅ 数据已导出到:\n${file.absolutePath}"
                    } else {
                        "❌ 导出失败"
                    }
                    showExportDialog = false
                }
            }
        )
    }
}

@Composable
fun DataStatisticsCard(statistics: DataStatistics, isLoading: Boolean) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "📊 数据统计",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.align(Alignment.CenterHorizontally),
                    color = MaterialTheme.colorScheme.primary
                )
            } else {
                StatisticRow("总对话数", statistics.totalConversations.toString())
                StatisticRow("清洗数据", statistics.cleanedConversations.toString())
                StatisticRow("训练记录", statistics.trainingRecords.toString())
                StatisticRow("数据大小", String.format("%.2f MB", statistics.getDataSizeMB()))
            }
        }
    }
}

@Composable
fun StatisticRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleSmall)
    }
}

@Composable
fun DataInfoCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "💡 关于对话数据",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = """
                    羲和会自动收集并清洗你的对话记录，保存为标准训练格式。
                    
                    • 原始数据：保留所有对话
                    • 清洗数据：去除噪音和多余空格
                    • 训练数据：OpenAI Fine-tuning 格式
                    
                    你可以导出这些数据，用于训练专属的AI模型。
                """.trimIndent(),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun ActionButtons(
    onExport: () -> Unit,
    onRefresh: () -> Unit,
    onClear: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Button(
            onClick = onExport,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
            Icon(
                Icons.Default.Download,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimary
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("导出训练数据", color = MaterialTheme.colorScheme.onPrimary)
        }
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = onRefresh,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null)
                Spacer(modifier = Modifier.width(4.dp))
                Text("刷新")
            }
            
            OutlinedButton(
                onClick = onClear,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
            ) {
                Icon(Icons.Default.Delete, contentDescription = null)
                Spacer(modifier = Modifier.width(4.dp))
                Text("清除")
            }
        }
    }
}

@Composable
fun ResultCard(result: String, onDismiss: () -> Unit) {
    val isSuccess = result.startsWith("✅")
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (isSuccess) {
                MaterialTheme.colorScheme.primaryContainer
            } else {
                MaterialTheme.colorScheme.errorContainer
            }
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = result,
                color = if (isSuccess) {
                    MaterialTheme.colorScheme.onPrimaryContainer
                } else {
                    MaterialTheme.colorScheme.onErrorContainer
                },
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onDismiss) {
                Icon(
                    Icons.Default.Close,
                    contentDescription = "关闭",
                    tint = if (isSuccess) {
                        MaterialTheme.colorScheme.onPrimaryContainer
                    } else {
                        MaterialTheme.colorScheme.onErrorContainer
                    }
                )
            }
        }
    }
}

@Composable
fun ExportDialog(
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    val context = LocalContext.current
    var exportPath by remember {
        mutableStateOf(context.getExternalFilesDir(null)?.absolutePath ?: "")
    }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("导出训练数据") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("选择导出路径：")
                OutlinedTextField(
                    value = exportPath,
                    onValueChange = { exportPath = it },
                    label = { Text("导出路径") },
                    singleLine = true
                )
                Text(
                    text = "提示：数据将导出为 JSONL 格式",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(exportPath) }) {
                Text("导出")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("取消")
            }
        }
    )
}
