package com.example.xihe.ui.screens

import android.graphics.BitmapFactory
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.xihe.automation.script.*
import com.example.xihe.core.LLMClient
import com.example.xihe.ui.theme.DeepSpaceBlue
import kotlinx.coroutines.launch
import java.io.File

/**
 * 📊 验证报告界面
 * 显示脚本验证结果，包括每步详情、错误分析和优化建议
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ValidationReportScreen(
    report: ValidationReport,
    script: SmartScript,
    onBack: () -> Unit,
    onApplyOptimizations: (SmartScript) -> Unit,
    onRevalidate: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    var expandedStepId by remember { mutableStateOf<String?>(null) }
    var isOptimizing by remember { mutableStateOf(false) }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("验证报告") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "返回")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DeepSpaceBlue.Primary
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(DeepSpaceBlue.Secondary),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 摘要卡片
            item {
                ReportSummaryCard(report)
            }
            
            // 操作按钮
            if (report.hasFailures) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = {
                                scope.launch {
                                    isOptimizing = true
                                    try {
                                        val optimizer = ScriptOptimizer(context, LLMClient(
                                            com.example.xihe.core.AutomationEngine.baseUrl,
                                            com.example.xihe.core.AutomationEngine.apiKey,
                                            com.example.xihe.core.AutomationEngine.modelName
                                        ))
                                        val result = optimizer.optimizeScript(script, report)
                                        if (result.hasChanges) {
                                            onApplyOptimizations(result.optimizedScript)
                                            Toast.makeText(
                                                context, 
                                                "已应用 ${result.fixCount} 个优化", 
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        } else {
                                            Toast.makeText(context, "没有可自动修复的问题", Toast.LENGTH_SHORT).show()
                                        }
                                    } finally {
                                        isOptimizing = false
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f),
                            enabled = !isOptimizing,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DeepSpaceBlue.Accent
                            )
                        ) {
                            if (isOptimizing) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                                Spacer(Modifier.width(8.dp))
                            }
                            Icon(Icons.Default.AutoFixHigh, null)
                            Spacer(Modifier.width(8.dp))
                            Text("一键优化")
                        }
                        
                        OutlinedButton(
                            onClick = onRevalidate,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Refresh, null)
                            Spacer(Modifier.width(8.dp))
                            Text("重新验证")
                        }
                    }
                }
            }
            
            // 步骤结果列表
            item {
                Text(
                    text = "步骤详情",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            }
            
            items(report.stepResults) { stepResult ->
                StepResultCard(
                    stepResult = stepResult,
                    isExpanded = expandedStepId == stepResult.stepId,
                    onToggleExpand = {
                        expandedStepId = if (expandedStepId == stepResult.stepId) null else stepResult.stepId
                    }
                )
            }
        }
    }
}

@Composable
fun ReportSummaryCard(report: ValidationReport) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color.White.copy(alpha = 0.05f)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = report.scriptName,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp
            )
            
            Spacer(Modifier.height(16.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                StatItem(
                    label = "总步骤",
                    value = report.totalSteps.toString(),
                    color = Color.White
                )
                StatItem(
                    label = "成功",
                    value = report.successSteps.toString(),
                    color = Color(0xFF4CAF50)
                )
                StatItem(
                    label = "失败",
                    value = report.failedSteps.toString(),
                    color = if (report.failedSteps > 0) Color(0xFFF44336) else Color.Gray
                )
                StatItem(
                    label = "耗时",
                    value = "${report.executionTimeMs / 1000}s",
                    color = Color.White
                )
            }
            
            Spacer(Modifier.height(16.dp))
            
            // 成功率进度条
            LinearProgressIndicator(
                progress = { report.successRate },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = if (report.successRate >= 0.8f) Color(0xFF4CAF50) 
                       else if (report.successRate >= 0.5f) Color(0xFFFF9800)
                       else Color(0xFFF44336),
                trackColor = Color.White.copy(alpha = 0.1f)
            )
            
            Text(
                text = "成功率: ${(report.successRate * 100).toInt()}%",
                color = Color.Gray,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 4.dp)
            )
            
            if (report.cancelled) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "⚠️ 验证已取消",
                    color = Color(0xFFFF9800),
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun StatItem(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            color = color,
            fontWeight = FontWeight.Bold,
            fontSize = 24.sp
        )
        Text(
            text = label,
            color = Color.Gray,
            fontSize = 12.sp
        )
    }
}


@Composable
fun StepResultCard(
    stepResult: StepResult,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggleExpand),
        colors = CardDefaults.cardColors(
            containerColor = Color.White.copy(alpha = 0.05f)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 状态图标
                Icon(
                    imageVector = if (stepResult.success) Icons.Default.CheckCircle else Icons.Default.Error,
                    contentDescription = null,
                    tint = if (stepResult.success) Color(0xFF4CAF50) else Color(0xFFF44336),
                    modifier = Modifier.size(24.dp)
                )
                
                Spacer(Modifier.width(12.dp))
                
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stepResult.stepDescription,
                        color = Color.White,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "ID: ${stepResult.stepId} | ${stepResult.executionTimeMs}ms",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                }
                
                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = Color.Gray
                )
            }
            
            // 展开详情
            if (isExpanded) {
                Spacer(Modifier.height(12.dp))
                Divider(color = Color.White.copy(alpha = 0.1f))
                Spacer(Modifier.height(12.dp))
                
                // 错误信息
                if (!stepResult.success && stepResult.errorMessage != null) {
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(
                            Icons.Default.Warning,
                            null,
                            tint = Color(0xFFFF9800),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = stepResult.errorMessage,
                            color = Color(0xFFFF9800),
                            fontSize = 14.sp
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                }
                
                // 截图
                if (stepResult.screenshotPath != null) {
                    val bitmap = remember(stepResult.screenshotPath) {
                        try {
                            BitmapFactory.decodeFile(stepResult.screenshotPath)?.asImageBitmap()
                        } catch (e: Exception) {
                            null
                        }
                    }
                    
                    if (bitmap != null) {
                        Text(
                            text = "屏幕截图",
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                        Spacer(Modifier.height(8.dp))
                        Image(
                            bitmap = bitmap,
                            contentDescription = "步骤截图",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp)
                                .clip(RoundedCornerShape(8.dp))
                        )
                        Spacer(Modifier.height(12.dp))
                    }
                }
                
                // AI 分析结果
                stepResult.optimizationSuggestion?.let { suggestion ->
                    OptimizationSuggestionCard(suggestion)
                }
            }
        }
    }
}

@Composable
fun OptimizationSuggestionCard(suggestion: OptimizationSuggestion) {
    Surface(
        color = DeepSpaceBlue.Accent.copy(alpha = 0.1f),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.Lightbulb,
                    null,
                    tint = DeepSpaceBlue.Accent,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "AI 分析",
                    color = DeepSpaceBlue.Accent,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(Modifier.weight(1f))
                Text(
                    text = "置信度: ${(suggestion.confidence * 100).toInt()}%",
                    color = Color.Gray,
                    fontSize = 12.sp
                )
            }
            
            Spacer(Modifier.height(8.dp))
            
            // 错误类型
            Row {
                Text(
                    text = "错误类型: ",
                    color = Color.Gray,
                    fontSize = 12.sp
                )
                Text(
                    text = getErrorTypeLabel(suggestion.errorType),
                    color = Color.White,
                    fontSize = 12.sp
                )
            }
            
            // 错误描述
            Text(
                text = suggestion.errorDescription,
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 13.sp,
                modifier = Modifier.padding(vertical = 8.dp)
            )
            
            // 修复建议
            suggestion.suggestedFix?.let { fix ->
                Surface(
                    color = Color(0xFF4CAF50).copy(alpha = 0.1f),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Build,
                            null,
                            tint = Color(0xFF4CAF50),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = getFixDescription(fix),
                            color = Color(0xFF4CAF50),
                            fontSize = 12.sp
                        )
                    }
                }
            }
            
            // 推理过程
            if (suggestion.reasoning.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "推理: ${suggestion.reasoning}",
                    color = Color.Gray,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

private fun getErrorTypeLabel(errorType: ErrorType): String {
    return when (errorType) {
        ErrorType.ELEMENT_NOT_FOUND -> "元素未找到"
        ErrorType.ELEMENT_MOVED -> "元素位置变化"
        ErrorType.APP_STATE_CHANGED -> "应用状态异常"
        ErrorType.PERMISSION_DENIED -> "权限不足"
        ErrorType.TIMEOUT -> "操作超时"
        ErrorType.UNKNOWN -> "未知错误"
    }
}

private fun getFixDescription(fix: SuggestedFix): String {
    return when (fix) {
        is SuggestedFix.UpdateTarget -> "更新目标为: ${fix.newTarget}"
        is SuggestedFix.UpdateCoordinates -> "更新坐标为: (${fix.x}, ${fix.y})"
        is SuggestedFix.AddWaitStep -> "添加等待: ${fix.waitMs}ms"
        is SuggestedFix.AddScrollStep -> "添加滚动: ${fix.direction}"
        is SuggestedFix.ChangeAction -> "更改动作为: ${fix.newAction}"
        is SuggestedFix.UpdateValue -> "更新值为: ${fix.newValue}"
    }
}
