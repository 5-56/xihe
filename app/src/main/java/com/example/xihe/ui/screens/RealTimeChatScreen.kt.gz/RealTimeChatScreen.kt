package com.example.xihe.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.animation.core.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.xihe.core.EngineStateManager
import com.example.xihe.ui.components.quickcommand.VoiceWaveform
import com.example.xihe.ui.components.quickcommand.VoiceWaveformState
import com.example.xihe.ui.components.quickcommand.WaveformStyle
import com.example.xihe.ui.components.quickcommand.rememberSimulatedAmplitudes
import com.example.xihe.ui.utils.rememberHapticFeedback
import com.example.xihe.utils.LogManager

// 📞 实时对话全屏界面
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RealTimeChatScreen(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val haptic = rememberHapticFeedback()
    val scope = rememberCoroutineScope()
    
    // 状态
    var isListening by remember { mutableStateOf(false) }
    val messages by EngineStateManager.messages.collectAsStateWithLifecycle()
    val engineStatus by EngineStateManager.status.collectAsStateWithLifecycle()
    val voiceState = com.example.xihe.core.ModuleCoordinator.getVoiceState()
    val isSpeaking = voiceState == com.example.xihe.interaction.VoiceInteractionManager.VoiceState.SPEAKING
    
    // 🆕 实时部分识别结果
    val partialText by com.example.xihe.core.ModuleCoordinator.partialRecognitionResult.collectAsStateWithLifecycle()
    
    // 📞 打断状态
    var wasInterrupted by remember { mutableStateOf(false) }
    
    // 模拟振幅数据 (用于可视化效果)
    val amplitudes by rememberSimulatedAmplitudes(
        barCount = 30,
        isActive = isListening || isSpeaking
    )
    
    // 📞 实时打断检测：当检测到用户说话且AI正在播报时，立即打断
    LaunchedEffect(partialText, isSpeaking) {
        if (isSpeaking && partialText.length >= 2) {
            LogManager.d("RealTimeChatScreen", "📞 检测到用户打断，停止播报")
            wasInterrupted = true
            com.example.xihe.core.ModuleCoordinator.stopSpeaking()
        }
    }
    
    // 🎤 进入时自动开始持续监听
    LaunchedEffect(Unit) {
        LogManager.d("RealTimeChatScreen", "进入实时对话模式，启动持续监听")
        isListening = true
        com.example.xihe.core.ModuleCoordinator.startContinuousVoiceRecognition()
    }
    
    // 🔙 返回时停止监听
    DisposableEffect(Unit) {
        onDispose {
            LogManager.d("RealTimeChatScreen", "退出实时对话模式，停止监听")
            com.example.xihe.core.ModuleCoordinator.stopContinuousVoiceRecognition()
        }
    }
    
    // 全屏界面
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(
                colors = listOf(Color(0xFF050B14), Color(0xFF0A192F))
            ))
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 顶部栏
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 48.dp, start = 16.dp, end = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        haptic.mediumTap()
                        onDismiss()
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f), CircleShape)
                ) {
                    Icon(Icons.Default.KeyboardArrowDown, "收起", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                
                // 灵动岛状态胶囊
                Surface(
                    shape = RoundedCornerShape(50),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // 状态指示点
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(
                                    when {
                                        isSpeaking -> MaterialTheme.colorScheme.primary
                                        isListening -> MaterialTheme.colorScheme.secondary
                                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                                    },
                                    CircleShape
                                )
                        )
                        
                        Text(
                            text = when {
                                isSpeaking -> "羲和说话中..."
                                isListening -> "正在聆听..."
                                engineStatus.contains("思考") -> "思考中..."
                                engineStatus.contains("执行") -> "执行任务中..."
                                else -> "等待指令"
                            },
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
                
                IconButton(
                    onClick = { /* TODO: 设置 */ },
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(Icons.Default.Settings, "设置", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            
            Spacer(modifier = Modifier.weight(1f))
            
            // 🌊 中心可视化区域
            Box(
                modifier = Modifier.size(300.dp),
                contentAlignment = Alignment.Center
            ) {
                // 背景光晕
                Box(
                    modifier = Modifier
                        .size(280.dp)
                        .background(
                            brush = androidx.compose.ui.graphics.Brush.radialGradient(
                                colors = listOf(
                                    MaterialTheme.colorScheme.primary.copy(alpha = if (isSpeaking) 0.2f else 0.05f),
                                    Color.Transparent
                                )
                            ),
                            shape = CircleShape
                        )
                )
                
                if (isListening) {
                    // 监听态：圆形波纹
                    VoiceWaveform(
                        state = VoiceWaveformState.LISTENING,
                        style = WaveformStyle.CIRCLE,
                        amplitudes = amplitudes,
                        modifier = Modifier.size(200.dp),
                        primaryColor = MaterialTheme.colorScheme.secondary
                    )
                } else if (isSpeaking) {
                    // 说话态：声波律动
                    VoiceWaveform(
                        state = VoiceWaveformState.SPEAKING,
                        style = WaveformStyle.WAVE, // 或者 BARS
                        amplitudes = amplitudes,
                        modifier = Modifier.width(200.dp).height(100.dp),
                        primaryColor = MaterialTheme.colorScheme.primary
                    )
                } else {
                    // 待机态：呼吸效果
                    val infiniteTransition = rememberInfiniteTransition(label = "idle")
                    val alpha by infiniteTransition.animateFloat(
                        initialValue = 0.3f,
                        targetValue = 0.7f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(2000),
                            repeatMode = RepeatMode.Reverse
                        ),
                        label = "idleAlpha"
                    )
                    
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = alpha * 0.2f), CircleShape)
                            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = alpha), CircleShape)
                    )
                    
                    Text("🤖", fontSize = 48.sp)
                }
            }
            
            Spacer(modifier = Modifier.weight(1f))
            
            // 📝 实时字幕 / 最近消息
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 32.dp)
                    .heightIn(min = 60.dp),
                contentAlignment = Alignment.Center
            ) {
                // 优先显示正在输入的实时内容
                if (isListening && partialText.isNotEmpty()) {
                    Text(
                        text = partialText,
                        color = MaterialTheme.colorScheme.secondary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        maxLines = 3,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                    )
                } else {
                    // 否则显示最后一条消息
                    AnimatedContent(
                        targetState = messages.lastOrNull(),
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "transcript"
                    ) { lastMsg ->
                        if (lastMsg != null) {
                            Text(
                                text = if (lastMsg.isUser) "你: ${lastMsg.content}" else "羲和: ${lastMsg.content}",
                                color = if (lastMsg.isUser) {
                                    MaterialTheme.colorScheme.onSurfaceVariant
                                } else {
                                    MaterialTheme.colorScheme.primary
                                },
                                fontSize = 16.sp,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                maxLines = 3,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                            )
                        } else {
                            Text(
                                "试着说：\"帮我定个闹钟\"",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(48.dp))
            
            // 🎮 底部控制区
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 48.dp, vertical = 32.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 静音/监听开关
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    FilledIconButton(
                        onClick = {
                            haptic.mediumTap()
                            isListening = !isListening
                            if (isListening) {
                                com.example.xihe.core.ModuleCoordinator.startContinuousVoiceRecognition()
                            } else {
                                com.example.xihe.core.ModuleCoordinator.stopContinuousVoiceRecognition()
                            }
                        },
                        modifier = Modifier.size(64.dp),
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = if (isListening) {
                                MaterialTheme.colorScheme.primaryContainer
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                            }
                        )
                    ) {
                        Icon(
                            if (isListening) Icons.Default.Mic else Icons.Default.MicOff,
                            contentDescription = null,
                            tint = if (isListening) {
                                MaterialTheme.colorScheme.onPrimaryContainer
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            },
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("监听", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                }
                
                // 挂断 (强调)
                FilledIconButton(
                    onClick = {
                        haptic.heavyTap()
                        onDismiss()
                    },
                    modifier = Modifier.size(80.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.9f)
                    )
                ) {
                    Icon(
                        Icons.Default.CallEnd,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onError,
                        modifier = Modifier.size(36.dp)
                    )
                }
                
                // 打断 (停止播报)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    FilledIconButton(
                        onClick = {
                            haptic.mediumTap()
                            com.example.xihe.core.ModuleCoordinator.stopSpeaking()
                        },
                        modifier = Modifier.size(64.dp),
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                        )
                    ) {
                        Icon(
                            Icons.Default.Stop,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("打断", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                }
            }
        }
    }
}
