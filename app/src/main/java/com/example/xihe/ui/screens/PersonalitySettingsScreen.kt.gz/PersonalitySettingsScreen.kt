package com.example.xihe.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.xihe.personality.Personality
import com.example.xihe.personality.PersonalityManager
import com.example.xihe.ui.components.GlassmorphicCard
import com.example.xihe.ui.utils.rememberHapticFeedback

/**
 * 🎭 人格矩阵设置界面
 * 
 * 采用科幻磨砂玻璃风格，统一全站视觉
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PersonalitySettingsScreen(
    onBack: () -> Unit = {}
) {
    val context = LocalContext.current
    val personalityManager = remember { PersonalityManager.getInstance(context) }
    val haptic = rememberHapticFeedback()
    
    val personalities by personalityManager.personalities.collectAsState()
    val currentPersonality by personalityManager.currentPersonality.collectAsState()
    
    var showCreateDialog by remember { mutableStateOf(false) }
    var showPreviewDialog by remember { mutableStateOf<Personality?>(null) }
    var showEditDialog by remember { mutableStateOf<Personality?>(null) }
    
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("人格矩阵", fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "返回", tint = MaterialTheme.colorScheme.primary)
                    }
                },
                actions = {
                    IconButton(onClick = { 
                        haptic.mediumTap()
                        showCreateDialog = true 
                    }) {
                        Icon(Icons.Default.AddCircleOutline, "同步新的人格", tint = MaterialTheme.colorScheme.primary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                GlassmorphicCard(
                    backgroundColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.05f),
                    borderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = "在此切换羲和的逻辑灵魂。每一个性格都拥有独特的语言模型权重与交互偏好。",
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                        fontSize = 13.sp,
                        lineHeight = 20.sp
                    )
                }
            }
            
            item {
                SectionHeader("活跃人格")
                ActivePersonalityPanel(
                    personality = currentPersonality,
                    onPreview = { showPreviewDialog = currentPersonality }
                )
            }
            
            item { SectionHeader("可用人格模块") }
            
            items(personalities) { personality ->
                PersonalityModuleCard(
                    personality = personality,
                    isSelected = personality.id == currentPersonality.id,
                    onClick = { 
                        haptic.lightTap()
                        personalityManager.setCurrentPersonality(personality.id) 
                    },
                    onPreview = { showPreviewDialog = personality },
                    onEdit = if (!personality.isDefault) { { showEditDialog = personality } } else null,
                    onDelete = if (!personality.isDefault) { { personalityManager.deletePersonality(personality.id) } } else null
                )
            }
        }
    }

    // 创建新性格对话框
    if (showCreateDialog) {
        CreatePersonalityDialog(
            onDismiss = { showCreateDialog = false },
            onCreate = { name, emoji, description, systemPrompt ->
                personalityManager.createPersonality(name, emoji, description, systemPrompt)
                showCreateDialog = false
            }
        )
    }
    
    // 编辑性格对话框
    showEditDialog?.let { personality ->
        EditPersonalityDialog(
            personality = personality,
            onDismiss = { showEditDialog = null },
            onSave = { updatedPersonality ->
                personalityManager.updatePersonality(updatedPersonality)
                showEditDialog = null
            }
        )
    }

    // 预览对话框
    showPreviewDialog?.let { personality ->
        AlertDialog(
            onDismissRequest = { showPreviewDialog = null },
            title = { Text(personality.name, color = MaterialTheme.colorScheme.primary) },
            text = {
                Text(personality.systemPrompt, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.9f), fontSize = 12.sp)
            },
            confirmButton = {
                TextButton(onClick = { showPreviewDialog = null }) {
                    Text("关闭", color = MaterialTheme.colorScheme.primary)
                }
            },
            containerColor = MaterialTheme.colorScheme.surface
        )
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title.uppercase(),
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
        letterSpacing = 1.5.sp,
        modifier = Modifier.padding(start = 4.dp, bottom = 4.dp, top = 8.dp)
    )
}

@Composable
private fun ActivePersonalityPanel(personality: Personality, onPreview: () -> Unit) {
    GlassmorphicCard(
        backgroundColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
        borderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f),
        borderWidth = 2.dp
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                modifier = Modifier.size(64.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(personality.emoji, fontSize = 32.sp)
                }
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(personality.name, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                Text(personality.description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
            }
            IconButton(onClick = onPreview) {
                Icon(Icons.Default.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
private fun PersonalityModuleCard(
    personality: Personality,
    isSelected: Boolean,
    onClick: () -> Unit,
    onPreview: () -> Unit,
    onEdit: (() -> Unit)?,
    onDelete: (() -> Unit)?
) {
    GlassmorphicCard(
        modifier = Modifier.clickable(onClick = onClick),
        borderColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
        borderWidth = if (isSelected) 1.5.dp else 1.dp
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(personality.emoji, fontSize = 24.sp)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(personality.name, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                Text(personality.description, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f), maxLines = 1)
            }
            if (isSelected) {
                Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
            }
            
            IconButton(onClick = onPreview, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Default.Visibility, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
            }
            
            if (onEdit != null) {
                IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Edit, null, tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f), modifier = Modifier.size(16.dp))
                }
            }
            
            if (onDelete != null) {
                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.DeleteOutline, null, tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f), modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

/**
 * 🆕 创建新性格对话框
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CreatePersonalityDialog(
    onDismiss: () -> Unit,
    onCreate: (name: String, emoji: String, description: String, systemPrompt: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var emoji by remember { mutableStateOf("🎭") }
    var description by remember { mutableStateOf("") }
    var systemPrompt by remember { mutableStateOf("") }
    
    val emojiOptions = listOf("🎭", "🌟", "🎀", "👩‍💼", "🧊", "🤡", "🦊", "🐱", "🌸", "⚡", "🔥", "💎")
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { 
            Text("创建新性格", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold) 
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // 名称输入
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("性格名称") },
                    placeholder = { Text("例如：温柔助手") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                        focusedLabelColor = MaterialTheme.colorScheme.primary,
                        cursorColor = MaterialTheme.colorScheme.primary,
                        unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                        focusedTextColor = MaterialTheme.colorScheme.onSurface
                    )
                )
                
                // Emoji 选择
                Text("选择图标", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    emojiOptions.take(6).forEach { e ->
                        Surface(
                            shape = CircleShape,
                            color = if (emoji == e) MaterialTheme.colorScheme.primary.copy(alpha = 0.3f) else Color.Transparent,
                            modifier = Modifier
                                .size(40.dp)
                                .clickable { emoji = e }
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(e, fontSize = 20.sp)
                            }
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    emojiOptions.drop(6).forEach { e ->
                        Surface(
                            shape = CircleShape,
                            color = if (emoji == e) MaterialTheme.colorScheme.primary.copy(alpha = 0.3f) else Color.Transparent,
                            modifier = Modifier
                                .size(40.dp)
                                .clickable { emoji = e }
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(e, fontSize = 20.sp)
                            }
                        }
                    }
                }
                
                // 描述输入
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("简短描述") },
                    placeholder = { Text("例如：温柔可爱的AI助手") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                        focusedLabelColor = MaterialTheme.colorScheme.primary,
                        cursorColor = MaterialTheme.colorScheme.primary,
                        unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                        focusedTextColor = MaterialTheme.colorScheme.onSurface
                    )
                )
                
                // 系统提示词输入
                OutlinedTextField(
                    value = systemPrompt,
                    onValueChange = { systemPrompt = it },
                    label = { Text("系统提示词") },
                    placeholder = { Text("定义AI的性格特点、说话风格等...") },
                    minLines = 5,
                    maxLines = 10,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                        focusedLabelColor = MaterialTheme.colorScheme.primary,
                        cursorColor = MaterialTheme.colorScheme.primary,
                        unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                        focusedTextColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { 
                    if (name.isNotBlank() && systemPrompt.isNotBlank()) {
                        onCreate(name, emoji, description.ifBlank { name }, systemPrompt)
                    }
                },
                enabled = name.isNotBlank() && systemPrompt.isNotBlank()
            ) {
                Text("创建", color = if (name.isNotBlank() && systemPrompt.isNotBlank()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("取消", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        containerColor = MaterialTheme.colorScheme.surface
    )
}

/**
 * ✏️ 编辑性格对话框
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditPersonalityDialog(
    personality: Personality,
    onDismiss: () -> Unit,
    onSave: (Personality) -> Unit
) {
    var name by remember { mutableStateOf(personality.name) }
    var emoji by remember { mutableStateOf(personality.emoji) }
    var description by remember { mutableStateOf(personality.description) }
    var systemPrompt by remember { mutableStateOf(personality.systemPrompt) }
    
    val emojiOptions = listOf("🎭", "🌟", "🎀", "👩‍💼", "🧊", "🤡", "🦊", "🐱", "🌸", "⚡", "🔥", "💎")
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { 
            Text("编辑性格", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold) 
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // 名称输入
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("性格名称") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                        focusedLabelColor = MaterialTheme.colorScheme.primary,
                        cursorColor = MaterialTheme.colorScheme.primary,
                        unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                        focusedTextColor = MaterialTheme.colorScheme.onSurface
                    )
                )
                
                // Emoji 选择
                Text("选择图标", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    emojiOptions.take(6).forEach { e ->
                        Surface(
                            shape = CircleShape,
                            color = if (emoji == e) MaterialTheme.colorScheme.primary.copy(alpha = 0.3f) else Color.Transparent,
                            modifier = Modifier
                                .size(40.dp)
                                .clickable { emoji = e }
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(e, fontSize = 20.sp)
                            }
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    emojiOptions.drop(6).forEach { e ->
                        Surface(
                            shape = CircleShape,
                            color = if (emoji == e) MaterialTheme.colorScheme.primary.copy(alpha = 0.3f) else Color.Transparent,
                            modifier = Modifier
                                .size(40.dp)
                                .clickable { emoji = e }
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(e, fontSize = 20.sp)
                            }
                        }
                    }
                }
                
                // 描述输入
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("简短描述") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                        focusedLabelColor = MaterialTheme.colorScheme.primary,
                        cursorColor = MaterialTheme.colorScheme.primary,
                        unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                        focusedTextColor = MaterialTheme.colorScheme.onSurface
                    )
                )
                
                // 系统提示词输入
                OutlinedTextField(
                    value = systemPrompt,
                    onValueChange = { systemPrompt = it },
                    label = { Text("系统提示词") },
                    minLines = 5,
                    maxLines = 10,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                        focusedLabelColor = MaterialTheme.colorScheme.primary,
                        cursorColor = MaterialTheme.colorScheme.primary,
                        unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                        focusedTextColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { 
                    if (name.isNotBlank() && systemPrompt.isNotBlank()) {
                        onSave(personality.copy(
                            name = name,
                            emoji = emoji,
                            description = description,
                            systemPrompt = systemPrompt
                        ))
                    }
                },
                enabled = name.isNotBlank() && systemPrompt.isNotBlank()
            ) {
                Text("保存", color = if (name.isNotBlank() && systemPrompt.isNotBlank()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("取消", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        containerColor = MaterialTheme.colorScheme.surface
    )
}