package com.example.xihe.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.example.xihe.service.TrainingKeepAliveService
import com.example.xihe.training.SystemMonitor

/**
 * 🎨 训练中心主界面
 * 
 * 美观的卡片式设计，提供所有训练相关功能的入口
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrainingHub(
    navController: NavController,
    onBack: () -> Unit = {}
) {
    val context = LocalContext.current
    val monitor = remember { SystemMonitor.getInstance(context) }
    val recommendation by monitor.trainingRecommendation.collectAsStateWithLifecycle()
    val systemState by monitor.systemState.collectAsStateWithLifecycle()
    val serviceRunning = remember { mutableStateOf(TrainingKeepAliveService.isRunning(context)) }
    
    LaunchedEffect(Unit) {
        monitor.startMonitoring()
    }
    
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background, // 🎨 独立深色背景，不透出聊天页
        topBar = {
            TopAppBar(
                title = { 
                    Column {
                        Text("🧠 羲和训练中心")
                        Text(
                            text = "Train Your Personal AI",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "返回")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background // 与页面背景一致
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. 状态概览卡片（大卡片，渐变背景）
            StatusOverviewCard(
                serviceRunning = serviceRunning.value,
                recommendation = recommendation,
                systemState = systemState
            )
            
            // 2. 快速操作
            Text(
                text = "⚡ 快速操作",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickActionCard(
                    title = "控制训练",
                    icon = Icons.Default.PlayArrow,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f),
                    onClick = { navController.navigate("training_control") }
                )
                
                QuickActionCard(
                    title = "添加数据",
                    icon = Icons.Default.Add,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.weight(1f),
                    onClick = { navController.navigate("custom_data") }
                )
            }
            
            // 3. 功能导航
            Text(
                text = "🎯 功能导航",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            FeatureCard(
                title = "训练监控",
                subtitle = "查看实时状态和训练进度",
                icon = Icons.Default.Analytics,
                onClick = { navController.navigate("training_monitor") }
            )
            
            FeatureCard(
                title = "数据管理",
                subtitle = "管理对话数据和训练集",
                icon = Icons.Default.Storage,
                onClick = { navController.navigate("data_management") }
            )
            
            FeatureCard(
                title = "训练设置",
                subtitle = "配置后台保活和训练参数",
                icon = Icons.Default.Settings,
                onClick = { navController.navigate("training_settings") }
            )
            
            // 🆕 数据清洗工具
            FeatureCard(
                title = "数据清洗",
                subtitle = "上传小说、聊天记录等自动生成训练数据",
                icon = Icons.Default.CleaningServices,
                onClick = { navController.navigate("data_cleaner") }
            )
            
            // 🆕 API训练监控
            FeatureCard(
                title = "API监控",
                subtitle = "远程监控训练、AI智能分析训练状态",
                icon = Icons.Default.Cloud,
                onClick = { navController.navigate("api_monitor") }
            )

            // 🆕 智能脚本库
            FeatureCard(
                title = "智能脚本库",
                subtitle = "管理 AI 学习到的自动化操作逻辑",
                icon = Icons.Default.AutoFixHigh,
                onClick = { navController.navigate("script_library") }
            )
            
            // 4. 帮助信息
            HelpInfoCard()
        }
    }
}

/**
 * 📊 状态概览卡片（大卡片，渐变背景）
 */
@Composable
fun StatusOverviewCard(
    serviceRunning: Boolean,
    recommendation: com.example.xihe.training.TrainingRecommendation,
    systemState: com.example.xihe.training.SystemState
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.Transparent
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.verticalGradient(
                        colors = if (recommendation.shouldStartTraining) {
                            listOf(
                                MaterialTheme.colorScheme.primaryContainer,
                                MaterialTheme.colorScheme.secondaryContainer
                            )
                        } else {
                            listOf(
                                MaterialTheme.colorScheme.surfaceVariant,
                                MaterialTheme.colorScheme.surface
                            )
                        }
                    )
                )
                .padding(20.dp)
        ) {
            Column(
                verticalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxSize()
            ) {
                // 顶部：服务状态
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text(
                            text = if (serviceRunning) "✅ 服务运行中" else "⭕ 服务已停止",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (serviceRunning) "正在监控训练时机" else "点击设置启动服务",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                
                // 中部：关键指标
                Row(
                    horizontalArrangement = Arrangement.SpaceAround,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    MetricItem("🌡️", "${systemState.temperature}°C")
                    MetricItem("🔋", "${systemState.batteryLevel}%")
                    MetricItem("💾", "${systemState.availableMemoryMB}MB")
                }
                
                // 底部：训练建议
                Surface(
                    color = if (recommendation.shouldStartTraining) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant
                    },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            if (recommendation.shouldStartTraining) Icons.Default.CheckCircle else Icons.Default.Info,
                            contentDescription = null,
                            tint = if (recommendation.shouldStartTraining) {
                                MaterialTheme.colorScheme.onPrimary
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            }
                        )
                        Text(
                            text = recommendation.reason,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (recommendation.shouldStartTraining) {
                                MaterialTheme.colorScheme.onPrimary
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            }
                        )
                    }
                }
            }
        }
    }
}

/**
 * 指标项
 */
@Composable
fun MetricItem(icon: String, value: String) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            text = icon,
            style = MaterialTheme.typography.headlineMedium
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold
        )
    }
}

/**
 * ⚡ 快速操作卡片
 */
@Composable
fun QuickActionCard(
    title: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .height(100.dp)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = color.copy(alpha = 0.1f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(32.dp)
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = color
            )
        }
    }
}

/**
 * 🎯 功能卡片
 */
@Composable
fun FeatureCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.size(56.dp)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.fillMaxSize()
                ) {
                    Icon(
                        icon,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
            
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            
            Icon(
                Icons.Default.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/**
 * 💡 帮助信息卡片
 */
@Composable
fun HelpInfoCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.tertiaryContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    Icons.Default.Lightbulb,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.tertiary
                )
                Text(
                    text = "💡 温馨提示",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
            }
            
            Text(
                text = """
                    羲和会在你睡觉时自动训练，完全不打扰：
                    
                    • 睡前插上充电器
                    • 关闭屏幕
                    • 羲和自动检测并训练
                    • 早上醒来，AI更懂你
                """.trimIndent(),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
