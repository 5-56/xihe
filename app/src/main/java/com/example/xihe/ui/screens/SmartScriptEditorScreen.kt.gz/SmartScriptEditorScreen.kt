package com.example.xihe.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.xihe.automation.script.*
import com.example.xihe.ui.theme.DeepSpaceBlue

/**
 * 📝 智能脚本编辑器界面
 * 用于编辑 SmartScript 的元数据和步骤参数
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartScriptEditorScreen(
    scriptId: String,
    onBack: () -> Unit,
    onValidate: ((String) -> Unit)? = null
) {
    val context = LocalContext.current
    var script by remember { mutableStateOf(SmartScriptManager.getScript(scriptId)) }
    var hasChanges by remember { mutableStateOf(false) }
    var expandedStepId by remember { mutableStateOf<String?>(null) }
    var showEditStepDialog by remember { mutableStateOf(false) }
    var editingStep by remember { mutableStateOf<SmartStep?>(null) }
    var showMetadataDialog by remember { mutableStateOf(false) }
    
    if (script == null) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    Icons.Default.Error,
                    contentDescription = null,
                    modifier = Modifier.size(64.dp),
                    tint = Color.Gray
                )
                Spacer(Modifier.height(16.dp))
                Text("脚本不存在", color = Color.Gray)
                Spacer(Modifier.height(16.dp))
                Button(onClick = onBack) {
                    Text("返回")
                }
            }
        }
        return
    }

    val currentScript = script ?: return
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Column {
                        Text(currentScript.metadata.name)
                        if (hasChanges) {
                            Text(
                                "有未保存的更改",
                                fontSize = 12.sp,
                                color = Color(0xFFFF9800)
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = {
                        if (hasChanges) {
                            // TODO: 显示确认对话框
                        }
                        onBack()
                    }) {
                        Icon(Icons.Default.ArrowBack, "返回")
                    }
                },
                actions = {
                    if (onValidate != null) {
                        IconButton(onClick = { onValidate(scriptId) }) {
                            Icon(Icons.Default.PlayArrow, "验证")
                        }
                    }
                    IconButton(
                        onClick = {
                            val updatedScript = SmartScriptManager.saveScriptWithVersion(context, currentScript)
                            script = updatedScript
                            hasChanges = false
                            Toast.makeText(context, "保存成功 (v${updatedScript.metadata.version})", Toast.LENGTH_SHORT).show()
                        },
                        enabled = hasChanges
                    ) {
                        Icon(
                            Icons.Default.Save, 
                            "保存",
                            tint = if (hasChanges) DeepSpaceBlue.Accent else Color.Gray
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DeepSpaceBlue.Primary
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(DeepSpaceBlue.Secondary),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 元数据卡片
            item {
                MetadataCard(
                    metadata = currentScript.metadata,
                    onEditClick = { showMetadataDialog = true }
                )
            }
            
            // 变量卡片
            if (currentScript.variables.isNotEmpty()) {
                item {
                    VariablesCard(
                        variables = currentScript.variables,
                        onVariableChange = { key, value ->
                            val newVariables = currentScript.variables.toMutableMap()
                            newVariables[key] = value
                            script = currentScript.copy(variables = newVariables)
                            hasChanges = true
                        }
                    )
                }
            }
            
            // 步骤列表标题
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "执行步骤 (${currentScript.flow.steps.size})",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
            }
            
            // 步骤列表
            itemsIndexed(currentScript.flow.steps, key = { _, step -> step.id }) { index, step ->
                SmartStepCard(
                    step = step,
                    index = index,
                    isExpanded = expandedStepId == step.id,
                    onToggleExpand = {
                        expandedStepId = if (expandedStepId == step.id) null else step.id
                    },
                    onEditClick = {
                        editingStep = step
                        showEditStepDialog = true
                    }
                )
            }
        }
    }
    
    // 元数据编辑对话框
    if (showMetadataDialog) {
        MetadataEditDialog(
            metadata = currentScript.metadata,
            onDismiss = { showMetadataDialog = false },
            onConfirm = { newMetadata ->
                script = currentScript.copy(metadata = newMetadata)
                hasChanges = true
                showMetadataDialog = false
            }
        )
    }
    
    // 步骤编辑对话框
    if (showEditStepDialog && editingStep != null) {
        val currentEditingStep = editingStep ?: return
        StepEditDialog(
            step = currentEditingStep,
            onDismiss = { 
                showEditStepDialog = false
                editingStep = null
            },
            onConfirm = { updatedStep ->
                val updatedSteps = currentScript.flow.steps.map { 
                    if (it.id == updatedStep.id) updatedStep else it 
                }
                script = currentScript.copy(
                    flow = currentScript.flow.copy(steps = updatedSteps)
                )
                hasChanges = true
                showEditStepDialog = false
                editingStep = null
            }
        )
    }
}


@Composable
private fun MetadataCard(
    metadata: ScriptMetadata,
    onEditClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color.White.copy(alpha = 0.05f)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "脚本信息",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onEditClick) {
                    Icon(Icons.Default.Edit, "编辑", tint = Color.Gray)
                }
            }
            
            Spacer(Modifier.height(8.dp))
            
            InfoRow("名称", metadata.name)
            InfoRow("描述", metadata.description)
            InfoRow("版本", "v${metadata.version}")
            InfoRow("意图", metadata.intent)
            
            if (metadata.keywords.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text("关键词", color = Color.Gray, fontSize = 12.sp)
                Spacer(Modifier.height(4.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.horizontalScroll(rememberScrollState())
                ) {
                    metadata.keywords.forEach { keyword ->
                        Surface(
                            color = DeepSpaceBlue.Accent.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = keyword,
                                color = DeepSpaceBlue.Accent,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
    ) {
        Text(
            text = "$label: ",
            color = Color.Gray,
            fontSize = 14.sp
        )
        Text(
            text = value,
            color = Color.White,
            fontSize = 14.sp
        )
    }
}

@Composable
private fun VariablesCard(
    variables: Map<String, String>,
    onVariableChange: (String, String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color.White.copy(alpha = 0.05f)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "变量",
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(Modifier.height(12.dp))
            
            variables.forEach { (key, value) ->
                var editValue by remember(key, value) { mutableStateOf(value) }
                
                OutlinedTextField(
                    value = editValue,
                    onValueChange = { 
                        editValue = it
                        onVariableChange(key, it)
                    },
                    label = { Text("\$$key") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        unfocusedBorderColor = Color.Gray.copy(alpha = 0.5f),
                        focusedBorderColor = DeepSpaceBlue.Accent
                    )
                )
            }
        }
    }
}

@Composable
private fun SmartStepCard(
    step: SmartStep,
    index: Int,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    onEditClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggleExpand),
        colors = CardDefaults.cardColors(
            containerColor = Color.White.copy(alpha = 0.05f)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 步骤序号
                Surface(
                    color = getStepTypeColor(step.type).copy(alpha = 0.2f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.size(36.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = "${index + 1}",
                            color = getStepTypeColor(step.type),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                
                Spacer(Modifier.width(12.dp))
                
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = getStepTypeLabel(step.type),
                            color = getStepTypeColor(step.type),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                        if (step.action != null) {
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = step.action,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    
                    if (step.target != null || step.value != null) {
                        Text(
                            text = listOfNotNull(step.target, step.value).joinToString(" → "),
                            color = Color.Gray,
                            fontSize = 12.sp,
                            maxLines = 1
                        )
                    }
                }
                
                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = Color.Gray
                )
            }
            
            // 展开详情
            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    Divider(color = Color.White.copy(alpha = 0.1f))
                    Spacer(Modifier.height(12.dp))
                    
                    DetailRow("ID", step.id)
                    DetailRow("类型", step.type.name)
                    step.action?.let { DetailRow("动作", it) }
                    step.target?.let { DetailRow("目标", it) }
                    step.value?.let { DetailRow("值", it) }
                    
                    step.condition?.let { condition ->
                        Spacer(Modifier.height(8.dp))
                        Text("条件", color = Color.Gray, fontSize = 12.sp)
                        DetailRow("类型", condition.type.name)
                        DetailRow("模式", condition.pattern)
                        condition.targetApp?.let { DetailRow("目标应用", it) }
                    }
                    
                    step.nextStepIfTrue?.let { DetailRow("条件为真时", it) }
                    step.nextStepIfFalse?.let { DetailRow("条件为假时", it) }
                    
                    Spacer(Modifier.height(12.dp))
                    
                    Button(
                        onClick = onEditClick,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = DeepSpaceBlue.Accent
                        )
                    ) {
                        Icon(Icons.Default.Edit, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("编辑步骤")
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
    ) {
        Text(
            text = "$label: ",
            color = Color.Gray,
            fontSize = 13.sp,
            modifier = Modifier.width(80.dp)
        )
        Text(
            text = value,
            color = Color.White.copy(alpha = 0.9f),
            fontSize = 13.sp
        )
    }
}

private fun getStepTypeColor(type: StepType): Color {
    return when (type) {
        StepType.ACTION -> Color(0xFF4CAF50)
        StepType.CONDITION -> Color(0xFF2196F3)
        StepType.LOOP -> Color(0xFFFF9800)
        StepType.DELAY -> Color(0xFF9C27B0)
    }
}

private fun getStepTypeLabel(type: StepType): String {
    return when (type) {
        StepType.ACTION -> "动作"
        StepType.CONDITION -> "条件"
        StepType.LOOP -> "循环"
        StepType.DELAY -> "延迟"
    }
}


@Composable
private fun MetadataEditDialog(
    metadata: ScriptMetadata,
    onDismiss: () -> Unit,
    onConfirm: (ScriptMetadata) -> Unit
) {
    var name by remember { mutableStateOf(metadata.name) }
    var description by remember { mutableStateOf(metadata.description) }
    var intent by remember { mutableStateOf(metadata.intent) }
    var keywordsText by remember { mutableStateOf(metadata.keywords.joinToString(", ")) }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("编辑脚本信息") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("名称") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("描述") },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
                
                OutlinedTextField(
                    value = intent,
                    onValueChange = { intent = it },
                    label = { Text("意图") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                
                OutlinedTextField(
                    value = keywordsText,
                    onValueChange = { keywordsText = it },
                    label = { Text("关键词 (逗号分隔)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val keywords = keywordsText.split(",")
                        .map { it.trim() }
                        .filter { it.isNotBlank() }
                    
                    onConfirm(metadata.copy(
                        name = name,
                        description = description,
                        intent = intent,
                        keywords = keywords
                    ))
                },
                enabled = name.isNotBlank()
            ) {
                Text("保存")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("取消")
            }
        }
    )
}

@Composable
private fun StepEditDialog(
    step: SmartStep,
    onDismiss: () -> Unit,
    onConfirm: (SmartStep) -> Unit
) {
    var action by remember { mutableStateOf(step.action ?: "") }
    var target by remember { mutableStateOf(step.target ?: "") }
    var value by remember { mutableStateOf(step.value ?: "") }
    var selectedType by remember { mutableStateOf(step.type) }
    
    // 条件相关
    var conditionType by remember { mutableStateOf(step.condition?.type ?: ConditionType.ELEMENT_EXISTS) }
    var conditionPattern by remember { mutableStateOf(step.condition?.pattern ?: "") }
    var conditionTargetApp by remember { mutableStateOf(step.condition?.targetApp ?: "") }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("编辑步骤") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // 步骤类型
                Text("步骤类型", fontWeight = FontWeight.Medium)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StepType.entries.forEach { type ->
                        FilterChip(
                            selected = selectedType == type,
                            onClick = { selectedType = type },
                            label = { Text(getStepTypeLabel(type)) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = getStepTypeColor(type).copy(alpha = 0.2f)
                            )
                        )
                    }
                }
                
                when (selectedType) {
                    StepType.ACTION -> {
                        // 动作选择
                        Text("动作", fontWeight = FontWeight.Medium)
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.horizontalScroll(rememberScrollState())
                        ) {
                            listOf("CLICK", "INPUT", "SCROLL", "BACK", "HOME", "SWIPE").forEach { act ->
                                FilterChip(
                                    selected = action == act,
                                    onClick = { action = act },
                                    label = { Text(act) }
                                )
                            }
                        }
                        
                        OutlinedTextField(
                            value = target,
                            onValueChange = { target = it },
                            label = { Text("目标 (元素文本/ID)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        
                        OutlinedTextField(
                            value = value,
                            onValueChange = { value = it },
                            label = { Text("值 (输入内容/方向)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    
                    StepType.CONDITION -> {
                        Text("条件类型", fontWeight = FontWeight.Medium)
                        Column {
                            ConditionType.entries.forEach { type ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { conditionType = type }
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = conditionType == type,
                                        onClick = { conditionType = type }
                                    )
                                    Text(getConditionTypeLabel(type))
                                }
                            }
                        }
                        
                        OutlinedTextField(
                            value = conditionPattern,
                            onValueChange = { conditionPattern = it },
                            label = { Text("匹配模式") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        
                        if (conditionType == ConditionType.APP_IN_FOREGROUND) {
                            OutlinedTextField(
                                value = conditionTargetApp,
                                onValueChange = { conditionTargetApp = it },
                                label = { Text("目标应用包名") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                    
                    StepType.DELAY -> {
                        OutlinedTextField(
                            value = value,
                            onValueChange = { value = it.filter { c -> c.isDigit() } },
                            label = { Text("延迟时间 (毫秒)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    
                    StepType.LOOP -> {
                        Text("循环配置需要在脚本级别设置", color = Color.Gray)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val updatedStep = when (selectedType) {
                        StepType.ACTION -> step.copy(
                            type = selectedType,
                            action = action.ifBlank { null },
                            target = target.ifBlank { null },
                            value = value.ifBlank { null },
                            condition = null
                        )
                        StepType.CONDITION -> step.copy(
                            type = selectedType,
                            action = null,
                            condition = ScriptCondition(
                                type = conditionType,
                                pattern = conditionPattern,
                                targetApp = conditionTargetApp.ifBlank { null }
                            )
                        )
                        StepType.DELAY -> step.copy(
                            type = selectedType,
                            action = null,
                            target = null,
                            value = value.ifBlank { "1000" },
                            condition = null
                        )
                        StepType.LOOP -> step.copy(type = selectedType)
                    }
                    onConfirm(updatedStep)
                }
            ) {
                Text("保存")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("取消")
            }
        }
    )
}

private fun getConditionTypeLabel(type: ConditionType): String {
    return when (type) {
        ConditionType.ELEMENT_EXISTS -> "元素存在"
        ConditionType.TEXT_CONTAINS -> "文本包含"
        ConditionType.APP_IN_FOREGROUND -> "应用在前台"
    }
}
