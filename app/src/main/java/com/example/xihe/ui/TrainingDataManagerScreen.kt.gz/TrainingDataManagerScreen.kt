package com.example.xihe.ui

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.xihe.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * 📊 训练数据管理界面
 * 
 * 功能：
 * 1. 查看数据统计
 * 2. 批量导入训练数据（从文件夹）
 * 3. 导出训练数据
 * 4. 清除数据
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrainingDataManagerScreen(
    onBack: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val dataManager = remember { ConversationDataManager.getInstance(context) }
    
    var statistics by remember { mutableStateOf<DataStatistics?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    var showImportResult by remember { mutableStateOf(false) }
    var importResult by remember { mutableStateOf<ImportResult?>(null) }
    var showImportOptions by remember { mutableStateOf(false) }
    
    // 🆕 单文件选择器 - 支持直接选择 .json 或 .jsonl 文件
    val filePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            scope.launch {
                isLoading = true
                try {
                    val result = importFromUri(context, dataManager, uri)
                    importResult = result
                    showImportResult = true
                    statistics = dataManager.getDataStatistics()
                } catch (e: Exception) {
                    importResult = ImportResult.Error("导入失败: ${e.message}")
                    showImportResult = true
                } finally {
                    isLoading = false
                }
            }
        }
    }
    
    // 🆕 多文件选择器
    val multiFilePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            scope.launch {
                isLoading = true
                try {
                    var totalSuccess = 0
                    var totalFail = 0
                    val errors = mutableListOf<String>()
                    
                    for (uri in uris) {
                        val result = importFromUri(context, dataManager, uri)
                        when (result) {
                            is ImportResult.Success -> {
                                totalSuccess += result.successCount
                                totalFail += result.failCount
                                errors.addAll(result.errors)
                            }
                            is ImportResult.Error -> {
                                totalFail++
                                errors.add(result.message)
                            }
                        }
                    }
                    
                    importResult = ImportResult.Success(totalSuccess, totalFail, errors)
                    showImportResult = true
                    statistics = dataManager.getDataStatistics()
                } catch (e: Exception) {
                    importResult = ImportResult.Error("批量导入失败: ${e.message}")
                    showImportResult = true
                } finally {
                    isLoading = false
                }
            }
        }
    }
    
    // 加载统计数据
    LaunchedEffect(Unit) {
        statistics = dataManager.getDataStatistics()
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("📊 训练数据管理") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "返回")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 数据统计卡片
            DataStatisticsCard(statistics)
            
            // 🆕 改进的数据操作卡片
            ImprovedDataOperationsCard(
                onImportSingleFile = {
                    // 打开单文件选择器
                    filePicker.launch(arrayOf("application/json", "*/*"))
                },
                onImportMultipleFiles = {
                    // 打开多文件选择器
                    multiFilePicker.launch(arrayOf("application/json", "*/*"))
                },
                onImportFromFolder = {
                    // 从应用目录导入
                    scope.launch {
                        isLoading = true
                        try {
                            val importDir = File(context.getExternalFilesDir(null), "import_training_data")
                            if (!importDir.exists()) importDir.mkdirs()
                            
                            if (importDir.listFiles()?.isEmpty() != false) {
                                importResult = ImportResult.Error(
                                    "请先将训练数据文件放入：\n${importDir.absolutePath}"
                                )
                            } else {
                                val result = dataManager.importTrainingDataFromFolder(importDir)
                                importResult = result
                            }
                            showImportResult = true
                            statistics = dataManager.getDataStatistics()
                        } finally {
                            isLoading = false
                        }
                    }
                },
                onExportData = {
                    scope.launch {
                        isLoading = true
                        try {
                            val exportDir = File(context.getExternalFilesDir(null), "exported_data")
                            if (!exportDir.exists()) exportDir.mkdirs()
                            
                            val file = dataManager.exportTrainingData(exportDir)
                            if (file != null) {
                                importResult = ImportResult.Success(
                                    successCount = 1,
                                    failCount = 0,
                                    errors = listOf("数据已导出到：${file.absolutePath}")
                                )
                            } else {
                                importResult = ImportResult.Error("导出失败：没有可导出的数据")
                            }
                            showImportResult = true
                        } finally {
                            isLoading = false
                        }
                    }
                },
                onClearData = {
                    scope.launch {
                        dataManager.clearAllData()
                        kotlinx.coroutines.delay(500)
                        statistics = dataManager.getDataStatistics()
                    }
                },
                isLoading = isLoading
            )
            
            // 使用说明卡片
            DataManagerUsageGuideCard()
        }
    }
    
    // 导入结果对话框
    if (showImportResult) {
        importResult?.let { result ->
            ImportResultDialog(
                result = result,
                onDismiss = { showImportResult = false }
            )
        }
    }
}

/**
 * 数据统计卡片
 */
@Composable
fun DataStatisticsCard(statistics: DataStatistics?) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "📈 数据统计",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            HorizontalDivider()
            
            if (statistics != null) {
                DataManagerStatisticRow("📝 总对话数", "${statistics.totalConversations} 条")
                DataManagerStatisticRow("🧹 已清洗数据", "${statistics.cleanedConversations} 条")
                DataManagerStatisticRow("🎓 训练记录", "${statistics.trainingRecords} 条")
                DataManagerStatisticRow("💾 数据大小", "%.2f MB".format(statistics.getDataSizeMB()))
                
                if (statistics.lastUpdated > 0) {
                    val dateFormat = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.CHINA)
                    DataManagerStatisticRow("🕐 最后更新", dateFormat.format(java.util.Date(statistics.lastUpdated)))
                }
            } else {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.CenterHorizontally))
            }
        }
    }
}

/**
 * 统计行
 */
@Composable
fun DataManagerStatisticRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium)
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold
        )
    }
}

/**
 * 数据操作卡片
 */
@Composable
fun DataOperationsCard(
    onImportFolder: () -> Unit,
    onExportData: () -> Unit,
    onClearData: () -> Unit,
    isLoading: Boolean
) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "⚙️ 数据操作",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            Divider()
            
            // 批量导入按钮
            Button(
                onClick = onImportFolder,
                modifier = Modifier.fillMaxWidth(),
                enabled = !isLoading
            ) {
                Icon(Icons.Default.Upload, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("📁 批量导入训练数据")
            }
            
            Text(
                text = "支持从文件夹批量导入 .jsonl 和 .json 格式的训练数据",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            
            // 导出数据按钮
            OutlinedButton(
                onClick = onExportData,
                modifier = Modifier.fillMaxWidth(),
                enabled = !isLoading
            ) {
                Icon(Icons.Default.Download, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("📤 导出训练数据")
            }
            
            // 清除数据按钮
            var showConfirmDialog by remember { mutableStateOf(false) }
            
            OutlinedButton(
                onClick = { showConfirmDialog = true },
                modifier = Modifier.fillMaxWidth(),
                enabled = !isLoading,
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = MaterialTheme.colorScheme.error
                )
            ) {
                Icon(Icons.Default.Delete, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("🗑️ 清除所有数据")
            }
            
            // 确认对话框
            if (showConfirmDialog) {
                AlertDialog(
                    onDismissRequest = { showConfirmDialog = false },
                    title = { Text("⚠️ 确认清除") },
                    text = { Text("确定要清除所有训练数据吗？此操作无法撤销！") },
                    confirmButton = {
                        TextButton(
                            onClick = {
                                showConfirmDialog = false
                                onClearData()
                            }
                        ) {
                            Text("确定")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showConfirmDialog = false }) {
                            Text("取消")
                        }
                    }
                )
            }
            
            if (isLoading) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

/**
 * 使用说明卡片
 */
@Composable
fun DataManagerUsageGuideCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "💡 使用说明",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            Divider()
            
            Text(
                text = "📁 批量导入训练数据：",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "1. 将训练数据文件（.jsonl 或 .json）放入手机存储的应用目录\n" +
                      "2. 路径：Android/data/com.example.xihe/files/import_training_data/\n" +
                      "3. 点击「批量导入」按钮自动扫描并导入所有文件",
                style = MaterialTheme.typography.bodySmall
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "📝 支持的数据格式：",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "1. OpenAI格式：{\"messages\": [{\"role\": \"user\", \"content\": \"...\"}, ...]}\n" +
                      "2. 简单格式：{\"input\": \"用户输入\", \"output\": \"系统回复\"}",
                style = MaterialTheme.typography.bodySmall
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "🤖 自动保存：",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "所有与AI的对话都会自动保存为训练数据，并进行智能清洗（纠错、脱敏、格式化）",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

/**
 * 导入结果对话框
 */
@Composable
fun ImportResultDialog(
    result: ImportResult,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                when (result) {
                    is ImportResult.Success -> "✅ 导入成功"
                    is ImportResult.Error -> "❌ 导入失败"
                }
            )
        },
        text = {
            Column {
                when (result) {
                    is ImportResult.Success -> {
                        Text("成功导入 ${result.successCount} 条数据")
                        if (result.failCount > 0) {
                            Text("\n失败 ${result.failCount} 条")
                        }
                        if (result.errors.isNotEmpty()) {
                            Text("\n\n错误详情：")
                            result.errors.take(5).forEach { error ->
                                Text("• $error", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    is ImportResult.Error -> {
                        Text(result.message)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("确定")
            }
        }
    )
}

// ==================== 🆕 改进的组件 ====================

/**
 * 🆕 改进的数据操作卡片 - 支持多种导入方式
 */
@Composable
fun ImprovedDataOperationsCard(
    onImportSingleFile: () -> Unit,
    onImportMultipleFiles: () -> Unit,
    onImportFromFolder: () -> Unit,
    onExportData: () -> Unit,
    onClearData: () -> Unit,
    isLoading: Boolean
) {
    var showImportMenu by remember { mutableStateOf(false) }
    var showConfirmDialog by remember { mutableStateOf(false) }
    
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "⚙️ 数据操作",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            HorizontalDivider()
            
            // 🆕 导入按钮（带下拉菜单）
            Box {
                Button(
                    onClick = { showImportMenu = true },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isLoading
                ) {
                    Icon(Icons.Default.Upload, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("📁 导入训练数据")
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                }
                
                // 导入方式下拉菜单
                DropdownMenu(
                    expanded = showImportMenu,
                    onDismissRequest = { showImportMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { 
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.InsertDriveFile, contentDescription = null, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("选择单个文件")
                            }
                        },
                        onClick = {
                            showImportMenu = false
                            onImportSingleFile()
                        }
                    )
                    DropdownMenuItem(
                        text = { 
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.FileCopy, contentDescription = null, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("选择多个文件")
                            }
                        },
                        onClick = {
                            showImportMenu = false
                            onImportMultipleFiles()
                        }
                    )
                    HorizontalDivider()
                    DropdownMenuItem(
                        text = { 
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Folder, contentDescription = null, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("从应用目录导入")
                            }
                        },
                        onClick = {
                            showImportMenu = false
                            onImportFromFolder()
                        }
                    )
                }
            }
            
            Text(
                text = "支持 .jsonl 和 .json 格式的训练数据文件",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            
            // 导出数据按钮
            OutlinedButton(
                onClick = onExportData,
                modifier = Modifier.fillMaxWidth(),
                enabled = !isLoading
            ) {
                Icon(Icons.Default.Download, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("📤 导出训练数据")
            }
            
            // 清除数据按钮
            OutlinedButton(
                onClick = { showConfirmDialog = true },
                modifier = Modifier.fillMaxWidth(),
                enabled = !isLoading,
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = MaterialTheme.colorScheme.error
                )
            ) {
                Icon(Icons.Default.Delete, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("🗑️ 清除所有数据")
            }
            
            // 确认对话框
            if (showConfirmDialog) {
                AlertDialog(
                    onDismissRequest = { showConfirmDialog = false },
                    title = { Text("⚠️ 确认清除") },
                    text = { Text("确定要清除所有训练数据吗？此操作无法撤销！") },
                    confirmButton = {
                        TextButton(
                            onClick = {
                                showConfirmDialog = false
                                onClearData()
                            }
                        ) {
                            Text("确定", color = MaterialTheme.colorScheme.error)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showConfirmDialog = false }) {
                            Text("取消")
                        }
                    }
                )
            }
            
            if (isLoading) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

/**
 * 🆕 从 Uri 导入数据的辅助函数
 */
private suspend fun importFromUri(
    context: android.content.Context,
    dataManager: ConversationDataManager,
    uri: Uri
): ImportResult = withContext(Dispatchers.IO) {
    try {
        val contentResolver = context.contentResolver
        val inputStream = contentResolver.openInputStream(uri)
            ?: return@withContext ImportResult.Error("无法打开文件")
        
        val reader = BufferedReader(InputStreamReader(inputStream))
        val content = reader.readText()
        reader.close()
        
        // 获取文件名用于日志
        val fileName = uri.lastPathSegment ?: "unknown"
        
        // 解析并导入数据
        var successCount = 0
        var failCount = 0
        val errors = mutableListOf<String>()
        
        // 尝试作为 JSONL 处理（每行一个JSON）
        val lines = content.split("\n").filter { it.isNotBlank() }
        
        if (lines.size > 1 || content.trim().startsWith("{")) {
            // JSONL 或单个 JSON 对象
            for ((index, line) in lines.withIndex()) {
                try {
                    if (line.isBlank()) continue
                    
                    // 尝试导入这行数据
                    val imported = dataManager.importSingleRecord(line.trim())
                    if (imported) {
                        successCount++
                    } else {
                        failCount++
                        if (errors.size < 5) {
                            errors.add("第${index + 1}行: 格式不正确")
                        }
                    }
                } catch (e: Exception) {
                    failCount++
                    if (errors.size < 5) {
                        errors.add("第${index + 1}行: ${e.message}")
                    }
                }
            }
        } else if (content.trim().startsWith("[")) {
            // JSON 数组
            try {
                val count = dataManager.importFromJsonArray(content)
                successCount = count
            } catch (e: Exception) {
                return@withContext ImportResult.Error("JSON数组解析失败: ${e.message}")
            }
        }
        
        if (successCount > 0) {
            ImportResult.Success(successCount, failCount, errors)
        } else if (failCount > 0) {
            ImportResult.Error("导入失败，共 $failCount 条错误")
        } else {
            ImportResult.Error("文件中没有有效的训练数据")
        }
        
    } catch (e: Exception) {
        ImportResult.Error("读取文件失败: ${e.message}")
    }
}
