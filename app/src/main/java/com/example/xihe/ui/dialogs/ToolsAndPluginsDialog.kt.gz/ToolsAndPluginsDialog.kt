package com.example.xihe.ui.dialogs

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.xihe.tools.ToolRegistry
import com.example.xihe.ui.theme.DeepSpaceBlue
import com.example.xihe.ui.theme.NeonCyan
import com.example.xihe.ui.utils.rememberHapticFeedback

/**
 * 🔧 工具与插件对话框
 * 
 * 从 SettingsDialogs.kt 中提取
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ToolsAndPluginsDialog(onDismiss: () -> Unit) {
    val haptic = rememberHapticFeedback()
    val tools = remember { ToolRegistry.getRegisteredTools() }
    
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<String?>(null) }
    
    // 获取所有分类
    val categories = remember(tools) {
        tools.map { it.category }.distinct().sorted()
    }
    
    // 过滤工具
    val filteredTools = remember(tools, searchQuery, selectedCategory) {
        tools.filter { tool ->
            val matchesSearch = searchQuery.isEmpty() || 
                tool.name.contains(searchQuery, ignoreCase = true) ||
                tool.description.contains(searchQuery, ignoreCase = true)
            val matchesCategory = selectedCategory == null || tool.category == selectedCategory
            matchesSearch && matchesCategory
        }
    }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { 
            Text("🔧 工具与插件", color = Color.White, fontWeight = FontWeight.Bold) 
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                // 搜索框
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("搜索工具...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color.Gray) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = DeepSpaceBlue.Secondary,
                        unfocusedContainerColor = DeepSpaceBlue.Secondary
                    )
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // 分类筛选
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    FilterChip(
                        selected = selectedCategory == null,
                        onClick = { 
                            haptic.lightTap()
                            selectedCategory = null 
                        },
                        label = { Text("全部", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NeonCyan.Primary.copy(alpha = 0.3f)
                        )
                    )
                    categories.take(3).forEach { category ->
                        FilterChip(
                            selected = selectedCategory == category,
                            onClick = { 
                                haptic.lightTap()
                                selectedCategory = category 
                            },
                            label = { Text(category, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NeonCyan.Primary.copy(alpha = 0.3f)
                            )
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                
                // 工具列表
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 400.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredTools) { tool ->
                        ToolItem(
                            name = tool.name,
                            description = tool.description,
                            category = tool.category,
                            isEnabled = tool.isEnabled
                        )
                    }
                    
                    if (filteredTools.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "没有找到匹配的工具",
                                    color = Color.Gray,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // 统计信息
                Text(
                    "共 ${tools.size} 个工具，已启用 ${tools.count { it.isEnabled }} 个",
                    color = Color.Gray,
                    fontSize = 12.sp
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                haptic.lightTap()
                onDismiss()
            }) {
                Text("关闭", color = NeonCyan.Primary)
            }
        },
        containerColor = DeepSpaceBlue.Secondary
    )
}

@Composable
private fun ToolItem(
    name: String,
    description: String,
    category: String,
    isEnabled: Boolean
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isEnabled) 
                DeepSpaceBlue.Tertiary 
            else 
                DeepSpaceBlue.Tertiary.copy(alpha = 0.5f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 状态图标
            Icon(
                if (isEnabled) Icons.Default.CheckCircle else Icons.Default.Cancel,
                contentDescription = null,
                tint = if (isEnabled) Color(0xFF4CAF50) else Color.Gray,
                modifier = Modifier.size(24.dp)
            )
            
            Spacer(modifier = Modifier.width(12.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        name,
                        color = Color.White,
                        fontWeight = FontWeight.Medium,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        category,
                        color = NeonCyan.Primary,
                        fontSize = 10.sp
                    )
                }
                Text(
                    description,
                    color = Color.Gray,
                    fontSize = 12.sp,
                    maxLines = 2
                )
            }
        }
    }
}
