package com.example.xihe.ui.components

import android.annotation.SuppressLint
import android.graphics.Color
import com.example.xihe.utils.LogManager
import android.view.ViewGroup
import android.webkit.*
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay

/**
 * 🌐 HTML 实时渲染组件
 * 
 * 功能：
 * 1. 渲染 AI 输出的 HTML 内容
 * 2. 支持 CSS 样式
 * 3. 支持 JavaScript 交互
 * 4. 支持代码高亮
 * 5. 支持全屏预览
 */
@Composable
fun HtmlRenderer(
    htmlContent: String,
    modifier: Modifier = Modifier,
    enableJavaScript: Boolean = true,
    showToolbar: Boolean = true,
    onError: ((String) -> Unit)? = null
) {
    var isFullScreen by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(true) }
    var showCode by remember { mutableStateOf(false) }
    
    // 包装 HTML 内容
    val wrappedHtml = remember(htmlContent) {
        wrapHtmlContent(htmlContent)
    }
    
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column {
            // 工具栏
            if (showToolbar) {
                HtmlToolbar(
                    isFullScreen = isFullScreen,
                    showCode = showCode,
                    onToggleFullScreen = { isFullScreen = !isFullScreen },
                    onToggleCode = { showCode = !showCode },
                    onRefresh = { isLoading = true }
                )
            }
            
            // 内容区域
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .then(
                        if (isFullScreen) Modifier.fillMaxHeight()
                        else Modifier.heightIn(min = 200.dp, max = 400.dp)
                    )
            ) {
                // 显示代码或渲染结果
                if (showCode) {
                    // 显示原始 HTML 代码
                    HtmlCodeView(htmlContent)
                } else {
                    // WebView 渲染
                    HtmlWebView(
                        html = wrappedHtml,
                        enableJavaScript = enableJavaScript,
                        onLoadingChanged = { isLoading = it },
                        onError = onError
                    )
                }
                
                // 加载指示器
                if (isLoading && !showCode) {
                    CircularProgressIndicator(
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
            }
        }
    }
}

/**
 * 🔧 HTML 工具栏
 */
@Composable
private fun HtmlToolbar(
    isFullScreen: Boolean,
    showCode: Boolean,
    onToggleFullScreen: () -> Unit,
    onToggleCode: () -> Unit,
    onRefresh: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        tonalElevation = 2.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "🌐 HTML 预览",
                style = MaterialTheme.typography.labelMedium
            )
            
            Row {
                // 查看代码
                IconButton(onClick = onToggleCode, modifier = Modifier.size(32.dp)) {
                    Icon(
                        imageVector = if (showCode) Icons.Default.Visibility else Icons.Default.Code,
                        contentDescription = if (showCode) "查看预览" else "查看代码",
                        modifier = Modifier.size(18.dp)
                    )
                }
                
                // 刷新
                IconButton(onClick = onRefresh, modifier = Modifier.size(32.dp)) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "刷新",
                        modifier = Modifier.size(18.dp)
                    )
                }
                
                // 全屏
                IconButton(onClick = onToggleFullScreen, modifier = Modifier.size(32.dp)) {
                    Icon(
                        imageVector = if (isFullScreen) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                        contentDescription = if (isFullScreen) "退出全屏" else "全屏",
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

/**
 * 📝 HTML 代码视图
 */
@Composable
private fun HtmlCodeView(htmlContent: String) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.fillMaxSize()
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(
                text = htmlContent,
                style = MaterialTheme.typography.bodySmall,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
            )
        }
    }
}

/**
 * 🌐 WebView 渲染组件
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun HtmlWebView(
    html: String,
    enableJavaScript: Boolean,
    onLoadingChanged: (Boolean) -> Unit,
    onError: ((String) -> Unit)?
) {
    val context = LocalContext.current
    
    AndroidView(
        factory = { ctx ->
            WebView(ctx).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                
                setBackgroundColor(Color.TRANSPARENT)
                
                settings.apply {
                    javaScriptEnabled = enableJavaScript
                    domStorageEnabled = true
                    loadWithOverviewMode = true
                    useWideViewPort = true
                    builtInZoomControls = true
                    displayZoomControls = false
                    setSupportZoom(true)
                    defaultTextEncodingName = "UTF-8"
                    
                    // 允许混合内容
                    mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                }
                
                webViewClient = object : WebViewClient() {
                    override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                        super.onPageStarted(view, url, favicon)
                        onLoadingChanged(true)
                    }
                    
                    override fun onPageFinished(view: WebView?, url: String?) {
                        super.onPageFinished(view, url)
                        onLoadingChanged(false)
                    }
                    
                    override fun onReceivedError(
                        view: WebView?,
                        request: WebResourceRequest?,
                        error: WebResourceError?
                    ) {
                        super.onReceivedError(view, request, error)
                        onError?.invoke("加载错误: ${error?.description}")
                        LogManager.w("HtmlRenderer", "WebView Error: ${error?.description}")
                    }
                }
                
                webChromeClient = object : WebChromeClient() {
                    override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                        LogManager.w("HtmlRenderer", "JS Console: ${consoleMessage?.message()}")
                        return true
                    }
                }
            }
        },
        update = { webView ->
            webView.loadDataWithBaseURL(
                null,
                html,
                "text/html",
                "UTF-8",
                null
            )
        },
        modifier = Modifier.fillMaxSize()
    )
}

/**
 * 📦 包装 HTML 内容
 * 添加基础样式和响应式支持
 */
private fun wrapHtmlContent(content: String): String {
    // 检查是否已经是完整的 HTML 文档
    val isCompleteHtml = content.contains("<html", ignoreCase = true) ||
                         content.contains("<!DOCTYPE", ignoreCase = true)
    
    return if (isCompleteHtml) {
        // 已经是完整的 HTML，只添加 viewport
        content.replace(
            "<head>",
            """<head>
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
            """
        )
    } else {
        // 包装为完整的 HTML 文档
        """
        <!DOCTYPE html>
        <html lang="zh-CN">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                * {
                    box-sizing: border-box;
                    margin: 0;
                    padding: 0;
                }
                
                body {
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 
                                 'Helvetica Neue', Arial, sans-serif;
                    font-size: 14px;
                    line-height: 1.6;
                    color: #333;
                    padding: 16px;
                    background-color: #fff;
                }
                
                h1, h2, h3, h4, h5, h6 {
                    margin-bottom: 12px;
                    font-weight: 600;
                }
                
                h1 { font-size: 24px; }
                h2 { font-size: 20px; }
                h3 { font-size: 18px; }
                
                p {
                    margin-bottom: 12px;
                }
                
                a {
                    color: #2196F3;
                    text-decoration: none;
                }
                
                a:hover {
                    text-decoration: underline;
                }
                
                img {
                    max-width: 100%;
                    height: auto;
                    border-radius: 8px;
                }
                
                table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-bottom: 16px;
                }
                
                th, td {
                    border: 1px solid #ddd;
                    padding: 8px;
                    text-align: left;
                }
                
                th {
                    background-color: #f5f5f5;
                    font-weight: 600;
                }
                
                tr:nth-child(even) {
                    background-color: #fafafa;
                }
                
                code {
                    background-color: #f5f5f5;
                    padding: 2px 6px;
                    border-radius: 4px;
                    font-family: 'Fira Code', 'Consolas', monospace;
                    font-size: 13px;
                }
                
                pre {
                    background-color: #282c34;
                    color: #abb2bf;
                    padding: 16px;
                    border-radius: 8px;
                    overflow-x: auto;
                    margin-bottom: 16px;
                }
                
                pre code {
                    background-color: transparent;
                    padding: 0;
                    color: inherit;
                }
                
                blockquote {
                    border-left: 4px solid #2196F3;
                    padding-left: 16px;
                    margin: 16px 0;
                    color: #666;
                }
                
                ul, ol {
                    padding-left: 24px;
                    margin-bottom: 12px;
                }
                
                li {
                    margin-bottom: 4px;
                }
                
                .card {
                    background: #fff;
                    border-radius: 12px;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                    padding: 16px;
                    margin-bottom: 16px;
                }
                
                .button {
                    display: inline-block;
                    padding: 8px 16px;
                    background-color: #2196F3;
                    color: white;
                    border: none;
                    border-radius: 8px;
                    cursor: pointer;
                    font-size: 14px;
                }
                
                .button:hover {
                    background-color: #1976D2;
                }
                
                .success { color: #4CAF50; }
                .warning { color: #FF9800; }
                .error { color: #F44336; }
                .info { color: #2196F3; }
                
                /* 动画 */
                @keyframes fadeIn {
                    from { opacity: 0; }
                    to { opacity: 1; }
                }
                
                .fade-in {
                    animation: fadeIn 0.5s ease-in;
                }
            </style>
        </head>
        <body>
            $content
        </body>
        </html>
        """.trimIndent()
    }
}

/**
 * 🎯 检测文本中是否包含 HTML 内容
 */
fun containsHtml(text: String): Boolean {
    val htmlPatterns = listOf(
        "<html",
        "<!DOCTYPE",
        "<div",
        "<span",
        "<table",
        "<ul>",
        "<ol>",
        "<p>",
        "<h1>",
        "<h2>",
        "<h3>",
        "<style>",
        "<script>"
    )
    
    return htmlPatterns.any { text.contains(it, ignoreCase = true) }
}

/**
 * 📝 从 AI 响应中提取 HTML 代码块
 */
fun extractHtmlFromResponse(response: String): String? {
    // 匹配 ```html ... ``` 代码块
    val htmlBlockRegex = "```html\\s*([\\s\\S]*?)```".toRegex(RegexOption.IGNORE_CASE)
    val match = htmlBlockRegex.find(response)
    
    if (match != null) {
        return match.groupValues[1].trim()
    }
    
    // 检查是否直接包含 HTML
    if (containsHtml(response)) {
        // 尝试提取 <html>...</html> 或 <body>...</body>
        val htmlDocRegex = "<html[^>]*>[\\s\\S]*</html>".toRegex(RegexOption.IGNORE_CASE)
        val bodyRegex = "<body[^>]*>[\\s\\S]*</body>".toRegex(RegexOption.IGNORE_CASE)
        
        htmlDocRegex.find(response)?.let { return it.value }
        bodyRegex.find(response)?.let { return it.value }
        
        // 如果有明显的 HTML 标签，返回整个响应
        if (response.contains("<div") || response.contains("<table")) {
            return response
        }
    }
    
    return null
}

/**
 * 🌐 智能消息渲染组件
 * 自动检测并渲染 HTML 内容
 */
@Composable
fun SmartMessageRenderer(
    message: String,
    modifier: Modifier = Modifier
) {
    val htmlContent = remember(message) { extractHtmlFromResponse(message) }
    
    if (htmlContent != null) {
        Column(modifier = modifier) {
            // 如果消息中还有非 HTML 文本，先显示
            val nonHtmlPart = message.replace("```html", "")
                .replace("```", "")
                .replace(htmlContent, "")
                .trim()
            
            if (nonHtmlPart.isNotEmpty()) {
                Text(
                    text = nonHtmlPart,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }
            
            // 渲染 HTML
            HtmlRenderer(
                htmlContent = htmlContent,
                modifier = Modifier.fillMaxWidth()
            )
        }
    } else {
        // 普通文本
        Text(
            text = message,
            style = MaterialTheme.typography.bodyMedium,
            modifier = modifier
        )
    }
}
