package com.example.xihe.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.xihe.training.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

/**
 * 🧠 训练监控界面
 * 查看训练状态、历史记录和模型性能
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrainingMonitorScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    var isTraining by remember { mutableStateOf(false) }
    var trainingProgress by remember { mutableStateOf(TrainingProgress("待机")) }
    var trainingStats by remember { mutableStateOf(TrainingStatistics()) }
    var autoTrainingEnabled by remember { mutableStateOf(true) }
    
    // 加载训练统计
    LaunchedEffect(Unit) {
        trainingStats = TrainingStateManager.getStatistics()
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("AI训练监控") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "返回")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground,
                    navigationIconContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 自动训练开关
            AutoTrainingCard(
                enabled = autoTrainingEnabled,
                onToggle = { enabled ->
                    autoTrainingEnabled = enabled
                    if (enabled) {
                        AutoTrainingWorker.schedule(context)
                    } else {
                        AutoTrainingWorker.cancel(context)
                    }
                }
            )
            
            // 当前训练状态
            if (isTraining) {
                TrainingProgressCard(progress = trainingProgress)
            }
            
            // 训练统计
            TrainingStatisticsCard(stats = trainingStats)
            
            // 训练说明
            TrainingInfoCard()
            
            // 操作按钮
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // 手动训练
                Button(
                    onClick = {
                        scope.launch {
                            isTraining = true
                            val trainer = LocalModelTrainer.getInstance(context)
                            
                            trainer.startTraining { progress ->
                                trainingProgress = progress
                            }
                            
                            isTraining = false
                            trainingStats = TrainingStateManager.getStatistics()
                        }
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    enabled = !isTraining
                ) {
                    Icon(
                        Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("立即训练", color = MaterialTheme.colorScheme.onPrimary)
                }
                
                // 停止训练
                OutlinedButton(
                    onClick = {
                        LocalModelTrainer.getInstance(context).pauseTraining()
                        isTraining = false
                    },
                    modifier = Modifier.weight(1f),
                    enabled = isTraining
                ) {
                    Icon(Icons.Default.Stop, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("停止")
                }
            }

            // 调试区域
            /*
            OutlinedButton(
                onClick = {
                    // Reset Logic here if needed
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("重置统计 (Debug)")
            }
            */
        }
    }
}

@Composable
fun AutoTrainingCard(
    enabled: Boolean,
    onToggle: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "🤖 自动训练",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (enabled) "充电时自动训练模型" else "已关闭",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(
                checked = enabled,
                onCheckedChange = onToggle,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = MaterialTheme.colorScheme.primary,
                    checkedTrackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                )
            )
        }
    }
}

@Composable
fun TrainingProgressCard(progress: TrainingProgress) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "⚡ 正在训练",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = if (progress.totalEpochs > 0) 
                        "${progress.epoch}/${progress.totalEpochs}" 
                    else "",
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            
            Text(
                text = progress.stage,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            
            LinearProgressIndicator(
                progress = progress.progress,
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surface
            )
            
            Text(
                text = "${(progress.progress * 100).toInt()}%",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun TrainingStatisticsCard(stats: TrainingStatistics) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "📊 训练统计",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            
            StatRow("训练次数", "${stats.totalSessions} 次")
            StatRow("总轮数", "${stats.totalEpochs} 轮")
            StatRow("平均准确率", "${(stats.averageAccuracy * 100).toInt()}%")
            StatRow("成功率", "${(stats.successRate * 100).toInt()}%")
            
            if (stats.lastTrainingTime > 0) {
                val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
                val lastTime = dateFormat.format(Date(stats.lastTrainingTime))
                StatRow("上次训练", lastTime)
            }
        }
    }
}

@Composable
fun StatRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
fun TrainingInfoCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "💡 关于本地训练",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = """
                    羲和会在以下条件下自动训练：
                    
                    ✅ 手机正在充电
                    ✅ 电量 > 50%
                    ✅ 设备空闲（无其他应用运行）
                    ✅ 温度正常（< 40°C）
                    ✅ 对话数据 > 100条
                    
                    训练使用轻量级模型，不会影响手机性能。
                    你的专属羲和AI会越来越懂你！
                """.trimIndent(),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
