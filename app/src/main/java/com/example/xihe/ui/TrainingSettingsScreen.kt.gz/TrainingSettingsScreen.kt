package com.example.xihe.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.xihe.service.TrainingKeepAliveService

/**
 * ⚙️ 训练设置界面
 * 
 * 功能：
 * 1. 后台保活开关
 * 2. 自动训练设置
 * 3. 训练条件配置
 * 4. 通知设置
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrainingSettingsScreen(
    onBack: () -> Unit = {}
) {
    val context = LocalContext.current
    
    // 保活服务状态
    var serviceEnabled by remember { 
        mutableStateOf(TrainingKeepAliveService.isEnabled(context))
    }
    var serviceRunning by remember { 
        mutableStateOf(TrainingKeepAliveService.isRunning(context))
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("⚙️ 训练设置") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "返回")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. 重要提示卡片
            ImportantTipCard()
            
            // 2. 后台保活设置
            KeepAliveSettingCard(
                serviceEnabled = serviceEnabled,
                serviceRunning = serviceRunning,
                onToggle = { enabled ->
                    if (enabled) {
                        TrainingKeepAliveService.start(context)
                    } else {
                        TrainingKeepAliveService.stop(context)
                    }
                    serviceEnabled = enabled
                    serviceRunning = enabled
                }
            )
            
            // 3. 训练条件说明
            TrainingConditionsCard()
            
            // 4. 电池优化提示
            BatteryOptimizationCard()
            
            // 5. 使用说明
            UsageGuideCard()
        }
    }
}

/**
 * 💡 重要提示卡片
 */
@Composable
fun ImportantTipCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    Icons.Default.Info,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "💡 关于后台训练",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            
            Divider()
            
            Text(
                text = """
                    羲和会在后台智能监控手机状态，当条件满足时自动开始训练：
                    
                    ✅ 你睡觉时（最佳时机）
                    ✅ 手机充电且空闲时
                    ✅ 温度和电量安全时
                    
                    完全不会影响你的日常使用！
                """.trimIndent(),
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

/**
 * 🔄 后台保活设置卡片
 */
@Composable
fun KeepAliveSettingCard(
    serviceEnabled: Boolean,
    serviceRunning: Boolean,
    onToggle: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "🔄 后台保活服务",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            Divider()
            
            // 服务状态
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "保持后台运行",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = if (serviceRunning) "✅ 服务运行中" else "⭕ 服务已停止",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (serviceRunning) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                }
                
                Switch(
                    checked = serviceEnabled,
                    onCheckedChange = onToggle
                )
            }
            
            // 说明
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = MaterialTheme.shapes.small
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "📌 开启后：",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "• 应用会保持在后台运行",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "• 持续监控训练时机",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "• 自动训练你的专属AI",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "• 通知栏会显示运行状态",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

/**
 * 📋 训练条件卡片
 */
@Composable
fun TrainingConditionsCard() {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "📋 自动训练条件",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            Divider()
            
            ConditionItem("🔋", "电池电量", "> 50%", true)
            ConditionItem("⚡", "充电状态", "充电中", true)
            ConditionItem("🌡️", "设备温度", "< 40°C", true)
            ConditionItem("💾", "可用内存", "> 30%", true)
            ConditionItem("😴", "用户状态", "睡觉/空闲", true)
            ConditionItem("📊", "训练数据", "> 100条", true)
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "✨ 所有条件满足时，羲和会自动开始学习",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

/**
 * 📱 电池优化提示卡片
 */
@Composable
fun BatteryOptimizationCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.tertiaryContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    Icons.Default.BatteryChargingFull,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.tertiary
                )
                Text(
                    text = "📱 电池优化建议",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            
            Divider()
            
            Text(
                text = """
                    为了保证后台服务稳定运行，建议：
                    
                    1️⃣ 关闭羲和的电池优化
                       设置 → 应用 → 羲和 → 电池 → 无限制
                    
                    2️⃣ 允许后台活动
                       设置 → 应用 → 羲和 → 后台限制 → 关闭
                    
                    3️⃣ 自启动权限
                       设置 → 应用 → 羲和 → 自启动 → 允许
                    
                    ⚠️ 不同手机品牌设置路径可能不同
                """.trimIndent(),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

/**
 * 📖 使用说明卡片
 */
@Composable
fun UsageGuideCard() {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "📖 使用说明",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            Divider()
            
            Text(
                text = """
                    🎯 推荐使用流程：
                    
                    1. 开启后台保活服务
                    2. 日常使用羲和，积累对话数据
                    3. 晚上睡觉前插上充电器
                    4. 睡觉时羲和自动训练
                    5. 早上醒来，羲和更懂你！
                    
                    💡 小贴士：
                    • 通知栏会显示运行状态
                    • 可以随时在"训练控制"查看详情
                    • 想停止服务就关闭开关即可
                    • 不会影响手机性能和续航
                """.trimIndent(),
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

/**
 * 条件项
 */
@Composable
fun ConditionItem(
    icon: String,
    label: String,
    value: String,
    isRequired: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(icon, style = MaterialTheme.typography.titleMedium)
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium
            )
        }
        
        Row(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            if (isRequired) {
                Icon(
                    Icons.Default.CheckCircle,
                    contentDescription = "必需",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
