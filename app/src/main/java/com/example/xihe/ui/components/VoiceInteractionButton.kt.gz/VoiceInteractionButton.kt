package com.example.xihe.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.xihe.interaction.VoiceInteractionManager

/**
 * 🎤 语音交互按钮组件
 * 
 * 功能:
 * 1. 点击开始语音识别
 * 2. 语音识别动画效果
 * 3. 识别结果显示
 * 4. 语音播报状态显示
 */
@Composable
fun VoiceInteractionButton(
    voiceState: VoiceInteractionManager.VoiceState,
    lastRecognizedText: String?,
    onStartListening: () -> Unit,
    onStopListening: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isListening = voiceState == VoiceInteractionManager.VoiceState.LISTENING
    val isSpeaking = voiceState == VoiceInteractionManager.VoiceState.SPEAKING
    val isProcessing = voiceState == VoiceInteractionManager.VoiceState.PROCESSING
    
    // 动画
    val pulseAnimation = rememberInfiniteTransition(label = "pulse")
    val scale by pulseAnimation.animateFloat(
        initialValue = 1f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(500),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )
    
    val buttonColor by animateColorAsState(
        targetValue = when {
            isListening -> MaterialTheme.colorScheme.error
            isSpeaking -> MaterialTheme.colorScheme.tertiary
            isProcessing -> MaterialTheme.colorScheme.secondary
            else -> MaterialTheme.colorScheme.primary
        },
        animationSpec = tween(300),
        label = "color"
    )
    
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // 状态文本
        Text(
            text = when (voiceState) {
                VoiceInteractionManager.VoiceState.LISTENING -> "🎤 正在聆听..."
                VoiceInteractionManager.VoiceState.SPEAKING -> "🔊 正在说话..."
                VoiceInteractionManager.VoiceState.PROCESSING -> "🤔 正在思考..."
                VoiceInteractionManager.VoiceState.ERROR -> "❌ 出错了"
                else -> "点击说话"
            },
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        
        // 语音按钮
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(80.dp)
                .scale(if (isListening) scale else 1f)
                .clip(CircleShape)
                .background(buttonColor)
                .clickable {
                    if (isListening) {
                        onStopListening()
                    } else {
                        onStartListening()
                    }
                }
        ) {
            Icon(
                imageVector = when {
                    isListening -> Icons.Default.Stop
                    isSpeaking -> Icons.Default.MicOff
                    else -> Icons.Default.Mic
                },
                contentDescription = if (isListening) "停止" else "开始语音",
                tint = Color.White,
                modifier = Modifier.size(36.dp)
            )
        }
        
        // 识别结果预览
        if (!lastRecognizedText.isNullOrBlank() && voiceState != VoiceInteractionManager.VoiceState.LISTENING) {
            Text(
                text = "\"${lastRecognizedText.take(30)}${if (lastRecognizedText.length > 30) "..." else ""}\"",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary,
                textAlign = TextAlign.Center,
                modifier = Modifier.widthIn(max = 200.dp)
            )
        }
    }
}

/**
 * 🎤 悬浮语音按钮
 * 可用于悬浮窗或主界面
 */
@Composable
fun FloatingVoiceButton(
    voiceState: VoiceInteractionManager.VoiceState,
    onStartListening: () -> Unit,
    onStopListening: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isListening = voiceState == VoiceInteractionManager.VoiceState.LISTENING
    
    // 脉冲动画
    val pulseAnimation = rememberInfiniteTransition(label = "pulse")
    val scale by pulseAnimation.animateFloat(
        initialValue = 1f,
        targetValue = if (isListening) 1.15f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )
    
    // 外圈动画
    val ringAlpha by pulseAnimation.animateFloat(
        initialValue = 0.6f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000),
            repeatMode = RepeatMode.Restart
        ),
        label = "ring"
    )
    
    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
    ) {
        // 外圈动画（仅在监听时显示）
        if (isListening) {
            Box(
                modifier = Modifier
                    .size(70.dp)
                    .scale(scale * 1.3f)
                    .border(
                        width = 2.dp,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = ringAlpha),
                        shape = CircleShape
                    )
            )
        }
        
        // 主按钮
        FloatingActionButton(
            onClick = {
                if (isListening) onStopListening() else onStartListening()
            },
            modifier = Modifier
                .size(56.dp)
                .scale(scale),
            containerColor = if (isListening) 
                MaterialTheme.colorScheme.error 
            else 
                MaterialTheme.colorScheme.primary
        ) {
            Icon(
                imageVector = if (isListening) Icons.Default.Stop else Icons.Default.Mic,
                contentDescription = if (isListening) "停止" else "语音",
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

/**
 * 🎤 语音状态指示条
 * 显示在输入框上方
 */
@Composable
fun VoiceStatusBar(
    voiceState: VoiceInteractionManager.VoiceState,
    recognizedText: String?,
    modifier: Modifier = Modifier
) {
    val isActive = voiceState != VoiceInteractionManager.VoiceState.IDLE
    
    if (!isActive && recognizedText.isNullOrBlank()) return
    
    // 波形动画
    val waveAnimation = rememberInfiniteTransition(label = "wave")
    val wave1 by waveAnimation.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(300),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wave1"
    )
    val wave2 by waveAnimation.animateFloat(
        initialValue = 0.5f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(400, delayMillis = 100),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wave2"
    )
    val wave3 by waveAnimation.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(350, delayMillis = 200),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wave3"
    )
    
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = when (voiceState) {
            VoiceInteractionManager.VoiceState.LISTENING -> MaterialTheme.colorScheme.primaryContainer
            VoiceInteractionManager.VoiceState.SPEAKING -> MaterialTheme.colorScheme.tertiaryContainer
            VoiceInteractionManager.VoiceState.PROCESSING -> MaterialTheme.colorScheme.secondaryContainer
            else -> MaterialTheme.colorScheme.surfaceVariant
        },
        tonalElevation = 2.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // 波形指示器
            if (voiceState == VoiceInteractionManager.VoiceState.LISTENING) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    repeat(5) { index ->
                        val height = when (index) {
                            0, 4 -> wave1
                            1, 3 -> wave2
                            else -> wave3
                        }
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .height((16 * height).dp)
                                .background(
                                    MaterialTheme.colorScheme.primary,
                                    shape = MaterialTheme.shapes.small
                                )
                        )
                    }
                }
            } else {
                Icon(
                    imageVector = when (voiceState) {
                        VoiceInteractionManager.VoiceState.SPEAKING -> Icons.Default.MicOff
                        VoiceInteractionManager.VoiceState.PROCESSING -> Icons.Default.Mic
                        else -> Icons.Default.Mic
                    },
                    contentDescription = null,
                    modifier = Modifier.size(20.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            
            // 状态/识别文本
            Text(
                text = when {
                    voiceState == VoiceInteractionManager.VoiceState.LISTENING -> "正在聆听..."
                    voiceState == VoiceInteractionManager.VoiceState.SPEAKING -> "正在回复..."
                    voiceState == VoiceInteractionManager.VoiceState.PROCESSING -> "正在处理..."
                    !recognizedText.isNullOrBlank() -> "\"$recognizedText\""
                    else -> ""
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
    }
}
