package com.example.xihe.ui

import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.xihe.core.AutomationEngine
import com.example.xihe.core.ModuleCoordinator
import com.example.xihe.core.PreferencesManager
import com.example.xihe.core.ProviderConfig
import com.example.xihe.core.ProviderRegistry
import com.example.xihe.tools.ToolRegistry
import com.example.xihe.ui.theme.DeepSpaceBlue
import com.example.xihe.ui.theme.NeonCyan
import com.example.xihe.ui.utils.rememberHapticFeedback
import com.example.xihe.interaction.VoiceprintManager
import com.example.xihe.interaction.VoiceprintConfig
import com.example.xihe.service.WakeWordService
import com.example.xihe.service.ServiceKeepAlive
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsMainMenu(
    onDismiss: () -> Unit,
    onNavigateToAIConfig: () -> Unit,
    onNavigateToPermissions: () -> Unit,
    onNavigateToPersonality: () -> Unit,
    onNavigateToPrivacy: () -> Unit,
    onNavigateToVoiceSettings: () -> Unit,
    onNavigateToTools: () -> Unit,
    onNavigateToExperimental: () -> Unit
) {
    val haptic = rememberHapticFeedback()
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("设置", color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                SettingsMenuItem(
                    icon = Icons.Default.Info,
                    title = "AI 配置",
                    onClick = {
                        haptic.lightTap()
                        onNavigateToAIConfig()
                    }
                )
                HorizontalDivider(color = Color.Gray.copy(alpha = 0.3f))
                SettingsMenuItem(
                    icon = Icons.Default.Lock,
                    title = "系统权限管理",
                    onClick = {
                        haptic.lightTap()
                        onNavigateToPermissions()
                    }
                )
                HorizontalDivider(color = Color.Gray.copy(alpha = 0.3f))
                SettingsMenuItem(
                    icon = Icons.Default.Security,
                    title = "🔐 隐私权限设置",
                    onClick = {
                        haptic.lightTap()
                        onNavigateToPrivacy()
                    }
                )
                HorizontalDivider(color = Color.Gray.copy(alpha = 0.3f))
                SettingsMenuItem(
                    icon = Icons.Default.Face,
                    title = "🎭 系统性格",
                    onClick = {
                        haptic.lightTap()
                        onNavigateToPersonality()
                    }
                )
                HorizontalDivider(color = Color.Gray.copy(alpha = 0.3f))
                SettingsMenuItem(
                    icon = Icons.Default.Mic,
                    title = "🎤 语音设置",
                    onClick = {
                        haptic.lightTap()
                        onNavigateToVoiceSettings()
                    }
                )
                HorizontalDivider(color = Color.Gray.copy(alpha = 0.3f))
                SettingsMenuItem(
                    icon = Icons.Default.Build,
                    title = "工具与插件",
                    onClick = {
                        haptic.lightTap()
                        onNavigateToTools()
                    }
                )
                HorizontalDivider(color = Color.Gray.copy(alpha = 0.3f))
                SettingsMenuItem(
                    icon = Icons.Default.Star,
                    title = "实验性功能",
                    onClick = {
                        haptic.lightTap()
                        onNavigateToExperimental()
                    }
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                haptic.lightTap()
                onDismiss()
            }) {
                Text("关闭")
            }
        },
        containerColor = DeepSpaceBlue.Secondary
    )
}

@Composable
fun SettingsMenuItem(icon: ImageVector, title: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 16.dp, horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = NeonCyan.Primary)
        Spacer(modifier = Modifier.width(16.dp))
        Text(title, color = Color.White, fontSize = 16.sp)
        Spacer(modifier = Modifier.weight(1f))
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = Color.Gray)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AIConfigDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val haptic = rememberHapticFeedback()
    
    // 🆕 初始化时加载当前活动的提供商
    val currentProviderId: String = remember { PreferencesManager.getCurrentProviderId(context) }
    val initialProvider: ProviderConfig = remember { 
        ProviderRegistry.getProviderById(currentProviderId) ?: ProviderRegistry.providers.first()
    }
    
    // 状态管理
    var selectedProvider by remember { mutableStateOf(initialProvider) }
    var baseUrl by remember { mutableStateOf(AutomationEngine.baseUrl) }
    var apiKey by remember { mutableStateOf(AutomationEngine.apiKey) }
    var selectedModel by remember { mutableStateOf(AutomationEngine.modelName) }
    var useManualModelInput by remember { mutableStateOf(false) } // 🆕 是否手动输入模型
    
    var availableModels by remember { mutableStateOf<List<String>>(emptyList()) }
    var isFetchingModels by remember { mutableStateOf(false) }
    var isTesting by remember { mutableStateOf(false) } // 🆕 测试连接状态
    var testResult by remember { mutableStateOf<String?>(null) } // 🆕 测试结果
    var fetchError by remember { mutableStateOf<String?>(null) }
    var expandedProvider by remember { mutableStateOf(false) }
    var expandedModel by remember { mutableStateOf(false) }
    
    // 🆕 自定义提供商对话框
    var showAddProviderDialog by remember { mutableStateOf(false) }
    var showEditProviderDialog by remember { mutableStateOf<ProviderConfig?>(null) }
    var providerToDelete by remember { mutableStateOf<ProviderConfig?>(null) }
    
    // 🆕 当提供商切换时，自动加载该提供商的独立配置
    LaunchedEffect(selectedProvider) {
        // 尝试加载该提供商的已保存配置
        val savedConfig = PreferencesManager.getProviderConfig(context, selectedProvider.id)
        
        if (savedConfig != null) {
            // 如果该提供商有保存的配置，加载它
            baseUrl = savedConfig.baseUrl
            apiKey = savedConfig.apiKey
            selectedModel = savedConfig.modelName
        } else {
            // 如果没有保存的配置，使用默认值
            baseUrl = selectedProvider.defaultBaseUrl
            apiKey = ""
            selectedModel = ""
        }
        
        // 清空模型列表和测试结果
        availableModels = emptyList()
        testResult = null
        fetchError = null
    }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { 
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("🤖 AI 配置", color = Color.White, fontWeight = FontWeight.Bold)
                // 🆕 添加自定义提供商按钮
                IconButton(onClick = { 
                    haptic.lightTap()
                    showAddProviderDialog = true 
                }) {
                    Icon(
                        Icons.Default.Add,
                        contentDescription = "添加自定义提供商",
                        tint = NeonCyan.Primary
                    )
                }
            }
        },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                // 提供商选择
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "提供商",
                        color = Color.Gray,
                        fontSize = 12.sp,
                        modifier = Modifier.weight(1f)
                    )
                    // 🆕 如果是自定义提供商，显示编辑/删除按钮
                    if (selectedProvider.isCustom) {
                        IconButton(
                            onClick = { 
                                haptic.lightTap()
                                showEditProviderDialog = selectedProvider 
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                Icons.Default.Edit,
                                contentDescription = "编辑",
                                tint = Color(0xFF64FFDA),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        IconButton(
                            onClick = { 
                                haptic.lightTap()
                                providerToDelete = selectedProvider 
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                Icons.Default.Delete,
                                contentDescription = "删除",
                                tint = Color(0xFFFF5252),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
                
                ExposedDropdownMenuBox(
                    expanded = expandedProvider,
                    onExpandedChange = { expandedProvider = !expandedProvider }
                ) {
                    OutlinedTextField(
                        value = selectedProvider.name,
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedProvider) },
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = DeepSpaceBlue.Secondary,
                            unfocusedContainerColor = DeepSpaceBlue.Secondary
                        )
                    )
                    ExposedDropdownMenu(
                        expanded = expandedProvider,
                        onDismissRequest = { expandedProvider = false }
                    ) {
                        ProviderRegistry.providers.forEach { provider ->
                            DropdownMenuItem(
                                text = { 
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(provider.name)
                                        if (provider.isCustom) {
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("✨", fontSize = 10.sp)
                                        }
                                    }
                                },
                                onClick = {
                                    selectedProvider = provider
                                    expandedProvider = false
                                    // 清空模型列表，强制重新获取
                                    availableModels = emptyList()
                                    useManualModelInput = false
                                }
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                
                // Base URL
                Text("基础链接 (Base URL)", color = Color.Gray, fontSize = 12.sp)
                OutlinedTextField(
                    value = baseUrl,
                    onValueChange = { baseUrl = it },
                    placeholder = { Text("https://api.example.com/v1/") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF112240),
                        unfocusedContainerColor = Color(0xFF112240)
                    )
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // API Key
                Text("API 密钥", color = Color.Gray, fontSize = 12.sp)
                OutlinedTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it },
                    placeholder = { Text("sk-...") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF112240),
                        unfocusedContainerColor = Color(0xFF112240)
                    )
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // 🆕 测试连接 + 获取模型 并排按钮
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // 🆕 测试连接按钮
                    Button(
                        onClick = {
                            if (apiKey.isNotEmpty() && baseUrl.isNotEmpty()) {
                                haptic.lightTap()
                                scope.launch {
                                    isTesting = true
                                    testResult = null
                                    try {
                                        withContext(Dispatchers.IO) {
                                            // 测试连接 - 尝试获取模型列表
                                            AutomationEngine.fetchModels(apiKey, baseUrl, selectedProvider.id)
                                        }
                                        testResult = "✅ 连接成功！"
                                    } catch (e: Exception) {
                                        testResult = "❌ 连接失败: ${e.message}"
                                    } finally {
                                        isTesting = false
                                    }
                                }
                            }
                        },
                        modifier = Modifier.weight(1f),
                        enabled = !isTesting && !isFetchingModels && apiKey.isNotEmpty() && baseUrl.isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF00BCD4)
                        )
                    ) {
                        if (isTesting) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White)
                        } else {
                            Text("🔍 测试连接")
                        }
                    }
                    
                    // 获取模型按钮
                    Button(
                        onClick = {
                            if (apiKey.isNotEmpty() && baseUrl.isNotEmpty()) {
                                haptic.lightTap()
                                scope.launch {
                                    isFetchingModels = true
                                    fetchError = null
                                    testResult = null
                                    try {
                                        val models = withContext(Dispatchers.IO) {
                                            AutomationEngine.fetchModels(apiKey, baseUrl, selectedProvider.id)
                                        }
                                        availableModels = models
                                        if (models.isNotEmpty()) {
                                            selectedModel = models.first()
                                            useManualModelInput = false
                                        } else {
                                            fetchError = "未找到模型"
                                            useManualModelInput = true
                                        }
                                    } catch (e: Exception) {
                                        fetchError = "错误: ${e.message}"
                                        useManualModelInput = true
                                    } finally {
                                        isFetchingModels = false
                                    }
                                }
                            }
                        },
                        modifier = Modifier.weight(1f),
                        enabled = !isFetchingModels && !isTesting && apiKey.isNotEmpty()
                    ) {
                        if (isFetchingModels) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.Black)
                        } else {
                            Text("📋 获取模型")
                        }
                    }
                }
                
                // 🆕 测试结果显示
                testResult?.let { result ->
                    Text(
                        text = result,
                        color = if (result.startsWith("✅")) Color(0xFF64FFDA) else Color(0xFFFF5252),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                
                fetchError?.let { error ->
                    Text(
                        text = error,
                        color = Color(0xFFFF5252),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                
                // 🆕 模型选择 - 支持手动输入
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "模型名称",
                        color = Color.Gray,
                        fontSize = 12.sp,
                        modifier = Modifier.weight(1f)
                    )
                    if (availableModels.isNotEmpty()) {
                        TextButton(
                            onClick = { 
                                haptic.lightTap()
                                useManualModelInput = !useManualModelInput 
                            },
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text(
                                if (useManualModelInput) "选择模型" else "手动输入",
                                color = NeonCyan.Primary,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
                
                // 模型输入/选择
                if (availableModels.isNotEmpty() && !useManualModelInput) {
                    // 下拉选择
                    ExposedDropdownMenuBox(
                        expanded = expandedModel,
                        onExpandedChange = { expandedModel = !expandedModel }
                    ) {
                        OutlinedTextField(
                            value = selectedModel,
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedModel) },
                            modifier = Modifier.menuAnchor().fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedContainerColor = Color(0xFF112240),
                                unfocusedContainerColor = Color(0xFF112240)
                            )
                        )
                        ExposedDropdownMenu(
                            expanded = expandedModel,
                            onDismissRequest = { expandedModel = false }
                        ) {
                            availableModels.forEach { model ->
                                DropdownMenuItem(
                                    text = { Text(model) },
                                    onClick = {
                                        selectedModel = model
                                        expandedModel = false
                                    }
                                )
                            }
                        }
                    }
                } else {
                    // 手动输入
                    OutlinedTextField(
                        value = selectedModel,
                        onValueChange = { selectedModel = it },
                        placeholder = { Text("例如: gpt-4o, gemini-pro") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color(0xFF112240),
                            unfocusedContainerColor = Color(0xFF112240)
                        )
                    )
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                
                // 💡 提示信息
                Text(
                    "💡 提示: 点击右上角 + 可添加自定义提供商",
                    color = Color(0xFF64FFDA),
                    fontSize = 10.sp,
                    lineHeight = 14.sp
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                haptic.lightTap()
                AutomationEngine.updateConfig(selectedProvider.id, baseUrl, apiKey, selectedModel, context)
                onDismiss()
            }) {
                Text("💾 保存并应用")
            }
        },
        dismissButton = {
            TextButton(onClick = {
                haptic.lightTap()
                onDismiss()
            }) {
                Text("取消")
            }
        },
        containerColor = Color(0xFF112240)
    )
    
    // 🆕 添加自定义提供商对话框
    if (showAddProviderDialog) {
        AddCustomProviderDialog(
            onDismiss = { showAddProviderDialog = false },
            onConfirm = { name, url ->
                val success = ProviderRegistry.addCustomProvider(context, name, url)
                if (success) {
                    android.widget.Toast.makeText(context, "✅ 提供商已添加", android.widget.Toast.LENGTH_SHORT).show()
                    showAddProviderDialog = false
                } else {
                    android.widget.Toast.makeText(context, "❌ 名称已存在", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
        )
    }
    
    // 🆕 编辑自定义提供商对话框
    showEditProviderDialog?.let { provider ->
        EditCustomProviderDialog(
            provider = provider,
            onDismiss = { showEditProviderDialog = null },
            onConfirm = { id, name, url ->
                val success = ProviderRegistry.updateCustomProvider(context, id, name, url)
                if (success) {
                    android.widget.Toast.makeText(context, "✅ 已更新", android.widget.Toast.LENGTH_SHORT).show()
                    showEditProviderDialog = null
                    // 更新当前选中的提供商
                    selectedProvider = ProviderRegistry.getProviderById(id) ?: selectedProvider
                } else {
                    android.widget.Toast.makeText(context, "❌ 更新失败", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
        )
    }
    
    // 🆕 删除确认对话框
    providerToDelete?.let { provider ->
        AlertDialog(
            onDismissRequest = { providerToDelete = null },
            title = { Text("确认删除", color = Color.White) },
            text = { Text("确定要删除提供商 \"${provider.name}\" 吗？", color = Color.White) },
            confirmButton = {
                Button(
                    onClick = {
                        val success = ProviderRegistry.deleteCustomProvider(context, provider.id)
                        android.widget.Toast.makeText(context, "🗑️ 已删除", android.widget.Toast.LENGTH_SHORT).show()
                        // 切换到第一个提供商
                        selectedProvider = ProviderRegistry.providers.first()
                        providerToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5252))
                ) {
                    Text("删除")
                }
            },
            dismissButton = {
                TextButton(onClick = { providerToDelete = null }) {
                    Text("取消")
                }
            },
            containerColor = Color(0xFF112240)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PermissionsDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    
    // 🔄 使用 mutableStateOf 实现实时刷新
    var refreshTrigger by remember { mutableStateOf(0) }
    
    // 检查各项权限状态（依赖 refreshTrigger 来触发重新计算）
    val hasAccessibility = remember(refreshTrigger) { 
        try {
            val enabledServices = android.provider.Settings.Secure.getString(
                context.contentResolver,
                android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            )
            enabledServices?.contains(context.packageName) == true
        } catch (e: Exception) { false }
    }
    
    val hasOverlay = remember(refreshTrigger) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else true
    }
    
    val hasRecordAudio = remember(refreshTrigger) {
        ContextCompat.checkSelfPermission(
            context, android.Manifest.permission.RECORD_AUDIO
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }
    
    val hasNotification = remember(refreshTrigger) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context, android.Manifest.permission.POST_NOTIFICATIONS
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        } else true
    }
    
    val hasFineLocation = remember(refreshTrigger) {
        ContextCompat.checkSelfPermission(
            context, android.Manifest.permission.ACCESS_FINE_LOCATION
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }
    
    val hasCoarseLocation = remember(refreshTrigger) {
        ContextCompat.checkSelfPermission(
            context, android.Manifest.permission.ACCESS_COARSE_LOCATION
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }
    
    val hasCamera = remember(refreshTrigger) {
        ContextCompat.checkSelfPermission(
            context, android.Manifest.permission.CAMERA
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }
    
    val hasStorage = remember(refreshTrigger) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            true // Android 11+ 使用 scoped storage
        } else {
            ContextCompat.checkSelfPermission(
                context, android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        }
    }
    
    val hasPhoneState = remember(refreshTrigger) {
        ContextCompat.checkSelfPermission(
            context, android.Manifest.permission.READ_PHONE_STATE
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }
    
    // 计算权限统计
    val allPermissions = listOf(
        hasAccessibility, hasOverlay, hasRecordAudio, hasNotification,
        hasFineLocation || hasCoarseLocation, hasCamera, hasStorage, hasPhoneState
    )
    val grantedCount = allPermissions.count { it }
    val totalCount = allPermissions.size
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { 
            Column {
                Text("🔒 系统权限管理", color = Color.White, fontWeight = FontWeight.Bold)
                Text(
                    "已授权 $grantedCount/$totalCount 项",
                    color = if (grantedCount == totalCount) Color(0xFF64FFDA) else Color(0xFFFFAB40),
                    fontSize = 12.sp
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // ⭐ 核心权限标题
                Text(
                    "⭐ 核心权限（必需）",
                    color = Color(0xFF64FFDA),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 8.dp, top = 4.dp)
                )
                
                // 🔐 无障碍服务
                PermissionItem(
                    icon = "♿",
                    title = "无障碍服务",
                    description = "核心功能，用于自动化操作",
                    isGranted = hasAccessibility,
                    onClick = {
                        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                        context.startActivity(intent)
                    }
                )
                
                // 🪟 悬浮窗权限
                PermissionItem(
                    icon = "🪟",
                    title = "悬浮窗权限",
                    description = "显示任务进度和快捷操作",
                    isGranted = hasOverlay,
                    onClick = {
                        val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
                        context.startActivity(intent)
                    }
                )
                
                // 🎤 录音权限
                PermissionItem(
                    icon = "🎤",
                    title = "录音权限",
                    description = "语音输入、语音识别、唤醒词检测",
                    isGranted = hasRecordAudio,
                    onClick = {
                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = android.net.Uri.parse("package:${context.packageName}")
                        }
                        context.startActivity(intent)
                    }
                )
                
                // 🔔 通知权限
                PermissionItem(
                    icon = "🔔",
                    title = "通知权限",
                    description = "任务完成提醒和状态通知",
                    isGranted = hasNotification,
                    onClick = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                                putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                            }
                            context.startActivity(intent)
                        }
                    }
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // 📍 可选权限标题
                Text(
                    "📍 可选权限（增强功能）",
                    color = Color(0xFFFFAB40),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                
                // 📍 定位权限
                PermissionItem(
                    icon = "📍",
                    title = "定位权限",
                    description = "自动获取天气、位置相关功能",
                    isGranted = hasFineLocation || hasCoarseLocation,
                    onClick = {
                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = android.net.Uri.parse("package:${context.packageName}")
                        }
                        context.startActivity(intent)
                    }
                )
                
                // 📷 相机权限
                PermissionItem(
                    icon = "📷",
                    title = "相机权限",
                    description = "扫码、拍照识别等功能",
                    isGranted = hasCamera,
                    onClick = {
                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = android.net.Uri.parse("package:${context.packageName}")
                        }
                        context.startActivity(intent)
                    }
                )
                
                // 📂 存储权限
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
                    PermissionItem(
                        icon = "📂",
                        title = "存储权限",
                        description = "读写文件、导出数据",
                        isGranted = hasStorage,
                        onClick = {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = android.net.Uri.parse("package:${context.packageName}")
                            }
                            context.startActivity(intent)
                        }
                    )
                }
                
                // 📱 电话状态权限
                PermissionItem(
                    icon = "📱",
                    title = "电话状态",
                    description = "来电时自动暂停操作",
                    isGranted = hasPhoneState,
                    onClick = {
                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = android.net.Uri.parse("package:${context.packageName}")
                        }
                        context.startActivity(intent)
                    }
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                // 🔄 刷新按钮
                Button(
                    onClick = { refreshTrigger++ },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF1E3A5F)
                    )
                ) {
                    Text("🔄 刷新权限状态", color = Color.White)
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "💡 点击权限项可跳转到系统设置页面\n授权后点击「刷新」更新状态",
                    color = Color(0xFF64FFDA),
                    fontSize = 10.sp,
                    lineHeight = 14.sp
                )
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("完成")
            }
        },
        containerColor = Color(0xFF112240)
    )
}

@Composable
fun PermissionItem(
    icon: String,
    title: String,
    description: String,
    isGranted: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable(onClick = onClick),
        color = if (isGranted) Color(0xFF1E3A5F).copy(alpha = 0.5f) else Color.Red.copy(alpha = 0.15f),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(icon, fontSize = 20.sp)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(description, color = Color.Gray, fontSize = 11.sp)
            }
            Text(
                if (isGranted) "✅" else "❌",
                fontSize = 16.sp
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ToolsAndPluginsDialog(onDismiss: () -> Unit) {
    val toolsByCategory = remember { ToolRegistry.getToolsByCategory() }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("工具与插件", color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                toolsByCategory.forEach { (category, tools) ->
                    val categoryName = when (category) {
                        "file" -> "📁 文件系统工具"
                        "http" -> "🌐 网络工具"
                        "system" -> "⚙️ 系统工具"
                        else -> "🔧 其他工具"
                    }
                    
                    Text(
                        categoryName,
                        color = Color(0xFF64FFDA),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                    )
                    
                    tools.forEach { tool ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            color = Color(0xFF1E3A5F),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    tool.name,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    tool.description,
                                    color = Color.Gray,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(top = 2.dp)
                                )
                                if (tool.parameters.isNotEmpty()) {
                                    Text(
                                        "参数: ${tool.parameters.joinToString(", ") { it.name }}",
                                        color = Color(0xFF64FFDA),
                                        fontSize = 10.sp,
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    "✨ 共 ${toolsByCategory.values.flatten().size} 个工具可供 AI 调用",
                    color = Color(0xFF64FFDA),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("关闭")
            }
        },
        containerColor = Color(0xFF112240)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExperimentalFeaturesDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("实验性功能", color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    "⚠️ 以下功能仍在开发中，可能不稳定",
                    color = Color(0xFFFFAA00),
                    fontSize = 12.sp,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("🎤 语音控制", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text("通过语音指令控制设备", color = Color.Gray, fontSize = 12.sp)
                    }
                    Switch(
                        checked = false,
                        onCheckedChange = {},
                        enabled = false,
                        colors = SwitchDefaults.colors(
                            disabledCheckedThumbColor = Color.Gray,
                            disabledUncheckedThumbColor = Color.Gray
                        )
                    )
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Text(
                    "更多实验性功能即将上线，敬请期待！✨",
                    color = Color(0xFF64FFDA),
                    fontSize = 10.sp
                )
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("知道了")
            }
        },
        containerColor = Color(0xFF112240)
    )
}

@Composable
fun VisionPreviewDialog(onDismiss: () -> Unit) {
    val screenState by AutomationEngine.currentScreenState.collectAsStateWithLifecycle()
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("视觉预览 (上帝之眼)", color = Color.White) },
        text = {
             Box(modifier = Modifier.height(300.dp).verticalScroll(rememberScrollState())) {
                 androidx.compose.foundation.text.selection.SelectionContainer {
                     Text(
                        text = screenState ?: "暂无屏幕数据，请开始任务以捕获。",
                        color = Color(0xFF64FFDA),
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        fontSize = 10.sp
                    )
                 }
             }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("关闭")
            }
        },
        containerColor = Color(0xFF112240)
    )
}

// 🎤 语音设置对话框
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceSettingsDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val prefs = context.getSharedPreferences("xihe_settings", android.content.Context.MODE_PRIVATE)
    
    var wakeWord by remember { mutableStateOf("羲和") }
    var enableWakeWord by remember { mutableStateOf(false) }
    var voiceSpeed by remember { mutableStateOf(1.0f) }
    var voicePitch by remember { mutableStateOf(1.0f) }
    var selectedVoiceStyle by remember { mutableStateOf("F1") }
    
    // 🎤 语音识别引擎选择
    var useOfflineRecognizer by remember { mutableStateOf(prefs.getBoolean("use_offline_recognizer", true)) }
    // 🔊 TTS 引擎选择
    var useLocalTTS by remember { mutableStateOf(prefs.getBoolean("use_local_tts", false)) }
    // 🔊 语音播报总开关
    var enableVoiceResponse by remember { mutableStateOf(prefs.getBoolean("enable_voice_response", true)) }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("🎤 语音设置", color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // === 语音识别设置 ===
                Text(
                    "🎙️ 语音识别引擎",
                    color = Color(0xFF64FFDA),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                
                // 识别引擎选择
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("使用离线识别 (Vosk)", color = Color.White, fontSize = 13.sp)
                        Text(
                            if (useOfflineRecognizer) "✅ 无需网络，完全本地运行" 
                            else "使用系统识别（需要Google服务）",
                            color = Color.Gray, 
                            fontSize = 10.sp
                        )
                    }
                    Switch(
                        checked = useOfflineRecognizer,
                        onCheckedChange = { enabled ->
                            useOfflineRecognizer = enabled
                            prefs.edit().putBoolean("use_offline_recognizer", enabled).apply()
                            // 通知 VoiceInteractionManager 切换引擎
                            ModuleCoordinator.setRecognizerType(enabled)
                            android.widget.Toast.makeText(
                                context,
                                if (enabled) "已切换到离线识别" else "已切换到系统识别",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF64FFDA),
                            checkedTrackColor = Color(0xFF64FFDA).copy(alpha = 0.5f)
                        )
                    )
                }
                
                // 当前状态
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color(0xFF1E3A5F).copy(alpha = 0.5f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            if (useOfflineRecognizer) "当前引擎: Vosk 离线识别" else "当前引擎: 系统语音识别",
                            color = Color.White, 
                            fontSize = 12.sp
                        )
                        Text("语言: 中文普通话", color = Color.Gray, fontSize = 11.sp)
                        if (useOfflineRecognizer) {
                            Text("特点: 完全离线，隐私保护好", color = Color(0xFF64FFDA), fontSize = 11.sp)
                        } else {
                            Text("特点: 需要网络，准确率较高", color = Color(0xFFFFAB40), fontSize = 11.sp)
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // === 🔊 语音播报总开关 ===
                Text(
                    "🔊 语音播报设置",
                    color = Color(0xFF64FFDA),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                
                // 语音播报总开关
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("启用语音播报", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text(
                            if (enableVoiceResponse) "✅ AI回复会使用语音播报" else "❌ AI仅文字回复，不播报",
                            color = if (enableVoiceResponse) Color(0xFF64FFDA) else Color.Gray,
                            fontSize = 10.sp
                        )
                    }
                    Switch(
                        checked = enableVoiceResponse,
                        onCheckedChange = { enabled ->
                            enableVoiceResponse = enabled
                            prefs.edit().putBoolean("enable_voice_response", enabled).apply()
                            // 通知 ModuleCoordinator 切换语音播报
                            ModuleCoordinator.setEnableTTSResponse(enabled)
                            android.widget.Toast.makeText(
                                context,
                                if (enabled) "✅ 语音播报已启用" else "❌ 语音播报已关闭",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF64FFDA),
                            checkedTrackColor = Color(0xFF64FFDA).copy(alpha = 0.5f),
                            uncheckedThumbColor = Color.Gray,
                            uncheckedTrackColor = Color.Gray.copy(alpha = 0.3f)
                        )
                    )
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // === TTS 语音合成设置 ===
                Text(
                    "🔊 语音合成引擎 (文字转语音)",
                    color = Color(0xFF64FFDA),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                
                // 检测系统 TTS 状态
                var systemTTSAvailable by remember { mutableStateOf(true) }
                var systemTTSEngine by remember { mutableStateOf("检测中...") }
                
                LaunchedEffect(Unit) {
                    // 检测系统 TTS
                    val tts = android.speech.tts.TextToSpeech(context) { status ->
                        systemTTSAvailable = status == android.speech.tts.TextToSpeech.SUCCESS
                        if (systemTTSAvailable) {
                            systemTTSEngine = "系统TTS已就绪"
                        } else {
                            systemTTSEngine = "系统TTS不可用"
                        }
                    }
                }
                
                // 当前 TTS 状态
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color(0xFF1E3A5F).copy(alpha = 0.5f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                if (useLocalTTS) "当前: 本地TTS模型" else "当前: 系统TTS",
                                color = Color.White, 
                                fontSize = 12.sp
                            )
                            Text(
                                if (systemTTSAvailable) "✅" else "⚠️",
                                fontSize = 14.sp
                            )
                        }
                        Text(
                            systemTTSEngine,
                            color = if (systemTTSAvailable) Color(0xFF64FFDA) else Color(0xFFFFAB40), 
                            fontSize = 11.sp
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                
                // TTS 引擎选择
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("使用本地TTS模型", color = Color.White, fontSize = 13.sp)
                        Text(
                            if (useLocalTTS) "⚠️ 本地模型暂不兼容" else "推荐：使用系统TTS",
                            color = if (useLocalTTS) Color(0xFFFFAB40) else Color.Gray, 
                            fontSize = 10.sp
                        )
                    }
                    Switch(
                        checked = useLocalTTS,
                        onCheckedChange = { enabled ->
                            useLocalTTS = enabled
                            prefs.edit().putBoolean("use_local_tts", enabled).apply()
                            android.widget.Toast.makeText(
                                context,
                                if (enabled) "已切换到本地TTS（暂不可用，将回退到系统TTS）" else "已切换到系统TTS",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF64FFDA),
                            checkedTrackColor = Color(0xFF64FFDA).copy(alpha = 0.5f)
                        )
                    )
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                
                // 打开系统 TTS 设置按钮
                Button(
                    onClick = {
                        try {
                            // 打开系统 TTS 设置
                            val intent = android.content.Intent().apply {
                                action = "com.android.settings.TTS_SETTINGS"
                                flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
                            }
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            // 如果上面的 action 不可用，尝试通用设置
                            try {
                                val intent = android.content.Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                                    flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
                                }
                                context.startActivity(intent)
                                android.widget.Toast.makeText(context, "请在设置中搜索「文字转语音」", android.widget.Toast.LENGTH_LONG).show()
                            } catch (e2: Exception) {
                                android.widget.Toast.makeText(context, "无法打开系统设置", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A5F)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        Icons.Default.Settings,
                        contentDescription = null,
                        tint = Color(0xFF64FFDA),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("打开系统TTS设置", color = Color.White, fontSize = 12.sp)
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "💡 系统TTS：设置 → 辅助功能 → 文字转语音输出",
                    color = Color.Gray,
                    fontSize = 10.sp
                )
                Text(
                    "📱 推荐安装：Google TTS 或 讯飞语音引擎",
                    color = Color.Gray,
                    fontSize = 10.sp
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // === 唤醒词设置 ===
                Text(
                    "唤醒词设置",
                    color = Color(0xFF64FFDA),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("启用唤醒词", color = Color.White, fontSize = 13.sp)
                        Text("说「羲和」或「你好羲和」唤醒", color = Color.Gray, fontSize = 10.sp)
                    }
                    Switch(
                        checked = enableWakeWord,
                        onCheckedChange = { 
                            enableWakeWord = it
                            // 启动或停止持续监听
                            if (it) {
                                ModuleCoordinator.startContinuousListening()
                            } else {
                                ModuleCoordinator.stopContinuousListening()
                            }
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF64FFDA),
                            checkedTrackColor = Color(0xFF64FFDA).copy(alpha = 0.5f)
                        )
                    )
                }
                
                if (enableWakeWord) {
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    // 支持的唤醒词列表
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = Color(0xFF1E3A5F).copy(alpha = 0.5f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("支持的唤醒词:", color = Color(0xFF64FFDA), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("• 羲和、小羲、嘿羲和", color = Color.White, fontSize = 11.sp)
                            Text("• 你好羲和、羲和你好", color = Color.White, fontSize = 11.sp)
                            Text("• hi羲和、hey羲和", color = Color.White, fontSize = 11.sp)
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "💡 开启后会持续监听，说出唤醒词即可激活羲和",
                        color = Color.Gray,
                        fontSize = 10.sp
                    )
                    Text(
                        "⚡ 唤醒后可直接说指令，如「羲和打开微信」",
                        color = Color(0xFF64FFDA),
                        fontSize = 10.sp
                    )
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // === 🌙 后台唤醒设置 ===
                var enableBackgroundWake by remember { mutableStateOf(prefs.getBoolean("enable_background_wake", false)) }
                
                Text(
                    "后台唤醒（类似小爱同学）",
                    color = Color(0xFF64FFDA),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("退出软件后仍可唤醒", color = Color.White, fontSize = 13.sp)
                        Text("开机自动启动后台服务", color = Color.Gray, fontSize = 10.sp)
                    }
                    Switch(
                        checked = enableBackgroundWake,
                        onCheckedChange = { enabled ->
                            enableBackgroundWake = enabled
                            prefs.edit().putBoolean("enable_background_wake", enabled).apply()
                            
                            if (enabled) {
                                // 启动后台唤醒服务
                                val serviceIntent = android.content.Intent(context, WakeWordService::class.java)
                                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                    context.startForegroundService(serviceIntent)
                                } else {
                                    context.startService(serviceIntent)
                                }
                                // 同时启动保活机制
                                ServiceKeepAlive.start(context)
                                android.widget.Toast.makeText(context, "后台唤醒已开启，说「羲和」即可唤醒", android.widget.Toast.LENGTH_SHORT).show()
                            } else {
                                // 停止后台唤醒服务和保活机制
                                val serviceIntent = android.content.Intent(context, WakeWordService::class.java)
                                context.stopService(serviceIntent)
                                ServiceKeepAlive.stop(context)
                                android.widget.Toast.makeText(context, "后台唤醒已关闭", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF64FFDA),
                            checkedTrackColor = Color(0xFF64FFDA).copy(alpha = 0.5f)
                        )
                    )
                }
                
                if (enableBackgroundWake) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "🌙 退出应用后，说「羲和」即可唤醒并打开悬浮窗",
                        color = Color(0xFF64FFDA),
                        fontSize = 10.sp
                    )
                    Text(
                        "⚡ 开机后自动启动，无需手动打开应用",
                        color = Color.Gray,
                        fontSize = 10.sp
                    )
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // === 🔐 声纹识别设置 ===
                var enableVoiceprint by remember { mutableStateOf(prefs.getBoolean("enable_voiceprint", false)) }
                var showVoiceprintEnroll by remember { mutableStateOf(false) }
                val enrolledUsers = remember { mutableStateOf(VoiceprintManager.getEnrolledUsers()) }
                
                Text(
                    "🔐 声纹识别（主人专属）",
                    color = Color(0xFF64FFDA),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("启用声纹验证", color = Color.White, fontSize = 13.sp)
                        Text("只响应主人的唤醒词", color = Color.Gray, fontSize = 10.sp)
                    }
                    Switch(
                        checked = enableVoiceprint,
                        onCheckedChange = { enabled ->
                            enableVoiceprint = enabled
                            prefs.edit().putBoolean("enable_voiceprint", enabled).apply()
                            VoiceprintManager.updateConfig(
                                VoiceprintConfig(enabled = enabled)
                            )
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF64FFDA),
                            checkedTrackColor = Color(0xFF64FFDA).copy(alpha = 0.5f)
                        )
                    )
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // 已注册用户列表
                if (enrolledUsers.value.isNotEmpty()) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = Color(0xFF1E3A5F).copy(alpha = 0.5f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("已注册声纹:", color = Color(0xFF64FFDA), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            enrolledUsers.value.forEach { user ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("• ${user.userName}", color = Color.White, fontSize = 11.sp)
                                        Text("  样本数: ${user.sampleCount}", color = Color.Gray, fontSize = 10.sp)
                                    }
                                    IconButton(
                                        onClick = {
                                            VoiceprintManager.deleteVoiceprint(user.userId)
                                            enrolledUsers.value = VoiceprintManager.getEnrolledUsers()
                                        },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, "删除", tint = Color.Red.copy(alpha = 0.7f), modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }
                
                // 注册新声纹按钮
                Button(
                    onClick = { showVoiceprintEnroll = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A5F)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Mic, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (enrolledUsers.value.isEmpty()) "录制主人声纹" else "添加新用户声纹", fontSize = 13.sp)
                }
                
                if (enableVoiceprint && enrolledUsers.value.isEmpty()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "⚠️ 请先录制声纹，否则无法使用唤醒词",
                        color = Color(0xFFFFAB40),
                        fontSize = 10.sp
                    )
                }
                
                Text(
                    "💡 录制你说「羲和」的声音，系统将只响应你的声音",
                    color = Color.Gray,
                    fontSize = 10.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )
                
                // 声纹录制对话框
                if (showVoiceprintEnroll) {
                    VoiceprintEnrollDialog(
                        onDismiss = { 
                            showVoiceprintEnroll = false
                            enrolledUsers.value = VoiceprintManager.getEnrolledUsers()
                        }
                    )
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // === 语音合成设置 ===
                Text(
                    "语音合成 (TTS)",
                    color = Color(0xFF64FFDA),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                
                // 语音播报开关
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("AI回复语音播报", color = Color.White, fontSize = 13.sp)
                    Switch(
                        checked = enableVoiceResponse,
                        onCheckedChange = { 
                            enableVoiceResponse = it
                            AutomationEngine.enableVoiceResponse = it
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF64FFDA),
                            checkedTrackColor = Color(0xFF64FFDA).copy(alpha = 0.5f)
                        )
                    )
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                
                // 语音风格选择
                Text("语音风格", color = Color.White, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("F1" to "女声1", "F2" to "女声2", "M1" to "男声1", "M2" to "男声2").forEach { (id, name) ->
                        FilterChip(
                            selected = selectedVoiceStyle == id,
                            onClick = { selectedVoiceStyle = id },
                            label = { Text(name, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF64FFDA),
                                selectedLabelColor = Color.Black
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                
                // 语速调节
                Text("语速: ${String.format("%.1f", voiceSpeed)}x", color = Color.White, fontSize = 13.sp)
                Slider(
                    value = voiceSpeed,
                    onValueChange = { voiceSpeed = it },
                    valueRange = 0.5f..2.0f,
                    steps = 5,
                    colors = SliderDefaults.colors(
                        thumbColor = Color(0xFF64FFDA),
                        activeTrackColor = Color(0xFF64FFDA)
                    )
                )
                
                // 音调调节
                Text("音调: ${String.format("%.1f", voicePitch)}x", color = Color.White, fontSize = 13.sp)
                Slider(
                    value = voicePitch,
                    onValueChange = { voicePitch = it },
                    valueRange = 0.5f..2.0f,
                    steps = 5,
                    colors = SliderDefaults.colors(
                        thumbColor = Color(0xFF64FFDA),
                        activeTrackColor = Color(0xFF64FFDA)
                    )
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // === 主动对话设置 ===
                Text(
                    "主动对话",
                    color = Color(0xFF64FFDA),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                
                var enableProactiveChat by remember { mutableStateOf(AutomationEngine.enableProactiveChat) }
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("启用主动对话", color = Color.White, fontSize = 13.sp)
                        Text("羲和会主动找你聊天", color = Color.Gray, fontSize = 10.sp)
                    }
                    Switch(
                        checked = enableProactiveChat,
                        onCheckedChange = { 
                            enableProactiveChat = it
                            AutomationEngine.enableProactiveChat = it
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF64FFDA),
                            checkedTrackColor = Color(0xFF64FFDA).copy(alpha = 0.5f)
                        )
                    )
                }
                
                if (enableProactiveChat) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "💬 当你5分钟没互动，羲和会主动找你聊天哦~",
                        color = Color.Gray,
                        fontSize = 10.sp
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF64FFDA))
            ) {
                Text("保存", color = Color.Black)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("取消", color = Color.Gray)
            }
        },
        containerColor = Color(0xFF112240)
    )
}

// 🔐 声纹录制对话框
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceprintEnrollDialog(onDismiss: () -> Unit) {
    var userName by remember { mutableStateOf("主人") }
    var enrollmentStep by remember { mutableStateOf(0) } // 0=输入名称, 1=录制中, 2=完成
    var currentSample by remember { mutableStateOf(0) }
    var totalSamples by remember { mutableStateOf(3) }
    var resultMessage by remember { mutableStateOf("") }
    var isSuccess by remember { mutableStateOf(false) }
    
    AlertDialog(
        onDismissRequest = { if (enrollmentStep != 1) onDismiss() },
        title = { 
            Text(
                when (enrollmentStep) {
                    0 -> "🔐 录制声纹"
                    1 -> "🎤 正在录制..."
                    else -> if (isSuccess) "✅ 录制成功" else "❌ 录制失败"
                },
                color = Color.White, 
                fontWeight = FontWeight.Bold
            ) 
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                when (enrollmentStep) {
                    0 -> {
                        // 输入用户名
                        Text("请输入你的称呼：", color = Color.White, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = userName,
                            onValueChange = { userName = it },
                            label = { Text("称呼", color = Color.Gray) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF64FFDA),
                                unfocusedBorderColor = Color.Gray,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            "💡 接下来需要录制3次你说「羲和」的声音",
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                        Text(
                            "🎤 每次录制3秒，请在安静环境下进行",
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                    }
                    1 -> {
                        // 录制进度
                        Text(
                            "请说「羲和」",
                            color = Color(0xFF64FFDA),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        // 进度指示
                        LinearProgressIndicator(
                            progress = { currentSample.toFloat() / totalSamples },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp),
                            color = Color(0xFF64FFDA),
                            trackColor = Color(0xFF1E3A5F)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "第 $currentSample / $totalSamples 次",
                            color = Color.White,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        // 麦克风动画指示
                        Icon(
                            Icons.Default.Mic,
                            contentDescription = null,
                            tint = Color(0xFF64FFDA),
                            modifier = Modifier.size(48.dp)
                        )
                        Text(
                            "🔴 录音中...",
                            color = Color.Red,
                            fontSize = 12.sp
                        )
                    }
                    else -> {
                        // 结果显示
                        Icon(
                            if (isSuccess) Icons.Default.CheckCircle else Icons.Default.Error,
                            contentDescription = null,
                            tint = if (isSuccess) Color(0xFF64FFDA) else Color.Red,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            resultMessage,
                            color = if (isSuccess) Color(0xFF64FFDA) else Color.Red,
                            fontSize = 14.sp
                        )
                        if (isSuccess) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "现在只有你说「羲和」，系统才会响应啦~",
                                color = Color.Gray,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            when (enrollmentStep) {
                0 -> {
                    Button(
                        onClick = {
                            enrollmentStep = 1
                            // 开始录制
                            VoiceprintManager.startEnrollment(
                                userId = java.util.UUID.randomUUID().toString(),
                                userName = userName,
                                onProgress = { current, total ->
                                    currentSample = current
                                    totalSamples = total
                                },
                                onComplete = { success, message ->
                                    isSuccess = success
                                    resultMessage = message
                                    enrollmentStep = 2
                                }
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF64FFDA)),
                        enabled = userName.isNotBlank()
                    ) {
                        Text("开始录制", color = Color.Black)
                    }
                }
                1 -> {
                    // 录制中不显示按钮
                }
                else -> {
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF64FFDA))
                    ) {
                        Text("完成", color = Color.Black)
                    }
                }
            }
        },
        dismissButton = {
            if (enrollmentStep != 1) {
                TextButton(onClick = onDismiss) {
                    Text("取消", color = Color.Gray)
                }
            }
        },
        containerColor = Color(0xFF112240)
    )
}
