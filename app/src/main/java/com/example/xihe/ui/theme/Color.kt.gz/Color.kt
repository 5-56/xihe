package com.example.xihe.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/**
 * 🎨 羲和AI助手 - 扩展色彩系统
 * 提供丰富的颜色定义和渐变效果
 */

// 主题色 - 深空蓝系列
object DeepSpaceBlue {
    val Primary = Color(0xFF0A192F)
    val Secondary = Color(0xFF112240)
    val Tertiary = Color(0xFF1A2F4F)
    val Light = Color(0xFF233554)
    val Accent = Color(0xFF64FFDA) // 添加 Accent 颜色
}

// 霓虹青色系列
object NeonCyan {
    val Primary = Color(0xFF64FFDA)
    val Light = Color(0xFF8FFFF0)
    val Dark = Color(0xFF3DCCAA)
    val Glow = Color(0xFFAAFFF5)
}

// 辅助色彩
object AccentColors {
    val Purple = Color(0xFFBB86FC)
    val Pink = Color(0xFFFF6B9D)
    val Orange = Color(0xFFFFAB40)
    val Yellow = Color(0xFFFFEB3B)
    val Green = Color(0xFF4CAF50)
    val Blue = Color(0xFF2196F3)
}

// 状态颜色
object StatusColors {
    val Success = Color(0xFF4CAF50)
    val Warning = Color(0xFFFF9800)
    val Error = Color(0xFFF44336)
    val Info = Color(0xFF2196F3)
}

// 渐变色定义
object Gradients {
    val CyanToBlue = Brush.horizontalGradient(
        colors = listOf(
            NeonCyan.Primary,
            AccentColors.Blue
        )
    )
    
    val PurpleToPink = Brush.horizontalGradient(
        colors = listOf(
            AccentColors.Purple,
            AccentColors.Pink
        )
    )
    
    val OrangeToYellow = Brush.horizontalGradient(
        colors = listOf(
            AccentColors.Orange,
            AccentColors.Yellow
        )
    )
    
    val DeepSpaceGlow = Brush.verticalGradient(
        colors = listOf(
            DeepSpaceBlue.Primary,
            DeepSpaceBlue.Secondary,
            DeepSpaceBlue.Tertiary
        )
    )
    
    val NeonGlow = Brush.radialGradient(
        colors = listOf(
            NeonCyan.Glow,
            NeonCyan.Primary,
            NeonCyan.Dark
        )
    )
}

// 透明度变体
object AlphaVariants {
    fun Color.withAlpha(alpha: Float) = this.copy(alpha = alpha)
    
    val glassmorphicOverlay = Color.White.copy(alpha = 0.1f)
    val dimOverlay = Color.Black.copy(alpha = 0.5f)
    val lightOverlay = Color.White.copy(alpha = 0.05f)
}
