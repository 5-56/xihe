package com.example.xihe.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * 🎤 语音状态指示器
 * 
 * 功能：
 * 1. 显示当前语音状态（空闲/监听中/播放中/处理中）
 * 2. 显示播放队列大小
 * 3. 提供快捷控制按钮（停止/跳过）
 * 4. 动画效果增强用户体验
 */
@Composable
fun VoiceStatusIndicator(
    voiceState: VoiceStatusState,
    queueSize: Int = 0,
    currentText: String? = null,
    onStopClick: () -> Unit = {},
    onSkipClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    // 只在非空闲状态显示
    AnimatedVisibility(
        visible = voiceState != VoiceStatusState.IDLE || queueSize > 0,
        enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
        exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
        modifier = modifier
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.95f)
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // 状态图标（带动画）
                VoiceStateIcon(state = voiceState)
                
                // 状态文本和当前内容
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = voiceState.displayName,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                            color = voiceState.color
                        )
                        
                        // 队列大小标签
                        if (queueSize > 0) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "队列: $queueSize",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    
                    // 当前播放内容预览
                    currentText?.let { text ->
                        Text(
                            text = text,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                
                // 控制按钮
                if (voiceState == VoiceStatusState.SPEAKING) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        // 跳过按钮
                        if (queueSize > 0) {
                            IconButton(
                                onClick = onSkipClick,
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SkipNext,
                                    contentDescription = "跳过",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        
                        // 停止按钮
                        IconButton(
                            onClick = onStopClick,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Stop,
                                contentDescription = "停止",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * 🎯 语音状态图标（带动画）
 */
@Composable
private fun VoiceStateIcon(state: VoiceStatusState) {
    val infiniteTransition = rememberInfiniteTransition(label = "voice_state")
    
    // 脉冲动画
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )
    
    // 旋转动画（处理中状态）
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )
    
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(state.color.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = state.icon,
            contentDescription = state.displayName,
            tint = state.color,
            modifier = Modifier
                .size(24.dp)
                .graphicsLayer {
                    when (state) {
                        VoiceStatusState.LISTENING, VoiceStatusState.SPEAKING -> {
                            scaleX = pulseScale
                            scaleY = pulseScale
                        }
                        VoiceStatusState.PROCESSING -> {
                            rotationZ = rotation
                        }
                        else -> {}
                    }
                }
        )
    }
}

/**
 * 🎤 紧凑型语音状态指示器（用于顶栏）
 */
@Composable
fun CompactVoiceStatusIndicator(
    voiceState: VoiceStatusState,
    queueSize: Int = 0,
    onClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = voiceState != VoiceStatusState.IDLE || queueSize > 0,
        enter = fadeIn() + scaleIn(),
        exit = fadeOut() + scaleOut(),
        modifier = modifier
    ) {
        val infiniteTransition = rememberInfiniteTransition(label = "compact_pulse")
        val pulseAlpha by infiniteTransition.animateFloat(
            initialValue = 0.6f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(600),
                repeatMode = RepeatMode.Reverse
            ),
            label = "alpha"
        )
        
        Surface(
            onClick = onClick,
            shape = RoundedCornerShape(20.dp),
            color = voiceState.color.copy(alpha = if (voiceState == VoiceStatusState.SPEAKING) pulseAlpha * 0.2f else 0.15f)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = voiceState.icon,
                    contentDescription = null,
                    tint = voiceState.color,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = if (queueSize > 0) "${voiceState.shortName} ($queueSize)" else voiceState.shortName,
                    style = MaterialTheme.typography.labelSmall,
                    color = voiceState.color,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

/**
 * 🎵 语音状态枚举
 */
enum class VoiceStatusState(
    val displayName: String,
    val shortName: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val color: Color
) {
    IDLE(
        displayName = "空闲",
        shortName = "空闲",
        icon = Icons.Default.MicOff,
        color = Color.Gray
    ),
    LISTENING(
        displayName = "正在聆听...",
        shortName = "聆听中",
        icon = Icons.Default.Mic,
        color = Color(0xFF4CAF50) // Green
    ),
    PROCESSING(
        displayName = "处理中...",
        shortName = "处理中",
        icon = Icons.Default.Sync,
        color = Color(0xFFFF9800) // Orange
    ),
    SPEAKING(
        displayName = "正在播放...",
        shortName = "播放中",
        icon = Icons.Default.VolumeUp,
        color = Color(0xFF2196F3) // Blue
    ),
    ERROR(
        displayName = "出错了",
        shortName = "错误",
        icon = Icons.Default.Error,
        color = Color(0xFFF44336) // Red
    )
}

/**
 * 🎤 语音波形动画指示器
 */
@Composable
fun VoiceWaveformIndicator(
    isActive: Boolean,
    modifier: Modifier = Modifier,
    barCount: Int = 5,
    color: Color = MaterialTheme.colorScheme.primary
) {
    val infiniteTransition = rememberInfiniteTransition(label = "waveform")
    
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(barCount) { index ->
            val height by infiniteTransition.animateFloat(
                initialValue = 8f,
                targetValue = 24f,
                animationSpec = infiniteRepeatable(
                    animation = tween(
                        durationMillis = 400 + index * 100,
                        easing = FastOutSlowInEasing
                    ),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "bar_$index"
            )
            
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(if (isActive) height.dp else 8.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(
                        if (isActive) color 
                        else color.copy(alpha = 0.3f)
                    )
            )
        }
    }
}
