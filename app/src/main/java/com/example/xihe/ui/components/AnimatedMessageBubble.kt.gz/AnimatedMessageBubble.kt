package com.example.xihe.ui.components

import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.xihe.core.ModuleCoordinator
import com.example.xihe.ui.animation.AnimationDurations
import com.example.xihe.ui.animation.AnimationSpecs
import kotlinx.coroutines.delay

/**
 * 💬 动画消息气泡组件
 * 带有滑入动画、打字效果、长按菜单及霓虹光效
 */
@Composable
fun AnimatedMessageBubble(
    message: String,
    isUser: Boolean,
    modifier: Modifier = Modifier,
    showTypingEffect: Boolean = false,
    imageUri: String? = null,
    onImageClick: ((String) -> Unit)? = null,
    thinkingContent: String? = null
) {
    var visible by remember { mutableStateOf(false) }
    var displayedText by remember(message) { mutableStateOf("") }
    var isThinkingExpanded by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    
    val clipboardManager = LocalClipboardManager.current
    val haptic = com.example.xihe.ui.utils.rememberHapticFeedback()

    // 霓虹边框呼吸动画（仅 AI）
    val infiniteTransition = rememberInfiniteTransition(label = "glow")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.6f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowAlpha"
    )

    LaunchedEffect(message) {
        delay(50)
        visible = true
        if (!isUser && showTypingEffect && message.isNotEmpty()) {
            displayedText = ""
            message.forEachIndexed { index, _ ->
                displayedText = message.substring(0, index + 1)
                delay(12)
            }
        } else {
            displayedText = message
        }
    }

    AnimatedVisibility(
        visible = visible,
        enter = slideInHorizontally(initialOffsetX = { if (isUser) it else -it }) + fadeIn(),
        exit = fadeOut()
    ) {
        val scale by animateFloatAsState(targetValue = 1f, animationSpec = AnimationSpecs.bouncy)
        val context = LocalContext.current

        Box(
            modifier = modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
                .scale(scale),
            contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
        ) {
            Column {
                Column(
                    modifier = Modifier
                        .widthIn(max = 280.dp)
                        .clip(RoundedCornerShape(
                            topStart = 16.dp, topEnd = 16.dp,
                            bottomStart = if (isUser) 16.dp else 4.dp,
                            bottomEnd = if (isUser) 4.dp else 16.dp
                        ))
                        .then(
                            if (!isUser) Modifier.border(
                                1.dp, 
                                MaterialTheme.colorScheme.primary.copy(alpha = glowAlpha), 
                                RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 4.dp, bottomEnd = 16.dp)
                            ) else Modifier
                        )
                        .background(if (isUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                        .pointerInput(message) {
                            detectTapGestures(
                                onLongPress = {
                                    haptic.mediumTap()
                                    showMenu = true
                                }
                            )
                        }
                        .padding(12.dp)
                ) {
                    if (!isUser && !thinkingContent.isNullOrBlank()) {
                        ThinkingContentCollapsibleBubble(
                            thinkingContent = thinkingContent,
                            isExpanded = isThinkingExpanded,
                            onToggle = { isThinkingExpanded = !isThinkingExpanded }
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    if (imageUri != null) {
                        ImageThumbnail(imageUri, context, onImageClick)
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    if (displayedText.isNotBlank()) {
                        Text(
                            text = displayedText,
                            color = if (isUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 15.sp,
                            lineHeight = 22.sp,
                            fontWeight = if (isUser) FontWeight.Medium else FontWeight.Normal
                        )
                    }
                }

                // 🚀 弹出式快捷菜单
                AnimatedVisibility(
                    visible = showMenu,
                    enter = expandVertically() + fadeIn(),
                    exit = shrinkVertically() + fadeOut()
                ) {
                    Row(
                        modifier = Modifier
                            .padding(top = 8.dp)
                            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                            .padding(horizontal = 4.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MenuActionIcon(Icons.Default.ContentCopy, "复制") {
                            clipboardManager.setText(AnnotatedString(message))
                            showMenu = false
                        }
                        if (!isUser) {
                            MenuActionIcon(Icons.Default.VolumeUp, "朗读") {
                                ModuleCoordinator.speak(message)
                                showMenu = false
                            }
                        }
                        MenuActionIcon(Icons.Default.Close, "关闭") { showMenu = false }
                    }
                }
            }
        }
    }
}

@Composable
private fun MenuActionIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(32.dp)) {
        Icon(icon, contentDescription = label, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun ImageThumbnail(uri: String, context: android.content.Context, onClick: ((String) -> Unit)?) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(150.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
            .clickable { onClick?.invoke(uri) }
    ) {
        AsyncImage(
            model = ImageRequest.Builder(context).data(Uri.parse(uri)).crossfade(true).build(),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Icon(Icons.Default.ZoomIn, null, tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f), modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp).size(20.dp))
    }
}

/**
 * 🧠 可折叠的思考内容区域（用于 AnimatedMessageBubble）
 */
@Composable
private fun ThinkingContentCollapsibleBubble(
    thinkingContent: String,
    isExpanded: Boolean,
    onToggle: () -> Unit
) {
    val rotationAngle by animateFloatAsState(
        targetValue = if (isExpanded) 180f else 0f,
        animationSpec = tween(300),
        label = "rotation"
    )
    
    Column {
        // 折叠/展开按钮
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onToggle)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Psychology,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f),
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = if (isExpanded) "收起思考过程" else "查看思考过程",
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                        fontSize = 12.sp
                    )
                }
                Icon(
                    imageVector = Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier
                        .size(18.dp)
                        .graphicsLayer { rotationZ = rotationAngle }
                )
            }
        }
        
        // 思考内容（可折叠）
        AnimatedVisibility(
            visible = isExpanded,
            enter = expandVertically(animationSpec = tween(300)) + fadeIn(),
            exit = shrinkVertically(animationSpec = tween(300)) + fadeOut()
        ) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp)
            ) {
                Column(
                    modifier = Modifier.padding(10.dp)
                ) {
                    Text(
                        text = thinkingContent,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}

/**
 * ⌨️ 打字指示器
 * 显示AI正在输入的动画
 */
@Composable
fun TypingIndicator(
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "typing")
    
    Row(
        modifier = modifier
            .padding(16.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(3) { index ->
            val offsetY by infiniteTransition.animateFloat(
                initialValue = 0f,
                targetValue = -8f,
                animationSpec = infiniteRepeatable(
                    animation = tween(
                        durationMillis = 600,
                        delayMillis = index * 150,
                        easing = FastOutSlowInEasing
                    ),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "dot$index"
            )
            
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .offset(y = offsetY.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.7f))
            )
        }
    }
}
