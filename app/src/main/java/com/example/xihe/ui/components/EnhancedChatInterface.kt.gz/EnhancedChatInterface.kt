package com.example.xihe.ui.components

import android.graphics.Bitmap
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.ripple
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.xihe.core.EngineStateManager
import com.example.xihe.core.AutomationEngine
import com.example.xihe.core.ModuleCoordinator
import com.example.xihe.core.model.ChatMessageDisplay
import com.example.xihe.ui.components.quickcommand.*
import com.example.xihe.ui.theme.StatusColors
import com.example.xihe.ui.utils.rememberHapticFeedback
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * 🚀 增强版聊天界面
 *
 * 功能：
 * 1. 快捷指令面板 - 悬浮式快速访问常用命令
 * 2. 语音波形显示 - 实时语音输入可视化
 * 3. AI 洞察面板 - 展示 AI 思考过程和学习成果
 * 4. 智能输入栏 - 支持多种输入方式
 * 5. 增强消息展示 - 动画和交互效果
 * 6. 智能建议 - 基于上下文的 AI 推荐
 *
 * 核心理念：AI 全自动化，用户无需手动配置
 */

@Composable
fun EnhancedChatInterface(
    modifier: Modifier = Modifier,
    onSendMessage: (String) -> Unit = {},
    onVoiceInput: () -> Unit = {},
    onImagePick: () -> Unit = {},
    onStopTask: () -> Unit = {},
    onRetryMessage: (String) -> Unit = {}  // 🔄 重试消息回调
) {
    val context = LocalContext.current
    val haptic = rememberHapticFeedback()
    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current

    // 状态
    val messages by EngineStateManager.messages.collectAsStateWithLifecycle()
    val taskProgress by EngineStateManager.taskProgress.collectAsStateWithLifecycle()
    val isPaused by EngineStateManager.isPaused.collectAsStateWithLifecycle()
    val status by EngineStateManager.status.collectAsStateWithLifecycle()

    var inputText by remember { mutableStateOf("") }
    var showQuickCommandPanel by remember { mutableStateOf(false) }
    var isVoiceListening by remember { mutableStateOf(false) }
    var showFullScreenImage by remember { mutableStateOf<String?>(null) }

    // 列表状态
    val listState = rememberLazyListState()
    
    // 任务执行状态
    val isTaskRunning = status != "Idle" && status != "完成" && status != "就绪"
    
    // 🎤 语音状态
    val voiceState by ModuleCoordinator.voiceState.collectAsStateWithLifecycle()
    val ttsQueueSize by ModuleCoordinator.ttsQueueSize.collectAsStateWithLifecycle()
    val currentTTSText by ModuleCoordinator.currentTTSText.collectAsStateWithLifecycle()
    
    // 映射语音状态
    val voiceStatusState = remember(voiceState) {
        when (voiceState) {
            "LISTENING" -> VoiceStatusState.LISTENING
            "SPEAKING" -> VoiceStatusState.SPEAKING
            "PROCESSING" -> VoiceStatusState.PROCESSING
            "ERROR" -> VoiceStatusState.ERROR
            else -> VoiceStatusState.IDLE
        }
    }

    // 自动滚动到最新消息
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // 消息列表
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 16.dp)
            ) {
                // 欢迎消息
                item {
                    EnhancedMessageBubble(
                        message = "主人好呀！我是羲和，您的专属 AI 小助手！✨\n\n试试点击右下角的 ➕ 按钮查看快捷指令哦~",
                        isUser = false,
                        showTypingEffect = true
                    )
                }

                // ✅ 优化：使用稳定的key和contentType减少重组
                items(
                    items = messages,
                    key = { it.id }, // 使用唯一ID而非timestamp
                    contentType = { if (it.isUser) "user" else "ai" } // 区分内容类型
                ) { msg ->
                    // ✅ 优化：remember关键计算
                    val shouldShowTyping = remember(msg.id) {
                        !msg.isUser
                    }
                    
                    EnhancedMessageBubble(
                        message = msg.content,
                        isUser = msg.isUser,
                        showTypingEffect = shouldShowTyping,
                        imageUri = msg.imageUri,
                        onImageClick = { uri -> showFullScreenImage = uri },
                        thinkingContent = msg.thinkingContent,
                        messageStatus = msg.status,
                        errorMessage = msg.errorMessage,
                        retryCount = msg.retryCount,
                        onRetryClick = if (msg.isUser && msg.status == com.example.xihe.core.model.MessageStatus.FAILED) {
                            { 
                                haptic.mediumTap()
                                onRetryMessage(msg.id) 
                            }
                        } else null
                    )

                    // 动作卡片
                    if (msg.action != null) {
                        Spacer(modifier = Modifier.height(4.dp))
                        ActionStatusCard(
                            action = msg.action,
                            status = "已执行"
                        )
                    }
                }
            }

            // 智能建议与指令融合区
            AnimatedVisibility(
                visible = !showQuickCommandPanel && !isTaskRunning,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Column {
                    // 芯片组（仅输入为空时显示建议）
                    if (inputText.isEmpty()) {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            val suggestions = listOf("停止任务", "今天天气", "屏幕内容", "微信操作", "性能状态")
                            items(suggestions) { suggestion ->
                                SuggestionChip(
                                    onClick = {
                                        haptic.lightTap()
                                        onSendMessage(suggestion)
                                    },
                                    label = { Text(suggestion, fontSize = 11.sp, fontWeight = FontWeight.Medium) },
                                    colors = SuggestionChipDefaults.suggestionChipColors(
                                        containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                                        labelColor = MaterialTheme.colorScheme.primary
                                    ),
                                    border = null,
                                    shape = RoundedCornerShape(12.dp)
                                )
                            }
                        }
                    }

                    // 快速指令条
                    QuickCommandBar(
                        onCommandSelected = { command ->
                            haptic.lightTap()
                            inputText = command.command
                        },
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
            }

            // 🎤 语音状态指示器
            VoiceStatusIndicator(
                voiceState = voiceStatusState,
                queueSize = ttsQueueSize,
                currentText = currentTTSText,
                onStopClick = {
                    haptic.mediumTap()
                    ModuleCoordinator.stopSpeaking()
                },
                onSkipClick = {
                    haptic.lightTap()
                    ModuleCoordinator.skipCurrentTTS()
                }
            )
            
            // 输入区域
            val attachedImage by AutomationEngine.attachedImageUri.collectAsStateWithLifecycle()
            
            EnhancedInputArea(
                inputText = inputText,
                onInputChange = { inputText = it },
                onSend = {
                    if (inputText.isNotBlank() || attachedImage != null) {
                        haptic.mediumTap()
                        onSendMessage(inputText)
                        inputText = ""
                        focusManager.clearFocus()
                    }
                },
                onVoiceClick = {
                    haptic.lightTap()
                    isVoiceListening = !isVoiceListening
                    if (isVoiceListening) {
                        onVoiceInput()
                    }
                },
                onImageClick = {
                    haptic.lightTap()
                    onImagePick()
                },
                isVoiceListening = isVoiceListening,
                isTaskRunning = isTaskRunning,
                attachedImageUri = attachedImage,
                onClearImage = { AutomationEngine.setAttachedImage(null) }
            )
        }

        // 快捷指令面板
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 16.dp, bottom = 100.dp)
        ) {
            QuickCommandPanel(
                expanded = showQuickCommandPanel,
                onExpandedChange = { showQuickCommandPanel = it },
                onCommandSelected = { command ->
                    haptic.mediumTap()
                    inputText = command.command
                    showQuickCommandPanel = false
                }
            )
        }

        // 全屏图片预览
        showFullScreenImage?.let { imageUri ->
            FullScreenImageDialog(
                imageUri = imageUri,
                onDismiss = { showFullScreenImage = null }
            )
        }
    }
}

// ==================== 增强消息气泡 ====================

/**
 * ✅ 优化：使用 produceState 和 remember 减少重组
 * - 批量更新打字效果，减少重组频率
 * - 使用 remember 缓存计算结果
 */
@Composable
fun EnhancedMessageBubble(
    message: String,
    isUser: Boolean,
    showTypingEffect: Boolean = false,
    imageUri: String? = null,
    onImageClick: ((String) -> Unit)? = null,
    thinkingContent: String? = null,  // 🧠 思考内容（可折叠）
    messageStatus: com.example.xihe.core.model.MessageStatus = com.example.xihe.core.model.MessageStatus.SUCCESS,
    errorMessage: String? = null,
    retryCount: Int = 0,
    onRetryClick: (() -> Unit)? = null  // 🔄 重试回调
) {
    // ✅ 优化：批量处理打字效果，每50ms更新一次而非每15ms
    val displayedText by produceState(initialValue = "", key1 = message, key2 = showTypingEffect) {
        if (!showTypingEffect || isUser) {
            value = message
            return@produceState
        }
        
        // 分批处理，减少重组
        val batchSize = 3
        val delayPerBatch = 50L // ms
        
        message.chunked(batchSize).forEach { batch ->
            value += batch
            delay(delayPerBatch)
        }
    }
    
    // ✅ 优化：使用 derivedStateOf 缓存计算结果
    val isTyping by remember(message, showTypingEffect, displayedText) {
        derivedStateOf {
            showTypingEffect && !isUser && displayedText.length < message.length
        }
    }
    
    // 判断是否是失败状态
    val isFailed = messageStatus == com.example.xihe.core.model.MessageStatus.FAILED
    val isSending = messageStatus == com.example.xihe.core.model.MessageStatus.SENDING
    
    var isThinkingExpanded by rememberSaveable { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        // 图片预览
        imageUri?.let { uri ->
            ImagePreviewThumbnail(
                imageUri = uri,
                onClick = { onImageClick?.invoke(uri) },
                modifier = Modifier.padding(bottom = 4.dp)
            )
        }

        // 消息气泡
        Surface(
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 16.dp
            ),
            color = when {
                isFailed -> StatusColors.Error.copy(alpha = 0.15f)
                isUser -> MaterialTheme.colorScheme.primary
                else -> MaterialTheme.colorScheme.surfaceVariant
            },
            modifier = Modifier
                .widthIn(max = 300.dp)
                .shadow(4.dp, RoundedCornerShape(16.dp))
        ) {
            Column(
                modifier = Modifier.padding(12.dp)
            ) {
                // 🧠 思考内容（可折叠）- 仅 AI 消息显示
                if (!isUser && !thinkingContent.isNullOrBlank()) {
                    ThinkingContentSection(
                        thinkingContent = thinkingContent,
                        isExpanded = isThinkingExpanded,
                        onToggle = { isThinkingExpanded = !isThinkingExpanded }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }
                
                // 消息文本
                Text(
                    text = displayedText,
                    color = when {
                        isFailed -> StatusColors.Error
                        isUser -> MaterialTheme.colorScheme.onPrimary
                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                    },
                    fontSize = 15.sp,
                    lineHeight = 22.sp
                )

                // 打字指示器
                if (isTyping && displayedText.length < message.length) {
                    Spacer(modifier = Modifier.height(4.dp))
                    TypingIndicator()
                }
                
                // 🔄 发送中状态指示器
                if (isSending) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(12.dp),
                            strokeWidth = 1.5.dp,
                            color = if (isUser) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.7f)
                                   else MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = if (retryCount > 0) "重试中... (第${retryCount}次)" else "发送中...",
                            fontSize = 11.sp,
                            color = if (isUser) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.7f)
                                   else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    }
                }
                
                // ❌ 失败状态和重试按钮
                if (isFailed) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Error,
                            contentDescription = null,
                            tint = StatusColors.Error,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = errorMessage?.take(30) ?: "发送失败",
                            fontSize = 11.sp,
                            color = StatusColors.Error,
                            maxLines = 1
                        )
                    }
                    
                    // 重试按钮（仅用户消息显示）
                    if (onRetryClick != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            onClick = onRetryClick,
                            shape = RoundedCornerShape(8.dp),
                            color = StatusColors.Error.copy(alpha = 0.2f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "重试",
                                    tint = StatusColors.Error,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (retryCount > 0) "再次重试" else "点击重试",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = StatusColors.Error
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==================== 🧠 思考内容区域 ====================

@Composable
private fun ThinkingContentSection(
    thinkingContent: String,
    isExpanded: Boolean,
    onToggle: () -> Unit
) {
    val rotationAngle by animateFloatAsState(
        targetValue = if (isExpanded) 180f else 0f,
        animationSpec = tween(300),
        label = "rotation"
    )
    
    Column {
        // 折叠/展开按钮
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onToggle)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Psychology,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f),
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = if (isExpanded) "收起思考过程" else "查看思考过程",
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                        fontSize = 12.sp
                    )
                }
                Icon(
                    imageVector = Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier
                        .size(18.dp)
                        .graphicsLayer { rotationZ = rotationAngle }
                )
            }
        }
        
        // 思考内容（可折叠）
        AnimatedVisibility(
            visible = isExpanded,
            enter = expandVertically(animationSpec = tween(300)) + fadeIn(),
            exit = shrinkVertically(animationSpec = tween(300)) + fadeOut()
        ) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp)
            ) {
                Column(
                    modifier = Modifier.padding(10.dp)
                ) {
                    Text(
                        text = thinkingContent,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}

// ==================== 打字指示器 ====================

@Composable
private fun TypingIndicator() {
    val infiniteTransition = rememberInfiniteTransition(label = "typing")

    Row(
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        repeat(3) { index ->
            val alpha by infiniteTransition.animateFloat(
                initialValue = 0.3f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(600, delayMillis = index * 150),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "dot_$index"
            )

            Box(
                modifier = Modifier
                    .size(6.dp)
                    .background(
                        color = Color.White.copy(alpha = alpha),
                        shape = CircleShape
                    )
            )
        }
    }
}

// ==================== 动态动作时间轴卡片 ====================

@Composable
fun ActionStatusCard(
    action: String,
    status: String
) {
    val isInProgress = status.contains("中") || status.contains("...") || status.contains("执行")
    val haptic = com.example.xihe.ui.utils.rememberHapticFeedback()
    
    // 呼吸动画（进行中状态）
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
        ),
        border = if (isInProgress) {
            androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = pulseAlpha))
        } else null
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            // 左侧状态指示器 (带连接线意向)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(
                            if (isInProgress) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                            else StatusColors.Success.copy(alpha = 0.2f)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isInProgress) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = pulseAlpha))
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = StatusColors.Success,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
                
                // 垂直连接线
                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .height(16.dp)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    if (isInProgress) MaterialTheme.colorScheme.primary.copy(alpha = 0.3f) else StatusColors.Success.copy(alpha = 0.3f),
                                    Color.Transparent
                                )
                            )
                        )
                )
            }

            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (isInProgress) "正在执行" else "已完成",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isInProgress) MaterialTheme.colorScheme.primary else StatusColors.Success
                    )
                    
                    if (isInProgress) {
                        Spacer(modifier = Modifier.width(6.dp))
                        // 小的旋转加载指示器
                        CircularProgressIndicator(
                            modifier = Modifier.size(10.dp),
                            strokeWidth = 1.dp,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = pulseAlpha)
                        )
                    }
                }

                Text(
                    text = action,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.9f),
                    lineHeight = 18.sp,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
                
                if (status.isNotBlank() && status != "已完成") {
                    Text(
                        text = "反馈: $status",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                    )
                }
            }
        }
    }
}

// ==================== 增强输入区域 ====================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EnhancedInputArea(
    inputText: String,
    onInputChange: (String) -> Unit,
    onSend: () -> Unit,
    onVoiceClick: () -> Unit,
    onImageClick: () -> Unit,
    isVoiceListening: Boolean,
    isTaskRunning: Boolean,
    attachedImageUri: String? = null,
    onClearImage: () -> Unit = {}
) {
    val haptic = rememberHapticFeedback()

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 8.dp
    ) {
        Column(
            modifier = Modifier.padding(12.dp)
        ) {
            // 📸 附件预览区
            AnimatedVisibility(
                visible = attachedImageUri != null,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Box(modifier = Modifier.padding(bottom = 12.dp)) {
                    ImagePreviewThumbnail(
                        imageUri = attachedImageUri ?: "",
                        onClick = { /* 放大预览 */ },
                        modifier = Modifier.size(60.dp)
                    )
                    // 删除按钮
                    Surface(
                        onClick = onClearImage,
                        shape = CircleShape,
                        color = Color.Black.copy(alpha = 0.7f),
                        modifier = Modifier
                            .size(20.dp)
                            .align(Alignment.TopEnd)
                            .offset(x = 6.dp, y = (-6).dp)
                    ) {
                        Icon(Icons.Default.Close, null, tint = Color.White, modifier = Modifier.padding(4.dp))
                    }
                }
            }

            // 语音波形（监听时显示）
            AnimatedVisibility(
                visible = isVoiceListening,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                VoiceWaveformWithStatus(
                    state = if (isVoiceListening) VoiceWaveformState.LISTENING else VoiceWaveformState.IDLE,
                    style = WaveformStyle.BARS,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 图片按钮 (如果有附件，变更为激活状态)
                IconButton(
                    onClick = onImageClick,
                    modifier = Modifier.size(40.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AddPhotoAlternate,
                        contentDescription = "选择图片",
                        tint = if (attachedImageUri != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // 输入框
                OutlinedTextField(
                    value = inputText,
                    onValueChange = onInputChange,
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp),
                    placeholder = {
                        Text(
                            text = if (isVoiceListening) "正在聆听..." else "输入消息或命令...",
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = MaterialTheme.colorScheme.onSurface,
                        unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = Color.Transparent,
                        cursorColor = MaterialTheme.colorScheme.primary
                    ),
                    shape = RoundedCornerShape(24.dp),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { onSend() })
                )

                // 语音/发送按钮
                val isInputActive = inputText.isNotBlank() || attachedImageUri != null
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(
                            if (isInputActive) MaterialTheme.colorScheme.primary
                            else if (isVoiceListening) StatusColors.Error
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = ripple(bounded = true)
                        ) {
                            haptic.lightTap()
                            if (isInputActive) {
                                onSend()
                            } else {
                                onVoiceClick()
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isInputActive) {
                            Icons.Default.Send
                        } else if (isVoiceListening) {
                            Icons.Default.Stop
                        } else {
                            Icons.Default.Mic
                        },
                        contentDescription = if (isInputActive) "发送" else "语音",
                        tint = if (isInputActive) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }
}

// ==================== 任务状态悬浮球 ====================

@Composable
fun TaskStatusBubble(
    progress: Float,
    isPaused: Boolean,
    onClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "bubble")

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Box(
        modifier = Modifier
            .size((56 * (if (isPaused) 1f else pulseScale)).dp)
            .shadow(8.dp, CircleShape)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        if (isPaused) StatusColors.Warning else MaterialTheme.colorScheme.primary,
                        if (isPaused) StatusColors.Warning.copy(alpha = 0.7f) else MaterialTheme.colorScheme.primaryContainer
                    )
                )
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        // 进度环
        CircularProgressIndicator(
            progress = { progress },
            modifier = Modifier.size(48.dp),
            color = Color.White.copy(alpha = 0.3f),
            strokeWidth = 3.dp,
            trackColor = Color.Transparent
        )

        // 百分比
        Text(
            text = "${(progress * 100).toInt()}%",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onPrimary
        )

        // 暂停图标
        if (isPaused) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .offset(x = 4.dp, y = 4.dp)
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surface),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Pause,
                    contentDescription = null,
                    tint = StatusColors.Warning,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}

// ==================== 图片预览缩略图 ====================

@Composable
fun ImagePreviewThumbnail(
    imageUri: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .size(80.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            // TODO: 加载实际图片
            Icon(
                imageVector = Icons.Default.Image,
                contentDescription = null,
                tint = Color.Gray,
                modifier = Modifier.size(32.dp)
            )

            // 放大图标
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(4.dp)
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.5f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ZoomIn,
                    contentDescription = "放大",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

// ==================== 任务进度条（简洁版） ====================

@Composable
fun TaskProgressBar(
    progress: Float,
    currentStep: Int,
    totalSteps: Int,
    description: String,
    isPaused: Boolean,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onStop: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .shadow(8.dp, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier.padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 进度信息
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // 状态指示
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(
                                color = if (isPaused) StatusColors.Warning else StatusColors.Success,
                                shape = CircleShape
                            )
                    )

                    Text(
                        text = if (isPaused) "已暂停" else "执行中",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isPaused) StatusColors.Warning else StatusColors.Success
                    )

                    Text(
                        text = "• 步骤 $currentStep/$totalSteps",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }

                // 控制按钮
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IconButton(
                        onClick = if (isPaused) onResume else onPause,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                            contentDescription = if (isPaused) "继续" else "暂停",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    IconButton(
                        onClick = onStop,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Stop,
                            contentDescription = "停止",
                            tint = StatusColors.Error,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 进度条
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = if (isPaused) StatusColors.Warning else MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            if (description.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = description,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

// ==================== 预览 ====================

@Composable
fun EnhancedChatInterfacePreview() {
    EnhancedChatInterface(
        onSendMessage = {},
        onVoiceInput = {},
        onImagePick = {},
        onStopTask = {}
    )
}
