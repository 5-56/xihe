package com.example.xihe.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.xihe.core.ProviderRegistry
import com.example.xihe.core.ProviderConfig
import com.example.xihe.core.PreferencesManager
import com.example.xihe.core.AutomationEngine
import com.example.xihe.ui.components.GlassmorphicCard
import com.example.xihe.ui.utils.rememberHapticFeedback
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

/**
 * 🔧 API 配置中枢 - 完整功能版
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApiConfigScreen(
    onBack: () -> Unit = {}
) {
    val context = LocalContext.current
    val haptic = rememberHapticFeedback()
    val scope = rememberCoroutineScope()
    
    var providers by remember { mutableStateOf(ProviderRegistry.getAllProviders()) }
    var currentProviderId by remember { mutableStateOf(PreferencesManager.getCurrentProviderId(context)) }
    var showAddDialog by remember { mutableStateOf(false) }
    var editingProvider by remember { mutableStateOf<ProviderConfig?>(null) }
    var configProvider by remember { mutableStateOf<ProviderConfig?>(null) }
    
    fun refresh() {
        providers = ProviderRegistry.getAllProviders()
        currentProviderId = PreferencesManager.getCurrentProviderId(context)
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("AI 模型配置", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "返回", tint = MaterialTheme.colorScheme.primary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) {
                Icon(Icons.Default.Add, "添加自定义提供商")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 80.dp, top = 8.dp)
        ) {
            item {
                Text(
                    "选择 AI 提供商",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                    modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
                )
            }
            
            items(providers) { provider ->
                val savedConfig = PreferencesManager.getProviderConfig(context, provider.id)
                val isConfigured = savedConfig != null && savedConfig.apiKey.isNotEmpty()
                val isCurrent = provider.id == currentProviderId
                
                ProviderCard(
                    provider = provider,
                    isCurrent = isCurrent,
                    isConfigured = isConfigured,
                    modelName = savedConfig?.modelName ?: "",
                    onSelect = {
                        haptic.lightTap()
                        ProviderRegistry.setCurrentProvider(context, provider.id)
                        // 同步到 AutomationEngine
                        savedConfig?.let { config ->
                            AutomationEngine.updateConfig(
                                newProviderId = provider.id,
                                newBaseUrl = config.baseUrl.ifEmpty { provider.defaultBaseUrl },
                                newApiKey = config.apiKey,
                                newModelName = config.modelName,
                                context = context
                            )
                        }
                        refresh()
                    },
                    onConfigure = {
                        haptic.lightTap()
                        configProvider = provider
                    },
                    onEdit = if (provider.isCustom) {
                        { editingProvider = provider }
                    } else null,
                    onDelete = if (provider.isCustom) {
                        {
                            haptic.mediumTap()
                            ProviderRegistry.deleteCustomProvider(context, provider.id)
                            refresh()
                        }
                    } else null
                )
            }
        }
    }
    
    // 添加自定义提供商对话框
    if (showAddDialog) {
        AddProviderDialog(
            onDismiss = { showAddDialog = false },
            onAdd = { name, url ->
                ProviderRegistry.addCustomProvider(context, name, url)
                refresh()
                showAddDialog = false
            }
        )
    }
    
    // 编辑自定义提供商对话框
    editingProvider?.let { provider ->
        EditProviderDialog(
            provider = provider,
            onDismiss = { editingProvider = null },
            onSave = { name, url ->
                ProviderRegistry.updateCustomProvider(context, provider.id, name, url)
                refresh()
                editingProvider = null
            }
        )
    }
    
    // 配置 API Key 和模型对话框
    configProvider?.let { provider ->
        ConfigureProviderDialog(
            provider = provider,
            onDismiss = { configProvider = null },
            onSave = { baseUrl, apiKey, modelName ->
                PreferencesManager.saveProviderConfig(context, provider.id, baseUrl, apiKey, modelName)
                // 如果是当前提供商，同步到 AutomationEngine
                if (provider.id == currentProviderId) {
                    AutomationEngine.updateConfig(
                        newProviderId = provider.id,
                        newBaseUrl = baseUrl,
                        newApiKey = apiKey,
                        newModelName = modelName,
                        context = context
                    )
                }
                refresh()
                configProvider = null
            }
        )
    }
}

@Composable
private fun ProviderCard(
    provider: ProviderConfig,
    isCurrent: Boolean,
    isConfigured: Boolean,
    modelName: String,
    onSelect: () -> Unit,
    onConfigure: () -> Unit,
    onEdit: (() -> Unit)?,
    onDelete: (() -> Unit)?
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onSelect),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isCurrent) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
        ),
        border = if (isCurrent) BorderStroke(1.dp, MaterialTheme.colorScheme.primary) else null
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 选中指示器
            Icon(
                imageVector = if (isCurrent) Icons.Default.RadioButtonChecked else Icons.Default.RadioButtonUnchecked,
                contentDescription = null,
                tint = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(24.dp)
            )
            
            Spacer(modifier = Modifier.width(12.dp))
            
            // 提供商信息
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        provider.name,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (provider.isCustom) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "自定义",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(4.dp))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }
                }
                
                Text(
                    provider.defaultBaseUrl,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    maxLines = 1
                )
                
                if (modelName.isNotEmpty()) {
                    Text(
                        "模型: $modelName",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f)
                    )
                }
                
                // 配置状态
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    Icon(
                        imageVector = if (isConfigured) Icons.Default.CheckCircle else Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (isConfigured) Color(0xFF4CAF50) else Color(0xFFFF9800),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        if (isConfigured) "已配置" else "未配置 API Key",
                        fontSize = 11.sp,
                        color = if (isConfigured) Color(0xFF4CAF50) else Color(0xFFFF9800)
                    )
                }
            }
            
            // 操作按钮
            Row {
                // 配置按钮
                IconButton(onClick = onConfigure) {
                    Icon(
                        Icons.Default.Settings,
                        "配置",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                
                // 编辑按钮（仅自定义提供商）
                onEdit?.let {
                    IconButton(onClick = it) {
                        Icon(Icons.Default.Edit, "编辑", tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f))
                    }
                }
                
                // 删除按钮（仅自定义提供商）
                onDelete?.let {
                    IconButton(onClick = it) {
                        Icon(Icons.Default.Delete, "删除", tint = Color(0xFFFF5252))
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddProviderDialog(
    onDismiss: () -> Unit,
    onAdd: (name: String, url: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("https://") }
    
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(24.dp)) {
                Text(
                    "添加自定义提供商",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("提供商名称") },
                    placeholder = { Text("例如: My API") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                        focusedLabelColor = MaterialTheme.colorScheme.primary,
                        cursorColor = MaterialTheme.colorScheme.primary,
                        focusedTextColor = MaterialTheme.colorScheme.onSurface,
                        unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                    )
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("API Base URL") },
                    placeholder = { Text("https://api.example.com/v1/") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                        focusedLabelColor = MaterialTheme.colorScheme.primary,
                        cursorColor = MaterialTheme.colorScheme.primary,
                        focusedTextColor = MaterialTheme.colorScheme.onSurface,
                        unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                    )
                )
                
                Spacer(modifier = Modifier.height(24.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("取消", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onAdd(name, url) },
                        enabled = name.isNotBlank() && url.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("添加", color = MaterialTheme.colorScheme.onPrimary)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditProviderDialog(
    provider: ProviderConfig,
    onDismiss: () -> Unit,
    onSave: (name: String, url: String) -> Unit
) {
    var name by remember { mutableStateOf(provider.name) }
    var url by remember { mutableStateOf(provider.defaultBaseUrl) }
    
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(24.dp)) {
                Text(
                    "编辑提供商",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("提供商名称") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                        focusedLabelColor = MaterialTheme.colorScheme.primary,
                        cursorColor = MaterialTheme.colorScheme.primary,
                        focusedTextColor = MaterialTheme.colorScheme.onSurface,
                        unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                    )
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("API Base URL") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                        focusedLabelColor = MaterialTheme.colorScheme.primary,
                        cursorColor = MaterialTheme.colorScheme.primary,
                        focusedTextColor = MaterialTheme.colorScheme.onSurface,
                        unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                    )
                )
                
                Spacer(modifier = Modifier.height(24.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("取消", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onSave(name, url) },
                        enabled = name.isNotBlank() && url.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("保存", color = MaterialTheme.colorScheme.onPrimary)
                    }
                }
            }
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ConfigureProviderDialog(
    provider: ProviderConfig,
    onDismiss: () -> Unit,
    onSave: (baseUrl: String, apiKey: String, modelName: String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    // 加载已保存的配置
    val savedConfig = PreferencesManager.getProviderConfig(context, provider.id)
    
    var baseUrl by remember { mutableStateOf(savedConfig?.baseUrl?.ifEmpty { provider.defaultBaseUrl } ?: provider.defaultBaseUrl) }
    var apiKey by remember { mutableStateOf(savedConfig?.apiKey ?: "") }
    var modelName by remember { mutableStateOf(savedConfig?.modelName ?: "") }
    var showApiKey by remember { mutableStateOf(false) }
    
    // 模型列表相关
    var availableModels by remember { mutableStateOf<List<String>>(emptyList()) }
    var isLoadingModels by remember { mutableStateOf(false) }
    var modelError by remember { mutableStateOf<String?>(null) }
    var showModelDropdown by remember { mutableStateOf(false) }
    
    // 获取可用模型列表
    fun fetchModels() {
        if (apiKey.isBlank()) {
            modelError = "请先输入 API Key"
            return
        }
        
        isLoadingModels = true
        modelError = null
        
        scope.launch {
            try {
                val models = withContext(Dispatchers.IO) {
                    fetchAvailableModels(baseUrl, apiKey)
                }
                availableModels = models
                if (models.isEmpty()) {
                    modelError = "未找到可用模型"
                }
            } catch (e: Exception) {
                modelError = "获取模型失败: ${e.message}"
                com.example.xihe.utils.LogManager.e("ApiConfigScreen", "获取模型列表失败", e)
            } finally {
                isLoadingModels = false
            }
        }
    }
    
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.verticalScroll(rememberScrollState())
        ) {
            Column(modifier = Modifier.padding(24.dp)) {
                Text(
                    "配置 ${provider.name}",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // API Base URL
                OutlinedTextField(
                    value = baseUrl,
                    onValueChange = { baseUrl = it },
                    label = { Text("API Base URL") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                        focusedLabelColor = MaterialTheme.colorScheme.primary,
                        cursorColor = MaterialTheme.colorScheme.primary,
                        focusedTextColor = MaterialTheme.colorScheme.onSurface,
                        unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                    )
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                // API Key
                OutlinedTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it },
                    label = { Text("API Key") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    visualTransformation = if (showApiKey) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showApiKey = !showApiKey }) {
                            Icon(
                                if (showApiKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = if (showApiKey) "隐藏" else "显示",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                        focusedLabelColor = MaterialTheme.colorScheme.primary,
                        cursorColor = MaterialTheme.colorScheme.primary,
                        focusedTextColor = MaterialTheme.colorScheme.onSurface,
                        unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                    )
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                // 模型名称输入 + 获取按钮
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedTextField(
                            value = modelName,
                            onValueChange = { modelName = it },
                            label = { Text("模型名称") },
                            placeholder = { Text("例如: gpt-4o, deepseek-chat") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            trailingIcon = {
                                if (availableModels.isNotEmpty()) {
                                    IconButton(onClick = { showModelDropdown = true }) {
                                        Icon(Icons.Default.ArrowDropDown, "选择模型", tint = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                                focusedLabelColor = MaterialTheme.colorScheme.primary,
                                cursorColor = MaterialTheme.colorScheme.primary,
                                focusedTextColor = MaterialTheme.colorScheme.onSurface,
                                unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        
                        // 模型下拉菜单
                        DropdownMenu(
                            expanded = showModelDropdown,
                            onDismissRequest = { showModelDropdown = false }
                        ) {
                            availableModels.forEach { model ->
                                DropdownMenuItem(
                                    text = { Text(model) },
                                    onClick = {
                                        modelName = model
                                        showModelDropdown = false
                                    }
                                )
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    // 获取模型列表按钮
                    Button(
                        onClick = { fetchModels() },
                        enabled = !isLoadingModels && apiKey.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f),
                            disabledContainerColor = Color.Gray.copy(alpha = 0.3f)
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        if (isLoadingModels) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(Icons.Default.Refresh, "获取模型", modifier = Modifier.size(18.dp))
                        }
                    }
                }
                
                // 错误提示
                modelError?.let { error ->
                    Text(
                        error,
                        fontSize = 12.sp,
                        color = Color(0xFFFF5252),
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                
                // 可用模型提示
                if (availableModels.isNotEmpty()) {
                    Text(
                        "找到 ${availableModels.size} 个可用模型，点击下拉选择",
                        fontSize = 12.sp,
                        color = Color(0xFF4CAF50),
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                
                Spacer(modifier = Modifier.height(24.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("取消", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onSave(baseUrl, apiKey, modelName) },
                        enabled = apiKey.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("保存", color = MaterialTheme.colorScheme.onPrimary)
                    }
                }
            }
        }
    }
}

/**
 * 从 API 获取可用模型列表
 */
private suspend fun fetchAvailableModels(baseUrl: String, apiKey: String): List<String> {
    // 检查是否是不支持模型列表的提供商
    val isWanQingApi = baseUrl.contains("wanqing.streamlakeapi.com")
    
    // 万清 AI 不支持 /models 端点，直接抛出友好提示
    if (isWanQingApi) {
        throw Exception("万清 AI 不支持自动获取模型列表，请手动输入模型名称（如: glm-5）")
    }
    
    val client = OkHttpClient.Builder()
        .connectTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
        .build()
    
    // 判断是否是 Google 原生 API
    val isGoogleNativeApi = baseUrl.contains("googleapis.com") && !baseUrl.contains("/openai/")
    
    // 构建 models 端点 URL
    val modelsUrl = if (isGoogleNativeApi) {
        // Google 原生 API 使用 URL 参数传递 API Key
        "https://generativelanguage.googleapis.com/v1beta/models?key=$apiKey"
    } else {
        if (baseUrl.endsWith("/")) {
            "${baseUrl}models"
        } else {
            "$baseUrl/models"
        }
    }
    
    // 构建请求，根据 API 类型选择认证方式
    val requestBuilder = Request.Builder()
        .url(modelsUrl)
        .addHeader("Content-Type", "application/json")
        .get()
    
    // Google 原生 API 不需要 Authorization header（使用 URL 参数）
    // Google OpenAI 兼容 API 使用 Bearer token
    // 其他 API 使用 Bearer token
    if (!isGoogleNativeApi) {
        requestBuilder.addHeader("Authorization", "Bearer $apiKey")
    }
    
    val request = requestBuilder.build()
    val response = client.newCall(request).execute()
    
    if (!response.isSuccessful) {
        throw Exception("HTTP ${response.code}: ${response.message}")
    }
    
    val body = response.body?.string() ?: throw Exception("空响应")
    val json = JSONObject(body)
    
    val models = mutableListOf<String>()
    
    // 解析响应 - 支持 OpenAI 格式和 Google 原生格式
    if (json.has("data")) {
        // OpenAI 格式
        val dataArray = json.getJSONArray("data")
        for (i in 0 until dataArray.length()) {
            val model = dataArray.getJSONObject(i)
            val id = model.optString("id", "")
            if (id.isNotEmpty()) {
                models.add(id)
            }
        }
    } else if (json.has("models")) {
        // Google 原生格式
        val modelsArray = json.getJSONArray("models")
        for (i in 0 until modelsArray.length()) {
            val model = modelsArray.getJSONObject(i)
            val name = model.optString("name", "")
            if (name.isNotEmpty()) {
                // Google 返回格式: "models/gemini-1.5-flash"，提取模型名
                val modelId = if (name.startsWith("models/")) {
                    name.substring(7)
                } else {
                    name
                }
                models.add(modelId)
            }
        }
    }
    
    // 按字母排序
    return models.sorted()
}
