package com.example.xihe.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.xihe.core.AutomationEngine
import com.example.xihe.core.PreferencesManager
import com.example.xihe.core.ProviderRegistry
import kotlinx.coroutines.launch

// 🆕 模型配置数据类
data class ProviderModelItem(
    val providerId: String,
    val providerName: String,
    val modelName: String,
    val isCurrentProvider: Boolean,
    val isCurrentModel: Boolean
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopBar(isServiceRunning: Boolean, onToggleService: () -> Unit, onOpenDrawer: () -> Unit, onShowVision: () -> Unit, onStartRealTimeChat: () -> Unit = {}) {
    val context = LocalContext.current
    
    // 🆕 使用 Flow 实时监听提供商变化，完全消除轮询延迟
    val currentProviderId by PreferencesManager.currentProviderIdFlow(context).collectAsStateWithLifecycle(
        initialValue = PreferencesManager.getCurrentProviderId(context)
    )
    
    // 模型选择器状态
    var expandedModel by remember { mutableStateOf(false) }
    var allProviderModels by remember { mutableStateOf<List<ProviderModelItem>>(emptyList()) }
    var refreshTrigger by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()
    
    // 🆕 当提供商 ID 变化时，自动重新加载模型列表
    LaunchedEffect(currentProviderId) {
        val modelItems = mutableListOf<ProviderModelItem>()
        val savedConfig = PreferencesManager.getProviderConfig(context, currentProviderId)
        val currentModelName = savedConfig?.modelName ?: AutomationEngine.modelName
        
        // 遍历所有提供商并收集已配置的模型
        ProviderRegistry.providers.forEach { provider ->
            val config = PreferencesManager.getProviderConfig(context, provider.id)
            if (config != null && (config.apiKey.isNotEmpty() || config.modelName.isNotEmpty())) {
                val isCurrentProvider = provider.id == currentProviderId
                modelItems.add(
                    ProviderModelItem(
                        providerId = provider.id,
                        providerName = provider.name,
                        modelName = config.modelName.ifEmpty { "未设置" },
                        isCurrentProvider = isCurrentProvider,
                        isCurrentModel = isCurrentProvider && config.modelName == currentModelName
                    )
                )
            }
        }
        
        // 如果没有任何已配置的提供商，显示当前项作为保底
        if (modelItems.isEmpty()) {
            val currentProvider = ProviderRegistry.getProviderById(currentProviderId)
            modelItems.add(ProviderModelItem(
                providerId = currentProviderId,
                providerName = currentProvider?.name ?: "Unknown",
                modelName = currentModelName,
                isCurrentProvider = true,
                isCurrentModel = true
            ))
        }
        allProviderModels = modelItems
    }

    val currentModelDisplay = allProviderModels.find { it.isCurrentModel }?.modelName ?: "选择模型"
    
    TopAppBar(
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "羲和 AI",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.width(8.dp))
                // Status Indicator
                Surface(
                    shape = RoundedCornerShape(50),
                    color = if (isServiceRunning) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(8.dp)
                ) {}
            }
        },
        navigationIcon = {
            IconButton(onClick = onOpenDrawer) {
                Icon(
                    Icons.Default.Menu,
                    contentDescription = "Menu",
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }
        },
        actions = {
            // 🎯 模型选择器（紧凑版）
            Box(
                modifier = Modifier.padding(horizontal = 4.dp)
            ) {
                Surface(
                    onClick = { expandedModel = true },
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "模型",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = currentModelDisplay.take(12) + if (currentModelDisplay.length > 12) "..." else "",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 12.sp,
                            maxLines = 1
                        )
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = "展开",
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                
                // 🆕 模型选择下拉菜单 - 显示所有已配置的提供商和模型
                DropdownMenu(
                    expanded = expandedModel,
                    onDismissRequest = { expandedModel = false },
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .widthIn(min = 200.dp, max = 300.dp)
                ) {
                    if (allProviderModels.isEmpty()) {
                        // 如果没有配置，显示提示
                        DropdownMenuItem(
                            text = { 
                                Text(
                                    "请先在设置中配置提供商",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 12.sp
                                )
                            },
                            onClick = { expandedModel = false }
                        )
                    } else {
                        // 按提供商分组显示
                        allProviderModels.forEachIndexed { index, item ->
                            // 提供商分组标题
                            if (index == 0 || allProviderModels[index - 1].providerId != item.providerId) {
                                // 提供商名称标题
                                Text(
                                    text = "📦 ${item.providerName}",
                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                                )
                            }
                            
                            // 模型选项
                            DropdownMenuItem(
                                text = { 
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        // 选中标记
                                        if (item.isCurrentModel) {
                                            Icon(
                                                Icons.Default.Check,
                                                contentDescription = "当前使用",
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                        } else {
                                            Spacer(modifier = Modifier.width(20.dp))
                                        }
                                        
                                        // 模型名称
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                item.modelName,
                                                color = if (item.isCurrentModel) {
                                                    MaterialTheme.colorScheme.primary
                                                } else {
                                                    MaterialTheme.colorScheme.onSurface
                                                },
                                                fontSize = 13.sp,
                                                fontWeight = if (item.isCurrentModel) FontWeight.Bold else FontWeight.Normal,
                                                maxLines = 1
                                            )
                                            // 如果不是当前提供商，显示提示
                                            if (!item.isCurrentProvider && item.isCurrentModel) {
                                                Text(
                                                    "当前使用",
                                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                                                    fontSize = 10.sp
                                                )
                                            }
                                        }
                                        
                                        // 当前提供商标记
                                        if (item.isCurrentProvider) {
                                            Text(
                                                "✓",
                                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                                                fontSize = 12.sp
                                            )
                                        }
                                    }
                                },
                                onClick = {
                                    expandedModel = false
                                    // 切换到选中的提供商和模型
                                    scope.launch {
                                        val config = PreferencesManager.getProviderConfig(context, item.providerId)
                                        if (config != null) {
                                            // 保存当前选择的提供商
                                            PreferencesManager.saveCurrentProviderId(context, item.providerId)
                                            
                                            // 更新引擎配置
                                            AutomationEngine.updateConfig(
                                                item.providerId,
                                                config.baseUrl,
                                                config.apiKey,
                                                item.modelName,
                                                context
                                            )
                                            
                                            // 触发刷新
                                            refreshTrigger++
                                            
                                            com.example.xihe.utils.LogManager.d("TopBar", "切换到: ${item.providerName} - ${item.modelName}")
                                        }
                                    }
                                },
                                modifier = Modifier.padding(horizontal = 8.dp)
                            )
                            
                            // 提供商之间的分隔线
                            if (index < allProviderModels.size - 1 && 
                                allProviderModels[index + 1].providerId != item.providerId) {
                                HorizontalDivider(
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f),
                                    modifier = Modifier.padding(vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
            
            // 📞 实时对话按钮
            IconButton(onClick = onStartRealTimeChat) {
                Icon(
                    Icons.Default.Call,
                    contentDescription = "实时对话",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
            
            // Service Toggle Switch
            Switch(
                checked = isServiceRunning,
                onCheckedChange = { onToggleService() },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = MaterialTheme.colorScheme.primary,
                    checkedTrackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                )
            )
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.background
        )
    )
}
