package com.example.xihe.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * ☀️ 浅色主题配色
 */
object LightTheme {
    val Primary = Color(0xFFFFFFFF)           // 纯白
    val Secondary = Color(0xFFF5F5F5)         // 浅灰白
    val Background = Color(0xFFFAFAFA)        // 背景白
    val Surface = Color(0xFFFFFFFF)           // 表面白
    
    val TextPrimary = Color(0xFF212121)       // 深灰文字
    val TextSecondary = Color(0xFF757575)     // 中灰文字
    val TextTertiary = Color(0xFF9E9E9E)      // 浅灰文字
    
    val Accent = Color(0xFF2196F3)            // 蓝色强调
    val AccentLight = Color(0xFF64B5F6)       // 浅蓝
    val AccentDark = Color(0xFF1976D2)        // 深蓝
    
    val Success = Color(0xFF4CAF50)           // 成功绿
    val Warning = Color(0xFFFF9800)           // 警告橙
    val Error = Color(0xFFF44336)             // 错误红
    
    val CardBackground = Color(0xFFFFFFFF)    // 卡片背景
    val CardBorder = Color(0xFFE0E0E0)        // 卡片边框
    
    val ButtonPrimary = Color(0xFF2196F3)     // 主按钮
    val ButtonSecondary = Color(0xFFE0E0E0)   // 次按钮
}

