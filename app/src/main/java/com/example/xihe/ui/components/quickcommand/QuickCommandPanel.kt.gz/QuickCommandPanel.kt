package com.example.xihe.ui.components.quickcommand

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.ripple
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.xihe.ui.utils.rememberHapticFeedback

/**
 * 🚀 快捷指令面板
 *
 * 功能：
 * 1. 悬浮式展开/收起面板
 * 2. 分类展示常用命令
 * 3. 支持自定义命令
 * 4. 动画效果和触觉反馈
 */

// ==================== 数据模型 ====================

data class QuickCommand(
    val id: String,
    val title: String,
    val description: String,
    val icon: ImageVector,
    val command: String,
    val category: CommandCategory,
    val color: Color = Color.Unspecified,
    val isPinned: Boolean = false
)

enum class CommandCategory(val displayName: String, val icon: ImageVector) {
    AUTOMATION("自动化", Icons.Default.AutoAwesome),
    SYSTEM("系统", Icons.Default.Settings),
    ENTERTAINMENT("娱乐", Icons.Default.SportsEsports),
    TOOLS("工具", Icons.Default.Build),
    CUSTOM("自定义", Icons.Default.Star)
}

// ==================== 预置命令 ====================

object QuickCommands {
    val presetCommands = listOf(
        // 自动化类
        QuickCommand(
            id = "video_swipe",
            title = "刷视频",
            description = "自动刷抖音/快手",
            icon = Icons.Default.VideoLibrary,
            command = "帮我刷50个抖音视频",
            category = CommandCategory.AUTOMATION,
            color = Color(0xFFFF6B6B)
        ),
        QuickCommand(
            id = "send_wechat",
            title = "发微信",
            description = "发送微信消息",
            icon = Icons.Default.Chat,
            command = "发微信给",
            category = CommandCategory.AUTOMATION,
            color = Color(0xFF4ECB71)
        ),
        QuickCommand(
            id = "open_app",
            title = "打开应用",
            description = "启动指定应用",
            icon = Icons.Default.OpenInNew,
            command = "打开",
            category = CommandCategory.AUTOMATION,
            color = Color(0xFF5B8DEF)
        ),
        QuickCommand(
            id = "screenshot",
            title = "截图",
            description = "截取当前屏幕",
            icon = Icons.Default.Screenshot,
            command = "帮我截图",
            category = CommandCategory.AUTOMATION,
            color = Color(0xFFFFAB40)
        ),

        // 系统类
        QuickCommand(
            id = "wifi_toggle",
            title = "WiFi开关",
            description = "切换WiFi状态",
            icon = Icons.Default.Wifi,
            command = "切换WiFi",
            category = CommandCategory.SYSTEM,
            color = Color(0xFF29B6F6)
        ),
        QuickCommand(
            id = "brightness",
            title = "亮度调节",
            description = "调整屏幕亮度",
            icon = Icons.Default.BrightnessHigh,
            command = "把亮度调到",
            category = CommandCategory.SYSTEM,
            color = Color(0xFFFFEB3B)
        ),
        QuickCommand(
            id = "volume",
            title = "音量调节",
            description = "调整系统音量",
            icon = Icons.Default.VolumeUp,
            command = "把音量调到",
            category = CommandCategory.SYSTEM,
            color = Color(0xFF7E57C2)
        ),
        QuickCommand(
            id = "dnd_mode",
            title = "勿扰模式",
            description = "开启/关闭勿扰",
            icon = Icons.Default.DoNotDisturb,
            command = "开启勿扰模式",
            category = CommandCategory.SYSTEM,
            color = Color(0xFFEC407A)
        ),

        // 娱乐类
        QuickCommand(
            id = "play_music",
            title = "播放音乐",
            description = "打开音乐应用播放",
            icon = Icons.Default.MusicNote,
            command = "播放音乐",
            category = CommandCategory.ENTERTAINMENT,
            color = Color(0xFFE91E63)
        ),
        QuickCommand(
            id = "gomoku",
            title = "五子棋",
            description = "和AI下五子棋",
            icon = Icons.Default.GridOn,
            command = "和我下五子棋",
            category = CommandCategory.ENTERTAINMENT,
            color = Color(0xFF000000)
        ),
        QuickCommand(
            id = "doudizhu",
            title = "斗地主",
            description = "智能出牌助手",
            icon = Icons.Default.Style,
            command = "帮我打斗地主",
            category = CommandCategory.ENTERTAINMENT,
            color = Color(0xFFD32F2F)
        ),
        QuickCommand(
            id = "joke",
            title = "讲笑话",
            description = "让AI讲个笑话",
            icon = Icons.Default.EmojiEmotions,
            command = "给我讲个笑话",
            category = CommandCategory.ENTERTAINMENT,
            color = Color(0xFFFFC107)
        ),

        // 工具类
        QuickCommand(
            id = "weather",
            title = "查天气",
            description = "获取当前天气",
            icon = Icons.Default.Cloud,
            command = "今天天气怎么样",
            category = CommandCategory.TOOLS,
            color = Color(0xFF03A9F4)
        ),
        QuickCommand(
            id = "reminder",
            title = "设提醒",
            description = "设置定时提醒",
            icon = Icons.Default.Alarm,
            command = "提醒我",
            category = CommandCategory.TOOLS,
            color = Color(0xFFFF5722)
        ),
        QuickCommand(
            id = "translate",
            title = "翻译",
            description = "文本翻译",
            icon = Icons.Default.Translate,
            command = "翻译：",
            category = CommandCategory.TOOLS,
            color = Color(0xFF009688)
        ),
        QuickCommand(
            id = "calculate",
            title = "计算器",
            description = "数学计算",
            icon = Icons.Default.Calculate,
            command = "计算",
            category = CommandCategory.TOOLS,
            color = Color(0xFF795548)
        )
    )

    fun getCommandsByCategory(category: CommandCategory): List<QuickCommand> {
        return presetCommands.filter { it.category == category }
    }

    fun getPinnedCommands(): List<QuickCommand> {
        return presetCommands.filter { it.isPinned }
    }
}

// ==================== 主组件 ====================

/**
 * 🎯 快捷指令面板
 *
 * @param expanded 是否展开
 * @param onExpandedChange 展开状态改变回调
 * @param onCommandSelected 命令选中回调
 * @param modifier Modifier
 */
@OptIn(ExperimentalAnimationApi::class)
@Composable
fun QuickCommandPanel(
    expanded: Boolean,
    onExpandedChange: (Boolean) -> Unit,
    onCommandSelected: (QuickCommand) -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = rememberHapticFeedback()
    var selectedCategory by remember { mutableStateOf<CommandCategory?>(null) }

    // 动画
    val rotationAngle by animateFloatAsState(
        targetValue = if (expanded) 45f else 0f,
        animationSpec = spring(dampingRatio = 0.6f),
        label = "rotation"
    )

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.End
    ) {
        // 展开的面板内容
        AnimatedVisibility(
            visible = expanded,
            enter = fadeIn() + expandVertically(expandFrom = Alignment.Bottom) + slideInVertically { it },
            exit = fadeOut() + shrinkVertically(shrinkTowards = Alignment.Bottom) + slideOutVertically { it }
        ) {
            QuickCommandPanelContent(
                selectedCategory = selectedCategory,
                onCategorySelected = {
                    haptic.lightTap()
                    selectedCategory = if (selectedCategory == it) null else it
                },
                onCommandSelected = { command ->
                    haptic.mediumTap()
                    onCommandSelected(command)
                    onExpandedChange(false)
                },
                onClose = { onExpandedChange(false) }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 悬浮按钮
        FloatingActionButton(
            onClick = {
                haptic.lightTap()
                onExpandedChange(!expanded)
                if (!expanded) selectedCategory = null
            },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier
                .size(56.dp)
                .shadow(8.dp, CircleShape)
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = if (expanded) "收起" else "快捷指令",
                modifier = Modifier
                    .size(28.dp)
                    .rotate(rotationAngle)
            )
        }
    }
}

/**
 * 📋 面板内容
 */
@Composable
private fun QuickCommandPanelContent(
    selectedCategory: CommandCategory?,
    onCategorySelected: (CommandCategory) -> Unit,
    onCommandSelected: (QuickCommand) -> Unit,
    onClose: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(320.dp)
            .shadow(16.dp, RoundedCornerShape(20.dp)),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            // 标题栏
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "⚡ 快捷指令",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                IconButton(
                    onClick = onClose,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "关闭",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 分类标签
            CategoryTabs(
                selectedCategory = selectedCategory,
                onCategorySelected = onCategorySelected
            )

            Spacer(modifier = Modifier.height(12.dp))

            // 命令列表
            CommandGrid(
                category = selectedCategory,
                onCommandSelected = onCommandSelected
            )
        }
    }
}

/**
 * 🏷️ 分类标签
 */
@Composable
private fun CategoryTabs(
    selectedCategory: CommandCategory?,
    onCategorySelected: (CommandCategory) -> Unit
) {
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(CommandCategory.values().toList()) { category ->
            CategoryChip(
                category = category,
                isSelected = selectedCategory == category,
                onClick = { onCategorySelected(category) }
            )
        }
    }
}

/**
 * 🔘 分类标签按钮
 */
@Composable
private fun CategoryChip(
    category: CommandCategory,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val backgroundColor by animateColorAsState(
        targetValue = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
        label = "chipBgColor"
    )

    val contentColor by animateColorAsState(
        targetValue = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
        label = "chipContentColor"
    )

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = backgroundColor
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = category.icon,
                contentDescription = null,
                tint = contentColor,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = category.displayName,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = contentColor
            )
        }
    }
}

/**
 * 📱 命令网格
 */
@Composable
private fun CommandGrid(
    category: CommandCategory?,
    onCommandSelected: (QuickCommand) -> Unit
) {
    val commands = if (category != null) {
        QuickCommands.getCommandsByCategory(category)
    } else {
        QuickCommands.presetCommands.take(8) // 默认显示前8个
    }

    LazyVerticalGrid(
        columns = GridCells.Fixed(4),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.height(180.dp)
    ) {
        items(commands) { command ->
            CommandItem(
                command = command,
                onClick = { onCommandSelected(command) }
            )
        }
    }
}

/**
 * 🎯 单个命令项
 */
@Composable
private fun CommandItem(
    command: QuickCommand,
    onClick: () -> Unit
) {
    val commandColor = if (command.color != Color.Unspecified) command.color else MaterialTheme.colorScheme.primary

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = true, color = commandColor)
            ) { onClick() }
            .padding(4.dp)
    ) {
        // 图标
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            commandColor.copy(alpha = 0.3f),
                            commandColor.copy(alpha = 0.1f)
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = command.icon,
                contentDescription = command.title,
                tint = commandColor,
                modifier = Modifier.size(24.dp)
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        // 标题
        Text(
            text = command.title,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

// ==================== 快捷入口组件 ====================

/**
 * 🚀 聊天界面底部快捷入口栏
 */
@Composable
fun QuickCommandBar(
    onCommandSelected: (QuickCommand) -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = rememberHapticFeedback()
    val hotCommands = remember {
        listOf(
            QuickCommands.presetCommands.find { it.id == "screenshot" },
            QuickCommands.presetCommands.find { it.id == "weather" },
            QuickCommands.presetCommands.find { it.id == "video_swipe" },
            QuickCommands.presetCommands.find { it.id == "send_wechat" }
        ).filterNotNull()
    }

    LazyRow(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(hotCommands) { command ->
            QuickCommandChip(
                command = command,
                onClick = {
                    haptic.lightTap()
                    onCommandSelected(command)
                }
            )
        }
    }
}

/**
 * 🏷️ 快捷命令标签
 */
@Composable
private fun QuickCommandChip(
    command: QuickCommand,
    onClick: () -> Unit
) {
    val commandColor = if (command.color != Color.Unspecified) command.color else MaterialTheme.colorScheme.primary

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = commandColor.copy(alpha = 0.15f),
        modifier = Modifier.height(32.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = command.icon,
                contentDescription = null,
                tint = commandColor,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = command.title,
                fontSize = 12.sp,
                color = commandColor,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

// ==================== 预览 ====================

@Composable
fun QuickCommandPanelPreview() {
    var expanded by remember { mutableStateOf(true) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        contentAlignment = Alignment.BottomEnd
    ) {
        QuickCommandPanel(
            expanded = expanded,
            onExpandedChange = { expanded = it },
            onCommandSelected = { /* Handle command */ }
        )
    }
}
