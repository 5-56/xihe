package com.example.xihe.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.xihe.health.HealthManager
import com.example.xihe.ui.charts.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter

/**
 * 📊 健康报告界面
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HealthReportScreen(
    healthManager: HealthManager,
    onBackClick: () -> Unit
) {
    val scrollState = rememberScrollState()
    val report = remember { healthManager.getHealthReport() }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("健康报告") },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, "返回")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // 日期
            Text(
                text = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy年MM月dd日")),
                style = MaterialTheme.typography.titleMedium,
                color = Color.Gray
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // 综合评分卡片
            OverallScoreCard(report.overallScore, report.evaluation)
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // 喝水趋势图
            LineChart(
                title = "每日喝水量",
                data = getWeeklyWaterData(),
                goal = report.waterGoal.toFloat(),
                lineColor = Color(0xFF03A9F4)
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // 步数柱状图
            BarChart(
                title = "每日步数",
                data = getWeeklyStepsData(),
                goal = report.stepsGoal.toFloat(),
                barColor = Color(0xFF4CAF50)
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // 运动时长饼图
            PieChart(
                title = "运动类型分布",
                data = listOf(
                    PieData("跑步", 15f, Color(0xFFFF5722)),
                    PieData("健身", 10f, Color(0xFF4CAF50)),
                    PieData("瑜伽", 5f, Color(0xFF9C27B0))
                )
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // 健康评分雷达图
            RadarChart(
                title = "健康评分",
                dimensions = listOf("喝水", "运动", "睡眠", "坐姿", "用眼"),
                scores = listOf(
                    report.waterCount.toFloat() / report.waterGoal * 100,
                    report.exerciseMinutes.toFloat() / report.exerciseGoal * 100,
                    80f, // 睡眠评分
                    75f, // 坐姿评分
                    70f  // 用眼评分
                ),
                fillColor = Color(0xFF2196F3)
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // 健康建议
            HealthSuggestionsCard(report.suggestions)
            
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

/**
 * 📊 综合评分卡片
 */
@Composable
fun OverallScoreCard(score: Int, evaluation: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = when {
                score >= 90 -> Color(0xFF4CAF50).copy(alpha = 0.1f)
                score >= 70 -> Color(0xFF2196F3).copy(alpha = 0.1f)
                score >= 50 -> Color(0xFFFF9800).copy(alpha = 0.1f)
                else -> Color(0xFFF44336).copy(alpha = 0.1f)
            }
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "综合评分",
                style = MaterialTheme.typography.titleMedium,
                color = Color.Gray
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "$score",
                style = MaterialTheme.typography.displayLarge,
                color = when {
                    score >= 90 -> Color(0xFF4CAF50)
                    score >= 70 -> Color(0xFF2196F3)
                    score >= 50 -> Color(0xFFFF9800)
                    else -> Color(0xFFF44336)
                }
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = evaluation,
                style = MaterialTheme.typography.bodyLarge,
                color = Color.Gray
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // 进度条
            LinearProgressIndicator(
                progress = score / 100f,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp),
                color = when {
                    score >= 90 -> Color(0xFF4CAF50)
                    score >= 70 -> Color(0xFF2196F3)
                    score >= 50 -> Color(0xFFFF9800)
                    else -> Color(0xFFF44336)
                }
            )
        }
    }
}

/**
 * 💡 健康建议卡片
 */
@Composable
fun HealthSuggestionsCard(suggestions: List<String>) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "💡 健康建议",
                style = MaterialTheme.typography.titleMedium
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            if (suggestions.isEmpty()) {
                Text(
                    text = "太棒了！保持现在的状态！",
                    color = Color.Gray
                )
            } else {
                suggestions.forEach { suggestion ->
                    Row(
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        Text("• ", color = Color.Gray)
                        Text(
                            text = suggestion,
                            color = Color.Gray,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

/**
 * 📊 获取每周喝水数据（示例）
 */
private fun getWeeklyWaterData(): List<ChartData> {
    return listOf(
        ChartData("周一", 6f),
        ChartData("周二", 7f),
        ChartData("周三", 5f),
        ChartData("周四", 8f),
        ChartData("周五", 7f),
        ChartData("周六", 6f),
        ChartData("周日", 8f)
    )
}

/**
 * 📊 获取每周步数数据（示例）
 */
private fun getWeeklyStepsData(): List<ChartData> {
    return listOf(
        ChartData("一", 8000f),
        ChartData("二", 9500f),
        ChartData("三", 7200f),
        ChartData("四", 10500f),
        ChartData("五", 8800f),
        ChartData("六", 6500f),
        ChartData("日", 11000f)
    )
}
