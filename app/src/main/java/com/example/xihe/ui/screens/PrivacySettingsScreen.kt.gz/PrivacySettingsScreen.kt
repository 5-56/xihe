package com.example.xihe.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.xihe.security.PrivacyPermissionManager
import com.example.xihe.security.PrivacyPermissionManager.PrivacyType

/**
 * 🔐 隐私权限设置界面
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacySettingsScreen(
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    
    // 初始化隐私权限管理器
    LaunchedEffect(Unit) {
        PrivacyPermissionManager.init(context)
    }
    
    val globalPrivacyEnabled by PrivacyPermissionManager.globalPrivacyEnabled.collectAsState()
    val permissionStates by PrivacyPermissionManager.permissionStates.collectAsState()
    
    var showResetDialog by remember { mutableStateOf(false) }
    var showInfoDialog by remember { mutableStateOf(false) }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("🔐 隐私权限设置") },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "返回")
                    }
                },
                actions = {
                    IconButton(onClick = { showInfoDialog = true }) {
                        Icon(Icons.Default.Info, contentDescription = "帮助")
                    }
                }
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 顶部说明卡片
            item {
                Spacer(modifier = Modifier.height(8.dp))
                PrivacyInfoCard()
            }
            
            // 一键授权开关
            item {
                GlobalPrivacySwitch(
                    enabled = globalPrivacyEnabled,
                    onToggle = { enabled ->
                        PrivacyPermissionManager.setGlobalPrivacyEnabled(enabled)
                    }
                )
            }
            
            // 权限统计
            item {
                val stats = PrivacyPermissionManager.getPermissionStats()
                PermissionStatsCard(stats)
            }
            
            // 分隔线
            item {
                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                Text(
                    text = "单项隐私权限",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }
            
            // 单项权限列表
            items(PrivacyType.values().toList()) { privacyType ->
                PrivacyPermissionItem(
                    type = privacyType,
                    enabled = permissionStates[privacyType] == true,
                    globalEnabled = globalPrivacyEnabled,
                    onToggle = { enabled ->
                        PrivacyPermissionManager.setPermission(privacyType, enabled)
                    }
                )
            }
            
            // 重置按钮
            item {
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedButton(
                    onClick = { showResetDialog = true },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("重置所有隐私权限")
                }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
    
    // 重置确认弹窗
    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("⚠️ 确认重置") },
            text = { Text("这将关闭所有隐私权限授权，之后访问隐私数据时会再次弹窗确认。确定要重置吗？") },
            confirmButton = {
                TextButton(
                    onClick = {
                        PrivacyPermissionManager.resetAllPermissions()
                        showResetDialog = false
                    },
                    colors = ButtonDefaults.textButtonColors(
                        contentColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Text("重置")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text("取消")
                }
            }
        )
    }
    
    // 帮助信息弹窗
    if (showInfoDialog) {
        AlertDialog(
            onDismissRequest = { showInfoDialog = false },
            title = { Text("🔐 关于隐私权限") },
            text = {
                Column {
                    Text(
                        "羲和AI助手非常重视您的隐私安全。\n\n" +
                        "• 【一键授权】：开启后，羲和可以直接访问所有隐私数据，无需每次确认\n\n" +
                        "• 【单项授权】：您可以针对每种隐私数据单独设置，开启后访问该类数据无需确认\n\n" +
                        "• 【未授权】：如果未开启授权，每次访问隐私数据前会弹窗询问您的同意\n\n" +
                        "您的数据永远只在本地使用，不会上传到任何服务器。"
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showInfoDialog = false }) {
                    Text("我知道了")
                }
            }
        )
    }
}

/**
 * 顶部说明卡片
 */
@Composable
private fun PrivacyInfoCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
        )
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Default.Security,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(40.dp)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(
                    text = "保护您的隐私",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "管理羲和访问您隐私数据的权限，您可以随时开启或关闭。",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }
        }
    }
}

/**
 * 一键授权开关
 */
@Composable
private fun GlobalPrivacySwitch(
    enabled: Boolean,
    onToggle: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (enabled) 
                MaterialTheme.colorScheme.primary.copy(alpha = 0.1f) 
            else 
                MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(
                            if (enabled) 
                                MaterialTheme.colorScheme.primary 
                            else 
                                MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        if (enabled) Icons.Default.LockOpen else Icons.Default.Lock,
                        contentDescription = null,
                        tint = if (enabled) Color.White else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = "一键授权所有隐私权限",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (enabled) "已开启 - 无需每次确认" else "未开启 - 访问时会弹窗确认",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (enabled) 
                            MaterialTheme.colorScheme.primary 
                        else 
                            MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            }
            Switch(
                checked = enabled,
                onCheckedChange = onToggle,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = MaterialTheme.colorScheme.primary,
                    checkedTrackColor = MaterialTheme.colorScheme.primaryContainer
                )
            )
        }
    }
}

/**
 * 权限统计卡片
 */
@Composable
private fun PermissionStatsCard(stats: PrivacyPermissionManager.PermissionStats) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            StatItem(
                value = stats.total.toString(),
                label = "总权限",
                color = MaterialTheme.colorScheme.outline
            )
            StatItem(
                value = stats.granted.toString(),
                label = "已授权",
                color = MaterialTheme.colorScheme.primary
            )
            StatItem(
                value = "${stats.percentage}%",
                label = "授权率",
                color = if (stats.percentage >= 100) 
                    Color(0xFF4CAF50) 
                else 
                    MaterialTheme.colorScheme.secondary
            )
        }
    }
}

@Composable
private fun StatItem(
    value: String,
    label: String,
    color: Color
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = color
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
        )
    }
}

/**
 * 单项隐私权限条目
 */
@Composable
private fun PrivacyPermissionItem(
    type: PrivacyType,
    enabled: Boolean,
    globalEnabled: Boolean,
    onToggle: (Boolean) -> Unit
) {
    val effectiveEnabled = globalEnabled || enabled
    
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (effectiveEnabled) 
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f)
            else 
                MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = type.icon,
                    fontSize = 28.sp
                )
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = type.displayName,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = getPrivacyTypeDescription(type),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            }
            Switch(
                checked = effectiveEnabled,
                onCheckedChange = { 
                    if (!globalEnabled) {
                        onToggle(it)
                    }
                },
                enabled = !globalEnabled, // 全局开启时禁用单项开关
                colors = SwitchDefaults.colors(
                    checkedThumbColor = MaterialTheme.colorScheme.primary,
                    checkedTrackColor = MaterialTheme.colorScheme.primaryContainer
                )
            )
        }
    }
}

/**
 * 获取隐私类型描述
 */
private fun getPrivacyTypeDescription(type: PrivacyType): String {
    return when (type) {
        PrivacyType.PHOTOS -> "允许查看相册中的照片和图片"
        PrivacyType.VIDEOS -> "允许查看存储的视频文件"
        PrivacyType.SMS -> "允许读取短信内容"
        PrivacyType.CONTACTS -> "允许访问通讯录联系人"
        PrivacyType.CALL_LOGS -> "允许查看通话记录"
        PrivacyType.FILES -> "允许访问文件和文档"
        PrivacyType.LOCATION -> "允许获取位置信息"
    }
}
