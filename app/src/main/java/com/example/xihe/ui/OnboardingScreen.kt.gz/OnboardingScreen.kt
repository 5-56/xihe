package com.example.xihe.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.xihe.ui.theme.DeepSpaceBlue

/**
 * 🎓 新手引导界面
 * 
 * 功能:
 * 1. 欢迎介绍
 * 2. 权限申请指引
 * 3. 功能演示
 * 4. 快速体验
 * 
 * 优化点:
 * - 友好的视觉设计
 * - 清晰的步骤说明
 * - 一键跳转到设置
 * - 可跳过的引导流程
 */
@OptIn(ExperimentalAnimationApi::class)
@Composable
fun OnboardingScreen(
    onComplete: () -> Unit = {},
    onSkip: () -> Unit = {}
) {
    var currentStep by remember { mutableStateOf(0) }
    val totalSteps = 5
    val context = LocalContext.current
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        DeepSpaceBlue.Primary,
                        DeepSpaceBlue.Secondary
                    )
                )
            )
    ) {
        // 步骤内容
        AnimatedContent(
            targetState = currentStep,
            transitionSpec = {
                slideInHorizontally { it } + fadeIn() with
                slideOutHorizontally { -it } + fadeOut()
            },
            label = "步骤切换"
        ) { step ->
            when (step) {
                0 -> WelcomeStep()
                1 -> FeaturesIntroStep()
                2 -> PermissionGuideStep(
                    permissionType = PermissionType.ACCESSIBILITY,
                    onGranted = { currentStep++ }
                )
                3 -> PermissionGuideStep(
                    permissionType = PermissionType.OVERLAY,
                    onGranted = { currentStep++ }
                )
                4 -> QuickStartStep(onComplete = onComplete)
            }
        }
        
        // 顶部进度指示器
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 32.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(horizontal = 32.dp)
            ) {
                repeat(totalSteps) { index ->
                    StepIndicator(
                        isActive = index == currentStep,
                        isCompleted = index < currentStep
                    )
                }
            }
            
            // 跳过按钮
            if (currentStep < totalSteps - 1) {
                TextButton(
                    onClick = onSkip,
                    modifier = Modifier
                        .align(Alignment.End)
                        .padding(end = 16.dp, top = 8.dp)
                ) {
                    Text("跳过", color = Color.White.copy(alpha = 0.7f))
                }
            }
        }
        
        // 底部导航按钮
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(32.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // 返回按钮
            if (currentStep > 0) {
                OutlinedButton(
                    onClick = { currentStep-- },
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = Color.White
                    )
                ) {
                    Icon(Icons.Default.ArrowBack, "返回")
                    Spacer(Modifier.width(4.dp))
                    Text("返回")
                }
            } else {
                Spacer(Modifier.width(1.dp))
            }
            
            // 下一步按钮
            if (currentStep < totalSteps - 1) {
                Button(
                    onClick = { currentStep++ },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = DeepSpaceBlue.Accent
                    )
                ) {
                    Text("下一步")
                    Spacer(Modifier.width(4.dp))
                    Icon(Icons.Default.ArrowForward, "下一步")
                }
            }
        }
    }
}

/**
 * 📍 步骤指示器
 */
@Composable
fun StepIndicator(
    isActive: Boolean,
    isCompleted: Boolean
) {
    val width by animateDpAsState(
        targetValue = if (isActive) 40.dp else 8.dp,
        animationSpec = spring(stiffness = Spring.StiffnessLow)
    )
    
    val color = when {
        isCompleted -> DeepSpaceBlue.Accent
        isActive -> Color.White
        else -> Color.White.copy(alpha = 0.3f)
    }
    
    Box(
        modifier = Modifier
            .width(width)
            .height(8.dp)
            .clip(CircleShape)
            .background(color)
    )
}

/**
 * 👋 欢迎步骤
 */
@Composable
fun WelcomeStep() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Logo动画
        val scale by rememberInfiniteTransition(label = "logo").animateFloat(
            initialValue = 0.9f,
            targetValue = 1.1f,
            animationSpec = infiniteRepeatable(
                animation = tween(1500, easing = EaseInOutCubic),
                repeatMode = RepeatMode.Reverse
            ),
            label = "logo_scale"
        )
        
        Box(
            modifier = Modifier
                .size(120.dp)
                .clip(CircleShape)
                .background(DeepSpaceBlue.Accent.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.AutoAwesome,
                contentDescription = "Logo",
                modifier = Modifier.size(60.dp),
                tint = DeepSpaceBlue.Accent
            )
        }
        
        Spacer(Modifier.height(32.dp))
        
        Text(
            text = "欢迎使用羲和AI",
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        
        Spacer(Modifier.height(16.dp))
        
        Text(
            text = "您的智能生活助手",
            fontSize = 18.sp,
            color = Color.White.copy(alpha = 0.7f)
        )
        
        Spacer(Modifier.height(48.dp))
        
        // 功能亮点
        FeatureHighlight(
            icon = Icons.Default.Mic,
            title = "语音控制",
            description = "解放双手，语音操作一切"
        )
        
        Spacer(Modifier.height(16.dp))
        
        FeatureHighlight(
            icon = Icons.Default.AutoFixHigh,
            title = "智能自动化",
            description = "AI帮你自动完成复杂任务"
        )
        
        Spacer(Modifier.height(16.dp))
        
        FeatureHighlight(
            icon = Icons.Default.Psychology,
            title = "深度学习",
            description = "越用越懂你的智能伙伴"
        )
    }
}

/**
 * ✨ 功能介绍步骤
 */
@Composable
fun FeaturesIntroStep() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(80.dp))
        
        Text(
            text = "羲和AI能做什么？",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        
        Spacer(Modifier.height(32.dp))
        
        FeatureCard(
            icon = Icons.Default.Chat,
            title = "智能对话",
            description = "自然语言交互，理解你的每一句话",
            color = Color(0xFF4CAF50)
        )
        
        Spacer(Modifier.height(16.dp))
        
        FeatureCard(
            icon = Icons.Default.TouchApp,
            title = "自动操作",
            description = "自动点击、滑动、输入，解放双手",
            color = Color(0xFF2196F3)
        )
        
        Spacer(Modifier.height(16.dp))
        
        FeatureCard(
            icon = Icons.Default.Apps,
            title = "跨应用协作",
            description = "在多个应用间自动完成复杂任务",
            color = Color(0xFFFF9800)
        )
        
        Spacer(Modifier.height(16.dp))
        
        FeatureCard(
            icon = Icons.Default.School,
            title = "自主学习",
            description = "录制操作序列，创建自动化任务",
            color = Color(0xFF9C27B0)
        )
        
        Spacer(Modifier.height(100.dp))
    }
}

/**
 * 🔐 权限引导步骤
 */
@Composable
fun PermissionGuideStep(
    permissionType: PermissionType,
    onGranted: () -> Unit
) {
    val context = LocalContext.current
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = permissionType.icon,
            contentDescription = permissionType.title,
            modifier = Modifier.size(80.dp),
            tint = DeepSpaceBlue.Accent
        )
        
        Spacer(Modifier.height(24.dp))
        
        Text(
            text = permissionType.title,
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        
        Spacer(Modifier.height(16.dp))
        
        Text(
            text = permissionType.description,
            fontSize = 16.sp,
            color = Color.White.copy(alpha = 0.8f),
            textAlign = TextAlign.Center
        )
        
        Spacer(Modifier.height(32.dp))
        
        // 为什么需要这个权限
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = Color.White.copy(alpha = 0.1f)
            ),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp)
            ) {
                Text(
                    text = "为什么需要这个权限？",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                
                Spacer(Modifier.height(12.dp))
                
                permissionType.reasons.forEach { reason ->
                    Row(
                        modifier = Modifier.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = DeepSpaceBlue.Accent,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = reason,
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
        
        Spacer(Modifier.height(32.dp))
        
        // 授权按钮
        Button(
            onClick = {
                when (permissionType) {
                    PermissionType.ACCESSIBILITY -> {
                        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    }
                    PermissionType.OVERLAY -> {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            context.startActivity(Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            ))
                        }
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = DeepSpaceBlue.Accent
            ),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text(
                text = "前往设置",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }
        
        Spacer(Modifier.height(16.dp))
        
        TextButton(
            onClick = onGranted
        ) {
            Text(
                "我已授权",
                color = Color.White.copy(alpha = 0.7f)
            )
        }
    }
}

/**
 * 🚀 快速开始步骤
 */
@Composable
fun QuickStartStep(onComplete: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Default.Celebration,
            contentDescription = "完成",
            modifier = Modifier.size(80.dp),
            tint = DeepSpaceBlue.Accent
        )
        
        Spacer(Modifier.height(24.dp))
        
        Text(
            text = "一切准备就绪！",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        
        Spacer(Modifier.height(16.dp))
        
        Text(
            text = "现在你可以体验羲和AI的强大功能了",
            fontSize = 16.sp,
            color = Color.White.copy(alpha = 0.8f),
            textAlign = TextAlign.Center
        )
        
        Spacer(Modifier.height(48.dp))
        
        // 示例任务
        Text(
            text = "试试这些命令：",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        
        Spacer(Modifier.height(16.dp))
        
        ExampleCommandCard("打开微信")
        Spacer(Modifier.height(12.dp))
        ExampleCommandCard("给张三发消息")
        Spacer(Modifier.height(12.dp))
        ExampleCommandCard("帮我搜索附近的餐厅")
        
        Spacer(Modifier.height(32.dp))
        
        Button(
            onClick = onComplete,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = DeepSpaceBlue.Accent
            ),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text(
                text = "开始使用",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

// ==================== 辅助组件 ====================

@Composable
fun FeatureHighlight(
    icon: ImageVector,
    title: String,
    description: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(DeepSpaceBlue.Accent.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                icon,
                contentDescription = title,
                tint = DeepSpaceBlue.Accent,
                modifier = Modifier.size(28.dp)
            )
        }
        
        Spacer(Modifier.width(16.dp))
        
        Column {
            Text(
                text = title,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = description,
                fontSize = 14.sp,
                color = Color.White.copy(alpha = 0.7f)
            )
        }
    }
}

@Composable
fun FeatureCard(
    icon: ImageVector,
    title: String,
    description: String,
    color: Color
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = color.copy(alpha = 0.15f)
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(color.copy(alpha = 0.3f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    icon,
                    contentDescription = title,
                    tint = color,
                    modifier = Modifier.size(24.dp)
                )
            }
            
            Spacer(Modifier.width(16.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = description,
                    fontSize = 13.sp,
                    color = Color.White.copy(alpha = 0.7f)
                )
            }
        }
    }
}

@Composable
fun ExampleCommandCard(command: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color.White.copy(alpha = 0.1f)
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Default.Mic,
                contentDescription = null,
                tint = DeepSpaceBlue.Accent,
                modifier = Modifier.size(20.dp)
            )
            Spacer(Modifier.width(12.dp))
            Text(
                text = "\"$command\"",
                color = Color.White,
                fontSize = 15.sp
            )
        }
    }
}

// ==================== 数据类 ====================

sealed class PermissionType(
    val icon: ImageVector,
    val title: String,
    val description: String,
    val reasons: List<String>
) {
    object ACCESSIBILITY : PermissionType(
        icon = Icons.Default.Accessibility,
        title = "无障碍服务",
        description = "这是羲和AI的核心权限，用于自动操作设备",
        reasons = listOf(
            "自动点击按钮和控件",
            "读取屏幕内容",
            "模拟手势操作",
            "跨应用执行任务"
        )
    )
    
    object OVERLAY : PermissionType(
        icon = Icons.Default.Layers,
        title = "悬浮窗权限",
        description = "用于显示对话窗口和状态提示",
        reasons = listOf(
            "显示对话泡泡",
            "实时任务进度",
            "快速语音输入",
            "状态通知"
        )
    )
}

