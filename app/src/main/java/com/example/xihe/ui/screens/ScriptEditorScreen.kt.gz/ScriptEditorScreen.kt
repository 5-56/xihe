package com.example.xihe.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.xihe.scripts.*

/**
 * 📜 脚本编辑器界面
 * 
 * 允许用户编辑脚本的各种参数：
 * - 调节每个动作的执行时间和等待时间
 * - 设置循环次数
 * - 自定义循环起点
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScriptEditorScreen(
    scriptId: String,
    onBack: () -> Unit,
    onSave: () -> Unit
) {
    val context = LocalContext.current
    val scriptManager = remember { ScriptManager.getInstance(context) }
    var script by remember { mutableStateOf(scriptManager.getScript(scriptId)) }
    var showLoopConfigDialog by remember { mutableStateOf(false) }
    var selectedStepId by remember { mutableStateOf<String?>(null) }
    var showTimingDialog by remember { mutableStateOf(false) }
    
    if (script == null) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text("脚本不存在", color = Color.Gray)
        }
        return
    }
    
    // 使用局部变量避免 !! 操作符
    val currentScript = script ?: return
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(currentScript.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "返回")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        script?.let { scriptManager.saveScript(it) }
                        onSave()
                    }) {
                        Icon(Icons.Default.Check, "保存")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // 脚本基本信息
            ScriptInfoCard(
                script = currentScript,
                onNameChange = { script = script?.copy(name = it) },
                onDescriptionChange = { script = script?.copy(description = it) }
            )
            
            // 循环配置卡片
            LoopConfigCard(
                loopConfig = currentScript.loopConfig,
                steps = currentScript.steps,
                onEditClick = { showLoopConfigDialog = true }
            )
            
            // 步骤列表
            Text(
                text = "📋 执行步骤 (${currentScript.steps.size})",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
            
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(currentScript.steps) { index, step ->
                    StepCard(
                        step = step,
                        index = index,
                        isLoopStart = currentScript.loopConfig.loopStartStepId == step.id,
                        isLoopEnd = currentScript.loopConfig.loopEndStepId == step.id,
                        onTimingClick = {
                            selectedStepId = step.id
                            showTimingDialog = true
                        },
                        onToggleEnabled = {
                            script?.let { s ->
                                val updatedSteps = s.steps.toMutableList()
                                updatedSteps[index] = step.copy(isEnabled = !step.isEnabled)
                                script = s.copy(steps = updatedSteps)
                            }
                        },
                        onSetLoopStart = {
                            script?.let { s ->
                                script = s.copy(
                                    loopConfig = s.loopConfig.copy(
                                        enabled = true,
                                        loopStartStepId = step.id
                                    )
                                )
                            }
                        },
                        onSetLoopEnd = {
                            script?.let { s ->
                                script = s.copy(
                                    loopConfig = s.loopConfig.copy(
                                        enabled = true,
                                        loopEndStepId = step.id
                                    )
                                )
                            }
                        }
                    )
                }
            }
            
            // 底部操作按钮
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        script = scriptManager.getScript(scriptId)
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Refresh, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("重置")
                }
                
                Button(
                    onClick = {
                        script?.let { scriptManager.saveScript(it) }
                        onSave()
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Check, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("保存")
                }
            }
        }
    }
    
    // 循环配置对话框
    if (showLoopConfigDialog) {
        script?.let { s ->
            LoopConfigDialog(
                loopConfig = s.loopConfig,
                steps = s.steps,
                onDismiss = { showLoopConfigDialog = false },
                onConfirm = { newConfig ->
                    script = s.copy(loopConfig = newConfig)
                    showLoopConfigDialog = false
                }
            )
        }
    }
    
    // 步骤时间配置对话框
    if (showTimingDialog && selectedStepId != null) {
        script?.let { s ->
            val selectedStep = s.steps.find { it.id == selectedStepId }
            if (selectedStep != null) {
                StepTimingDialog(
                    step = selectedStep,
                    onDismiss = { 
                        showTimingDialog = false
                        selectedStepId = null
                    },
                    onConfirm = { newTiming ->
                        val updatedSteps = s.steps.map { step ->
                            if (step.id == selectedStepId) {
                                step.copy(timing = newTiming)
                            } else {
                                step
                            }
                        }
                        script = s.copy(steps = updatedSteps)
                        showTimingDialog = false
                        selectedStepId = null
                    }
                )
            }
        }
    }
}

@Composable
private fun ScriptInfoCard(
    script: UserScript,
    onNameChange: (String) -> Unit,
    onDescriptionChange: (String) -> Unit
) {
    var isEditing by remember { mutableStateOf(false) }
    var editName by remember { mutableStateOf(script.name) }
    var editDescription by remember { mutableStateOf(script.description) }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = getCategoryEmoji(script.category),
                        fontSize = 24.sp
                    )
                    Spacer(Modifier.width(8.dp))
                    Column {
                        if (isEditing) {
                            OutlinedTextField(
                                value = editName,
                                onValueChange = { editName = it },
                                label = { Text("脚本名称") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(0.7f)
                            )
                        } else {
                            Text(
                                text = script.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                        }
                        Text(
                            text = script.appName,
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                    }
                }
                
                IconButton(onClick = {
                    if (isEditing) {
                        onNameChange(editName)
                        onDescriptionChange(editDescription)
                    }
                    isEditing = !isEditing
                }) {
                    Icon(
                        if (isEditing) Icons.Default.Check else Icons.Default.Edit,
                        "编辑"
                    )
                }
            }
            
            if (isEditing) {
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = editDescription,
                    onValueChange = { editDescription = it },
                    label = { Text("描述") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2
                )
            } else if (script.description.isNotEmpty()) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = script.description,
                    color = Color.Gray,
                    fontSize = 14.sp
                )
            }
            
            Spacer(Modifier.height(8.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                InfoChip("执行 ${script.executionCount} 次")
                InfoChip("${script.steps.size} 步骤")
                if (script.isFavorite) {
                    InfoChip("⭐ 收藏")
                }
            }
        }
    }
}

@Composable
private fun LoopConfigCard(
    loopConfig: LoopConfig,
    steps: List<ScriptStep>,
    onEditClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (loopConfig.enabled) 
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
            else 
                MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onEditClick() }
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("🔄", fontSize = 24.sp)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(
                        text = "循环配置",
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (loopConfig.enabled) {
                            buildString {
                                append(if (loopConfig.loopCount < 0) "无限循环" else "循环 ${loopConfig.loopCount} 次")
                                if (loopConfig.loopStartStepId != null) {
                                    val startStep = steps.find { it.id == loopConfig.loopStartStepId }
                                    append(" • 从「${startStep?.name ?: "?"}」开始")
                                }
                            }
                        } else {
                            "未启用循环"
                        },
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                }
            }
            
            Icon(Icons.Default.ChevronRight, "编辑", tint = Color.Gray)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun StepCard(
    step: ScriptStep,
    index: Int,
    isLoopStart: Boolean,
    isLoopEnd: Boolean,
    onTimingClick: () -> Unit,
    onToggleEnabled: () -> Unit,
    onSetLoopStart: () -> Unit,
    onSetLoopEnd: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = onTimingClick,
                onLongClick = { showMenu = true }
            ),
        colors = CardDefaults.cardColors(
            containerColor = when {
                !step.isEnabled -> Color.Gray.copy(alpha = 0.2f)
                isLoopStart -> Color(0xFF4CAF50).copy(alpha = 0.15f)
                isLoopEnd -> Color(0xFFFF9800).copy(alpha = 0.15f)
                else -> MaterialTheme.colorScheme.surface
            }
        ),
        border = when {
            isLoopStart -> BorderStroke(2.dp, Color(0xFF4CAF50))
            isLoopEnd -> BorderStroke(2.dp, Color(0xFFFF9800))
            else -> null
        }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 步骤序号
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(
                        if (step.isEnabled)
                            MaterialTheme.colorScheme.primary
                        else
                            Color.Gray
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "${index + 1}",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
            
            Spacer(Modifier.width(12.dp))
            
            // 步骤信息
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = step.name,
                        fontWeight = FontWeight.Medium,
                        color = if (step.isEnabled) Color.Unspecified else Color.Gray
                    )
                    if (isLoopStart) {
                        Spacer(Modifier.width(4.dp))
                        Text("🔄起点", fontSize = 10.sp, color = Color(0xFF4CAF50))
                    }
                    if (isLoopEnd) {
                        Spacer(Modifier.width(4.dp))
                        Text("🔄终点", fontSize = 10.sp, color = Color(0xFFFF9800))
                    }
                }
                Text(
                    text = "${getActionEmoji(step.actionType)} ${step.description}",
                    color = Color.Gray,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                
                // 时间配置
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    if (step.timing.waitBefore > 0) {
                        TimingChip("前等${step.timing.waitBefore}ms")
                    }
                    TimingChip("执行${step.timing.executionDuration}ms")
                    if (step.timing.waitAfter > 0) {
                        TimingChip("后等${step.timing.waitAfter}ms")
                    }
                    if (step.timing.randomDelay) {
                        TimingChip("🎲随机")
                    }
                }
            }
            
            // 操作按钮
            IconButton(onClick = onToggleEnabled) {
                Icon(
                    if (step.isEnabled) Icons.Default.CheckCircle else Icons.Default.Cancel,
                    "启用/禁用",
                    tint = if (step.isEnabled) Color(0xFF4CAF50) else Color.Gray
                )
            }
        }
        
        // 长按菜单
        DropdownMenu(
            expanded = showMenu,
            onDismissRequest = { showMenu = false }
        ) {
            DropdownMenuItem(
                text = { Text("⏱️ 编辑时间") },
                onClick = {
                    showMenu = false
                    onTimingClick()
                }
            )
            DropdownMenuItem(
                text = { Text("🔄 设为循环起点") },
                onClick = {
                    showMenu = false
                    onSetLoopStart()
                }
            )
            DropdownMenuItem(
                text = { Text("🔄 设为循环终点") },
                onClick = {
                    showMenu = false
                    onSetLoopEnd()
                }
            )
            DropdownMenuItem(
                text = { Text(if (step.isEnabled) "⏸️ 禁用步骤" else "▶️ 启用步骤") },
                onClick = {
                    showMenu = false
                    onToggleEnabled()
                }
            )
        }
    }
}

@Composable
private fun InfoChip(text: String) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
    ) {
        Text(
            text = text,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun TimingChip(text: String) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = Color(0xFF2196F3).copy(alpha = 0.1f)
    ) {
        Text(
            text = text,
            fontSize = 10.sp,
            color = Color(0xFF2196F3),
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
private fun LoopConfigDialog(
    loopConfig: LoopConfig,
    steps: List<ScriptStep>,
    onDismiss: () -> Unit,
    onConfirm: (LoopConfig) -> Unit
) {
    var enabled by remember { mutableStateOf(loopConfig.enabled) }
    var loopCount by remember { mutableStateOf(loopConfig.loopCount.toString()) }
    var isInfinite by remember { mutableStateOf(loopConfig.loopCount < 0) }
    var loopInterval by remember { mutableStateOf(loopConfig.loopInterval.toString()) }
    var selectedStartStepId by remember { mutableStateOf(loopConfig.loopStartStepId) }
    var selectedEndStepId by remember { mutableStateOf(loopConfig.loopEndStepId) }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("🔄 循环配置") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // 启用循环
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("启用循环")
                    Switch(
                        checked = enabled,
                        onCheckedChange = { enabled = it }
                    )
                }
                
                if (enabled) {
                    // 循环次数
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("无限循环")
                        Switch(
                            checked = isInfinite,
                            onCheckedChange = { isInfinite = it }
                        )
                    }
                    
                    if (!isInfinite) {
                        OutlinedTextField(
                            value = loopCount,
                            onValueChange = { loopCount = it.filter { c -> c.isDigit() } },
                            label = { Text("循环次数") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    
                    // 循环间隔
                    OutlinedTextField(
                        value = loopInterval,
                        onValueChange = { loopInterval = it.filter { c -> c.isDigit() } },
                        label = { Text("循环间隔 (毫秒)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    
                    // 循环起点
                    Text("循环起点", fontWeight = FontWeight.Medium)
                    LazyColumn(
                        modifier = Modifier.height(120.dp)
                    ) {
                        item {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedStartStepId = null }
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = selectedStartStepId == null,
                                    onClick = { selectedStartStepId = null }
                                )
                                Text("从头开始")
                            }
                        }
                        items(steps) { step ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedStartStepId = step.id }
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = selectedStartStepId == step.id,
                                    onClick = { selectedStartStepId = step.id }
                                )
                                Text("${step.order}. ${step.name}", maxLines = 1)
                            }
                        }
                    }
                    
                    // 循环终点
                    Text("循环终点", fontWeight = FontWeight.Medium)
                    LazyColumn(
                        modifier = Modifier.height(120.dp)
                    ) {
                        item {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedEndStepId = null }
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = selectedEndStepId == null,
                                    onClick = { selectedEndStepId = null }
                                )
                                Text("到末尾")
                            }
                        }
                        items(steps) { step ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedEndStepId = step.id }
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = selectedEndStepId == step.id,
                                    onClick = { selectedEndStepId = step.id }
                                )
                                Text("${step.order}. ${step.name}", maxLines = 1)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                onConfirm(LoopConfig(
                    enabled = enabled,
                    loopCount = if (isInfinite) -1 else loopCount.toIntOrNull() ?: 1,
                    loopStartStepId = selectedStartStepId,
                    loopEndStepId = selectedEndStepId,
                    loopInterval = loopInterval.toLongOrNull() ?: 0
                ))
            }) {
                Text("确定")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("取消")
            }
        }
    )
}

@Composable
private fun StepTimingDialog(
    step: ScriptStep,
    onDismiss: () -> Unit,
    onConfirm: (StepTiming) -> Unit
) {
    var executionDuration by remember { mutableStateOf(step.timing.executionDuration.toString()) }
    var waitBefore by remember { mutableStateOf(step.timing.waitBefore.toString()) }
    var waitAfter by remember { mutableStateOf(step.timing.waitAfter.toString()) }
    var timeout by remember { mutableStateOf(step.timing.timeout.toString()) }
    var randomDelay by remember { mutableStateOf(step.timing.randomDelay) }
    var randomDelayMin by remember { mutableStateOf(step.timing.randomDelayMin.toString()) }
    var randomDelayMax by remember { mutableStateOf(step.timing.randomDelayMax.toString()) }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("⏱️ 步骤时间配置") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = step.name,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                
                OutlinedTextField(
                    value = waitBefore,
                    onValueChange = { waitBefore = it.filter { c -> c.isDigit() } },
                    label = { Text("执行前等待 (毫秒)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                
                OutlinedTextField(
                    value = executionDuration,
                    onValueChange = { executionDuration = it.filter { c -> c.isDigit() } },
                    label = { Text("执行时长 (毫秒)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                
                OutlinedTextField(
                    value = waitAfter,
                    onValueChange = { waitAfter = it.filter { c -> c.isDigit() } },
                    label = { Text("执行后等待 (毫秒)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                
                OutlinedTextField(
                    value = timeout,
                    onValueChange = { timeout = it.filter { c -> c.isDigit() } },
                    label = { Text("超时时间 (毫秒)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                
                Divider()
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("🎲 随机延迟")
                    Switch(
                        checked = randomDelay,
                        onCheckedChange = { randomDelay = it }
                    )
                }
                
                if (randomDelay) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = randomDelayMin,
                            onValueChange = { 
                                randomDelayMin = it.filter { c -> c.isDigit() || c == '-' }
                            },
                            label = { Text("最小 (ms)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = randomDelayMax,
                            onValueChange = { 
                                randomDelayMax = it.filter { c -> c.isDigit() }
                            },
                            label = { Text("最大 (ms)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Text(
                        text = "提示：随机延迟会在执行时间基础上增加随机值",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                onConfirm(StepTiming(
                    executionDuration = executionDuration.toLongOrNull() ?: 300,
                    waitBefore = waitBefore.toLongOrNull() ?: 0,
                    waitAfter = waitAfter.toLongOrNull() ?: 500,
                    timeout = timeout.toLongOrNull() ?: 10000,
                    randomDelay = randomDelay,
                    randomDelayMin = randomDelayMin.toLongOrNull() ?: 0,
                    randomDelayMax = randomDelayMax.toLongOrNull() ?: 1000
                ))
            }) {
                Text("确定")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("取消")
            }
        }
    )
}

private fun getCategoryEmoji(category: ScriptCategory): String {
    return when (category) {
        ScriptCategory.MESSAGE -> "💬"
        ScriptCategory.VIDEO -> "📹"
        ScriptCategory.SEARCH -> "🔍"
        ScriptCategory.SHOPPING -> "🛒"
        ScriptCategory.SOCIAL -> "👥"
        ScriptCategory.GAME -> "🎮"
        ScriptCategory.OFFICE -> "📝"
        ScriptCategory.CUSTOM -> "⚙️"
    }
}

private fun getActionEmoji(actionType: ScriptActionType): String {
    return when (actionType) {
        ScriptActionType.LAUNCH_APP -> "🚀"
        ScriptActionType.CLICK -> "👆"
        ScriptActionType.LONG_CLICK -> "👇"
        ScriptActionType.INPUT_TEXT -> "⌨️"
        ScriptActionType.SWIPE_UP -> "⬆️"
        ScriptActionType.SWIPE_DOWN -> "⬇️"
        ScriptActionType.SWIPE_LEFT -> "⬅️"
        ScriptActionType.SWIPE_RIGHT -> "➡️"
        ScriptActionType.SCROLL -> "📜"
        ScriptActionType.PRESS_BACK -> "🔙"
        ScriptActionType.PRESS_HOME -> "🏠"
        ScriptActionType.WAIT -> "⏳"
        ScriptActionType.WAIT_FOR_ELEMENT -> "👀"
        ScriptActionType.CLOSE_POPUP -> "❌"
        ScriptActionType.TAKE_SCREENSHOT -> "📷"
        ScriptActionType.CUSTOM_GESTURE -> "✋"
    }
}
