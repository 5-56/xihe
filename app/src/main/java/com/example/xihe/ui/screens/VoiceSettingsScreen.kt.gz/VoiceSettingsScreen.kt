package com.example.xihe.ui.screens

import android.content.Context
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.xihe.core.ModuleCoordinator
import kotlinx.coroutines.launch

/**
 * 🎤 语音设置界面
 * 
 * 配置项:
 * 1. 语音识别开关
 * 2. 唤醒词设置
 * 3. 语音播报设置
 * 4. 语音速度/音调
 * 5. 离线模式设置
 */
/**
 * 🎤 语音设置工具类
 */
object VoiceSettingsPrefs {
    private const val PREFS_NAME = "xihe_voice_settings"
    
    fun getPrefs(context: Context) = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    
    // Keys
    const val KEY_ENABLE_VOICE_RECOGNITION = "enable_voice_recognition"
    const val KEY_ENABLE_WAKE_WORD = "enable_wake_word"
    const val KEY_ENABLE_TTS = "enable_tts"
    const val KEY_CONTINUOUS_LISTENING = "continuous_listening"
    const val KEY_USE_OFFLINE_RECOGNITION = "use_offline_recognition"
    const val KEY_USE_LOCAL_TTS = "use_local_tts"
    const val KEY_VOICE_SPEED = "voice_speed"
    const val KEY_VOICE_PITCH = "voice_pitch"
    const val KEY_WAKE_WORD = "wake_word"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceSettingsScreen(
    onBack: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { VoiceSettingsPrefs.getPrefs(context) }
    
    // 💾 从 SharedPreferences 加载设置
    var enableVoiceRecognition by remember { 
        mutableStateOf(prefs.getBoolean(VoiceSettingsPrefs.KEY_ENABLE_VOICE_RECOGNITION, true)) 
    }
    var enableWakeWord by remember { 
        mutableStateOf(prefs.getBoolean(VoiceSettingsPrefs.KEY_ENABLE_WAKE_WORD, false)) 
    }
    var enableTTS by remember { 
        mutableStateOf(prefs.getBoolean(VoiceSettingsPrefs.KEY_ENABLE_TTS, true)) 
    }
    var enableContinuousListening by remember { 
        mutableStateOf(prefs.getBoolean(VoiceSettingsPrefs.KEY_CONTINUOUS_LISTENING, false)) 
    }
    var useOfflineRecognition by remember { 
        mutableStateOf(prefs.getBoolean(VoiceSettingsPrefs.KEY_USE_OFFLINE_RECOGNITION, true)) 
    }
    var useLocalTTS by remember { 
        mutableStateOf(prefs.getBoolean(VoiceSettingsPrefs.KEY_USE_LOCAL_TTS, false)) 
    }
    var voiceSpeed by remember { 
        mutableFloatStateOf(prefs.getFloat(VoiceSettingsPrefs.KEY_VOICE_SPEED, 1.0f)) 
    }
    var voicePitch by remember { 
        mutableFloatStateOf(prefs.getFloat(VoiceSettingsPrefs.KEY_VOICE_PITCH, 1.0f)) 
    }
    var selectedWakeWord by remember { 
        mutableStateOf(prefs.getString(VoiceSettingsPrefs.KEY_WAKE_WORD, "羲和") ?: "羲和") 
    }
    
    // 📊 实时状态
    var isTesting by remember { mutableStateOf(false) }
    var testResult by remember { mutableStateOf<String?>(null) }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("🎤 语音设置") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "返回")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // ==================== 语音识别设置 ====================
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "🎤 语音识别",
                        style = MaterialTheme.typography.titleMedium
                    )
                    
                    HorizontalDivider()
                    
                    // 启用语音识别
                    SettingSwitch(
                        title = "启用语音识别",
                        subtitle = "允许通过语音与羲和交互",
                        checked = enableVoiceRecognition,
                        onCheckedChange = { 
                            enableVoiceRecognition = it
                            prefs.edit().putBoolean(VoiceSettingsPrefs.KEY_ENABLE_VOICE_RECOGNITION, it).apply()
                        }
                    )
                    
                    // 离线识别
                    SettingSwitch(
                        title = "离线语音识别",
                        subtitle = "使用 Vosk 本地模型，无需网络",
                        checked = useOfflineRecognition,
                        onCheckedChange = { 
                            useOfflineRecognition = it
                            prefs.edit().putBoolean(VoiceSettingsPrefs.KEY_USE_OFFLINE_RECOGNITION, it).apply()
                            // 🔧 实际切换识别引擎
                            ModuleCoordinator.setRecognizerType(it)
                        },
                        enabled = enableVoiceRecognition
                    )
                    
                    // 持续监听
                    SettingSwitch(
                        title = "持续监听模式",
                        subtitle = "识别完成后自动继续监听",
                        checked = enableContinuousListening,
                        onCheckedChange = { 
                            enableContinuousListening = it
                            prefs.edit().putBoolean(VoiceSettingsPrefs.KEY_CONTINUOUS_LISTENING, it).apply()
                            // 🔧 实际切换持续监听模式
                            ModuleCoordinator.setContinuousListening(it)
                        },
                        enabled = enableVoiceRecognition
                    )
                }
            }
            
            // ==================== 唤醒词设置 ====================
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "📢 唤醒词",
                        style = MaterialTheme.typography.titleMedium
                    )
                    
                    HorizontalDivider()
                    
                    // 启用唤醒词
                    SettingSwitch(
                        title = "启用唤醒词",
                        subtitle = "说「$selectedWakeWord」唤醒助手",
                        checked = enableWakeWord,
                        onCheckedChange = { 
                            enableWakeWord = it
                            prefs.edit().putBoolean(VoiceSettingsPrefs.KEY_ENABLE_WAKE_WORD, it).apply()
                            // 🔧 实际切换唤醒词检测
                            if (it) {
                                ModuleCoordinator.startWakeWordDetection()
                            } else {
                                ModuleCoordinator.stopWakeWordDetection()
                            }
                        },
                        enabled = enableVoiceRecognition
                    )
                    
                    // 唤醒词选择
                    AnimatedVisibility(visible = enableWakeWord) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "选择唤醒词",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("羲和", "小羲", "嘿羲和").forEach { word ->
                                    FilterChip(
                                        selected = selectedWakeWord == word,
                                        onClick = { 
                                            selectedWakeWord = word
                                            prefs.edit().putString(VoiceSettingsPrefs.KEY_WAKE_WORD, word).apply()
                                        },
                                        label = { Text(word) }
                                    )
                                }
                            }
                            
                            Text(
                                text = "💡 唤醒词检测会持续使用麦克风，可能增加耗电",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
            
            // ==================== 语音播报设置 ====================
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "🔊 语音播报",
                        style = MaterialTheme.typography.titleMedium
                    )
                    
                    HorizontalDivider()
                    
                    // 启用TTS
                    SettingSwitch(
                        title = "启用语音播报",
                        subtitle = "羲和会用语音回复你",
                        checked = enableTTS,
                        onCheckedChange = { 
                            enableTTS = it
                            prefs.edit().putBoolean(VoiceSettingsPrefs.KEY_ENABLE_TTS, it).apply()
                            // 🔧 实际切换语音播报
                            ModuleCoordinator.setEnableTTSResponse(it)
                        }
                    )
                    
                    // TTS 引擎选择 (使用 voice_settings 保持一致)
                    val voicePrefs = remember { context.getSharedPreferences("voice_settings", Context.MODE_PRIVATE) }
                    var selectedEngine by remember { 
                        mutableStateOf(voicePrefs.getString("tts_engine_type", "local") ?: "local") 
                    }
                    
                    // 当前引擎状态显示
                    val currentEngine = ModuleCoordinator.getCurrentTTSEngine()
                    val engineStatusText = when (currentEngine) {
                        "local" -> "✅ 本地模型 (Supertonic)"
                        "online" -> "🌐 在线API"
                        else -> "📱 系统TTS (Android)"
                    }
                    
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        shape = MaterialTheme.shapes.small
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "当前引擎：",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = engineStatusText,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    
                    // TTS 引擎选择器
                    Text(
                        text = "选择语音引擎",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        // 本地TTS选项
                        TTSEngineOption(
                            title = "🎵 本地模型",
                            subtitle = "Supertonic ONNX，离线快速",
                            selected = selectedEngine == "local",
                            onClick = {
                                selectedEngine = "local"
                                voicePrefs.edit().putString("tts_engine_type", "local").apply()
                                ModuleCoordinator.setTTSEngine("local")
                            },
                            enabled = enableTTS
                        )
                        
                        // 在线TTS选项
                        TTSEngineOption(
                            title = "🌐 在线API",
                            subtitle = "通过API调用在线TTS服务",
                            selected = selectedEngine == "online",
                            onClick = {
                                selectedEngine = "online"
                                voicePrefs.edit().putString("tts_engine_type", "online").apply()
                                ModuleCoordinator.setTTSEngine("online")
                            },
                            enabled = enableTTS
                        )
                        
                        // 系统TTS选项
                        TTSEngineOption(
                            title = "📱 系统TTS",
                            subtitle = "使用Android系统语音引擎",
                            selected = selectedEngine == "system",
                            onClick = {
                                selectedEngine = "system"
                                voicePrefs.edit().putString("tts_engine_type", "system").apply()
                                ModuleCoordinator.setTTSEngine("system")
                            },
                            enabled = enableTTS
                        )
                    }
                    
                    // 在线TTS配置（仅当选择在线时显示）
                    AnimatedVisibility(visible = selectedEngine == "online" && enableTTS) {
                        Column(
                            modifier = Modifier.padding(top = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            var onlineTtsUrl by remember { 
                                mutableStateOf(voicePrefs.getString("online_tts_url", "") ?: "") 
                            }
                            var onlineTtsKey by remember { 
                                mutableStateOf(voicePrefs.getString("online_tts_key", "") ?: "") 
                            }
                            
                            OutlinedTextField(
                                value = onlineTtsUrl,
                                onValueChange = { 
                                    onlineTtsUrl = it
                                    voicePrefs.edit().putString("online_tts_url", it).apply()
                                },
                                label = { Text("API 地址") },
                                placeholder = { Text("https://api.example.com/tts") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                            
                            OutlinedTextField(
                                value = onlineTtsKey,
                                onValueChange = { 
                                    onlineTtsKey = it
                                    voicePrefs.edit().putString("online_tts_key", it).apply()
                                },
                                label = { Text("API Key (可选)") },
                                placeholder = { Text("Bearer token...") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                        }
                    }
                    
                    // 语速调节
                    AnimatedVisibility(visible = enableTTS) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            // 语速
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "语速",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    text = "${String.format("%.1f", voiceSpeed)}x",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Slider(
                                value = voiceSpeed,
                                onValueChange = { voiceSpeed = it },
                                onValueChangeFinished = {
                                    prefs.edit().putFloat(VoiceSettingsPrefs.KEY_VOICE_SPEED, voiceSpeed).apply()
                                },
                                valueRange = 0.5f..2.0f,
                                steps = 5
                            )
                            
                            // 音调
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "音调",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    text = "${String.format("%.1f", voicePitch)}x",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Slider(
                                value = voicePitch,
                                onValueChange = { voicePitch = it },
                                onValueChangeFinished = {
                                    prefs.edit().putFloat(VoiceSettingsPrefs.KEY_VOICE_PITCH, voicePitch).apply()
                                },
                                valueRange = 0.5f..2.0f,
                                steps = 5
                            )
                            
                            // 测试按钮
                            Button(
                                onClick = {
                                    if (!isTesting) {
                                        isTesting = true
                                        testResult = null
                                        scope.launch {
                                            try {
                                                ModuleCoordinator.speak("你好主人，我是羲和，很高兴为您服务！")
                                                testResult = "✅ 播放成功"
                                            } catch (e: Exception) {
                                                testResult = "❌ 播放失败: ${e.message}"
                                            } finally {
                                                isTesting = false
                                            }
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !isTesting
                            ) {
                                if (isTesting) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(20.dp),
                                        strokeWidth = 2.dp,
                                        color = MaterialTheme.colorScheme.onPrimary
                                    )
                                } else {
                                    Icon(Icons.Default.PlayArrow, null)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(if (isTesting) "播放中..." else "测试语音")
                            }
                            
                            // 测试结果
                            testResult?.let { result ->
                                Text(
                                    text = result,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (result.startsWith("✅")) 
                                        MaterialTheme.colorScheme.primary 
                                    else 
                                        MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }
            
            // ==================== 权限状态 ====================
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "📋 权限状态",
                        style = MaterialTheme.typography.titleMedium
                    )
                    
                    HorizontalDivider()
                    
                    PermissionStatusItem(
                        icon = Icons.Default.Mic,
                        title = "麦克风权限",
                        granted = true // 实际应检查权限
                    )
                    
                    PermissionStatusItem(
                        icon = Icons.Default.RecordVoiceOver,
                        title = "语音识别服务",
                        granted = true
                    )
                    
                    PermissionStatusItem(
                        icon = Icons.Default.VolumeUp,
                        title = "语音合成服务",
                        granted = true
                    )
                }
            }
            
            // ==================== 使用说明 ====================
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "💡 使用技巧",
                        style = MaterialTheme.typography.titleMedium
                    )
                    
                    Text(
                        text = """
                            • 点击麦克风按钮开始语音输入
                            • 说话完毕后会自动识别
                            • 支持中英文混合识别
                            • 离线模式无需网络即可使用
                            • 持续监听模式适合连续对话
                        """.trimIndent(),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

/**
 * 设置开关项
 */
@Composable
private fun SettingSwitch(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    enabled: Boolean = true
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                color = if (enabled) 
                    MaterialTheme.colorScheme.onSurface 
                else 
                    MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(
                    alpha = if (enabled) 1f else 0.5f
                )
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            enabled = enabled
        )
    }
}

/**
 * 权限状态项
 */
@Composable
private fun PermissionStatusItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    granted: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (granted) 
                MaterialTheme.colorScheme.primary 
            else 
                MaterialTheme.colorScheme.error
        )
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(1f)
        )
        Icon(
            imageVector = if (granted) Icons.Default.CheckCircle else Icons.Default.Cancel,
            contentDescription = null,
            tint = if (granted) 
                MaterialTheme.colorScheme.primary 
            else 
                MaterialTheme.colorScheme.error
        )
    }
}

/**
 * TTS引擎选项
 */
@Composable
private fun TTSEngineOption(
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit,
    enabled: Boolean = true
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.small),
        color = if (selected) 
            MaterialTheme.colorScheme.primaryContainer 
        else 
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
        onClick = { if (enabled) onClick() }
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(
                selected = selected,
                onClick = { if (enabled) onClick() },
                enabled = enabled
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    color = if (enabled) 
                        MaterialTheme.colorScheme.onSurface 
                    else 
                        MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (enabled) 
                        MaterialTheme.colorScheme.onSurfaceVariant 
                    else 
                        MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                )
            }
            if (selected) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}
