package com.example.xihe.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.xihe.core.EnhancedAutomationEngine
import com.example.xihe.core.ModuleCoordinator
import com.example.xihe.interaction.VoiceInteractionManager
import kotlinx.coroutines.launch

/**
 * 🎨 增强功能控制面板
 * 显示和控制所有新功能模块
 */
@Composable
fun EnhancedFeaturesPanel(
    modifier: Modifier = Modifier,
    onClose: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    // 状态观察
    val engineState by EnhancedAutomationEngine.engineState.collectAsStateWithLifecycle()
    val currentMode by EnhancedAutomationEngine.currentMode.collectAsStateWithLifecycle()
    val isProcessing by EnhancedAutomationEngine.isProcessing.collectAsStateWithLifecycle()
    val moduleStatus = ModuleCoordinator.getStatusReport()
    
    // UI状态
    var expandedModule by remember { mutableStateOf<String?>(null) }
    var showVoiceIndicator by remember { mutableStateOf(false) }
    
    // 主题颜色
    val primaryColor = MaterialTheme.colorScheme.primary
    val backgroundColor = MaterialTheme.colorScheme.surface
    val surfaceColor = MaterialTheme.colorScheme.surfaceVariant
    
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp)
            .shadow(8.dp, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor)
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // 标题栏
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Star,
                        contentDescription = "增强功能",
                        tint = primaryColor,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "增强功能控制中心",
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                IconButton(onClick = onClose) {
                    Icon(
                        Icons.Default.Close,
                        contentDescription = "关闭",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // 引擎状态
            EngineStatusCard(
                engineState = engineState,
                currentMode = currentMode,
                isProcessing = isProcessing
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // 快速控制
            QuickControlsRow(
                onVoiceClick = {
                    showVoiceIndicator = true
                    EnhancedAutomationEngine.startVoiceInput()
                },
                onModeChange = { mode ->
                    EnhancedAutomationEngine.setExecutionMode(mode)
                }
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // 模块状态列表
            Text(
                "功能模块",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // 各个模块的状态卡片
            ModulesList(
                moduleStatus = moduleStatus,
                expandedModule = expandedModule,
                onModuleClick = { module ->
                    expandedModule = if (expandedModule == module) null else module
                }
            )
        }
    }
    
    // 语音指示器
    if (showVoiceIndicator) {
        VoiceRecordingIndicator(
            onDismiss = { showVoiceIndicator = false }
        )
    }
}

/**
 * 引擎状态卡片
 */
@Composable
fun EngineStatusCard(
    engineState: EnhancedAutomationEngine.EngineState,
    currentMode: EnhancedAutomationEngine.ExecutionMode,
    isProcessing: Boolean
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("引擎状态", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                Text(
                    engineState.name,
                    color = when (engineState) {
                        EnhancedAutomationEngine.EngineState.READY -> Color.Green
                        EnhancedAutomationEngine.EngineState.PROCESSING -> Color.Yellow
                        EnhancedAutomationEngine.EngineState.ERROR -> Color.Red
                        else -> Color.Gray
                    },
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("执行模式", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                Text(
                    currentMode.name,
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            
            if (isProcessing) {
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

/**
 * 快速控制按钮行
 */
@Composable
fun QuickControlsRow(
    onVoiceClick: () -> Unit,
    onModeChange: (EnhancedAutomationEngine.ExecutionMode) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        // 语音按钮
        FloatingActionButton(
            onClick = onVoiceClick,
            containerColor = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(56.dp)
        ) {
            Icon(
                Icons.Default.Mic,
                contentDescription = "语音输入",
                tint = MaterialTheme.colorScheme.onPrimary
            )
        }
        
        // 模式选择按钮
        OutlinedButton(
            onClick = { onModeChange(EnhancedAutomationEngine.ExecutionMode.SAFE) },
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = MaterialTheme.colorScheme.onSurface
            ),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
        ) {
            Icon(Icons.Default.Shield, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("安全模式")
        }
        
        OutlinedButton(
            onClick = { onModeChange(EnhancedAutomationEngine.ExecutionMode.LEARNING) },
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = MaterialTheme.colorScheme.onSurface
            ),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
        ) {
            Icon(Icons.Default.School, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("学习模式")
        }
    }
}

/**
 * 模块列表
 */
@Composable
fun ModulesList(
    moduleStatus: ModuleCoordinator.StatusReport,
    expandedModule: String?,
    onModuleClick: (String) -> Unit
) {
    Column {
        // AI模块
        ModuleCard(
            icon = Icons.Default.Psychology,
            title = "AI智能系统",
            subtitle = "意图理解、任务规划、屏幕分析",
            isAvailable = moduleStatus.aiReady,
            isExpanded = expandedModule == "AI",
            onClick = { onModuleClick("AI") }
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        // 语音模块
        ModuleCard(
            icon = Icons.Default.RecordVoiceOver,
            title = "语音交互",
            subtitle = "语音识别、合成、唤醒词",
            isAvailable = moduleStatus.voiceReady,
            isExpanded = expandedModule == "Voice",
            onClick = { onModuleClick("Voice") }
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        // 学习系统
        ModuleCard(
            icon = Icons.Default.AutoGraph,
            title = "学习系统",
            subtitle = "行为学习、预测优化",
            isAvailable = moduleStatus.learningReady,
            isExpanded = expandedModule == "Learning",
            onClick = { onModuleClick("Learning") }
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        // 性能优化
        ModuleCard(
            icon = Icons.Default.Speed,
            title = "性能优化",
            subtitle = "电池管理、内存优化",
            isAvailable = moduleStatus.performanceReady,
            isExpanded = expandedModule == "Performance",
            onClick = { onModuleClick("Performance") }
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        // 跨应用协作
        ModuleCard(
            icon = Icons.Default.SwapHoriz,
            title = "跨应用协作",
            subtitle = "多应用联动、数据传输",
            isAvailable = moduleStatus.crossAppReady,
            isExpanded = expandedModule == "CrossApp",
            onClick = { onModuleClick("CrossApp") }
        )
    }
}

/**
 * 模块卡片
 */
@Composable
fun ModuleCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    isAvailable: Boolean,
    isExpanded: Boolean,
    onClick: () -> Unit,
    expandedContent: @Composable (() -> Unit)? = null
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(
            containerColor = if (isAvailable) {
                MaterialTheme.colorScheme.surfaceVariant
            } else {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            }
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    icon,
                    contentDescription = null,
                    tint = if (isAvailable) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(24.dp)
                )
                
                Spacer(modifier = Modifier.width(12.dp))
                
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        title,
                        color = if (isAvailable) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        subtitle,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp
                    )
                }
                
                Icon(
                    if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            
            AnimatedVisibility(visible = isExpanded && expandedContent != null) {
                Column {
                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    Spacer(modifier = Modifier.height(8.dp))
                    expandedContent?.invoke()
                }
            }
        }
    }
}

/**
 * 语音录制指示器
 */
@Composable
fun VoiceRecordingIndicator(
    onDismiss: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.7f))
            .clickable { onDismiss() },
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier.size(200.dp),
            shape = CircleShape,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        Icons.Default.Mic,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        "正在聆听...",
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    CircularProgressIndicator(
                        modifier = Modifier.size(32.dp),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

/**
 * 模块状态项
 */
@Composable
fun ModuleStatusItem(
    name: String,
    isActive: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(name, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
        )
    }
}

/**
 * 性能指标
 */
@Composable
fun PerformanceMetric(
    label: String,
    value: String,
    color: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        Text(value, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}
