package com.example.xihe.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.xihe.training.*
import kotlinx.coroutines.launch

/**
 * 🎮 训练控制界面
 * 
 * 功能：
 * 1. 实时显示系统状态
 * 2. 手动开始/停止训练
 * 3. 查看训练建议
 * 4. 自定义训练配置
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrainingControlScreen(
    onBack: () -> Unit = {},
    onManageData: () -> Unit = {},
    onKeepAliveSettings: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    // 系统监控
    val monitor = remember { SystemMonitor.getInstance(context) }
    val systemState by monitor.systemState.collectAsStateWithLifecycle()
    val userState by monitor.userState.collectAsStateWithLifecycle()
    val recommendation by monitor.trainingRecommendation.collectAsStateWithLifecycle()
    
    // 训练器
    val trainer = remember { LocalModelTrainer.getInstance(context) }
    var isTraining by remember { mutableStateOf(false) }
    var trainingProgress by remember { mutableStateOf<TrainingProgress?>(null) }
    
    // 启动监控
    LaunchedEffect(Unit) {
        monitor.startMonitoring()
    }
    
    DisposableEffect(Unit) {
        onDispose {
            monitor.stopMonitoring()
        }
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("🎮 训练控制中心") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "返回")
                    }
                },
                actions = {
                    IconButton(onClick = onKeepAliveSettings) {
                        Icon(Icons.Default.Security, "保活设置")
                    }
                    IconButton(onClick = onManageData) {
                        Icon(Icons.Default.Storage, "数据管理")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. 系统状态卡片
            SystemStatusCard(systemState, userState)
            
            // 2. 训练建议卡片
            TrainingRecommendationCard(recommendation)
            
            // 3. 训练控制卡片
            TrainingControlCard(
                isTraining = isTraining,
                progress = trainingProgress,
                canStartTraining = recommendation.canStartTraining,
                onStartTraining = {
                    scope.launch {
                        isTraining = true
                        val result = trainer.startTraining { progress ->
                            trainingProgress = progress
                        }
                        isTraining = false
                        trainingProgress = null
                    }
                },
                onStopTraining = {
                    trainer.pauseTraining()
                    isTraining = false
                }
            )
            
            // 4. 详细信息
            DetailedInfoCard(systemState, userState)
        }
    }
}

/**
 * 📊 系统状态卡片
 */
@Composable
fun SystemStatusCard(systemState: SystemState, userState: UserState) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "📊 系统状态",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            Divider()
            
            // 温度
            StatusRow(
                icon = "🌡️",
                label = "设备温度",
                value = "${systemState.temperature}°C",
                isGood = systemState.temperature < 40f
            )
            
            // 电池
            StatusRow(
                icon = "🔋",
                label = "电池状态",
                value = "${systemState.batteryLevel}% ${if (systemState.isCharging) "⚡充电中" else ""}",
                isGood = systemState.batteryLevel > 50 && systemState.isCharging
            )
            
            // 内存
            StatusRow(
                icon = "💾",
                label = "可用内存",
                value = "${systemState.availableMemoryMB}MB (使用${systemState.memoryUsagePercent}%)",
                isGood = systemState.memoryUsagePercent < 70
            )
            
            // 存储
            StatusRow(
                icon = "💿",
                label = "存储空间",
                value = "${systemState.availableStorageMB}MB 可用",
                isGood = systemState.availableStorageMB > 500
            )
            
            // 用户状态
            StatusRow(
                icon = if (userState.isProbablySleeping) "😴" else if (userState.isDeviceIdle) "💤" else "👤",
                label = "用户状态",
                value = when {
                    userState.isProbablySleeping -> "睡眠中"
                    userState.isDeviceIdle -> "设备空闲"
                    else -> "使用中"
                },
                isGood = userState.isProbablySleeping || userState.isDeviceIdle
            )
        }
    }
}

/**
 * 💡 训练建议卡片
 */
@Composable
fun TrainingRecommendationCard(recommendation: TrainingRecommendation) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (recommendation.shouldStartTraining) {
                MaterialTheme.colorScheme.primaryContainer
            } else {
                MaterialTheme.colorScheme.surfaceVariant
            }
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "💡 训练建议",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                
                if (recommendation.shouldStartTraining) {
                    AssistChip(
                        onClick = {},
                        label = { Text("✅ 推荐训练") },
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            labelColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                }
            }
            
            Divider()
            
            // 建议原因
            Text(
                text = recommendation.reason,
                style = MaterialTheme.typography.bodyLarge
            )
            
            // 信心度
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("信心度:")
                LinearProgressIndicator(
                    progress = recommendation.confidence,
                    modifier = Modifier.weight(1f)
                )
                Text("${(recommendation.confidence * 100).toInt()}%")
            }
            
            // 阻碍因素
            if (recommendation.blockers.isNotEmpty()) {
                Text(
                    text = "🚫 阻碍因素:",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
                recommendation.blockers.forEach { blocker ->
                    Text(
                        text = "• $blocker",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }
}

/**
 * 🎮 训练控制卡片
 */
@Composable
fun TrainingControlCard(
    isTraining: Boolean,
    progress: TrainingProgress?,
    canStartTraining: Boolean,
    onStartTraining: () -> Unit,
    onStopTraining: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "🎮 手动控制",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            Divider()
            
            if (isTraining) {
                // 训练中
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "⚡ 训练进行中...",
                        style = MaterialTheme.typography.titleSmall
                    )
                    
                    progress?.let {
                        Text("阶段: ${it.stage}")
                        LinearProgressIndicator(
                            progress = it.progress,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text("进度: ${(it.progress * 100).toInt()}%")
                    }
                    
                    Button(
                        onClick = onStopTraining,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.error
                        )
                    ) {
                        Icon(Icons.Default.Stop, null)
                        Spacer(Modifier.width(8.dp))
                        Text("停止训练")
                    }
                }
            } else {
                // 未训练
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onStartTraining,
                        modifier = Modifier.fillMaxWidth(),
                        enabled = canStartTraining
                    ) {
                        Icon(Icons.Default.PlayArrow, null)
                        Spacer(Modifier.width(8.dp))
                        Text("立即开始训练")
                    }
                    
                    if (!canStartTraining) {
                        Text(
                            text = "⚠️ 当前条件不适合训练",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        }
    }
}

/**
 * 📋 详细信息卡片
 */
@Composable
fun DetailedInfoCard(systemState: SystemState, userState: UserState) {
    var expanded by remember { mutableStateOf(false) }
    
    Card(
        modifier = Modifier.fillMaxWidth(),
        onClick = { expanded = !expanded }
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "📋 详细信息",
                    style = MaterialTheme.typography.titleMedium
                )
                Icon(
                    imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = if (expanded) "收起" else "展开"
                )
            }
            
            if (expanded) {
                Divider()
                
                DetailRow("电池健康", systemState.batteryHealth)
                DetailRow("总内存", "${systemState.totalMemoryMB}MB")
                DetailRow("屏幕状态", if (systemState.isScreenOn) "开启" else "关闭")
                DetailRow("光线强度", "${systemState.lightLevel} lux")
                DetailRow("CPU使用率", "${systemState.cpuUsagePercent}%")
                DetailRow("屏幕关闭时长", "${userState.screenOffDurationMinutes}分钟")
                DetailRow("当前活动", userState.currentActivity)
            }
        }
    }
}

/**
 * 状态行组件
 */
@Composable
fun StatusRow(icon: String, label: String, value: String, isGood: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(icon, style = MaterialTheme.typography.titleMedium)
            Text(label, style = MaterialTheme.typography.bodyMedium)
        }
        
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = if (isGood) {
                MaterialTheme.colorScheme.primary
            } else {
                MaterialTheme.colorScheme.error
            }
        )
    }
}

/**
 * 详细信息行
 */
@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold
        )
    }
}
