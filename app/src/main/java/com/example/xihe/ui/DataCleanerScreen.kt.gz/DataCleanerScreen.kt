package com.example.xihe.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.xihe.data.*
import kotlinx.coroutines.launch

/**
 * 🧹 数据清洗界面
 * 
 * 功能：
 * 1. 📁 上传文件（支持大文件）
 * 2. 🔍 自动识别内容类型
 * 3. 📊 显示清洗进度和结果
 * 4. 💾 保存为训练数据
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DataCleanerScreen(
    onNavigateBack: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val cleaner = remember { TrainingDataCleaner.getInstance(context) }
    
    // 状态
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var selectedFileName by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf(TrainingDataCleaner.TYPE_AUTO) }
    var isProcessing by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(CleaningProgress()) }
    var result by remember { mutableStateOf<CleaningResult?>(null) }
    var showPreview by remember { mutableStateOf(false) }
    var saveSuccess by remember { mutableStateOf(false) }
    
    // 文件选择器
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            selectedUri = it
            selectedFileName = it.lastPathSegment ?: "未知文件"
            result = null
            saveSuccess = false
        }
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("🧹 数据清洗工具") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, "返回")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 📁 文件选择区域
            item {
                FileSelectionCard(
                    selectedFileName = selectedFileName,
                    onSelectFile = { filePickerLauncher.launch("*/*") }
                )
            }
            
            // 🔧 内容类型选择
            item {
                ContentTypeSelector(
                    selectedType = selectedType,
                    onTypeSelected = { selectedType = it }
                )
            }
            
            // 🚀 开始清洗按钮
            item {
                Button(
                    onClick = {
                        selectedUri?.let { uri ->
                            isProcessing = true
                            result = null
                            scope.launch {
                                val cleanResult = cleaner.cleanFile(
                                    uri = uri,
                                    contentType = selectedType,
                                    onProgress = { progress = it }
                                )
                                result = cleanResult
                                isProcessing = false
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = selectedUri != null && !isProcessing,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    if (isProcessing) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = Color.White,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("处理中...")
                    } else {
                        Icon(Icons.Default.PlayArrow, null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("开始清洗", fontSize = 16.sp)
                    }
                }
            }
            
            // 📊 进度显示
            if (isProcessing) {
                item {
                    ProgressCard(progress = progress)
                }
            }
            
            // 📈 结果显示
            result?.let { cleanResult ->
                when (cleanResult) {
                    is CleaningResult.Success -> {
                        item {
                            ResultCard(
                                result = cleanResult,
                                onPreview = { showPreview = true },
                                onSave = {
                                    scope.launch {
                                        cleaner.saveTrainingData(cleanResult.trainingData)
                                        saveSuccess = true
                                    }
                                },
                                saveSuccess = saveSuccess
                            )
                        }
                        
                        // 数据预览
                        if (showPreview) {
                            item {
                                DataPreviewCard(
                                    pairs = cleanResult.pairs.take(20),
                                    onClose = { showPreview = false }
                                )
                            }
                        }
                    }
                    is CleaningResult.Error -> {
                        item {
                            ErrorCard(message = cleanResult.message)
                        }
                    }
                }
            }
            
            // 📖 使用说明
            item {
                DataCleanerUsageGuideCard()
            }
        }
    }
}

/**
 * 📁 文件选择卡片
 */
@Composable
private fun FileSelectionCard(
    selectedFileName: String,
    onSelectFile: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "📁 选择文件",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .border(
                        2.dp,
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                        RoundedCornerShape(12.dp)
                    )
                    .background(MaterialTheme.colorScheme.surface)
                    .clickable(onClick = onSelectFile),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.CloudUpload,
                        contentDescription = null,
                        modifier = Modifier.size(40.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (selectedFileName.isEmpty()) "点击选择文件" else selectedFileName,
                        color = if (selectedFileName.isEmpty()) 
                            MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        else MaterialTheme.colorScheme.primary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "支持：TXT、JSON、聊天记录导出文件等",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
        }
    }
}

/**
 * 🔧 内容类型选择器
 */
@Composable
private fun ContentTypeSelector(
    selectedType: String,
    onTypeSelected: (String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "🔧 内容类型",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            val types = listOf(
                TrainingDataCleaner.TYPE_AUTO to "🤖 自动识别",
                TrainingDataCleaner.TYPE_NOVEL to "📚 小说对话",
                TrainingDataCleaner.TYPE_CHAT to "💬 聊天记录",
                TrainingDataCleaner.TYPE_QA to "❓ 问答对",
                TrainingDataCleaner.TYPE_TEXT to "📝 普通文本"
            )
            
            types.chunked(3).forEach { row ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    row.forEach { (type, label) ->
                        FilterChip(
                            selected = selectedType == type,
                            onClick = { onTypeSelected(type) },
                            label = { Text(label, fontSize = 12.sp) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    // 填充空位
                    repeat(3 - row.size) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }
}

/**
 * 📊 进度卡片
 */
@Composable
private fun ProgressCard(progress: CleaningProgress) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    strokeWidth = 2.dp
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = progress.message,
                    fontWeight = FontWeight.Medium
                )
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            LinearProgressIndicator(
                progress = { progress.progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (progress.detectedType.isNotEmpty()) {
                    Text(
                        text = "类型: ${getTypeLabel(progress.detectedType)}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
                Text(
                    text = "${(progress.progress * 100).toInt()}%",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

/**
 * 📈 结果卡片
 */
@Composable
private fun ResultCard(
    result: CleaningResult.Success,
    onPreview: () -> Unit,
    onSave: () -> Unit,
    saveSuccess: Boolean
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF4CAF50).copy(alpha = 0.1f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = Color(0xFF4CAF50),
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "清洗完成！",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = Color(0xFF4CAF50)
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // 统计信息
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                StatItem("识别类型", getTypeLabel(result.detectedType))
                StatItem("原始数据", "${result.originalCount}条")
                StatItem("有效数据", "${result.cleanedCount}条")
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // 操作按钮
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onPreview,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Visibility, null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("预览数据")
                }
                
                Button(
                    onClick = onSave,
                    modifier = Modifier.weight(1f),
                    enabled = !saveSuccess,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (saveSuccess) Color(0xFF4CAF50) else MaterialTheme.colorScheme.primary
                    )
                ) {
                    Icon(
                        if (saveSuccess) Icons.Default.Done else Icons.Default.Save,
                        null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (saveSuccess) "已保存" else "保存数据")
                }
            }
            
            if (saveSuccess) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "✅ 已保存到: /training_data/cleaned_training_data.jsonl",
                    fontSize = 12.sp,
                    color = Color(0xFF4CAF50)
                )
            }
        }
    }
}

/**
 * 统计项
 */
@Composable
private fun StatItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = label,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
        )
    }
}

/**
 * 📋 数据预览卡片
 */
@Composable
private fun DataPreviewCard(
    pairs: List<DialoguePair>,
    onClose: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "📋 数据预览 (前20条)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, "关闭")
                }
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            pairs.forEachIndexed { index, pair ->
                PreviewItem(index = index + 1, pair = pair)
                if (index < pairs.size - 1) {
                    HorizontalDivider(
                        modifier = Modifier.padding(vertical = 8.dp),
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                    )
                }
            }
        }
    }
}

/**
 * 预览项
 */
@Composable
private fun PreviewItem(index: Int, pair: DialoguePair) {
    Column {
        Text(
            text = "#$index",
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(4.dp))
        
        Row {
            Text(
                text = "输入: ",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF2196F3)
            )
            Text(
                text = pair.input,
                fontSize = 12.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
        
        Spacer(modifier = Modifier.height(4.dp))
        
        Row {
            Text(
                text = "输出: ",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF4CAF50)
            )
            Text(
                text = pair.output,
                fontSize = 12.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * ❌ 错误卡片
 */
@Composable
private fun ErrorCard(message: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFFF44336).copy(alpha = 0.1f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Default.Error,
                contentDescription = null,
                tint = Color(0xFFF44336),
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = message,
                color = Color(0xFFF44336)
            )
        }
    }
}

/**
 * 📖 数据清洗使用说明卡片
 */
@Composable
private fun DataCleanerUsageGuideCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "📖 使用说明",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            val guides = listOf(
                "\uD83D\uDCDA 小说对话" to "自动提取引号内的对话内容，支持多种引号格式",
                "\uD83D\uDCAC 聊天记录" to "支持微信、QQ导出的聊天记录，自动配对问答",
                "\u2753 问答对" to "识别Q:A:或问:答:格式的问答数据",
                "\uD83D\uDCDD 普通文本" to "按段落拆分，相邻段落自动配对"
            )
            
            guides.forEach { (title, desc) ->
                Row(modifier = Modifier.padding(vertical = 4.dp)) {
                    Text(
                        text = title,
                        fontWeight = FontWeight.Medium,
                        fontSize = 13.sp,
                        modifier = Modifier.width(90.dp)
                    )
                    Text(
                        text = desc,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
            }
        }
    }
}

/**
 * 获取类型标签
 */
private fun getTypeLabel(type: String): String {
    return when (type) {
        TrainingDataCleaner.TYPE_AUTO -> "自动"
        TrainingDataCleaner.TYPE_NOVEL -> "小说"
        TrainingDataCleaner.TYPE_CHAT -> "聊天"
        TrainingDataCleaner.TYPE_QA -> "问答"
        TrainingDataCleaner.TYPE_TEXT -> "文本"
        else -> type
    }
}
