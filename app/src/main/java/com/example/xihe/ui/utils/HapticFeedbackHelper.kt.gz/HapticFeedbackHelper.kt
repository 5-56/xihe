package com.example.xihe.ui.utils

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext

/**
 * 📳 触觉反馈辅助类
 * 提供不同强度的震动反馈
 */
class HapticFeedbackHelper(private val context: Context) {
    
    private val vibrator: Vibrator by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vibratorManager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
    }
    
    /**
     * 轻触反馈（用于按钮点击）
     */
    fun lightTap() {
        vibrate(10, 50)
    }
    
    /**
     * 中等反馈（用于重要操作）
     */
    fun mediumTap() {
        vibrate(20, 100)
    }
    
    /**
     * 重击反馈（用于错误或警告）
     */
    fun heavyTap() {
        vibrate(30, 150)
    }
    
    /**
     * 成功反馈（双击效果）
     */
    fun success() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val timings = longArrayOf(0, 50, 50, 50)
            val amplitudes = intArrayOf(0, 100, 0, 150)
            vibrator.vibrate(
                VibrationEffect.createWaveform(timings, amplitudes, -1)
            )
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(longArrayOf(0, 50, 50, 50), -1)
        }
    }
    
    /**
     * 错误反馈（三次短震）
     */
    fun error() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val timings = longArrayOf(0, 30, 30, 30, 30, 30)
            val amplitudes = intArrayOf(0, 150, 0, 150, 0, 150)
            vibrator.vibrate(
                VibrationEffect.createWaveform(timings, amplitudes, -1)
            )
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(longArrayOf(0, 30, 30, 30, 30, 30), -1)
        }
    }
    
    /**
     * 选择反馈（用于滑动选择）
     */
    fun selection() {
        vibrate(5, 30)
    }
    
    private fun vibrate(amplitude: Int, duration: Long) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(
                VibrationEffect.createOneShot(duration, amplitude)
            )
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(duration)
        }
    }
}

/**
 * Composable函数，用于获取HapticFeedbackHelper实例
 */
@Composable
fun rememberHapticFeedback(): HapticFeedbackHelper {
    val context = LocalContext.current
    return remember { HapticFeedbackHelper(context) }
}
