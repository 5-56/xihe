package com.example.xihe.ai

import com.example.xihe.utils.LogManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.PriorityBlockingQueue

/**
 * 🎯 增强任务规划器
 * 
 * 新增功能：
 * - 复杂任务分解（将复杂任务分解为原子操作）
 * - 任务依赖分析（识别任务间的依赖关系）
 * - 任务执行路径优化（选择最优执行路径）
 * - 任务风险评估（评估任务执行风险）
 * - 任务回滚策略（失败时自动回滚）
 * - 任务并行执行（支持多任务并行）
 * - 任务优先级管理（重要任务优先执行）
 */
object EnhancedTaskPlanner {
    
    private const val TAG = "EnhancedTaskPlanner"
    
    // 任务队列（按优先级排序）
    private val taskQueue = PriorityBlockingQueue<PrioritizedTask>(11) { t1, t2 ->
        t2.priority.ordinal - t1.priority.ordinal // 高优先级在前
    }
    
    // 正在执行的任务
    private val runningTasks = ConcurrentHashMap<String, TaskExecutionState>()
    
    // 任务依赖图
    private val dependencyGraph = mutableMapOf<String, MutableSet<String>>()
    
    // 任务状态流
    private val _taskStates = MutableStateFlow<Map<String, TaskExecutionState>>(emptyMap())
    val taskStates = _taskStates.asStateFlow()
    
    // 协程作用域
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    
    // ==================== 🎯 任务分解 ====================
    
    /**
     * 🔧 分解复杂任务为原子操作
     */
    fun decomposeTask(
        userRequest: String,
        intent: IntentClassifier.IntentResult
    ): List<AtomicTask> {
        LogManager.d(TAG, "🔧 分解任务: $userRequest")
        
        val atomicTasks = mutableListOf<AtomicTask>()
        var taskIndex = 0
        
        // 根据意图类型进行不同的分解策略
        when (intent.intent) {
            IntentClassifier.UserIntent.AUTOMATION_TASK -> {
                atomicTasks.addAll(decomposeAutomationTask(userRequest, intent, taskIndex))
            }
            IntentClassifier.UserIntent.SYSTEM_CONTROL -> {
                atomicTasks.addAll(decomposeSystemTask(userRequest, intent, taskIndex))
            }
            else -> {
                // 简单任务不需要分解
                atomicTasks.add(AtomicTask(
                    id = "task_0",
                    name = userRequest,
                    type = TaskType.SIMPLE,
                    action = intent.suggestedAction ?: userRequest,
                    priority = TaskPriority.NORMAL
                ))
            }
        }
        
        LogManager.d(TAG, "📋 分解为 ${atomicTasks.size} 个原子任务")
        return atomicTasks
    }
    
    /**
     * 🤖 分解自动化任务
     */
    private fun decomposeAutomationTask(
        request: String,
        intent: IntentClassifier.IntentResult,
        startIndex: Int
    ): List<AtomicTask> {
        val tasks = mutableListOf<AtomicTask>()
        var index = startIndex
        
        // 检测任务类型并分解
        when {
            // 发消息任务
            request.contains("发") && (request.contains("微信") || request.contains("消息")) -> {
                val contact = intent.entities["contact"]?.toString()
                val message = intent.entities["message"]?.toString()
                
                tasks.add(AtomicTask(
                    id = "task_${index++}",
                    name = "启动微信",
                    type = TaskType.LAUNCH_APP,
                    action = "launch:com.tencent.mm",
                    priority = TaskPriority.HIGH,
                    timeout = 5000L
                ))
                
                if (contact != null) {
                    tasks.add(AtomicTask(
                        id = "task_${index++}",
                        name = "搜索联系人",
                        type = TaskType.SEARCH,
                        action = "search:$contact",
                        priority = TaskPriority.HIGH,
                        dependsOn = listOf("task_${index - 2}")
                    ))
                    
                    tasks.add(AtomicTask(
                        id = "task_${index++}",
                        name = "选择联系人",
                        type = TaskType.CLICK,
                        action = "click:contact_$contact",
                        priority = TaskPriority.HIGH,
                        dependsOn = listOf("task_${index - 2}")
                    ))
                }
                
                if (message != null) {
                    tasks.add(AtomicTask(
                        id = "task_${index++}",
                        name = "输入消息",
                        type = TaskType.INPUT,
                        action = "input:$message",
                        priority = TaskPriority.HIGH,
                        dependsOn = listOf("task_${index - 2}")
                    ))
                    
                    tasks.add(AtomicTask(
                        id = "task_${index++}",
                        name = "发送消息",
                        type = TaskType.CLICK,
                        action = "click:send_button",
                        priority = TaskPriority.CRITICAL,
                        requiresConfirmation = true,
                        dependsOn = listOf("task_${index - 2}")
                    ))
                }
            }
            
            // 搜索任务
            request.contains("搜索") || request.contains("百度") -> {
                val keyword = extractSearchKeyword(request)
                
                tasks.add(AtomicTask(
                    id = "task_${index++}",
                    name = "打开浏览器/搜索引擎",
                    type = TaskType.LAUNCH_APP,
                    action = "launch:browser",
                    priority = TaskPriority.HIGH
                ))
                
                tasks.add(AtomicTask(
                    id = "task_${index++}",
                    name = "点击搜索框",
                    type = TaskType.CLICK,
                    action = "click:search_box",
                    priority = TaskPriority.NORMAL,
                    dependsOn = listOf("task_${index - 2}")
                ))
                
                tasks.add(AtomicTask(
                    id = "task_${index++}",
                    name = "输入搜索关键词",
                    type = TaskType.INPUT,
                    action = "input:$keyword",
                    priority = TaskPriority.NORMAL,
                    dependsOn = listOf("task_${index - 2}")
                ))
                
                tasks.add(AtomicTask(
                    id = "task_${index++}",
                    name = "执行搜索",
                    type = TaskType.CLICK,
                    action = "click:search_button",
                    priority = TaskPriority.NORMAL,
                    dependsOn = listOf("task_${index - 2}")
                ))
            }
            
            // 通用点击任务
            request.contains("点击") -> {
                val target = extractClickTarget(request)
                tasks.add(AtomicTask(
                    id = "task_${index++}",
                    name = "点击$target",
                    type = TaskType.CLICK,
                    action = "click:$target",
                    priority = TaskPriority.NORMAL
                ))
            }
            
            // 默认：创建单一任务
            else -> {
                tasks.add(AtomicTask(
                    id = "task_${index++}",
                    name = request,
                    type = TaskType.SIMPLE,
                    action = intent.suggestedAction ?: request,
                    priority = TaskPriority.NORMAL
                ))
            }
        }
        
        return tasks
    }
    
    /**
     * ⚙️ 分解系统控制任务
     */
    private fun decomposeSystemTask(
        request: String,
        intent: IntentClassifier.IntentResult,
        startIndex: Int
    ): List<AtomicTask> {
        val tasks = mutableListOf<AtomicTask>()
        var index = startIndex
        
        when {
            request.contains("音量") -> {
                val direction = if (request.contains("高") || request.contains("大")) "up" else "down"
                tasks.add(AtomicTask(
                    id = "task_${index++}",
                    name = "调节音量",
                    type = TaskType.SYSTEM,
                    action = "volume:$direction",
                    priority = TaskPriority.HIGH
                ))
            }
            
            request.contains("亮度") -> {
                val direction = if (request.contains("高") || request.contains("亮")) "up" else "down"
                tasks.add(AtomicTask(
                    id = "task_${index++}",
                    name = "调节亮度",
                    type = TaskType.SYSTEM,
                    action = "brightness:$direction",
                    priority = TaskPriority.HIGH
                ))
            }
            
            request.contains("WiFi") || request.contains("wifi") -> {
                val action = if (request.contains("开") || request.contains("打开")) "on" else "off"
                tasks.add(AtomicTask(
                    id = "task_${index++}",
                    name = "WiFi开关",
                    type = TaskType.SYSTEM,
                    action = "wifi:$action",
                    priority = TaskPriority.HIGH
                ))
            }
            
            else -> {
                tasks.add(AtomicTask(
                    id = "task_${index++}",
                    name = request,
                    type = TaskType.SYSTEM,
                    action = intent.suggestedAction ?: request,
                    priority = TaskPriority.NORMAL
                ))
            }
        }
        
        return tasks
    }
    
    // ==================== 🔗 依赖分析 ====================
    
    /**
     * 🔗 构建任务依赖图
     */
    fun buildDependencyGraph(tasks: List<AtomicTask>): DependencyGraph {
        val graph = DependencyGraph()
        
        tasks.forEach { task ->
            graph.addTask(task.id)
            task.dependsOn.forEach { depId ->
                graph.addDependency(task.id, depId)
            }
        }
        
        // 检测循环依赖
        if (graph.hasCycle()) {
            LogManager.e(TAG, "⚠️ 检测到循环依赖！")
            throw IllegalStateException("任务存在循环依赖")
        }
        
        return graph
    }
    
    /**
     * 📊 获取任务执行顺序（拓扑排序）
     */
    fun getExecutionOrder(tasks: List<AtomicTask>): List<AtomicTask> {
        val graph = buildDependencyGraph(tasks)
        val sortedIds = graph.topologicalSort()
        
        val taskMap = tasks.associateBy { it.id }
        return sortedIds.mapNotNull { taskMap[it] }
    }
    
    /**
     * 🚀 获取可并行执行的任务组
     */
    fun getParallelGroups(tasks: List<AtomicTask>): List<List<AtomicTask>> {
        val groups = mutableListOf<List<AtomicTask>>()
        val completed = mutableSetOf<String>()
        val remaining = tasks.toMutableList()
        
        while (remaining.isNotEmpty()) {
            // 找出所有依赖已完成的任务
            val canExecute = remaining.filter { task ->
                task.dependsOn.all { it in completed }
            }
            
            if (canExecute.isEmpty()) {
                LogManager.e(TAG, "⚠️ 无法继续执行，可能存在未满足的依赖")
                break
            }
            
            groups.add(canExecute)
            canExecute.forEach { task ->
                completed.add(task.id)
                remaining.remove(task)
            }
        }
        
        LogManager.d(TAG, "📊 分为 ${groups.size} 个并行执行组")
        return groups
    }
    
    // ==================== ⚖️ 风险评估 ====================
    
    /**
     * ⚖️ 评估任务风险
     */
    fun assessTaskRisk(task: AtomicTask): RiskAssessment {
        var riskScore = 0
        val riskFactors = mutableListOf<String>()
        
        // 任务类型风险
        when (task.type) {
            TaskType.PAYMENT -> {
                riskScore += 50
                riskFactors.add("涉及支付操作")
            }
            TaskType.DELETE -> {
                riskScore += 40
                riskFactors.add("涉及删除操作")
            }
            TaskType.SHARE -> {
                riskScore += 30
                riskFactors.add("涉及分享操作")
            }
            TaskType.INPUT -> {
                riskScore += 10
                riskFactors.add("涉及输入操作")
            }
            else -> { }
        }
        
        // 需要确认的任务
        if (task.requiresConfirmation) {
            riskScore += 20
            riskFactors.add("需要用户确认")
        }
        
        // 高优先级任务
        if (task.priority == TaskPriority.CRITICAL) {
            riskScore += 10
            riskFactors.add("关键任务")
        }
        
        val level = when {
            riskScore >= 50 -> RiskLevel.HIGH
            riskScore >= 30 -> RiskLevel.MEDIUM
            riskScore >= 10 -> RiskLevel.LOW
            else -> RiskLevel.SAFE
        }
        
        return RiskAssessment(
            level = level,
            score = riskScore,
            factors = riskFactors,
            requiresConfirmation = level == RiskLevel.HIGH || task.requiresConfirmation
        )
    }
    
    /**
     * ⚖️ 评估任务计划整体风险
     */
    fun assessPlanRisk(tasks: List<AtomicTask>): RiskAssessment {
        val assessments = tasks.map { assessTaskRisk(it) }
        
        val maxLevel = assessments.maxOfOrNull { it.level } ?: RiskLevel.SAFE
        val totalScore = assessments.sumOf { it.score }
        val allFactors = assessments.flatMap { it.factors }.distinct()
        
        return RiskAssessment(
            level = maxLevel,
            score = totalScore,
            factors = allFactors,
            requiresConfirmation = assessments.any { it.requiresConfirmation }
        )
    }
    
    // ==================== ↩️ 回滚策略 ====================
    
    /**
     * ↩️ 生成任务回滚策略
     */
    fun generateRollbackStrategy(task: AtomicTask): RollbackStrategy? {
        return when (task.type) {
            TaskType.LAUNCH_APP -> RollbackStrategy(
                taskId = task.id,
                action = "返回主页",
                command = "home",
                priority = 1
            )
            
            TaskType.CLICK -> RollbackStrategy(
                taskId = task.id,
                action = "返回上一页",
                command = "back",
                priority = 2
            )
            
            TaskType.INPUT -> RollbackStrategy(
                taskId = task.id,
                action = "清空输入",
                command = "clear_input",
                priority = 3
            )
            
            TaskType.SCROLL -> RollbackStrategy(
                taskId = task.id,
                action = "滚动回原位置",
                command = "scroll_back",
                priority = 4
            )
            
            else -> null
        }
    }
    
    /**
     * 🔄 执行回滚
     */
    suspend fun executeRollback(
        completedTasks: List<AtomicTask>,
        onRollbackStep: suspend (RollbackStrategy) -> Boolean
    ): Boolean {
        LogManager.i(TAG, "🔄 开始回滚 ${completedTasks.size} 个任务")
        
        val rollbackStrategies = completedTasks
            .mapNotNull { generateRollbackStrategy(it) }
            .sortedByDescending { it.priority }
        
        var allSuccess = true
        for (strategy in rollbackStrategies) {
            LogManager.d(TAG, "↩️ 回滚: ${strategy.action}")
            val success = onRollbackStep(strategy)
            if (!success) {
                LogManager.e(TAG, "❌ 回滚失败: ${strategy.action}")
                allSuccess = false
            }
            delay(300)
        }
        
        return allSuccess
    }
    
    // ==================== 📊 任务队列管理 ====================
    
    /**
     * ➕ 添加任务到队列
     */
    fun enqueueTask(task: AtomicTask) {
        val prioritizedTask = PrioritizedTask(
            task = task,
            priority = task.priority,
            enqueuedAt = System.currentTimeMillis()
        )
        taskQueue.add(prioritizedTask)
        LogManager.d(TAG, "➕ 任务入队: ${task.name} (优先级: ${task.priority})")
    }
    
    /**
     * ➖ 获取下一个任务
     */
    fun dequeueTask(): AtomicTask? {
        return taskQueue.poll()?.task
    }
    
    /**
     * 📊 获取队列状态
     */
    fun getQueueStatus(): QueueStatus {
        return QueueStatus(
            pendingCount = taskQueue.size,
            runningCount = runningTasks.size,
            tasks = taskQueue.map { it.task.name }
        )
    }
    
    // ==================== 🔧 辅助方法 ====================
    
    private fun extractSearchKeyword(request: String): String {
        val patterns = listOf(
            "搜索(.+)".toRegex(),
            "查(.+)".toRegex(),
            "找(.+)".toRegex()
        )
        
        for (pattern in patterns) {
            pattern.find(request)?.let {
                return it.groupValues[1].trim()
            }
        }
        
        return request
    }
    
    private fun extractClickTarget(request: String): String {
        val pattern = "点击(.+?)(?:按钮|选项|链接)?$".toRegex()
        return pattern.find(request)?.groupValues?.get(1)?.trim() ?: "目标"
    }
}

// ==================== 📦 数据类定义 ====================

/**
 * 🎯 原子任务
 */
data class AtomicTask(
    val id: String,
    val name: String,
    val type: TaskType,
    val action: String,
    val priority: TaskPriority = TaskPriority.NORMAL,
    val timeout: Long = 10000L,
    val retryCount: Int = 3,
    val dependsOn: List<String> = emptyList(),
    val requiresConfirmation: Boolean = false,
    val metadata: Map<String, Any> = emptyMap()
)

/**
 * 📋 任务类型
 */
enum class TaskType {
    SIMPLE,         // 简单任务
    LAUNCH_APP,     // 启动应用
    CLICK,          // 点击
    LONG_CLICK,     // 长按
    INPUT,          // 输入
    SCROLL,         // 滚动
    SEARCH,         // 搜索
    SYSTEM,         // 系统操作
    PAYMENT,        // 支付
    DELETE,         // 删除
    SHARE,          // 分享
    WAIT            // 等待
}

/**
 * ⚡ 任务优先级
 */
enum class TaskPriority {
    LOW,        // 低
    NORMAL,     // 普通
    HIGH,       // 高
    CRITICAL    // 关键
}

/**
 * 📊 任务执行状态
 */
data class TaskExecutionState(
    val taskId: String,
    val status: ExecutionStatus,
    val progress: Float = 0f,
    val startTime: Long = 0,
    val endTime: Long = 0,
    val error: String? = null
)

/**
 * 🔄 执行状态
 */
enum class ExecutionStatus {
    PENDING,    // 等待
    RUNNING,    // 执行中
    COMPLETED,  // 完成
    FAILED,     // 失败
    CANCELLED,  // 取消
    ROLLBACK    // 回滚中
}

/**
 * ⚖️ 风险评估
 */
data class RiskAssessment(
    val level: RiskLevel,
    val score: Int,
    val factors: List<String>,
    val requiresConfirmation: Boolean
)

/**
 * ⚠️ 风险级别
 */
enum class RiskLevel {
    SAFE,       // 安全
    LOW,        // 低风险
    MEDIUM,     // 中风险
    HIGH        // 高风险
}

/**
 * ↩️ 回滚策略
 */
data class RollbackStrategy(
    val taskId: String,
    val action: String,
    val command: String,
    val priority: Int
)

/**
 * 🔗 依赖图
 */
class DependencyGraph {
    private val adjacency = mutableMapOf<String, MutableSet<String>>()
    private val inDegree = mutableMapOf<String, Int>()
    
    fun addTask(taskId: String) {
        if (taskId !in adjacency) {
            adjacency[taskId] = mutableSetOf()
            inDegree[taskId] = 0
        }
    }
    
    fun addDependency(taskId: String, dependsOnId: String) {
        addTask(taskId)
        addTask(dependsOnId)
        
        adjacency[dependsOnId]?.add(taskId)
        inDegree[taskId] = (inDegree[taskId] ?: 0) + 1
    }
    
    fun hasCycle(): Boolean {
        val visited = mutableSetOf<String>()
        val recStack = mutableSetOf<String>()
        
        fun dfs(node: String): Boolean {
            visited.add(node)
            recStack.add(node)
            
            adjacency[node]?.forEach { neighbor ->
                if (neighbor !in visited) {
                    if (dfs(neighbor)) return true
                } else if (neighbor in recStack) {
                    return true
                }
            }
            
            recStack.remove(node)
            return false
        }
        
        adjacency.keys.forEach { node ->
            if (node !in visited) {
                if (dfs(node)) return true
            }
        }
        
        return false
    }
    
    fun topologicalSort(): List<String> {
        val result = mutableListOf<String>()
        val queue = ArrayDeque<String>()
        val degree = inDegree.toMutableMap()
        
        degree.forEach { (node, deg) ->
            if (deg == 0) queue.add(node)
        }
        
        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()
            result.add(node)
            
            adjacency[node]?.forEach { neighbor ->
                degree[neighbor] = (degree[neighbor] ?: 0) - 1
                if (degree[neighbor] == 0) {
                    queue.add(neighbor)
                }
            }
        }
        
        return result
    }
}

/**
 * 📊 优先级任务包装
 */
data class PrioritizedTask(
    val task: AtomicTask,
    val priority: TaskPriority,
    val enqueuedAt: Long
)

/**
 * 📊 队列状态
 */
data class QueueStatus(
    val pendingCount: Int,
    val runningCount: Int,
    val tasks: List<String>
)
