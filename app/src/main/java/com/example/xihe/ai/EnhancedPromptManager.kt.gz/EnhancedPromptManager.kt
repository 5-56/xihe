package com.example.xihe.ai

import com.example.xihe.utils.LogManager

/**
 * 📝 增强提示词管理器
 * 
 * 功能：
 * - 设备操控专用提示词模板
 * - 屏幕状态理解提示词
 * - 操作步骤生成提示词
 * - 错误恢复提示词
 * - 多轮对话上下文管理
 */
object EnhancedPromptManager {
    
    private const val TAG = "EnhancedPromptManager"
    
    // ==================== 🎯 核心系统提示词 ====================
    
    /**
     * 🤖 AI助手核心人设
     */
    val corePersonality = """
你是羲和（Xihe），一个可爱、活泼、超级能干的AI手机助手！

【性格特点】
- 🌟 热情友好：总是用积极的态度回应用户
- 💪 专业可靠：精通Android设备操控，能准确执行各种任务
- 🎀 俏皮可爱：回复时会用一些可爱的语气词和表情
- 🧠 聪明伶俐：能理解模糊的指令，主动询问细节

【交互风格】
- 用"~"、"呢"、"哦"等语气词增加亲和力
- 适当使用emoji让对话更生动
- 任务完成时给予正面反馈
- 遇到问题时耐心解释
""".trimIndent()
    
    /**
     * 📱 设备操控能力描述
     */
    val deviceControlCapabilities = """
【核心能力】
1. 📱 屏幕理解：通过AccessibilityService获取的UI树，精确理解屏幕上的每个元素
2. 🎯 元素定位：根据文本、ID、描述、类型等多维度精确定位目标元素
3. 👆 操作执行：点击、长按、滑动、输入等精确操作
4. 🔄 状态跟踪：跟踪操作结果，判断是否成功并决定下一步
5. 🛡️ 安全保护：涉及敏感操作时主动确认，保护用户安全

【屏幕元素理解规则】
- [ID:数字] 是元素的唯一标识，操作时必须使用正确的ID
- ✅ 表示可点击，📜 表示可滚动，✏️ 表示可输入
- text='xxx' 是元素显示的文字
- desc='xxx' 是元素的内容描述（无障碍描述）
- 优先选择有文字或描述的元素，避免操作空白元素

【操作决策规则】
1. 点击前验证：确保目标元素存在且可点击
2. 输入前聚焦：输入文字前先点击输入框
3. 滚动查找：如果目标不在可见区域，先滚动查找
4. 等待加载：操作后如果页面需要加载，耐心等待
5. 失败重试：如果操作失败，尝试其他方式达成目标
""".trimIndent()
    
    // ==================== 📱 屏幕分析提示词 ====================
    
    /**
     * 📱 生成屏幕分析提示词
     */
    fun buildScreenAnalysisPrompt(
        packageName: String,
        screenType: String?,
        elementCount: Int,
        visibleTexts: List<String>
    ): String = """
【当前屏幕分析】
📦 应用: $packageName
📄 页面类型: ${screenType ?: "未识别"}
🔢 元素数量: $elementCount

【可见文本摘要】
${visibleTexts.take(10).joinToString("\n") { "• $it" }}
${if (visibleTexts.size > 10) "... 还有 ${visibleTexts.size - 10} 个" else ""}

请分析：
1. 这是什么功能页面？（聊天、列表、设置、搜索等）
2. 用户可能想做什么操作？
3. 有哪些关键的可交互元素？
4. 当前页面状态如何？（加载中、有弹窗、正常等）
""".trimIndent()
    
    /**
     * 🎯 生成元素定位提示词
     */
    fun buildElementLocatePrompt(
        targetDescription: String,
        availableElements: List<ElementInfo>
    ): String = """
【目标元素定位】
🎯 寻找: $targetDescription

【可用元素列表】
${availableElements.take(20).mapIndexed { i, e -> 
    "${i+1}. [ID:${e.id}] ${e.type} - text='${e.text}' desc='${e.description}' ${if (e.clickable) "✅" else ""}"
}.joinToString("\n")}

请选择最匹配的元素，返回其ID。如果没有完全匹配的，选择最接近的。
如果找不到合适元素，说明原因并建议下一步操作（如滚动查找）。
""".trimIndent()
    
    // ==================== 🎬 任务执行提示词 ====================
    
    /**
     * 🎬 生成任务执行提示词
     */
    fun buildTaskExecutionPrompt(
        goal: String,
        completedSteps: List<String>,
        currentScreen: String,
        domain: String?
    ): String {
        val sceneHint = getSceneHint(domain)
        
        return """
【任务目标】
$goal

【已完成步骤】
${if (completedSteps.isEmpty()) "（刚开始）" else completedSteps.mapIndexed { i, s -> "✅ ${i+1}. $s" }.joinToString("\n")}

【当前屏幕】
$currentScreen

$sceneHint

【请决定下一步操作】
分析当前屏幕，判断：
1. 距离目标还差哪些步骤？
2. 当前屏幕上有哪些可用操作？
3. 最优的下一步操作是什么？

如果目标已完成，返回 "action": "DONE"
如果遇到问题需要用户帮助，返回 "action": "ASK" 并说明问题
""".trimIndent()
    }
    
    /**
     * 🎯 获取场景特定提示
     */
    private fun getSceneHint(domain: String?): String = when (domain) {
        "消息" -> """
【💬 消息发送场景提示】
- 进入聊天界面后，找消息输入框（通常在底部）
- 点击输入框等待键盘弹出
- 输入消息后找发送按钮（"发送"或箭头图标）
- 确认消息出现在聊天列表中表示发送成功
"""
        "购物" -> """
【🛒 购物场景提示】
- 搜索商品：找搜索框 → 输入关键词 → 点击搜索
- 浏览商品：滑动查看，点击感兴趣的商品
- 加购物车：在商品详情页找"加入购物车"
- 涉及支付时需要用户确认
"""
        "娱乐" -> """
【🎬 娱乐场景提示】
- 刷视频：上滑切换下一个，下滑返回上一个
- 点赞：双击屏幕或点击爱心按钮
- 评论：点击评论区 → 输入评论 → 发送
"""
        "出行" -> """
【🚗 出行场景提示】
- 打车：输入目的地 → 选择车型 → 确认叫车
- 导航：输入目的地 → 选择路线 → 开始导航
"""
        else -> ""
    }
    
    // ==================== 🔄 错误恢复提示词 ====================
    
    /**
     * 🔄 生成错误恢复提示词
     */
    fun buildErrorRecoveryPrompt(
        originalGoal: String,
        failedStep: String,
        errorType: ErrorType,
        currentScreen: String,
        attemptCount: Int
    ): String = """
【❌ 错误恢复】
🎯 原始目标: $originalGoal
❌ 失败步骤: $failedStep
⚠️ 错误类型: ${errorType.description}
🔄 已尝试: $attemptCount 次

【当前屏幕状态】
$currentScreen

【恢复策略建议】
${getRecoveryStrategies(errorType)}

请分析错误原因，选择合适的恢复策略：
1. 如果可以继续，返回恢复操作
2. 如果需要回退，返回 "action": "ROLLBACK"
3. 如果需要用户帮助，返回 "action": "ASK" 并说明问题
4. 如果无法继续，返回 "action": "ABORT" 并解释原因
""".trimIndent()
    
    /**
     * 📋 获取恢复策略
     */
    private fun getRecoveryStrategies(errorType: ErrorType): String = when (errorType) {
        ErrorType.ELEMENT_NOT_FOUND -> """
• 尝试滚动页面查找目标元素
• 使用模糊匹配寻找类似元素
• 检查是否在正确的页面
• 等待页面加载完成后重试
"""
        ErrorType.ELEMENT_NOT_CLICKABLE -> """
• 检查是否有遮挡弹窗需要关闭
• 尝试长按或其他交互方式
• 滚动使元素完全可见
• 等待动画完成后重试
"""
        ErrorType.INPUT_FAILED -> """
• 确保输入框已获得焦点
• 清空输入框后重新输入
• 检查是否需要关闭键盘
• 尝试使用剪贴板粘贴
"""
        ErrorType.APP_NOT_RESPONDING -> """
• 等待应用响应
• 尝试返回并重新进入
• 强制停止应用后重试
• 检查网络连接
"""
        ErrorType.UNEXPECTED_DIALOG -> """
• 查找并关闭对话框
• 点击取消/关闭按钮
• 点击对话框外部区域
• 按返回键关闭
"""
        ErrorType.NETWORK_ERROR -> """
• 检查网络连接状态
• 等待网络恢复
• 提示用户检查网络
• 尝试离线操作
"""
        ErrorType.PERMISSION_DENIED -> """
• 提示用户授予权限
• 引导用户到设置页面
• 使用替代方案
"""
        ErrorType.UNKNOWN -> """
• 分析屏幕状态找出问题
• 尝试返回上一步重试
• 请求用户协助
"""
    }
    
    // ==================== 💬 多轮对话提示词 ====================
    
    /**
     * 💬 生成多轮对话上下文提示词
     */
    fun buildConversationContextPrompt(
        recentTurns: List<ConversationTurn>,
        currentTopic: String?,
        currentApp: String?
    ): String {
        if (recentTurns.isEmpty()) return ""
        
        return """
【对话上下文】
📍 当前话题: ${currentTopic ?: "未确定"}
📱 当前应用: ${currentApp ?: "未知"}

【最近对话】
${recentTurns.takeLast(5).mapIndexed { i, turn ->
    """
${i+1}. 用户: ${turn.userInput}
   羲和: ${turn.aiResponse.take(50)}${if (turn.aiResponse.length > 50) "..." else ""}
   [意图: ${turn.intent}]
"""
}.joinToString("")}

【上下文理解】
- 根据对话历史理解用户真实意图
- 对于"它"、"这个"、"那个"等代词，参考上文确定指代对象
- 如果用户说"继续"或"接着"，延续上一个任务
- 如果用户说"算了"或"取消"，停止当前任务
""".trimIndent()
    }
    
    /**
     * 🤔 生成意图澄清提示词
     */
    fun buildClarificationPrompt(
        userInput: String,
        possibleIntents: List<String>,
        missingInfo: List<String>
    ): String = """
【需要澄清】
用户输入: "$userInput"

可能的意图:
${possibleIntents.mapIndexed { i, intent -> "${i+1}. $intent" }.joinToString("\n")}

缺少的信息:
${missingInfo.map { "• $it" }.joinToString("\n")}

请生成一个友好、简洁的澄清问题，帮助确定用户的真实意图。
语气要可爱亲切，不要让用户感到被质疑。
""".trimIndent()
    
    // ==================== 🔧 组合提示词 ====================
    
    /**
     * 🔧 构建完整提示词
     */
    fun buildCompletePrompt(
        goal: String,
        screenState: String,
        domain: String?,
        conversationContext: ConversationContext? = null,
        hasError: Boolean = false,
        errorInfo: ErrorInfo? = null
    ): String {
        return buildString {
            // 1. 核心人设
            appendLine(corePersonality)
            appendLine()
            
            // 2. 设备操控能力
            appendLine(deviceControlCapabilities)
            appendLine()
            
            // 3. 对话上下文（如果有）
            if (conversationContext != null && conversationContext.recentMessages.isNotEmpty()) {
                val turns = conversationContext.recentMessages.mapIndexed { i, msg ->
                    ConversationTurn(
                        userInput = msg,
                        aiResponse = "",
                        intent = conversationContext.lastIntent ?: IntentClassifier.UserIntent.UNCLEAR,
                        entities = emptyMap(),
                        screenContext = null,
                        timestamp = System.currentTimeMillis()
                    )
                }
                appendLine(buildConversationContextPrompt(
                    turns,
                    conversationContext.currentTopic,
                    conversationContext.currentApp
                ))
                appendLine()
            }
            
            appendLine("---")
            appendLine()
            
            // 4. 任务执行或错误恢复
            if (hasError && errorInfo != null) {
                appendLine(buildErrorRecoveryPrompt(
                    originalGoal = goal,
                    failedStep = errorInfo.failedStep,
                    errorType = errorInfo.errorType,
                    currentScreen = screenState,
                    attemptCount = errorInfo.attemptCount
                ))
            } else {
                appendLine(buildTaskExecutionPrompt(
                    goal = goal,
                    completedSteps = emptyList(),
                    currentScreen = screenState,
                    domain = domain
                ))
            }
        }
    }
    
    /**
     * 📊 获取提示词统计
     */
    fun getPromptStats(prompt: String): PromptStats {
        val charCount = prompt.length
        val lineCount = prompt.lines().size
        val estimatedTokens = charCount / 2 // 粗略估算中文tokens
        
        return PromptStats(
            characterCount = charCount,
            lineCount = lineCount,
            estimatedTokens = estimatedTokens
        )
    }
}

// ==================== 📦 数据类定义 ====================

/**
 * 📱 元素信息
 */
data class ElementInfo(
    val id: Int,
    val type: String,
    val text: String?,
    val description: String?,
    val clickable: Boolean,
    val bounds: String?
)

/**
 * ❌ 错误类型
 */
enum class ErrorType(val description: String) {
    ELEMENT_NOT_FOUND("找不到目标元素"),
    ELEMENT_NOT_CLICKABLE("元素不可点击"),
    INPUT_FAILED("输入失败"),
    APP_NOT_RESPONDING("应用无响应"),
    UNEXPECTED_DIALOG("意外弹窗"),
    NETWORK_ERROR("网络错误"),
    PERMISSION_DENIED("权限被拒绝"),
    UNKNOWN("未知错误")
}

/**
 * ❌ 错误信息
 */
data class ErrorInfo(
    val failedStep: String,
    val errorType: ErrorType,
    val errorMessage: String,
    val attemptCount: Int
)

/**
 * 📊 提示词统计
 */
data class PromptStats(
    val characterCount: Int,
    val lineCount: Int,
    val estimatedTokens: Int
)
