package com.example.xihe.ai

import android.content.Context
import android.content.SharedPreferences
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * 意图理解反馈系统
 * 
 * 功能：
 * 1. 记录每次意图理解的结果
 * 2. 收集用户打分反馈
 * 3. 基于反馈学习和调整意图识别
 * 4. 避免重复错误
 * 
 * 打分机制：
 * - 5分: 完美理解，执行正确
 * - 4分: 理解正确，执行有小问题
 * - 3分: 部分理解正确
 * - 2分: 理解有偏差
 * - 1分: 完全理解错误
 */
object IntentFeedbackSystem {
    private const val TAG = "IntentFeedback"
    private const val PREF_NAME = "xihe_intent_feedback"
    private const val KEY_FEEDBACK_HISTORY = "feedback_history"
    private const val KEY_LEARNED_PATTERNS = "learned_patterns"
    private const val KEY_FEEDBACK_ENABLED = "feedback_enabled"
    private const val MAX_HISTORY_SIZE = 500
    
    // 打分功能开关
    private val _feedbackEnabled = MutableStateFlow(true)
    val feedbackEnabled: StateFlow<Boolean> = _feedbackEnabled.asStateFlow()
    
    private var prefs: SharedPreferences? = null
    private val json = Json { ignoreUnknownKeys = true; prettyPrint = false }
    
    // ==================== 数据类 ====================
    
    @Serializable
    data class IntentRecord(
        val id: String,                      // 唯一ID
        val timestamp: Long,                 // 时间戳
        val userInput: String,               // 用户原始输入
        val recognizedIntent: String?,       // 识别到的意图
        val recognizedMode: String,          // 识别的模式 (CHAT/TASK/QUERY)
        val confidence: Float,               // 置信度
        val executedAction: String?,         // 执行的动作
        var userScore: Int = 0,              // 用户打分 (1-5)
        var userFeedback: String? = null,    // 用户反馈文字
        var correctIntent: String? = null,   // 用户指出的正确意图
        var isScored: Boolean = false        // 是否已打分
    )
    
    @Serializable
    data class LearnedPattern(
        val pattern: String,                 // 输入模式（关键词组合）
        val correctIntent: String,           // 正确的意图
        val correctMode: String,             // 正确的模式
        val weight: Float,                   // 权重（基于打分累积）
        val sampleCount: Int,                // 样本数量
        val lastUpdated: Long                // 最后更新时间
    )
    
    // ==================== 状态管理 ====================
    
    // 当前待打分的记录
    private val _pendingFeedback = MutableStateFlow<IntentRecord?>(null)
    val pendingFeedback: StateFlow<IntentRecord?> = _pendingFeedback.asStateFlow()
    
    // 是否显示打分UI
    private val _showFeedbackUI = MutableStateFlow(false)
    val showFeedbackUI: StateFlow<Boolean> = _showFeedbackUI.asStateFlow()
    
    // 历史记录
    private var feedbackHistory = mutableListOf<IntentRecord>()
    
    // 学习到的模式
    private var learnedPatterns = mutableMapOf<String, LearnedPattern>()
    
    // ==================== 初始化 ====================
    
    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        loadData()
        // 加载开关设置
        _feedbackEnabled.value = prefs?.getBoolean(KEY_FEEDBACK_ENABLED, true) ?: true
        LogManager.d(TAG, "意图反馈系统初始化完成，历史记录: ${feedbackHistory.size}, 学习模式: ${learnedPatterns.size}, 打分开关: ${_feedbackEnabled.value}")
    }
    
    /**
     * 设置打分功能开关
     */
    fun setFeedbackEnabled(enabled: Boolean) {
        _feedbackEnabled.value = enabled
        prefs?.edit()?.putBoolean(KEY_FEEDBACK_ENABLED, enabled)?.apply()
        LogManager.d(TAG, "打分功能已${if (enabled) "开启" else "关闭"}")
    }
    
    private fun loadData() {
        prefs?.let { p ->
            // 加载历史记录
            val historyJson = p.getString(KEY_FEEDBACK_HISTORY, null)
            if (historyJson != null) {
                try {
                    feedbackHistory = json.decodeFromString<List<IntentRecord>>(historyJson).toMutableList()
                } catch (e: Exception) {
                    LogManager.e(TAG, "加载历史记录失败", e)
                }
            }
            
            // 加载学习模式
            val patternsJson = p.getString(KEY_LEARNED_PATTERNS, null)
            if (patternsJson != null) {
                try {
                    val patterns = json.decodeFromString<List<LearnedPattern>>(patternsJson)
                    learnedPatterns = patterns.associateBy { it.pattern }.toMutableMap()
                } catch (e: Exception) {
                    LogManager.e(TAG, "加载学习模式失败", e)
                }
            }
        }
    }
    
    private fun saveData() {
        prefs?.edit()?.apply {
            // 限制历史记录大小
            while (feedbackHistory.size > MAX_HISTORY_SIZE) {
                feedbackHistory.removeAt(0)
            }
            
            putString(KEY_FEEDBACK_HISTORY, json.encodeToString(feedbackHistory.toList()))
            putString(KEY_LEARNED_PATTERNS, json.encodeToString(learnedPatterns.values.toList()))
            apply()
        }
    }
    
    // ==================== 记录意图识别 ====================
    
    /**
     * 记录一次意图识别
     * 每次AutomationEngine处理用户输入后调用
     */
    fun recordIntentRecognition(
        userInput: String,
        recognizedIntent: String?,
        recognizedMode: String,
        confidence: Float,
        executedAction: String?
    ): String {
        val record = IntentRecord(
            id = "intent_${System.currentTimeMillis()}",
            timestamp = System.currentTimeMillis(),
            userInput = userInput,
            recognizedIntent = recognizedIntent,
            recognizedMode = recognizedMode,
            confidence = confidence,
            executedAction = executedAction
        )
        
        feedbackHistory.add(record)
        _pendingFeedback.value = record
        
        LogManager.d(TAG, "记录意图识别: input='$userInput', intent=$recognizedIntent, mode=$recognizedMode")
        
        return record.id
    }
    
    /**
     * 显示打分UI（检查开关状态）
     */
    fun requestFeedback() {
        if (!_feedbackEnabled.value) {
            LogManager.d(TAG, "打分功能已关闭，跳过")
            return
        }
        if (_pendingFeedback.value != null) {
            _showFeedbackUI.value = true
            LogManager.d(TAG, "请求用户打分")
        }
    }
    
    /**
     * 任务/对话结束后触发打分弹窗
     */
    fun triggerFeedbackAfterCompletion() {
        if (!_feedbackEnabled.value) {
            LogManager.d(TAG, "打分功能已关闭，跳过弹窗")
            _pendingFeedback.value = null
            return
        }
        if (_pendingFeedback.value != null) {
            _showFeedbackUI.value = true
            LogManager.d(TAG, "任务完成，显示打分弹窗")
        }
    }
    
    /**
     * 隐藏打分UI
     */
    fun dismissFeedback() {
        _showFeedbackUI.value = false
    }
    
    // ==================== 用户打分 ====================
    
    /**
     * 提交用户打分
     * @param score 评分 1-5
     * @param feedback 可选的文字反馈
     * @param correctIntent 如果理解错误，用户指出的正确意图
     */
    fun submitFeedback(
        score: Int,
        feedback: String? = null,
        correctIntent: String? = null
    ) {
        val record = _pendingFeedback.value ?: return
        
        record.userScore = score.coerceIn(1, 5)
        record.userFeedback = feedback
        record.correctIntent = correctIntent
        record.isScored = true
        
        // 更新历史记录
        val index = feedbackHistory.indexOfFirst { it.id == record.id }
        if (index >= 0) {
            feedbackHistory[index] = record
        }
        
        LogManager.d(TAG, "收到用户打分: score=$score, feedback=$feedback, correctIntent=$correctIntent")
        
        // 基于反馈学习
        learnFromFeedback(record)
        
        // 保存数据
        saveData()
        
        // 清除待打分记录
        _pendingFeedback.value = null
        _showFeedbackUI.value = false
    }
    
    /**
     * 快速打分（只打分数）
     */
    fun quickScore(score: Int) {
        submitFeedback(score)
    }
    
    /**
     * 跳过打分
     */
    fun skipFeedback() {
        _pendingFeedback.value = null
        _showFeedbackUI.value = false
    }
    
    // ==================== 学习机制 ====================
    
    /**
     * 从用户反馈中学习
     */
    private fun learnFromFeedback(record: IntentRecord) {
        val input = record.userInput.lowercase().trim()
        val keywords = extractKeywords(input)
        val patternKey = keywords.sorted().joinToString("|")
        
        if (patternKey.isBlank()) return
        
        val existingPattern = learnedPatterns[patternKey]
        
        when {
            // 高分：强化当前模式
            record.userScore >= 4 -> {
                val newWeight = (existingPattern?.weight ?: 0f) + (record.userScore - 3) * 0.1f
                learnedPatterns[patternKey] = LearnedPattern(
                    pattern = patternKey,
                    correctIntent = record.recognizedIntent ?: "chat",
                    correctMode = record.recognizedMode,
                    weight = minOf(newWeight, 1.0f),
                    sampleCount = (existingPattern?.sampleCount ?: 0) + 1,
                    lastUpdated = System.currentTimeMillis()
                )
                LogManager.d(TAG, "强化模式: $patternKey -> ${record.recognizedMode} (weight=$newWeight)")
            }
            
            // 低分：学习正确意图
            record.userScore <= 2 && record.correctIntent != null -> {
                val userCorrectIntent = record.correctIntent ?: return
                val correctMode = inferModeFromIntent(userCorrectIntent)
                learnedPatterns[patternKey] = LearnedPattern(
                    pattern = patternKey,
                    correctIntent = userCorrectIntent,
                    correctMode = correctMode,
                    weight = 0.8f,  // 用户明确指出的错误，高权重
                    sampleCount = 1,
                    lastUpdated = System.currentTimeMillis()
                )
                LogManager.d(TAG, "学习新模式: $patternKey -> $correctMode (来自用户纠正)")
            }
            
            // 低分但没有正确意图：降低当前模式权重
            record.userScore <= 2 -> {
                if (existingPattern != null) {
                    val newWeight = maxOf(0f, existingPattern.weight - 0.2f)
                    learnedPatterns[patternKey] = existingPattern.copy(
                        weight = newWeight,
                        lastUpdated = System.currentTimeMillis()
                    )
                    LogManager.d(TAG, "降低权重: $patternKey (weight=$newWeight)")
                }
            }
        }
    }
    
    /**
     * 提取输入中的关键词
     */
    private fun extractKeywords(input: String): List<String> {
        val keywords = mutableListOf<String>()
        
        // 任务关键词
        val taskWords = listOf("打开", "发", "搜索", "导航", "设置", "截图", "滑动", "点击", "返回")
        // 对话关键词
        val chatWords = listOf("你好", "聊聊", "觉得", "怎么办", "无聊", "开心", "难过")
        // 查询关键词
        val queryWords = listOf("天气", "时间", "几点", "位置", "在哪")
        
        for (word in taskWords + chatWords + queryWords) {
            if (input.contains(word)) {
                keywords.add(word)
            }
        }
        
        // 提取应用名
        val appNames = listOf("微信", "qq", "抖音", "淘宝", "支付宝", "高德", "百度")
        for (app in appNames) {
            if (input.contains(app)) {
                keywords.add(app)
            }
        }
        
        return keywords.take(5)  // 最多5个关键词
    }
    
    /**
     * 从意图推断模式
     */
    private fun inferModeFromIntent(intent: String): String {
        return when {
            intent in listOf("chat", "聊天", "对话") -> "CHAT"
            intent in listOf("task", "任务", "执行") -> "TASK"
            intent in listOf("query", "查询", "询问") -> "QUERY"
            intent.contains("发") || intent.contains("打开") || intent.contains("搜索") -> "TASK"
            intent.contains("聊") || intent.contains("说说") -> "CHAT"
            else -> "CHAT"
        }
    }
    
    // ==================== 应用学习结果 ====================
    
    /**
     * 根据学习结果调整意图识别
     * 返回建议的模式和置信度调整
     */
    fun getLearnedAdjustment(userInput: String): LearnedAdjustment? {
        val input = userInput.lowercase().trim()
        val keywords = extractKeywords(input)
        
        if (keywords.isEmpty()) return null
        
        // 查找匹配的学习模式
        val patternKey = keywords.sorted().joinToString("|")
        val exactMatch = learnedPatterns[patternKey]
        
        if (exactMatch != null && exactMatch.weight >= 0.5f) {
            LogManager.d(TAG, "找到学习模式: $patternKey -> ${exactMatch.correctMode} (weight=${exactMatch.weight})")
            return LearnedAdjustment(
                suggestedMode = exactMatch.correctMode,
                suggestedIntent = exactMatch.correctIntent,
                confidenceBoost = exactMatch.weight * 0.3f,
                reason = "基于${exactMatch.sampleCount}次用户反馈学习"
            )
        }
        
        // 部分匹配
        for ((pattern, learned) in learnedPatterns) {
            val patternKeywords = pattern.split("|")
            val matchCount = keywords.count { it in patternKeywords }
            if (matchCount >= 2 && learned.weight >= 0.6f) {
                LogManager.d(TAG, "部分匹配学习模式: $pattern -> ${learned.correctMode}")
                return LearnedAdjustment(
                    suggestedMode = learned.correctMode,
                    suggestedIntent = learned.correctIntent,
                    confidenceBoost = learned.weight * 0.2f,
                    reason = "基于相似输入的用户反馈"
                )
            }
        }
        
        return null
    }
    
    data class LearnedAdjustment(
        val suggestedMode: String,
        val suggestedIntent: String,
        val confidenceBoost: Float,
        val reason: String
    )
    
    // ==================== 统计信息 ====================
    
    /**
     * 获取统计信息
     */
    fun getStatistics(): FeedbackStatistics {
        val scoredRecords = feedbackHistory.filter { it.isScored }
        val avgScore = if (scoredRecords.isNotEmpty()) {
            scoredRecords.map { it.userScore }.average().toFloat()
        } else 0f
        
        val accuracyRate = if (scoredRecords.isNotEmpty()) {
            scoredRecords.count { it.userScore >= 4 }.toFloat() / scoredRecords.size
        } else 0f
        
        return FeedbackStatistics(
            totalRecords = feedbackHistory.size,
            scoredRecords = scoredRecords.size,
            averageScore = avgScore,
            accuracyRate = accuracyRate,
            learnedPatterns = learnedPatterns.size,
            recentErrors = scoredRecords.takeLast(20).count { it.userScore <= 2 }
        )
    }
    
    data class FeedbackStatistics(
        val totalRecords: Int,
        val scoredRecords: Int,
        val averageScore: Float,
        val accuracyRate: Float,
        val learnedPatterns: Int,
        val recentErrors: Int
    )
    
    /**
     * 获取最近的低分记录（用于分析改进）
     */
    fun getRecentLowScoreRecords(limit: Int = 10): List<IntentRecord> {
        return feedbackHistory
            .filter { it.isScored && it.userScore <= 2 }
            .takeLast(limit)
    }
    
    /**
     * 清除所有学习数据（重置）
     */
    fun clearLearningData() {
        learnedPatterns.clear()
        saveData()
        LogManager.d(TAG, "已清除所有学习数据")
    }
}
