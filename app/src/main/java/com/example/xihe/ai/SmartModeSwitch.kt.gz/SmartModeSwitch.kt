package com.example.xihe.ai

import com.example.xihe.utils.LogManager

/**
 * 🧠 智能模式切换器
 * 
 * 核心功能：智能识别用户意图，在任务执行模式和日常对话模式之间自由切换
 * 
 * 模式类型：
 * - CHAT: 日常对话模式 - 闲聊、咨询、情感交流
 * - TASK: 任务执行模式 - 自动化操作、系统控制
 * - QUERY: 信息查询模式 - 天气、时间、位置等实时信息
 * - HYBRID: 混合模式 - 需要结合AI理解和任务执行
 */
object SmartModeSwitch {
    private const val TAG = "SmartModeSwitch"
    
    // ==================== 模式定义 ====================
    
    enum class Mode {
        CHAT,   // 日常对话
        TASK,   // 任务执行
        QUERY,  // 信息查询
        HYBRID  // 混合模式
    }
    
    data class ModeDecision(
        val mode: Mode,
        val confidence: Float,
        val reason: String,
        val suggestedAction: String? = null
    )
    
    // ==================== 关键词库 ====================
    
    // 🎯 明确的任务执行关键词（高权重）
    private val explicitTaskKeywords = listOf(
        // 应用操作
        "打开", "启动", "关闭", "退出", "切换到",
        // 发送消息
        "发消息", "发微信", "发短信", "给.+发", "告诉.+说",
        // 搜索操作
        "搜索", "搜一下", "百度", "谷歌", "查一下",
        // 系统操作
        "截图", "录屏", "设置闹钟", "设置提醒", "设置定时",
        // 手势操作
        "滑动", "向上滑", "向下滑", "点击", "返回", "回到主页",
        // 导航
        "导航到", "怎么去", "路线", "带我去"
    )
    
    // 💬 明确的对话关键词（高权重）
    private val explicitChatKeywords = listOf(
        // 问候
        "你好", "您好", "嗨", "hi", "hello",
        // 情感交流
        "我很开心", "我很难过", "我好累", "心情不好", "我很无聊",
        "陪我聊", "和我聊", "跟我聊", "聊聊天",
        // 询问AI看法
        "你觉得", "你认为", "你怎么看", "你怎么想",
        "你喜欢", "你讨厌", "你有没有",
        // 寻求建议
        "怎么办", "该怎么", "应该怎么", "给我建议",
        // 闲聊
        "无聊", "没事", "随便聊", "想聊天"
    )
    
    // 🔍 信息查询关键词
    private val queryKeywords = listOf(
        // 时间日期
        "几点", "现在时间", "今天日期", "星期几", "几月几号",
        // 天气
        "天气", "气温", "温度", "下雨", "会不会下雨",
        // 位置
        "在哪", "我的位置", "定位", "什么地方",
        // 设备信息
        "电量", "存储", "内存", "手机型号"
    )
    
    // 📚 知识问答关键词（应交给AI处理）
    private val knowledgeKeywords = listOf(
        // 是什么/为什么类问题
        "是什么", "什么是", "为什么", "为啥", "怎么回事",
        "什么意思", "意思是", "含义", "定义",
        // 如何/怎样类问题
        "怎么样", "如何", "怎样", "方法", "技巧",
        // 比较类问题
        "哪个好", "哪个更", "区别", "差别", "对比",
        // 推荐类问题
        "推荐", "建议", "有什么好的", "有没有推荐",
        // 解释类问题
        "解释一下", "说明", "介绍", "讲讲", "说说"
    )
    
    // 🚫 对话排除词（如果包含这些，可能不是纯对话）
    private val chatExclusionKeywords = listOf(
        "打开", "启动", "发送", "搜索", "导航", "设置", "截图"
    )
    
    // ==================== 核心判断逻辑 ====================
    
    /**
     * 智能判断用户输入的模式
     */
    fun determineMode(input: String): ModeDecision {
        val normalized = input.trim().lowercase()
        
        // 计算各模式得分
        val taskScore = calculateTaskScore(normalized)
        val chatScore = calculateChatScore(normalized)
        val queryScore = calculateQueryScore(normalized)
        val knowledgeScore = calculateKnowledgeScore(normalized)
        
        LogManager.d(TAG, "📊 模式得分: task=$taskScore, chat=$chatScore, query=$queryScore, knowledge=$knowledgeScore")
        
        // 综合判断
        return when {
            // 1. 明确的任务意图（高分且远超其他）
            taskScore >= 0.8f && taskScore > chatScore + 0.3f -> {
                ModeDecision(
                    mode = Mode.TASK,
                    confidence = taskScore,
                    reason = "检测到明确的任务指令",
                    suggestedAction = "execute_task"
                )
            }
            
            // 2. 明确的对话意图
            chatScore >= 0.7f && chatScore > taskScore + 0.2f -> {
                ModeDecision(
                    mode = Mode.CHAT,
                    confidence = chatScore,
                    reason = "检测到日常对话意图",
                    suggestedAction = "ai_chat"
                )
            }
            
            // 3. 信息查询（天气、时间等）
            queryScore >= 0.7f -> {
                ModeDecision(
                    mode = Mode.QUERY,
                    confidence = queryScore,
                    reason = "检测到实时信息查询",
                    suggestedAction = "fetch_realtime_data"
                )
            }
            
            // 4. 知识问答（交给AI）
            knowledgeScore >= 0.6f -> {
                ModeDecision(
                    mode = Mode.CHAT,
                    confidence = knowledgeScore,
                    reason = "检测到知识问答意图",
                    suggestedAction = "ai_knowledge_answer"
                )
            }
            
            // 5. 任务和对话得分接近 - 混合模式
            taskScore >= 0.5f && chatScore >= 0.4f && 
                kotlin.math.abs(taskScore - chatScore) < 0.2f -> {
                ModeDecision(
                    mode = Mode.HYBRID,
                    confidence = maxOf(taskScore, chatScore),
                    reason = "任务和对话意图混合，需要进一步分析",
                    suggestedAction = "ai_analyze_then_decide"
                )
            }
            
            // 6. 任务得分较高
            taskScore > chatScore && taskScore >= 0.5f -> {
                ModeDecision(
                    mode = Mode.TASK,
                    confidence = taskScore,
                    reason = "倾向于任务执行",
                    suggestedAction = "execute_task"
                )
            }
            
            // 7. 对话得分较高
            chatScore > taskScore && chatScore >= 0.4f -> {
                ModeDecision(
                    mode = Mode.CHAT,
                    confidence = chatScore,
                    reason = "倾向于日常对话",
                    suggestedAction = "ai_chat"
                )
            }
            
            // 8. 默认交给AI处理
            else -> {
                ModeDecision(
                    mode = Mode.CHAT,
                    confidence = 0.5f,
                    reason = "无法明确判断，默认交给AI理解",
                    suggestedAction = "ai_chat"
                )
            }
        }
    }
    
    /**
     * 计算任务执行得分
     */
    private fun calculateTaskScore(normalized: String): Float {
        var score = 0f
        var matchCount = 0
        
        // 明确任务关键词匹配
        for (keyword in explicitTaskKeywords) {
            if (keyword.contains(".+")) {
                // 正则模式
                if (Regex(keyword).containsMatchIn(normalized)) {
                    score += 0.4f
                    matchCount++
                }
            } else if (normalized.contains(keyword)) {
                score += 0.3f
                matchCount++
            }
        }
        
        // 命令式语气加分
        val commandPatterns = listOf(
            "帮我", "帮忙", "请", "麻烦"
        )
        if (commandPatterns.any { normalized.contains(it) }) {
            score += 0.15f
        }
        
        // 应用名称检测加分
        val appPatterns = listOf(
            "微信", "qq", "抖音", "淘宝", "支付宝", "高德", "百度",
            "美团", "饿了么", "京东", "拼多多", "网易", "b站", "bilibili"
        )
        if (appPatterns.any { normalized.contains(it) }) {
            score += 0.2f
        }
        
        // 祈使句式加分
        if (normalized.length < 20 && !normalized.contains("吗") && 
            !normalized.contains("呢") && !normalized.contains("？")) {
            score += 0.1f
        }
        
        return minOf(score, 1.0f)
    }
    
    /**
     * 计算日常对话得分
     */
    private fun calculateChatScore(normalized: String): Float {
        var score = 0f
        
        // 明确对话关键词匹配
        for (keyword in explicitChatKeywords) {
            if (normalized.contains(keyword)) {
                score += 0.3f
            }
        }
        
        // 排除词检测（降分）
        for (keyword in chatExclusionKeywords) {
            if (normalized.contains(keyword)) {
                score -= 0.25f
            }
        }
        
        // 疑问句式加分
        val questionMarkers = listOf("吗", "呢", "？", "?", "吧")
        if (questionMarkers.any { normalized.contains(it) }) {
            score += 0.15f
        }
        
        // 情感词汇加分
        val emotionalWords = listOf(
            "开心", "难过", "伤心", "高兴", "累", "烦", "无聊", 
            "紧张", "焦虑", "压力", "郁闷", "孤单"
        )
        if (emotionalWords.any { normalized.contains(it) }) {
            score += 0.25f
        }
        
        // 长文本倾向对话
        if (normalized.length > 30 && 
            !explicitTaskKeywords.any { normalized.contains(it) }) {
            score += 0.15f
        }
        
        // 叙述性语气
        val narrativeMarkers = listOf("其实", "说实话", "我觉得", "我想")
        if (narrativeMarkers.any { normalized.contains(it) }) {
            score += 0.2f
        }
        
        return maxOf(0f, minOf(score, 1.0f))
    }
    
    /**
     * 计算信息查询得分
     */
    private fun calculateQueryScore(normalized: String): Float {
        var score = 0f
        
        for (keyword in queryKeywords) {
            if (normalized.contains(keyword)) {
                score += 0.35f
            }
        }
        
        // 简短的查询问题加分
        if (normalized.length < 15 && queryKeywords.any { normalized.contains(it) }) {
            score += 0.2f
        }
        
        return minOf(score, 1.0f)
    }
    
    /**
     * 计算知识问答得分
     */
    private fun calculateKnowledgeScore(normalized: String): Float {
        var score = 0f
        
        for (keyword in knowledgeKeywords) {
            if (normalized.contains(keyword)) {
                score += 0.3f
            }
        }
        
        // 疑问句式加分
        if (normalized.contains("吗") || normalized.contains("？") || 
            normalized.contains("呢")) {
            score += 0.1f
        }
        
        return minOf(score, 1.0f)
    }
    
    // ==================== 上下文感知切换 ====================
    
    /**
     * 根据对话历史判断是否需要切换模式
     */
    fun shouldSwitchMode(
        currentMode: Mode,
        newInput: String,
        recentHistory: List<String>
    ): Boolean {
        val newDecision = determineMode(newInput)
        
        // 如果新输入的模式与当前不同，且置信度较高，则切换
        if (newDecision.mode != currentMode && newDecision.confidence >= 0.6f) {
            LogManager.d(TAG, "🔄 建议切换模式: $currentMode -> ${newDecision.mode}")
            return true
        }
        
        // 检测模式切换信号词
        val switchToChatSignals = listOf(
            "算了", "不用了", "停", "别", "我们聊聊", "换个话题"
        )
        val switchToTaskSignals = listOf(
            "帮我", "我要", "我想", "请", "麻烦"
        )
        
        val normalizedInput = newInput.lowercase()
        
        if (currentMode == Mode.TASK && 
            switchToChatSignals.any { normalizedInput.contains(it) }) {
            return true
        }
        
        if (currentMode == Mode.CHAT && 
            switchToTaskSignals.any { normalizedInput.startsWith(it) }) {
            return true
        }
        
        return false
    }
    
    /**
     * 获取模式切换的过渡语
     */
    fun getModeTransitionMessage(fromMode: Mode, toMode: Mode): String {
        return when {
            fromMode == Mode.TASK && toMode == Mode.CHAT -> 
                "好的，任务先放一边，有什么想聊的吗？😊"
            fromMode == Mode.CHAT && toMode == Mode.TASK -> 
                "收到！让我来帮你执行这个任务~ ✨"
            fromMode == Mode.QUERY && toMode == Mode.CHAT -> 
                "信息查好了！还想聊点什么呀？"
            else -> ""
        }
    }
}
