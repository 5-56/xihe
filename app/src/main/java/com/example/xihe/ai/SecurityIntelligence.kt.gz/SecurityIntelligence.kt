package com.example.xihe.ai

import com.example.xihe.utils.LogManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ConcurrentHashMap

/**
 * 🔒 安全智能模块
 * 
 * 实现操作安全性和审计功能
 */
object SecurityIntelligence {
    
    private const val TAG = "SecurityIntelligence"
    
    // 数据存储
    private val operationLogs = mutableListOf<OperationLog>()
    private val sensitiveOperations = mutableListOf<SensitiveOperationRecord>()
    private val pendingConfirmations = ConcurrentHashMap<String, PendingConfirmation>()
    private val permissionCache = ConcurrentHashMap<String, PermissionStatus>()
    private val anomalyRecords = mutableListOf<AnomalyRecord>()
    private val operationBaselines = ConcurrentHashMap<String, OperationBaseline>()
    
    private val _securityState = MutableStateFlow(SecurityState())
    val securityState: StateFlow<SecurityState> = _securityState.asStateFlow()
    
    private var securityConfig = SecurityConfig()
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
    
    // ==================== 💰 支付操作检查 ====================
    
    fun checkPaymentOperation(
        amount: Double,
        paymentMethod: String,
        recipient: String,
        context: OperationSecurityContext
    ): PaymentCheckResult {
        LogManager.d(TAG, "💰 检查支付操作: ¥$amount -> $recipient")
        
        val risks = mutableListOf<SecurityRisk>()
        var requireConfirmation = false
        var confirmationType = ConfirmationType.NONE
        
        // 金额检查
        if (amount >= securityConfig.paymentHighRiskThreshold) {
            risks.add(SecurityRisk(RiskType.HIGH_AMOUNT, SecurityRiskLevel.HIGH, 
                "支付金额较大(¥$amount)", "确认收款方和金额"))
            requireConfirmation = true
            confirmationType = ConfirmationType.BIOMETRIC
        } else if (amount >= securityConfig.paymentMediumRiskThreshold) {
            risks.add(SecurityRisk(RiskType.MEDIUM_AMOUNT, SecurityRiskLevel.MEDIUM,
                "支付金额需要确认", "请确认支付信息"))
            requireConfirmation = true
            confirmationType = ConfirmationType.PASSWORD
        }
        
        // 收款方检查
        if (!isKnownRecipient(recipient)) {
            risks.add(SecurityRisk(RiskType.UNKNOWN_RECIPIENT, SecurityRiskLevel.MEDIUM,
                "首次向此收款方付款", "确认收款方身份"))
            requireConfirmation = true
        }
        
        // 时间检查
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        if (hour in 0..5) {
            risks.add(SecurityRisk(RiskType.UNUSUAL_TIME, SecurityRiskLevel.LOW,
                "深夜支付操作", "确认是本人操作"))
        }
        
        // 频率检查
        val recentPayments = getRecentPaymentCount(30 * 60 * 1000)
        if (recentPayments >= securityConfig.maxPaymentsPerHour) {
            risks.add(SecurityRisk(RiskType.FREQUENT_OPERATION, SecurityRiskLevel.HIGH,
                "短时间内多次支付", "检查是否异常"))
            requireConfirmation = true
            confirmationType = ConfirmationType.BIOMETRIC
        }
        
        recordSensitiveOperation(SensitiveOperationRecord(
            id = generateId("op"), type = SensitiveOperationType.PAYMENT,
            description = "支付 ¥$amount 给 $recipient",
            riskLevel = calculateOverallRisk(risks),
            timestamp = System.currentTimeMillis(), context = context, confirmed = false
        ))
        
        logOperation(OperationType.PAYMENT, "支付检查", true, risks)
        
        return PaymentCheckResult(
            allowed = true, requireConfirmation = requireConfirmation,
            confirmationType = confirmationType, risks = risks,
            confirmationMessage = if (requireConfirmation) generatePaymentConfirmMsg(amount, recipient, risks) else null,
            confirmationId = if (requireConfirmation) createPendingConfirmation(OperationType.PAYMENT, 
                mapOf("amount" to amount.toString(), "recipient" to recipient)) else null
        )
    }
    
    // ==================== 🗑️ 删除操作检查 ====================
    
    fun checkDeleteOperation(
        targetType: DeleteTargetType,
        targetName: String,
        targetCount: Int,
        isRecoverable: Boolean,
        context: OperationSecurityContext
    ): DeleteCheckResult {
        LogManager.d(TAG, "🗑️ 检查删除操作: $targetType - $targetName")
        
        val risks = mutableListOf<SecurityRisk>()
        var requireConfirmation = false
        var confirmationType = ConfirmationType.NONE
        
        when (targetType) {
            DeleteTargetType.FILE -> if (!isRecoverable) {
                risks.add(SecurityRisk(RiskType.IRREVERSIBLE, SecurityRiskLevel.HIGH, "文件删除后无法恢复", "确认是否需要备份"))
                requireConfirmation = true; confirmationType = ConfirmationType.EXPLICIT
            }
            DeleteTargetType.CONTACT -> {
                risks.add(SecurityRisk(RiskType.DATA_LOSS, SecurityRiskLevel.MEDIUM, "删除联系人将丢失信息", "确认是否需要删除"))
                requireConfirmation = true; confirmationType = ConfirmationType.SIMPLE
            }
            DeleteTargetType.MESSAGE -> if (targetCount > 10) {
                risks.add(SecurityRisk(RiskType.BATCH_OPERATION, SecurityRiskLevel.MEDIUM, "批量删除${targetCount}条消息", "确认删除范围"))
                requireConfirmation = true; confirmationType = ConfirmationType.EXPLICIT
            }
            DeleteTargetType.APP_DATA -> {
                risks.add(SecurityRisk(RiskType.DATA_LOSS, SecurityRiskLevel.HIGH, "清除应用数据将丢失所有记录", "确认是否需要备份"))
                requireConfirmation = true; confirmationType = ConfirmationType.EXPLICIT
            }
            DeleteTargetType.ACCOUNT -> {
                risks.add(SecurityRisk(RiskType.IRREVERSIBLE, SecurityRiskLevel.CRITICAL, "删除账户不可逆", "请三思"))
                requireConfirmation = true; confirmationType = ConfirmationType.BIOMETRIC
            }
            DeleteTargetType.PHOTO, DeleteTargetType.VIDEO -> if (targetCount > 5) {
                risks.add(SecurityRisk(RiskType.BATCH_OPERATION, SecurityRiskLevel.MEDIUM, "批量删除${targetCount}个媒体", "确认删除内容"))
                requireConfirmation = true
            }
        }
        
        recordSensitiveOperation(SensitiveOperationRecord(
            id = generateId("op"), type = SensitiveOperationType.DELETE,
            description = "删除 $targetType: $targetName (${targetCount}项)",
            riskLevel = calculateOverallRisk(risks),
            timestamp = System.currentTimeMillis(), context = context, confirmed = false
        ))
        
        logOperation(OperationType.DELETE, "删除检查", true, risks)
        
        return DeleteCheckResult(
            allowed = true, requireConfirmation = requireConfirmation,
            confirmationType = confirmationType, risks = risks,
            confirmationMessage = if (requireConfirmation) "确认删除 $targetName？" else null,
            confirmationId = if (requireConfirmation) createPendingConfirmation(OperationType.DELETE,
                mapOf("type" to targetType.name, "name" to targetName)) else null,
            suggestBackup = !isRecoverable
        )
    }
    
    // ==================== 📝 敏感操作记录 ====================
    
    fun recordSensitiveOperation(record: SensitiveOperationRecord) {
        sensitiveOperations.add(record)
        if (sensitiveOperations.size > 1000) sensitiveOperations.removeAll(sensitiveOperations.take(100))
        updateSecurityState()
    }
    
    // ==================== 🔐 权限检查 ====================
    
    fun checkOperationPermission(
        operation: OperationType,
        requiredPermissions: List<String>
    ): PermissionCheckResult {
        val missing = mutableListOf<String>()
        val granted = mutableListOf<String>()
        
        requiredPermissions.forEach { perm ->
            when (permissionCache[perm]) {
                PermissionStatus.GRANTED -> granted.add(perm)
                else -> missing.add(perm)
            }
        }
        
        return PermissionCheckResult(
            allGranted = missing.isEmpty(),
            grantedPermissions = granted, missingPermissions = missing,
            canProceed = missing.isEmpty(), requestRequired = missing.isNotEmpty(),
            permissionExplanations = missing.associate { it to "需要此权限完成操作" }
        )
    }
    
    fun updatePermissionStatus(permission: String, status: PermissionStatus) {
        permissionCache[permission] = status
    }
    
    // ==================== ⚠️ 风险评估 ====================
    
    fun assessOperationRisk(
        operation: OperationType,
        parameters: Map<String, Any>,
        context: OperationSecurityContext
    ): SecurityRiskAssessment {
        val risks = mutableListOf<SecurityRisk>()
        
        // 基础风险
        when (operation) {
            OperationType.PAYMENT -> risks.add(SecurityRisk(RiskType.FINANCIAL, SecurityRiskLevel.MEDIUM, "涉及资金", "确认金额"))
            OperationType.DELETE -> risks.add(SecurityRisk(RiskType.DATA_LOSS, SecurityRiskLevel.LOW, "数据删除", "确认内容"))
            OperationType.ACCOUNT_ACTION -> risks.add(SecurityRisk(RiskType.ACCOUNT_SECURITY, SecurityRiskLevel.MEDIUM, "账户操作", "确认必要性"))
            else -> {}
        }
        
        // 上下文风险
        if (!context.isSecureNetwork) risks.add(SecurityRisk(RiskType.INSECURE_NETWORK, SecurityRiskLevel.MEDIUM, "网络不安全", "使用安全网络"))
        if (context.isRooted) risks.add(SecurityRisk(RiskType.DEVICE_COMPROMISED, SecurityRiskLevel.HIGH, "设备已root", "谨慎操作"))
        
        val level = calculateOverallRisk(risks)
        return SecurityRiskAssessment(
            operation = operation, overallLevel = level,
            riskScore = risks.map { it.level.ordinal }.average().toFloat(),
            risks = risks, recommendations = risks.map { it.mitigation },
            proceedAllowed = level != SecurityRiskLevel.CRITICAL,
            requiresConfirmation = level >= SecurityRiskLevel.MEDIUM
        )
    }
    
    // ==================== ✅ 确认操作 ====================
    
    fun confirmPendingOperation(confirmationId: String, type: ConfirmationType, data: String? = null): ConfirmationResult {
        val pending = pendingConfirmations[confirmationId]
            ?: return ConfirmationResult(false, "未找到待确认操作", false)
        
        if (System.currentTimeMillis() - pending.createdAt > securityConfig.confirmationTimeout) {
            pendingConfirmations.remove(confirmationId)
            return ConfirmationResult(false, "确认已过期", false)
        }
        
        if (pending.requiredType.ordinal > type.ordinal) {
            return ConfirmationResult(false, "确认级别不足", false)
        }
        
        pendingConfirmations.remove(confirmationId)
        logOperation(pending.operationType, "操作已确认", true, emptyList())
        return ConfirmationResult(true, "确认成功", true)
    }
    
    fun cancelPendingOperation(confirmationId: String): Boolean {
        return pendingConfirmations.remove(confirmationId) != null
    }
    
    // ==================== 📋 操作日志 ====================
    
    fun logOperation(type: OperationType, description: String, success: Boolean, risks: List<SecurityRisk>, details: Map<String, String> = emptyMap()) {
        val log = OperationLog(
            id = generateId("log"), type = type, description = description,
            success = success, timestamp = System.currentTimeMillis(),
            risks = risks, details = details, sessionId = "session_${System.currentTimeMillis() / 3600000}"
        )
        operationLogs.add(log)
        detectAnomalies(log)
        if (operationLogs.size > 5000) operationLogs.removeAll(operationLogs.take(500))
        updateSecurityState()
    }
    
    // ==================== 🔍 异常检测 ====================
    
    fun detectAnomalies(log: OperationLog) {
        val anomalies = mutableListOf<AnomalyType>()
        
        // 频率异常
        val recentSame = operationLogs.count { System.currentTimeMillis() - it.timestamp < 60000 && it.type == log.type }
        if (recentSame > 10) anomalies.add(AnomalyType.FREQUENCY)
        
        // 时间异常
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        if (hour in 0..5) anomalies.add(AnomalyType.UNUSUAL_TIME)
        
        // 失败率异常
        if (!log.success && operationLogs.takeLast(10).count { !it.success } >= 5) {
            anomalies.add(AnomalyType.HIGH_FAILURE_RATE)
        }
        
        // 连续高风险
        if (log.risks.any { it.level >= SecurityRiskLevel.HIGH }) {
            if (operationLogs.takeLast(5).count { it.risks.any { r -> r.level >= SecurityRiskLevel.HIGH } } >= 3) {
                anomalies.add(AnomalyType.CONSECUTIVE_RISKY)
            }
        }
        
        if (anomalies.isNotEmpty()) {
            anomalyRecords.add(AnomalyRecord(
                id = generateId("anomaly"), types = anomalies, relatedLogId = log.id,
                severity = if (anomalies.contains(AnomalyType.CONSECUTIVE_RISKY)) AnomalySeverity.HIGH else AnomalySeverity.MEDIUM,
                timestamp = System.currentTimeMillis(),
                description = "${log.type.description}: ${anomalies.joinToString()}", investigated = false
            ))
            if (anomalyRecords.size > 500) anomalyRecords.removeAll(anomalyRecords.take(100))
        }
    }
    
    fun analyzeAnomalies(timeRange: LongRange = (System.currentTimeMillis() - 86400000)..System.currentTimeMillis()): AnomalyAnalysis {
        val relevant = anomalyRecords.filter { it.timestamp in timeRange }
        return AnomalyAnalysis(
            totalAnomalies = relevant.size,
            severityDistribution = relevant.groupBy { it.severity }.mapValues { it.value.size },
            typeDistribution = relevant.flatMap { it.types }.groupBy { it }.mapValues { it.value.size },
            trends = emptyList(),
            recommendations = if (relevant.isEmpty()) listOf("系统运行正常") else listOf("关注异常趋势", "检查安全配置")
        )
    }
    
    // ==================== 🔄 操作回放 ====================
    
    fun replayOperations(startTime: Long, endTime: Long, types: List<OperationType>? = null): OperationReplay {
        var logs = operationLogs.filter { it.timestamp in startTime..endTime }
        if (types != null) logs = logs.filter { it.type in types }
        
        val timeline = logs.map { ReplayEvent(it.timestamp, dateFormat.format(Date(it.timestamp)), it.type, it.description, it.success, it.risks.map { r -> r.description }, it.details) }
        val stats = ReplayStatistics(logs.size, logs.count { it.success }, logs.count { !it.success }, logs.groupBy { it.type }.mapValues { it.value.size }, 0f)
        
        return OperationReplay(startTime, endTime, timeline, stats, "共${logs.size}个操作")
    }
    
    // ==================== 📄 报告生成 ====================
    
    fun generateOperationReport(reportType: ReportType, timeRange: LongRange = (System.currentTimeMillis() - 86400000)..System.currentTimeMillis()): OperationReport {
        val logs = operationLogs.filter { it.timestamp in timeRange }
        val sensitive = sensitiveOperations.filter { it.timestamp in timeRange }
        val anomalies = anomalyRecords.filter { it.timestamp in timeRange }
        
        val sections = mutableListOf<ReportSection>()
        
        sections.add(ReportSection("📊 概览", "总操作: ${logs.size}, 成功: ${logs.count { it.success }}", 
            listOf("敏感操作: ${sensitive.size}", "异常: ${anomalies.size}")))
        
        if (reportType in listOf(ReportType.FULL, ReportType.SECURITY)) {
            sections.add(ReportSection("🔒 安全", "高风险: ${sensitive.count { it.riskLevel >= SecurityRiskLevel.HIGH }}",
                listOf("待确认: ${pendingConfirmations.size}")))
        }
        
        sections.add(ReportSection("💡 建议", "定期审查日志", listOf("保持安全配置", "关注异常")))
        
        return OperationReport(generateId("report"), reportType, System.currentTimeMillis(), timeRange, sections, 
            "操作${logs.size}次，异常${anomalies.size}次", listOf(ExportFormat.TEXT, ExportFormat.JSON))
    }
    
    fun exportReport(report: OperationReport, format: ExportFormat): String {
        return when (format) {
            ExportFormat.TEXT -> report.sections.joinToString("\n\n") { "${it.title}\n${it.content}\n${it.highlights.joinToString(", ")}" }
            ExportFormat.JSON -> """{"id":"${report.id}","type":"${report.type}","summary":"${report.summary}"}"""
            ExportFormat.HTML -> "<html><body><h1>报告</h1>${report.sections.joinToString("") { "<h2>${it.title}</h2><p>${it.content}</p>" }}</body></html>"
            ExportFormat.CSV -> "Section,Content\n${report.sections.joinToString("\n") { "${it.title},${it.content}" }}"
        }
    }
    
    // ==================== 🛠️ 辅助方法 ====================
    
    private fun isKnownRecipient(recipient: String) = sensitiveOperations.any { it.type == SensitiveOperationType.PAYMENT && it.confirmed && it.description.contains(recipient) }
    private fun getRecentPaymentCount(windowMs: Long) = sensitiveOperations.count { it.type == SensitiveOperationType.PAYMENT && System.currentTimeMillis() - it.timestamp < windowMs }
    private fun calculateOverallRisk(risks: List<SecurityRisk>): SecurityRiskLevel {
        if (risks.isEmpty()) return SecurityRiskLevel.NONE
        val max = risks.maxOf { it.level.ordinal }
        return SecurityRiskLevel.entries[max.coerceAtMost(SecurityRiskLevel.entries.size - 1)]
    }
    private fun generatePaymentConfirmMsg(amount: Double, recipient: String, risks: List<SecurityRisk>) = "确认支付 ¥$amount 给 $recipient？\n${risks.joinToString("\n") { "• ${it.description}" }}"
    private fun createPendingConfirmation(type: OperationType, params: Map<String, String>): String {
        val id = generateId("confirm")
        pendingConfirmations[id] = PendingConfirmation(id, generateId("op"), type, params, 
            if (type == OperationType.PAYMENT) ConfirmationType.PASSWORD else ConfirmationType.SIMPLE, System.currentTimeMillis())
        return id
    }
    private fun generateId(prefix: String) = "${prefix}_${System.currentTimeMillis()}_${(Math.random() * 1000).toInt()}"
    private fun updateSecurityState() {
        _securityState.value = SecurityState(operationLogs.size, sensitiveOperations.size, pendingConfirmations.size, anomalyRecords.size, System.currentTimeMillis())
    }
    
    fun updateSecurityConfig(config: SecurityConfig) { securityConfig = config }
    fun resetSecurityData() { operationLogs.clear(); sensitiveOperations.clear(); pendingConfirmations.clear(); anomalyRecords.clear(); updateSecurityState() }
    
    fun getSecurityStats() = SecurityStats(
        operationLogs.size, operationLogs.count { System.currentTimeMillis() - it.timestamp < 86400000 },
        sensitiveOperations.size, sensitiveOperations.count { it.riskLevel >= SecurityRiskLevel.HIGH },
        anomalyRecords.size, pendingConfirmations.size,
        if (operationLogs.isNotEmpty()) operationLogs.count { it.success }.toFloat() / operationLogs.size else 1f
    )
}

// ==================== 📦 数据类 ====================

data class SecurityConfig(
    val paymentHighRiskThreshold: Double = 1000.0, val paymentMediumRiskThreshold: Double = 100.0,
    val maxPaymentsPerHour: Int = 5, val confirmationTimeout: Long = 300000
)

enum class OperationType(val description: String) {
    PAYMENT("支付"), DELETE("删除"), LOGIN("登录"), LOGOUT("登出"),
    SETTINGS_CHANGE("设置"), ACCOUNT_ACTION("账户"), DATA_EXPORT("导出"),
    DATA_IMPORT("导入"), PERMISSION_GRANT("授权"), APP_INSTALL("安装"),
    APP_UNINSTALL("卸载"), GENERAL("一般")
}

enum class DeleteTargetType(val description: String) {
    FILE("文件"), CONTACT("联系人"), MESSAGE("消息"),
    PHOTO("照片"), VIDEO("视频"), APP_DATA("应用数据"), ACCOUNT("账户")
}

enum class SensitiveOperationType(val description: String) {
    PAYMENT("支付"), DELETE("删除"), ACCOUNT("账户"), PERMISSION("权限"), EXPORT("导出")
}

enum class SecurityRiskLevel { NONE, LOW, MEDIUM, HIGH, CRITICAL }

enum class RiskType {
    HIGH_AMOUNT, MEDIUM_AMOUNT, UNKNOWN_RECIPIENT, UNUSUAL_TIME, FREQUENT_OPERATION,
    IRREVERSIBLE, DATA_LOSS, BATCH_OPERATION, FINANCIAL, ACCOUNT_SECURITY,
    INSECURE_NETWORK, DEVICE_COMPROMISED, REPEATED_FAILURE
}

data class SecurityRisk(val type: RiskType, val level: SecurityRiskLevel, val description: String, val mitigation: String)

enum class ConfirmationType(val desc: String) { NONE("无"), SIMPLE("简单"), EXPLICIT("明确"), PASSWORD("密码"), BIOMETRIC("生物") }

data class OperationSecurityContext(val isSecureNetwork: Boolean = true, val isRooted: Boolean = false, val deviceId: String = "", val appVersion: String = "")

data class PaymentCheckResult(val allowed: Boolean, val requireConfirmation: Boolean, val confirmationType: ConfirmationType, val risks: List<SecurityRisk>, val confirmationMessage: String?, val confirmationId: String?)

data class DeleteCheckResult(val allowed: Boolean, val requireConfirmation: Boolean, val confirmationType: ConfirmationType, val risks: List<SecurityRisk>, val confirmationMessage: String?, val confirmationId: String?, val suggestBackup: Boolean)

enum class PermissionStatus { GRANTED, DENIED, UNKNOWN }

data class PermissionCheckResult(val allGranted: Boolean, val grantedPermissions: List<String>, val missingPermissions: List<String>, val canProceed: Boolean, val requestRequired: Boolean, val permissionExplanations: Map<String, String>)

data class SecurityRiskAssessment(val operation: OperationType, val overallLevel: SecurityRiskLevel, val riskScore: Float, val risks: List<SecurityRisk>, val recommendations: List<String>, val proceedAllowed: Boolean, val requiresConfirmation: Boolean)

data class ConfirmationResult(val success: Boolean, val reason: String, val operationAllowed: Boolean)

data class PendingConfirmation(val id: String, val operationId: String, val operationType: OperationType, val parameters: Map<String, String>, val requiredType: ConfirmationType, val createdAt: Long)

data class SensitiveOperationRecord(val id: String, val type: SensitiveOperationType, val description: String, val riskLevel: SecurityRiskLevel, val timestamp: Long, val context: OperationSecurityContext, val confirmed: Boolean)

data class OperationLog(val id: String, val type: OperationType, val description: String, val success: Boolean, val timestamp: Long, val risks: List<SecurityRisk>, val details: Map<String, String>, val sessionId: String)

enum class AnomalyType { FREQUENCY, UNUSUAL_TIME, HIGH_FAILURE_RATE, CONSECUTIVE_RISKY, PATTERN_DEVIATION, UNAUTHORIZED_ACCESS }
enum class AnomalySeverity { LOW, MEDIUM, HIGH, CRITICAL }

data class AnomalyRecord(val id: String, val types: List<AnomalyType>, val relatedLogId: String, val severity: AnomalySeverity, val timestamp: Long, val description: String, val investigated: Boolean)

data class AnomalyAnalysis(val totalAnomalies: Int, val severityDistribution: Map<AnomalySeverity, Int>, val typeDistribution: Map<AnomalyType, Int>, val trends: List<AnomalyTrend>, val recommendations: List<String>)

data class AnomalyTrend(val type: AnomalyType, val frequency: Int, val direction: TrendDirection, val description: String)
enum class TrendDirection { INCREASING, STABLE, DECREASING }

data class OperationBaseline(val type: OperationType, val activeHours: Set<Int>, val avgHourlyFrequency: Float, val avgSuccessRate: Float)

data class ReplayEvent(val timestamp: Long, val formattedTime: String, val type: OperationType, val description: String, val success: Boolean, val risks: List<String>, val details: Map<String, String>)

data class ReplayStatistics(val totalOperations: Int, val successCount: Int, val failureCount: Int, val operationTypes: Map<OperationType, Int>, val averageRiskLevel: Float)

data class OperationReplay(val startTime: Long, val endTime: Long, val timeline: List<ReplayEvent>, val statistics: ReplayStatistics, val summary: String)

enum class ReportType { SUMMARY, DETAILED, SECURITY, FULL }
enum class ExportFormat { TEXT, JSON, HTML, CSV }

data class ReportSection(val title: String, val content: String, val highlights: List<String>)

data class OperationReport(val id: String, val type: ReportType, val generatedAt: Long, val timeRange: LongRange, val sections: List<ReportSection>, val summary: String, val exportFormats: List<ExportFormat>)

data class SecurityState(val totalOperations: Int = 0, val sensitiveOperations: Int = 0, val pendingConfirmations: Int = 0, val anomalyCount: Int = 0, val lastUpdate: Long = 0)

data class SecurityStats(val totalOperations: Int, val recentOperations: Int, val sensitiveOperations: Int, val highRiskOperations: Int, val anomalyCount: Int, val pendingConfirmations: Int, val successRate: Float)
