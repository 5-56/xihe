package com.example.xihe.ai

import com.example.xihe.utils.LogManager
import com.example.xihe.core.AutomationEngine
import com.example.xihe.screen.ScreenAnalyzer
import kotlinx.coroutines.delay
import kotlinx.serialization.Serializable

/**
 * 🎯 智能任务规划器
 * 将用户请求分解为可执行的步骤序列
 */
class TaskPlanner {
    
    companion object {
        private const val TAG = "TaskPlanner"
    }
    
    /**
     * 任务风险级别
     */
    enum class RiskLevel {
        SAFE,      // 安全
        LOW,       // 低风险
        MEDIUM,    // 中风险
        HIGH,      // 高风险
        CRITICAL   // 危险
    }
    
    /**
     * 执行步骤
     */
    @Serializable
    data class ExecutionStep(
        val id: String,
        val description: String,
        val action: ActionType,
        val target: String? = null,
        val value: String? = null,
        val waitAfter: Long = 500, // 执行后等待时间(ms)
        val retryCount: Int = 3,    // 重试次数
        val fallbackStepId: String? = null, // 失败后的备选步骤
        val requiresConfirmation: Boolean = false // 是否需要用户确认
    )
    
    /**
     * 动作类型
     */
    enum class ActionType {
        LAUNCH_APP,      // 启动应用
        CLICK,           // 点击
        LONG_CLICK,      // 长按
        SWIPE,           // 滑动
        INPUT_TEXT,      // 输入文本
        SCROLL,          // 滚动
        BACK,            // 返回
        HOME,            // 主页
        RECENT_APPS,     // 最近任务
        WAIT,            // 等待
        CHECK_STATE,     // 检查状态
        TAKE_SCREENSHOT, // 截图
        SYSTEM_ACTION    // 系统动作
    }
    
    /**
     * 任务计划
     */
    data class TaskPlan(
        val taskId: String,
        val userRequest: String,
        val steps: List<ExecutionStep>,
        val estimatedDuration: Long, // 预计耗时(ms)
        val riskLevel: RiskLevel,
        val fallbackStrategies: Map<String, FallbackStrategy>,
        val metadata: Map<String, Any> = emptyMap()
    )
    
    /**
     * 失败回退策略
     */
    data class FallbackStrategy(
        val trigger: String, // 触发条件
        val action: String,  // 回退动作
        val maxRetries: Int = 3
    )
    
    /**
     * 任务模板库 - 常见任务的预定义步骤
     */
    private val taskTemplates = mapOf(
        "send_wechat_message" to listOf(
            ExecutionStep(
                id = "1",
                description = "打开微信",
                action = ActionType.LAUNCH_APP,
                target = "com.tencent.mm",
                waitAfter = 2000
            ),
            ExecutionStep(
                id = "2",
                description = "点击搜索",
                action = ActionType.CLICK,
                target = "搜索",
                waitAfter = 1000
            ),
            ExecutionStep(
                id = "3",
                description = "输入联系人",
                action = ActionType.INPUT_TEXT,
                target = "search_input",
                waitAfter = 1000
            ),
            ExecutionStep(
                id = "4",
                description = "选择联系人",
                action = ActionType.CLICK,
                target = "contact_item",
                waitAfter = 1500
            ),
            ExecutionStep(
                id = "5",
                description = "输入消息",
                action = ActionType.INPUT_TEXT,
                target = "message_input",
                waitAfter = 500
            ),
            ExecutionStep(
                id = "6",
                description = "发送消息",
                action = ActionType.CLICK,
                target = "send_button",
                waitAfter = 500
            )
        ),
        
        "take_screenshot" to listOf(
            ExecutionStep(
                id = "1",
                description = "执行截图",
                action = ActionType.TAKE_SCREENSHOT,
                waitAfter = 500
            ),
            ExecutionStep(
                id = "2",
                description = "保存截图",
                action = ActionType.SYSTEM_ACTION,
                target = "save_screenshot",
                waitAfter = 500
            )
        ),
        
        "open_app" to listOf(
            ExecutionStep(
                id = "1",
                description = "启动应用",
                action = ActionType.LAUNCH_APP,
                waitAfter = 2000
            )
        )
    )
    
    /**
     * 🎯 规划任务
     */
    fun planTask(
        userRequest: String,
        intent: IntentClassifier.IntentResult,
        currentScreen: ScreenAnalyzer.ScreenState? = null
    ): TaskPlan {
        LogManager.d(TAG, "开始规划任务: $userRequest")
        
        // 根据意图选择或生成执行步骤
        val steps = when {
            // 检查是否有匹配的模板
            hasTemplate(userRequest, intent) -> {
                getTemplateSteps(userRequest, intent)
            }
            // 动态生成步骤
            else -> {
                generateDynamicSteps(userRequest, intent, currentScreen)
            }
        }
        
        // 评估风险级别
        val riskLevel = assessRisk(userRequest, steps)
        
        // 生成回退策略
        val fallbacks = generateFallbackStrategies(steps, intent)
        
        // 估算执行时间
        val estimatedDuration = calculateDuration(steps)
        
        // 生成任务ID
        val taskId = "task_${System.currentTimeMillis()}"
        
        val plan = TaskPlan(
            taskId = taskId,
            userRequest = userRequest,
            steps = steps,
            estimatedDuration = estimatedDuration,
            riskLevel = riskLevel,
            fallbackStrategies = fallbacks,
            metadata = mapOf(
                "intent" to intent.intent.name,
                "confidence" to intent.confidence,
                "timestamp" to System.currentTimeMillis()
            )
        )
        
        LogManager.d(TAG, "任务规划完成: ${steps.size}个步骤, 风险级别: $riskLevel")
        return plan
    }
    
    /**
     * 检查是否有预定义模板
     */
    private fun hasTemplate(
        userRequest: String,
        intent: IntentClassifier.IntentResult
    ): Boolean {
        return when {
            userRequest.contains("微信") && userRequest.contains("发") -> true
            userRequest.contains("截图") || userRequest.contains("截屏") -> true
            userRequest.contains("打开") && intent.entities.containsKey("app") -> true
            else -> false
        }
    }
    
    /**
     * 获取模板步骤
     */
    private fun getTemplateSteps(
        userRequest: String,
        intent: IntentClassifier.IntentResult
    ): List<ExecutionStep> {
        val template = when {
            userRequest.contains("微信") && userRequest.contains("发") -> {
                val steps = taskTemplates["send_wechat_message"]?.toMutableList() ?: return emptyList()
                // 填充具体参数
                intent.entities["contact"]?.let { contact ->
                    steps[2] = steps[2].copy(value = contact.toString())
                }
                intent.entities["message"]?.let { message ->
                    steps[4] = steps[4].copy(value = message.toString())
                }
                steps
            }
            userRequest.contains("截图") || userRequest.contains("截屏") -> {
                taskTemplates["take_screenshot"] ?: return emptyList()
            }
            userRequest.contains("打开") -> {
                val steps = taskTemplates["open_app"]?.toMutableList() ?: return emptyList()
                intent.entities["app"]?.let { app ->
                    steps[0] = steps[0].copy(
                        target = getPackageName(app.toString()),
                        description = "打开$app"
                    )
                }
                steps
            }
            else -> emptyList()
        }
        
        return template
    }
    
    /**
     * 动态生成执行步骤
     */
    private fun generateDynamicSteps(
        userRequest: String,
        intent: IntentClassifier.IntentResult,
        currentScreen: ScreenAnalyzer.ScreenState?
    ): List<ExecutionStep> {
        val steps = mutableListOf<ExecutionStep>()
        var stepId = 1
        
        // 🚀 优先检查 LLM 提供的【多步动作序列】 (llm_actions)
        val llmActionsJson = intent.entities["llm_actions"]?.toString()
        if (llmActionsJson != null && llmActionsJson.isNotEmpty()) {
            try {
                val json = kotlinx.serialization.json.Json { ignoreUnknownKeys = true }
                val llmActions = json.decodeFromString(
                    kotlinx.serialization.builtins.ListSerializer(com.example.xihe.core.LLMClient.LLMAction.serializer()), 
                    llmActionsJson
                )
                
                if (llmActions.isNotEmpty()) {
                    LogManager.d(TAG, "🎯 使用 LLM 多步连招: ${llmActions.size} 步")
                    
                    llmActions.forEach { action ->
                        // 根据 LLMAction 类型映射到 ExecutionStep
                        val stepAction = when (action.type) {
                            "CLICK" -> ActionType.CLICK
                            "INPUT" -> ActionType.INPUT_TEXT
                            "OPEN_APP" -> ActionType.LAUNCH_APP
                            "SCROLL" -> ActionType.SCROLL // 或 SWIPE
                            "SWIPE" -> ActionType.SWIPE
                            "HOME" -> ActionType.HOME
                            "BACK" -> ActionType.BACK
                            "WAIT" -> ActionType.WAIT
                            else -> ActionType.CLICK // 默认点击
                        }
                        
                        // 处理特殊参数
                        val target = if (stepAction == ActionType.LAUNCH_APP) {
                            getPackageName(action.target)
                        } else {
                            action.target
                        }
                        
                        val value = if (stepAction == ActionType.SCROLL || stepAction == ActionType.SWIPE) {
                             action.target // SCROLL 的 target 通常是 "down"/"up"
                        } else {
                            action.text
                        }
                        
                        // 智能计算等待时间
                        val waitTime = if (action.type == "WAIT") {
                             action.text.toLongOrNull() ?: 1000L
                        } else when (stepAction) {
                            ActionType.LAUNCH_APP -> 3000L
                            ActionType.INPUT_TEXT -> 1500L
                            ActionType.SCROLL -> 800L
                            else -> 1000L
                        }

                        steps.add(
                            ExecutionStep(
                                id = stepId++.toString(),
                                description = action.description.ifEmpty { "${action.type} ${action.target}" },
                                action = stepAction,
                                target = target,
                                value = value,
                                waitAfter = waitTime
                            )
                        )
                    }
                    return steps
                }
            } catch (e: Exception) {
                LogManager.e(TAG, "解析 LLM 动作序列失败", e)
            }
        }
        
        // 🚀 (旧) 优先检查 LLM 提供的明确动作指令
        // 这些指令是由 ModuleCoordinator 从 LLMResponse 中提取并注入到 entities 中的
        val explicitActionType = intent.entities["action_type"]?.toString()
        if (explicitActionType != null && explicitActionType != "NONE") {
            LogManager.d(TAG, "🎯 使用 LLM 明确指令: $explicitActionType")
            val target = intent.entities["target"]?.toString()
            val text = intent.entities["text"]?.toString()
            val app = intent.entities["app"]?.toString()
            
            when (explicitActionType) {
                "CLICK" -> {
                    steps.add(
                        ExecutionStep(
                            id = stepId++.toString(),
                            description = "点击${target ?: "目标"}",
                            action = ActionType.CLICK,
                            target = target,
                            waitAfter = 1000
                        )
                    )
                }
                "INPUT" -> {
                    steps.add(
                        ExecutionStep(
                            id = stepId++.toString(),
                            description = "输入文本",
                            action = ActionType.INPUT_TEXT,
                            value = text, // LLM 的 text 字段对应 value
                            target = target, // 可选的目标输入框
                            waitAfter = 500
                        )
                    )
                }
                "OPEN_APP" -> {
                    if (app != null) {
                        steps.add(
                            ExecutionStep(
                                id = stepId++.toString(),
                                description = "启动$app",
                                action = ActionType.LAUNCH_APP,
                                target = getPackageName(app),
                                waitAfter = 2000
                            )
                        )
                    }
                }
                "SCROLL" -> {
                    steps.add(
                        ExecutionStep(
                            id = stepId++.toString(),
                            description = "滑动屏幕",
                            action = ActionType.SWIPE,
                            value = target ?: "down", // target 暂时作为方向
                            waitAfter = 800
                        )
                    )
                }
                "HOME" -> {
                     steps.add(
                        ExecutionStep(
                            id = stepId++.toString(),
                            description = "返回主页",
                            action = ActionType.HOME,
                            waitAfter = 500
                        )
                    )
                }
                "BACK" -> {
                     steps.add(
                        ExecutionStep(
                            id = stepId++.toString(),
                            description = "返回上一页",
                            action = ActionType.BACK,
                            waitAfter = 500
                        )
                    )
                }
            }
            
            // 如果成功生成了 LLM 指令步骤，直接返回
            if (steps.isNotEmpty()) {
                return steps
            }
        }
        
        // ==================== 旧的正则匹配逻辑 (兜底) ====================
        
        // 根据意图类型生成基础步骤
        when (intent.intent) {
            IntentClassifier.UserIntent.AUTOMATION_TASK -> {
                // 分析需要执行的动作
                if (userRequest.contains("返回")) {
                    steps.add(
                        ExecutionStep(
                            id = stepId++.toString(),
                            description = "返回上一页",
                            action = ActionType.BACK,
                            waitAfter = 500
                        )
                    )
                }
                
                if (userRequest.contains("主页") || userRequest.contains("桌面")) {
                    steps.add(
                        ExecutionStep(
                            id = stepId++.toString(),
                            description = "返回主页",
                            action = ActionType.HOME,
                            waitAfter = 500
                        )
                    )
                }
                
                if (userRequest.contains("点击")) {
                    val target = extractClickTarget(userRequest)
                    steps.add(
                        ExecutionStep(
                            id = stepId++.toString(),
                            description = "点击$target",
                            action = ActionType.CLICK,
                            target = target,
                            waitAfter = 1000
                        )
                    )
                }
                
                if (userRequest.contains("滑动") || userRequest.contains("滚动")) {
                    val direction = extractScrollDirection(userRequest)
                    steps.add(
                        ExecutionStep(
                            id = stepId++.toString(),
                            description = "向$direction 滑动",
                            action = ActionType.SWIPE,
                            value = direction,
                            waitAfter = 500
                        )
                    )
                }
                
                if (userRequest.contains("输入")) {
                    val text = extractInputText(userRequest)
                    steps.add(
                        ExecutionStep(
                            id = stepId++.toString(),
                            description = "输入文本",
                            action = ActionType.INPUT_TEXT,
                            value = text,
                            waitAfter = 500
                        )
                    )
                }
            }
            
            IntentClassifier.UserIntent.SYSTEM_CONTROL -> {
                // 系统控制相关步骤
                when {
                    userRequest.contains("音量") -> {
                        steps.add(
                            ExecutionStep(
                                id = stepId++.toString(),
                                description = "调节音量",
                                action = ActionType.SYSTEM_ACTION,
                                target = "volume",
                                value = intent.entities["direction"]?.toString() ?: "up"
                            )
                        )
                    }
                    userRequest.contains("亮度") -> {
                        steps.add(
                            ExecutionStep(
                                id = stepId++.toString(),
                                description = "调节亮度",
                                action = ActionType.SYSTEM_ACTION,
                                target = "brightness",
                                value = intent.entities["value"]?.toString()
                            )
                        )
                    }
                    userRequest.contains("WiFi") -> {
                        steps.add(
                            ExecutionStep(
                                id = stepId++.toString(),
                                description = "切换WiFi",
                                action = ActionType.SYSTEM_ACTION,
                                target = "wifi_toggle"
                            )
                        )
                    }
                }
            }
            
            else -> {
                // 默认步骤
                LogManager.w(TAG, "无法为意图 ${intent.intent} 生成步骤")
            }
        }
        
        // 如果没有生成任何步骤，添加一个等待步骤
        if (steps.isEmpty()) {
            steps.add(
                ExecutionStep(
                    id = "1",
                    description = "等待进一步指令",
                    action = ActionType.WAIT,
                    waitAfter = 1000
                )
            )
        }
        
        return steps
    }
    
    /**
     * 评估任务风险级别
     */
    private fun assessRisk(userRequest: String, steps: List<ExecutionStep>): RiskLevel {
        // 高风险关键词
        val highRiskKeywords = listOf("支付", "转账", "密码", "删除", "卸载", "清空", "格式化")
        val mediumRiskKeywords = listOf("发送", "分享", "授权", "允许", "安装")
        
        // 检查用户请求
        for (keyword in highRiskKeywords) {
            if (userRequest.contains(keyword)) {
                return RiskLevel.HIGH
            }
        }
        
        for (keyword in mediumRiskKeywords) {
            if (userRequest.contains(keyword)) {
                return RiskLevel.MEDIUM
            }
        }
        
        // 检查步骤中的风险操作
        val hasInputText = steps.any { it.action == ActionType.INPUT_TEXT }
        val hasSystemAction = steps.any { it.action == ActionType.SYSTEM_ACTION }
        
        return when {
            steps.any { it.requiresConfirmation } -> RiskLevel.HIGH
            hasInputText && hasSystemAction -> RiskLevel.MEDIUM
            hasSystemAction -> RiskLevel.LOW
            else -> RiskLevel.SAFE
        }
    }
    
    /**
     * 生成回退策略
     */
    private fun generateFallbackStrategies(
        steps: List<ExecutionStep>,
        intent: IntentClassifier.IntentResult
    ): Map<String, FallbackStrategy> {
        val strategies = mutableMapOf<String, FallbackStrategy>()
        
        // 通用回退策略
        strategies["timeout"] = FallbackStrategy(
            trigger = "execution_timeout",
            action = "retry_from_beginning",
            maxRetries = 2
        )
        
        strategies["element_not_found"] = FallbackStrategy(
            trigger = "element_not_found",
            action = "wait_and_retry",
            maxRetries = 3
        )
        
        // 应用特定策略
        if (steps.any { it.action == ActionType.LAUNCH_APP }) {
            strategies["app_not_responding"] = FallbackStrategy(
                trigger = "app_not_responding",
                action = "force_stop_and_restart",
                maxRetries = 1
            )
        }
        
        if (steps.any { it.action == ActionType.INPUT_TEXT }) {
            strategies["input_failed"] = FallbackStrategy(
                trigger = "text_input_failed",
                action = "clear_and_retry",
                maxRetries = 2
            )
        }
        
        return strategies
    }
    
    /**
     * 计算预计执行时间
     */
    private fun calculateDuration(steps: List<ExecutionStep>): Long {
        return steps.sumOf { step ->
            val actionTime = when (step.action) {
                ActionType.LAUNCH_APP -> 3000L
                ActionType.CLICK -> 500L
                ActionType.LONG_CLICK -> 1000L
                ActionType.SWIPE -> 800L
                ActionType.INPUT_TEXT -> 2000L
                ActionType.SCROLL -> 600L
                ActionType.BACK -> 300L
                ActionType.HOME -> 300L
                ActionType.RECENT_APPS -> 500L
                ActionType.WAIT -> step.waitAfter
                ActionType.CHECK_STATE -> 200L
                ActionType.TAKE_SCREENSHOT -> 1000L
                ActionType.SYSTEM_ACTION -> 500L
            }
            actionTime + step.waitAfter
        }
    }
    
    /**
     * 获取应用包名
     */
    private fun getPackageName(appName: String): String {
        return when (appName) {
            "微信" -> "com.tencent.mm"
            "QQ" -> "com.tencent.mobileqq"
            "支付宝" -> "com.eg.android.AlipayGphone"
            "淘宝" -> "com.taobao.taobao"
            "抖音" -> "com.ss.android.ugc.aweme"
            "B站", "哔哩哔哩" -> "tv.danmaku.bili"
            "知乎" -> "com.zhihu.android"
            "网易云" -> "com.netease.cloudmusic"
            "微博" -> "com.sina.weibo"
            "美团" -> "com.sankuai.meituan"
            "京东" -> "com.jingdong.app.mall"
            else -> ""
        }
    }
    
    /**
     * 提取点击目标
     */
    private fun extractClickTarget(request: String): String {
        val pattern = "点击(.+?)(?:按钮|选项|链接|图标)?$".toRegex()
        return pattern.find(request)?.groupValues?.get(1) ?: "目标元素"
    }
    
    /**
     * 提取滑动方向
     */
    private fun extractScrollDirection(request: String): String {
        return when {
            request.contains("上") -> "up"
            request.contains("下") -> "down"
            request.contains("左") -> "left"
            request.contains("右") -> "right"
            else -> "down"
        }
    }
    
    /**
     * 提取输入文本
     */
    private fun extractInputText(request: String): String {
        val pattern = "输入(.+)$".toRegex()
        return pattern.find(request)?.groupValues?.get(1) ?: ""
    }
    
    // ==================== 🔧 增强功能：任务执行优化 ====================
    
    /**
     * 🔄 任务执行状态
     */
    enum class TaskStatus {
        PENDING,        // 等待执行
        RUNNING,        // 执行中
        PAUSED,         // 已暂停
        COMPLETED,      // 已完成
        FAILED,         // 失败
        CANCELLED,      // 已取消
        ROLLBACK        // 回滚中
    }
    
    /**
     * 📊 任务执行结果
     */
    data class StepResult(
        val stepId: String,
        val success: Boolean,
        val duration: Long,
        val errorMessage: String? = null,
        val retryCount: Int = 0,
        val screenshotPath: String? = null
    )
    
    /**
     * 🎯 任务执行上下文
     */
    data class TaskExecutionContext(
        val plan: TaskPlan,
        var currentStepIndex: Int = 0,
        var status: TaskStatus = TaskStatus.PENDING,
        val stepResults: MutableList<StepResult> = mutableListOf(),
        var startTime: Long = 0,
        var endTime: Long = 0,
        val rollbackStack: MutableList<RollbackAction> = mutableListOf()
    )
    
    /**
     * ↩️ 回滚动作
     */
    data class RollbackAction(
        val stepId: String,
        val action: ActionType,
        val description: String,
        val params: Map<String, Any> = emptyMap()
    )
    
    /**
     * 🚀 创建任务执行上下文
     */
    fun createExecutionContext(plan: TaskPlan): TaskExecutionContext {
        return TaskExecutionContext(
            plan = plan,
            startTime = System.currentTimeMillis()
        )
    }
    
    /**
     * 📝 获取当前步骤
     */
    fun getCurrentStep(context: TaskExecutionContext): ExecutionStep? {
        if (context.currentStepIndex >= context.plan.steps.size) {
            return null
        }
        return context.plan.steps[context.currentStepIndex]
    }
    
    /**
     * ➡️ 移动到下一步
     */
    fun moveToNextStep(context: TaskExecutionContext): Boolean {
        if (context.currentStepIndex < context.plan.steps.size - 1) {
            context.currentStepIndex++
            return true
        }
        return false
    }
    
    /**
     * 📊 记录步骤结果
     */
    fun recordStepResult(
        context: TaskExecutionContext,
        stepId: String,
        success: Boolean,
        duration: Long,
        errorMessage: String? = null,
        retryCount: Int = 0
    ) {
        context.stepResults.add(
            StepResult(
                stepId = stepId,
                success = success,
                duration = duration,
                errorMessage = errorMessage,
                retryCount = retryCount
            )
        )
        
        LogManager.d(TAG, "📊 步骤结果: stepId=$stepId, success=$success, retryCount=$retryCount")
    }
    
    /**
     * ↩️ 添加回滚动作
     */
    fun addRollbackAction(context: TaskExecutionContext, action: RollbackAction) {
        context.rollbackStack.add(action)
        LogManager.d(TAG, "↩️ 添加回滚动作: ${action.description}")
    }
    
    /**
     * 🔙 生成步骤的回滚动作
     */
    fun generateRollbackAction(step: ExecutionStep): RollbackAction? {
        return when (step.action) {
            ActionType.LAUNCH_APP -> {
                // 启动应用的回滚：返回主页
                RollbackAction(
                    stepId = step.id,
                    action = ActionType.HOME,
                    description = "返回主页（回滚启动应用）"
                )
            }
            ActionType.INPUT_TEXT -> {
                // 输入文本的回滚：清空输入框
                RollbackAction(
                    stepId = step.id,
                    action = ActionType.INPUT_TEXT,
                    description = "清空输入框（回滚输入）",
                    params = mapOf("clear" to true, "target" to (step.target ?: ""))
                )
            }
            ActionType.CLICK -> {
                // 点击的回滚：返回
                RollbackAction(
                    stepId = step.id,
                    action = ActionType.BACK,
                    description = "返回上一页（回滚点击）"
                )
            }
            else -> null
        }
    }
    
    /**
     * 🔄 执行回滚
     */
    suspend fun executeRollback(context: TaskExecutionContext): Boolean {
        LogManager.i(TAG, "🔄 开始执行回滚，共${context.rollbackStack.size}个动作")
        context.status = TaskStatus.ROLLBACK
        
        var success = true
        while (context.rollbackStack.isNotEmpty()) {
            val rollbackAction = context.rollbackStack.removeAt(context.rollbackStack.lastIndex)
            LogManager.d(TAG, "↩️ 执行回滚: ${rollbackAction.description}")
            
            // 这里需要实际执行回滚动作
            // 由于没有直接访问AccessibilityService，返回true表示需要外部执行
            delay(300)
        }
        
        return success
    }
    
    /**
     * ⏸️ 暂停任务
     */
    fun pauseTask(context: TaskExecutionContext) {
        if (context.status == TaskStatus.RUNNING) {
            context.status = TaskStatus.PAUSED
            LogManager.d(TAG, "⏸️ 任务已暂停")
        }
    }
    
    /**
     * ▶️ 恢复任务
     */
    fun resumeTask(context: TaskExecutionContext) {
        if (context.status == TaskStatus.PAUSED) {
            context.status = TaskStatus.RUNNING
            LogManager.d(TAG, "▶️ 任务已恢复")
        }
    }
    
    /**
     * ❌ 取消任务
     */
    fun cancelTask(context: TaskExecutionContext) {
        context.status = TaskStatus.CANCELLED
        context.endTime = System.currentTimeMillis()
        LogManager.d(TAG, "❌ 任务已取消")
    }
    
    /**
     * ✅ 完成任务
     */
    fun completeTask(context: TaskExecutionContext, success: Boolean) {
        context.status = if (success) TaskStatus.COMPLETED else TaskStatus.FAILED
        context.endTime = System.currentTimeMillis()
        LogManager.d(TAG, "✅ 任务完成: success=$success, 耗时=${context.endTime - context.startTime}ms")
    }
    
    /**
     * 📊 获取任务执行报告
     */
    fun getExecutionReport(context: TaskExecutionContext): Map<String, Any> {
        val totalDuration = if (context.endTime > 0) {
            context.endTime - context.startTime
        } else {
            System.currentTimeMillis() - context.startTime
        }
        
        val successSteps = context.stepResults.count { it.success }
        val failedSteps = context.stepResults.count { !it.success }
        val totalRetries = context.stepResults.sumOf { it.retryCount }
        
        return mapOf(
            "taskId" to context.plan.taskId,
            "status" to context.status.name,
            "totalSteps" to context.plan.steps.size,
            "completedSteps" to context.currentStepIndex,
            "successSteps" to successSteps,
            "failedSteps" to failedSteps,
            "totalRetries" to totalRetries,
            "totalDuration" to totalDuration,
            "riskLevel" to context.plan.riskLevel.name,
            "errors" to context.stepResults.filter { !it.success }.mapNotNull { it.errorMessage }
        )
    }
    
    /**
     * 🔍 检查步骤是否需要等待
     */
    fun shouldWaitBeforeStep(step: ExecutionStep, previousStep: ExecutionStep?): Long {
        // 启动应用后需要更长等待时间
        if (previousStep?.action == ActionType.LAUNCH_APP) {
            return maxOf(step.waitAfter, 2000L)
        }
        
        // 输入后点击发送需要短暂等待
        if (previousStep?.action == ActionType.INPUT_TEXT && step.action == ActionType.CLICK) {
            return maxOf(step.waitAfter, 500L)
        }
        
        return step.waitAfter
    }
    
    /**
     * 🎯 智能重试策略
     */
    fun getRetryStrategy(step: ExecutionStep, attemptCount: Int): RetryStrategy {
        return when {
            attemptCount >= step.retryCount -> RetryStrategy.GIVE_UP
            step.action == ActionType.CLICK -> RetryStrategy.WAIT_AND_RETRY
            step.action == ActionType.INPUT_TEXT -> RetryStrategy.CLEAR_AND_RETRY
            step.action == ActionType.LAUNCH_APP -> RetryStrategy.FORCE_STOP_AND_RETRY
            else -> RetryStrategy.SIMPLE_RETRY
        }
    }
    
    /**
     * 重试策略
     */
    enum class RetryStrategy {
        SIMPLE_RETRY,           // 简单重试
        WAIT_AND_RETRY,         // 等待后重试
        CLEAR_AND_RETRY,        // 清空后重试
        FORCE_STOP_AND_RETRY,   // 强制停止后重试
        USE_FALLBACK,           // 使用备选方案
        GIVE_UP                 // 放弃
    }
    
    /**
     * ⏱️ 获取重试等待时间
     */
    fun getRetryDelay(strategy: RetryStrategy, attemptCount: Int): Long {
        val baseDelay = when (strategy) {
            RetryStrategy.SIMPLE_RETRY -> 500L
            RetryStrategy.WAIT_AND_RETRY -> 1000L
            RetryStrategy.CLEAR_AND_RETRY -> 500L
            RetryStrategy.FORCE_STOP_AND_RETRY -> 2000L
            RetryStrategy.USE_FALLBACK -> 1000L
            RetryStrategy.GIVE_UP -> 0L
        }
        
        // 指数退避
        return baseDelay * (attemptCount + 1)
    }
}
