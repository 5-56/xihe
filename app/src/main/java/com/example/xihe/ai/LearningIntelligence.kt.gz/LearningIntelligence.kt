package com.example.xihe.ai

import com.example.xihe.utils.LogManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ConcurrentHashMap

/**
 * 学习智能模块
 * 
 * 实现用户行为学习和任务执行学习能力
 * - 用户操作模式学习
 * - 用户偏好学习
 * - 用户习惯学习
 * - 用户反馈学习
 * - 成功模式学习
 * - 失败模式学习
 * - 优化策略学习
 * - 自适应调整
 */
object LearningIntelligence {
    
    private const val TAG = "LearningIntelligence"
    
    // ==================== 学习数据存储 ====================
    
    // 用户操作模式
    private val operationPatterns = ConcurrentHashMap<String, OperationPattern>()
    
    // 用户偏好
    private val userPreferences = ConcurrentHashMap<String, UserPreferenceData>()
    
    // 用户习惯
    private val userHabits = ConcurrentHashMap<String, UserHabit>()
    
    // 用户反馈记录
    private val feedbackRecords = mutableListOf<FeedbackRecord>()
    
    // 成功执行模式
    private val successPatterns = ConcurrentHashMap<String, SuccessPattern>()
    
    // 失败执行模式
    private val failurePatterns = ConcurrentHashMap<String, FailurePattern>()
    
    // 优化策略
    private val optimizationStrategies = ConcurrentHashMap<String, OptimizationStrategy>()
    
    // 学习状态
    private val _learningState = MutableStateFlow(LearningState())
    val learningState: StateFlow<LearningState> = _learningState.asStateFlow()
    
    // 学习配置
    private const val MIN_PATTERN_OCCURRENCES = 3
    private const val PATTERN_CONFIDENCE_THRESHOLD = 0.6f
    private const val MAX_PATTERNS_PER_CATEGORY = 100
    private const val HABIT_FORMATION_DAYS = 7
    
    // ==================== 用户操作模式学习 ====================
    
    /**
     * 学习用户操作模式
     */
    fun learnOperationPattern(
        operation: UserOperation,
        context: OperationContext
    ): LearnedUserPattern? {
        LogManager.d(TAG, " 学习操作模式: ${operation.action}")
        
        val patternKey = generatePatternKey(operation, context)
        
        val existingPattern = operationPatterns[patternKey]
        
        if (existingPattern != null) {
            // 更新现有模式
            val updatedPattern = existingPattern.copy(
                occurrences = existingPattern.occurrences + 1,
                lastOccurrence = System.currentTimeMillis(),
                avgDuration = (existingPattern.avgDuration * existingPattern.occurrences + operation.duration) / 
                             (existingPattern.occurrences + 1),
                contexts = (existingPattern.contexts + context).takeLast(20)
            )
            operationPatterns[patternKey] = updatedPattern
            
            // 如果达到阈值，返回学习到的模式
            if (updatedPattern.occurrences >= MIN_PATTERN_OCCURRENCES) {
                return LearnedUserPattern(
                    patternId = patternKey,
                    type = UserPatternType.OPERATION,
                    description = "用户经常${describeOperation(operation)}",
                    confidence = calculatePatternConfidence(updatedPattern),
                    recommendation = generateRecommendation(updatedPattern)
                )
            }
        } else {
            // 创建新模式
            operationPatterns[patternKey] = OperationPattern(
                id = patternKey,
                action = operation.action,
                targetType = operation.targetType,
                appPackage = operation.appPackage,
                occurrences = 1,
                firstOccurrence = System.currentTimeMillis(),
                lastOccurrence = System.currentTimeMillis(),
                avgDuration = operation.duration,
                contexts = listOf(context)
            )
        }
        
        // 清理过多的模式
        prunePatterns()
        
        return null
    }
    
    /**
     * 识别当前操作模式
     */
    fun recognizeOperationPattern(
        currentOperation: UserOperation,
        context: OperationContext
    ): List<MatchedPattern> {
        LogManager.d(TAG, " 识别操作模式: ${currentOperation.action}")
        
        val matches = mutableListOf<MatchedPattern>()
        
        operationPatterns.values.forEach { pattern ->
            val similarity = calculatePatternSimilarity(currentOperation, context, pattern)
            if (similarity >= PATTERN_CONFIDENCE_THRESHOLD) {
                matches.add(MatchedPattern(
                    pattern = pattern,
                    similarity = similarity,
                    predictedNextActions = predictNextActions(pattern, context)
                ))
            }
        }
        
        return matches.sortedByDescending { it.similarity }
    }
    
    private fun generatePatternKey(operation: UserOperation, context: OperationContext): String {
        return "${operation.action}_${operation.targetType}_${context.timeSlot}_${operation.appPackage ?: "any"}"
    }
    
    private fun calculatePatternConfidence(pattern: OperationPattern): Float {
        val occurrenceFactor = (pattern.occurrences.toFloat() / 10f).coerceAtMost(1f)
        val recencyFactor = calculateRecencyFactor(pattern.lastOccurrence)
        val consistencyFactor = calculateConsistencyFactor(pattern.contexts)
        
        return (occurrenceFactor * 0.4f + recencyFactor * 0.3f + consistencyFactor * 0.3f)
    }
    
    private fun calculateRecencyFactor(lastOccurrence: Long): Float {
        val daysSince = (System.currentTimeMillis() - lastOccurrence) / (24 * 60 * 60 * 1000f)
        return (1f - daysSince / 30f).coerceIn(0f, 1f)
    }
    
    private fun calculateConsistencyFactor(contexts: List<OperationContext>): Float {
        if (contexts.size < 2) return 0.5f
        
        val timeSlots = contexts.map { it.timeSlot }
        val mostCommonSlot = timeSlots.groupBy { it }.maxByOrNull { it.value.size }
        val consistency = (mostCommonSlot?.value?.size ?: 0).toFloat() / contexts.size
        
        return consistency
    }
    
    private fun calculatePatternSimilarity(
        operation: UserOperation,
        context: OperationContext,
        pattern: OperationPattern
    ): Float {
        var similarity = 0f
        
        // 动作匹配
        if (operation.action == pattern.action) similarity += 0.4f
        
        // 目标类型匹配
        if (operation.targetType == pattern.targetType) similarity += 0.2f
        
        // 应用匹配
        if (operation.appPackage == pattern.appPackage) similarity += 0.2f
        
        // 时间段匹配
        val timeMatches = pattern.contexts.count { it.timeSlot == context.timeSlot }
        similarity += 0.2f * (timeMatches.toFloat() / pattern.contexts.size.coerceAtLeast(1))
        
        return similarity
    }
    
    private fun predictNextActions(pattern: OperationPattern, context: OperationContext): List<String> {
        val predictions = mutableListOf<String>()
        
        // 基于历史上下文预测
        val similarContexts = pattern.contexts.filter { it.timeSlot == context.timeSlot }
        similarContexts.flatMap { it.followUpActions }.groupBy { it }
            .mapValues { it.value.size }
            .toList()
            .sortedByDescending { it.second }
            .take(3)
            .forEach { predictions.add(it.first) }
        
        return predictions
    }
    
    private fun describeOperation(operation: UserOperation): String {
        return when (operation.action) {
            OperationAction.CLICK -> "点击${operation.targetType.description}"
            OperationAction.SCROLL -> "滑动浏览"
            OperationAction.INPUT -> "输入文字"
            OperationAction.LONG_PRESS -> "长按${operation.targetType.description}"
            OperationAction.SWIPE -> "滑动切换"
            OperationAction.BACK -> "返回"
            OperationAction.HOME -> "回到主页"
        }
    }
    
    private fun generateRecommendation(pattern: OperationPattern): String {
        return "检测到您经常在${pattern.contexts.lastOrNull()?.timeSlot?.description ?: ""}进行此操作，是否需要快捷方式？"
    }
    
    // ==================== 用户偏好学习 ====================
    
    /**
     * 学习用户偏好
     */
    fun learnUserPreference(
        category: PreferenceCategory,
        choice: String,
        context: PreferenceContext
    ) {
        LogManager.d(TAG, " 学习用户偏好: $category -> $choice")
        
        val key = "${category}_$choice"
        val existing = userPreferences[key]
        
        if (existing != null) {
            userPreferences[key] = existing.copy(
                count = existing.count + 1,
                lastSelected = System.currentTimeMillis(),
                contexts = (existing.contexts + context).takeLast(50)
            )
        } else {
            userPreferences[key] = UserPreferenceData(
                category = category,
                value = choice,
                count = 1,
                firstSelected = System.currentTimeMillis(),
                lastSelected = System.currentTimeMillis(),
                contexts = listOf(context)
            )
        }
        
        updateLearningState()
    }
    
    /**
     * 获取用户偏好
     */
    fun getUserPreference(
        category: PreferenceCategory,
        context: PreferenceContext? = null
    ): UserPreferenceResult {
        LogManager.d(TAG, " 获取用户偏好: $category")
        
        val categoryPreferences = userPreferences.values
            .filter { it.category == category }
            .sortedByDescending { it.count }
        
        if (categoryPreferences.isEmpty()) {
            return UserPreferenceResult(
                hasPreference = false,
                preferredValue = null,
                confidence = 0f,
                alternatives = emptyList()
            )
        }
        
        val topPreference = categoryPreferences.first()
        val totalCount = categoryPreferences.sumOf { it.count }
        
        // 如果有上下文，查找上下文相关偏好
        val contextualPreference = if (context != null) {
            categoryPreferences.maxByOrNull { pref ->
                pref.contexts.count { ctx -> 
                    ctx.timeSlot == context.timeSlot || ctx.situation == context.situation
                }
            }
        } else topPreference
        
        return UserPreferenceResult(
            hasPreference = true,
            preferredValue = contextualPreference?.value,
            confidence = topPreference.count.toFloat() / totalCount,
            alternatives = categoryPreferences.drop(1).take(3).map { it.value }
        )
    }
    
    /**
     * 分析用户偏好趋势
     */
    fun analyzePreferenceTrends(): List<PreferenceTrend> {
        val trends = mutableListOf<PreferenceTrend>()
        
        PreferenceCategory.values().forEach { category ->
            val categoryData = userPreferences.values.filter { it.category == category }
            if (categoryData.size >= 2) {
                val sorted = categoryData.sortedByDescending { it.lastSelected }
                val recent = sorted.take(3)
                val older = sorted.drop(3).take(3)
                
                if (recent.isNotEmpty() && older.isNotEmpty()) {
                    val recentTop = recent.maxByOrNull { it.count }?.value
                    val olderTop = older.maxByOrNull { it.count }?.value
                    
                    if (recentTop != olderTop && recentTop != null) {
                        trends.add(PreferenceTrend(
                            category = category,
                            fromValue = olderTop,
                            toValue = recentTop,
                            confidence = 0.7f,
                            description = "您最近偏好${category.description}从${olderTop ?: "未知"}转向$recentTop"
                        ))
                    }
                }
            }
        }
        
        return trends
    }
    
    // ==================== 用户习惯学习 ====================
    
    /**
     * 学习用户习惯
     */
    fun learnUserHabit(
        habitType: HabitType,
        behavior: String,
        timestamp: Long = System.currentTimeMillis()
    ) {
        LogManager.d(TAG, " 学习用户习惯: $habitType -> $behavior")
        
        val key = "${habitType}_$behavior"
        val existing = userHabits[key]
        
        val timeSlot = getTimeSlot(timestamp)
        val dayOfWeek = getDayOfWeek(timestamp)
        
        if (existing != null) {
            val updatedOccurrences = existing.occurrences.toMutableMap()
            updatedOccurrences[timeSlot] = (updatedOccurrences[timeSlot] ?: 0) + 1
            
            val updatedDays = existing.daysOfWeek.toMutableMap()
            updatedDays[dayOfWeek] = (updatedDays[dayOfWeek] ?: 0) + 1
            
            userHabits[key] = existing.copy(
                totalCount = existing.totalCount + 1,
                occurrences = updatedOccurrences,
                daysOfWeek = updatedDays,
                lastOccurrence = timestamp,
                consecutiveDays = calculateConsecutiveDays(existing, timestamp)
            )
        } else {
            userHabits[key] = UserHabit(
                type = habitType,
                behavior = behavior,
                totalCount = 1,
                occurrences = mapOf(timeSlot to 1),
                daysOfWeek = mapOf(dayOfWeek to 1),
                firstOccurrence = timestamp,
                lastOccurrence = timestamp,
                consecutiveDays = 1
            )
        }
    }
    
    /**
     * 预测用户习惯
     */
    fun predictUserHabits(
        currentTime: Long = System.currentTimeMillis()
    ): List<HabitPrediction> {
        LogManager.d(TAG, " 预测用户习惯")
        
        val predictions = mutableListOf<HabitPrediction>()
        val timeSlot = getTimeSlot(currentTime)
        val dayOfWeek = getDayOfWeek(currentTime)
        
        userHabits.values.forEach { habit ->
            val timeScore = habit.occurrences[timeSlot]?.toFloat()?.div(habit.totalCount) ?: 0f
            val dayScore = habit.daysOfWeek[dayOfWeek]?.toFloat()?.div(habit.totalCount) ?: 0f
            val habitStrength = calculateHabitStrength(habit)
            
            val probability = (timeScore * 0.4f + dayScore * 0.3f + habitStrength * 0.3f)
            
            if (probability >= 0.3f) {
                predictions.add(HabitPrediction(
                    habit = habit,
                    probability = probability,
                    suggestedAction = generateHabitSuggestion(habit),
                    timing = estimateHabitTiming(habit, timeSlot)
                ))
            }
        }
        
        return predictions.sortedByDescending { it.probability }
    }
    
    /**
     * 检查习惯是否形成
     */
    fun isHabitFormed(habitType: HabitType, behavior: String): Boolean {
        val key = "${habitType}_$behavior"
        val habit = userHabits[key] ?: return false
        
        return habit.consecutiveDays >= HABIT_FORMATION_DAYS && habit.totalCount >= 10
    }
    
    private fun calculateConsecutiveDays(habit: UserHabit, newTimestamp: Long): Int {
        val dayDiff = (newTimestamp - habit.lastOccurrence) / (24 * 60 * 60 * 1000)
        return if (dayDiff <= 1) habit.consecutiveDays + 1 else 1
    }
    
    private fun calculateHabitStrength(habit: UserHabit): Float {
        val frequencyScore = (habit.totalCount.toFloat() / 30f).coerceAtMost(1f)
        val consistencyScore = (habit.consecutiveDays.toFloat() / HABIT_FORMATION_DAYS).coerceAtMost(1f)
        return (frequencyScore + consistencyScore) / 2
    }
    
    private fun generateHabitSuggestion(habit: UserHabit): String {
        return when (habit.type) {
            HabitType.APP_USAGE -> "现在是您通常使用${habit.behavior}的时间"
            HabitType.TASK_EXECUTION -> "您通常会在这个时间${habit.behavior}"
            HabitType.COMMUNICATION -> "您通常会在这个时间联系${habit.behavior}"
            HabitType.CONTENT_CONSUMPTION -> "您通常会在这个时间浏览${habit.behavior}"
            HabitType.ROUTINE -> "提醒：${habit.behavior}"
        }
    }
    
    private fun estimateHabitTiming(habit: UserHabit, currentSlot: TimeSlot): HabitTiming {
        val peakSlot = habit.occurrences.maxByOrNull { it.value }?.key ?: currentSlot
        return if (peakSlot == currentSlot) {
            HabitTiming.NOW
        } else if (peakSlot.ordinal > currentSlot.ordinal) {
            HabitTiming.LATER_TODAY
        } else {
            HabitTiming.PASSED
        }
    }
    
    // ==================== 用户反馈学习 ====================
    
    /**
     * 记录用户反馈
     */
    fun recordUserFeedback(feedback: UserFeedback) {
        LogManager.d(TAG, " 记录用户反馈: ${feedback.type} - ${feedback.sentiment}")
        
        val record = FeedbackRecord(
            id = generateFeedbackId(),
            feedback = feedback,
            timestamp = System.currentTimeMillis(),
            processed = false
        )
        
        feedbackRecords.add(record)
        
        // 实时学习
        processFeedbackImmediate(feedback)
        
        // 保持记录数量
        if (feedbackRecords.size > 500) {
            feedbackRecords.removeAll(feedbackRecords.take(100))
        }
    }
    
    /**
     * 分析反馈趋势
     */
    fun analyzeFeedbackTrends(): FeedbackAnalysis {
        val recentFeedback = feedbackRecords.filter { 
            System.currentTimeMillis() - it.timestamp < 7 * 24 * 60 * 60 * 1000 // 最近7天
        }
        
        if (recentFeedback.isEmpty()) {
            return FeedbackAnalysis(
                overallSentiment = FeedbackSentiment.NEUTRAL,
                satisfactionScore = 0.5f,
                commonIssues = emptyList(),
                improvements = emptyList()
            )
        }
        
        val sentimentCounts = recentFeedback.groupBy { it.feedback.sentiment }
        val positiveCounts = sentimentCounts[FeedbackSentiment.POSITIVE]?.size ?: 0
        val negativeCounts = sentimentCounts[FeedbackSentiment.NEGATIVE]?.size ?: 0
        val totalCount = recentFeedback.size
        
        val satisfactionScore = (positiveCounts.toFloat() + 0.5f * (totalCount - positiveCounts - negativeCounts)) / totalCount
        
        val overallSentiment = when {
            satisfactionScore >= 0.7f -> FeedbackSentiment.POSITIVE
            satisfactionScore <= 0.3f -> FeedbackSentiment.NEGATIVE
            else -> FeedbackSentiment.NEUTRAL
        }
        
        // 识别常见问题
        val issues = recentFeedback
            .filter { it.feedback.sentiment == FeedbackSentiment.NEGATIVE }
            .flatMap { it.feedback.tags }
            .groupBy { it }
            .mapValues { it.value.size }
            .toList()
            .sortedByDescending { it.second }
            .take(5)
            .map { CommonIssue(it.first, it.second, generateIssueSolution(it.first)) }
        
        // 生成改进建议
        val improvements = generateImprovements(recentFeedback)
        
        return FeedbackAnalysis(
            overallSentiment = overallSentiment,
            satisfactionScore = satisfactionScore,
            commonIssues = issues,
            improvements = improvements
        )
    }
    
    private fun processFeedbackImmediate(feedback: UserFeedback) {
        when (feedback.type) {
            FeedbackType.ACTION_RESULT -> {
                if (feedback.sentiment == FeedbackSentiment.NEGATIVE) {
                    // 学习失败模式
                    feedback.relatedTask?.let { task ->
                        recordFailurePattern(task, feedback.detail ?: "用户不满意结果")
                    }
                } else if (feedback.sentiment == FeedbackSentiment.POSITIVE) {
                    // 学习成功模式
                    feedback.relatedTask?.let { task ->
                        recordSuccessPattern(task, "用户满意结果")
                    }
                }
            }
            FeedbackType.PREFERENCE -> {
                feedback.detail?.let { detail ->
                    val parts = detail.split(":")
                    if (parts.size == 2) {
                        val category = PreferenceCategory.values().find { it.name == parts[0] }
                        category?.let {
                            learnUserPreference(it, parts[1], PreferenceContext(
                                timeSlot = getTimeSlot(System.currentTimeMillis()),
                                situation = "feedback"
                            ))
                        }
                    }
                }
            }
            FeedbackType.CORRECTION -> {
                // 记录纠正，用于优化策略
                feedback.detail?.let { detail ->
                    learnCorrection(feedback.relatedTask ?: "", detail)
                }
            }
            else -> {}
        }
    }
    
    private fun generateFeedbackId(): String {
        return "fb_${System.currentTimeMillis()}_${(Math.random() * 1000).toInt()}"
    }
    
    private fun generateIssueSolution(issue: String): String {
        return when {
            issue.contains("慢") -> "优化执行速度"
            issue.contains("错误") -> "增强错误处理"
            issue.contains("理解") -> "改进意图理解"
            else -> "持续优化"
        }
    }
    
    private fun generateImprovements(feedbacks: List<FeedbackRecord>): List<ImprovementSuggestion> {
        val suggestions = mutableListOf<ImprovementSuggestion>()
        
        val negativeByType = feedbacks
            .filter { it.feedback.sentiment == FeedbackSentiment.NEGATIVE }
            .groupBy { it.feedback.type }
        
        negativeByType.forEach { (type, records) ->
            if (records.size >= 3) {
                suggestions.add(ImprovementSuggestion(
                    area = type.name,
                    priority = if (records.size >= 5) Priority.HIGH else Priority.MEDIUM,
                    description = "改进${type.description}相关功能",
                    expectedImpact = "提升用户满意度${records.size * 5}%"
                ))
            }
        }
        
        return suggestions.sortedByDescending { it.priority.ordinal }
    }
    
    private fun learnCorrection(task: String, correction: String) {
        val strategyKey = "correction_${task.hashCode()}"
        val existing = optimizationStrategies[strategyKey]
        
        if (existing != null) {
            optimizationStrategies[strategyKey] = existing.copy(
                corrections = existing.corrections + correction,
                lastUpdated = System.currentTimeMillis()
            )
        } else {
            optimizationStrategies[strategyKey] = OptimizationStrategy(
                id = strategyKey,
                type = StrategyType.CORRECTION_BASED,
                targetTask = task,
                corrections = listOf(correction),
                improvements = emptyList(),
                effectiveness = 0f,
                lastUpdated = System.currentTimeMillis()
            )
        }
    }
    
    // ==================== 成功模式学习 ====================
    
    /**
     * 记录成功执行模式
     */
    fun recordSuccessPattern(
        taskExecution: TaskExecutionRecord
    ) {
        LogManager.d(TAG, " 记录成功模式: ${taskExecution.taskType}")
        
        val patternKey = generateTaskPatternKey(taskExecution)
        val existing = successPatterns[patternKey]
        
        if (existing != null) {
            val updatedSteps = mergeExecutionSteps(existing.commonSteps, taskExecution.steps)
            successPatterns[patternKey] = existing.copy(
                successCount = existing.successCount + 1,
                avgDuration = (existing.avgDuration * existing.successCount + taskExecution.duration) / 
                             (existing.successCount + 1),
                commonSteps = updatedSteps,
                lastSuccess = System.currentTimeMillis()
            )
        } else {
            successPatterns[patternKey] = SuccessPattern(
                id = patternKey,
                taskType = taskExecution.taskType,
                conditions = taskExecution.conditions,
                commonSteps = taskExecution.steps,
                successCount = 1,
                avgDuration = taskExecution.duration,
                firstSuccess = System.currentTimeMillis(),
                lastSuccess = System.currentTimeMillis()
            )
        }
    }
    
    private fun recordSuccessPattern(task: String, reason: String) {
        val patternKey = "success_${task.hashCode()}"
        val existing = successPatterns[patternKey]
        
        if (existing != null) {
            successPatterns[patternKey] = existing.copy(
                successCount = existing.successCount + 1,
                lastSuccess = System.currentTimeMillis()
            )
        } else {
            successPatterns[patternKey] = SuccessPattern(
                id = patternKey,
                taskType = task,
                conditions = mapOf("reason" to reason),
                commonSteps = emptyList(),
                successCount = 1,
                avgDuration = 0L,
                firstSuccess = System.currentTimeMillis(),
                lastSuccess = System.currentTimeMillis()
            )
        }
    }
    
    /**
     * 查找成功模式
     */
    fun findSuccessPattern(taskType: String, conditions: Map<String, String>): SuccessPattern? {
        return successPatterns.values
            .filter { it.taskType == taskType }
            .maxByOrNull { 
                it.successCount * calculateConditionMatch(it.conditions, conditions)
            }
    }
    
    /**
     * 获取成功率统计
     */
    fun getSuccessRateStats(taskType: String? = null): SuccessRateStats {
        val relevantSuccess = if (taskType != null) {
            successPatterns.values.filter { it.taskType == taskType }
        } else {
            successPatterns.values.toList()
        }
        
        val relevantFailure = if (taskType != null) {
            failurePatterns.values.filter { it.taskType == taskType }
        } else {
            failurePatterns.values.toList()
        }
        
        val totalSuccess = relevantSuccess.sumOf { it.successCount }
        val totalFailure = relevantFailure.sumOf { it.failureCount }
        val total = totalSuccess + totalFailure
        
        return SuccessRateStats(
            totalExecutions = total,
            successCount = totalSuccess,
            failureCount = totalFailure,
            successRate = if (total > 0) totalSuccess.toFloat() / total else 0f,
            avgSuccessDuration = relevantSuccess.map { it.avgDuration }.average().toLong(),
            mostReliablePatterns = relevantSuccess.sortedByDescending { it.successCount }.take(5)
        )
    }
    
    private fun generateTaskPatternKey(execution: TaskExecutionRecord): String {
        return "${execution.taskType}_${execution.conditions.hashCode()}"
    }
    
    private fun mergeExecutionSteps(existing: List<String>, newSteps: List<String>): List<String> {
        // 简单合并，保留两者中都有的步骤
        return existing.filter { step -> newSteps.any { it.contains(step.take(10)) } }
            .ifEmpty { newSteps }
    }
    
    private fun calculateConditionMatch(pattern: Map<String, String>, current: Map<String, String>): Float {
        if (pattern.isEmpty()) return 0.5f
        val matches = pattern.count { (k, v) -> current[k] == v }
        return matches.toFloat() / pattern.size
    }
    
    // ==================== 失败模式学习 ====================
    
    /**
     * 记录失败执行模式
     */
    fun recordFailurePattern(
        taskExecution: TaskExecutionRecord,
        failureReason: String
    ) {
        LogManager.d(TAG, " 记录失败模式: ${taskExecution.taskType} - $failureReason")
        
        val patternKey = "fail_${taskExecution.taskType}_${failureReason.hashCode()}"
        val existing = failurePatterns[patternKey]
        
        if (existing != null) {
            failurePatterns[patternKey] = existing.copy(
                failureCount = existing.failureCount + 1,
                lastFailure = System.currentTimeMillis(),
                failedSteps = mergeFailedSteps(existing.failedSteps, taskExecution.steps, taskExecution.failedAtStep)
            )
        } else {
            failurePatterns[patternKey] = FailurePattern(
                id = patternKey,
                taskType = taskExecution.taskType,
                failureReason = failureReason,
                conditions = taskExecution.conditions,
                failedSteps = if (taskExecution.failedAtStep != null) 
                    listOf(taskExecution.steps.getOrElse(taskExecution.failedAtStep) { "" }) 
                else emptyList(),
                failureCount = 1,
                firstFailure = System.currentTimeMillis(),
                lastFailure = System.currentTimeMillis(),
                recoveryAttempts = emptyList()
            )
        }
        
        // 尝试生成恢复策略
        generateRecoveryStrategy(patternKey, failureReason)
    }
    
    private fun recordFailurePattern(task: String, reason: String) {
        val patternKey = "fail_${task.hashCode()}_${reason.hashCode()}"
        val existing = failurePatterns[patternKey]
        
        if (existing != null) {
            failurePatterns[patternKey] = existing.copy(
                failureCount = existing.failureCount + 1,
                lastFailure = System.currentTimeMillis()
            )
        } else {
            failurePatterns[patternKey] = FailurePattern(
                id = patternKey,
                taskType = task,
                failureReason = reason,
                conditions = emptyMap(),
                failedSteps = emptyList(),
                failureCount = 1,
                firstFailure = System.currentTimeMillis(),
                lastFailure = System.currentTimeMillis(),
                recoveryAttempts = emptyList()
            )
        }
    }
    
    /**
     * 分析失败原因
     */
    fun analyzeFailureReasons(taskType: String? = null): List<FailureAnalysis> {
        val relevantPatterns = if (taskType != null) {
            failurePatterns.values.filter { it.taskType == taskType }
        } else {
            failurePatterns.values.toList()
        }
        
        return relevantPatterns
            .groupBy { it.failureReason }
            .map { (reason, patterns) ->
                FailureAnalysis(
                    reason = reason,
                    occurrences = patterns.sumOf { it.failureCount },
                    affectedTasks = patterns.map { it.taskType }.distinct(),
                    suggestedFix = suggestFix(reason),
                    preventionStrategy = generatePreventionStrategy(reason)
                )
            }
            .sortedByDescending { it.occurrences }
    }
    
    private fun mergeFailedSteps(existing: List<String>, steps: List<String>, failedAt: Int?): List<String> {
        return if (failedAt != null && failedAt < steps.size) {
            (existing + steps[failedAt]).distinct()
        } else existing
    }
    
    private fun generateRecoveryStrategy(patternKey: String, reason: String) {
        val strategyKey = "recovery_$patternKey"
        
        if (!optimizationStrategies.containsKey(strategyKey)) {
            optimizationStrategies[strategyKey] = OptimizationStrategy(
                id = strategyKey,
                type = StrategyType.RECOVERY,
                targetTask = patternKey,
                corrections = emptyList(),
                improvements = listOf(suggestFix(reason)),
                effectiveness = 0f,
                lastUpdated = System.currentTimeMillis()
            )
        }
    }
    
    private fun suggestFix(reason: String): String {
        return when {
            reason.contains("找不到") -> "增加元素等待时间或使用模糊匹配"
            reason.contains("超时") -> "优化执行路径或增加超时时间"
            reason.contains("权限") -> "提前检查并请求所需权限"
            reason.contains("网络") -> "添加网络状态检查和重试机制"
            reason.contains("崩溃") -> "增加异常捕获和恢复逻辑"
            else -> "分析具体场景并针对性优化"
        }
    }
    
    private fun generatePreventionStrategy(reason: String): String {
        return when {
            reason.contains("找不到") -> "执行前验证目标元素存在"
            reason.contains("超时") -> "预估执行时间并设置合理超时"
            reason.contains("权限") -> "启动任务前检查权限状态"
            reason.contains("网络") -> "执行网络操作前确认连接状态"
            else -> "增加前置条件检查"
        }
    }
    
    // ==================== 优化策略学习 ====================
    
    /**
     * 学习优化策略
     */
    fun learnOptimizationStrategy(
        taskType: String,
        beforeMetrics: ExecutionMetrics,
        afterMetrics: ExecutionMetrics,
        appliedChanges: List<String>
    ) {
        LogManager.d(TAG, " 学习优化策略: $taskType")
        
        val improvement = calculateImprovement(beforeMetrics, afterMetrics)
        
        if (improvement > 0) {
            val strategyKey = "opt_${taskType}_${appliedChanges.hashCode()}"
            
            optimizationStrategies[strategyKey] = OptimizationStrategy(
                id = strategyKey,
                type = StrategyType.PERFORMANCE,
                targetTask = taskType,
                corrections = emptyList(),
                improvements = appliedChanges,
                effectiveness = improvement,
                lastUpdated = System.currentTimeMillis()
            )
        }
    }
    
    /**
     * 获取优化建议
     */
    fun getOptimizationSuggestions(taskType: String): List<OptimizationSuggestion> {
        val suggestions = mutableListOf<OptimizationSuggestion>()
        
        // 基于成功模式
        successPatterns.values
            .filter { it.taskType == taskType && it.successCount >= 5 }
            .forEach { pattern ->
                suggestions.add(OptimizationSuggestion(
                    type = SuggestionType.USE_SUCCESS_PATTERN,
                    description = "使用已验证的成功执行模式",
                    expectedImprovement = "成功率 +${(pattern.successCount * 2).coerceAtMost(30)}%",
                    confidence = calculatePatternReliability(pattern),
                    steps = pattern.commonSteps
                ))
            }
        
        // 基于失败分析
        failurePatterns.values
            .filter { it.taskType == taskType && it.failureCount >= 3 }
            .forEach { pattern ->
                suggestions.add(OptimizationSuggestion(
                    type = SuggestionType.AVOID_FAILURE_PATTERN,
                    description = "避免: ${pattern.failureReason}",
                    expectedImprovement = "减少失败 ${(pattern.failureCount * 5).coerceAtMost(50)}%",
                    confidence = 0.7f,
                    steps = listOf(suggestFix(pattern.failureReason))
                ))
            }
        
        // 基于已学习的优化策略
        optimizationStrategies.values
            .filter { it.targetTask == taskType && it.effectiveness > 0.1f }
            .forEach { strategy ->
                suggestions.add(OptimizationSuggestion(
                    type = SuggestionType.APPLY_OPTIMIZATION,
                    description = "应用已验证的优化策略",
                    expectedImprovement = "性能提升 ${(strategy.effectiveness * 100).toInt()}%",
                    confidence = strategy.effectiveness,
                    steps = strategy.improvements
                ))
            }
        
        return suggestions.sortedByDescending { it.confidence }
    }
    
    private fun calculateImprovement(before: ExecutionMetrics, after: ExecutionMetrics): Float {
        val durationImprove = (before.duration - after.duration).toFloat() / before.duration
        val successImprove = after.successRate - before.successRate
        val errorReduce = before.errorRate - after.errorRate
        
        return (durationImprove * 0.3f + successImprove * 0.4f + errorReduce * 0.3f).coerceIn(0f, 1f)
    }
    
    private fun calculatePatternReliability(pattern: SuccessPattern): Float {
        val countFactor = (pattern.successCount.toFloat() / 20f).coerceAtMost(1f)
        val recencyFactor = calculateRecencyFactor(pattern.lastSuccess)
        return (countFactor * 0.6f + recencyFactor * 0.4f)
    }
    
    // ==================== 自适应调整 ====================
    
    /**
     * 执行自适应调整
     */
    fun performAdaptiveAdjustment(
        taskType: String,
        currentPerformance: ExecutionMetrics
    ): AdaptiveAdjustment {
        LogManager.d(TAG, " 执行自适应调整: $taskType")
        
        val adjustments = mutableListOf<LearningAdjustment>()
        
        // 基于成功模式调整
        val successPattern = findSuccessPattern(taskType, emptyMap())
        if (successPattern != null && currentPerformance.successRate < 0.8f) {
            adjustments.add(LearningAdjustment(
                type = LearningAdjustmentType.STRATEGY,
                parameter = "execution_steps",
                from = "current",
                to = "success_pattern",
                reason = "当前成功率低于阈值，切换到验证过的成功模式"
            ))
        }
        
        // 基于失败模式调整
        val recentFailures = failurePatterns.values
            .filter { it.taskType == taskType }
            .filter { System.currentTimeMillis() - it.lastFailure < 24 * 60 * 60 * 1000 }
        
        recentFailures.forEach { failure ->
            adjustments.add(LearningAdjustment(
                type = LearningAdjustmentType.AVOIDANCE,
                parameter = "failure_condition",
                from = failure.failureReason,
                to = generatePreventionStrategy(failure.failureReason),
                reason = "最近发生相关失败，添加预防措施"
            ))
        }
        
        // 基于用户偏好调整
        val speedPreference = getUserPreference(PreferenceCategory.EXECUTION_SPEED)
        if (speedPreference.hasPreference && speedPreference.preferredValue == "fast") {
            if (currentPerformance.duration > 5000) {
                adjustments.add(LearningAdjustment(
                    type = LearningAdjustmentType.PARAMETER,
                    parameter = "timeout",
                    from = "${currentPerformance.duration}ms",
                    to = "3000ms",
                    reason = "用户偏好快速执行"
                ))
            }
        }
        
        return AdaptiveAdjustment(
            taskType = taskType,
            adjustments = adjustments,
            confidence = calculateAdjustmentConfidence(adjustments),
            expectedImprovement = estimateAdjustmentImprovement(adjustments)
        )
    }
    
    /**
     * 📊 评估自适应效果
     */
    fun evaluateAdaptation(
        adjustment: AdaptiveAdjustment,
        beforeMetrics: ExecutionMetrics,
        afterMetrics: ExecutionMetrics
    ): AdaptationEvaluation {
        val improvement = calculateImprovement(beforeMetrics, afterMetrics)
        val successful = improvement > 0
        
        // 更新策略有效性
        if (successful) {
            adjustment.adjustments.forEach { adj ->
                val strategyKey = "adapt_${adjustment.taskType}_${adj.parameter}"
                val existing = optimizationStrategies[strategyKey]
                
                if (existing != null) {
                    optimizationStrategies[strategyKey] = existing.copy(
                        effectiveness = (existing.effectiveness + improvement) / 2,
                        lastUpdated = System.currentTimeMillis()
                    )
                } else {
                    optimizationStrategies[strategyKey] = OptimizationStrategy(
                        id = strategyKey,
                        type = StrategyType.ADAPTIVE,
                        targetTask = adjustment.taskType,
                        corrections = emptyList(),
                        improvements = listOf("${adj.parameter}: ${adj.from} -> ${adj.to}"),
                        effectiveness = improvement,
                        lastUpdated = System.currentTimeMillis()
                    )
                }
            }
        }
        
        return AdaptationEvaluation(
            adjustment = adjustment,
            successful = successful,
            actualImprovement = improvement,
            recommendation = if (successful) 
                "保持当前调整" 
            else 
                "回滚调整并尝试其他策略"
        )
    }
    
    private fun calculateAdjustmentConfidence(adjustments: List<LearningAdjustment>): Float {
        if (adjustments.isEmpty()) return 0f
        
        return adjustments.map { adj ->
            when (adj.type) {
                LearningAdjustmentType.STRATEGY -> 0.8f
                LearningAdjustmentType.PARAMETER -> 0.6f
                LearningAdjustmentType.AVOIDANCE -> 0.7f
            }
        }.average().toFloat()
    }
    
    private fun estimateAdjustmentImprovement(adjustments: List<LearningAdjustment>): String {
        val totalImprovement = adjustments.map { adj ->
            when (adj.type) {
                LearningAdjustmentType.STRATEGY -> 15
                LearningAdjustmentType.PARAMETER -> 10
                LearningAdjustmentType.AVOIDANCE -> 20
            }
        }.sum()
        return "预计提升 ${totalImprovement.coerceAtMost(50)}%"
    }
    
    // ==================== 🛠️ 辅助方法 ====================
    
    private fun getTimeSlot(timestamp: Long): TimeSlot {
        val calendar = java.util.Calendar.getInstance().apply { timeInMillis = timestamp }
        val hour = calendar.get(java.util.Calendar.HOUR_OF_DAY)
        
        return when (hour) {
            in 6..9 -> TimeSlot.EARLY_MORNING
            in 10..12 -> TimeSlot.MORNING
            in 13..14 -> TimeSlot.NOON
            in 15..18 -> TimeSlot.AFTERNOON
            in 19..22 -> TimeSlot.EVENING
            else -> TimeSlot.NIGHT
        }
    }
    
    private fun getDayOfWeek(timestamp: Long): Int {
        val calendar = java.util.Calendar.getInstance().apply { timeInMillis = timestamp }
        return calendar.get(java.util.Calendar.DAY_OF_WEEK)
    }
    
    private fun prunePatterns() {
        if (operationPatterns.size > MAX_PATTERNS_PER_CATEGORY) {
            val toRemove = operationPatterns.entries
                .sortedBy { it.value.lastOccurrence }
                .take(operationPatterns.size - MAX_PATTERNS_PER_CATEGORY)
                .map { it.key }
            
            toRemove.forEach { operationPatterns.remove(it) }
        }
    }
    
    private fun updateLearningState() {
        _learningState.value = LearningState(
            totalPatterns = operationPatterns.size,
            totalPreferences = userPreferences.size,
            totalHabits = userHabits.size,
            totalFeedback = feedbackRecords.size,
            successPatterns = successPatterns.size,
            failurePatterns = failurePatterns.size,
            lastUpdate = System.currentTimeMillis()
        )
    }
    
    /**
     * 🔄 重置学习数据
     */
    fun resetLearningData() {
        operationPatterns.clear()
        userPreferences.clear()
        userHabits.clear()
        feedbackRecords.clear()
        successPatterns.clear()
        failurePatterns.clear()
        optimizationStrategies.clear()
        updateLearningState()
    }
    
    /**
     * 📊 获取学习统计
     */
    fun getLearningStats(): DetailedLearningStats {
        return DetailedLearningStats(
            operationPatternsCount = operationPatterns.size,
            preferencesCount = userPreferences.size,
            habitsCount = userHabits.size,
            formedHabitsCount = userHabits.values.count { it.consecutiveDays >= HABIT_FORMATION_DAYS },
            feedbackCount = feedbackRecords.size,
            successPatternsCount = successPatterns.size,
            failurePatternsCount = failurePatterns.size,
            strategiesCount = optimizationStrategies.size,
            overallSuccessRate = getSuccessRateStats().successRate
        )
    }
}

// ==================== 📦 数据类定义 ====================

// 用户操作
data class UserOperation(
    val action: OperationAction,
    val targetType: TargetType,
    val appPackage: String?,
    val duration: Long
)

enum class OperationAction { CLICK, SCROLL, INPUT, LONG_PRESS, SWIPE, BACK, HOME }

enum class TargetType(val description: String) {
    BUTTON("按钮"),
    TEXT("文字"),
    IMAGE("图片"),
    INPUT_FIELD("输入框"),
    LIST_ITEM("列表项"),
    MENU("菜单"),
    ICON("图标"),
    OTHER("其他")
}

// 操作上下文
data class OperationContext(
    val timeSlot: TimeSlot,
    val appState: String,
    val previousAction: String?,
    val followUpActions: List<String> = emptyList()
)

enum class TimeSlot(val description: String) {
    EARLY_MORNING("清晨6-9点"),
    MORNING("上午10-12点"),
    NOON("中午12-14点"),
    AFTERNOON("下午15-18点"),
    EVENING("傍晚19-22点"),
    NIGHT("夜间22-6点")
}

// 操作模式
data class OperationPattern(
    val id: String,
    val action: OperationAction,
    val targetType: TargetType,
    val appPackage: String?,
    val occurrences: Int,
    val firstOccurrence: Long,
    val lastOccurrence: Long,
    val avgDuration: Long,
    val contexts: List<OperationContext>
)

// 学习到的用户模式
data class LearnedUserPattern(
    val patternId: String,
    val type: UserPatternType,
    val description: String,
    val confidence: Float,
    val recommendation: String
)

enum class UserPatternType { OPERATION, PREFERENCE, HABIT, TASK }

// 匹配的模式
data class MatchedPattern(
    val pattern: OperationPattern,
    val similarity: Float,
    val predictedNextActions: List<String>
)

// 用户偏好
enum class PreferenceCategory(val description: String) {
    APP_CHOICE("应用选择"),
    EXECUTION_SPEED("执行速度"),
    CONFIRMATION_LEVEL("确认级别"),
    NOTIFICATION("通知偏好"),
    LANGUAGE("语言风格"),
    UI_DENSITY("界面密度")
}

data class PreferenceContext(
    val timeSlot: TimeSlot,
    val situation: String
)

data class UserPreferenceData(
    val category: PreferenceCategory,
    val value: String,
    val count: Int,
    val firstSelected: Long,
    val lastSelected: Long,
    val contexts: List<PreferenceContext>
)

data class UserPreferenceResult(
    val hasPreference: Boolean,
    val preferredValue: String?,
    val confidence: Float,
    val alternatives: List<String>
)

data class PreferenceTrend(
    val category: PreferenceCategory,
    val fromValue: String?,
    val toValue: String,
    val confidence: Float,
    val description: String
)

// 用户习惯
enum class HabitType {
    APP_USAGE,
    TASK_EXECUTION,
    COMMUNICATION,
    CONTENT_CONSUMPTION,
    ROUTINE
}

data class UserHabit(
    val type: HabitType,
    val behavior: String,
    val totalCount: Int,
    val occurrences: Map<TimeSlot, Int>,
    val daysOfWeek: Map<Int, Int>,
    val firstOccurrence: Long,
    val lastOccurrence: Long,
    val consecutiveDays: Int
)

data class HabitPrediction(
    val habit: UserHabit,
    val probability: Float,
    val suggestedAction: String,
    val timing: HabitTiming
)

enum class HabitTiming { NOW, LATER_TODAY, PASSED }

// 用户反馈
data class UserFeedback(
    val type: FeedbackType,
    val sentiment: FeedbackSentiment,
    val detail: String?,
    val relatedTask: String?,
    val tags: List<String> = emptyList()
)

enum class FeedbackType(val description: String) {
    ACTION_RESULT("操作结果"),
    PREFERENCE("偏好表达"),
    CORRECTION("纠正"),
    SUGGESTION("建议"),
    COMPLAINT("投诉")
}

enum class FeedbackSentiment { POSITIVE, NEUTRAL, NEGATIVE }

data class FeedbackRecord(
    val id: String,
    val feedback: UserFeedback,
    val timestamp: Long,
    val processed: Boolean
)

data class FeedbackAnalysis(
    val overallSentiment: FeedbackSentiment,
    val satisfactionScore: Float,
    val commonIssues: List<CommonIssue>,
    val improvements: List<ImprovementSuggestion>
)

data class CommonIssue(
    val issue: String,
    val occurrences: Int,
    val suggestedSolution: String
)

data class ImprovementSuggestion(
    val area: String,
    val priority: Priority,
    val description: String,
    val expectedImpact: String
)

enum class Priority { LOW, MEDIUM, HIGH }

// 任务执行记录
data class TaskExecutionRecord(
    val taskType: String,
    val conditions: Map<String, String>,
    val steps: List<String>,
    val duration: Long,
    val success: Boolean,
    val failedAtStep: Int? = null
)

// 成功模式
data class SuccessPattern(
    val id: String,
    val taskType: String,
    val conditions: Map<String, String>,
    val commonSteps: List<String>,
    val successCount: Int,
    val avgDuration: Long,
    val firstSuccess: Long,
    val lastSuccess: Long
)

// 失败模式
data class FailurePattern(
    val id: String,
    val taskType: String,
    val failureReason: String,
    val conditions: Map<String, String>,
    val failedSteps: List<String>,
    val failureCount: Int,
    val firstFailure: Long,
    val lastFailure: Long,
    val recoveryAttempts: List<String>
)

data class FailureAnalysis(
    val reason: String,
    val occurrences: Int,
    val affectedTasks: List<String>,
    val suggestedFix: String,
    val preventionStrategy: String
)

// 优化策略
data class OptimizationStrategy(
    val id: String,
    val type: StrategyType,
    val targetTask: String,
    val corrections: List<String>,
    val improvements: List<String>,
    val effectiveness: Float,
    val lastUpdated: Long
)

enum class StrategyType { CORRECTION_BASED, RECOVERY, PERFORMANCE, ADAPTIVE }

// 执行指标
data class ExecutionMetrics(
    val duration: Long,
    val successRate: Float,
    val errorRate: Float
)

// 优化建议
data class OptimizationSuggestion(
    val type: SuggestionType,
    val description: String,
    val expectedImprovement: String,
    val confidence: Float,
    val steps: List<String>
)

enum class SuggestionType { USE_SUCCESS_PATTERN, AVOID_FAILURE_PATTERN, APPLY_OPTIMIZATION }

// 成功率统计
data class SuccessRateStats(
    val totalExecutions: Int,
    val successCount: Int,
    val failureCount: Int,
    val successRate: Float,
    val avgSuccessDuration: Long,
    val mostReliablePatterns: List<SuccessPattern>
)

// 自适应调整
data class AdaptiveAdjustment(
    val taskType: String,
    val adjustments: List<LearningAdjustment>,
    val confidence: Float,
    val expectedImprovement: String
)

data class LearningAdjustment(
    val type: LearningAdjustmentType,
    val parameter: String,
    val from: String,
    val to: String,
    val reason: String
)

enum class LearningAdjustmentType { STRATEGY, PARAMETER, AVOIDANCE }

data class AdaptationEvaluation(
    val adjustment: AdaptiveAdjustment,
    val successful: Boolean,
    val actualImprovement: Float,
    val recommendation: String
)

// 学习状态
data class LearningState(
    val totalPatterns: Int = 0,
    val totalPreferences: Int = 0,
    val totalHabits: Int = 0,
    val totalFeedback: Int = 0,
    val successPatterns: Int = 0,
    val failurePatterns: Int = 0,
    val lastUpdate: Long = 0
)

// 详细学习统计
data class DetailedLearningStats(
    val operationPatternsCount: Int,
    val preferencesCount: Int,
    val habitsCount: Int,
    val formedHabitsCount: Int,
    val feedbackCount: Int,
    val successPatternsCount: Int,
    val failurePatternsCount: Int,
    val strategiesCount: Int,
    val overallSuccessRate: Float
)
