package com.example.xihe.ai

import android.content.Context
import android.content.SharedPreferences
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * 🧠 增强AI核心模块
 * 集成意图理解、任务规划、学习能力的统一管理
 * 
 * 功能：
 * - 📚 意图纠正学习（用户纠正后学习改进）
 * - 🔄 上下文感知（历史对话和屏幕状态）
 * - 🎯 多轮对话管理
 * - 📊 设备自适应
 */
object EnhancedAICore {
    
    private const val TAG = "EnhancedAICore"
    private const val PREFS_NAME = "enhanced_ai_prefs"
    private const val KEY_INTENT_CORRECTIONS = "intent_corrections"
    private const val KEY_LEARNED_PATTERNS = "learned_patterns"
    private const val KEY_USER_PREFERENCES = "user_preferences"
    
    private var context: Context? = null
    private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }
    
    // 🧠 对话历史管理
    private val _conversationHistory = MutableStateFlow<List<ConversationTurn>>(emptyList())
    val conversationHistory = _conversationHistory.asStateFlow()
    
    // 📊 设备能力信息
    private val _deviceCapabilities = MutableStateFlow<DeviceCapabilities?>(null)
    val deviceCapabilities = _deviceCapabilities.asStateFlow()
    
    // 📚 学习到的意图模式
    private val intentPatterns = mutableMapOf<String, LearnedPattern>()
    
    // 🔄 意图纠正记录
    private val intentCorrections = mutableListOf<IntentCorrection>()
    
    /**
     * 🚀 初始化
     */
    fun initialize(appContext: Context) {
        context = appContext.applicationContext
        loadLearnedData()
        detectDeviceCapabilities()
        LogManager.i(TAG, "✅ EnhancedAICore 初始化完成")
    }
    
    /**
     * 📱 检测设备能力
     */
    private fun detectDeviceCapabilities() {
        val ctx = context ?: return
        
        val runtime = Runtime.getRuntime()
        val maxMemory = runtime.maxMemory() / 1024 / 1024 // MB
        val availableProcessors = runtime.availableProcessors()
        
        val displayMetrics = ctx.resources.displayMetrics
        val screenWidth = displayMetrics.widthPixels
        val screenHeight = displayMetrics.heightPixels
        val density = displayMetrics.density
        
        val capabilities = DeviceCapabilities(
            maxMemoryMB = maxMemory.toInt(),
            cpuCores = availableProcessors,
            screenWidth = screenWidth,
            screenHeight = screenHeight,
            screenDensity = density,
            androidVersion = android.os.Build.VERSION.SDK_INT,
            manufacturer = android.os.Build.MANUFACTURER,
            model = android.os.Build.MODEL,
            // 能力评估
            canUseLocalTTS = maxMemory >= 256,
            canUseLocalASR = maxMemory >= 200,
            canUseOCR = true,
            recommendedThreads = minOf(availableProcessors, 4)
        )
        
        _deviceCapabilities.value = capabilities
        LogManager.d(TAG, "📱 设备能力: $capabilities")
    }
    
    // ==================== 💬 对话管理 ====================
    
    /**
     * 💬 添加对话轮次
     */
    fun addConversationTurn(
        userInput: String,
        aiResponse: String,
        intent: IntentClassifier.UserIntent,
        entities: Map<String, Any>,
        screenContext: ScreenContext? = null
    ) {
        val turn = ConversationTurn.create(
            userInput = userInput,
            aiResponse = aiResponse,
            intent = intent,
            entities = entities,
            screenContext = screenContext,
            timestamp = System.currentTimeMillis()
        )
        
        val history = _conversationHistory.value.toMutableList()
        history.add(turn)
        
        // 保留最近20轮对话
        if (history.size > 20) {
            history.removeAt(0)
        }
        
        _conversationHistory.value = history
        LogManager.d(TAG, "💬 添加对话轮次: ${userInput.take(30)}...")
    }
    
    /**
     * 🔍 获取相关的历史上下文
     */
    fun getRelevantContext(currentInput: String): ConversationContext {
        val history = _conversationHistory.value
        
        if (history.isEmpty()) {
            return ConversationContext()
        }
        
        val lastTurn = history.last()
        val recentTurns = history.takeLast(5)
        
        // 提取最近的实体
        val recentEntities = mutableMapOf<String, Any>()
        recentTurns.forEach { turn ->
            turn.entities.forEach { (key, value) ->
                recentEntities[key] = value
            }
        }
        
        // 推断当前话题
        val currentTopic = inferTopic(recentTurns)
        
        // 获取当前应用（如果有屏幕上下文）
        val currentApp = lastTurn.screenContext?.packageName
        
        return ConversationContext(
            lastIntent = lastTurn.intent,
            lastEntities = lastTurn.entities,
            conversationTurns = history.size,
            currentTopic = currentTopic,
            recentMessages = recentTurns.map { it.userInput },
            currentApp = currentApp,
            screenType = lastTurn.screenContext?.screenType
        )
    }
    
    /**
     * 🎯 推断当前话题
     */
    private fun inferTopic(recentTurns: List<ConversationTurn>): String? {
        if (recentTurns.isEmpty()) return null
        
        // 统计最常见的意图
        val intentCounts = recentTurns.groupingBy { it.intent }.eachCount()
        val dominantIntent = intentCounts.maxByOrNull { it.value }?.key
        
        // 统计最常提及的应用
        val appMentions = recentTurns.flatMap { turn ->
            turn.entities.filterKeys { it == "app" }.values.map { it.toString() }
        }
        val dominantApp = appMentions.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
        
        return when {
            dominantApp != null -> "${dominantApp}相关操作"
            dominantIntent == IntentClassifier.UserIntent.AUTOMATION_TASK -> "自动化任务"
            dominantIntent == IntentClassifier.UserIntent.CASUAL_CHAT -> "闲聊"
            else -> null
        }
    }
    
    /**
     * 🗑️ 清空对话历史
     */
    fun clearConversationHistory() {
        _conversationHistory.value = emptyList()
        LogManager.d(TAG, "🗑️ 对话历史已清空")
    }
    
    // ==================== 📚 意图学习 ====================
    
    /**
     * 📝 记录意图纠正
     * 当用户纠正AI的意图理解时调用
     */
    fun recordIntentCorrection(
        originalInput: String,
        wrongIntent: IntentClassifier.UserIntent,
        correctIntent: IntentClassifier.UserIntent,
        correctAction: String? = null
    ) {
        val correction = IntentCorrection(
            originalInput = originalInput,
            wrongIntent = wrongIntent,
            correctIntent = correctIntent,
            correctAction = correctAction,
            timestamp = System.currentTimeMillis()
        )
        
        intentCorrections.add(correction)
        
        // 更新学习模式
        updateLearnedPattern(originalInput, correctIntent, correctAction)
        
        // 持久化
        saveLearnedData()
        
        LogManager.i(TAG, "📝 记录意图纠正: $wrongIntent -> $correctIntent")
    }
    
    /**
     * 🔄 更新学习模式
     */
    private fun updateLearnedPattern(
        input: String,
        intent: IntentClassifier.UserIntent,
        action: String?
    ) {
        // 提取关键词
        val keywords = extractKeywords(input)
        
        keywords.forEach { keyword ->
            val existing = intentPatterns[keyword]
            if (existing != null) {
                // 增加计数
                intentPatterns[keyword] = existing.copy(
                    occurrences = existing.occurrences + 1,
                    lastUpdated = System.currentTimeMillis()
                )
            } else {
                // 新增模式
                intentPatterns[keyword] = LearnedPattern(
                    keyword = keyword,
                    associatedIntent = intent,
                    associatedAction = action,
                    occurrences = 1,
                    confidence = 0.6f,
                    lastUpdated = System.currentTimeMillis()
                )
            }
        }
    }
    
    /**
     * 🔍 提取关键词
     */
    private fun extractKeywords(input: String): List<String> {
        val keywords = mutableListOf<String>()
        
        // 提取双字词组
        for (i in 0 until input.length - 1) {
            val word = input.substring(i, i + 2)
            if (!isStopWord(word)) {
                keywords.add(word)
            }
        }
        
        // 提取三字词组
        for (i in 0 until input.length - 2) {
            val word = input.substring(i, i + 3)
            if (!isStopWord(word)) {
                keywords.add(word)
            }
        }
        
        return keywords.distinct()
    }
    
    /**
     * 🚫 停用词判断
     */
    private fun isStopWord(word: String): Boolean {
        val stopWords = setOf(
            "的", "了", "是", "在", "我", "有", "和", "就",
            "不", "人", "都", "一", "一个", "上", "也", "很",
            "到", "说", "要", "去", "你", "会", "着", "没有",
            "看", "好", "自己", "这", "那", "它", "还", "把"
        )
        return stopWords.contains(word)
    }
    
    /**
     * 🎯 应用学习到的模式增强意图分类
     */
    fun enhanceIntentClassification(
        input: String,
        baseResult: IntentClassifier.IntentResult
    ): IntentClassifier.IntentResult {
        val normalizedInput = input.lowercase()
        
        // 查找匹配的学习模式
        var matchedPattern: LearnedPattern? = null
        var maxOccurrences = 0
        
        intentPatterns.forEach { (keyword, pattern) ->
            if (normalizedInput.contains(keyword) && pattern.occurrences > maxOccurrences) {
                matchedPattern = pattern
                maxOccurrences = pattern.occurrences
            }
        }
        
        // 如果找到高置信度的学习模式，调整意图
        matchedPattern?.let { pattern ->
            if (pattern.occurrences >= 3 && pattern.confidence >= 0.7f) {
                if (pattern.associatedIntent != baseResult.intent) {
                    LogManager.d(TAG, "🧠 应用学习模式: ${pattern.keyword} -> ${pattern.associatedIntent}")
                    return baseResult.copy(
                        intent = pattern.associatedIntent,
                        confidence = (baseResult.confidence + pattern.confidence) / 2,
                        suggestedAction = pattern.associatedAction ?: baseResult.suggestedAction
                    )
                }
            }
        }
        
        return baseResult
    }
    
    // ==================== 💾 数据持久化 ====================
    
    /**
     * 💾 保存学习数据
     */
    private fun saveLearnedData() {
        val prefs = context?.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE) ?: return
        
        try {
            val correctionsJson = json.encodeToString(intentCorrections.takeLast(100))
            val patternsJson = json.encodeToString(intentPatterns.toMap())
            
            prefs.edit()
                .putString(KEY_INTENT_CORRECTIONS, correctionsJson)
                .putString(KEY_LEARNED_PATTERNS, patternsJson)
                .apply()
            
            LogManager.d(TAG, "💾 学习数据已保存")
        } catch (e: Exception) {
            LogManager.e(TAG, "保存学习数据失败", e)
        }
    }
    
    /**
     * 📂 加载学习数据
     */
    private fun loadLearnedData() {
        val prefs = context?.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE) ?: return
        
        try {
            // 加载意图纠正记录
            prefs.getString(KEY_INTENT_CORRECTIONS, null)?.let { jsonStr ->
                val corrections: List<IntentCorrection> = json.decodeFromString(jsonStr)
                intentCorrections.clear()
                intentCorrections.addAll(corrections)
            }
            
            // 加载学习模式
            prefs.getString(KEY_LEARNED_PATTERNS, null)?.let { jsonStr ->
                val patterns: Map<String, LearnedPattern> = json.decodeFromString(jsonStr)
                intentPatterns.clear()
                intentPatterns.putAll(patterns)
            }
            
            LogManager.d(TAG, "📂 加载了 ${intentCorrections.size} 条纠正记录, ${intentPatterns.size} 个学习模式")
        } catch (e: Exception) {
            LogManager.e(TAG, "加载学习数据失败", e)
        }
    }
    
    /**
     * 📊 获取学习统计
     */
    fun getLearningStats(): LearningStats {
        return LearningStats(
            totalCorrections = intentCorrections.size,
            learnedPatterns = intentPatterns.size,
            topPatterns = intentPatterns.values
                .sortedByDescending { it.occurrences }
                .take(10)
                .map { "${it.keyword}: ${it.occurrences}次" }
        )
    }
}

// ==================== 📦 数据类定义 ====================

/**
 * 💬 对话轮次
 */
@Serializable
data class ConversationTurn(
    val userInput: String,
    val aiResponse: String,
    val intent: IntentClassifier.UserIntent,
    val entities: Map<String, String> = emptyMap(),
    val screenContext: ScreenContext? = null,
    val timestamp: Long
) {
    companion object {
        /**
         * 从 Any 类型的 entities 创建
         */
        fun create(
            userInput: String,
            aiResponse: String,
            intent: IntentClassifier.UserIntent,
            entities: Map<String, Any>,
            screenContext: ScreenContext?,
            timestamp: Long
        ): ConversationTurn = ConversationTurn(
            userInput = userInput,
            aiResponse = aiResponse,
            intent = intent,
            entities = entities.mapValues { it.value.toString() },
            screenContext = screenContext,
            timestamp = timestamp
        )
    }
}

/**
 * 📱 屏幕上下文
 */
@Serializable
data class ScreenContext(
    val packageName: String,
    val screenType: String?,
    val visibleElements: List<String> = emptyList(),
    val currentFocus: String? = null
)

/**
 * 📝 意图纠正记录
 */
@Serializable
data class IntentCorrection(
    val originalInput: String,
    val wrongIntent: IntentClassifier.UserIntent,
    val correctIntent: IntentClassifier.UserIntent,
    val correctAction: String?,
    val timestamp: Long
)

/**
 * 🧠 学习到的模式
 */
@Serializable
data class LearnedPattern(
    val keyword: String,
    val associatedIntent: IntentClassifier.UserIntent,
    val associatedAction: String?,
    val occurrences: Int,
    val confidence: Float,
    val lastUpdated: Long
)

/**
 * 📱 设备能力
 */
data class DeviceCapabilities(
    val maxMemoryMB: Int,
    val cpuCores: Int,
    val screenWidth: Int,
    val screenHeight: Int,
    val screenDensity: Float,
    val androidVersion: Int,
    val manufacturer: String,
    val model: String,
    // 能力评估
    val canUseLocalTTS: Boolean,
    val canUseLocalASR: Boolean,
    val canUseOCR: Boolean,
    val recommendedThreads: Int
)

/**
 * 📊 学习统计
 */
data class LearningStats(
    val totalCorrections: Int,
    val learnedPatterns: Int,
    val topPatterns: List<String>
)
