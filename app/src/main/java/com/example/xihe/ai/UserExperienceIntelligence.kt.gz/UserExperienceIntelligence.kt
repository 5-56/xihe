package com.example.xihe.ai

import com.example.xihe.utils.LogManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ConcurrentHashMap

/**
 * 🎨 用户体验智能模块
 * 
 * 实现界面响应、自然语言交互、操作反馈优化
 */
object UserExperienceIntelligence {
    
    private const val TAG = "UserExperienceIntelligence"
    
    // 对话历史
    private val conversationHistory = mutableListOf<UXConversationTurn>()
    
    // 用户画像
    private val userProfile = MutableStateFlow(UserProfile())
    
    // 反馈队列
    private val feedbackQueue = mutableListOf<FeedbackItem>()
    
    // 个性化设置
    private val personalizationSettings = ConcurrentHashMap<String, Any>()
    
    // UI性能记录
    private val uiPerformanceRecords = mutableListOf<UIPerformanceRecord>()
    
    // 体验状态
    private val _uxState = MutableStateFlow(UXState())
    val uxState: StateFlow<UXState> = _uxState.asStateFlow()
    
    // 配置
    private var config = UXConfig()
    
    // ==================== 🖼️ 界面响应速度优化 ====================
    
    /**
     * 🖼️ 记录UI渲染性能
     */
    fun recordUIRenderPerformance(
        viewName: String,
        renderTimeMs: Long,
        frameDropCount: Int = 0
    ): UIRenderAnalysis {
        val record = UIPerformanceRecord(
            viewName = viewName,
            renderTimeMs = renderTimeMs,
            frameDropCount = frameDropCount,
            timestamp = System.currentTimeMillis()
        )
        uiPerformanceRecords.add(record)
        
        // 保持记录数量
        if (uiPerformanceRecords.size > 500) {
            uiPerformanceRecords.removeAll(uiPerformanceRecords.take(100))
        }
        
        // 分析性能
        val avgRenderTime = uiPerformanceRecords
            .filter { it.viewName == viewName }
            .map { it.renderTimeMs }
            .average()
        
        val isSmooth = renderTimeMs < 16 && frameDropCount == 0
        
        val recommendations = mutableListOf<String>()
        if (renderTimeMs > 16) recommendations.add("渲染时间超过16ms，考虑优化布局复杂度")
        if (frameDropCount > 0) recommendations.add("存在掉帧，检查主线程是否阻塞")
        if (avgRenderTime > 20) recommendations.add("平均渲染时间较高，考虑使用ViewStub延迟加载")
        
        return UIRenderAnalysis(
            viewName = viewName,
            currentRenderTime = renderTimeMs,
            avgRenderTime = avgRenderTime.toLong(),
            isSmooth = isSmooth,
            frameDropCount = frameDropCount,
            recommendations = recommendations
        )
    }
    
    /**
     * 🎬 获取动画性能建议
     */
    fun getAnimationOptimizationTips(
        animationType: AnimationType,
        durationMs: Long,
        complexity: AnimationComplexity
    ): AnimationOptimizationTips {
        val tips = mutableListOf<String>()
        
        // 通用建议
        if (durationMs > 300) tips.add("动画时长超过300ms可能影响体验")
        
        when (animationType) {
            AnimationType.TRANSITION -> {
                tips.add("使用共享元素过渡提升连贯性")
                tips.add("考虑使用Fade+Scale组合效果")
            }
            AnimationType.LOADING -> {
                tips.add("使用骨架屏替代传统加载动画")
                tips.add("加载动画应简洁不分散注意力")
            }
            AnimationType.FEEDBACK -> {
                tips.add("反馈动画应快速(100-200ms)")
                tips.add("使用缩放或颜色变化提供反馈")
            }
            AnimationType.CELEBRATION -> {
                tips.add("庆祝动画可以稍长(300-500ms)")
                tips.add("使用粒子效果增加喜悦感")
            }
            AnimationType.SCROLL -> {
                tips.add("使用RecyclerView的ItemAnimator")
                tips.add("避免在滚动时执行复杂计算")
            }
        }
        
        when (complexity) {
            AnimationComplexity.SIMPLE -> {}
            AnimationComplexity.MEDIUM -> tips.add("中等复杂度动画建议使用硬件加速")
            AnimationComplexity.COMPLEX -> {
                tips.add("复杂动画建议使用Lottie或自定义View")
                tips.add("考虑在低端设备上简化或禁用")
            }
        }
        
        return AnimationOptimizationTips(
            animationType = animationType,
            recommendedDuration = getRecommendedDuration(animationType),
            useHardwareAcceleration = complexity != AnimationComplexity.SIMPLE,
            tips = tips
        )
    }
    
    /**
     * 📋 获取列表性能优化建议
     */
    fun getListOptimizationTips(
        itemCount: Int,
        itemComplexity: ItemComplexity,
        hasImages: Boolean
    ): ListOptimizationTips {
        val tips = mutableListOf<String>()
        
        // 基础建议
        tips.add("使用RecyclerView替代ListView")
        tips.add("实现DiffUtil进行高效更新")
        
        if (itemCount > 100) {
            tips.add("数据量较大，考虑分页加载")
            tips.add("使用Paging3库实现无限滚动")
        }
        
        when (itemComplexity) {
            ItemComplexity.SIMPLE -> tips.add("简单列表可使用ConstraintLayout优化")
            ItemComplexity.MEDIUM -> {
                tips.add("使用ViewHolder模式复用视图")
                tips.add("避免在onBindViewHolder中创建对象")
            }
            ItemComplexity.COMPLEX -> {
                tips.add("复杂列表项考虑使用异步填充")
                tips.add("使用setHasFixedSize(true)如果尺寸固定")
            }
        }
        
        if (hasImages) {
            tips.add("使用Coil/Glide加载图片")
            tips.add("设置合适的图片缓存策略")
            tips.add("使用placeholder避免闪烁")
        }
        
        return ListOptimizationTips(
            recommendedPageSize = if (itemCount > 100) 20 else itemCount,
            usePagination = itemCount > 100,
            useViewHolder = true,
            tips = tips
        )
    }
    
    /**
     * 🖼️ 获取图片加载优化建议
     */
    fun getImageLoadingTips(
        imageSize: ImageSize,
        loadSource: ImageLoadSource,
        displayContext: ImageDisplayContext
    ): ImageLoadingTips {
        val tips = mutableListOf<String>()
        
        // 尺寸建议
        val recommendedSize = when (displayContext) {
            ImageDisplayContext.THUMBNAIL -> ImageSize(100, 100)
            ImageDisplayContext.LIST_ITEM -> ImageSize(200, 200)
            ImageDisplayContext.DETAIL -> ImageSize(800, 800)
            ImageDisplayContext.FULLSCREEN -> imageSize
        }
        
        if (imageSize.width > recommendedSize.width * 2 || imageSize.height > recommendedSize.height * 2) {
            tips.add("图片尺寸过大，建议压缩至${recommendedSize.width}x${recommendedSize.height}")
        }
        
        // 加载源建议
        when (loadSource) {
            ImageLoadSource.NETWORK -> {
                tips.add("使用内存+磁盘二级缓存")
                tips.add("支持渐进式加载(JPEG Progressive)")
                tips.add("考虑使用WebP格式减少体积")
            }
            ImageLoadSource.LOCAL -> {
                tips.add("本地图片可预解码提升显示速度")
            }
            ImageLoadSource.CACHE -> {
                tips.add("缓存图片直接显示，性能最优")
            }
        }
        
        // 通用建议
        tips.add("使用合适的ScaleType避免内存浪费")
        tips.add("设置placeholder和error图片")
        
        return ImageLoadingTips(
            recommendedSize = recommendedSize,
            useCache = true,
            usePlaceholder = true,
            useTransition = displayContext != ImageDisplayContext.THUMBNAIL,
            compressionQuality = if (displayContext == ImageDisplayContext.THUMBNAIL) 70 else 85,
            tips = tips
        )
    }
    
    // ==================== 💬 自然语言交互优化 ====================
    
    /**
     * 💬 增强自然语言理解
     */
    fun enhanceNaturalLanguageUnderstanding(
        userInput: String,
        context: UXConversationContext
    ): EnhancedUnderstanding {
        LogManager.d(TAG, "💬 增强理解: $userInput")
        
        // 预处理
        val normalizedInput = normalizeInput(userInput)
        
        // 意图识别
        val intents = recognizeIntents(normalizedInput)
        
        // 实体提取
        val entities = extractEntities(normalizedInput)
        
        // 情感分析
        val sentiment = analyzeSentiment(normalizedInput)
        
        // 上下文关联
        val contextualInfo = resolveContextReferences(normalizedInput, context)
        
        // 置信度评估
        val confidence = calculateUnderstandingConfidence(intents, entities, contextualInfo)
        
        // 如果置信度低，生成澄清问题
        val clarificationNeeded = confidence < 0.6f
        val clarificationQuestion = if (clarificationNeeded) {
            generateClarificationQuestion(normalizedInput, intents, entities)
        } else null
        
        return EnhancedUnderstanding(
            originalInput = userInput,
            normalizedInput = normalizedInput,
            intents = intents,
            entities = entities,
            sentiment = sentiment,
            contextualInfo = contextualInfo,
            confidence = confidence,
            clarificationNeeded = clarificationNeeded,
            clarificationQuestion = clarificationQuestion
        )
    }
    
    /**
     * 🔄 提升对话流畅性
     */
    fun improveConversationFluency(
        currentTurn: UXConversationTurn,
        responseOptions: List<String>
    ): FluentResponse {
        // 记录对话
        conversationHistory.add(currentTurn)
        if (conversationHistory.size > 50) {
            conversationHistory.removeAll(conversationHistory.take(10))
        }
        
        // 选择最佳响应
        val selectedResponse = selectBestResponse(responseOptions, currentTurn)
        
        // 添加过渡词
        val fluentResponse = addTransitionWords(selectedResponse, currentTurn)
        
        // 调整语气
        val toneAdjusted = adjustTone(fluentResponse, userProfile.value)
        
        // 添加个性化元素
        val personalizedResponse = personalize(toneAdjusted, userProfile.value)
        
        return FluentResponse(
            originalResponse = selectedResponse,
            enhancedResponse = personalizedResponse,
            tone = detectTone(personalizedResponse),
            transitionUsed = fluentResponse != selectedResponse,
            personalizationApplied = personalizedResponse != toneAdjusted
        )
    }
    
    /**
     * 🔗 保持上下文连贯性
     */
    fun maintainContextCoherence(
        newInput: String,
        maxHistoryTurns: Int = 10
    ): ContextCoherence {
        val recentHistory = conversationHistory.takeLast(maxHistoryTurns)
        
        // 识别话题
        val currentTopic = identifyTopic(newInput)
        val previousTopics = recentHistory.map { identifyTopic(it.userInput) }
        
        // 检查话题连续性
        val isTopicContinued = previousTopics.lastOrNull() == currentTopic
        
        // 解析代词引用
        val resolvedReferences = resolvePronouns(newInput, recentHistory)
        
        // 提取上下文变量
        val contextVariables = extractContextVariables(recentHistory)
        
        // 生成上下文摘要
        val contextSummary = generateContextSummary(recentHistory)
        
        return ContextCoherence(
            currentTopic = currentTopic,
            isTopicContinued = isTopicContinued,
            resolvedInput = resolvedReferences,
            contextVariables = contextVariables,
            contextSummary = contextSummary,
            coherenceScore = calculateCoherenceScore(newInput, recentHistory)
        )
    }
    
    /**
     * 👤 个性化回复
     */
    fun personalizeResponse(
        baseResponse: String,
        personalizationType: PersonalizationType
    ): PersonalizedResponse {
        val profile = userProfile.value
        
        var personalizedText = baseResponse
        val appliedPersonalizations = mutableListOf<String>()
        
        when (personalizationType) {
            PersonalizationType.GREETING -> {
                personalizedText = personalizeGreeting(baseResponse, profile)
                appliedPersonalizations.add("问候语个性化")
            }
            PersonalizationType.TONE -> {
                personalizedText = adjustToneToPreference(baseResponse, profile.preferredTone)
                appliedPersonalizations.add("语气调整")
            }
            PersonalizationType.DETAIL_LEVEL -> {
                personalizedText = adjustDetailLevel(baseResponse, profile.preferredDetailLevel)
                appliedPersonalizations.add("详细程度调整")
            }
            PersonalizationType.EXAMPLES -> {
                personalizedText = addRelevantExamples(baseResponse, profile)
                appliedPersonalizations.add("添加相关示例")
            }
            PersonalizationType.FULL -> {
                personalizedText = personalizeGreeting(baseResponse, profile)
                personalizedText = adjustToneToPreference(personalizedText, profile.preferredTone)
                personalizedText = adjustDetailLevel(personalizedText, profile.preferredDetailLevel)
                appliedPersonalizations.addAll(listOf("问候语", "语气", "详细程度"))
            }
        }
        
        return PersonalizedResponse(
            originalResponse = baseResponse,
            personalizedResponse = personalizedText,
            appliedPersonalizations = appliedPersonalizations,
            userPreferences = mapOf(
                "tone" to profile.preferredTone.name,
                "detailLevel" to profile.preferredDetailLevel.name
            )
        )
    }
    
    /**
     * 📝 更新用户画像
     */
    fun updateUserProfile(
        preferredTone: ResponseTone? = null,
        preferredDetailLevel: DetailLevel? = null,
        interests: List<String>? = null,
        nickname: String? = null
    ) {
        val current = userProfile.value
        userProfile.value = current.copy(
            preferredTone = preferredTone ?: current.preferredTone,
            preferredDetailLevel = preferredDetailLevel ?: current.preferredDetailLevel,
            interests = interests ?: current.interests,
            nickname = nickname ?: current.nickname,
            lastUpdated = System.currentTimeMillis()
        )
    }
    
    // ==================== 📢 操作反馈优化 ====================
    
    /**
     * 📢 生成实时状态反馈
     */
    fun generateStatusFeedback(
        operation: String,
        status: OperationStatus,
        progress: Float = 0f,
        details: String? = null
    ): StatusFeedback {
        val message = when (status) {
            OperationStatus.PENDING -> "准备${operation}..."
            OperationStatus.IN_PROGRESS -> "${operation}中... ${(progress * 100).toInt()}%"
            OperationStatus.COMPLETED -> "${operation}完成！"
            OperationStatus.FAILED -> "${operation}失败"
            OperationStatus.CANCELLED -> "${operation}已取消"
        }
        
        val icon = when (status) {
            OperationStatus.PENDING -> "⏳"
            OperationStatus.IN_PROGRESS -> "🔄"
            OperationStatus.COMPLETED -> "✅"
            OperationStatus.FAILED -> "❌"
            OperationStatus.CANCELLED -> "🚫"
        }
        
        val animation = when (status) {
            OperationStatus.PENDING, OperationStatus.IN_PROGRESS -> FeedbackAnimation.LOADING
            OperationStatus.COMPLETED -> FeedbackAnimation.SUCCESS
            OperationStatus.FAILED -> FeedbackAnimation.ERROR
            OperationStatus.CANCELLED -> FeedbackAnimation.NONE
        }
        
        return StatusFeedback(
            operation = operation,
            status = status,
            message = message,
            icon = icon,
            animation = animation,
            progress = progress,
            details = details,
            timestamp = System.currentTimeMillis()
        )
    }
    
    /**
     * 📋 生成操作结果反馈
     */
    fun generateResultFeedback(
        operation: String,
        success: Boolean,
        result: Any? = null,
        error: String? = null
    ): ResultFeedback {
        val title = if (success) "操作成功" else "操作失败"
        
        val message = when {
            success && result != null -> "${operation}成功：$result"
            success -> "${operation}已完成"
            error != null -> "${operation}失败：$error"
            else -> "${operation}遇到问题，请重试"
        }
        
        val suggestions = if (!success) {
            generateErrorSuggestions(operation, error)
        } else emptyList()
        
        val celebrationType = if (success) {
            determineCelebrationType(operation)
        } else null
        
        return ResultFeedback(
            operation = operation,
            success = success,
            title = title,
            message = message,
            result = result,
            error = error,
            suggestions = suggestions,
            celebrationType = celebrationType,
            showCelebration = success && celebrationType != null
        )
    }
    
    /**
     * ⚠️ 生成友好错误提示
     */
    fun generateFriendlyErrorMessage(
        errorCode: String?,
        technicalMessage: String,
        context: ErrorContext
    ): FriendlyError {
        // 将技术错误转换为用户友好消息
        val friendlyMessage = when {
            technicalMessage.contains("network", ignoreCase = true) ||
            technicalMessage.contains("connection", ignoreCase = true) ->
                "网络连接出现问题，请检查网络后重试"
            
            technicalMessage.contains("timeout", ignoreCase = true) ->
                "操作超时了，请稍后再试"
            
            technicalMessage.contains("permission", ignoreCase = true) ->
                "需要相关权限才能完成操作"
            
            technicalMessage.contains("not found", ignoreCase = true) ->
                "找不到相关内容"
            
            technicalMessage.contains("already exists", ignoreCase = true) ->
                "该内容已存在"
            
            else -> "遇到了一些问题，请重试"
        }
        
        val icon = "😅"
        val suggestions = generateContextualSuggestions(errorCode, technicalMessage, context)
        val canRetry = !technicalMessage.contains("permission", ignoreCase = true)
        
        return FriendlyError(
            errorCode = errorCode,
            technicalMessage = technicalMessage,
            friendlyMessage = friendlyMessage,
            icon = icon,
            suggestions = suggestions,
            canRetry = canRetry,
            retryDelay = if (technicalMessage.contains("timeout")) 3000L else 1000L
        )
    }
    
    /**
     * 🎉 生成成功庆祝
     */
    fun generateCelebration(
        achievement: String,
        celebrationType: CelebrationType
    ): Celebration {
        val (title, message, emoji) = when (celebrationType) {
            CelebrationType.TASK_COMPLETED -> Triple("任务完成！", "太棒了，$achievement", "🎉")
            CelebrationType.MILESTONE -> Triple("里程碑！", "恭喜达成$achievement", "🏆")
            CelebrationType.FIRST_TIME -> Triple("首次成功！", "第一次$achievement，继续加油！", "⭐")
            CelebrationType.STREAK -> Triple("连续成功！", "$achievement，保持这个势头！", "🔥")
            CelebrationType.PERFECT -> Triple("完美！", "$achievement，无可挑剔！", "💯")
        }
        
        val animation = when (celebrationType) {
            CelebrationType.TASK_COMPLETED -> CelebrationAnimation.CONFETTI
            CelebrationType.MILESTONE -> CelebrationAnimation.FIREWORKS
            CelebrationType.FIRST_TIME -> CelebrationAnimation.STARS
            CelebrationType.STREAK -> CelebrationAnimation.FLAME
            CelebrationType.PERFECT -> CelebrationAnimation.SPARKLE
        }
        
        val sound = when (celebrationType) {
            CelebrationType.MILESTONE, CelebrationType.PERFECT -> CelebrationSound.FANFARE
            else -> CelebrationSound.CHIME
        }
        
        return Celebration(
            title = title,
            message = message,
            emoji = emoji,
            animation = animation,
            sound = sound,
            duration = if (celebrationType == CelebrationType.MILESTONE) 3000L else 2000L
        )
    }
    
    // ==================== 🛠️ 辅助方法 ====================
    
    private fun normalizeInput(input: String): String {
        return input.trim()
            .replace(Regex("\\s+"), " ")
            .lowercase()
    }
    
    private fun recognizeIntents(input: String): List<UXRecognizedIntent> {
        val intents = mutableListOf<UXRecognizedIntent>()
        
        val patterns = mapOf(
            "打开" to UXIntentType.OPEN_APP,
            "发送" to UXIntentType.SEND_MESSAGE,
            "搜索" to UXIntentType.SEARCH,
            "设置" to UXIntentType.SETTINGS,
            "帮助" to UXIntentType.HELP,
            "取消" to UXIntentType.CANCEL
        )
        
        patterns.forEach { (keyword, intentType) ->
            if (input.contains(keyword)) {
                intents.add(UXRecognizedIntent(intentType, 0.8f, keyword))
            }
        }
        
        if (intents.isEmpty()) {
            intents.add(UXRecognizedIntent(UXIntentType.GENERAL, 0.5f, null))
        }
        
        return intents
    }
    
    private fun extractEntities(input: String): List<UXExtractedEntity> {
        val entities = mutableListOf<UXExtractedEntity>()
        
        // 简单的实体提取
        val appPattern = Regex("(微信|支付宝|淘宝|抖音|qq|百度)")
        appPattern.find(input)?.let {
            entities.add(UXExtractedEntity(UXEntityType.APP_NAME, it.value, 0.9f))
        }
        
        val contactPattern = Regex("(给|找|联系)(\\S+)")
        contactPattern.find(input)?.let {
            entities.add(UXExtractedEntity(UXEntityType.CONTACT, it.groupValues[2], 0.7f))
        }
        
        return entities
    }
    
    private fun analyzeSentiment(input: String): UXSentimentResult {
        val positiveWords = listOf("好", "棒", "喜欢", "谢谢", "感谢")
        val negativeWords = listOf("不", "差", "糟", "讨厌", "烦")
        
        val positiveCount = positiveWords.count { input.contains(it) }
        val negativeCount = negativeWords.count { input.contains(it) }
        
        val sentiment = when {
            positiveCount > negativeCount -> UXSentiment.POSITIVE
            negativeCount > positiveCount -> UXSentiment.NEGATIVE
            else -> UXSentiment.NEUTRAL
        }
        
        return UXSentimentResult(sentiment, (positiveCount + negativeCount).toFloat() / 10)
    }
    
    private fun resolveContextReferences(input: String, context: UXConversationContext): ContextualInfo {
        val resolvedInput = input
            .replace("它", context.lastMentionedObject ?: "它")
            .replace("这个", context.lastMentionedObject ?: "这个")
            .replace("那个", context.previousMentionedObject ?: "那个")
        
        return ContextualInfo(
            resolvedInput = resolvedInput,
            referencesResolved = input != resolvedInput,
            contextUsed = context.lastMentionedObject != null
        )
    }
    
    private fun calculateUnderstandingConfidence(
        intents: List<UXRecognizedIntent>,
        entities: List<UXExtractedEntity>,
        contextInfo: ContextualInfo
    ): Float {
        var confidence = 0.5f
        
        if (intents.isNotEmpty()) confidence += intents.maxOf { it.confidence } * 0.3f
        if (entities.isNotEmpty()) confidence += entities.maxOf { it.confidence } * 0.2f
        if (contextInfo.contextUsed) confidence += 0.1f
        
        return confidence.coerceIn(0f, 1f)
    }
    
    private fun generateClarificationQuestion(
        input: String,
        intents: List<UXRecognizedIntent>,
        entities: List<UXExtractedEntity>
    ): String {
        return when {
            intents.isEmpty() || intents.all { it.type == UXIntentType.GENERAL } ->
                "请问您想要做什么呢？"
            entities.isEmpty() ->
                "请问是针对哪个应用或联系人呢？"
            else ->
                "能再详细说明一下吗？"
        }
    }
    
    private fun selectBestResponse(options: List<String>, turn: UXConversationTurn): String {
        return options.firstOrNull() ?: "好的，我来帮你处理"
    }
    
    private fun addTransitionWords(response: String, turn: UXConversationTurn): String {
        val transitions = listOf("好的，", "明白了，", "收到，", "没问题，")
        return if (!response.startsWith("好") && !response.startsWith("明")) {
            transitions.random() + response
        } else response
    }
    
    private fun adjustTone(response: String, profile: UserProfile): String {
        return when (profile.preferredTone) {
            ResponseTone.FORMAL -> response.replace("哈哈", "").replace("~", "")
            ResponseTone.FRIENDLY -> response + "~"
            ResponseTone.PLAYFUL -> response + " (◕‿◕)"
            ResponseTone.CONCISE -> response.split("，").first()
        }
    }
    
    private fun personalize(response: String, profile: UserProfile): String {
        return if (profile.nickname.isNotBlank()) {
            response.replace("您", profile.nickname)
        } else response
    }
    
    private fun detectTone(text: String): ResponseTone {
        return when {
            text.contains("~") || text.contains("◕") -> ResponseTone.PLAYFUL
            text.length < 20 -> ResponseTone.CONCISE
            else -> ResponseTone.FRIENDLY
        }
    }
    
    private fun identifyTopic(input: String): String {
        val topics = mapOf(
            listOf("微信", "消息", "聊天") to "通讯",
            listOf("支付", "转账", "付款") to "支付",
            listOf("搜索", "查找", "找") to "搜索",
            listOf("设置", "配置") to "设置"
        )
        
        topics.forEach { (keywords, topic) ->
            if (keywords.any { input.contains(it) }) return topic
        }
        return "通用"
    }
    
    private fun resolvePronouns(input: String, history: List<UXConversationTurn>): String {
        var resolved = input
        val lastObject = history.lastOrNull()?.entities?.firstOrNull()?.value
        
        if (lastObject != null) {
            resolved = resolved.replace("它", lastObject)
                .replace("这个", lastObject)
        }
        return resolved
    }
    
    private fun extractContextVariables(history: List<UXConversationTurn>): Map<String, String> {
        val variables = mutableMapOf<String, String>()
        
        history.forEach { turn ->
            turn.entities.forEach { entity ->
                variables[entity.type.name] = entity.value
            }
        }
        return variables
    }
    
    private fun generateContextSummary(history: List<UXConversationTurn>): String {
        if (history.isEmpty()) return "无历史对话"
        
        val topics = history.map { identifyTopic(it.userInput) }.distinct()
        return "讨论话题: ${topics.joinToString(", ")}"
    }
    
    private fun calculateCoherenceScore(input: String, history: List<UXConversationTurn>): Float {
        if (history.isEmpty()) return 1f
        
        val currentTopic = identifyTopic(input)
        val lastTopic = identifyTopic(history.last().userInput)
        
        return if (currentTopic == lastTopic) 1f else 0.7f
    }
    
    private fun personalizeGreeting(response: String, profile: UserProfile): String {
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val greeting = when (hour) {
            in 5..11 -> "早上好"
            in 12..17 -> "下午好"
            else -> "晚上好"
        }
        
        return if (profile.nickname.isNotBlank()) {
            "$greeting，${profile.nickname}！$response"
        } else response
    }
    
    private fun adjustToneToPreference(response: String, tone: ResponseTone): String = adjustTone(response, userProfile.value.copy(preferredTone = tone))
    
    private fun adjustDetailLevel(response: String, level: DetailLevel): String {
        return when (level) {
            DetailLevel.BRIEF -> response.split("。").first() + "。"
            DetailLevel.NORMAL -> response
            DetailLevel.DETAILED -> "$response 如需更多帮助请告诉我。"
        }
    }
    
    private fun addRelevantExamples(response: String, profile: UserProfile): String {
        return if (profile.interests.isNotEmpty()) {
            "$response 比如${profile.interests.first()}相关的操作。"
        } else response
    }
    
    private fun getRecommendedDuration(type: AnimationType): Long {
        return when (type) {
            AnimationType.TRANSITION -> 300
            AnimationType.LOADING -> 200
            AnimationType.FEEDBACK -> 150
            AnimationType.CELEBRATION -> 500
            AnimationType.SCROLL -> 250
        }
    }
    
    private fun generateErrorSuggestions(operation: String, error: String?): List<String> {
        return listOf("重试操作", "检查网络连接", "稍后再试")
    }
    
    private fun determineCelebrationType(operation: String): CelebrationType? {
        return when {
            operation.contains("首次") -> CelebrationType.FIRST_TIME
            operation.contains("连续") -> CelebrationType.STREAK
            else -> CelebrationType.TASK_COMPLETED
        }
    }
    
    private fun generateContextualSuggestions(
        errorCode: String?,
        message: String,
        context: ErrorContext
    ): List<String> {
        return when {
            message.contains("network") -> listOf("检查WiFi连接", "尝试移动数据", "稍后重试")
            message.contains("permission") -> listOf("前往设置授权", "检查应用权限")
            else -> listOf("重试", "联系支持")
        }
    }
    
    /**
     * 📊 获取UX统计
     */
    fun getUXStats(): UXStats {
        val avgRenderTime = uiPerformanceRecords.map { it.renderTimeMs }.average().toLong()
        val conversationCount = conversationHistory.size
        
        return UXStats(
            avgRenderTime = avgRenderTime,
            totalConversations = conversationCount,
            userProfileComplete = userProfile.value.nickname.isNotBlank(),
            feedbackQueueSize = feedbackQueue.size
        )
    }
}

// ==================== 📦 数据类 ====================

data class UXConfig(val maxHistoryTurns: Int = 50, val enablePersonalization: Boolean = true)

data class UXState(val isReady: Boolean = true, val lastUpdate: Long = 0)

// UI性能
data class UIPerformanceRecord(val viewName: String, val renderTimeMs: Long, val frameDropCount: Int, val timestamp: Long)

data class UIRenderAnalysis(val viewName: String, val currentRenderTime: Long, val avgRenderTime: Long, val isSmooth: Boolean, val frameDropCount: Int, val recommendations: List<String>)

enum class AnimationType { TRANSITION, LOADING, FEEDBACK, CELEBRATION, SCROLL }
enum class AnimationComplexity { SIMPLE, MEDIUM, COMPLEX }

data class AnimationOptimizationTips(val animationType: AnimationType, val recommendedDuration: Long, val useHardwareAcceleration: Boolean, val tips: List<String>)

enum class ItemComplexity { SIMPLE, MEDIUM, COMPLEX }

data class ListOptimizationTips(val recommendedPageSize: Int, val usePagination: Boolean, val useViewHolder: Boolean, val tips: List<String>)

data class ImageSize(val width: Int, val height: Int)
enum class ImageLoadSource { NETWORK, LOCAL, CACHE }
enum class ImageDisplayContext { THUMBNAIL, LIST_ITEM, DETAIL, FULLSCREEN }

data class ImageLoadingTips(val recommendedSize: ImageSize, val useCache: Boolean, val usePlaceholder: Boolean, val useTransition: Boolean, val compressionQuality: Int, val tips: List<String>)

// 自然语言
data class UXConversationContext(val lastMentionedObject: String? = null, val previousMentionedObject: String? = null, val currentTopic: String? = null)

data class UXConversationTurn(val userInput: String, val aiResponse: String, val entities: List<UXExtractedEntity> = emptyList(), val timestamp: Long = System.currentTimeMillis())

enum class UXIntentType { OPEN_APP, SEND_MESSAGE, SEARCH, SETTINGS, HELP, CANCEL, GENERAL }

data class UXRecognizedIntent(val type: UXIntentType, val confidence: Float, val trigger: String?)

enum class UXEntityType { APP_NAME, CONTACT, TIME, LOCATION, NUMBER }

data class UXExtractedEntity(val type: UXEntityType, val value: String, val confidence: Float)

enum class UXSentiment { POSITIVE, NEUTRAL, NEGATIVE }

data class UXSentimentResult(val sentiment: UXSentiment, val intensity: Float)

data class ContextualInfo(val resolvedInput: String, val referencesResolved: Boolean, val contextUsed: Boolean)

data class EnhancedUnderstanding(
    val originalInput: String, val normalizedInput: String, val intents: List<UXRecognizedIntent>,
    val entities: List<UXExtractedEntity>, val sentiment: UXSentimentResult, val contextualInfo: ContextualInfo,
    val confidence: Float, val clarificationNeeded: Boolean, val clarificationQuestion: String?
)

data class FluentResponse(val originalResponse: String, val enhancedResponse: String, val tone: ResponseTone, val transitionUsed: Boolean, val personalizationApplied: Boolean)

data class ContextCoherence(val currentTopic: String, val isTopicContinued: Boolean, val resolvedInput: String, val contextVariables: Map<String, String>, val contextSummary: String, val coherenceScore: Float)

enum class ResponseTone { FORMAL, FRIENDLY, PLAYFUL, CONCISE }
enum class DetailLevel { BRIEF, NORMAL, DETAILED }
enum class PersonalizationType { GREETING, TONE, DETAIL_LEVEL, EXAMPLES, FULL }

data class UserProfile(
    val nickname: String = "", val preferredTone: ResponseTone = ResponseTone.FRIENDLY,
    val preferredDetailLevel: DetailLevel = DetailLevel.NORMAL, val interests: List<String> = emptyList(), val lastUpdated: Long = 0
)

data class PersonalizedResponse(val originalResponse: String, val personalizedResponse: String, val appliedPersonalizations: List<String>, val userPreferences: Map<String, String>)

// 操作反馈
enum class OperationStatus { PENDING, IN_PROGRESS, COMPLETED, FAILED, CANCELLED }
enum class FeedbackAnimation { NONE, LOADING, SUCCESS, ERROR }

data class StatusFeedback(val operation: String, val status: OperationStatus, val message: String, val icon: String, val animation: FeedbackAnimation, val progress: Float, val details: String?, val timestamp: Long)

data class ResultFeedback(val operation: String, val success: Boolean, val title: String, val message: String, val result: Any?, val error: String?, val suggestions: List<String>, val celebrationType: CelebrationType?, val showCelebration: Boolean)

data class ErrorContext(val screen: String = "", val lastAction: String = "")

data class FriendlyError(val errorCode: String?, val technicalMessage: String, val friendlyMessage: String, val icon: String, val suggestions: List<String>, val canRetry: Boolean, val retryDelay: Long)

enum class CelebrationType { TASK_COMPLETED, MILESTONE, FIRST_TIME, STREAK, PERFECT }
enum class CelebrationAnimation { CONFETTI, FIREWORKS, STARS, FLAME, SPARKLE }
enum class CelebrationSound { CHIME, FANFARE }

data class Celebration(val title: String, val message: String, val emoji: String, val animation: CelebrationAnimation, val sound: CelebrationSound, val duration: Long)

data class FeedbackItem(val type: String, val message: String, val timestamp: Long)

data class UXStats(val avgRenderTime: Long, val totalConversations: Int, val userProfileComplete: Boolean, val feedbackQueueSize: Int)
