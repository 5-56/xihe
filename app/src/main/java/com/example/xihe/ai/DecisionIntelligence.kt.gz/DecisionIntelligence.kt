package com.example.xihe.ai

import com.example.xihe.utils.LogManager
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.exp

/**
 * 智能决策模块
 * 
 * 功能：
 * - 多方案生成
 * - 方案评估
 * - 最优方案选择
 * - 方案调整
 * - 决策解释
 * - 置信度评估
 * - 不确定性处理
 * - 歧义消除
 */
object DecisionIntelligence {
    
    private const val TAG = "DecisionIntelligence"
    
    // 决策历史
    private val decisionHistory = mutableListOf<DecisionRecord>()
    private const val HISTORY_CAPACITY = 100
    
    // 置信度阈值
    private const val HIGH_CONFIDENCE_THRESHOLD = 0.8f
    private const val MEDIUM_CONFIDENCE_THRESHOLD = 0.5f
    private const val LOW_CONFIDENCE_THRESHOLD = 0.3f
    
    // 当前决策状态
    private val _currentDecision = MutableStateFlow<DecisionState?>(null)
    val currentDecision = _currentDecision.asStateFlow()
    
    // ==================== 多方案生成 ====================
    
    /**
     * 生成多个执行方案
     */
    fun generatePlans(
        task: String,
        context: UnifiedContext?,
        constraints: List<Constraint> = emptyList()
    ): List<ExecutionPlan> {
        LogManager.d(TAG, "生成执行方案: $task")
        
        val plans = mutableListOf<ExecutionPlan>()
        
        // 解析任务类型
        val taskType = parseTaskType(task)
        
        // 根据任务类型生成不同方案
        when (taskType) {
            DecisionTaskType.OPEN_APP -> {
                plans.addAll(generateOpenAppPlans(task, context))
            }
            DecisionTaskType.SEND_MESSAGE -> {
                plans.addAll(generateSendMessagePlans(task, context))
            }
            DecisionTaskType.SEARCH -> {
                plans.addAll(generateSearchPlans(task, context))
            }
            DecisionTaskType.PURCHASE -> {
                plans.addAll(generatePurchasePlans(task, context))
            }
            DecisionTaskType.SETTINGS -> {
                plans.addAll(generateSettingsPlans(task, context))
            }
            else -> {
                plans.addAll(generateGeneralPlans(task, context))
            }
        }
        
        // 过滤不满足约束的方案
        val filteredPlans = plans.filter { plan ->
            constraints.all { constraint -> checkConstraint(plan, constraint) }
        }
        
        // 如果所有方案都被过滤，生成备选方案
        return if (filteredPlans.isEmpty()) {
            listOf(generateFallbackPlan(task))
        } else {
            filteredPlans
        }
    }
    
    private fun parseTaskType(task: String): DecisionTaskType {
        val lowerTask = task.lowercase()
        return when {
            lowerTask.contains(Regex("打开|启动|运行")) -> DecisionTaskType.OPEN_APP
            lowerTask.contains(Regex("发送|发|消息|告诉")) -> DecisionTaskType.SEND_MESSAGE
            lowerTask.contains(Regex("搜索|查找|找")) -> DecisionTaskType.SEARCH
            lowerTask.contains(Regex("购买|买|下单")) -> DecisionTaskType.PURCHASE
            lowerTask.contains(Regex("设置|调整|修改")) -> DecisionTaskType.SETTINGS
            lowerTask.contains(Regex("播放|听|看")) -> DecisionTaskType.MEDIA
            else -> DecisionTaskType.GENERAL
        }
    }
    
    private fun generateOpenAppPlans(task: String, context: UnifiedContext?): List<ExecutionPlan> {
        val appName = extractAppName(task)
        
        return listOf(
            ExecutionPlan(
                id = "open_direct",
                name = "直接打开应用",
                description = "通过系统启动器直接打开应用",
                steps = listOf(
                    PlanStep(1, "查找应用: $appName", StepType.SEARCH),
                    PlanStep(2, "启动应用", StepType.ACTION)
                ),
                estimatedTime = 2000L,
                successProbability = 0.9f,
                riskLevel = DecisionRiskLevel.LOW
            ),
            ExecutionPlan(
                id = "open_search",
                name = "搜索后打开",
                description = "在应用列表中搜索后打开",
                steps = listOf(
                    PlanStep(1, "打开应用抽屉", StepType.ACTION),
                    PlanStep(2, "搜索: $appName", StepType.SEARCH),
                    PlanStep(3, "点击应用图标", StepType.ACTION)
                ),
                estimatedTime = 4000L,
                successProbability = 0.85f,
                riskLevel = DecisionRiskLevel.LOW
            ),
            ExecutionPlan(
                id = "open_voice",
                name = "语音启动",
                description = "使用语音助手启动应用",
                steps = listOf(
                    PlanStep(1, "唤醒语音助手", StepType.ACTION),
                    PlanStep(2, "说: 打开$appName", StepType.ACTION)
                ),
                estimatedTime = 3000L,
                successProbability = 0.7f,
                riskLevel = DecisionRiskLevel.LOW
            )
        )
    }
    
    private fun generateSendMessagePlans(task: String, context: UnifiedContext?): List<ExecutionPlan> {
        val contact = extractContact(task)
        val message = extractMessageContent(task)
        
        return listOf(
            ExecutionPlan(
                id = "msg_wechat",
                name = "通过微信发送",
                description = "使用微信发送消息",
                steps = listOf(
                    PlanStep(1, "打开微信", StepType.ACTION),
                    PlanStep(2, "搜索联系人: $contact", StepType.SEARCH),
                    PlanStep(3, "进入聊天界面", StepType.ACTION),
                    PlanStep(4, "输入消息: $message", StepType.INPUT),
                    PlanStep(5, "点击发送", StepType.ACTION)
                ),
                estimatedTime = 8000L,
                successProbability = 0.85f,
                riskLevel = DecisionRiskLevel.LOW
            ),
            ExecutionPlan(
                id = "msg_sms",
                name = "通过短信发送",
                description = "使用系统短信发送",
                steps = listOf(
                    PlanStep(1, "打开短信应用", StepType.ACTION),
                    PlanStep(2, "新建短信", StepType.ACTION),
                    PlanStep(3, "选择联系人: $contact", StepType.SEARCH),
                    PlanStep(4, "输入消息: $message", StepType.INPUT),
                    PlanStep(5, "发送", StepType.ACTION)
                ),
                estimatedTime = 10000L,
                successProbability = 0.9f,
                riskLevel = DecisionRiskLevel.LOW
            )
        )
    }
    
    private fun generateSearchPlans(task: String, context: UnifiedContext?): List<ExecutionPlan> {
        val query = extractSearchQuery(task)
        
        return listOf(
            ExecutionPlan(
                id = "search_browser",
                name = "浏览器搜索",
                description = "使用浏览器进行搜索",
                steps = listOf(
                    PlanStep(1, "打开浏览器", StepType.ACTION),
                    PlanStep(2, "在搜索框输入: $query", StepType.INPUT),
                    PlanStep(3, "执行搜索", StepType.ACTION)
                ),
                estimatedTime = 5000L,
                successProbability = 0.9f,
                riskLevel = DecisionRiskLevel.LOW
            ),
            ExecutionPlan(
                id = "search_app",
                name = "应用内搜索",
                description = "在当前应用内搜索",
                steps = listOf(
                    PlanStep(1, "查找搜索框", StepType.SEARCH),
                    PlanStep(2, "输入: $query", StepType.INPUT),
                    PlanStep(3, "执行搜索", StepType.ACTION)
                ),
                estimatedTime = 3000L,
                successProbability = 0.75f,
                riskLevel = DecisionRiskLevel.LOW
            )
        )
    }
    
    private fun generatePurchasePlans(task: String, context: UnifiedContext?): List<ExecutionPlan> {
        val product = extractProductName(task)
        
        return listOf(
            ExecutionPlan(
                id = "buy_taobao",
                name = "淘宝购买",
                description = "通过淘宝购买商品",
                steps = listOf(
                    PlanStep(1, "打开淘宝", StepType.ACTION),
                    PlanStep(2, "搜索: $product", StepType.SEARCH),
                    PlanStep(3, "选择商品", StepType.ACTION),
                    PlanStep(4, "加入购物车", StepType.ACTION),
                    PlanStep(5, "结算", StepType.ACTION),
                    PlanStep(6, "确认订单", StepType.CONFIRM),
                    PlanStep(7, "支付", StepType.ACTION)
                ),
                estimatedTime = 30000L,
                successProbability = 0.7f,
                riskLevel = DecisionRiskLevel.MEDIUM
            ),
            ExecutionPlan(
                id = "buy_jd",
                name = "京东购买",
                description = "通过京东购买商品",
                steps = listOf(
                    PlanStep(1, "打开京东", StepType.ACTION),
                    PlanStep(2, "搜索: $product", StepType.SEARCH),
                    PlanStep(3, "选择商品", StepType.ACTION),
                    PlanStep(4, "立即购买", StepType.ACTION),
                    PlanStep(5, "确认订单", StepType.CONFIRM),
                    PlanStep(6, "支付", StepType.ACTION)
                ),
                estimatedTime = 25000L,
                successProbability = 0.75f,
                riskLevel = DecisionRiskLevel.MEDIUM
            )
        )
    }
    
    private fun generateSettingsPlans(task: String, context: UnifiedContext?): List<ExecutionPlan> {
        val setting = extractSettingName(task)
        
        return listOf(
            ExecutionPlan(
                id = "settings_direct",
                name = "直接进入设置",
                description = "通过系统设置修改",
                steps = listOf(
                    PlanStep(1, "打开设置", StepType.ACTION),
                    PlanStep(2, "搜索: $setting", StepType.SEARCH),
                    PlanStep(3, "修改设置", StepType.ACTION)
                ),
                estimatedTime = 5000L,
                successProbability = 0.85f,
                riskLevel = DecisionRiskLevel.LOW
            ),
            ExecutionPlan(
                id = "settings_quick",
                name = "快捷设置",
                description = "通过快捷设置面板修改",
                steps = listOf(
                    PlanStep(1, "下拉通知栏", StepType.ACTION),
                    PlanStep(2, "找到设置开关", StepType.SEARCH),
                    PlanStep(3, "切换状态", StepType.ACTION)
                ),
                estimatedTime = 2000L,
                successProbability = 0.6f,
                riskLevel = DecisionRiskLevel.LOW
            )
        )
    }
    
    private fun generateGeneralPlans(task: String, context: UnifiedContext?): List<ExecutionPlan> {
        return listOf(
            ExecutionPlan(
                id = "general_auto",
                name = "自动执行",
                description = "根据任务自动分析并执行",
                steps = listOf(
                    PlanStep(1, "分析任务", StepType.ANALYZE),
                    PlanStep(2, "执行操作", StepType.ACTION)
                ),
                estimatedTime = 5000L,
                successProbability = 0.6f,
                riskLevel = DecisionRiskLevel.LOW
            )
        )
    }
    
    private fun generateFallbackPlan(task: String): ExecutionPlan {
        return ExecutionPlan(
            id = "fallback",
            name = "备选方案",
            description = "请用户提供更多信息",
            steps = listOf(
                PlanStep(1, "询问用户详细需求", StepType.CONFIRM)
            ),
            estimatedTime = 0L,
            successProbability = 0.5f,
            riskLevel = DecisionRiskLevel.LOW
        )
    }
    
    private fun checkConstraint(plan: ExecutionPlan, constraint: Constraint): Boolean {
        return when (constraint.type) {
            ConstraintType.TIME -> plan.estimatedTime <= (constraint.value as? Long ?: Long.MAX_VALUE)
            ConstraintType.RISK -> plan.riskLevel.ordinal <= (constraint.value as? DecisionRiskLevel ?: DecisionRiskLevel.HIGH).ordinal
            ConstraintType.SUCCESS_RATE -> plan.successProbability >= (constraint.value as? Float ?: 0f)
            ConstraintType.STEP_COUNT -> plan.steps.size <= (constraint.value as? Int ?: Int.MAX_VALUE)
        }
    }
    
    // ==================== 方案评估 ====================
    
    /**
     * 评估执行方案
     */
    fun evaluatePlans(
        plans: List<ExecutionPlan>,
        context: UnifiedContext?,
        preferences: UserPreferences = UserPreferences()
    ): List<PlanEvaluation> {
        LogManager.d(TAG, "评估 ${plans.size} 个方案")
        
        return plans.map { plan ->
            evaluateSinglePlan(plan, context, preferences)
        }.sortedByDescending { it.overallScore }
    }
    
    private fun evaluateSinglePlan(
        plan: ExecutionPlan,
        context: UnifiedContext?,
        preferences: UserPreferences
    ): PlanEvaluation {
        // 计算各维度得分
        val successScore = plan.successProbability
        
        val timeScore = calculateTimeScore(plan.estimatedTime, preferences.maxWaitTime)
        
        val riskScore = when (plan.riskLevel) {
            DecisionRiskLevel.SAFE -> 1.0f
            DecisionRiskLevel.LOW -> 0.9f
            DecisionRiskLevel.MEDIUM -> 0.6f
            DecisionRiskLevel.HIGH -> 0.3f
        }
        
        val complexityScore = calculateComplexityScore(plan.steps.size)
        
        val contextScore = calculateContextScore(plan, context)
        
        // 加权计算总分
        val overallScore = (
            successScore * preferences.successWeight +
            timeScore * preferences.timeWeight +
            riskScore * preferences.riskWeight +
            complexityScore * preferences.complexityWeight +
            contextScore * 0.1f
        ) / (preferences.successWeight + preferences.timeWeight + 
             preferences.riskWeight + preferences.complexityWeight + 0.1f)
        
        return PlanEvaluation(
            plan = plan,
            overallScore = overallScore,
            successScore = successScore,
            timeScore = timeScore,
            riskScore = riskScore,
            complexityScore = complexityScore,
            contextScore = contextScore,
            pros = identifyPros(plan, overallScore),
            cons = identifyCons(plan, overallScore)
        )
    }
    
    private fun calculateTimeScore(estimatedTime: Long, maxWaitTime: Long): Float {
        return if (estimatedTime <= 0) 1.0f
        else (1.0f - (estimatedTime.toFloat() / maxWaitTime.toFloat()).coerceAtMost(1.0f))
    }
    
    private fun calculateComplexityScore(stepCount: Int): Float {
        return when {
            stepCount <= 2 -> 1.0f
            stepCount <= 4 -> 0.8f
            stepCount <= 6 -> 0.6f
            else -> 0.4f
        }
    }
    
    private fun calculateContextScore(plan: ExecutionPlan, context: UnifiedContext?): Float {
        if (context == null) return 0.5f
        
        var score = 0.5f
        
        // 如果当前页面与方案相关，加分
        context.screenContext?.let { screen ->
            if (plan.name.contains("应用") && screen.pageType == PageType.HOME) {
                score += 0.2f
            }
        }
        
        return score.coerceAtMost(1.0f)
    }
    
    private fun identifyPros(plan: ExecutionPlan, score: Float): List<String> {
        val pros = mutableListOf<String>()
        
        if (plan.successProbability >= 0.8f) pros.add("成功率高")
        if (plan.estimatedTime <= 5000L) pros.add("执行速度快")
        if (plan.steps.size <= 3) pros.add("步骤简单")
        if (plan.riskLevel == DecisionRiskLevel.LOW) pros.add("风险低")
        
        return pros
    }
    
    private fun identifyCons(plan: ExecutionPlan, score: Float): List<String> {
        val cons = mutableListOf<String>()
        
        if (plan.successProbability < 0.6f) cons.add("成功率较低")
        if (plan.estimatedTime > 10000L) cons.add("耗时较长")
        if (plan.steps.size > 5) cons.add("步骤较多")
        if (plan.riskLevel == DecisionRiskLevel.HIGH) cons.add("存在风险")
        
        return cons
    }
    
    // ==================== 最优方案选择 ====================
    
    /**
     * 选择最优方案
     */
    fun selectBestPlan(
        evaluations: List<PlanEvaluation>,
        selectionStrategy: SelectionStrategy = SelectionStrategy.BEST_SCORE
    ): SelectedPlan {
        LogManager.d(TAG, "选择最优方案，策略: $selectionStrategy")
        
        val selected = when (selectionStrategy) {
            SelectionStrategy.BEST_SCORE -> {
                evaluations.maxByOrNull { it.overallScore }
            }
            SelectionStrategy.LOWEST_RISK -> {
                evaluations.filter { it.plan.riskLevel == DecisionRiskLevel.LOW }
                    .maxByOrNull { it.overallScore }
                    ?: evaluations.maxByOrNull { it.riskScore }
            }
            SelectionStrategy.FASTEST -> {
                evaluations.minByOrNull { it.plan.estimatedTime }
            }
            SelectionStrategy.HIGHEST_SUCCESS -> {
                evaluations.maxByOrNull { it.successScore }
            }
            SelectionStrategy.SIMPLEST -> {
                evaluations.minByOrNull { it.plan.steps.size }
            }
        }
        
        val evaluation = selected ?: evaluations.first()
        val alternatives = evaluations.filter { it != evaluation }.take(2)
        
        return SelectedPlan(
            plan = evaluation.plan,
            evaluation = evaluation,
            selectionReason = generateSelectionReason(evaluation, selectionStrategy),
            alternatives = alternatives.map { it.plan },
            confidence = evaluation.overallScore
        )
    }
    
    private fun generateSelectionReason(evaluation: PlanEvaluation, strategy: SelectionStrategy): String {
        val reasons = mutableListOf<String>()
        
        reasons.add("选择策略: ${strategy.description}")
        
        if (evaluation.pros.isNotEmpty()) {
            reasons.add("优点: ${evaluation.pros.joinToString("、")}")
        }
        
        reasons.add("综合得分: ${String.format("%.2f", evaluation.overallScore)}")
        
        return reasons.joinToString("；")
    }
    
    // ==================== 方案调整 ====================
    
    /**
     * 根据执行情况调整方案
     */
    fun adjustPlan(
        currentPlan: ExecutionPlan,
        executionResult: StepExecutionResult,
        context: UnifiedContext?
    ): PlanAdjustment {
        LogManager.d(TAG, "调整方案: 步骤${executionResult.stepIndex} ${if (executionResult.success) "成功" else "失败"}")
        
        return when {
            executionResult.success -> {
                // 成功，继续下一步
                PlanAdjustment(
                    adjustmentType = AdjustmentType.CONTINUE,
                    modifiedPlan = currentPlan,
                    reason = "步骤执行成功，继续下一步"
                )
            }
            executionResult.retryable && executionResult.retryCount < 3 -> {
                // 可重试，重试当前步骤
                PlanAdjustment(
                    adjustmentType = AdjustmentType.RETRY,
                    modifiedPlan = currentPlan,
                    reason = "步骤失败但可重试 (${executionResult.retryCount + 1}/3)"
                )
            }
            else -> {
                // 尝试生成替代方案
                val alternativePlan = generateAlternativeStep(
                    currentPlan, 
                    executionResult.stepIndex, 
                    executionResult.error
                )
                
                if (alternativePlan != null) {
                    PlanAdjustment(
                        adjustmentType = AdjustmentType.MODIFY,
                        modifiedPlan = alternativePlan,
                        reason = "切换到替代方案: ${alternativePlan.steps[executionResult.stepIndex].description}"
                    )
                } else {
                    PlanAdjustment(
                        adjustmentType = AdjustmentType.ABORT,
                        modifiedPlan = currentPlan,
                        reason = "无法继续执行: ${executionResult.error ?: "未知错误"}"
                    )
                }
            }
        }
    }
    
    private fun generateAlternativeStep(
        plan: ExecutionPlan,
        failedStepIndex: Int,
        error: String?
    ): ExecutionPlan? {
        val failedStep = plan.steps.getOrNull(failedStepIndex) ?: return null
        
        // 根据步骤类型生成替代方案
        val alternativeStep = when (failedStep.type) {
            StepType.SEARCH -> PlanStep(
                failedStep.index,
                "使用滚动查找: ${failedStep.description.substringAfter(":")}",
                StepType.ACTION
            )
            StepType.ACTION -> PlanStep(
                failedStep.index,
                "使用辅助功能点击",
                StepType.ACTION
            )
            StepType.INPUT -> PlanStep(
                failedStep.index,
                "使用剪贴板粘贴",
                StepType.ACTION
            )
            else -> return null
        }
        
        val modifiedSteps = plan.steps.toMutableList()
        modifiedSteps[failedStepIndex] = alternativeStep
        
        return plan.copy(
            id = plan.id + "_alt",
            steps = modifiedSteps,
            successProbability = plan.successProbability * 0.8f
        )
    }
    
    // ==================== 决策解释 ====================
    
    /**
     * 生成决策解释
     */
    fun explainDecision(selectedPlan: SelectedPlan): DecisionExplanation {
        LogManager.d(TAG, "生成决策解释")
        
        val evaluation = selectedPlan.evaluation
        
        return DecisionExplanation(
            summary = generateSummary(selectedPlan),
            detailedReasoning = generateDetailedReasoning(evaluation),
            scoreBreakdown = ScoreBreakdown(
                success = "成功率: ${String.format("%.0f%%", evaluation.successScore * 100)}",
                time = "执行时间: ${evaluation.plan.estimatedTime / 1000}秒",
                risk = "风险等级: ${evaluation.plan.riskLevel.name}",
                complexity = "复杂度: ${evaluation.plan.steps.size}步"
            ),
            alternativeComparison = generateAlternativeComparison(selectedPlan),
            confidenceLevel = categorizeConfidence(selectedPlan.confidence)
        )
    }
    
    private fun generateSummary(selectedPlan: SelectedPlan): String {
        return "推荐使用「${selectedPlan.plan.name}」方案。" +
               "${selectedPlan.plan.description}。" +
               "预计${selectedPlan.plan.estimatedTime / 1000}秒完成。"
    }
    
    private fun generateDetailedReasoning(evaluation: PlanEvaluation): List<String> {
        val reasoning = mutableListOf<String>()
        
        reasoning.add("该方案成功率${String.format("%.0f%%", evaluation.successScore * 100)}，" +
                     if (evaluation.successScore >= 0.8f) "非常可靠" else "较为可靠")
        
        if (evaluation.plan.estimatedTime <= 5000L) {
            reasoning.add("执行速度快，用户等待时间短")
        }
        
        if (evaluation.plan.riskLevel == DecisionRiskLevel.LOW) {
            reasoning.add("操作风险低，不会造成不可逆的后果")
        }
        
        if (evaluation.pros.isNotEmpty()) {
            reasoning.add("主要优势：${evaluation.pros.joinToString("、")}")
        }
        
        if (evaluation.cons.isNotEmpty()) {
            reasoning.add("注意事项：${evaluation.cons.joinToString("、")}")
        }
        
        return reasoning
    }
    
    private fun generateAlternativeComparison(selectedPlan: SelectedPlan): List<AlternativeComparison> {
        return selectedPlan.alternatives.map { alt ->
            AlternativeComparison(
                planName = alt.name,
                difference = "耗时${alt.estimatedTime / 1000}秒，成功率${String.format("%.0f%%", alt.successProbability * 100)}",
                whyNotSelected = if (alt.successProbability < selectedPlan.plan.successProbability) 
                    "成功率较低" else "执行时间较长"
            )
        }
    }
    
    private fun categorizeConfidence(confidence: Float): DecisionConfidenceLevel {
        return when {
            confidence >= HIGH_CONFIDENCE_THRESHOLD -> DecisionConfidenceLevel.HIGH
            confidence >= MEDIUM_CONFIDENCE_THRESHOLD -> DecisionConfidenceLevel.MEDIUM
            else -> DecisionConfidenceLevel.LOW
        }
    }
    
    // ==================== 置信度评估 ====================
    
    /**
     * 评估操作置信度
     */
    fun assessConfidence(
        task: String,
        context: UnifiedContext?,
        semanticResult: TextSemanticResult?
    ): ConfidenceAssessment {
        LogManager.d(TAG, "评估操作置信度")
        
        var confidence = 0.5f
        val factors = mutableListOf<ConfidenceFactor>()
        
        // 意图清晰度
        semanticResult?.let {
            val intentClarity = if (it.intent != SemanticIntent.UNKNOWN) 0.2f else 0f
            confidence += intentClarity
            factors.add(ConfidenceFactor("意图识别", intentClarity, it.intent.name))
        }
        
        // 实体完整度
        semanticResult?.let {
            val entityScore = (it.entities.size * 0.1f).coerceAtMost(0.2f)
            confidence += entityScore
            factors.add(ConfidenceFactor("实体识别", entityScore, "${it.entities.size}个实体"))
        }
        
        // 上下文匹配度
        context?.screenContext?.let {
            val contextMatch = if (it.pageState == PageState.READY) 0.1f else 0f
            confidence += contextMatch
            factors.add(ConfidenceFactor("页面状态", contextMatch, it.pageState.name))
        }
        
        // 历史成功率
        val historyScore = calculateHistoricalSuccessRate(task)
        confidence += historyScore * 0.2f
        factors.add(ConfidenceFactor("历史成功率", historyScore * 0.2f, 
            String.format("%.0f%%", historyScore * 100)))
        
        confidence = confidence.coerceIn(0f, 1f)
        
        return ConfidenceAssessment(
            overallConfidence = confidence,
            level = categorizeConfidence(confidence),
            factors = factors,
            recommendation = generateConfidenceRecommendation(confidence)
        )
    }
    
    private fun calculateHistoricalSuccessRate(task: String): Float {
        val similarTasks = decisionHistory.filter { 
            it.task.contains(task.take(10)) || task.contains(it.task.take(10))
        }
        
        if (similarTasks.isEmpty()) return 0.5f
        
        return similarTasks.count { it.success }.toFloat() / similarTasks.size
    }
    
    private fun generateConfidenceRecommendation(confidence: Float): String {
        return when {
            confidence >= HIGH_CONFIDENCE_THRESHOLD -> "可以自动执行"
            confidence >= MEDIUM_CONFIDENCE_THRESHOLD -> "建议确认后执行"
            else -> "建议用户提供更多信息"
        }
    }
    
    // ==================== 不确定性处理 ====================
    
    /**
     * 处理低置信度情况
     */
    fun handleLowConfidence(
        task: String,
        assessment: ConfidenceAssessment
    ): LowConfidenceResponse {
        LogManager.d(TAG, "处理低置信度: ${assessment.overallConfidence}")
        
        val clarificationQuestions = generateClarificationQuestions(task, assessment)
        val suggestions = generateSuggestions(task)
        
        return LowConfidenceResponse(
            shouldProceed = assessment.level != DecisionConfidenceLevel.LOW,
            clarificationQuestions = clarificationQuestions,
            suggestions = suggestions,
            fallbackAction = if (assessment.level == DecisionConfidenceLevel.LOW) 
                "请您提供更详细的指令" else null
        )
    }
    
    private fun generateClarificationQuestions(task: String, assessment: ConfidenceAssessment): List<String> {
        val questions = mutableListOf<String>()
        
        // 根据缺失信息生成问题
        val lowFactors = assessment.factors.filter { it.score < 0.1f }
        
        if (lowFactors.any { it.name == "意图识别" }) {
            questions.add("您想要做什么操作呢？")
        }
        
        if (lowFactors.any { it.name == "实体识别" }) {
            if (task.contains("发") || task.contains("消息")) {
                questions.add("请问要发给谁？")
                questions.add("消息内容是什么？")
            }
            if (task.contains("打开")) {
                questions.add("请问要打开哪个应用？")
            }
        }
        
        return questions.take(3)
    }
    
    private fun generateSuggestions(task: String): List<String> {
        return listOf(
            "您可以说「打开微信」来打开应用",
            "您可以说「给张三发消息说你好」来发送消息",
            "您可以说「搜索天气」来搜索信息"
        ).take(3)
    }
    
    // ==================== 歧义消除 ====================
    
    /**
     * 处理模糊指令
     */
    fun handleAmbiguousInstruction(
        task: String,
        possibleInterpretations: List<String>
    ): AmbiguityResolution {
        LogManager.d(TAG, "处理歧义指令: $task")
        
        val interpretations = if (possibleInterpretations.isEmpty()) {
            generatePossibleInterpretations(task)
        } else {
            possibleInterpretations
        }
        
        val rankedInterpretations = interpretations.mapIndexed { index, interpretation ->
            RankedInterpretation(
                interpretation = interpretation,
                probability = (1.0f - index * 0.2f).coerceAtLeast(0.1f),
                reasoning = "基于${if (index == 0) "最常见" else "可能的"}理解"
            )
        }
        
        return AmbiguityResolution(
            originalInstruction = task,
            interpretations = rankedInterpretations,
            needsUserConfirmation = rankedInterpretations.size > 1,
            suggestedAction = if (rankedInterpretations.isNotEmpty()) 
                "您是想${rankedInterpretations[0].interpretation}吗？" else null
        )
    }
    
    private fun generatePossibleInterpretations(task: String): List<String> {
        val interpretations = mutableListOf<String>()
        
        if (task.contains("打开")) {
            val apps = listOf("微信", "淘宝", "浏览器", "设置")
            apps.forEach { app ->
                if (task.contains(app)) {
                    interpretations.add("打开$app")
                }
            }
            if (interpretations.isEmpty()) {
                interpretations.add("打开应用")
            }
        }
        
        if (task.contains("发")) {
            interpretations.add("发送微信消息")
            interpretations.add("发送短信")
        }
        
        return interpretations.take(3)
    }
    
    /**
     * 消除指令歧义
     */
    fun resolveAmbiguity(
        originalTask: String,
        userChoice: String
    ): ResolvedInstruction {
        LogManager.d(TAG, "用户选择: $userChoice")
        
        return ResolvedInstruction(
            originalTask = originalTask,
            resolvedTask = userChoice,
            wasAmbiguous = true,
            resolutionMethod = "用户确认"
        )
    }
    
    // ==================== 🔧 辅助方法 ====================
    
    private fun extractAppName(task: String): String {
        val appNames = listOf("微信", "QQ", "抖音", "淘宝", "支付宝", "百度", "美团", "饿了么", "滴滴", "京东")
        return appNames.find { task.contains(it) } ?: task.substringAfter("打开").trim()
    }
    
    private fun extractContact(task: String): String {
        val pattern = Regex("""(?:给|找|叫)\s*(\S+?)(?:\s*发|说|打)""")
        return pattern.find(task)?.groupValues?.get(1) ?: "联系人"
    }
    
    private fun extractMessageContent(task: String): String {
        val pattern = Regex("""(?:说|发|告诉.*?)\s*[：:"]?\s*(.+)$""")
        return pattern.find(task)?.groupValues?.get(1)?.trim('"', '"', '"') ?: "消息内容"
    }
    
    private fun extractSearchQuery(task: String): String {
        return task.replace(Regex("""^.*?搜索\s*"""), "").trim()
    }
    
    private fun extractProductName(task: String): String {
        return task.replace(Regex("""^.*?[买购]\s*"""), "").trim()
    }
    
    private fun extractSettingName(task: String): String {
        return task.replace(Regex("""^.*?设置\s*"""), "").trim()
    }
    
    /**
     * 📝 记录决策结果
     */
    fun recordDecision(task: String, plan: ExecutionPlan, success: Boolean) {
        decisionHistory.add(DecisionRecord(
            task = task,
            planId = plan.id,
            success = success,
            timestamp = System.currentTimeMillis()
        ))
        
        if (decisionHistory.size > HISTORY_CAPACITY) {
            decisionHistory.removeAt(0)
        }
    }
}

// ==================== 📦 数据类定义 ====================

// 任务类型
enum class DecisionTaskType { OPEN_APP, SEND_MESSAGE, SEARCH, PURCHASE, SETTINGS, MEDIA, GENERAL }

// 执行方案
data class ExecutionPlan(
    val id: String,
    val name: String,
    val description: String,
    val steps: List<PlanStep>,
    val estimatedTime: Long,
    val successProbability: Float,
    val riskLevel: DecisionRiskLevel
)

data class PlanStep(
    val index: Int,
    val description: String,
    val type: StepType
)

enum class StepType { SEARCH, ACTION, INPUT, CONFIRM, ANALYZE }

// 决策风险级别
enum class DecisionRiskLevel { LOW, MEDIUM, HIGH, SAFE }

// 约束
data class Constraint(val type: ConstraintType, val value: Any?)
enum class ConstraintType { TIME, RISK, SUCCESS_RATE, STEP_COUNT }

// 方案评估
data class PlanEvaluation(
    val plan: ExecutionPlan,
    val overallScore: Float,
    val successScore: Float,
    val timeScore: Float,
    val riskScore: Float,
    val complexityScore: Float,
    val contextScore: Float,
    val pros: List<String>,
    val cons: List<String>
)

// 用户偏好
data class UserPreferences(
    val successWeight: Float = 0.4f,
    val timeWeight: Float = 0.2f,
    val riskWeight: Float = 0.2f,
    val complexityWeight: Float = 0.2f,
    val maxWaitTime: Long = 30000L
)

// 选择策略
enum class SelectionStrategy(val description: String) {
    BEST_SCORE("综合评分最高"),
    LOWEST_RISK("风险最低"),
    FASTEST("执行最快"),
    HIGHEST_SUCCESS("成功率最高"),
    SIMPLEST("步骤最少")
}

// 选中的方案
data class SelectedPlan(
    val plan: ExecutionPlan,
    val evaluation: PlanEvaluation,
    val selectionReason: String,
    val alternatives: List<ExecutionPlan>,
    val confidence: Float
)

// 方案调整
data class PlanAdjustment(
    val adjustmentType: AdjustmentType,
    val modifiedPlan: ExecutionPlan,
    val reason: String
)

enum class AdjustmentType { CONTINUE, RETRY, MODIFY, ABORT }

data class StepExecutionResult(
    val stepIndex: Int,
    val success: Boolean,
    val error: String? = null,
    val retryable: Boolean = true,
    val retryCount: Int = 0
)

// 决策解释
data class DecisionExplanation(
    val summary: String,
    val detailedReasoning: List<String>,
    val scoreBreakdown: ScoreBreakdown,
    val alternativeComparison: List<AlternativeComparison>,
    val confidenceLevel: DecisionConfidenceLevel
)

data class ScoreBreakdown(
    val success: String,
    val time: String,
    val risk: String,
    val complexity: String
)

data class AlternativeComparison(
    val planName: String,
    val difference: String,
    val whyNotSelected: String
)

// 置信度
enum class DecisionConfidenceLevel { HIGH, MEDIUM, LOW }

data class ConfidenceAssessment(
    val overallConfidence: Float,
    val level: DecisionConfidenceLevel,
    val factors: List<ConfidenceFactor>,
    val recommendation: String
)

data class ConfidenceFactor(
    val name: String,
    val score: Float,
    val detail: String
)

// 低置信度响应
data class LowConfidenceResponse(
    val shouldProceed: Boolean,
    val clarificationQuestions: List<String>,
    val suggestions: List<String>,
    val fallbackAction: String?
)

// 歧义处理
data class AmbiguityResolution(
    val originalInstruction: String,
    val interpretations: List<RankedInterpretation>,
    val needsUserConfirmation: Boolean,
    val suggestedAction: String?
)

data class RankedInterpretation(
    val interpretation: String,
    val probability: Float,
    val reasoning: String
)

data class ResolvedInstruction(
    val originalTask: String,
    val resolvedTask: String,
    val wasAmbiguous: Boolean,
    val resolutionMethod: String
)

// 决策记录
data class DecisionRecord(
    val task: String,
    val planId: String,
    val success: Boolean,
    val timestamp: Long
)

// 决策状态
data class DecisionState(
    val currentTask: String,
    val selectedPlan: SelectedPlan?,
    val currentStep: Int,
    val status: DecisionStatus
)

enum class DecisionStatus { PLANNING, EXECUTING, ADJUSTING, COMPLETED, FAILED }
