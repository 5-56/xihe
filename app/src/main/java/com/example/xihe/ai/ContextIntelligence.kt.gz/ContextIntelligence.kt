package com.example.xihe.ai

import android.content.Context
import android.graphics.Rect
import com.example.xihe.utils.LogManager
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable
import java.util.concurrent.ConcurrentHashMap

/**
 * 上下文智能理解模块
 * 
 * 功能：
 * - 屏幕视觉理解
 * - 文本语义理解
 * - 用户行为理解
 * - 历史对话理解
 * - 任务上下文理解
 * - 记忆管理系统
 */
object ContextIntelligence {
    
    private const val TAG = "ContextIntelligence"
    
    // 短期记忆（最近对话）
    private val shortTermMemory = mutableListOf<MemoryItem>()
    private const val SHORT_TERM_CAPACITY = 20
    
    // 长期记忆（用户偏好、习惯）
    private val longTermMemory = ConcurrentHashMap<String, LongTermMemoryItem>()
    
    // 任务记忆（任务执行历史）
    private val taskMemory = mutableListOf<TaskMemoryItem>()
    private const val TASK_MEMORY_CAPACITY = 50
    
    // 场景记忆（不同场景的上下文）
    private val sceneMemory = ConcurrentHashMap<String, SceneMemoryItem>()
    
    // 当前上下文状态
    private val _currentContext = MutableStateFlow<UnifiedContext?>(null)
    val currentContext = _currentContext.asStateFlow()
    
    // 用户行为模式
    private val userBehaviorPatterns = mutableListOf<BehaviorPattern>()
    
    // ==================== 屏幕视觉理解 ====================
    
    /**
     * 理解屏幕视觉内容
     */
    fun understandScreenVisual(rootNode: AccessibilityNodeInfo?): ScreenUnderstanding {
        if (rootNode == null) return ScreenUnderstanding.empty()
        
        LogManager.d(TAG, "分析屏幕视觉内容")
        
        // 识别页面类型
        val pageType = identifyPageType(rootNode)
        
        // 识别主要区域
        val regions = identifyScreenRegions(rootNode)
        
        // 识别可交互元素
        val interactiveElements = findInteractiveElements(rootNode)
        
        // 识别当前焦点
        val focusedElement = findFocusedElement(rootNode)
        
        // 识别页面状态
        val pageState = analyzePageState(rootNode)
        
        // 识别内容层次
        val contentHierarchy = analyzeContentHierarchy(rootNode)
        
        return ScreenUnderstanding(
            pageType = pageType,
            regions = regions,
            interactiveElements = interactiveElements,
            focusedElement = focusedElement,
            pageState = pageState,
            contentHierarchy = contentHierarchy,
            analyzedAt = System.currentTimeMillis()
        )
    }
    
    private fun identifyPageType(rootNode: AccessibilityNodeInfo): PageType {
        val allText = StringBuilder()
        traverseNodes(rootNode) { node ->
            allText.append(node.text?.toString() ?: "")
            allText.append(node.contentDescription?.toString() ?: "")
        }
        
        val text = allText.toString().lowercase()
        
        return when {
            text.contains("登录") || text.contains("login") -> PageType.LOGIN
            text.contains("注册") || text.contains("register") -> PageType.REGISTER
            text.contains("首页") || text.contains("home") -> PageType.HOME
            text.contains("搜索结果") -> PageType.SEARCH_RESULTS
            text.contains("聊天") || text.contains("消息") -> PageType.CHAT
            text.contains("设置") || text.contains("settings") -> PageType.SETTINGS
            text.contains("购物车") -> PageType.SHOPPING_CART
            text.contains("支付") || text.contains("付款") -> PageType.PAYMENT
            text.contains("订单") -> PageType.ORDER
            text.contains("详情") || text.contains("detail") -> PageType.DETAIL
            text.contains("列表") -> PageType.LIST
            else -> PageType.UNKNOWN
        }
    }
    
    private fun identifyScreenRegions(rootNode: AccessibilityNodeInfo): List<ScreenRegion> {
        val regions = mutableListOf<ScreenRegion>()
        val screenRect = Rect()
        rootNode.getBoundsInScreen(screenRect)
        val screenHeight = screenRect.height()
        
        traverseNodes(rootNode) { node ->
            val rect = Rect()
            node.getBoundsInScreen(rect)
            
            val regionType = when {
                rect.top < screenHeight * 0.1 -> RegionType.HEADER
                rect.bottom > screenHeight * 0.9 -> RegionType.FOOTER
                rect.left < screenRect.width() * 0.2 && rect.height() > screenHeight * 0.5 -> RegionType.SIDEBAR
                else -> RegionType.CONTENT
            }
            
            if (rect.width() > 100 && rect.height() > 100) {
                regions.add(ScreenRegion(
                    type = regionType,
                    bounds = rect,
                    hasInteractiveElements = node.isClickable || node.isScrollable
                ))
            }
        }
        
        return regions.distinctBy { "${it.type}_${it.bounds.top}" }.take(10)
    }
    
    private fun findInteractiveElements(rootNode: AccessibilityNodeInfo): List<InteractiveElement> {
        val elements = mutableListOf<InteractiveElement>()
        
        traverseNodes(rootNode) { node ->
            if (node.isClickable || node.isEditable || node.isScrollable || node.isCheckable) {
                val rect = Rect()
                node.getBoundsInScreen(rect)
                
                elements.add(InteractiveElement(
                    text = node.text?.toString() ?: node.contentDescription?.toString(),
                    bounds = rect,
                    isClickable = node.isClickable,
                    isEditable = node.isEditable,
                    isScrollable = node.isScrollable,
                    isCheckable = node.isCheckable,
                    elementType = detectElementType(node)
                ))
            }
        }
        
        return elements.take(50)
    }
    
    private fun detectElementType(node: AccessibilityNodeInfo): ElementType {
        val className = node.className?.toString()?.lowercase() ?: ""
        val text = node.text?.toString()?.lowercase() ?: ""
        
        return when {
            className.contains("button") -> ElementType.BUTTON
            className.contains("edittext") || node.isEditable -> ElementType.INPUT
            className.contains("checkbox") || node.isCheckable -> ElementType.CHECKBOX
            className.contains("image") -> ElementType.IMAGE
            className.contains("recycler") || className.contains("listview") -> ElementType.LIST
            text.contains("搜索") -> ElementType.SEARCH
            text.contains("返回") || text.contains("back") -> ElementType.BACK
            text.contains("确定") || text.contains("确认") -> ElementType.CONFIRM
            text.contains("取消") -> ElementType.CANCEL
            else -> ElementType.OTHER
        }
    }
    
    private fun findFocusedElement(rootNode: AccessibilityNodeInfo): FocusedElement? {
        var focused: FocusedElement? = null
        
        traverseNodes(rootNode) { node ->
            if (node.isFocused || node.isAccessibilityFocused) {
                val rect = Rect()
                node.getBoundsInScreen(rect)
                focused = FocusedElement(
                    text = node.text?.toString(),
                    bounds = rect,
                    isEditable = node.isEditable
                )
            }
        }
        
        return focused
    }
    
    private fun analyzePageState(rootNode: AccessibilityNodeInfo): PageState {
        var hasLoading = false
        var hasError = false
        var hasEmpty = false
        var hasContent = false
        
        traverseNodes(rootNode) { node ->
            val text = (node.text?.toString() ?: "") + (node.contentDescription?.toString() ?: "")
            val className = node.className?.toString() ?: ""
            
            if (text.contains("加载") || text.contains("loading") || className.contains("Progress")) {
                hasLoading = true
            }
            if (text.contains("错误") || text.contains("error") || text.contains("失败")) {
                hasError = true
            }
            if (text.contains("暂无") || text.contains("空空") || text.contains("no data")) {
                hasEmpty = true
            }
            if (text.length > 20) {
                hasContent = true
            }
        }
        
        return when {
            hasLoading -> PageState.LOADING
            hasError -> PageState.ERROR
            hasEmpty -> PageState.EMPTY
            hasContent -> PageState.READY
            else -> PageState.UNKNOWN
        }
    }
    
    private fun analyzeContentHierarchy(rootNode: AccessibilityNodeInfo): ContentHierarchy {
        var maxDepth = 0
        var totalNodes = 0
        
        fun countDepth(node: AccessibilityNodeInfo, depth: Int) {
            totalNodes++
            maxDepth = maxOf(maxDepth, depth)
            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { countDepth(it, depth + 1) }
            }
        }
        
        countDepth(rootNode, 0)
        
        return ContentHierarchy(
            maxDepth = maxDepth,
            totalNodes = totalNodes,
            complexity = when {
                totalNodes > 500 -> ComplexityLevel.VERY_HIGH
                totalNodes > 200 -> ComplexityLevel.HIGH
                totalNodes > 100 -> ComplexityLevel.MEDIUM
                else -> ComplexityLevel.LOW
            }
        )
    }
    
    // ==================== 文本语义理解 ====================
    
    /**
     * 理解文本语义
     */
    fun understandTextSemantics(text: String): TextSemanticResult {
        LogManager.d(TAG, "分析文本语义: ${text.take(50)}...")
        
        // 意图识别
        val intent = recognizeIntent(text)
        
        // 实体提取
        val entities = extractEntities(text)
        
        // 情感分析
        val sentiment = analyzeSentiment(text)
        
        // 关键词提取
        val keywords = extractKeywords(text)
        
        // 话题识别
        val topics = identifyTopics(text)
        
        // 动作提取
        val actions = extractActions(text)
        
        return TextSemanticResult(
            originalText = text,
            intent = intent,
            entities = entities,
            sentiment = sentiment,
            keywords = keywords,
            topics = topics,
            actions = actions,
            confidence = calculateSemanticConfidence(intent, entities)
        )
    }
    
    private fun recognizeIntent(text: String): SemanticIntent {
        val lowerText = text.lowercase()
        
        return when {
            lowerText.contains(Regex("打开|启动|运行")) -> SemanticIntent.OPEN_APP
            lowerText.contains(Regex("发送|发|给.*说")) -> SemanticIntent.SEND_MESSAGE
            lowerText.contains(Regex("搜索|查找|找")) -> SemanticIntent.SEARCH
            lowerText.contains(Regex("播放|听|看")) -> SemanticIntent.PLAY_MEDIA
            lowerText.contains(Regex("设置|调|改")) -> SemanticIntent.CHANGE_SETTINGS
            lowerText.contains(Regex("提醒|闹钟|定时")) -> SemanticIntent.SET_REMINDER
            lowerText.contains(Regex("导航|去|怎么走")) -> SemanticIntent.NAVIGATE
            lowerText.contains(Regex("购买|买|下单")) -> SemanticIntent.PURCHASE
            lowerText.contains(Regex("取消|退出|关闭")) -> SemanticIntent.CANCEL
            lowerText.contains(Regex("帮助|怎么|如何")) -> SemanticIntent.HELP
            lowerText.contains("?") || lowerText.contains("？") -> SemanticIntent.QUERY
            else -> SemanticIntent.UNKNOWN
        }
    }
    
    private fun extractEntities(text: String): Map<IntelligenceEntityType, List<String>> {
        val entities = mutableMapOf<IntelligenceEntityType, MutableList<String>>()
        
        // 时间实体
        val timePatterns = listOf(
            Regex("""\d{1,2}[点时:：]\d{0,2}分?"""),
            Regex("""今天|明天|后天|昨天|上午|下午|晚上|中午"""),
            Regex("""周[一二三四五六日天]"""),
            Regex("""\d{1,2}月\d{1,2}[日号]""")
        )
        timePatterns.forEach { pattern ->
            pattern.findAll(text).forEach {
                entities.getOrPut(IntelligenceEntityType.TIME) { mutableListOf() }.add(it.value)
            }
        }
        
        // 地点实体
        val locationPattern = Regex("""(?:在|到|去)\s*([^\s,，。！!?？]{2,10}?)(?:[见面会]|$)""")
        locationPattern.findAll(text).forEach {
            entities.getOrPut(IntelligenceEntityType.LOCATION) { mutableListOf() }.add(it.groupValues[1])
        }
        
        // 人名实体
        val personPattern = Regex("""(?:给|找|叫|告诉)\s*([^\s,，。！!?？]{2,4})""")
        personPattern.findAll(text).forEach {
            entities.getOrPut(IntelligenceEntityType.PERSON) { mutableListOf() }.add(it.groupValues[1])
        }
        
        // 数量实体
        val numberPattern = Regex("""\d+(?:\.\d+)?\s*(?:个|元|块|份|次|分钟|小时)""")
        numberPattern.findAll(text).forEach {
            entities.getOrPut(IntelligenceEntityType.NUMBER) { mutableListOf() }.add(it.value)
        }
        
        // 应用名实体
        val appNames = listOf("微信", "QQ", "抖音", "淘宝", "支付宝", "百度", "美团", "饿了么", "滴滴")
        appNames.forEach { app ->
            if (text.contains(app)) {
                entities.getOrPut(IntelligenceEntityType.APP_NAME) { mutableListOf() }.add(app)
            }
        }
        
        return entities
    }
    
    private fun analyzeSentiment(text: String): SentimentAnalysis {
        val positiveWords = listOf("好", "棒", "赞", "喜欢", "开心", "感谢", "谢谢", "太好了", "不错")
        val negativeWords = listOf("不", "差", "烦", "讨厌", "生气", "失望", "糟糕", "难过")
        
        var positiveScore = 0f
        var negativeScore = 0f
        
        positiveWords.forEach { if (text.contains(it)) positiveScore += 0.2f }
        negativeWords.forEach { if (text.contains(it)) negativeScore += 0.2f }
        
        val score = (positiveScore - negativeScore).coerceIn(-1f, 1f)
        
        return SentimentAnalysis(
            sentiment = when {
                score > 0.3f -> Sentiment.POSITIVE
                score < -0.3f -> Sentiment.NEGATIVE
                else -> Sentiment.NEUTRAL
            },
            score = score,
            confidence = (kotlin.math.abs(score) + 0.5f).coerceAtMost(1f)
        )
    }
    
    private fun extractKeywords(text: String): List<String> {
        val stopWords = setOf("的", "了", "是", "在", "我", "你", "他", "她", "它", "们", "这", "那", "有", "和", "与")
        
        return text.split(Regex("""[\s,，。！!?？；;：:、]+"""))
            .filter { it.length >= 2 && it !in stopWords }
            .distinct()
            .take(10)
    }
    
    private fun identifyTopics(text: String): List<String> {
        val topics = mutableListOf<String>()
        val lowerText = text.lowercase()
        
        if (lowerText.contains(Regex("工作|项目|会议|报告"))) topics.add("工作")
        if (lowerText.contains(Regex("吃|喝|餐|饭"))) topics.add("餐饮")
        if (lowerText.contains(Regex("玩|游戏|电影|音乐"))) topics.add("娱乐")
        if (lowerText.contains(Regex("买|购|钱|付"))) topics.add("购物")
        if (lowerText.contains(Regex("去|来|走|回|出发"))) topics.add("出行")
        if (lowerText.contains(Regex("学|课|考|书"))) topics.add("学习")
        if (lowerText.contains(Regex("健康|医|药|病"))) topics.add("健康")
        
        return topics.ifEmpty { listOf("日常") }
    }
    
    private fun extractActions(text: String): List<ActionItem> {
        val actions = mutableListOf<ActionItem>()
        
        val actionPatterns = listOf(
            Regex("""打开\s*(\S+)""") to ActionType.OPEN,
            Regex("""发送?\s*(\S+)?""") to ActionType.SEND,
            Regex("""搜索\s*(\S+)""") to ActionType.SEARCH,
            Regex("""播放\s*(\S+)""") to ActionType.PLAY,
            Regex("""设置\s*(\S+)""") to ActionType.SET,
            Regex("""取消\s*(\S+)?""") to ActionType.CANCEL
        )
        
        actionPatterns.forEach { (pattern, type) ->
            pattern.find(text)?.let { match ->
                actions.add(ActionItem(
                    type = type,
                    target = match.groupValues.getOrNull(1)?.takeIf { it.isNotBlank() },
                    rawText = match.value
                ))
            }
        }
        
        return actions
    }
    
    private fun calculateSemanticConfidence(intent: SemanticIntent, entities: Map<IntelligenceEntityType, List<String>>): Float {
        var confidence = 0.5f
        
        if (intent != SemanticIntent.UNKNOWN) confidence += 0.2f
        if (entities.isNotEmpty()) confidence += 0.1f * entities.size.coerceAtMost(3)
        
        return confidence.coerceAtMost(0.95f)
    }
    
    // ==================== 用户行为理解 ====================
    
    /**
     * 理解用户行为意图
     */
    fun understandUserBehavior(
        currentAction: String,
        screenContext: ScreenUnderstanding?,
        recentActions: List<String> = emptyList()
    ): UserBehaviorUnderstanding {
        LogManager.d(TAG, "分析用户行为意图")
        
        // 识别行为模式
        val behaviorPattern = identifyBehaviorPattern(currentAction, recentActions)
        
        // 预测下一步
        val predictedNextActions = predictNextActions(currentAction, screenContext, behaviorPattern)
        
        // 识别用户目标
        val inferredGoal = inferUserGoal(currentAction, recentActions, screenContext)
        
        // 检测异常行为
        val isAnomalous = detectAnomalousBehavior(currentAction, behaviorPattern)
        
        return UserBehaviorUnderstanding(
            currentAction = currentAction,
            behaviorPattern = behaviorPattern,
            predictedNextActions = predictedNextActions,
            inferredGoal = inferredGoal,
            isAnomalous = isAnomalous,
            confidence = calculateBehaviorConfidence(behaviorPattern, predictedNextActions)
        )
    }
    
    private fun identifyBehaviorPattern(currentAction: String, recentActions: List<String>): BehaviorPattern? {
        // 查找匹配的行为模式
        return userBehaviorPatterns.find { pattern ->
            pattern.actionSequence.any { currentAction.contains(it, ignoreCase = true) }
        }
    }
    
    private fun predictNextActions(
        currentAction: String,
        screenContext: ScreenUnderstanding?,
        pattern: BehaviorPattern?
    ): List<PredictedAction> {
        val predictions = mutableListOf<PredictedAction>()
        
        // 基于行为模式预测
        pattern?.let {
            val currentIndex = it.actionSequence.indexOfFirst { action ->
                currentAction.contains(action, ignoreCase = true)
            }
            if (currentIndex >= 0 && currentIndex < it.actionSequence.size - 1) {
                predictions.add(PredictedAction(
                    action = it.actionSequence[currentIndex + 1],
                    probability = 0.8f,
                    source = "行为模式"
                ))
            }
        }
        
        // 基于页面上下文预测
        screenContext?.let { context ->
            when (context.pageType) {
                PageType.LOGIN -> predictions.add(PredictedAction("输入密码", 0.7f, "页面上下文"))
                PageType.SEARCH_RESULTS -> predictions.add(PredictedAction("点击结果", 0.7f, "页面上下文"))
                PageType.SHOPPING_CART -> predictions.add(PredictedAction("结算", 0.6f, "页面上下文"))
                PageType.CHAT -> predictions.add(PredictedAction("发送消息", 0.7f, "页面上下文"))
                else -> {}
            }
        }
        
        return predictions.sortedByDescending { it.probability }.take(5)
    }
    
    private fun inferUserGoal(
        currentAction: String,
        recentActions: List<String>,
        screenContext: ScreenUnderstanding?
    ): UserGoal {
        val allActions = recentActions + currentAction
        val actionText = allActions.joinToString(" ")
        
        return when {
            actionText.contains(Regex("发.*消息|聊天")) -> UserGoal("发送消息", GoalCategory.COMMUNICATION)
            actionText.contains(Regex("搜索|查找")) -> UserGoal("搜索信息", GoalCategory.INFORMATION)
            actionText.contains(Regex("购买|下单|付款")) -> UserGoal("完成购物", GoalCategory.SHOPPING)
            actionText.contains(Regex("播放|听|看")) -> UserGoal("娱乐消遣", GoalCategory.ENTERTAINMENT)
            actionText.contains(Regex("设置|调整")) -> UserGoal("修改设置", GoalCategory.SETTINGS)
            screenContext?.pageType == PageType.LOGIN -> UserGoal("登录账号", GoalCategory.AUTHENTICATION)
            else -> UserGoal("浏览内容", GoalCategory.BROWSING)
        }
    }
    
    private fun detectAnomalousBehavior(currentAction: String, pattern: BehaviorPattern?): Boolean {
        // 简单异常检测：检查是否与历史模式差异太大
        return pattern == null && currentAction.length > 50
    }
    
    private fun calculateBehaviorConfidence(pattern: BehaviorPattern?, predictions: List<PredictedAction>): Float {
        var confidence = 0.5f
        if (pattern != null) confidence += 0.2f
        if (predictions.isNotEmpty()) confidence += 0.1f * predictions.size.coerceAtMost(3)
        return confidence.coerceAtMost(0.9f)
    }
    
    // ==================== 历史对话理解 ====================
    
    /**
     * 理解历史对话上下文
     */
    fun understandDialogueContext(
        currentInput: String,
        dialogueHistory: List<DialogueTurn> = emptyList()
    ): DialogueUnderstanding {
        LogManager.d(TAG, "分析对话上下文")
        
        // 识别对话主题
        val topics = identifyDialogueTopics(dialogueHistory + DialogueTurn(currentInput, "", System.currentTimeMillis()))
        
        // 识别上下文引用
        val contextReferences = findContextReferences(currentInput, dialogueHistory)
        
        // 解析代词指代
        val resolvedPronouns = resolvePronounReferences(currentInput, dialogueHistory)
        
        // 判断是否需要澄清
        val needsClarification = checkNeedsClarification(currentInput, contextReferences)
        
        // 生成上下文增强的输入
        val enhancedInput = enhanceWithContext(currentInput, resolvedPronouns, dialogueHistory)
        
        return DialogueUnderstanding(
            currentInput = currentInput,
            enhancedInput = enhancedInput,
            topics = topics,
            contextReferences = contextReferences,
            resolvedPronouns = resolvedPronouns,
            needsClarification = needsClarification,
            suggestedClarifications = if (needsClarification) generateClarifications(currentInput) else emptyList()
        )
    }
    
    private fun identifyDialogueTopics(turns: List<DialogueTurn>): List<String> {
        val allText = turns.joinToString(" ") { it.userInput + " " + it.aiResponse }
        return identifyTopics(allText)
    }
    
    private fun findContextReferences(currentInput: String, history: List<DialogueTurn>): List<ContextReference> {
        val references = mutableListOf<ContextReference>()
        
        // 检测"这个"、"那个"等指示代词
        val demonstratives = listOf("这个", "那个", "这", "那", "它", "他", "她")
        demonstratives.forEach { pronoun ->
            if (currentInput.contains(pronoun)) {
                // 尝试从历史中找到指代对象
                val referent = findReferentInHistory(pronoun, history)
                references.add(ContextReference(
                    pronoun = pronoun,
                    referent = referent,
                    confidence = if (referent != null) 0.8f else 0.3f
                ))
            }
        }
        
        return references
    }
    
    private fun findReferentInHistory(pronoun: String, history: List<DialogueTurn>): String? {
        if (history.isEmpty()) return null
        
        // 简单策略：从最近的对话中提取名词短语
        val lastTurn = history.last()
        val nouns = extractNouns(lastTurn.userInput + " " + lastTurn.aiResponse)
        return nouns.firstOrNull()
    }
    
    private fun extractNouns(text: String): List<String> {
        // 简单的名词提取（实际应用中可以使用NLP库）
        return text.split(Regex("""[\s,，。！!?？；;：:、]+"""))
            .filter { it.length >= 2 && !it.matches(Regex("""^[的了是在我你他她它们这那有和与].*""")) }
            .take(5)
    }
    
    private fun resolvePronounReferences(currentInput: String, history: List<DialogueTurn>): Map<String, String> {
        val resolved = mutableMapOf<String, String>()
        
        val references = findContextReferences(currentInput, history)
        references.forEach { ref ->
            ref.referent?.let { resolved[ref.pronoun] = it }
        }
        
        return resolved
    }
    
    private fun checkNeedsClarification(currentInput: String, references: List<ContextReference>): Boolean {
        // 如果有低置信度的引用，需要澄清
        return references.any { it.confidence < 0.5f && it.referent == null }
    }
    
    private fun generateClarifications(currentInput: String): List<String> {
        return listOf(
            "您是指哪个具体的内容呢？",
            "能请您说得更具体一些吗？",
            "您想要我操作什么呢？"
        )
    }
    
    private fun enhanceWithContext(
        currentInput: String,
        resolvedPronouns: Map<String, String>,
        history: List<DialogueTurn>
    ): String {
        var enhanced = currentInput
        resolvedPronouns.forEach { (pronoun, referent) ->
            enhanced = enhanced.replace(pronoun, referent)
        }
        return enhanced
    }
    
    // ==================== 任务上下文理解 ====================
    
    /**
     * 理解任务执行上下文
     */
    fun understandTaskContext(
        currentTask: String,
        taskHistory: List<TaskExecution> = emptyList(),
        screenContext: ScreenUnderstanding? = null
    ): TaskContextUnderstanding {
        LogManager.d(TAG, "分析任务上下文")
        
        // 识别任务类型
        val taskType = identifyTaskType(currentTask)
        
        // 识别前置任务
        val prerequisites = identifyPrerequisites(currentTask, taskHistory)
        
        // 识别相关历史任务
        val relatedTasks = findRelatedTasks(currentTask, taskHistory)
        
        // 评估任务复杂度
        val complexity = assessTaskComplexity(currentTask, screenContext)
        
        // 预估完成时间
        val estimatedDuration = estimateTaskDuration(taskType, complexity, relatedTasks)
        
        // 识别潜在风险
        val risks = identifyTaskRisks(currentTask, taskType)
        
        return TaskContextUnderstanding(
            currentTask = currentTask,
            taskType = taskType,
            prerequisites = prerequisites,
            relatedTasks = relatedTasks,
            complexity = complexity,
            estimatedDuration = estimatedDuration,
            risks = risks
        )
    }
    
    private fun identifyTaskType(task: String): ContextTaskType {
        val lowerTask = task.lowercase()
        return when {
            lowerTask.contains("发送") || lowerTask.contains("消息") -> ContextTaskType.MESSAGE
            lowerTask.contains("搜索") -> ContextTaskType.SEARCH
            lowerTask.contains("打开") || lowerTask.contains("启动") -> ContextTaskType.OPEN_APP
            lowerTask.contains("设置") -> ContextTaskType.SETTINGS
            lowerTask.contains("购买") || lowerTask.contains("下单") -> ContextTaskType.PURCHASE
            lowerTask.contains("播放") -> ContextTaskType.MEDIA
            lowerTask.contains("导航") -> ContextTaskType.NAVIGATION
            else -> ContextTaskType.GENERAL
        }
    }
    
    private fun identifyPrerequisites(task: String, history: List<TaskExecution>): List<String> {
        val prerequisites = mutableListOf<String>()
        
        if (task.contains("发送") && !history.any { it.task.contains("打开") }) {
            prerequisites.add("打开相应的应用")
        }
        if (task.contains("支付") && !history.any { it.task.contains("选择") }) {
            prerequisites.add("选择商品")
        }
        
        return prerequisites
    }
    
    private fun findRelatedTasks(task: String, history: List<TaskExecution>): List<TaskExecution> {
        val keywords = extractKeywords(task)
        return history.filter { execution ->
            keywords.any { keyword -> execution.task.contains(keyword) }
        }.take(5)
    }
    
    private fun assessTaskComplexity(task: String, screenContext: ScreenUnderstanding?): ContextTaskComplexity {
        var score = 0
        
        // 基于任务描述复杂度
        if (task.length > 50) score += 1
        if (task.contains("然后") || task.contains("接着")) score += 1
        
        // 基于屏幕复杂度
        screenContext?.let {
            if (it.contentHierarchy.complexity == ComplexityLevel.HIGH) score += 1
            if (it.contentHierarchy.complexity == ComplexityLevel.VERY_HIGH) score += 2
        }
        
        return when {
            score >= 3 -> ContextTaskComplexity.HIGH
            score >= 2 -> ContextTaskComplexity.MEDIUM
            else -> ContextTaskComplexity.LOW
        }
    }
    
    private fun estimateTaskDuration(
        taskType: ContextTaskType,
        complexity: ContextTaskComplexity,
        relatedTasks: List<TaskExecution>
    ): Long {
        // 基础时间（毫秒）
        val baseTime = when (taskType) {
            ContextTaskType.MESSAGE -> 5000L
            ContextTaskType.SEARCH -> 3000L
            ContextTaskType.OPEN_APP -> 2000L
            ContextTaskType.PURCHASE -> 15000L
            else -> 5000L
        }
        
        // 复杂度调整
        val complexityMultiplier = when (complexity) {
            ContextTaskComplexity.HIGH -> 2.0
            ContextTaskComplexity.MEDIUM -> 1.5
            ContextTaskComplexity.LOW -> 1.0
        }
        
        // 基于历史调整
        val historicalAvg = if (relatedTasks.isNotEmpty()) {
            relatedTasks.mapNotNull { it.duration }.average().toLong()
        } else baseTime
        
        return ((baseTime + historicalAvg) / 2 * complexityMultiplier).toLong()
    }
    
    private fun identifyTaskRisks(task: String, taskType: ContextTaskType): List<TaskRisk> {
        val risks = mutableListOf<TaskRisk>()
        
        when (taskType) {
            ContextTaskType.PURCHASE -> {
                risks.add(TaskRisk("支付风险", "涉及金钱交易，请确认金额", ContextRiskLevel.MEDIUM))
            }
            ContextTaskType.MESSAGE -> {
                if (task.contains("所有人") || task.contains("群发")) {
                    risks.add(TaskRisk("批量发送", "将发送给多人，请确认内容", ContextRiskLevel.LOW))
                }
            }
            ContextTaskType.SETTINGS -> {
                risks.add(TaskRisk("设置更改", "将更改系统设置", ContextRiskLevel.LOW))
            }
            else -> {}
        }
        
        return risks
    }
    
    // ==================== 记忆管理 ====================
    
    /**
     * 保存到短期记忆
     */
    fun saveToShortTermMemory(item: MemoryItem) {
        shortTermMemory.add(item)
        if (shortTermMemory.size > SHORT_TERM_CAPACITY) {
            // 将旧记忆转移到长期记忆（如果重要）
            val oldest = shortTermMemory.removeAt(0)
            if (oldest.importance >= 0.7f) {
                promoteToLongTermMemory(oldest)
            }
        }
        LogManager.d(TAG, "保存短期记忆: ${item.content.take(30)}...")
    }
    
    /**
     * 保存到长期记忆
     */
    fun saveToLongTermMemory(key: String, item: LongTermMemoryItem) {
        longTermMemory[key] = item
        LogManager.d(TAG, "保存长期记忆: $key")
    }
    
    private fun promoteToLongTermMemory(item: MemoryItem) {
        val key = "memory_${System.currentTimeMillis()}"
        longTermMemory[key] = LongTermMemoryItem(
            content = item.content,
            category = item.category,
            importance = item.importance,
            accessCount = 1,
            createdAt = item.timestamp,
            lastAccessedAt = System.currentTimeMillis()
        )
    }
    
    /**
     * 保存任务记忆
     */
    fun saveTaskMemory(item: TaskMemoryItem) {
        taskMemory.add(item)
        if (taskMemory.size > TASK_MEMORY_CAPACITY) {
            taskMemory.removeAt(0)
        }
        LogManager.d(TAG, "保存任务记忆: ${item.taskName}")
    }
    
    /**
     * 保存场景记忆
     */
    fun saveSceneMemory(sceneId: String, item: SceneMemoryItem) {
        sceneMemory[sceneId] = item
        LogManager.d(TAG, "保存场景记忆: $sceneId")
    }
    
    /**
     * 检索相关记忆
     */
    fun retrieveMemory(query: String, limit: Int = 5): MemoryRetrievalResult {
        val keywords = extractKeywords(query)
        
        // 检索短期记忆
        val shortTermResults = shortTermMemory
            .filter { memory -> keywords.any { memory.content.contains(it) } }
            .sortedByDescending { it.importance }
            .take(limit)
        
        // 检索长期记忆
        val longTermResults = longTermMemory.values
            .filter { memory -> keywords.any { memory.content.contains(it) } }
            .sortedByDescending { it.importance }
            .take(limit)
        
        // 检索任务记忆
        val taskResults = taskMemory
            .filter { memory -> keywords.any { memory.taskName.contains(it) } }
            .sortedByDescending { it.completedAt }
            .take(limit)
        
        return MemoryRetrievalResult(
            shortTermMemories = shortTermResults,
            longTermMemories = longTermResults.toList(),
            taskMemories = taskResults,
            totalResults = shortTermResults.size + longTermResults.size + taskResults.size
        )
    }
    
    /**
     * 更新上下文
     */
    fun updateContext(context: UnifiedContext) {
        _currentContext.value = context
    }
    
    /**
     * 学习用户行为模式
     */
    fun learnBehaviorPattern(pattern: BehaviorPattern) {
        val existing = userBehaviorPatterns.find { it.name == pattern.name }
        if (existing != null) {
            val index = userBehaviorPatterns.indexOf(existing)
            userBehaviorPatterns[index] = pattern.copy(
                frequency = existing.frequency + 1,
                lastOccurrence = System.currentTimeMillis()
            )
        } else {
            userBehaviorPatterns.add(pattern)
        }
        LogManager.d(TAG, "学习行为模式: ${pattern.name}")
    }
    
    // ==================== 辅助方法 ====================
    
    private fun traverseNodes(node: AccessibilityNodeInfo, action: (AccessibilityNodeInfo) -> Unit) {
        action(node)
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { traverseNodes(it, action) }
        }
    }
}

// ==================== 📦 数据类定义 ====================

// 屏幕理解
data class ScreenUnderstanding(
    val pageType: PageType,
    val regions: List<ScreenRegion>,
    val interactiveElements: List<InteractiveElement>,
    val focusedElement: FocusedElement?,
    val pageState: PageState,
    val contentHierarchy: ContentHierarchy,
    val analyzedAt: Long
) {
    companion object {
        fun empty() = ScreenUnderstanding(
            PageType.UNKNOWN, emptyList(), emptyList(), null,
            PageState.UNKNOWN, ContentHierarchy(0, 0, ComplexityLevel.LOW), 0
        )
    }
}

enum class PageType { LOGIN, REGISTER, HOME, SEARCH_RESULTS, CHAT, SETTINGS, SHOPPING_CART, PAYMENT, ORDER, DETAIL, LIST, UNKNOWN }
enum class PageState { LOADING, READY, ERROR, EMPTY, UNKNOWN }

data class ScreenRegion(val type: RegionType, val bounds: Rect, val hasInteractiveElements: Boolean)
enum class RegionType { HEADER, FOOTER, SIDEBAR, CONTENT }

data class InteractiveElement(
    val text: String?,
    val bounds: Rect,
    val isClickable: Boolean,
    val isEditable: Boolean,
    val isScrollable: Boolean,
    val isCheckable: Boolean,
    val elementType: ElementType
)

enum class ElementType { BUTTON, INPUT, CHECKBOX, IMAGE, LIST, SEARCH, BACK, CONFIRM, CANCEL, OTHER }

data class FocusedElement(val text: String?, val bounds: Rect, val isEditable: Boolean)
data class ContentHierarchy(val maxDepth: Int, val totalNodes: Int, val complexity: ComplexityLevel)
enum class ComplexityLevel { LOW, MEDIUM, HIGH, VERY_HIGH }

// 文本语义
data class TextSemanticResult(
    val originalText: String,
    val intent: SemanticIntent,
    val entities: Map<IntelligenceEntityType, List<String>>,
    val sentiment: SentimentAnalysis,
    val keywords: List<String>,
    val topics: List<String>,
    val actions: List<ActionItem>,
    val confidence: Float
)

enum class SemanticIntent { OPEN_APP, SEND_MESSAGE, SEARCH, PLAY_MEDIA, CHANGE_SETTINGS, SET_REMINDER, NAVIGATE, PURCHASE, CANCEL, HELP, QUERY, UNKNOWN }
enum class IntelligenceEntityType { TIME, LOCATION, PERSON, NUMBER, APP_NAME, PRODUCT, ORGANIZATION }

data class SentimentAnalysis(val sentiment: Sentiment, val score: Float, val confidence: Float)
enum class Sentiment { POSITIVE, NEGATIVE, NEUTRAL }

data class ActionItem(val type: ActionType, val target: String?, val rawText: String)
enum class ActionType { OPEN, SEND, SEARCH, PLAY, SET, CANCEL }

// 用户行为
data class UserBehaviorUnderstanding(
    val currentAction: String,
    val behaviorPattern: BehaviorPattern?,
    val predictedNextActions: List<PredictedAction>,
    val inferredGoal: UserGoal,
    val isAnomalous: Boolean,
    val confidence: Float
)

data class BehaviorPattern(
    val name: String,
    val actionSequence: List<String>,
    val frequency: Int = 0,
    val lastOccurrence: Long = 0
)

data class PredictedAction(val action: String, val probability: Float, val source: String)
data class UserGoal(val goal: String, val category: GoalCategory)
enum class GoalCategory { COMMUNICATION, INFORMATION, SHOPPING, ENTERTAINMENT, SETTINGS, AUTHENTICATION, BROWSING }

// 对话理解
data class DialogueUnderstanding(
    val currentInput: String,
    val enhancedInput: String,
    val topics: List<String>,
    val contextReferences: List<ContextReference>,
    val resolvedPronouns: Map<String, String>,
    val needsClarification: Boolean,
    val suggestedClarifications: List<String>
)

data class DialogueTurn(val userInput: String, val aiResponse: String, val timestamp: Long)
data class ContextReference(val pronoun: String, val referent: String?, val confidence: Float)

// 任务上下文
data class TaskContextUnderstanding(
    val currentTask: String,
    val taskType: ContextTaskType,
    val prerequisites: List<String>,
    val relatedTasks: List<TaskExecution>,
    val complexity: ContextTaskComplexity,
    val estimatedDuration: Long,
    val risks: List<TaskRisk>
)

enum class ContextTaskType { MESSAGE, SEARCH, OPEN_APP, SETTINGS, PURCHASE, MEDIA, NAVIGATION, GENERAL }
enum class ContextTaskComplexity { LOW, MEDIUM, HIGH }

data class TaskExecution(val task: String, val success: Boolean, val duration: Long?, val completedAt: Long)
data class TaskRisk(val name: String, val description: String, val level: ContextRiskLevel)
enum class ContextRiskLevel { LOW, MEDIUM, HIGH }

// 记忆系统
data class MemoryItem(
    val content: String,
    val category: String,
    val importance: Float,
    val timestamp: Long
)

data class LongTermMemoryItem(
    val content: String,
    val category: String,
    val importance: Float,
    val accessCount: Int,
    val createdAt: Long,
    val lastAccessedAt: Long
)

data class TaskMemoryItem(
    val taskName: String,
    val success: Boolean,
    val steps: List<String>,
    val completedAt: Long
)

data class SceneMemoryItem(
    val sceneType: String,
    val context: Map<String, String>,
    val lastUpdated: Long
)

data class MemoryRetrievalResult(
    val shortTermMemories: List<MemoryItem>,
    val longTermMemories: List<LongTermMemoryItem>,
    val taskMemories: List<TaskMemoryItem>,
    val totalResults: Int
)

// 统一上下文
data class UnifiedContext(
    val screenContext: ScreenUnderstanding?,
    val textContext: TextSemanticResult?,
    val behaviorContext: UserBehaviorUnderstanding?,
    val dialogueContext: DialogueUnderstanding?,
    val taskContext: TaskContextUnderstanding?,
    val timestamp: Long
)
