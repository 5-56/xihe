package com.example.xihe.ai

import com.example.xihe.utils.LogManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * ⚡ 性能智能模块
 * 
 * 实现操作执行速度优化和资源使用优化
 */
object PerformanceIntelligence {
    
    private const val TAG = "PerformanceIntelligence"
    
    // 操作缓存
    private val operationCache = ConcurrentHashMap<String, CachedOperation>()
    private val resultCache = ConcurrentHashMap<String, CachedResult>()
    
    // 性能统计
    private val latencyRecords = mutableListOf<LatencyRecord>()
    private val resourceRecords = mutableListOf<ResourceRecord>()
    
    // 批量操作队列
    private val batchQueue = ConcurrentHashMap<String, MutableList<BatchItem>>()
    
    // 并行操作管理
    private val parallelJobs = ConcurrentHashMap<String, Job>()
    
    // 性能状态
    private val _performanceState = MutableStateFlow(PerformanceState())
    val performanceState: StateFlow<PerformanceState> = _performanceState.asStateFlow()
    
    // 配置
    private var config = PerformanceConfig()
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    
    // 统计计数器
    private val cacheHits = AtomicLong(0)
    private val cacheMisses = AtomicLong(0)
    
    // ==================== ⚡ 操作延迟优化 ====================
    
    /**
     * ⚡ 优化操作延迟
     */
    fun <T> optimizeLatency(
        operationId: String,
        operation: suspend () -> T,
        priority: OperationPriority = OperationPriority.NORMAL
    ): Deferred<T> {
        LogManager.d(TAG, "⚡ 优化操作延迟: $operationId")
        
        val startTime = System.currentTimeMillis()
        
        return scope.async(getDispatcher(priority)) {
            try {
                val result = operation()
                recordLatency(operationId, System.currentTimeMillis() - startTime, true)
                result
            } catch (e: Exception) {
                recordLatency(operationId, System.currentTimeMillis() - startTime, false)
                throw e
            }
        }
    }
    
    /**
     * 🚀 快速执行（跳过非必要检查）
     */
    suspend fun <T> fastExecute(
        operationId: String,
        operation: suspend () -> T
    ): T = withContext(Dispatchers.Default) {
        val startTime = System.nanoTime()
        try {
            operation().also {
                val latencyMs = (System.nanoTime() - startTime) / 1_000_000
                recordLatency(operationId, latencyMs, true)
            }
        } catch (e: Exception) {
            val latencyMs = (System.nanoTime() - startTime) / 1_000_000
            recordLatency(operationId, latencyMs, false)
            throw e
        }
    }
    
    /**
     * 📊 获取延迟统计
     */
    fun getLatencyStats(operationId: String? = null): LatencyStats {
        val records = if (operationId != null) {
            latencyRecords.filter { it.operationId == operationId }
        } else latencyRecords
        
        if (records.isEmpty()) return LatencyStats(0, 0, 0, 0, 0f)
        
        val latencies = records.map { it.latencyMs }
        return LatencyStats(
            avgLatency = latencies.average().toLong(),
            minLatency = latencies.minOrNull() ?: 0,
            maxLatency = latencies.maxOrNull() ?: 0,
            p95Latency = latencies.sorted().getOrElse((latencies.size * 0.95).toInt()) { 0 },
            successRate = records.count { it.success }.toFloat() / records.size
        )
    }
    
    private fun recordLatency(operationId: String, latencyMs: Long, success: Boolean) {
        latencyRecords.add(LatencyRecord(operationId, latencyMs, success, System.currentTimeMillis()))
        if (latencyRecords.size > 1000) latencyRecords.removeAll(latencyRecords.take(200))
        updatePerformanceState()
    }
    
    // ==================== 📦 批量操作支持 ====================
    
    /**
     * 📦 添加到批量队列
     */
    fun <T> addToBatch(
        batchId: String,
        item: T,
        processor: suspend (List<T>) -> List<Any>
    ): String {
        val itemId = "${batchId}_${System.currentTimeMillis()}"
        
        @Suppress("UNCHECKED_CAST")
        val queue = batchQueue.getOrPut(batchId) { mutableListOf() }
        queue.add(BatchItem(itemId, item as Any, processor as suspend (List<Any>) -> List<Any>))
        
        // 检查是否需要触发批量处理
        if (queue.size >= config.batchSize) {
            scope.launch { processBatch(batchId) }
        }
        
        return itemId
    }
    
    /**
     * 📦 立即处理批量
     */
    suspend fun processBatch(batchId: String): BatchResult {
        val queue = batchQueue[batchId] ?: return BatchResult(batchId, 0, 0, emptyList())
        
        if (queue.isEmpty()) return BatchResult(batchId, 0, 0, emptyList())
        
        val items = queue.toList()
        queue.clear()
        
        LogManager.d(TAG, "📦 处理批量: $batchId, 数量: ${items.size}")
        
        val startTime = System.currentTimeMillis()
        
        return try {
            val processor = items.first().processor
            val results = processor(items.map { it.data })
            
            BatchResult(
                batchId = batchId,
                processedCount = items.size,
                duration = System.currentTimeMillis() - startTime,
                results = results
            )
        } catch (e: Exception) {
            LogManager.e(TAG, "批量处理失败: $batchId", e)
            BatchResult(batchId, 0, System.currentTimeMillis() - startTime, emptyList(), e.message)
        }
    }
    
    /**
     * ⏰ 定时批量处理
     */
    fun scheduleBatchProcessing(batchId: String, intervalMs: Long) {
        scope.launch {
            while (isActive) {
                delay(intervalMs)
                processBatch(batchId)
            }
        }
    }
    
    // ==================== 🔀 并行操作支持 ====================
    
    /**
     * 🔀 并行执行多个操作
     */
    suspend fun <T> executeParallel(
        operations: List<Pair<String, suspend () -> T>>
    ): ParallelResult<T> {
        LogManager.d(TAG, "🔀 并行执行: ${operations.size}个操作")
        
        val startTime = System.currentTimeMillis()
        val results = mutableMapOf<String, Result<T>>()
        
        coroutineScope {
            operations.map { (id, operation) ->
                async {
                    id to runCatching { operation() }
                }
            }.awaitAll().forEach { (id, result) ->
                results[id] = result
            }
        }
        
        val successCount = results.count { it.value.isSuccess }
        
        return ParallelResult(
            totalOperations = operations.size,
            successCount = successCount,
            failureCount = operations.size - successCount,
            duration = System.currentTimeMillis() - startTime,
            results = results
        )
    }
    
    /**
     * 🔀 限制并发数的并行执行
     */
    suspend fun <T> executeWithConcurrencyLimit(
        operations: List<Pair<String, suspend () -> T>>,
        maxConcurrency: Int = config.maxParallelOperations
    ): ParallelResult<T> {
        LogManager.d(TAG, "🔀 限制并发执行: ${operations.size}个, 最大并发: $maxConcurrency")
        
        val startTime = System.currentTimeMillis()
        val results = ConcurrentHashMap<String, Result<T>>()
        val semaphore = kotlinx.coroutines.sync.Semaphore(maxConcurrency)
        
        coroutineScope {
            operations.map { (id, operation) ->
                async {
                    semaphore.acquire()
                    try {
                        results[id] = runCatching { operation() }
                    } finally {
                        semaphore.release()
                    }
                }
            }.awaitAll()
        }
        
        val successCount = results.count { it.value.isSuccess }
        
        return ParallelResult(
            totalOperations = operations.size,
            successCount = successCount,
            failureCount = operations.size - successCount,
            duration = System.currentTimeMillis() - startTime,
            results = results.toMap()
        )
    }
    
    /**
     * 🏃 启动后台并行任务
     */
    fun launchParallelTask(taskId: String, task: suspend () -> Unit): Job {
        parallelJobs[taskId]?.cancel()
        
        val job = scope.launch {
            try {
                task()
            } finally {
                parallelJobs.remove(taskId)
            }
        }
        
        parallelJobs[taskId] = job
        return job
    }
    
    /**
     * ❌ 取消并行任务
     */
    fun cancelParallelTask(taskId: String): Boolean {
        return parallelJobs.remove(taskId)?.let {
            it.cancel()
            true
        } ?: false
    }
    
    // ==================== 💾 操作缓存 ====================
    
    /**
     * 💾 带缓存执行
     */
    suspend fun <T> executeWithCache(
        cacheKey: String,
        ttlMs: Long = config.defaultCacheTtl,
        operation: suspend () -> T
    ): T {
        // 检查缓存
        @Suppress("UNCHECKED_CAST")
        val cached = resultCache[cacheKey] as? CachedResult
        if (cached != null && !cached.isExpired()) {
            cacheHits.incrementAndGet()
            LogManager.d(TAG, "💾 缓存命中: $cacheKey")
            @Suppress("UNCHECKED_CAST")
            return cached.result as T
        }
        
        cacheMisses.incrementAndGet()
        
        // 执行操作
        val result = operation()
        
        // 缓存结果
        resultCache[cacheKey] = CachedResult(result as Any, System.currentTimeMillis(), ttlMs)
        
        // 清理过期缓存
        if (resultCache.size > config.maxCacheSize) {
            cleanupCache()
        }
        
        return result
    }
    
    /**
     * 💾 预热缓存
     */
    fun <T> preloadCache(cacheKey: String, value: T, ttlMs: Long = config.defaultCacheTtl) {
        resultCache[cacheKey] = CachedResult(value as Any, System.currentTimeMillis(), ttlMs)
    }
    
    /**
     * 🗑️ 清除缓存
     */
    fun clearCache(cacheKey: String? = null) {
        if (cacheKey != null) {
            resultCache.remove(cacheKey)
            operationCache.remove(cacheKey)
        } else {
            resultCache.clear()
            operationCache.clear()
        }
    }
    
    /**
     * 📊 获取缓存统计
     */
    fun getCacheStats(): CacheStats {
        val hits = cacheHits.get()
        val misses = cacheMisses.get()
        val total = hits + misses
        
        return CacheStats(
            totalEntries = resultCache.size,
            hitCount = hits,
            missCount = misses,
            hitRate = if (total > 0) hits.toFloat() / total else 0f,
            memoryUsage = estimateCacheMemory()
        )
    }
    
    private fun cleanupCache() {
        val now = System.currentTimeMillis()
        resultCache.entries.removeIf { it.value.isExpired() }
        
        // 如果还是太大，移除最旧的
        if (resultCache.size > config.maxCacheSize) {
            val toRemove = resultCache.entries
                .sortedBy { it.value.createdAt }
                .take(resultCache.size - config.maxCacheSize / 2)
            toRemove.forEach { resultCache.remove(it.key) }
        }
    }
    
    private fun estimateCacheMemory(): Long {
        // 简单估算
        return resultCache.size * 1024L
    }
    
    // ==================== 🧠 内存优化 ====================
    
    /**
     * 🧠 监控内存使用
     */
    fun monitorMemoryUsage(): MemoryInfo {
        val runtime = Runtime.getRuntime()
        val maxMemory = runtime.maxMemory()
        val totalMemory = runtime.totalMemory()
        val freeMemory = runtime.freeMemory()
        val usedMemory = totalMemory - freeMemory
        
        val info = MemoryInfo(
            maxMemory = maxMemory,
            totalMemory = totalMemory,
            usedMemory = usedMemory,
            freeMemory = freeMemory,
            usagePercent = usedMemory.toFloat() / maxMemory
        )
        
        recordResource(ResourceType.MEMORY, info.usagePercent)
        
        return info
    }
    
    /**
     * 🧹 优化内存使用
     */
    fun optimizeMemory(): MemoryOptimizationResult {
        val before = monitorMemoryUsage()
        
        // 清理缓存
        cleanupCache()
        
        // 建议GC
        System.gc()
        
        val after = monitorMemoryUsage()
        val freedMemory = before.usedMemory - after.usedMemory
        
        return MemoryOptimizationResult(
            freedMemory = if (freedMemory > 0) freedMemory else 0,
            beforeUsage = before.usagePercent,
            afterUsage = after.usagePercent,
            recommendations = generateMemoryRecommendations(after)
        )
    }
    
    private fun generateMemoryRecommendations(info: MemoryInfo): List<String> {
        val recommendations = mutableListOf<String>()
        
        if (info.usagePercent > 0.8f) {
            recommendations.add("内存使用率过高，建议清理缓存")
            recommendations.add("考虑减少并行任务数量")
        } else if (info.usagePercent > 0.6f) {
            recommendations.add("内存使用适中，注意监控")
        }
        
        if (resultCache.size > config.maxCacheSize / 2) {
            recommendations.add("缓存数量较多，考虑清理")
        }
        
        return recommendations
    }
    
    // ==================== ⚙️ CPU优化 ====================
    
    /**
     * ⚙️ 获取CPU使用情况
     */
    fun getCpuInfo(): CpuInfo {
        val processors = Runtime.getRuntime().availableProcessors()
        val activeThreads = Thread.activeCount()
        
        val info = CpuInfo(
            availableProcessors = processors,
            activeThreads = activeThreads,
            threadPoolUsage = parallelJobs.size.toFloat() / config.maxParallelOperations,
            recommendations = generateCpuRecommendations(activeThreads, processors)
        )
        
        recordResource(ResourceType.CPU, info.threadPoolUsage)
        
        return info
    }
    
    private fun generateCpuRecommendations(threads: Int, processors: Int): List<String> {
        val recommendations = mutableListOf<String>()
        
        if (threads > processors * 2) {
            recommendations.add("活跃线程过多，考虑减少并发")
        }
        
        if (parallelJobs.size > config.maxParallelOperations / 2) {
            recommendations.add("并行任务较多，注意性能影响")
        }
        
        return recommendations
    }
    
    // ==================== 🌐 网络优化 ====================
    
    /**
     * 🌐 优化网络请求
     */
    fun <T> optimizeNetworkRequest(
        requestId: String,
        request: suspend () -> T,
        retryCount: Int = config.networkRetryCount,
        timeoutMs: Long = config.networkTimeout
    ): Deferred<T> {
        return scope.async {
            var lastException: Exception? = null
            
            repeat(retryCount) { attempt ->
                try {
                    return@async withTimeout(timeoutMs) {
                        request()
                    }
                } catch (e: Exception) {
                    lastException = e
                    LogManager.w(TAG, "网络请求失败 (尝试 ${attempt + 1}/$retryCount): $requestId")
                    if (attempt < retryCount - 1) {
                        delay(config.retryDelayMs * (attempt + 1))
                    }
                }
            }
            
            throw lastException ?: Exception("网络请求失败")
        }
    }
    
    /**
     * 🌐 批量网络请求
     */
    suspend fun <T> batchNetworkRequests(
        requests: List<Pair<String, suspend () -> T>>,
        maxConcurrency: Int = 3
    ): Map<String, Result<T>> {
        return executeWithConcurrencyLimit(requests, maxConcurrency).results
    }
    
    // ==================== 🔋 电池优化 ====================
    
    /**
     * 🔋 获取电池友好配置
     */
    fun getBatteryFriendlyConfig(batteryLevel: Int, isCharging: Boolean): BatteryConfig {
        return when {
            isCharging -> BatteryConfig(
                maxParallel = config.maxParallelOperations,
                batchInterval = config.batchInterval,
                cacheEnabled = true,
                aggressiveOptimization = false
            )
            batteryLevel < 15 -> BatteryConfig(
                maxParallel = 1,
                batchInterval = config.batchInterval * 3,
                cacheEnabled = true,
                aggressiveOptimization = true
            )
            batteryLevel < 30 -> BatteryConfig(
                maxParallel = 2,
                batchInterval = config.batchInterval * 2,
                cacheEnabled = true,
                aggressiveOptimization = false
            )
            else -> BatteryConfig(
                maxParallel = config.maxParallelOperations,
                batchInterval = config.batchInterval,
                cacheEnabled = true,
                aggressiveOptimization = false
            )
        }
    }
    
    /**
     * 🔋 应用电池优化
     */
    fun applyBatteryOptimization(batteryLevel: Int, isCharging: Boolean) {
        val batteryConfig = getBatteryFriendlyConfig(batteryLevel, isCharging)
        
        config = config.copy(
            maxParallelOperations = batteryConfig.maxParallel,
            batchInterval = batteryConfig.batchInterval
        )
        
        if (batteryConfig.aggressiveOptimization) {
            // 取消非关键任务
            parallelJobs.entries
                .filter { !it.key.startsWith("critical_") }
                .forEach { it.value.cancel() }
        }
        
        LogManager.d(TAG, "🔋 应用电池优化: level=$batteryLevel, charging=$isCharging")
    }
    
    // ==================== 🚀 AI响应优化 ====================
    
    /**
     * 🚀 流式响应
     */
    fun <T> streamResponse(
        source: Flow<T>
    ): Flow<StreamChunk<T>> = flow {
        var index = 0
        val startTime = System.currentTimeMillis()
        
        source.collect { item ->
            emit(StreamChunk(
                index = index++,
                data = item,
                timestamp = System.currentTimeMillis(),
                latency = System.currentTimeMillis() - startTime
            ))
        }
    }
    
    /**
     * 🚀 异步处理请求
     */
    fun <T> asyncProcess(
        requestId: String,
        processor: suspend () -> T,
        onComplete: (Result<T>) -> Unit
    ): Job {
        return scope.launch {
            val result = runCatching { processor() }
            withContext(Dispatchers.Main) {
                onComplete(result)
            }
        }
    }
    
    // ==================== 🛠️ 辅助方法 ====================
    
    private fun getDispatcher(priority: OperationPriority) = when (priority) {
        OperationPriority.LOW -> Dispatchers.IO
        OperationPriority.NORMAL -> Dispatchers.Default
        OperationPriority.HIGH -> Dispatchers.Default
        OperationPriority.CRITICAL -> Dispatchers.Unconfined
    }
    
    private fun recordResource(type: ResourceType, usage: Float) {
        resourceRecords.add(ResourceRecord(type, usage, System.currentTimeMillis()))
        if (resourceRecords.size > 500) resourceRecords.removeAll(resourceRecords.take(100))
    }
    
    private fun updatePerformanceState() {
        val latencyStats = getLatencyStats()
        val cacheStats = getCacheStats()
        
        _performanceState.value = PerformanceState(
            avgLatency = latencyStats.avgLatency,
            cacheHitRate = cacheStats.hitRate,
            activeParallelTasks = parallelJobs.size,
            pendingBatchItems = batchQueue.values.sumOf { it.size },
            lastUpdate = System.currentTimeMillis()
        )
    }
    
    /**
     * ⚙️ 更新配置
     */
    fun updateConfig(newConfig: PerformanceConfig) {
        config = newConfig
    }
    
    /**
     * 📊 获取性能报告
     */
    fun getPerformanceReport(): PerformanceReport {
        val latencyStats = getLatencyStats()
        val cacheStats = getCacheStats()
        val memoryInfo = monitorMemoryUsage()
        val cpuInfo = getCpuInfo()
        
        return PerformanceReport(
            latencyStats = latencyStats,
            cacheStats = cacheStats,
            memoryInfo = memoryInfo,
            cpuInfo = cpuInfo,
            activeParallelTasks = parallelJobs.size,
            pendingBatchItems = batchQueue.values.sumOf { it.size },
            recommendations = generateOverallRecommendations(latencyStats, cacheStats, memoryInfo, cpuInfo)
        )
    }
    
    private fun generateOverallRecommendations(
        latency: LatencyStats, cache: CacheStats, memory: MemoryInfo, cpu: CpuInfo
    ): List<String> {
        val recommendations = mutableListOf<String>()
        
        if (latency.avgLatency > 1000) recommendations.add("平均延迟较高，考虑增加缓存")
        if (cache.hitRate < 0.5f && cache.totalEntries > 0) recommendations.add("缓存命中率低，检查缓存策略")
        if (memory.usagePercent > 0.8f) recommendations.add("内存使用高，建议优化")
        if (cpu.threadPoolUsage > 0.8f) recommendations.add("线程池使用率高，减少并发")
        
        if (recommendations.isEmpty()) recommendations.add("性能状况良好")
        
        return recommendations
    }
    
    /**
     * 🔄 重置统计
     */
    fun resetStats() {
        latencyRecords.clear()
        resourceRecords.clear()
        cacheHits.set(0)
        cacheMisses.set(0)
        updatePerformanceState()
    }
}

// ==================== 📦 数据类 ====================

data class PerformanceConfig(
    val maxParallelOperations: Int = 4,
    val batchSize: Int = 10,
    val batchInterval: Long = 1000,
    val defaultCacheTtl: Long = 300000, // 5分钟
    val maxCacheSize: Int = 100,
    val networkRetryCount: Int = 3,
    val networkTimeout: Long = 30000,
    val retryDelayMs: Long = 1000
)

enum class OperationPriority { LOW, NORMAL, HIGH, CRITICAL }

data class LatencyRecord(val operationId: String, val latencyMs: Long, val success: Boolean, val timestamp: Long)

data class LatencyStats(val avgLatency: Long, val minLatency: Long, val maxLatency: Long, val p95Latency: Long, val successRate: Float)

data class BatchItem(val id: String, val data: Any, val processor: suspend (List<Any>) -> List<Any>)

data class BatchResult(val batchId: String, val processedCount: Int, val duration: Long, val results: List<Any>, val error: String? = null)

data class ParallelResult<T>(val totalOperations: Int, val successCount: Int, val failureCount: Int, val duration: Long, val results: Map<String, Result<T>>)

data class CachedOperation(val operation: suspend () -> Any, val createdAt: Long, val ttlMs: Long) {
    fun isExpired() = System.currentTimeMillis() - createdAt > ttlMs
}

data class CachedResult(val result: Any, val createdAt: Long, val ttlMs: Long) {
    fun isExpired() = System.currentTimeMillis() - createdAt > ttlMs
}

data class CacheStats(val totalEntries: Int, val hitCount: Long, val missCount: Long, val hitRate: Float, val memoryUsage: Long)

data class MemoryInfo(val maxMemory: Long, val totalMemory: Long, val usedMemory: Long, val freeMemory: Long, val usagePercent: Float)

data class MemoryOptimizationResult(val freedMemory: Long, val beforeUsage: Float, val afterUsage: Float, val recommendations: List<String>)

data class CpuInfo(val availableProcessors: Int, val activeThreads: Int, val threadPoolUsage: Float, val recommendations: List<String>)

enum class ResourceType { MEMORY, CPU, NETWORK, BATTERY }

data class ResourceRecord(val type: ResourceType, val usage: Float, val timestamp: Long)

data class BatteryConfig(val maxParallel: Int, val batchInterval: Long, val cacheEnabled: Boolean, val aggressiveOptimization: Boolean)

data class StreamChunk<T>(val index: Int, val data: T, val timestamp: Long, val latency: Long)

data class PerformanceState(
    val avgLatency: Long = 0, val cacheHitRate: Float = 0f,
    val activeParallelTasks: Int = 0, val pendingBatchItems: Int = 0, val lastUpdate: Long = 0
)

data class PerformanceReport(
    val latencyStats: LatencyStats, val cacheStats: CacheStats,
    val memoryInfo: MemoryInfo, val cpuInfo: CpuInfo,
    val activeParallelTasks: Int, val pendingBatchItems: Int, val recommendations: List<String>
)
