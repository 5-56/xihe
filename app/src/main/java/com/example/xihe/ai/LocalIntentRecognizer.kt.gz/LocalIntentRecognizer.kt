package com.example.xihe.ai

import com.example.xihe.utils.LogManager
import com.example.xihe.core.UserIntent as CoreUserIntent

/**
 * 本地意图识别器
 * 快速识别用户指令，不依赖LLM，减少错误
 */
object LocalIntentRecognizer {
    private const val TAG = "LocalIntentRecognizer"
    
    /**
     * 识别结果
     */
    data class IntentResult(
        val isRecognized: Boolean,
        val intent: String?,
        val params: Map<String, String> = emptyMap(),
        val confidence: Float = 0f,
        // 🆕 智能纠错机制
        val needsConfirmation: Boolean = false,  // 是否需要用户确认
        val confirmationMessage: String? = null, // 确认提示语
        val alternativeInterpretation: String? = null // 备选理解
    )
    
    // 🆕 置信度阈值配置
    private const val HIGH_CONFIDENCE_THRESHOLD = 0.90f   // 高置信度：直接执行
    private const val MEDIUM_CONFIDENCE_THRESHOLD = 0.70f // 中置信度：需要确认
    // 低于 0.70：交给AI处理
    
    // 🆕 用户纠错关键词
    private val correctionKeywords = listOf(
        "不对", "不是", "错了", "取消", "算了", "停", "别", 
        "我不是这个意思", "理解错了", "不要", "重来"
    )
    
    /**
     * 🆕 检测是否是用户纠正指令
     */
    private fun isCorrection(normalized: String): Boolean {
        return correctionKeywords.any { normalized.contains(it) }
    }
    
    /**
     * 🛰️ 语义权重识别器 (离线降级方案)
     * 通过关键词组合识别意图，比正则表达式更具鲁棒性
     */
    private fun recognizeByWeights(normalized: String): IntentResult {
        val tokens = normalized.split(Regex("\\s+"))
        
        // 意图权重库
        val weights = mapOf(
            "OPEN_APP" to mapOf("打开" to 40, "启动" to 40, "运行" to 30, "app" to 20),
            "CLEAN_UP" to mapOf("清理" to 50, "垃圾" to 40, "瘦身" to 30, "空间" to 20),
            "VIDEO_SWIPE" to mapOf("刷" to 40, "看" to 30, "视频" to 40, "抖音" to 30),
            "SEARCH" to mapOf("搜" to 40, "查" to 40, "找" to 30, "百度" to 30)
        )

        var bestIntent: String? = null
        var maxScore = 0

        weights.forEach { (intent, keywords) ->
            var score = 0
            keywords.forEach { (kw, weight) ->
                if (normalized.contains(kw)) score += weight
            }
            if (score > maxScore) {
                maxScore = score
                bestIntent = intent
            }
        }

        return if (maxScore >= 60) {
            LogManager.d(TAG, "🎯 语义权重匹配成功: $bestIntent (Score: $maxScore)")
            IntentResult(true, bestIntent, confidence = maxScore / 100f)
        } else {
            IntentResult(false, null)
        }
    }
    
    /**
     * 识别用户输入的意图
     */
    fun recognize(input: String): IntentResult {
        val normalizedInput = input.trim().lowercase()
        
        // 首先检查是否是纠错指令
        if (isCorrection(normalizedInput)) {
            LogManager.d(TAG, "检测到用户纠正，跳过本地规则")
            return IntentResult(
                isRecognized = false, 
                intent = null,
                alternativeInterpretation = "用户正在纠正之前的理解"
            )
        }
        
        // 0. 首先检测是否是纯对话/聊天意图 - 这类应该直接交给AI
        if (isChatIntent(normalizedInput)) {
            LogManager.d(TAG, "检测到聊天/对话意图，交给AI处理")
            return IntentResult(isRecognized = false, intent = null)
        }
        
        // 收集所有可能的意图识别结果
        val candidates = mutableListOf<IntentResult>()
        
        // 1. 微信消息发送
        val wechatResult = recognizeWechatMessage(normalizedInput, input)
        if (wechatResult.isRecognized) candidates.add(wechatResult)
        
        // 2. 多平台消息发送
        val multiAppResult = recognizeMultiAppMessage(normalizedInput, input)
        if (multiAppResult.isRecognized) candidates.add(multiAppResult)
        
        // 3. 搜索意图
        val searchResult = recognizeSearch(normalizedInput, input)
        if (searchResult.isRecognized) candidates.add(searchResult)
        
        // 4. 应用操作
        val appResult = recognizeAppOperation(normalizedInput, input)
        if (appResult.isRecognized) candidates.add(appResult)
        
        // 5. 系统操作
        val systemResult = recognizeSystemOperation(normalizedInput, input)
        if (systemResult.isRecognized) candidates.add(systemResult)
        
        // 6. 多媒体控制
        val mediaResult = recognizeMediaControl(normalizedInput, input)
        if (mediaResult.isRecognized) candidates.add(mediaResult)
        
        // 7. 日程/提醒管理
        val scheduleResult = recognizeScheduleIntent(normalizedInput, input)
        if (scheduleResult.isRecognized) candidates.add(scheduleResult)
        
        // 8. 导航/出行
        val navigationResult = recognizeNavigationIntent(normalizedInput, input)
        if (navigationResult.isRecognized) candidates.add(navigationResult)
        
        // 9. 复合意图识别
        val compositeResult = recognizeCompositeIntent(normalizedInput, input)
        if (compositeResult.isRecognized) candidates.add(compositeResult)
        
        // 10. 手势操作识别（滑动、点击等）
        val gestureResult = recognizeGestureOperation(normalizedInput, input)
        if (gestureResult.isRecognized) candidates.add(gestureResult)
        
        // 11. 屏幕查看/识别意图
        val screenViewResult = recognizeScreenViewIntent(normalizedInput, input)
        if (screenViewResult.isRecognized) candidates.add(screenViewResult)
        
        // 智能选择最佳结果
        if (candidates.isEmpty()) {
            return IntentResult(isRecognized = false, intent = null)
        }
        
        // 按置信度排序
        val sortedCandidates = candidates.sortedByDescending { it.confidence }
        val bestMatch = sortedCandidates.first()
        
        // 根据置信度决定是否需要确认
        return when {
            // 高置信度：直接执行
            bestMatch.confidence >= HIGH_CONFIDENCE_THRESHOLD -> {
                LogManager.d(TAG, "高置信度识别: ${bestMatch.intent} (${bestMatch.confidence})")
                bestMatch
            }
            
            // 中等置信度：需要用户确认
            bestMatch.confidence >= MEDIUM_CONFIDENCE_THRESHOLD -> {
                val confirmMsg = generateConfirmationMessage(bestMatch, input)
                LogManager.d(TAG, "中置信度识别，需确认: ${bestMatch.intent} (${bestMatch.confidence})")
                bestMatch.copy(
                    needsConfirmation = true,
                    confirmationMessage = confirmMsg,
                    alternativeInterpretation = if (sortedCandidates.size > 1) 
                        "也可能是: ${sortedCandidates[1].intent}" else null
                )
            }
            
            // 低置信度：交给AI处理
            else -> {
                LogManager.d(TAG, "低置信度，交给AI: ${bestMatch.intent} (${bestMatch.confidence})")
                IntentResult(
                    isRecognized = false, 
                    intent = null,
                    alternativeInterpretation = "本地规则不确定，建议交给AI分析"
                )
            }
        }
    }
    
    /**
     * 生成确认消息
     */
    private fun generateConfirmationMessage(result: IntentResult, originalInput: String): String {
        return when (result.intent) {
            "send_wechat_message" -> {
                val contact = result.params["contact"] ?: "对方"
                val message = result.params["message"] ?: ""
                "你是要给[$contact]发微信说[$message]吗？说'对'确认，说'不对'取消"
            }
            "web_search" -> {
                val query = result.params["query"] ?: result.params["originalQuery"] ?: ""
                "你是要搜索[$query]吗？说'对'确认，说'不对'我来问问AI"
            }
            "open_app" -> {
                val app = result.params["app_name"] ?: ""
                "你是要打开[$app]吗？"
            }
            "navigation" -> {
                val dest = result.params["destination"] ?: ""
                "你是要导航到[$dest]吗？"
            }
            "set_reminder", "set_alarm" -> {
                val time = "${result.params["hour"]}:${result.params["minute"]}"
                val content = result.params["content"] ?: ""
                "你是要设置${result.params["date"]} $time 的提醒[$content]吗？"
            }
            else -> "你是要执行[${result.intent}]吗？说'对'确认"
        }
    }
    
    /**
     * 识别微信消息发送
     * 示例: "给陈丽发消息说我饿了"
     */
    private fun recognizeWechatMessage(normalized: String, original: String): IntentResult {
        // 更精确的模式，避免将对话类表达误判为发消息
        val patterns = listOf(
            Regex("给(.+?)(发|发送)(微信|消息).{0,5}说(.+)"),
            Regex("(微信|发消息)(给|跟)(.+?)说(.+)"),
            // 只有明确提到"告诉XX某件事"才匹配，避免"告诉我..."被误判
            Regex("(帮我)?告诉(.+?)[，,：:说](.+)"),
            // 只有"发消息跟XX说"才匹配，"跟我说说"这类不匹配
            Regex("(发|发送)(消息|微信)?跟(.+?)说(.+)")
        )
        
        for (pattern in patterns) {
            val match = pattern.find(normalized)
            if (match != null) {
                val groups = match.groupValues
                val contact: String
                val message: String
                
                when {
                    // "给XX发消息说YY"
                    normalized.contains("给") && groups.size >= 5 && groups[1].isNotBlank() -> {
                        contact = groups[1].trim()
                        message = groups[4].trim()
                    }
                    // "微信给XX说YY" 或 "发消息给XX说YY"
                    (normalized.contains("微信") || normalized.contains("发消息")) && groups.size >= 5 -> {
                        contact = groups[3].trim()
                        message = groups[4].trim()
                    }
                    // "告诉XX，YY" 或 "告诉XX说YY"
                    normalized.contains("告诉") && groups.size >= 4 -> {
                        contact = groups[2].trim()
                        message = groups[3].trim()
                    }
                    // "发消息跟XX说YY"
                    groups.size >= 5 -> {
                        contact = groups[3].trim()
                        message = groups[4].trim()
                    }
                    else -> continue
                }
                
                // 过滤掉对话类表达
                if (contact in listOf("我", "你", "他", "她", "它") && 
                    (message.contains("一下") || message.contains("说说") || 
                     message.contains("怎么") || message.contains("什么"))) {
                    LogManager.d(TAG, "检测到对话表达，跳过: $contact -> $message")
                    continue
                }
                
                if (contact.isNotBlank() && message.isNotBlank()) {
                    // 智能联系人映射：将"自己"相关表达映射到"文件传输助手"
                    val normalizedContact = normalizeContactName(contact)
                    
                    LogManager.d(TAG, "识别到微信消息: 联系人=$normalizedContact (原始: $contact), 消息=$message")
                    return IntentResult(
                        isRecognized = true,
                        intent = "send_wechat_message",
                        params = mapOf(
                            "contact" to normalizedContact,
                            "message" to message
                        ),
                        confidence = 0.95f
                    )
                }
            }
        }
        
        return IntentResult(isRecognized = false, intent = null)
    }
    
    /**
     * 智能联系人名称规范化
     * 将"自己"相关的表达映射到"文件传输助手"
     */
    private fun normalizeContactName(contact: String): String {
        val normalized = contact.trim().lowercase()
        
        // 自我指代的各种表达方式
        val selfExpressions = listOf(
            "自己", "我自己", "我", 
            "me", "myself", "self",
            "我的", "本人"
        )
        
        // 如果是自我指代，映射到文件传输助手
        if (selfExpressions.any { normalized.contains(it) }) {
            LogManager.d(TAG, "智能映射: \"$contact\" → \"文件传输助手\"")
            return "文件传输助手"
        }
        
        // 其他特殊别名映射（可扩展）
        val aliasMap = mapOf(
            "老婆" to "老婆",
            "老公" to "老公", 
            "爸爸" to "爸爸",
            "妈妈" to "妈妈",
            "爸" to "爸爸",
            "妈" to "妈妈"
        )
        
        return aliasMap[normalized] ?: contact
    }
    
    /**
     * 识别搜索意图
     * 示例: "搜索胃疼吃什么", "百度一下天气"
     * 
     * 重要区分:
     * - 搜索意图: "搜索xxx", "百度xxx", "查一下xxx"
     * - 咨询/建议意图: "怎么办", "应该怎么做", "你觉得呢" -> 交给AI
     * 
     * 搜索软件识别:
     * - 指定软件: "用百度搜索", "打开微信搜索", "在报头条搜索" -> 打开对应APP
     * - 未指定: "搜索xxx" -> 直接调用浏览器API，不打开UI
     */
    private fun recognizeSearch(normalized: String, original: String): IntentResult {
        // 对话性质的句子 - 交给 AI 智能判断
        val conversationalPhrases = listOf(
            "你", "您", "我", "咱", "我们",
            "干嘛", "干什么", "在做", "在干",
            "不懂", "不会", "不知道", "不明白",
            "能不能", "可以不", "行不行"
        )
        
        // 咨询/建议类问题的关键词 - 这类问题应该交给AI回答
        val consultationPhrases = listOf(
            "怎么办", "怎么处理", "应该怎么", "该怎么",
            "怎样才能", "如何应对", "如何处理",
            "你觉得", "你认为", "你怎么看",
            "帮帮我", "给个建议", "建议一下",
            "可以吗", "好不好", "合适吗",
            "另一半", "男朋友", "女朋友", "感情", "恋爱",
            "工作", "职业", "面试", "考试",
            "然后呢", "接下来", "以后",
            "如果", "假如", "万一"
        )
        
        // 感情/咨询类问题的话题词
        val emotionalTopics = listOf(
            "开心", "难过", "伤心", "失望", "焦虑", "压力",
            "喜欢", "爱", "恨", "分手", "复合", "吵架",
            "纠结", "迷茫", "困惑", "烦恼",
            "父母", "家人", "朋友", "同事"
        )
        
        // 检测是否包含对话性质的词
        val hasConversationalTone = conversationalPhrases.any { normalized.contains(it) }
        
        // 检测是否是咨询类问题
        val isConsultation = consultationPhrases.any { normalized.contains(it) }
        val hasEmotionalTopic = emotionalTopics.any { normalized.contains(it) }
        
        // 如果是咨询类问题，直接交给AI
        if (isConsultation || hasEmotionalTopic) {
            LogManager.d(TAG, "检测到咨询/情感类问题，交给AI处理: $normalized")
            return IntentResult(isRecognized = false, intent = null)
        }
        
        // 检测是否是求助/建议类的问句
        val advicePatterns = listOf(
            "怎么办",
            "怎样办",
            "应该怎么",
            "该怎么",
            "怎样才",
            "何如是好",
            "如何应对"
        )
        if (advicePatterns.any { normalized.contains(it) }) {
            LogManager.d(TAG, "检测到求助/建议类问句，交给AI处理: $normalized")
            return IntentResult(isRecognized = false, intent = null)
        }
        
        // 检测是否指定了搜索软件/APP
        val searchAppKeywords = mapOf(
            // APP名称 -> (APP包名, 显示名称)
            "百度" to Pair("com.baidu.searchbox", "百度"),
            "报头条" to Pair("com.ss.android.article.news", "今日头条"),
            "头条" to Pair("com.ss.android.article.news", "今日头条"),
            "微信" to Pair("com.tencent.mm", "微信"),
            "抠抠" to Pair("com.tencent.mobileqq", "QQ"),
            "qq" to Pair("com.tencent.mobileqq", "QQ"),
            "微博" to Pair("com.sina.weibo", "微博"),
            "知乎" to Pair("com.zhihu.android", "知乎"),
            "小红书" to Pair("com.xingin.xhs", "小红书"),
            "淘宝" to Pair("com.taobao.taobao", "淘宝"),
            "京东" to Pair("com.jingdong.app.mall", "京东"),
            "押音" to Pair("com.ss.android.ugc.aweme", "押音"),
            "快手" to Pair("com.smile.gifmaker", "快手"),
            "b站" to Pair("tv.danmaku.bili", "哔哩哔哩"),
            "哔哩哔哩" to Pair("tv.danmaku.bili", "哔哩哔哩"),
            "谷歌" to Pair("com.google.android.googlequicksearchbox", "谷歌"),
            "google" to Pair("com.google.android.googlequicksearchbox", "谷歌")
        )
        
        // 检测是否指定了搜索软件
        var specifiedApp: Pair<String, String>? = null
        val appIndicators = listOf("用", "在", "打开", "去", "上")
        
        for ((keyword, appInfo) in searchAppKeywords) {
            // "用百度搜索", "在百度搜索", "打开百度搜索", "去头条搜索"
            val keywordLi = keyword + "里"
            val keywordZhong = keyword + "中"
            val keywordShang = keyword + "上"
            if (appIndicators.any { normalized.contains("$it$keyword") } ||
                normalized.contains(keywordLi) ||
                normalized.contains(keywordZhong) ||
                normalized.contains(keywordShang)) {
                specifiedApp = appInfo
                LogManager.d(TAG, "检测到指定搜索软件: ${appInfo.second}")
                break
            }
        }
        
        val patterns = listOf(
            // 明确的搜索指令 - 高置信度
            Regex("(搜索|搜|查|查一下|百度|谷歌)(.+)"),
            // 疑问句式 - 需要具体的主题词，且不能是咨询类
            Regex("([^你我您咱如果假如万一那就]{2,})(是什么|在哪里|在哪|有多少|多少钱)")
        )
        
        for ((index, pattern) in patterns.withIndex()) {
            val match = pattern.find(normalized)
            if (match != null) {
                val isExplicitSearch = index == 0  // 第一个模式是明确的搜索指令
                
                var query = when (match.groupValues.size) {
                    3 -> {
                        // 对于疑问句式，组合主题和问题
                        val topic = match.groupValues[1].trim()
                        val question = match.groupValues[2].trim()
                        if (topic.length < 2) continue  // 主题太短，可能不是真正的搜索
                        "$topic$question"
                    }
                    2 -> match.groupValues[1].trim()
                    else -> continue
                }
                
                // 清理query中的APP名称和指示词
                if (specifiedApp != null) {
                    for ((keyword, _) in searchAppKeywords) {
                        query = query.replace(Regex("(用|在|打开|去|上)?$keyword(里|中|上)?"), "").trim()
                    }
                }
                
                if (query.isNotBlank() && query.length >= 2) {
                    // 智能判断：如果有对话性质且不是明确搜索指令，降低置信度，交给 IntentClassifier 判断
                    if (hasConversationalTone && !isExplicitSearch) {
                        LogManager.d(TAG, "检测到对话性质，降低搜索置信度，交给智能分析 - $normalized")
                        // 返回低置信度结果，让 IntentClassifier 重新评估
                        return IntentResult(
                            isRecognized = true,
                            intent = "web_search",
                            params = mapOf(
                                "query" to sanitizeMedicalQuery(query),
                                "originalQuery" to query
                            ),
                            confidence = 0.3f  // 低置信度
                        )
                    }
                    
                    // 明确的搜索指令 or 无对话性质
                    val confidence = if (isExplicitSearch) 0.95f else 0.85f
                    
                    // 构建搜索参数，包含是否指定了APP
                    val params = mutableMapOf(
                        "query" to sanitizeMedicalQuery(query),
                        "originalQuery" to query
                    )
                    
                    if (specifiedApp != null) {
                        params["search_app_package"] = specifiedApp.first
                        params["search_app_name"] = specifiedApp.second
                        params["use_app_mode"] = "true"
                        LogManager.d(TAG, "检测到APP内搜索: ${specifiedApp.second} - $query (置信度: $confidence)")
                    } else {
                        params["use_app_mode"] = "false"
                        LogManager.d(TAG, "检测到快速搜索: $query (置信度: $confidence)")
                    }
                    
                    return IntentResult(
                        isRecognized = true,
                        intent = "web_search",
                        params = params,
                        confidence = confidence
                    )
                }
            }
        }
        
        return IntentResult(isRecognized = false, intent = null)
    }
    
    /**
     * 识别应用操作
     * 示例: "打开微信", "关闭抖音"
     */
    private fun recognizeAppOperation(normalized: String, original: String): IntentResult {
        val patterns = listOf(
            Regex("(打开|启动|开启)(.+)"),
            Regex("(关闭|退出)(.+)")
        )
        
        for (pattern in patterns) {
            val match = pattern.find(normalized)
            if (match != null && match.groupValues.size >= 3) {
                val action = match.groupValues[1]
                val appName = match.groupValues[2].trim()
                
                if (appName.isNotBlank()) {
                    LogManager.d(TAG, "识别到应用操作: $action $appName")
                    return IntentResult(
                        isRecognized = true,
                        intent = if (action in listOf("打开", "启动", "开启")) 
                            "open_app" else "close_app",
                        params = mapOf("app_name" to appName),
                        confidence = 0.85f
                    )
                }
            }
        }
        
        return IntentResult(isRecognized = false, intent = null)
    }
    
    /**
     * 识别系统操作
     */
    private fun recognizeSystemOperation(normalized: String, original: String): IntentResult {
        val operations = mapOf(
            listOf("截图", "截屏", "屏幕截图") to "screenshot",
            listOf("返回", "后退", "back") to "go_back",
            listOf("主页", "桌面", "home") to "go_home",
            listOf("最近任务", "多任务") to "recent_apps",
            listOf("音量加", "音量+", "声音大一点") to "volume_up",
            listOf("音量减", "音量-", "声音小一点") to "volume_down"
        )
        
        for ((keywords, intent) in operations) {
            if (keywords.any { normalized.contains(it) }) {
                LogManager.d(TAG, "识别到系统操作: $intent")
                return IntentResult(
                    isRecognized = true,
                    intent = intent,
                    confidence = 1.0f
                )
            }
        }
        
        return IntentResult(isRecognized = false, intent = null)
    }
    
    /**
     * 过滤医疗敏感词，避免被审核
     */
    private fun sanitizeMedicalQuery(query: String): String {
        val replacements = mapOf(
            "疼" to "不适",
            "痛" to "不舒服",
            "吃什么药" to "饮食建议",
            "治疗" to "缓解方法",
            "病" to "症状",
            "药" to "方法"
        )
        
        var sanitized = query
        replacements.forEach { (old, new) ->
            sanitized = sanitized.replace(old, new)
        }
        
        return sanitized
    }
    
    // ==================== 新增意图识别功能 ====================
    
    /**
     * 识别多平台消息发送 (QQ/钉钉/飞书/Telegram等)
     */
    private fun recognizeMultiAppMessage(normalized: String, original: String): IntentResult {
        // 应用关键词映射
        val appKeywords = mapOf(
            "qq" to "QQ",
            "钉钉" to "钉钉",
            "飞书" to "飞书",
            "lark" to "飞书",
            "telegram" to "Telegram",
            "电报" to "Telegram",
            "短信" to "短信",
            "信息" to "短信",
            "邮件" to "邮件",
            "email" to "邮件"
        )
        
        // 检测目标应用
        var targetApp: String? = null
        for ((keyword, app) in appKeywords) {
            if (normalized.contains(keyword)) {
                targetApp = app
                break
            }
        }
        
        if (targetApp == null) return IntentResult(isRecognized = false, intent = null)
        
        // 提取联系人和消息
        val patterns = listOf(
            Regex("给(.+?)(发|发送).{0,10}说(.+)"),
            Regex("(发|发送)(.{2,6})(给|跟)(.+?)说(.+)"),
            Regex("告诉(.+?)[，,：:](.+)"),
            Regex("跟(.+?)说(.+)")
        )
        
        for (pattern in patterns) {
            val match = pattern.find(normalized)
            if (match != null) {
                val groups = match.groupValues
                var contact = ""
                var message = ""
                
                when {
                    groups.size >= 4 && groups[1].isNotBlank() -> {
                        contact = groups[1].trim()
                        message = groups.last().trim()
                    }
                    groups.size >= 6 -> {
                        contact = groups[4].trim()
                        message = groups[5].trim()
                    }
                }
                
                if (contact.isNotBlank() && message.isNotBlank()) {
                    LogManager.d(TAG, "识别到${targetApp}消息: 联系人=$contact, 消息=$message")
                    return IntentResult(
                        isRecognized = true,
                        intent = "send_${targetApp.lowercase()}_message",
                        params = mapOf(
                            "app" to targetApp,
                            "contact" to contact,
                            "message" to message
                        ),
                        confidence = 0.90f
                    )
                }
            }
        }
        
        return IntentResult(isRecognized = false, intent = null)
    }
    
    /**
     * 识别多媒体控制意图
     * 示例: "播放音乐", "暂停视频", "下一首", "音量调大"
     */
    private fun recognizeMediaControl(normalized: String, original: String): IntentResult {
        val mediaActions = mapOf(
            // 播放控制
            listOf("播放", "开始播放", "继续播放", "play") to Pair("media_play", 0.95f),
            listOf("暂停", "停止", "pause", "stop") to Pair("media_pause", 0.95f),
            listOf("下一首", "下一个", "切歌", "next") to Pair("media_next", 0.95f),
            listOf("上一首", "上一个", "previous") to Pair("media_previous", 0.95f),
            listOf("快进", "forward") to Pair("media_forward", 0.90f),
            listOf("后退", "倒退", "rewind") to Pair("media_rewind", 0.90f),
            // 音量控制
            listOf("音量大", "声音大", "调大声音", "音量+") to Pair("volume_up", 0.95f),
            listOf("音量小", "声音小", "调小声音", "音量-") to Pair("volume_down", 0.95f),
            listOf("静音", "mute") to Pair("volume_mute", 0.95f),
            // 播放模式
            listOf("单曲循环", "循环播放") to Pair("media_repeat_one", 0.90f),
            listOf("随机播放", "shuffle") to Pair("media_shuffle", 0.90f)
        )
        
        for ((keywords, result) in mediaActions) {
            if (keywords.any { normalized.contains(it) }) {
                LogManager.d(TAG, "识别到多媒体控制: ${result.first}")
                return IntentResult(
                    isRecognized = true,
                    intent = result.first,
                    confidence = result.second
                )
            }
        }
        
        return IntentResult(isRecognized = false, intent = null)
    }
    
    /**
     * 识别日程/提醒意图
     * 示例: "明天早上8点提醒我开会", "设置闹钟7点"
     */
    private fun recognizeScheduleIntent(normalized: String, original: String): IntentResult {
        // 时间模式
        val timePattern = Regex("(\\d{1,2})[点时:：](\\d{0,2})?(分钟?)?")
        val datePattern = Regex("(今天|明天|后天|大后天|下周一|下周二|下周三|下周四|下周五|下周六|下周日|周一|周二|周三|周四|周五|周六|周日|\\d{1,2}月\\d{1,2}[日号])")
        
        // 提醒/闹钟关键词
        val reminderKeywords = listOf("提醒", "闹钟", "定时", "提醒我", "叫我", "记得")
        
        val isReminder = reminderKeywords.any { normalized.contains(it) }
        if (!isReminder) return IntentResult(isRecognized = false, intent = null)
        
        // 提取时间
        val timeMatch = timePattern.find(normalized)
        val dateMatch = datePattern.find(normalized)
        
        if (timeMatch != null) {
            val hour = timeMatch.groupValues[1]
            val minute = timeMatch.groupValues.getOrNull(2)?.takeIf { it.isNotEmpty() } ?: "00"
            val date = dateMatch?.value ?: "今天"
            
            // 提取内容（提醒做什么）
            val contentPatterns = listOf(
                Regex("提醒我?(.+)"),
                Regex("叫我(.+)"),
                Regex("记得(.+)")
            )
            
            var content = ""
            for (pattern in contentPatterns) {
                val match = pattern.find(normalized)
                if (match != null) {
                    content = match.groupValues[1]
                        .replace(timePattern, "")
                        .replace(datePattern, "")
                        .trim()
                    break
                }
            }
            
            LogManager.d(TAG, "识别到日程/提醒: $date $hour:$minute - $content")
            return IntentResult(
                isRecognized = true,
                intent = if (normalized.contains("闹钟")) "set_alarm" else "set_reminder",
                params = mapOf(
                    "date" to date,
                    "hour" to hour,
                    "minute" to minute,
                    "content" to content.ifBlank { "提醒事项" }
                ),
                confidence = 0.90f
            )
        }
        
        return IntentResult(isRecognized = false, intent = null)
    }
    
    /**
     * 识别导航/出行意图
     * 示例: "导航到公司", "打车去机场", "查路线到北京"
     */
    private fun recognizeNavigationIntent(normalized: String, original: String): IntentResult {
        val navKeywords = listOf("导航", "路线", "怎么走", "怎么去", "去哪", "到哪")
        val rideKeywords = listOf("打车", "叫车", "滴滴", "出租车", "专车", "快车")
        val transitKeywords = listOf("公交", "地铁", "怎么坐", "坐几路")
        
        // 导航意图
        if (navKeywords.any { normalized.contains(it) }) {
            val destPattern = Regex("(导航|去|到)(.+)")
            val match = destPattern.find(normalized)
            if (match != null && match.groupValues.size >= 3) {
                val destination = match.groupValues[2].trim()
                    .replace("怎么走", "")
                    .replace("怎么去", "")
                    .trim()
                
                if (destination.isNotBlank() && destination.length >= 2) {
                    LogManager.d(TAG, "识别到导航: $destination")
                    return IntentResult(
                        isRecognized = true,
                        intent = "navigation",
                        params = mapOf("destination" to destination),
                        confidence = 0.90f
                    )
                }
            }
        }
        
        // 打车意图
        if (rideKeywords.any { normalized.contains(it) }) {
            val destPattern = Regex("(打车|叫车|滴滴).{0,5}(去|到)(.+)")
            val match = destPattern.find(normalized)
            if (match != null && match.groupValues.size >= 4) {
                val destination = match.groupValues[3].trim()
                if (destination.isNotBlank()) {
                    LogManager.d(TAG, "识别到打车: $destination")
                    return IntentResult(
                        isRecognized = true,
                        intent = "call_ride",
                        params = mapOf("destination" to destination),
                        confidence = 0.90f
                    )
                }
            }
        }
        
        // 公交/地铁查询
        if (transitKeywords.any { normalized.contains(it) }) {
            LogManager.d(TAG, "识别到公交/地铁查询")
            return IntentResult(
                isRecognized = true,
                intent = "transit_query",
                params = mapOf("query" to original),
                confidence = 0.85f
            )
        }
        
        return IntentResult(isRecognized = false, intent = null)
    }
    
    /**
     * 识别复合意图 (然后/接着/同时)
     * 示例: "打开微信然后给张三发消息"
     */
    private fun recognizeCompositeIntent(normalized: String, original: String): IntentResult {
        val connectors = listOf("然后", "接着", "之后", "再", "并且", "同时", "顺便")
        
        for (connector in connectors) {
            if (normalized.contains(connector)) {
                val parts = normalized.split(connector, limit = 2)
                if (parts.size == 2 && parts[0].isNotBlank() && parts[1].isNotBlank()) {
                    // 递归识别每个部分
                    val firstIntent = recognize(parts[0].trim())
                    val secondIntent = recognize(parts[1].trim())
                    
                    if (firstIntent.isRecognized || secondIntent.isRecognized) {
                        LogManager.d(TAG, "识别到复合意图: [${firstIntent.intent}] $connector [${secondIntent.intent}]")
                        return IntentResult(
                            isRecognized = true,
                            intent = "composite_intent",
                            params = mapOf(
                                "first_intent" to (firstIntent.intent ?: "unknown"),
                                "first_params" to firstIntent.params.toString(),
                                "second_intent" to (secondIntent.intent ?: "unknown"),
                                "second_params" to secondIntent.params.toString(),
                                "connector" to connector
                            ),
                            confidence = minOf(firstIntent.confidence, secondIntent.confidence) * 0.9f
                        )
                    }
                }
            }
        }
        
        return IntentResult(isRecognized = false, intent = null)
    }
    
    // ==================== 手势操作识别 ====================
    
    /**
     * 识别手势操作意图
     * 示例: "向上滑动", "往下滑", "滑到底部", "点击屏幕中间"
     */
    private fun recognizeGestureOperation(normalized: String, original: String): IntentResult {
        // 滑动操作
        val swipePatterns = listOf(
            // 向上滑动
            Regex("(向上|往上|上滑|朝上|向上面)(滑|滑动|划|翻|翻页)?"),
            Regex("(滑|划|翻)(到)?(上面|上方|顶部|最上面)"),
            Regex("(往|向)?上(滑|划|翻)(一下|动)?"),
            // 向下滑动
            Regex("(向下|往下|下滑|朝下|向下面)(滑|滑动|划|翻|翻页)?"),
            Regex("(滑|划|翻)(到)?(下面|下方|底部|最下面)"),
            Regex("(往|向)?下(滑|划|翻)(一下|动)?"),
            // 向左滑动
            Regex("(向左|往左|左滑|朝左)(滑|滑动|划)?"),
            Regex("(往|向)?左(滑|划)(一下|动)?"),
            // 向右滑动
            Regex("(向右|往右|右滑|朝右)(滑|滑动|划)?"),
            Regex("(往|向)?右(滑|划)(一下|动)?")
        )
        
        // 检测滑动方向
        for (pattern in swipePatterns) {
            if (pattern.containsMatchIn(normalized)) {
                val direction = when {
                    normalized.contains("上") && !normalized.contains("下") -> "UP"
                    normalized.contains("下") && !normalized.contains("上") -> "DOWN"
                    normalized.contains("左") && !normalized.contains("右") -> "LEFT"
                    normalized.contains("右") && !normalized.contains("左") -> "RIGHT"
                    else -> "UP"  // 默认向上
                }
                
                val directionChinese = when (direction) {
                    "UP" -> "向上"
                    "DOWN" -> "向下"
                    "LEFT" -> "向左"
                    "RIGHT" -> "向右"
                    else -> "向上"
                }
                
                LogManager.d(TAG, "识别到滑动操作: $directionChinese")
                return IntentResult(
                    isRecognized = true,
                    intent = "gesture_swipe",
                    params = mapOf(
                        "direction" to direction,
                        "direction_chinese" to directionChinese,
                        "action_description" to "${directionChinese}滑动"
                    ),
                    confidence = 0.95f
                )
            }
        }
        
        // 点击操作
        val clickPatterns = listOf(
            Regex("(点击|点一下|按一下|触摸|点)(屏幕)?(中间|中心|中央|上面|下面|左边|右边)?"),
            Regex("(帮我|帮忙)?(点|按|触)(一下)?(这里|那里|这个|那个)?")
        )
        
        for (pattern in clickPatterns) {
            val match = pattern.find(normalized)
            if (match != null) {
                val position = when {
                    normalized.contains("中间") || normalized.contains("中心") || normalized.contains("中央") -> "center"
                    normalized.contains("上面") || normalized.contains("顶部") -> "top"
                    normalized.contains("下面") || normalized.contains("底部") -> "bottom"
                    normalized.contains("左") -> "left"
                    normalized.contains("右") -> "right"
                    else -> "center"
                }
                
                LogManager.d(TAG, "识别到点击操作: $position")
                return IntentResult(
                    isRecognized = true,
                    intent = "gesture_click",
                    params = mapOf(
                        "position" to position,
                        "action_description" to "点击屏幕$position"
                    ),
                    confidence = 0.9f
                )
            }
        }
        
        // 返回操作
        if (normalized.contains("返回") || normalized.contains("后退") || normalized.contains("回去")) {
            LogManager.d(TAG, "识别到返回操作")
            return IntentResult(
                isRecognized = true,
                intent = "gesture_back",
                params = mapOf("action_description" to "返回上一页"),
                confidence = 0.95f
            )
        }
        
        // 回到主页
        if (normalized.contains("回到主页") || normalized.contains("回到桌面") || normalized.contains("返回主页") || normalized.contains("回主页")) {
            LogManager.d(TAG, "识别到回到主页操作")
            return IntentResult(
                isRecognized = true,
                intent = "gesture_home",
                params = mapOf("action_description" to "回到主页"),
                confidence = 0.95f
            )
        }
        
        // 长按操作
        if (normalized.contains("长按") || normalized.contains("按住")) {
            LogManager.d(TAG, "识别到长按操作")
            return IntentResult(
                isRecognized = true,
                intent = "gesture_long_press",
                params = mapOf("action_description" to "长按屏幕"),
                confidence = 0.9f
            )
        }
        
        return IntentResult(isRecognized = false, intent = null)
    }
    
    // ==================== 屏幕查看识别 ====================
    
    /**
     * 识别屏幕查看/识别意图
     * 示例: "看看屏幕", "屏幕上有什么", "帮我看看现在显示什么"
     */
    private fun recognizeScreenViewIntent(normalized: String, original: String): IntentResult {
        val screenViewPatterns = listOf(
            Regex("(看看|看一下|帮我看|帮忙看)(屏幕|页面|界面|现在)?(上)?(有什么|显示什么|内容|是什么)?"),
            Regex("(屏幕|页面|界面)(上)?(有什么|显示什么|是什么|有啥)"),
            Regex("(现在|当前)(屏幕|页面|界面)?(显示|是)?(什么|啥)?"),
            Regex("(描述|说说|告诉我)(屏幕|页面|界面|现在)?(的)?(内容|情况)?"),
            Regex("(分析|识别)(一下)?(屏幕|页面|界面)?(内容)?"),
            Regex("这(是|个)?(什么)?(页面|界面|App|应用)?"),
            Regex("(我)?(在|到)(哪|什么)(页面|界面|地方)?")
        )
        
        for (pattern in screenViewPatterns) {
            if (pattern.containsMatchIn(normalized)) {
                LogManager.d(TAG, "识别到屏幕查看意图")
                return IntentResult(
                    isRecognized = true,
                    intent = "screen_view",
                    params = mapOf(
                        "action" to "describe_screen",
                        "action_description" to "查看屏幕内容"
                    ),
                    confidence = 0.95f
                )
            }
        }
        
        // 查找特定元素
        val findPatterns = listOf(
            Regex("(找|找到|找一下|搜|搜一下)(屏幕上的?)?(.{1,20})"),
            Regex("(有没有|有无|能不能找到)(.{1,20})"),
            Regex("(.{1,10})(在哪|在哪里|位置)")
        )
        
        for (pattern in findPatterns) {
            val match = pattern.find(normalized)
            if (match != null) {
                val target = match.groupValues.lastOrNull { it.length in 1..20 }?.trim()
                if (!target.isNullOrBlank()) {
                    LogManager.d(TAG, "识别到屏幕搜索意图: $target")
                    return IntentResult(
                        isRecognized = true,
                        intent = "screen_find",
                        params = mapOf(
                            "target" to target,
                            "action_description" to "在屏幕上查找「$target」"
                        ),
                        confidence = 0.85f
                    )
                }
            }
        }
        
        return IntentResult(isRecognized = false, intent = null)
    }
    
    /**
     * 🆕 检测是否是聊天/对话意图
     * 这类意图应该直接交给AI处理，而不是尝试匹配本地规则
     */
    private fun isChatIntent(normalized: String): Boolean {
        // 📝 对话开场白/问候
        val greetings = listOf(
            "你好", "您好", "嗨", "hi", "hello", "哈喽",
            "早上好", "下午好", "晚上好", "早安", "晚安",
            "在吗", "在不在", "忙吗"
        )
        
        // 💬 聊天性质的问题 - 询问AI的看法/感受
        val chatQuestions = listOf(
            "你觉得", "你认为", "你怎么看", "你怎么想",
            "你喜欢", "你爱", "你讨厌",
            "你有没有", "你会不会", "你能不能",
            "告诉我", "跟我说", "聊聊",
            "我想聊", "陪我聊", "和我聊"
        )
        
        // 🎭 情感表达/分享
        val emotionalSharing = listOf(
            "我很开心", "我很难过", "我很伤心", "我很高兴",
            "我好累", "我好烦", "我好无聊", "我好孤单",
            "心情不好", "心情很好", "郁闷", "焦虑",
            "压力大", "很紧张", "很兴奋"
        )
        
        // 🤔 寻求建议/咨询
        val seekingAdvice = listOf(
            "怎么办", "该怎么", "应该怎么", "怎样才能",
            "如何才能", "有什么办法", "有什么方法",
            "给我建议", "帮帮我", "你说呢"
        )
        
        // 💑 关系/情感话题
        val relationshipTopics = listOf(
            "男朋友", "女朋友", "老公", "老婆", "对象",
            "另一半", "暗恋", "表白", "分手", "复合",
            "吵架", "冷战", "感情", "恋爱", "婚姻"
        )
        
        // 🏠 生活话题
        val lifeTopics = listOf(
            "工作", "上班", "加班", "老板", "同事",
            "学习", "考试", "作业", "学校",
            "父母", "爸妈", "家人", "朋友"
        )
        
        // 📖 叙述性语气词 (表示在讲述/分享)
        val narrativeMarkers = listOf(
            "其实", "说实话", "老实说", "坦白说",
            "我跟你说", "你知道吗", "想跟你说",
            "就是", "然后", "后来", "结果"
        )
        
        // 🎯 检测是否匹配聊天意图
        val matchesGreeting = greetings.any { normalized.contains(it) }
        val matchesChatQuestion = chatQuestions.any { normalized.contains(it) }
        val matchesEmotional = emotionalSharing.any { normalized.contains(it) }
        val matchesAdvice = seekingAdvice.any { normalized.contains(it) }
        val matchesRelationship = relationshipTopics.any { normalized.contains(it) }
        val matchesLife = lifeTopics.any { normalized.contains(it) }
        val matchesNarrative = narrativeMarkers.any { normalized.contains(it) }
        
        // 🔍 综合判断
        // 1. 问候语 -> 聊天
        if (matchesGreeting && normalized.length < 15) return true
        
        // 2. 聊天问题 -> 聊天
        if (matchesChatQuestion) return true
        
        // 3. 情感表达 -> 聊天
        if (matchesEmotional) return true
        
        // 4. 寻求建议 + 关系/生活话题 -> 聊天
        if (matchesAdvice && (matchesRelationship || matchesLife)) return true
        
        // 5. 关系话题 + 叙述语气 -> 聊天
        if (matchesRelationship && matchesNarrative) return true
        
        // 6. 生活话题 + 寻求建议 -> 聊天
        if (matchesLife && matchesAdvice) return true
        
        // 7. 纯叙述性分享 (较长文本 + 叙述语气)
        if (matchesNarrative && normalized.length > 20 && 
            !normalized.contains("搜索") && !normalized.contains("打开")) {
            return true
        }
        
        // 8. 疑问句但是关于感受/看法的
        val feelingQuestions = listOf("好吗", "对吗", "是吗", "呢", "吧")
        if (feelingQuestions.any { normalized.endsWith(it) } && 
            (matchesRelationship || matchesLife || matchesEmotional)) {
            return true
        }
        
        return false
    }
}

fun LocalIntentRecognizer.IntentResult.toCoreUserIntent(originalText: String): CoreUserIntent? {
    if (!isRecognized || intent == null) return null
    val (finalType, finalEntities, reason) = when (intent) {
        // 统一到通用 send_message 意图，并补充 app 信息
        "send_wechat_message" -> {
            val entities = params.toMutableMap()
            if (!entities.containsKey("app")) {
                entities["app"] = "微信"
            }
            Triple("send_message", entities.toMap(), "local_intent:send_message(wechat)")
        }
        else -> Triple(intent, params, "local_intent:$intent")
    }

    return CoreUserIntent(
        type = finalType,
        confidence = confidence.toDouble(),
        entities = finalEntities,
        parameters = null,
        reasoning = reason,
        originalText = originalText
    )
}
