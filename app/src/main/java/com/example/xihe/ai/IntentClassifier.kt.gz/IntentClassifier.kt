package com.example.xihe.ai

import com.example.xihe.utils.LogManager
import com.example.xihe.core.UserIntent as CoreUserIntent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs

/**
 * 🧠 AI意图分类器
 * 负责理解用户输入，判断是闲聊、执行任务还是查询信息
 */
class IntentClassifier {
    
    companion object {
        private const val TAG = "IntentClassifier"
    }
    
    /**
     * 用户意图类型
     */
    enum class UserIntent {
        CASUAL_CHAT,        // 闲聊对话
        AUTOMATION_TASK,    // 自动化任务
        INFORMATION_QUERY,  // 信息查询
        SYSTEM_CONTROL,     // 系统控制
        MIXED_INTENT,       // 混合意图
        UNCLEAR            // 不明确
    }
    
    /**
     * 意图分析结果
     */
    data class IntentResult(
        val intent: UserIntent,
        val confidence: Float,  // 0.0 - 1.0
        val entities: Map<String, Any> = emptyMap(),  // 识别出的实体
        val suggestedAction: String? = null,
        val needsClarification: Boolean = false,
        val clarificationQuestion: String? = null
    )
    
    // 任务关键词库
    private val taskKeywords = listOf(
        // 应用操作
        "打开", "启动", "运行", "关闭", "退出", "切换",
        // 消息相关
        "发送", "发消息", "发微信", "发短信", "回复", "转发",
        // 搜索相关
        "搜索", "查找", "搜", "找", "查询", "百度", "谷歌",
        // 系统操作
        "截图", "截屏", "录屏", "调节", "设置", "连接", "断开",
        // 媒体控制
        "播放", "暂停", "下一首", "上一首", "快进", "后退",
        // 文件操作
        "保存", "删除", "复制", "粘贴", "分享", "下载",
        // 购物相关
        "购买", "下单", "加购物车", "结算", "支付",
        // 其他动作
        "点击", "滑动", "长按", "输入", "填写", "选择"
    )
    
    // 查询关键词库
    private val queryKeywords = listOf(
        "什么", "怎么", "为什么", "哪里", "哪个", "多少",
        "是不是", "有没有", "能不能", "可以吗",
        "查看", "显示", "告诉我", "帮我看看",
        "干吗", "干啥", "干什么", "做什么", "有什么",
        "能力", "功能", "作用", "用途", "介绍",
        "天气", "新闻", "时间", "日期", "今天", "明天", "后天"
    )
    
    // 闲聊关键词库
    private val chatKeywords = listOf(
        // 问候语
        "你好", "早安", "晚安", "谢谢", "再见", "拜拜", "您好",
        // 闲聊话题
        "聊天", "聊聊", "无聊", "开心", "难过", "累",
        "心情", "故事", "笑话",
        // 询问身份和状态 - 扩展！
        "你是谁", "你是什么", "你叫什么", "你是", "你叫",
        "你在干嘛", "你在干啥", "你在做什么", "你在忙什么",
        "在干嘛", "在干啥", "在做什么", "干嘛呢", "干啥呢",
        "在吗", "在不在", "有空吗", "忙不忙", "忙吗"
    )
    
    // 系统控制关键词库
    private val systemKeywords = listOf(
        "音量", "亮度", "WiFi", "蓝牙", "飞行模式",
        "勿扰", "省电", "定位", "通知", "权限",
        "返回", "主页", "最近任务", "分屏"
    )
    
    private val _lastIntent = MutableStateFlow<IntentResult?>(null)
    val lastIntent = _lastIntent.asStateFlow()
    
    /**
     * 🎯 分析用户意图
     */
    fun classifyIntent(userInput: String, context: ConversationContext? = null): IntentResult {
        LogManager.d(TAG, "分析用户输入: $userInput")
        
        // 清理和标准化输入
        val normalizedInput = userInput.trim().lowercase()
        
        // 🎯 快速检测：明确的自动化任务模式
        val explicitTaskPatterns = listOf(
            Regex("打开.+(应用|app|APP)"),
            Regex("启动.+"),
            Regex("关闭.+"),
            Regex("发送.+消息"),
            Regex("给.+发.+"),
            Regex("搜索.+"),
            Regex("帮我(打开|启动|发送|搜索|下载|播放).+"),
            Regex("请(打开|启动|发送|搜索).+"),
            Regex("(淘宝|京东|拼多多|微信|支付宝|抖音|QQ).+(搜索|买|看|打开)"),
            Regex("(刷|看)(抖音|快手|B站|视频)"),
            Regex("自动(刷|看|播放).+")
        )
        
        for (pattern in explicitTaskPatterns) {
            if (pattern.containsMatchIn(normalizedInput)) {
                LogManager.d(TAG, "🎯 检测到明确的自动化任务模式: $pattern")
                return IntentResult(
                    intent = UserIntent.AUTOMATION_TASK,
                    confidence = 0.95f,
                    entities = extractEntities(normalizedInput, UserIntent.AUTOMATION_TASK),
                    suggestedAction = generateSuggestedAction(UserIntent.AUTOMATION_TASK, emptyMap(), normalizedInput),
                    needsClarification = false
                ).also { _lastIntent.value = it }
            }
        }
        
        // 💬 快速检测：明确的聊天模式
        val explicitChatPatterns = listOf(
            "你是谁", "你叫什么", "你在干嘛", "在干嘛", "在吗", "在不在",
            "你好呀", "你好喔", "聊聊天", "聊聊吧", "无聊", "吃饭了吗",
            "谢谢", "多谢", "再见", "拜拜", "晚安", "早安"
        )
        
        for (pattern in explicitChatPatterns) {
            if (normalizedInput.contains(pattern)) {
                LogManager.d(TAG, "💬 检测到明确的聊天模式: $pattern")
                return IntentResult(
                    intent = UserIntent.CASUAL_CHAT,
                    confidence = 0.9f,
                    entities = emptyMap(),
                    suggestedAction = "进行对话交流",
                    needsClarification = false
                ).also { _lastIntent.value = it }
            }
        }
        
        // 计算各类意图的得分
        val scores = mutableMapOf<UserIntent, Float>()
        scores[UserIntent.AUTOMATION_TASK] = calculateTaskScore(normalizedInput)
        scores[UserIntent.INFORMATION_QUERY] = calculateQueryScore(normalizedInput)
        scores[UserIntent.CASUAL_CHAT] = calculateChatScore(normalizedInput)
        scores[UserIntent.SYSTEM_CONTROL] = calculateSystemScore(normalizedInput)
        
        // 考虑上下文影响
        if (context != null) {
            adjustScoresBasedOnContext(scores, context)
        }
        
        // 🎯 如果所有得分都很低，默认为聊天
        val maxScore = scores.maxByOrNull { it.value }
        val intent = if (maxScore == null || maxScore.value < 0.3f) {
            UserIntent.CASUAL_CHAT  // 默认聊天
        } else {
            maxScore.key
        }
        val confidence = maxScore?.value ?: 0.5f
        
        // 检查是否需要澄清
        val needsClarification = confidence < 0.6f || hasAmbiguity(normalizedInput)
        
        // 提取实体
        val entities = extractEntities(normalizedInput, intent)
        
        // 生成建议动作
        val suggestedAction = generateSuggestedAction(intent, entities, normalizedInput)
        
        // 生成澄清问题
        val clarificationQuestion = if (needsClarification) {
            generateClarificationQuestion(intent, normalizedInput)
        } else null
        
        val result = IntentResult(
            intent = intent,
            confidence = confidence,
            entities = entities,
            suggestedAction = suggestedAction,
            needsClarification = needsClarification,
            clarificationQuestion = clarificationQuestion
        )
        
        _lastIntent.value = result
        LogManager.d(TAG, "意图分析结果: $result")
        
        return result
    }
    
    /**
     * 计算任务意图得分
     */
    private fun calculateTaskScore(input: String): Float {
        var score = 0f
        
        // 🔇 排除对话性质的句子（扩展列表）
        val conversationalPhrases = listOf(
            "你在", "你是", "你叫", "在干嘛", "在干啥", "干嘛呢", "干啥呢",
            "你好", "在吗", "在不在", "谢谢", "再见", "拜拜", "早安", "晚安",
            "聊天", "聊聊", "无聊", "开心", "难过", "累了", "吃了吗",
            "你觉得", "你认为", "你喜欢", "你想",
            "干嘴", "啥事", "什么事", "怎么啦", "如何呀"
        )
        
        // 🎯 纯聊天问答模式（直接返回0）
        val pureChatPatterns = listOf(
            "你是谁", "你是什么", "你叫什么", "你叫啥",
            "在干嘛", "在干啥", "做什么呢", "忙什么",
            "吃饭了吗", "睡觉了吗", "你好呀", "在吗",
            "聊聊天", "说说话", "无聊啊", "我好无聊"
        )
        
        for (pattern in pureChatPatterns) {
            if (input.contains(pattern)) {
                return 0f  // 纯聊天，直接返回0
            }
        }
        
        // 如果是对话性质，降低得分
        if (conversationalPhrases.any { input.contains(it) }) {
            score -= 0.3f
        }
        
        // 🎯 检查明确的任务动词（必须同时有动词+对象）
        val strongTaskVerbs = listOf("打开", "启动", "关闭", "发送", "搜索", "播放", "暂停", "下载", "删除", "分享")
        val hasStrongVerb = strongTaskVerbs.any { input.contains(it) }
        
        // 检查应用名称
        val appNames = listOf("微信", "支付宝", "抖音", "淘宝", "京东", "美团", "QQ", "微博", "B站", "快手", "小红书")
        val hasApp = appNames.any { input.contains(it) }
        
        // 🎯 核心逻辑：必须同时有动词+对象才算任务
        if (hasStrongVerb && hasApp) {
            score += 0.7f  // 明确的任务意图
        } else if (hasStrongVerb) {
            score += 0.4f  // 有动词但无对象
        } else if (hasApp) {
            score += 0.2f  // 只提到APP，可能是查询
        }
        
        // 检查任务关键词（降低权重）
        taskKeywords.forEach { keyword ->
            if (input.contains(keyword)) {
                score += 0.15f
            }
        }
        
        // 检查命令式语句特征
        if (input.startsWith("帮我") || input.startsWith("请帮我")) {
            score += 0.2f
        }
        if (input.endsWith("一下") || input.endsWith("吧")) {
            score += 0.1f
        }
        
        return score.coerceIn(0f, 1f)
    }
    
    /**
     * 计算查询意图得分
     */
    private fun calculateQueryScore(input: String): Float {
        var score = 0f
        
        // 🔇 排除对话性质的简单询问（这些应该是闲聊）
        val casualConversations = listOf(
            "你在干嘛", "你在干啥", "在干嘛", "在干啥", "干嘛呢", "干啥呢",
            "你是谁", "在吗", "在不在"
        )
        
        if (casualConversations.any { input.contains(it) }) {
            return 0f  // 这些是闲聊，不是查询
        }
        
        // 特别检测：询问 AI 能力（信息查询类）
        val abilityQuestions = listOf(
            "你可以干吗", "你能干吗", "你会干吗",
            "你可以干啥", "你能干啥", "你会干啥",
            "你可以做什么", "你能做什么", "你会做什么",
            "你有什么能力", "你有什么功能", "你是做什么的",
            "介绍一下你自己", "介绍一下你", "你能帮我什么"
        )
        
        for (pattern in abilityQuestions) {
            if (input.contains(pattern.replace(" ", ""))) {
                return 1.0f  // 直接返回最高分
            }
        }
        
        queryKeywords.forEach { keyword ->
            if (input.contains(keyword)) {
                score += 0.3f
            }
        }
        
        // 问号增加查询可能性
        if (input.contains("?") || input.contains("？")) {
            score += 0.2f
        }
        
        return score.coerceIn(0f, 1f)
    }
    
    /**
     * 计算闲聊意图得分
     */
    private fun calculateChatScore(input: String): Float {
        var score = 0f
        
        // 🎯 纯聊天模式（直接返回高分）
        val pureChatPatterns = listOf(
            "你是谁", "你是什么", "你叫什么", "你叫啥",
            "你在干嘛", "你在干啥", "你在做什么",
            "在干嘛", "在干啥", "干嘛呢", "干啥呢",
            "在吗", "在不在", "你好呀", "你好喔",
            "聊聊天", "聊聊吧", "说说话", "无聊啊", "我好无聊",
            "吃饭了吗", "睡觉了吗", "你吃了吗", "你睡了吗",
            "谢谢你", "多谢", "感谢", "谢谢啦", "谢谢了",
            "再见啦", "拜拜了", "晚安啦", "早安啦"
        )
        
        for (pattern in pureChatPatterns) {
            if (input.contains(pattern)) {
                return 0.9f  // 纯聊天，直接返回高分
            }
        }
        
        // 🎯 优先检测：直接询问 AI 的对话
        val directQuestions = listOf(
            "你是谁", "你是什么", "你叫什么", "你叫啥",
            "你在干嘛", "你在干啥", "你在做什么",
            "在干嘛", "在干啥", "干嘛呢", "干啥呢",
            "在吗", "在不在"
        )
        
        for (question in directQuestions) {
            if (input.contains(question)) {
                score += 0.6f  // 高分！
                break
            }
        }
        
        // 检测对话性质的词
        val conversationalWords = listOf("你", "您", "我", "咱们")
        val hasConversationalTone = conversationalWords.any { input.contains(it) }
        
        chatKeywords.forEach { keyword ->
            if (input.contains(keyword)) {
                score += 0.3f
            }
        }
        
        // 情感词汇
        val emotionWords = listOf("开心", "难过", "生气", "累", "无聊", "兴奋")
        emotionWords.forEach { word ->
            if (input.contains(word)) {
                score += 0.2f
            }
        }
        
        // 🆕 如果有对话性质且得分较低，给予基础分
        if (hasConversationalTone && score < 0.3f && input.length < 10) {
            score += 0.3f
        }
        
        return score.coerceIn(0f, 1f)
    }
    
    /**
     * 计算系统控制意图得分
     */
    private fun calculateSystemScore(input: String): Float {
        var score = 0f
        
        systemKeywords.forEach { keyword ->
            if (input.contains(keyword)) {
                score += 0.4f
            }
        }
        
        // 系统操作动词
        val systemVerbs = listOf("调高", "调低", "打开", "关闭", "开启", "关掉")
        systemVerbs.forEach { verb ->
            if (input.contains(verb)) {
                score += 0.2f
            }
        }
        
        return score.coerceIn(0f, 1f)
    }
    
    /**
     * 根据上下文调整得分
     */
    private fun adjustScoresBasedOnContext(
        scores: MutableMap<UserIntent, Float>,
        context: ConversationContext
    ) {
        LogManager.d(TAG, "🧠 上下文调整: 轮数=${context.conversationTurns}, 上次意图=${context.lastIntent}, 话题=${context.currentTopic}")
        
        // 🆕 检测是否在质疑/责问系统
        if (isQuestioningSystem(context)) {
            LogManager.d(TAG, "🎯 检测到用户在质疑系统，提高闲聊/对话意图")
            scores[UserIntent.CASUAL_CHAT] = scores[UserIntent.CASUAL_CHAT]?.times(2.0f) ?: 0.8f
            scores[UserIntent.AUTOMATION_TASK] = scores[UserIntent.AUTOMATION_TASK]?.times(0.3f) ?: 0f
            scores[UserIntent.INFORMATION_QUERY] = scores[UserIntent.INFORMATION_QUERY]?.times(0.4f) ?: 0f
            return
        }
        
        // 🎯 检测后续操作模式（用户说"继续"、"再来一次"、"下一个"等）
        val lastInput = context.recentMessages.lastOrNull()?.lowercase() ?: ""
        val followUpPatterns = listOf("继续", "再来", "下一个", "还有吗", "然后呢", "接下来", "还要", "还想")
        val isFollowUp = followUpPatterns.any { lastInput.contains(it) }
        
        if (isFollowUp && context.lastIntent != null) {
            LogManager.d(TAG, "🔄 检测到后续操作，保持上次意图: ${context.lastIntent}")
            scores[context.lastIntent!!] = scores[context.lastIntent]?.times(1.5f) ?: 0.7f
        }
        
        // 📱 如果当前在操作某个APP，相关任务得分提高
        if (context.currentApp != null) {
            scores[UserIntent.AUTOMATION_TASK] = scores[UserIntent.AUTOMATION_TASK]?.times(1.3f) ?: 0f
            LogManager.d(TAG, "📱 当前APP: ${context.currentApp}，提高任务得分")
        }
        
        // 🗣️ 连续对话中的意图惯性
        when (context.lastIntent) {
            UserIntent.AUTOMATION_TASK -> {
                // 如果之前在执行任务，后续更可能是任务相关或确认
                if (context.conversationTurns <= 3) {
                    scores[UserIntent.AUTOMATION_TASK] = scores[UserIntent.AUTOMATION_TASK]?.times(1.2f) ?: 0f
                }
            }
            UserIntent.CASUAL_CHAT -> {
                // 如果在闲聊中，继续闲聊的可能性更高
                scores[UserIntent.CASUAL_CHAT] = scores[UserIntent.CASUAL_CHAT]?.times(1.3f) ?: 0f
            }
            UserIntent.INFORMATION_QUERY -> {
                // 如果在查询中，可能有后续问题
                scores[UserIntent.INFORMATION_QUERY] = scores[UserIntent.INFORMATION_QUERY]?.times(1.2f) ?: 0f
                scores[UserIntent.CASUAL_CHAT] = scores[UserIntent.CASUAL_CHAT]?.times(1.1f) ?: 0f
            }
            else -> {}
        }
        
        // 🔄 对话轮数影响：长对话中更容易维持意图
        if (context.conversationTurns > 5) {
            // 长对话中，如果没有明确转换，维持上一个意图
            context.lastIntent?.let { lastIntent ->
                if (scores[lastIntent] != null && scores[lastIntent]!! > 0.3f) {
                    scores[lastIntent] = scores[lastIntent]!! * 1.15f
                }
            }
        }
    }
    
    /**
     * 🔍 检测用户是否在质疑/责问系统
     * 例如：系统说"我没听懂"，用户回复"你为什么不懂"
     */
    private fun isQuestioningSystem(context: ConversationContext): Boolean {
        // 获取最近的对话消息（包括系统回复和用户输入）
        val recentMessages = context.recentMessages
        if (recentMessages.size < 2) return false
        
        // 最后一条是用户输入，倒数第二条是系统回复
        val lastUserInput = recentMessages.lastOrNull()?.lowercase() ?: return false
        val lastSystemResponse = recentMessages.getOrNull(recentMessages.size - 2)?.lowercase() ?: return false
        
        // 系统表示不理解/失败的关键词
        val systemConfusionKeywords = listOf(
            "没听懂", "没理解", "没明白", "不太明白",
            "不清楚", "不确定", "失败", "错误",
            "再说", "详细", "具体", "再试", "抱歉"
        )
        
        // 用户质疑的关键词
        val questioningKeywords = listOf(
            "为什么", "怎么会", "怎么不", 
            "不懂", "不会", "不能", "不明白",
            "干嘛", "干什么", "怎么回事"
        )
        
        // 用户指向系统的词
        val systemReferenceKeywords = listOf(
            "你", "您", "系统", "助手", "ai"
        )
        
        // 检查：系统刚刚表示困惑 + 用户在质疑 + 用户指向系统
        val systemWasConfused = systemConfusionKeywords.any { lastSystemResponse.contains(it) }
        val userIsQuestioning = questioningKeywords.any { lastUserInput.contains(it) }
        val userRefersToSystem = systemReferenceKeywords.any { lastUserInput.contains(it) }
        
        val isQuestioning = systemWasConfused && userIsQuestioning && userRefersToSystem
        
        if (isQuestioning) {
            LogManager.d(TAG, "🎯 用户在质疑系统: 系统困惑=$systemWasConfused, 质疑词=$userIsQuestioning, 指向系统=$userRefersToSystem")
        }
        
        return isQuestioning
    }
    
    /**
     * 检查是否有歧义
     */
    private fun hasAmbiguity(input: String): Boolean {
        // 太短的输入可能有歧义
        if (input.length < 3) return true
        
        // 只有单个词的输入可能有歧义
        if (!input.contains(" ") && input.length < 5) return true
        
        // 包含模糊词汇
        val vagueWords = listOf("这个", "那个", "它", "刚才的", "上面的")
        return vagueWords.any { input.contains(it) }
    }
    
    /**
     * 提取实体信息
     */
    private fun extractEntities(
        input: String,
        intent: UserIntent
    ): Map<String, Any> {
        val entities = mutableMapOf<String, Any>()
        
        when (intent) {
            UserIntent.AUTOMATION_TASK -> {
                // 提取应用名称
                val appPattern = "(微信|支付宝|抖音|淘宝|QQ|微博|B站|知乎|网易云)".toRegex()
                appPattern.find(input)?.let {
                    entities["app"] = it.value
                }
                
                // 提取联系人
                val contactPattern = "给(.+?)发".toRegex()
                contactPattern.find(input)?.let {
                    entities["contact"] = it.groupValues[1]
                }
                
                // 提取消息内容
                val messagePattern = "发送?(.+)$".toRegex()
                messagePattern.find(input)?.let {
                    entities["message"] = it.groupValues[1]
                }
            }
            
            UserIntent.SYSTEM_CONTROL -> {
                // 提取数值
                val numberPattern = "(\\d+)".toRegex()
                numberPattern.find(input)?.let {
                    entities["value"] = it.value.toInt()
                }
                
                // 提取方向
                if (input.contains("调高") || input.contains("增加")) {
                    entities["direction"] = "up"
                } else if (input.contains("调低") || input.contains("减少")) {
                    entities["direction"] = "down"
                }
            }
            
            UserIntent.INFORMATION_QUERY -> {
                // 提取查询主题
                val topicPattern = "什么是(.+)".toRegex()
                topicPattern.find(input)?.let {
                    entities["topic"] = it.groupValues[1]
                }
            }
            
            else -> {
                // 其他意图暂不提取
            }
        }
        
        return entities
    }
    
    /**
     * 生成建议动作
     */
    private fun generateSuggestedAction(
        intent: UserIntent,
        entities: Map<String, Any>,
        input: String
    ): String? {
        return when (intent) {
            UserIntent.AUTOMATION_TASK -> {
                when {
                    entities.containsKey("app") -> "启动${entities["app"]}应用"
                    input.contains("截图") -> "执行屏幕截图"
                    input.contains("返回") -> "返回上一页"
                    else -> "执行自动化任务"
                }
            }
            UserIntent.SYSTEM_CONTROL -> {
                when {
                    input.contains("音量") -> "调节系统音量"
                    input.contains("亮度") -> "调节屏幕亮度"
                    input.contains("WiFi") -> "切换WiFi状态"
                    else -> "执行系统控制"
                }
            }
            UserIntent.INFORMATION_QUERY -> "搜索相关信息"
            UserIntent.CASUAL_CHAT -> "进行对话交流"
            else -> null
        }
    }
    
    /**
     * 生成澄清问题
     */
    private fun generateClarificationQuestion(
        intent: UserIntent,
        input: String
    ): String {
        return when {
            input.length < 3 -> "请问您想要做什么呢？可以说得详细一点吗？"
            intent == UserIntent.UNCLEAR -> "抱歉我没有理解，您是想要执行操作还是聊天呢？"
            intent == UserIntent.AUTOMATION_TASK && !input.contains("微信") && !input.contains("支付宝") -> 
                "请问您想在哪个应用中执行这个操作？"
            else -> "请问您能说得更具体一些吗？"
        }
    }
}

/**
 * 对话上下文
 */
data class ConversationContext(
    val lastIntent: IntentClassifier.UserIntent? = null,
    val lastEntities: Map<String, Any> = emptyMap(),
    val conversationTurns: Int = 0,
    val currentTopic: String? = null,
    val recentMessages: List<String> = emptyList(),
    val currentApp: String? = null,
    val screenType: String? = null
)

// ==================== 🔧 增强功能：高级意图分析 ====================

/**
 * 🎯 多意图识别结果
 */
data class MultiIntentResult(
    val primaryIntent: IntentClassifier.IntentResult,
    val secondaryIntents: List<IntentClassifier.IntentResult> = emptyList(),
    val hasMultipleIntents: Boolean = false,
    val intentSequence: List<String> = emptyList()  // 意图执行顺序
)

/**
 * 🧠 增强意图分析器
 * 提供更高级的意图理解功能
 */
object EnhancedIntentAnalyzer {
    
    private const val TAG = "EnhancedIntent"
    
    // 🔍 模糊意图映射表
    private val vagueIntentMappings = mapOf(
        "帮我处理一下" to listOf("需要更多信息", "请问您想处理什么？"),
        "搞定它" to listOf("需要更多信息", "请问您想搞定什么？"),
        "弄一下" to listOf("需要更多信息", "请问您想弄什么？"),
        "看看" to listOf("INFORMATION_QUERY", "请问您想看什么？"),
        "试试" to listOf("AUTOMATION_TASK", "请问您想试什么？"),
        "快点" to listOf("需要上下文", "快点做什么呢？"),
        "继续" to listOf("需要上下文", "继续之前的操作吗？"),
        "算了" to listOf("CANCEL", "好的，取消了~"),
        "不用了" to listOf("CANCEL", "好的，那就不做了~")
    )
    
    // 🎯 领域特定关键词
    private val domainKeywords = mapOf(
        "消息" to listOf("微信", "QQ", "短信", "发送", "回复", "消息", "私信", "聊天"),
        "购物" to listOf("淘宝", "京东", "拼多多", "购买", "下单", "加购", "购物车", "支付"),
        "办公" to listOf("文档", "Excel", "PPT", "邮件", "会议", "日程", "笔记", "提醒"),
        "娱乐" to listOf("抖音", "B站", "视频", "音乐", "游戏", "直播", "追剧"),
        "出行" to listOf("滴滴", "打车", "导航", "地图", "路线", "公交", "地铁"),
        "生活" to listOf("外卖", "美团", "饿了么", "点餐", "天气", "闹钟", "日历")
    )
    
    // 🔗 多意图连接词
    private val intentConnectors = listOf(
        "然后", "接着", "之后", "再", "并且", "同时", "还要", "顺便", "完了后"
    )
    
    /**
     * 🎯 分析多意图
     * 一句话可能包含多个任务
     */
    fun analyzeMultipleIntents(
        input: String,
        classifier: IntentClassifier,
        context: ConversationContext? = null
    ): MultiIntentResult {
        LogManager.d(TAG, "🔍 分析多意图: $input")
        
        // 检测是否包含连接词
        val hasConnector = intentConnectors.any { input.contains(it) }
        
        if (!hasConnector) {
            // 单一意图
            val result = classifier.classifyIntent(input, context)
            return MultiIntentResult(primaryIntent = result)
        }
        
        // 🔗 分割多意图
        val intentParts = splitByConnectors(input)
        LogManager.d(TAG, "📋 分割出 ${intentParts.size} 个意图部分")
        
        if (intentParts.size <= 1) {
            val result = classifier.classifyIntent(input, context)
            return MultiIntentResult(primaryIntent = result)
        }
        
        // 分析每个部分的意图
        val intents = intentParts.map { part ->
            classifier.classifyIntent(part.trim(), context)
        }
        
        return MultiIntentResult(
            primaryIntent = intents.first(),
            secondaryIntents = intents.drop(1),
            hasMultipleIntents = true,
            intentSequence = intentParts
        )
    }
    
    /**
     * 🔗 按连接词分割输入
     */
    private fun splitByConnectors(input: String): List<String> {
        var remaining = input
        val parts = mutableListOf<String>()
        
        for (connector in intentConnectors) {
            if (remaining.contains(connector)) {
                val splitResult = remaining.split(connector, limit = 2)
                if (splitResult.size == 2) {
                    if (splitResult[0].isNotBlank()) {
                        parts.add(splitResult[0].trim())
                    }
                    remaining = splitResult[1]
                }
            }
        }
        
        if (remaining.isNotBlank()) {
            parts.add(remaining.trim())
        }
        
        return if (parts.isEmpty()) listOf(input) else parts
    }
    
    /**
     * 🤔 处理模糊意图
     */
    fun handleVagueIntent(
        input: String,
        context: ConversationContext?
    ): Pair<String, String>? {
        val normalizedInput = input.trim()
        
        // 检查是否是已知的模糊表达
        for ((vague, mapping) in vagueIntentMappings) {
            if (normalizedInput.contains(vague)) {
                val intentType = mapping[0]
                val clarification = mapping[1]
                
                // 如果有上下文，尝试理解
                if (context != null && intentType == "需要上下文") {
                    context.currentTopic?.let { topic ->
                        return Pair("AUTOMATION_TASK", "继续$topic")
                    }
                }
                
                return Pair(intentType, clarification)
            }
        }
        
        return null
    }
    
    /**
     * 🏷️ 识别领域
     */
    fun identifyDomain(input: String): String? {
        val normalizedInput = input.lowercase()
        
        for ((domain, keywords) in domainKeywords) {
            val matchCount = keywords.count { normalizedInput.contains(it) }
            if (matchCount >= 1) {
                LogManager.d(TAG, "🏷️ 识别到领域: $domain (匹配 $matchCount 个关键词)")
                return domain
            }
        }
        
        return null
    }
    
    /**
     * 📊 评估意图置信度
     */
    fun evaluateConfidence(
        result: IntentClassifier.IntentResult,
        context: ConversationContext?
    ): ConfidenceEvaluation {
        var confidence = result.confidence
        var reasons = mutableListOf<String>()
        
        // 上下文一致性加分
        if (context?.lastIntent == result.intent) {
            confidence += 0.1f
            reasons.add("与上下文一致")
        }
        
        // 实体完整性评估
        val entityCompleteness = when (result.intent) {
            IntentClassifier.UserIntent.AUTOMATION_TASK -> {
                if (result.entities.containsKey("app")) 0.2f else -0.1f
            }
            IntentClassifier.UserIntent.SYSTEM_CONTROL -> {
                if (result.entities.containsKey("direction") || result.entities.containsKey("value")) 0.15f else 0f
            }
            else -> 0f
        }
        confidence += entityCompleteness
        if (entityCompleteness > 0) reasons.add("实体信息完整")
        
        // 对话轮次影响
        if (context != null && context.conversationTurns > 3) {
            confidence += 0.05f
            reasons.add("多轮对话上下文")
        }
        
        confidence = confidence.coerceIn(0f, 1f)
        
        val level = when {
            confidence >= 0.8f -> IntentConfidenceLevel.HIGH
            confidence >= 0.6f -> IntentConfidenceLevel.MEDIUM
            confidence >= 0.4f -> IntentConfidenceLevel.LOW
            else -> IntentConfidenceLevel.VERY_LOW
        }
        
        return ConfidenceEvaluation(
            confidence = confidence,
            level = level,
            reasons = reasons,
            shouldAskClarification = level == IntentConfidenceLevel.VERY_LOW || level == IntentConfidenceLevel.LOW
        )
    }
    
    /**
     * 🔄 上下文感知意图修正
     */
    fun refineIntentWithContext(
        result: IntentClassifier.IntentResult,
        context: ConversationContext?
    ): IntentClassifier.IntentResult {
        if (context == null) return result
        
        var refinedEntities = result.entities.toMutableMap()
        var refinedIntent = result.intent
        
        // 如果缺少应用名，从上下文补充
        if (!refinedEntities.containsKey("app") && context.currentApp != null) {
            refinedEntities["app"] = context.currentApp
            LogManager.d(TAG, "🔄 从上下文补充应用: ${context.currentApp}")
        }
        
        // 如果缺少联系人，从上下文补充
        if (!refinedEntities.containsKey("contact") && context.lastEntities.containsKey("contact")) {
            context.lastEntities["contact"]?.let { contact ->
                refinedEntities["contact"] = contact
                LogManager.d(TAG, "🔄 从上下文补充联系人")
            }
        }
        
        // 指代消解：处理"它"、"这个"等代词
        val hasReference = result.entities.values.any { 
            it.toString().contains("它") || it.toString().contains("这个") || it.toString().contains("那个")
        }
        if (hasReference && context.lastEntities.isNotEmpty()) {
            // 用上下文实体替换代词
            context.lastEntities.forEach { (key, value) ->
                if (!refinedEntities.containsKey(key)) {
                    refinedEntities[key] = value
                }
            }
            LogManager.d(TAG, "🔄 指代消解: 用上下文实体替换代词")
        }
        
        return result.copy(
            entities = refinedEntities,
            confidence = (result.confidence + 0.1f).coerceAtMost(1f)
        )
    }
}

/**
 * 📊 意图置信度等级
 */
enum class IntentConfidenceLevel {
    HIGH,       // >= 0.8
    MEDIUM,     // >= 0.6
    LOW,        // >= 0.4
    VERY_LOW    // < 0.4
}

/**
 * 📊 置信度评估结果
 */
data class ConfidenceEvaluation(
    val confidence: Float,
    val level: IntentConfidenceLevel,
    val reasons: List<String>,
    val shouldAskClarification: Boolean
)

/**
 * 将规则意图结果转换为统一的核心 UserIntent 模型
 */
fun IntentClassifier.IntentResult.toCoreUserIntent(originalText: String): CoreUserIntent {
    val entitiesString = entities.mapValues { it.value.toString() }
    val baseType = when (intent) {
        IntentClassifier.UserIntent.CASUAL_CHAT -> "casual_chat"
        IntentClassifier.UserIntent.AUTOMATION_TASK -> "automation_task"
        IntentClassifier.UserIntent.INFORMATION_QUERY -> "information_query"
        IntentClassifier.UserIntent.SYSTEM_CONTROL -> "system_control"
        IntentClassifier.UserIntent.MIXED_INTENT -> "mixed_intent"
        IntentClassifier.UserIntent.UNCLEAR -> "unclear"
    }
    val lower = originalText.lowercase()
    val isSendMessageLike = intent == IntentClassifier.UserIntent.AUTOMATION_TASK &&
            ("发消息" in lower || "发信息" in lower || "发微信" in lower ||
             "发qq" in lower || "发 qq" in lower || "给" in lower && "说" in lower)
    val type = if (isSendMessageLike) "send_message" else baseType
    return CoreUserIntent(
        type = type,
        confidence = confidence.toDouble(),
        entities = entitiesString,
        parameters = null,
        reasoning = "rule_intent:$intent score=$confidence",
        originalText = originalText
    )
}
