package com.example.xihe.ai

import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.core.ContextMemory
import com.example.xihe.core.UserIntent as CoreUserIntent

/**
 * 🧠 智能理解引擎 (Smart Understanding Engine)
 * 
 * 整合记忆系统、学习系统和意图识别，实现真正的"听懂人话"
 * 
 * 功能：
 * 1. 多轮对话理解 - 结合上下文理解用户意图
 * 2. 模糊意图识别 - 即使表达不清楚也能理解
 * 3. 个性化理解 - 根据用户习惯调整理解
 * 4. 学习改进 - 从反馈中不断改进理解能力
 */
object SmartUnderstandingEngine {
    
    private const val TAG = "SmartUnderstanding"
    
    // ==================== 理解结果 ====================
    
    data class UnderstandingResult(
        val understood: Boolean,           // 是否理解
        val intent: String,                // 识别的意图
        val confidence: Float,             // 置信度
        val entities: Map<String, String>, // 提取的实体
        val response: String,              // 建议的回复
        val action: ActionSuggestion?,     // 建议的操作
        val clarificationNeeded: Boolean = false,  // 是否需要澄清
        val clarificationQuestion: String? = null  // 澄清问题
    )
    
    data class ActionSuggestion(
        val actionType: String,
        val parameters: Map<String, Any>,
        val description: String
    )
    
    // ==================== 表达方式映射 ====================
    
    // 同义词和口语化表达映射
    private val synonymMap = mapOf(
        // 打开相关
        "开" to "打开", "启动" to "打开", "进入" to "打开", "运行" to "打开",
        "开启" to "打开", "启用" to "打开", "点开" to "打开", "打开看看" to "打开",
        
        // 关闭相关
        "关" to "关闭", "退出" to "关闭", "关掉" to "关闭", "停止" to "关闭",
        "关上" to "关闭", "结束" to "关闭", "杀掉" to "关闭",
        
        // 发送消息相关
        "发" to "发送", "说" to "发送", "告诉" to "发送", "传" to "发送",
        "给...说" to "发消息", "跟...说" to "发消息", "和...说" to "发消息",
        
        // 搜索相关
        "搜" to "搜索", "查" to "搜索", "找" to "搜索", "百度一下" to "搜索",
        "谷歌一下" to "搜索", "搜一下" to "搜索", "查一下" to "搜索",
        
        // 播放相关
        "放" to "播放", "听" to "播放", "看" to "播放", "来一首" to "播放",
        "播" to "播放", "放一下" to "播放",
        
        // 暂停相关
        "停" to "暂停", "停一下" to "暂停", "别放了" to "暂停",
        
        // 调节相关
        "大点" to "增大", "大声点" to "增大音量", "小点" to "减小", 
        "小声点" to "减小音量", "亮点" to "增加亮度", "暗点" to "降低亮度"
    )
    
    // 口语化时间表达
    private val timeExpressionMap = mapOf(
        "等会" to "5分钟后", "待会" to "10分钟后", "一会" to "10分钟后",
        "马上" to "1分钟后", "立刻" to "现在", "现在" to "现在",
        "明早" to "明天早上", "今晚" to "今天晚上", "后天" to "后天",
        "大后天" to "3天后", "下周" to "7天后", "下个月" to "30天后"
    )
    
    // 模糊指代词
    private val pronounMap = mapOf(
        "那个" to "上次提到的", "这个" to "当前的", "它" to "上次提到的",
        "他" to "上次提到的人", "她" to "上次提到的人", "那边" to "上次提到的地方"
    )
    
    // ==================== 核心理解方法 ====================
    
    /**
     * 🧠 智能理解用户输入
     */
    fun understand(
        input: String,
        context: Context?,
        conversationHistory: List<Pair<String, String>> = emptyList()
    ): UnderstandingResult {
        LogManager.d(TAG, "🧠 开始理解: $input")
        
        // 1. 预处理输入
        val processedInput = preprocessInput(input)
        LogManager.d(TAG, "预处理后: $processedInput")
        
        // 2. 从记忆中获取上下文
        val memoryContext = getMemoryContext()
        
        // 3. 解析指代词
        val resolvedInput = resolvePronouns(processedInput, conversationHistory, memoryContext)
        LogManager.d(TAG, "指代解析后: $resolvedInput")
        
        // 4. 使用本地识别器
        val localResult = LocalIntentRecognizer.recognize(resolvedInput)
        
        // 5. 如果本地识别成功且置信度高
        if (localResult.isRecognized && localResult.confidence >= 0.8f) {
            LogManager.d(TAG, "✅ 本地识别成功: ${localResult.intent}")
            return createResultFromLocal(localResult, input)
        }
        
        // 6. 尝试模糊匹配
        val fuzzyResult = fuzzyMatch(resolvedInput, memoryContext)
        if (fuzzyResult != null && fuzzyResult.confidence >= 0.7f) {
            LogManager.d(TAG, "✅ 模糊匹配成功: ${fuzzyResult.intent}")
            return fuzzyResult
        }
        
        // 7. 使用上下文推断
        val contextResult = inferFromContext(resolvedInput, conversationHistory, memoryContext)
        if (contextResult != null && contextResult.confidence >= 0.6f) {
            LogManager.d(TAG, "✅ 上下文推断成功: ${contextResult.intent}")
            return contextResult
        }
        
        // 8. 如果还是无法理解，返回需要澄清
        return createClarificationResult(input, localResult)
    }
    
    /**
     * 预处理输入 - 标准化表达
     */
    private fun preprocessInput(input: String): String {
        var processed = input.trim().lowercase()
        
        // 移除语气词
        val fillerWords = listOf("嗯", "啊", "呃", "那个", "就是", "然后呢", "好吧")
        fillerWords.forEach { processed = processed.replace(it, " ") }
        
        // 替换同义词
        synonymMap.forEach { (from, to) ->
            if (processed.contains(from)) {
                processed = processed.replace(from, to)
            }
        }
        
        // 替换口语化时间表达
        timeExpressionMap.forEach { (from, to) ->
            if (processed.contains(from)) {
                processed = processed.replace(from, to)
            }
        }
        
        return processed.replace(Regex("\\s+"), " ").trim()
    }
    
    /**
     * 从记忆中获取上下文
     */
    private fun getMemoryContext(): MemoryContext {
        val nickname = ContextMemory.getUserNickname()
        val aiName = ContextMemory.getAIName()
        val people = ContextMemory.getUserProfile().importantPeople
        val history = ContextMemory.getConversationHistory()
        
        return MemoryContext(
            userNickname = nickname,
            aiName = aiName,
            knownPeople = people.keys.toList(),
            recentTopics = extractTopics(history),
            lastMentionedPerson = extractLastPerson(history),
            lastMentionedApp = extractLastApp(history)
        )
    }
    
    /**
     * 解析指代词
     */
    private fun resolvePronouns(
        input: String,
        history: List<Pair<String, String>>,
        memoryContext: MemoryContext
    ): String {
        var resolved = input
        
        // 解析"他/她" -> 上次提到的人
        if (input.contains("他") || input.contains("她")) {
            memoryContext.lastMentionedPerson?.let { person ->
                resolved = resolved.replace("他", person).replace("她", person)
            }
        }
        
        // 解析"那个App" -> 上次提到的App
        if (input.contains("那个app") || input.contains("那个应用")) {
            memoryContext.lastMentionedApp?.let { app ->
                resolved = resolved.replace("那个app", app).replace("那个应用", app)
            }
        }
        
        return resolved
    }
    
    /**
     * 模糊匹配
     */
    private fun fuzzyMatch(input: String, memoryContext: MemoryContext): UnderstandingResult? {
        // 检查是否在问候
        if (isGreeting(input)) {
            return UnderstandingResult(
                understood = true,
                intent = "greeting",
                confidence = 0.95f,
                entities = emptyMap(),
                response = getGreetingResponse(memoryContext),
                action = null
            )
        }
        
        // 检查是否在询问能力
        if (isAskingCapability(input)) {
            return UnderstandingResult(
                understood = true,
                intent = "capability_query",
                confidence = 0.9f,
                entities = emptyMap(),
                response = getCapabilityResponse(),
                action = null
            )
        }
        
        // 检查是否在感谢
        if (isThanking(input)) {
            return UnderstandingResult(
                understood = true,
                intent = "thanks",
                confidence = 0.95f,
                entities = emptyMap(),
                response = "不客气呀～能帮到你我很开心！还有什么需要的吗？😊",
                action = null
            )
        }
        
        // 检查是否是简单的应用操作
        val appResult = fuzzyMatchApp(input)
        if (appResult != null) return appResult
        
        // 检查是否是系统操作
        val systemResult = fuzzyMatchSystem(input)
        if (systemResult != null) return systemResult
        
        return null
    }
    
    /**
     * 模糊匹配应用操作
     */
    private fun fuzzyMatchApp(input: String): UnderstandingResult? {
        val appKeywords = mapOf(
            "微信" to "com.tencent.mm",
            "qq" to "com.tencent.mobileqq",
            "抖音" to "com.ss.android.ugc.aweme",
            "快手" to "com.smile.gifmaker",
            "淘宝" to "com.taobao.taobao",
            "支付宝" to "com.eg.android.AlipayGphone",
            "美团" to "com.sankuai.meituan",
            "饿了么" to "me.ele",
            "哔哩哔哩" to "tv.danmaku.bili",
            "微博" to "com.sina.weibo",
            "知乎" to "com.zhihu.android",
            "网易云音乐" to "com.netease.cloudmusic",
            "qq音乐" to "com.tencent.qqmusic",
            "酷狗音乐" to "com.kugou.android",
            "高德地图" to "com.autonavi.minimap",
            "百度地图" to "com.baidu.BaiduMap",
            "滴滴" to "com.sdu.didi.psnger",
            "京东" to "com.jingdong.app.mall",
            "拼多多" to "com.xunmeng.pinduoduo",
            "相机" to "camera",
            "设置" to "settings",
            "相册" to "gallery",
            "计算器" to "calculator",
            "日历" to "calendar",
            "时钟" to "clock",
            "备忘录" to "notes",
            "浏览器" to "browser"
        )
        
        for ((appName, _) in appKeywords) {
            if (input.contains(appName)) {
                val action = when {
                    input.contains("打开") || input.contains("启动") || input.contains("进") -> "open_app"
                    input.contains("关闭") || input.contains("退出") || input.contains("关") -> "close_app"
                    else -> "open_app"  // 默认打开
                }
                
                return UnderstandingResult(
                    understood = true,
                    intent = action,
                    confidence = 0.85f,
                    entities = mapOf("app_name" to appName),
                    response = if (action == "open_app") "好的，帮你打开$appName~" else "好的，帮你关闭$appName~",
                    action = ActionSuggestion(
                        actionType = action,
                        parameters = mapOf("app" to appName),
                        description = "${if (action == "open_app") "打开" else "关闭"}$appName"
                    )
                )
            }
        }
        
        return null
    }
    
    /**
     * 模糊匹配系统操作
     */
    private fun fuzzyMatchSystem(input: String): UnderstandingResult? {
        val systemActions = mapOf(
            listOf("截图", "截屏", "屏幕截图") to Pair("screenshot", "截图"),
            listOf("返回", "后退", "回去") to Pair("go_back", "返回"),
            listOf("主页", "桌面", "回到主页") to Pair("go_home", "回到主页"),
            listOf("音量大", "声音大", "大声") to Pair("volume_up", "增大音量"),
            listOf("音量小", "声音小", "小声") to Pair("volume_down", "减小音量"),
            listOf("静音", "关闭声音") to Pair("mute", "静音"),
            listOf("亮度高", "亮点", "屏幕亮") to Pair("brightness_up", "增加亮度"),
            listOf("亮度低", "暗点", "屏幕暗") to Pair("brightness_down", "降低亮度"),
            listOf("wifi", "无线网") to Pair("toggle_wifi", "切换WiFi"),
            listOf("蓝牙") to Pair("toggle_bluetooth", "切换蓝牙"),
            listOf("飞行模式") to Pair("toggle_airplane", "切换飞行模式"),
            listOf("手电筒", "闪光灯") to Pair("toggle_flashlight", "切换手电筒")
        )
        
        for ((keywords, actionPair) in systemActions) {
            if (keywords.any { input.contains(it) }) {
                return UnderstandingResult(
                    understood = true,
                    intent = actionPair.first,
                    confidence = 0.9f,
                    entities = emptyMap(),
                    response = "好的，${actionPair.second}~",
                    action = ActionSuggestion(
                        actionType = actionPair.first,
                        parameters = emptyMap(),
                        description = actionPair.second
                    )
                )
            }
        }
        
        return null
    }
    
    /**
     * 从上下文推断意图
     */
    private fun inferFromContext(
        input: String,
        history: List<Pair<String, String>>,
        memoryContext: MemoryContext
    ): UnderstandingResult? {
        if (history.isEmpty()) return null
        
        val lastUserMsg = history.lastOrNull()?.first ?: return null
        val lastAiResp = history.lastOrNull()?.second ?: return null
        
        // 如果上一轮是确认问题，这一轮可能是回答
        if (lastAiResp.contains("是否") || lastAiResp.contains("要不要") || lastAiResp.contains("确认")) {
            if (isAffirmative(input)) {
                return UnderstandingResult(
                    understood = true,
                    intent = "confirm_yes",
                    confidence = 0.9f,
                    entities = emptyMap(),
                    response = "好的，马上执行~",
                    action = null
                )
            } else if (isNegative(input)) {
                return UnderstandingResult(
                    understood = true,
                    intent = "confirm_no",
                    confidence = 0.9f,
                    entities = emptyMap(),
                    response = "好的，已取消~",
                    action = null
                )
            }
        }
        
        // 如果是追问细节
        if (input.length < 10 && !input.contains("打开") && !input.contains("关闭")) {
            // 可能是在补充信息
            return UnderstandingResult(
                understood = true,
                intent = "supplement_info",
                confidence = 0.7f,
                entities = mapOf("info" to input),
                response = "收到补充信息~",
                action = null
            )
        }
        
        return null
    }
    
    /**
     * 创建需要澄清的结果
     */
    private fun createClarificationResult(
        input: String,
        localResult: LocalIntentRecognizer.IntentResult
    ): UnderstandingResult {
        val question = when {
            input.length < 5 -> "你想让我做什么呢？可以说得详细一点吗？"
            input.contains("打开") -> "你想打开哪个应用呢？"
            input.contains("发") && input.contains("消息") -> "你想发消息给谁？说什么内容呢？"
            input.contains("搜") -> "你想搜索什么内容呢？"
            else -> "我不太确定你的意思，可以说得更具体一点吗？比如'打开微信'或'帮我搜索xxx'"
        }
        
        return UnderstandingResult(
            understood = false,
            intent = "unclear",
            confidence = localResult.confidence,
            entities = localResult.params,
            response = question,
            action = null,
            clarificationNeeded = true,
            clarificationQuestion = question
        )
    }
    
    /**
     * 从本地识别结果创建理解结果
     */
    private fun createResultFromLocal(
        localResult: LocalIntentRecognizer.IntentResult,
        originalInput: String
    ): UnderstandingResult {
        val response = when (localResult.intent) {
            "send_wechat_message" -> {
                val contact = localResult.params["contact"] ?: "对方"
                val message = localResult.params["message"] ?: ""
                "好的，帮你给$contact 发消息：$message"
            }
            "web_search" -> {
                val query = localResult.params["query"] ?: localResult.params["originalQuery"] ?: ""
                "好的，帮你搜索：$query"
            }
            "open_app" -> {
                val app = localResult.params["app_name"] ?: ""
                "好的，帮你打开$app"
            }
            "gesture_swipe" -> {
                val direction = localResult.params["direction_chinese"] ?: "向上"
                "好的，${direction}滑动"
            }
            "screen_view" -> "好的，让我看看屏幕上有什么"
            else -> "好的，正在处理..."
        }
        
        return UnderstandingResult(
            understood = true,
            intent = localResult.intent ?: "unknown",
            confidence = localResult.confidence,
            entities = localResult.params,
            response = response,
            action = createActionFromIntent(localResult)
        )
    }
    
    /**
     * 从意图创建操作建议
     */
    private fun createActionFromIntent(result: LocalIntentRecognizer.IntentResult): ActionSuggestion? {
        return when (result.intent) {
            "send_wechat_message" -> ActionSuggestion(
                actionType = "send_message",
                parameters = mapOf(
                    "app" to "微信",
                    "contact" to (result.params["contact"] ?: ""),
                    "message" to (result.params["message"] ?: "")
                ),
                description = "发送微信消息"
            )
            "open_app" -> ActionSuggestion(
                actionType = "open_app",
                parameters = mapOf("app" to (result.params["app_name"] ?: "")),
                description = "打开应用"
            )
            "gesture_swipe" -> ActionSuggestion(
                actionType = "swipe",
                parameters = mapOf("direction" to (result.params["direction"] ?: "UP")),
                description = result.params["action_description"] ?: "滑动"
            )
            else -> null
        }
    }
    
    // ==================== 辅助方法 ====================
    
    private fun isGreeting(input: String): Boolean {
        val greetings = listOf("你好", "早上好", "下午好", "晚上好", "嗨", "hi", "hello", 
            "早安", "午安", "晚安", "在吗", "在不在")
        return greetings.any { input.contains(it) }
    }
    
    private fun isAskingCapability(input: String): Boolean {
        val patterns = listOf("你能", "你会", "你可以", "能做什么", "会什么", "有什么功能")
        return patterns.any { input.contains(it) }
    }
    
    private fun isThanking(input: String): Boolean {
        val thanks = listOf("谢谢", "感谢", "多谢", "thank", "3q", "蟹蟹")
        return thanks.any { input.contains(it) }
    }
    
    private fun isAffirmative(input: String): Boolean {
        val affirmatives = listOf("是", "好", "对", "行", "可以", "没问题", "ok", "yes", "嗯", "确认")
        return affirmatives.any { input.trim() == it || input.contains(it) }
    }
    
    private fun isNegative(input: String): Boolean {
        val negatives = listOf("不", "否", "算了", "取消", "no", "不要", "不用", "别")
        return negatives.any { input.contains(it) }
    }
    
    private fun getGreetingResponse(context: MemoryContext): String {
        val greeting = when {
            java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) < 12 -> "早上好"
            java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) < 18 -> "下午好"
            else -> "晚上好"
        }
        
        return if (context.userNickname.isNotBlank()) {
            "$greeting，${context.userNickname}！我是${context.aiName}，有什么可以帮你的吗？😊"
        } else {
            "$greeting！我是${context.aiName}，有什么可以帮你的吗？😊"
        }
    }
    
    private fun getCapabilityResponse(): String {
        return """
            我可以帮你做很多事情呢！😊
            
            📱 **应用控制**：打开/关闭应用
            💬 **发消息**：给微信、QQ好友发消息
            🔍 **搜索**：帮你搜索各种信息
            📸 **屏幕操作**：截图、滑动、点击
            🎵 **媒体控制**：播放/暂停音乐
            ⏰ **提醒设置**：设置闹钟和提醒
            🗺️ **导航**：帮你导航到目的地
            🧠 **记忆**：记住你告诉我的事情
            
            直接说出你想做的，我来帮你完成！
        """.trimIndent()
    }
    
    private fun extractTopics(history: List<Pair<String, String>>): List<String> {
        // 简单提取最近话题
        return history.takeLast(5).flatMap { (user, _) ->
            listOf(user)
        }
    }
    
    private fun extractLastPerson(history: List<Pair<String, String>>): String? {
        val personPatterns = listOf(
            Regex("给(.{2,4})(发|说)"),
            Regex("告诉(.{2,4})"),
            Regex("(.{2,4})说")
        )
        
        for ((msg, _) in history.reversed()) {
            for (pattern in personPatterns) {
                val match = pattern.find(msg)
                if (match != null) {
                    return match.groupValues[1]
                }
            }
        }
        return null
    }
    
    private fun extractLastApp(history: List<Pair<String, String>>): String? {
        val apps = listOf("微信", "qq", "抖音", "淘宝", "支付宝", "美团", "饿了么")
        
        for ((msg, _) in history.reversed()) {
            for (app in apps) {
                if (msg.contains(app)) return app
            }
        }
        return null
    }
    
    // ==================== 数据类 ====================
    
    data class MemoryContext(
        val userNickname: String,
        val aiName: String,
        val knownPeople: List<String>,
        val recentTopics: List<String>,
        val lastMentionedPerson: String?,
        val lastMentionedApp: String?
    )
}
