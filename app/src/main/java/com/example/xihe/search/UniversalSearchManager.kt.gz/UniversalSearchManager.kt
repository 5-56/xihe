package com.example.xihe.search

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.xihe.utils.LogManager
import com.example.xihe.CoreAccessibilityService
import kotlinx.coroutines.delay

/**
 * 🔍 通用搜索管理器
 * 支持在各种应用中执行搜索操作
 */
class UniversalSearchManager private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "UniversalSearchManager"
        
        @Volatile
        private var instance: UniversalSearchManager? = null
        
        fun getInstance(context: Context): UniversalSearchManager {
            return instance ?: synchronized(this) {
                instance ?: UniversalSearchManager(context.applicationContext).also { instance = it }
            }
        }
    }
    
    /**
     * 搜索平台
     */
    enum class SearchPlatform {
        GOOGLE,         // Google搜索
        BAIDU,          // 百度搜索
        TAOBAO,         // 淘宝搜索
        JD,             // 京东搜索
        WECHAT,         // 微信搜索
        DOUYIN,         // 抖音搜索
        BILIBILI,       // B站搜索
        ZHIHU,          // 知乎搜索
        WEIBO,          // 微博搜索
        XIAOHONGSHU,    // 小红书搜索
        APP             // 应用内搜索
    }
    
    /**
     * 搜索结果
     */
    data class SearchResult(
        val success: Boolean,
        val platform: SearchPlatform,
        val keyword: String,
        val message: String? = null
    )
    
    /**
     * 🔍 通用搜索
     */
    suspend fun search(
        platform: SearchPlatform,
        keyword: String
    ): SearchResult {
        return try {
            when (platform) {
                SearchPlatform.GOOGLE -> searchGoogle(keyword)
                SearchPlatform.BAIDU -> searchBaidu(keyword)
                SearchPlatform.TAOBAO -> searchTaobao(keyword)
                SearchPlatform.JD -> searchJD(keyword)
                SearchPlatform.WECHAT -> searchWeChat(keyword)
                SearchPlatform.DOUYIN -> searchDouyin(keyword)
                SearchPlatform.BILIBILI -> searchBilibili(keyword)
                SearchPlatform.ZHIHU -> searchZhihu(keyword)
                SearchPlatform.WEIBO -> searchWeibo(keyword)
                SearchPlatform.XIAOHONGSHU -> searchXiaohongshu(keyword)
                SearchPlatform.APP -> searchInCurrentApp(keyword)
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "搜索失败", e)
            SearchResult(false, platform, keyword, e.message)
        }
    }
    
    /**
     * 🌐 Google搜索
     */
    private fun searchGoogle(keyword: String): SearchResult {
        return try {
            val url = "https://www.google.com/search?q=${Uri.encode(keyword)}"
            openUrl(url)
            LogManager.i(TAG, "✅ Google搜索: $keyword")
            SearchResult(true, SearchPlatform.GOOGLE, keyword, "已在Google搜索")
        } catch (e: Exception) {
            SearchResult(false, SearchPlatform.GOOGLE, keyword, e.message)
        }
    }
    
    /**
     * 🌐 百度搜索
     */
    private fun searchBaidu(keyword: String): SearchResult {
        return try {
            val url = "https://www.baidu.com/s?wd=${Uri.encode(keyword)}"
            openUrl(url)
            LogManager.i(TAG, "✅ 百度搜索: $keyword")
            SearchResult(true, SearchPlatform.BAIDU, keyword, "已在百度搜索")
        } catch (e: Exception) {
            SearchResult(false, SearchPlatform.BAIDU, keyword, e.message)
        }
    }
    
    /**
     * 🛒 淘宝搜索
     */
    private fun searchTaobao(keyword: String): SearchResult {
        return try {
            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = Uri.parse("taobao://s.taobao.com/search?q=${Uri.encode(keyword)}")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            LogManager.i(TAG, "✅ 淘宝搜索: $keyword")
            SearchResult(true, SearchPlatform.TAOBAO, keyword, "已在淘宝搜索")
        } catch (e: Exception) {
            // 回退到网页版
            openUrl("https://s.taobao.com/search?q=${Uri.encode(keyword)}")
            SearchResult(true, SearchPlatform.TAOBAO, keyword, "已在淘宝网页版搜索")
        }
    }
    
    /**
     * 🛒 京东搜索
     */
    private fun searchJD(keyword: String): SearchResult {
        return try {
            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = Uri.parse("openapp.jdmobile://virtual?params={\"category\":\"jump\",\"des\":\"productList\",\"keyWord\":\"${keyword}\"}")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            LogManager.i(TAG, "✅ 京东搜索: $keyword")
            SearchResult(true, SearchPlatform.JD, keyword, "已在京东搜索")
        } catch (e: Exception) {
            // 回退到网页版
            openUrl("https://search.jd.com/Search?keyword=${Uri.encode(keyword)}")
            SearchResult(true, SearchPlatform.JD, keyword, "已在京东网页版搜索")
        }
    }
    
    /**
     * 💬 微信搜索
     */
    private suspend fun searchWeChat(keyword: String): SearchResult {
        return searchInApp("com.tencent.mm", keyword, "微信搜索")
    }
    
    /**
     * 📱 抖音搜索
     */
    private suspend fun searchDouyin(keyword: String): SearchResult {
        return searchInApp("com.ss.android.ugc.aweme", keyword, "抖音搜索")
    }
    
    /**
     * 📺 B站搜索
     */
    private suspend fun searchBilibili(keyword: String): SearchResult {
        return try {
            val url = "bilibili://search?keyword=${Uri.encode(keyword)}"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            LogManager.i(TAG, "✅ B站搜索: $keyword")
            SearchResult(true, SearchPlatform.BILIBILI, keyword, "已在B站搜索")
        } catch (e: Exception) {
            openUrl("https://search.bilibili.com/all?keyword=${Uri.encode(keyword)}")
            SearchResult(true, SearchPlatform.BILIBILI, keyword, "已在B站网页版搜索")
        }
    }
    
    /**
     * 📖 知乎搜索
     */
    private fun searchZhihu(keyword: String): SearchResult {
        return try {
            openUrl("https://www.zhihu.com/search?q=${Uri.encode(keyword)}")
            LogManager.i(TAG, "✅ 知乎搜索: $keyword")
            SearchResult(true, SearchPlatform.ZHIHU, keyword, "已在知乎搜索")
        } catch (e: Exception) {
            SearchResult(false, SearchPlatform.ZHIHU, keyword, e.message)
        }
    }
    
    /**
     * 📱 微博搜索
     */
    private fun searchWeibo(keyword: String): SearchResult {
        return try {
            openUrl("https://s.weibo.com/weibo?q=${Uri.encode(keyword)}")
            LogManager.i(TAG, "✅ 微博搜索: $keyword")
            SearchResult(true, SearchPlatform.WEIBO, keyword, "已在微博搜索")
        } catch (e: Exception) {
            SearchResult(false, SearchPlatform.WEIBO, keyword, e.message)
        }
    }
    
    /**
     * 📕 小红书搜索
     */
    private suspend fun searchXiaohongshu(keyword: String): SearchResult {
        return searchInApp("com.xingin.xhs", keyword, "小红书搜索")
    }
    
    /**
     * 🔍 在指定应用中搜索
     */
    private suspend fun searchInApp(packageName: String, keyword: String, appName: String): SearchResult {
        return try {
            val service = CoreAccessibilityService.instance
            if (service == null) {
                return SearchResult(false, SearchPlatform.APP, keyword, "无障碍服务未启动")
            }
            
            // 1. 启动应用
            service.launchApp(packageName)
            delay(2000)
            
            // 2. 查找搜索框（通过ID或文本）
            val searchHints = listOf("搜索", "Search", "查找", "搜一搜")
            var found = false
            
            for (hint in searchHints) {
                if (service.findAndClick(hint)) {
                    found = true
                    delay(500)
                    break
                }
            }
            
            if (!found) {
                return SearchResult(false, SearchPlatform.APP, keyword, "未找到搜索入口")
            }
            
            // 3. 输入搜索关键词
            service.inputText(keyword)
            delay(500)
            
            // 4. 点击搜索按钮
            service.findAndClick("搜索")
            
            LogManager.i(TAG, "✅ $appName: $keyword")
            SearchResult(true, SearchPlatform.APP, keyword, "已在${appName}搜索")
        } catch (e: Exception) {
            LogManager.e(TAG, "$appName 搜索失败", e)
            SearchResult(false, SearchPlatform.APP, keyword, e.message)
        }
    }
    
    /**
     * 🔍 在当前应用中搜索
     */
    private suspend fun searchInCurrentApp(keyword: String): SearchResult {
        return try {
            val service = CoreAccessibilityService.instance
                ?: return SearchResult(false, SearchPlatform.APP, keyword, "无障碍服务未启动")
            
            // 查找搜索框
            val searchHints = listOf("搜索", "Search", "查找", "搜一搜", "输入关键词")
            var found = false
            
            for (hint in searchHints) {
                if (service.findAndInput(hint, keyword)) {
                    found = true
                    delay(500)
                    // 尝试点击搜索按钮
                    service.findAndClick("搜索")
                    break
                }
            }
            
            if (found) {
                LogManager.i(TAG, "✅ 当前应用搜索: $keyword")
                SearchResult(true, SearchPlatform.APP, keyword, "已在当前应用搜索")
            } else {
                SearchResult(false, SearchPlatform.APP, keyword, "未找到搜索框")
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "当前应用搜索失败", e)
            SearchResult(false, SearchPlatform.APP, keyword, e.message)
        }
    }
    
    /**
     * 🌐 打开URL
     */
    private fun openUrl(url: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }
    
    /**
     * 🔍 智能搜索（自动选择平台）
     */
    suspend fun smartSearch(keyword: String, context: String? = null): SearchResult {
        // 根据关键词和上下文智能选择平台
        val platform = when {
            context?.contains("购物") == true || context?.contains("买") == true -> SearchPlatform.TAOBAO
            context?.contains("视频") == true -> SearchPlatform.BILIBILI
            keyword.contains("商品") || keyword.contains("价格") -> SearchPlatform.TAOBAO
            else -> SearchPlatform.BAIDU // 默认百度
        }
        
        return search(platform, keyword)
    }
}
