package com.example.xihe.core

import java.util.Locale

object SafetyGuard {

    private val SENSITIVE_KEYWORDS = listOf(
        "转账", "支付", "付款", "money", "pay", "transfer",
        "删除", "移除", "delete", "remove", "format",
        "密码", "验证码", "password", "code", "pin",
        "发送", "红包", "余额", "提现"
    )

    private val HIGH_RISK_PACKAGES = listOf(
        "com.tencent.mm",           // 微信
        "com.eg.android.AlipayGphone", // 支付宝
        "com.android.settings",     // 系统设置
        "com.android.vending",      // 商店支付
        "com.unionpay",             // 银联
        "com.icbc.android.mobilebanking" // 工行示例
    )

    /**
     * 🛡️ 隐私脱敏处理
     * 将可能的验证码、密码或金额进行遮蔽
     */
    fun scrubPrivacy(text: String): String {
        // 遮蔽 4-6 位数字（通常是验证码）
        val otpPattern = Regex("""\b\d{4,6}\b""")
        // 遮蔽可能的银行卡号尾数
        val cardPattern = Regex("""\d{12,19}""")
        
        return text.replace(otpPattern, "****")
                   .replace(cardPattern, "************")
    }

    data class SafetyResult(
        val isSafe: Boolean,
        val reason: String? = null,
        val riskLevel: RiskLevel = RiskLevel.LOW,
        val suggestedAction: String = "PROCEED" // PROCEED, CONFIRM, BLOCK
    )

    enum class RiskLevel(val score: Int) {
        LOW(0), MEDIUM(50), HIGH(90)
    }

    fun checkAction(goal: String, command: AICommand, packageName: String?): SafetyResult {
        val isHighRiskApp = HIGH_RISK_PACKAGES.any { packageName?.contains(it) == true }
        val textToCheck = "${command.thought} ${command.action} ${command.inputText ?: ""}".lowercase()
        
        val matchedKeyword = SENSITIVE_KEYWORDS.find { textToCheck.contains(it) }
        
        return when {
            // 🚨 极其高危：在金融 App 中执行支付或修改密码
            isHighRiskApp && matchedKeyword != null -> SafetyResult(
                isSafe = false,
                reason = "警告：检测到在敏感应用 [${packageName}] 中执行高危操作: '$matchedKeyword'",
                riskLevel = RiskLevel.HIGH,
                suggestedAction = "BLOCK"
            )
            
            // ⚠️ 中度风险：普通应用中的敏感关键词
            matchedKeyword != null -> SafetyResult(
                isSafe = false,
                reason = "提示：任务涉及敏感关键词: '$matchedKeyword'，请确认",
                riskLevel = RiskLevel.MEDIUM,
                suggestedAction = "CONFIRM"
            )
            
            // 🔒 潜在风险：在支付应用中进行非支付操作（如扫描）
            isHighRiskApp -> SafetyResult(
                isSafe = true,
                reason = "提示：正在敏感应用中执行辅助操作",
                riskLevel = RiskLevel.LOW,
                suggestedAction = "CONFIRM"
            )
            
            else -> SafetyResult(isSafe = true)
        }
    }
}
