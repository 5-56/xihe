package com.example.xihe.core

import android.content.Context
import android.os.Bundle
import com.example.xihe.utils.LogManager
import android.view.accessibility.AccessibilityNodeInfo
import com.example.xihe.CoreAccessibilityService
import kotlinx.coroutines.delay

/**
 * 🤖 增强版操作执行器
 * 负责将AI指令转换为实际的屏幕操作，支持智能容错和重试
 */
class ActionExecutor(private val service: CoreAccessibilityService, private val context: Context) {

    companion object {
        private const val TAG = "ActionExecutor"
        private const val MAX_RETRY_COUNT = 3
        private const val RETRY_DELAY_MS = 500L
    }
    
    // 🆕 执行统计
    private var successCount = 0
    private var failureCount = 0
    private var retryCount = 0

    suspend fun execute(command: AICommand, rootNode: AccessibilityNodeInfo): Boolean {
        LogManager.d(TAG, "🎯 执行操作: ${command.action}, target=${command.targetId}")
        
        val result = when (command.action) {
            "CLICK" -> executeClick(command, rootNode)
            "SCROLL" -> executeScroll(command, rootNode)
            "INPUT" -> executeInput(command, rootNode)
            "HOME" -> executeHome()
            "BACK" -> executeBack()
            "LONG_PRESS" -> executeLongPress(command, rootNode)
            "DOUBLE_CLICK" -> executeDoubleClick(command, rootNode)
            "DRAG" -> executeDrag(command)
            "PINCH" -> executePinch(command, rootNode)
            // 🆕 新增操作类型
            "SWIPE" -> executeSwipe(command)
            "WAIT" -> executeWait(command)
            "FOCUS" -> executeFocus(command, rootNode)
            "SELECT" -> executeSelect(command, rootNode)
            "CLEAR" -> executeClear(command, rootNode)
            "COPY" -> executeCopy(command, rootNode)
            "PASTE" -> executePaste(command, rootNode)
            "EXPAND" -> executeExpand(command, rootNode)
            "COLLAPSE" -> executeCollapse(command, rootNode)
            "DONE" -> false
            else -> {
                LogManager.w(TAG, "⚠️ 未知操作类型: ${command.action}")
                false
            }
        }
        
        // 更新统计
        if (result) successCount++ else failureCount++
        LogManager.d(TAG, "📊 执行统计: 成功=$successCount, 失败=$failureCount, 重试=$retryCount")
        
        return result
    }
    
    /**
     * 🖱️ 执行点击操作 - 支持智能容错
     */
    private suspend fun executeClick(command: AICommand, rootNode: AccessibilityNodeInfo): Boolean {
        if (command.targetId != null) {
            // 尝试多次查找节点（智能重试）
            var node: AccessibilityNodeInfo? = null
            for (attempt in 1..MAX_RETRY_COUNT) {
                node = ScreenAnalyzer.findNodeById(rootNode, command.targetId)
                if (node != null) break
                
                // 🆕 智能模糊匹配：如果精确ID找不到，尝试模糊匹配
                node = findNodeByFuzzyMatch(rootNode, command.targetId.toString(), command.thought)
                if (node != null) {
                    LogManager.d(TAG, "🔍 通过模糊匹配找到节点")
                    break
                }
                
                if (attempt < MAX_RETRY_COUNT) {
                    LogManager.d(TAG, "🔄 节点未找到，重试 $attempt/$MAX_RETRY_COUNT")
                    retryCount++
                    delay(RETRY_DELAY_MS)
                }
            }
            
            if (node != null) {
                // 尝试 performAction
                val clicked = node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                if (clicked) {
                    LogManager.d(TAG, "✅ 点击成功 (performAction)")
                    return true
                }
                
                // Fallback: 使用手势点击
                val rect = android.graphics.Rect()
                node.getBoundsInScreen(rect)
                
                // 检查坐标是否有效
                if (rect.width() > 0 && rect.height() > 0) {
                    service.performClick(rect.exactCenterX(), rect.exactCenterY())
                    LogManager.d(TAG, "✅ 点击成功 (手势)")
                    return true
                }
            }
            
            LogManager.w(TAG, "❌ 点击失败: 未找到目标节点 ${command.targetId}")
        }
        return false
    }
    
    /**
     * 📜 执行滚动操作
     */
    private fun executeScroll(command: AICommand, rootNode: AccessibilityNodeInfo): Boolean {
        val isDown = command.direction == "DOWN" || command.direction == null
        
        // 如果有目标节点，尝试滚动该节点
        if (command.targetId != null) {
            val node = ScreenAnalyzer.findNodeById(rootNode, command.targetId)
            if (node != null && node.isScrollable) {
                val action = if (isDown) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                val scrolled = node.performAction(action)
                if (scrolled) {
                    LogManager.d(TAG, "✅ 滚动成功 (节点滚动)")
                    return true
                }
            }
        }
        
        // Fallback: 全局手势滑动
        val displayMetrics = service.resources.displayMetrics
        val width = displayMetrics.widthPixels
        val height = displayMetrics.heightPixels
        val centerX = width / 2f
        val centerY = height / 2f
        
        val startY = if (isDown) centerY + 300 else centerY - 300
        val endY = if (isDown) centerY - 300 else centerY + 300
        
        service.performScroll(centerX, startY, centerX, endY)
        LogManager.d(TAG, "✅ 滚动成功 (手势)")
        return true
    }
    
    /**
     * ⌨️ 执行输入操作
     */
    private suspend fun executeInput(command: AICommand, rootNode: AccessibilityNodeInfo): Boolean {
        if (command.targetId != null && command.inputText != null) {
            val node = ScreenAnalyzer.findNodeById(rootNode, command.targetId)
            if (node != null) {
                val result = TextInputHelper.inputText(
                    service, context, node, command.inputText,
                    TextInputHelper.InputStrategy.AUTO
                )
                LogManager.d(TAG, if (result) "✅ 输入成功" else "❌ 输入失败")
                return result
            }
        }
        return false
    }
    
    /**
     * 🏠 返回主页
     */
    private fun executeHome(): Boolean {
        service.performGlobalHome()
        LogManager.d(TAG, "✅ 返回主页成功")
        return true
    }
    
    /**
     * ◀️ 返回上一页
     */
    private fun executeBack(): Boolean {
        service.performGlobalBack()
        LogManager.d(TAG, "✅ 返回上一页成功")
        return true
    }
    
    /**
     * 👆 长按操作
     */
    private fun executeLongPress(command: AICommand, rootNode: AccessibilityNodeInfo): Boolean {
        if (command.targetId != null) {
            val node = ScreenAnalyzer.findNodeById(rootNode, command.targetId)
            if (node != null) {
                val rect = android.graphics.Rect()
                node.getBoundsInScreen(rect)
                val duration = command.duration ?: 800L
                service.performLongPress(rect.exactCenterX(), rect.exactCenterY(), duration)
                LogManager.d(TAG, "✅ 长按成功")
                return true
            }
        }
        return false
    }
    
    /**
     * 👆👆 双击操作
     */
    private fun executeDoubleClick(command: AICommand, rootNode: AccessibilityNodeInfo): Boolean {
        if (command.targetId != null) {
            val node = ScreenAnalyzer.findNodeById(rootNode, command.targetId)
            if (node != null) {
                val rect = android.graphics.Rect()
                node.getBoundsInScreen(rect)
                service.performDoubleClick(rect.exactCenterX(), rect.exactCenterY())
                LogManager.d(TAG, "✅ 双击成功")
                return true
            }
        }
        return false
    }
    
    /**
     * 🔄 拖拽操作
     */
    private fun executeDrag(command: AICommand): Boolean {
        if (command.startX != null && command.startY != null && command.endX != null && command.endY != null) {
            val duration = command.duration ?: 500L
            service.performDrag(command.startX, command.startY, command.endX, command.endY, duration)
            LogManager.d(TAG, "✅ 拖拽成功")
            return true
        }
        return false
    }
    
    /**
     * 🔍 缩放操作
     */
    private fun executePinch(command: AICommand, rootNode: AccessibilityNodeInfo): Boolean {
        val displayMetrics = service.resources.displayMetrics
        val centerX: Float
        val centerY: Float
        
        if (command.targetId != null) {
            val node = ScreenAnalyzer.findNodeById(rootNode, command.targetId)
            if (node != null) {
                val rect = android.graphics.Rect()
                node.getBoundsInScreen(rect)
                centerX = rect.exactCenterX()
                centerY = rect.exactCenterY()
            } else {
                centerX = displayMetrics.widthPixels / 2f
                centerY = displayMetrics.heightPixels / 2f
            }
        } else {
            centerX = displayMetrics.widthPixels / 2f
            centerY = displayMetrics.heightPixels / 2f
        }
        
        val scaleIn = command.scaleIn ?: false
        service.performPinch(centerX, centerY, scaleIn)
        LogManager.d(TAG, "✅ 缩放成功")
        return true
    }
    
    // ==================== 🆕 新增操作类型 ====================
    
    /**
     * 👋 滑动操作 (支持任意方向)
     */
    private fun executeSwipe(command: AICommand): Boolean {
        val displayMetrics = service.resources.displayMetrics
        val width = displayMetrics.widthPixels.toFloat()
        val height = displayMetrics.heightPixels.toFloat()
        
        val direction = command.direction?.uppercase() ?: "UP"
        val distance = 400f
        
        val (startX, startY, endX, endY) = when (direction) {
            "UP" -> listOf(width / 2, height / 2 + distance / 2, width / 2, height / 2 - distance / 2)
            "DOWN" -> listOf(width / 2, height / 2 - distance / 2, width / 2, height / 2 + distance / 2)
            "LEFT" -> listOf(width / 2 + distance / 2, height / 2, width / 2 - distance / 2, height / 2)
            "RIGHT" -> listOf(width / 2 - distance / 2, height / 2, width / 2 + distance / 2, height / 2)
            else -> listOf(width / 2, height / 2 + distance / 2, width / 2, height / 2 - distance / 2)
        }
        
        service.performScroll(startX, startY, endX, endY)
        LogManager.d(TAG, "✅ 滑动成功: $direction")
        return true
    }
    
    /**
     * ⏳ 等待操作
     */
    private suspend fun executeWait(command: AICommand): Boolean {
        val waitTime = command.duration ?: 1000L
        LogManager.d(TAG, "⏳ 等待 ${waitTime}ms...")
        delay(waitTime)
        LogManager.d(TAG, "✅ 等待完成")
        return true
    }
    
    /**
     * 🎯 聚焦操作
     */
    private fun executeFocus(command: AICommand, rootNode: AccessibilityNodeInfo): Boolean {
        if (command.targetId != null) {
            val node = ScreenAnalyzer.findNodeById(rootNode, command.targetId)
            if (node != null) {
                val focused = node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                LogManager.d(TAG, if (focused) "✅ 聚焦成功" else "❌ 聚焦失败")
                return focused
            }
        }
        return false
    }
    
    /**
     * ☑️ 选择操作
     */
    private fun executeSelect(command: AICommand, rootNode: AccessibilityNodeInfo): Boolean {
        if (command.targetId != null) {
            val node = ScreenAnalyzer.findNodeById(rootNode, command.targetId)
            if (node != null) {
                val selected = node.performAction(AccessibilityNodeInfo.ACTION_SELECT)
                LogManager.d(TAG, if (selected) "✅ 选择成功" else "❌ 选择失败")
                return selected
            }
        }
        return false
    }
    
    /**
     * 🗑️ 清空操作
     */
    private fun executeClear(command: AICommand, rootNode: AccessibilityNodeInfo): Boolean {
        if (command.targetId != null) {
            val node = ScreenAnalyzer.findNodeById(rootNode, command.targetId)
            if (node != null) {
                // 先聚焦，再全选清空
                node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                val args = Bundle().apply {
                    putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0)
                    putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, Int.MAX_VALUE)
                }
                node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, args)
                val cleared = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
                })
                LogManager.d(TAG, if (cleared) "✅ 清空成功" else "❌ 清空失败")
                return cleared
            }
        }
        return false
    }
    
    /**
     * 📋 复制操作
     */
    private fun executeCopy(command: AICommand, rootNode: AccessibilityNodeInfo): Boolean {
        if (command.targetId != null) {
            val node = ScreenAnalyzer.findNodeById(rootNode, command.targetId)
            if (node != null) {
                val copied = node.performAction(AccessibilityNodeInfo.ACTION_COPY)
                LogManager.d(TAG, if (copied) "✅ 复制成功" else "❌ 复制失败")
                return copied
            }
        }
        return false
    }
    
    /**
     * 📄 粘贴操作
     */
    private fun executePaste(command: AICommand, rootNode: AccessibilityNodeInfo): Boolean {
        if (command.targetId != null) {
            val node = ScreenAnalyzer.findNodeById(rootNode, command.targetId)
            if (node != null) {
                val pasted = node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
                LogManager.d(TAG, if (pasted) "✅ 粘贴成功" else "❌ 粘贴失败")
                return pasted
            }
        }
        return false
    }
    
    /**
     * 📂 展开操作
     */
    private fun executeExpand(command: AICommand, rootNode: AccessibilityNodeInfo): Boolean {
        if (command.targetId != null) {
            val node = ScreenAnalyzer.findNodeById(rootNode, command.targetId)
            if (node != null) {
                val expanded = node.performAction(AccessibilityNodeInfo.ACTION_EXPAND)
                LogManager.d(TAG, if (expanded) "✅ 展开成功" else "❌ 展开失败")
                return expanded
            }
        }
        return false
    }
    
    /**
     * 📁 折叠操作
     */
    private fun executeCollapse(command: AICommand, rootNode: AccessibilityNodeInfo): Boolean {
        if (command.targetId != null) {
            val node = ScreenAnalyzer.findNodeById(rootNode, command.targetId)
            if (node != null) {
                val collapsed = node.performAction(AccessibilityNodeInfo.ACTION_COLLAPSE)
                LogManager.d(TAG, if (collapsed) "✅ 折叠成功" else "❌ 折叠失败")
                return collapsed
            }
        }
        return false
    }
    
    // ==================== 🔧 辅助方法 ====================
    
    /**
     * 🔍 智能模糊匹配节点
     * 当精确ID找不到时，尝试通过文本内容或描述来匹配
     */
    private fun findNodeByFuzzyMatch(
        rootNode: AccessibilityNodeInfo,
        targetId: String,
        thought: String
    ): AccessibilityNodeInfo? {
        // 从 thought 中提取可能的目标文本
        val possibleTexts = extractPossibleTargetTexts(thought)
        
        for (text in possibleTexts) {
            if (text.isBlank()) continue
            
            // 尝试通过文本匹配
            val nodesByText = rootNode.findAccessibilityNodeInfosByText(text)
            if (nodesByText.isNotEmpty()) {
                // 返回第一个可点击的节点
                val clickable = nodesByText.find { it.isClickable }
                if (clickable != null) {
                    LogManager.d(TAG, "🔍 模糊匹配成功: 通过文本 '$text' 找到节点")
                    return clickable
                }
                // 没有可点击的，返回第一个
                return nodesByText.first()
            }
        }
        
        return null
    }
    
    /**
     * 📝 从思考文本中提取可能的目标文本
     */
    private fun extractPossibleTargetTexts(thought: String): List<String> {
        val texts = mutableListOf<String>()
        
        // 提取引号中的内容
        val quotePattern = Regex("""["'「」『』""''](.+?)["'「」『』""'']""")
        quotePattern.findAll(thought).forEach {
            texts.add(it.groupValues[1])
        }
        
        // 提取常见UI元素关键词
        val uiKeywords = listOf(
            "确定", "取消", "确认", "提交", "发送", "搜索", "登录", "注册",
            "下一步", "完成", "保存", "返回", "关闭", "打开", "添加", "删除",
            "同意", "允许", "拒绝", "跳过", "继续", "开始"
        )
        
        uiKeywords.forEach { keyword ->
            if (thought.contains(keyword)) {
                texts.add(keyword)
            }
        }
        
        return texts.distinct()
    }
    
    /**
     * 📊 获取执行统计
     */
    fun getStatistics(): Triple<Int, Int, Int> {
        return Triple(successCount, failureCount, retryCount)
    }
    
    /**
     * 🔄 重置统计
     */
    fun resetStatistics() {
        successCount = 0
        failureCount = 0
        retryCount = 0
    }
}
