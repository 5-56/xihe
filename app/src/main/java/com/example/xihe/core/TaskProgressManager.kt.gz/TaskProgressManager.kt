package com.example.xihe.core

import com.example.xihe.utils.LogManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * 📊 任务进度管理器
 * 
 * 从 AutomationEngine 中提取的进度管理模块
 * 负责任务执行进度的跟踪和状态管理
 */
object TaskProgressManager {
    
    private const val TAG = "TaskProgressManager"
    
    // 任务进度状态
    private val _taskProgress = MutableStateFlow(TaskProgress())
    val taskProgress: StateFlow<TaskProgress> = _taskProgress.asStateFlow()
    
    // 暂停状态
    private val _isPaused = MutableStateFlow(false)
    val isPaused: StateFlow<Boolean> = _isPaused.asStateFlow()
    
    // 运行状态
    private val _status = MutableStateFlow("Idle")
    val status: StateFlow<String> = _status.asStateFlow()
    
    /**
     * 🚀 开始新任务
     */
    fun startTask(taskName: String, totalSteps: Int = 0) {
        _taskProgress.value = TaskProgress(
            isRunning = true,
            currentStep = 0,
            totalSteps = totalSteps,
            progress = 0f,
            currentAction = "开始: $taskName",
            taskName = taskName,
            startTime = System.currentTimeMillis()
        )
        _status.value = "运行中"
        _isPaused.value = false
        LogManager.d(TAG, "🚀 任务开始: $taskName")
    }
    
    /**
     * 📈 更新进度
     */
    fun updateProgress(
        currentStep: Int? = null,
        totalSteps: Int? = null,
        progress: Float? = null,
        currentAction: String? = null
    ) {
        val current = _taskProgress.value
        
        val newStep = currentStep ?: current.currentStep
        val newTotal = totalSteps ?: current.totalSteps
        val newProgress = progress ?: if (newTotal > 0) newStep.toFloat() / newTotal else current.progress
        
        _taskProgress.value = current.copy(
            currentStep = newStep,
            totalSteps = newTotal,
            progress = newProgress.coerceIn(0f, 1f),
            currentAction = currentAction ?: current.currentAction
        )
        
        LogManager.d(TAG, "📈 进度更新: $newStep/$newTotal (${(newProgress * 100).toInt()}%)")
    }
    
    /**
     * ✅ 任务完成
     */
    fun completeTask(message: String = "任务完成") {
        val current = _taskProgress.value
        val duration = System.currentTimeMillis() - current.startTime
        
        _taskProgress.value = current.copy(
            isRunning = false,
            progress = 1f,
            currentAction = message,
            endTime = System.currentTimeMillis()
        )
        _status.value = "完成"
        
        LogManager.d(TAG, "✅ 任务完成: ${current.taskName}, 耗时: ${duration/1000}秒")
    }
    
    /**
     * ❌ 任务失败
     */
    fun failTask(error: String) {
        val current = _taskProgress.value
        
        _taskProgress.value = current.copy(
            isRunning = false,
            currentAction = "失败: $error",
            error = error,
            endTime = System.currentTimeMillis()
        )
        _status.value = "失败"
        
        LogManager.e(TAG, "❌ 任务失败: $error")
    }
    
    /**
     * ⏸️ 暂停任务
     */
    fun pauseTask() {
        if (_taskProgress.value.isRunning && !_isPaused.value) {
            _isPaused.value = true
            _status.value = "暂停"
            LogManager.d(TAG, "⏸️ 任务暂停")
        }
    }
    
    /**
     * ▶️ 恢复任务
     */
    fun resumeTask() {
        if (_taskProgress.value.isRunning && _isPaused.value) {
            _isPaused.value = false
            _status.value = "运行中"
            LogManager.d(TAG, "▶️ 任务恢复")
        }
    }
    
    /**
     * 🛑 取消任务
     */
    fun cancelTask() {
        val current = _taskProgress.value
        
        _taskProgress.value = current.copy(
            isRunning = false,
            currentAction = "已取消",
            endTime = System.currentTimeMillis()
        )
        _status.value = "已取消"
        _isPaused.value = false
        
        LogManager.d(TAG, "🛑 任务取消")
    }
    
    /**
     * 🔄 重置状态
     */
    fun reset() {
        _taskProgress.value = TaskProgress()
        _status.value = "Idle"
        _isPaused.value = false
        LogManager.d(TAG, "🔄 状态重置")
    }
    
    /**
     * 🔍 检查是否可以执行
     */
    fun canExecute(): Boolean {
        return !_taskProgress.value.isRunning || _isPaused.value
    }
    
    /**
     * ⏱️ 获取任务耗时（毫秒）
     */
    fun getElapsedTime(): Long {
        val current = _taskProgress.value
        return if (current.isRunning) {
            System.currentTimeMillis() - current.startTime
        } else {
            current.endTime - current.startTime
        }
    }
    
    /**
     * 📊 获取任务状态摘要
     */
    fun getStatusSummary(): String {
        val current = _taskProgress.value
        return buildString {
            append("任务: ${current.taskName}")
            append(" | 状态: ${_status.value}")
            append(" | 进度: ${(current.progress * 100).toInt()}%")
            if (current.isRunning) {
                append(" | 耗时: ${getElapsedTime() / 1000}秒")
            }
            current.error?.let { append(" | 错误: $it") }
        }
    }
}
