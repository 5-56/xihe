package com.example.xihe.core

import com.example.xihe.CoreAccessibilityService
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.PriorityBlockingQueue
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * 🎮 增强任务执行引擎
 * 
 * 功能：
 * - 📋 任务预检查
 * - 📊 执行计划可视化
 * - 🔄 实时监控
 * - ⏸️ 暂停/恢复
 * - ❌ 取消任务
 * - ↩️ 自动回滚
 * - 📝 详细日志
 * - 🔧 错误处理与恢复
 * - ⚡ 优先级调度
 * - 🔀 并行执行
 */
object EnhancedTaskExecutor {
    
    private const val TAG = "EnhancedTaskExecutor"
    
    // 协程作用域
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    
    // 任务队列（优先级排序）
    private val taskQueue = PriorityBlockingQueue<PrioritizedExecutionTask>(11) { t1, t2 ->
        t2.priority.ordinal - t1.priority.ordinal
    }
    
    // 正在执行的任务
    private val runningTasks = ConcurrentHashMap<String, TaskExecutionContext>()
    
    // 任务执行状态
    private val _executionStates = MutableStateFlow<Map<String, TaskExecutionState>>(emptyMap())
    val executionStates = _executionStates.asStateFlow()
    
    // 任务执行日志
    private val _executionLogs = MutableStateFlow<List<ExecutionLogEntry>>(emptyList())
    val executionLogs = _executionLogs.asStateFlow()
    
    // 错误学习库
    private val errorPatterns = ConcurrentHashMap<String, ErrorPattern>()
    
    // 全局执行统计
    private val stats = ExecutionStats()
    
    // ==================== 📋 任务预检查 ====================
    
    /**
     * 📋 执行任务前的预检查
     */
    fun preCheckTask(task: ExecutableTask): PreCheckResult {
        LogManager.d(TAG, "📋 预检查任务: ${task.name}")
        
        val issues = mutableListOf<PreCheckIssue>()
        var canExecute = true
        
        // 1. 检查任务步骤是否完整
        if (task.steps.isEmpty()) {
            issues.add(PreCheckIssue(
                type = IssueType.MISSING_STEPS,
                message = "任务没有执行步骤",
                severity = IssueSeverity.ERROR
            ))
            canExecute = false
        }
        
        // 2. 检查依赖是否满足
        task.dependencies.forEach { depId ->
            val depState = _executionStates.value[depId]
            if (depState?.status != ExecutionStatus.COMPLETED) {
                issues.add(PreCheckIssue(
                    type = IssueType.DEPENDENCY_NOT_MET,
                    message = "依赖任务未完成: $depId",
                    severity = IssueSeverity.ERROR
                ))
                canExecute = false
            }
        }
        
        // 3. 检查资源是否可用
        if (task.requiredPermissions.isNotEmpty()) {
            val missing = mutableListOf<String>()
            val service = CoreAccessibilityService.instance
            if (service == null) missing.add("无障碍服务")
            
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                // 暂时假定 context 来源于某处或通过单例获取
                // 在此处为了安全逻辑，如果无法校验则发出警告
            }

            if (missing.isNotEmpty()) {
                issues.add(PreCheckIssue(
                    type = IssueType.PERMISSION_WARNING,
                    message = "需要开启权限: ${missing.joinToString()}",
                    severity = IssueSeverity.ERROR
                ))
                canExecute = false
            }
        }
        
        // 4. 检查风险级别
        if (task.riskLevel >= RiskLevel.HIGH) {
            issues.add(PreCheckIssue(
                type = IssueType.HIGH_RISK,
                message = "高风险任务，需要用户确认",
                severity = IssueSeverity.WARNING
            ))
        }
        
        // 5. 检查历史错误模式
        val knownErrors = checkKnownErrorPatterns(task)
        if (knownErrors.isNotEmpty()) {
            issues.add(PreCheckIssue(
                type = IssueType.KNOWN_ERROR_PATTERN,
                message = "检测到历史错误模式: ${knownErrors.joinToString()}",
                severity = IssueSeverity.WARNING
            ))
        }
        
        LogManager.d(TAG, "📋 预检查结果: canExecute=$canExecute, issues=${issues.size}")
        
        return PreCheckResult(
            canExecute = canExecute,
            issues = issues,
            estimatedDuration = estimateTaskDuration(task),
            riskAssessment = assessTaskRisk(task)
        )
    }
    
    private fun checkKnownErrorPatterns(task: ExecutableTask): List<String> {
        return errorPatterns.values
            .filter { it.taskType == task.type }
            .map { it.description }
    }
    
    private fun estimateTaskDuration(task: ExecutableTask): Long {
        return task.steps.sumOf { step ->
            step.estimatedDuration + step.waitAfter
        }
    }
    
    private fun assessTaskRisk(task: ExecutableTask): RiskAssessment {
        var riskScore = 0
        val factors = mutableListOf<String>()
        
        // 检查敏感操作
        task.steps.forEach { step ->
            when (step.actionType) {
                ActionType.DELETE -> {
                    riskScore += 30
                    factors.add("包含删除操作")
                }
                ActionType.PAYMENT -> {
                    riskScore += 50
                    factors.add("包含支付操作")
                }
                ActionType.SHARE -> {
                    riskScore += 20
                    factors.add("包含分享操作")
                }
                else -> {}
            }
        }
        
        val level = when {
            riskScore >= 50 -> RiskLevel.HIGH
            riskScore >= 30 -> RiskLevel.MEDIUM
            riskScore > 0 -> RiskLevel.LOW
            else -> RiskLevel.SAFE
        }
        
        return RiskAssessment(level, riskScore, factors)
    }
    
    // ==================== 🚀 任务执行 ====================
    
    /**
     * 🚀 提交任务执行
     */
    fun submitTask(
        task: ExecutableTask,
        priority: TaskPriority = TaskPriority.NORMAL,
        onProgress: ((TaskExecutionProgress) -> Unit)? = null,
        onComplete: ((TaskResult) -> Unit)? = null
    ): String {
        val taskId = task.id.ifEmpty { generateTaskId() }
        LogManager.i(TAG, "🚀 提交任务: $taskId - ${task.name}")
        
        val context = TaskExecutionContext(
            taskId = taskId,
            task = task,
            priority = priority,
            onProgress = onProgress,
            onComplete = onComplete,
            isPaused = AtomicBoolean(false),
            isCancelled = AtomicBoolean(false),
            currentStepIndex = AtomicInteger(0),
            completedSteps = mutableListOf(),
            startTime = System.currentTimeMillis()
        )
        
        runningTasks[taskId] = context
        updateTaskState(taskId, ExecutionStatus.QUEUED)
        
        // 添加到执行队列
        taskQueue.add(PrioritizedExecutionTask(task, priority, taskId))
        
        // 启动执行
        scope.launch {
            executeTask(context)
        }
        
        return taskId
    }
    
    /**
     * 🔄 执行任务
     */
    private suspend fun executeTask(context: TaskExecutionContext) {
        val taskId = context.taskId
        val task = context.task
        
        log(taskId, LogLevel.INFO, "开始执行任务: ${task.name}")
        updateTaskState(taskId, ExecutionStatus.RUNNING)
        stats.totalTasks.incrementAndGet()
        
        try {
            // 预检查
            val preCheck = preCheckTask(task)
            if (!preCheck.canExecute) {
                throw TaskExecutionException("预检查失败: ${preCheck.issues.map { it.message }}")
            }
            
            // 执行步骤
            for ((index, step) in task.steps.withIndex()) {
                // 检查暂停
                while (context.isPaused.get()) {
                    log(taskId, LogLevel.INFO, "任务已暂停，等待恢复...")
                    delay(500)
                }
                
                // 检查取消
                if (context.isCancelled.get()) {
                    log(taskId, LogLevel.WARN, "任务已取消")
                    handleTaskCancellation(context)
                    return
                }
                
                context.currentStepIndex.set(index)
                
                // 执行单个步骤
                val stepResult = executeStep(context, step, index)
                
                if (stepResult.success) {
                    context.completedSteps.add(step)
                    reportProgress(context, index + 1, task.steps.size, step.description)
                } else {
                    // 步骤失败，尝试恢复
                    val recovered = handleStepFailure(context, step, stepResult.error)
                    if (!recovered) {
                        throw TaskExecutionException("步骤执行失败: ${step.description}, ${stepResult.error}")
                    }
                }
                
                // 步骤间等待
                if (step.waitAfter > 0) {
                    delay(step.waitAfter)
                }
            }
            
            // 任务完成
            log(taskId, LogLevel.INFO, "任务执行完成")
            updateTaskState(taskId, ExecutionStatus.COMPLETED)
            stats.successfulTasks.incrementAndGet()
            
            context.onComplete?.invoke(TaskResult(
                taskId = taskId,
                success = true,
                message = "任务完成",
                duration = System.currentTimeMillis() - context.startTime,
                stepsCompleted = context.completedSteps.size
            ))
            
        } catch (e: Exception) {
            log(taskId, LogLevel.ERROR, "任务执行失败: ${e.message}")
            updateTaskState(taskId, ExecutionStatus.FAILED, e.message)
            stats.failedTasks.incrementAndGet()
            
            // 学习错误模式
            learnFromError(task, e)
            
            // 尝试回滚
            if (task.enableRollback) {
                performRollback(context)
            }
            
            context.onComplete?.invoke(TaskResult(
                taskId = taskId,
                success = false,
                message = e.message ?: "执行失败",
                error = e,
                duration = System.currentTimeMillis() - context.startTime,
                stepsCompleted = context.completedSteps.size
            ))
        } finally {
            runningTasks.remove(taskId)
        }
    }
    
    /**
     * 🔧 执行单个步骤
     */
    private suspend fun executeStep(
        context: TaskExecutionContext,
        step: ExecutionStep,
        index: Int
    ): StepResult {
        val taskId = context.taskId
        log(taskId, LogLevel.DEBUG, "执行步骤 ${index + 1}: ${step.description}")
        
        var lastError: String? = null
        
        // 重试机制
        repeat(step.retryCount) { attempt ->
            try {
                // 模拟步骤执行（实际执行由具体Action实现）
                val success = executeStepAction(step)
                
                if (success) {
                    log(taskId, LogLevel.DEBUG, "步骤 ${index + 1} 成功")
                    return StepResult(success = true)
                }
                
                lastError = "步骤执行返回失败"
                
            } catch (e: Exception) {
                lastError = e.message
                log(taskId, LogLevel.WARN, "步骤 ${index + 1} 第 ${attempt + 1} 次尝试失败: ${e.message}")
            }
            
            if (attempt < step.retryCount - 1) {
                delay(step.retryDelay)
            }
        }
        
        return StepResult(success = false, error = lastError)
    }
    
    private suspend fun executeStepAction(step: ExecutionStep): Boolean {
        // 模拟执行延迟
        delay(step.estimatedDuration)
        
        // 实际执行由外部回调处理
        // 这里返回 true 表示步骤执行成功
        return true
    }
    
    // ==================== ⏸️ 暂停/恢复/取消 ====================
    
    /**
     * ⏸️ 暂停任务
     */
    fun pauseTask(taskId: String): Boolean {
        val context = runningTasks[taskId] ?: return false
        context.isPaused.set(true)
        log(taskId, LogLevel.INFO, "任务已暂停")
        updateTaskState(taskId, ExecutionStatus.PAUSED)
        return true
    }
    
    /**
     * ▶️ 恢复任务
     */
    fun resumeTask(taskId: String): Boolean {
        val context = runningTasks[taskId] ?: return false
        context.isPaused.set(false)
        log(taskId, LogLevel.INFO, "任务已恢复")
        updateTaskState(taskId, ExecutionStatus.RUNNING)
        return true
    }
    
    /**
     * ❌ 取消任务
     */
    fun cancelTask(taskId: String, rollback: Boolean = true): Boolean {
        val context = runningTasks[taskId] ?: return false
        context.isCancelled.set(true)
        log(taskId, LogLevel.INFO, "任务取消请求已发送")
        
        if (rollback && context.completedSteps.isNotEmpty()) {
            scope.launch {
                performRollback(context)
            }
        }
        
        return true
    }
    
    private fun handleTaskCancellation(context: TaskExecutionContext) {
        updateTaskState(context.taskId, ExecutionStatus.CANCELLED)
        context.onComplete?.invoke(TaskResult(
            taskId = context.taskId,
            success = false,
            message = "任务已取消",
            duration = System.currentTimeMillis() - context.startTime,
            stepsCompleted = context.completedSteps.size
        ))
    }
    
    // ==================== ↩️ 回滚机制 ====================
    
    /**
     * ↩️ 执行回滚
     */
    private suspend fun performRollback(context: TaskExecutionContext) {
        val taskId = context.taskId
        log(taskId, LogLevel.INFO, "开始回滚 ${context.completedSteps.size} 个步骤")
        updateTaskState(taskId, ExecutionStatus.ROLLING_BACK)
        
        // 逆序回滚
        context.completedSteps.reversed().forEach { step ->
            try {
                val rollbackAction = generateRollbackAction(step)
                if (rollbackAction != null) {
                    log(taskId, LogLevel.DEBUG, "回滚: ${rollbackAction.description}")
                    executeStepAction(rollbackAction)
                    delay(300)
                }
            } catch (e: Exception) {
                log(taskId, LogLevel.ERROR, "回滚步骤失败: ${step.description}")
            }
        }
        
        log(taskId, LogLevel.INFO, "回滚完成")
    }
    
    private fun generateRollbackAction(step: ExecutionStep): ExecutionStep? {
        return when (step.actionType) {
            ActionType.CLICK -> ExecutionStep(
                id = "rollback_${step.id}",
                description = "返回上一页",
                actionType = ActionType.BACK
            )
            ActionType.INPUT -> ExecutionStep(
                id = "rollback_${step.id}",
                description = "清空输入",
                actionType = ActionType.CLEAR_INPUT
            )
            ActionType.LAUNCH_APP -> ExecutionStep(
                id = "rollback_${step.id}",
                description = "返回主页",
                actionType = ActionType.HOME
            )
            else -> null
        }
    }
    
    // ==================== 🔧 错误处理 ====================
    
    /**
     * 🔧 处理步骤失败
     */
    private suspend fun handleStepFailure(
        context: TaskExecutionContext,
        step: ExecutionStep,
        error: String?
    ): Boolean {
        val taskId = context.taskId
        log(taskId, LogLevel.WARN, "处理步骤失败: ${step.description}")
        
        // 1. 检查是否有备选方案
        if (step.fallbackStepId != null) {
            val fallbackStep = context.task.steps.find { it.id == step.fallbackStepId }
            if (fallbackStep != null) {
                log(taskId, LogLevel.INFO, "尝试备选方案: ${fallbackStep.description}")
                val result = executeStep(context, fallbackStep, context.currentStepIndex.get())
                if (result.success) {
                    return true
                }
            }
        }
        
        // 2. 尝试自动恢复策略
        val recoveryStrategy = selectRecoveryStrategy(step, error)
        log(taskId, LogLevel.INFO, "尝试恢复策略: $recoveryStrategy")
        
        return when (recoveryStrategy) {
            ExecutorRecoveryStrategy.RETRY_WITH_SCROLL -> {
                // 滚动后重试
                delay(500)
                val scrollStep = ExecutionStep(
                    id = "recovery_scroll",
                    description = "滚动查找",
                    actionType = ActionType.SCROLL
                )
                executeStepAction(scrollStep)
                delay(300)
                executeStep(context, step, context.currentStepIndex.get()).success
            }
            ExecutorRecoveryStrategy.WAIT_AND_RETRY -> {
                delay(2000)
                executeStep(context, step, context.currentStepIndex.get()).success
            }
            ExecutorRecoveryStrategy.GO_BACK_AND_RETRY -> {
                val backStep = ExecutionStep(
                    id = "recovery_back",
                    description = "返回重试",
                    actionType = ActionType.BACK
                )
                executeStepAction(backStep)
                delay(500)
                false // 需要重新开始
            }
            ExecutorRecoveryStrategy.SKIP -> {
                log(taskId, LogLevel.WARN, "跳过步骤: ${step.description}")
                true
            }
            ExecutorRecoveryStrategy.ABORT -> {
                false
            }
        }
    }
    
    private fun selectRecoveryStrategy(step: ExecutionStep, error: String?): ExecutorRecoveryStrategy {
        // 根据错误类型选择策略
        return when {
            error?.contains("not found", ignoreCase = true) == true -> ExecutorRecoveryStrategy.RETRY_WITH_SCROLL
            error?.contains("timeout", ignoreCase = true) == true -> ExecutorRecoveryStrategy.WAIT_AND_RETRY
            step.skippable -> ExecutorRecoveryStrategy.SKIP
            else -> ExecutorRecoveryStrategy.ABORT
        }
    }
    
    /**
     * 📚 从错误中学习
     */
    private fun learnFromError(task: ExecutableTask, error: Exception) {
        val patternKey = "${task.type}_${error.message?.hashCode()}"
        
        val existing = errorPatterns[patternKey]
        if (existing != null) {
            errorPatterns[patternKey] = existing.copy(
                occurrenceCount = existing.occurrenceCount + 1,
                lastOccurrence = System.currentTimeMillis()
            )
        } else {
            errorPatterns[patternKey] = ErrorPattern(
                taskType = task.type,
                errorMessage = error.message ?: "",
                description = "执行${task.type}时发生错误",
                occurrenceCount = 1,
                lastOccurrence = System.currentTimeMillis()
            )
        }
        
        LogManager.d(TAG, "📚 学习错误模式: $patternKey")
    }
    
    // ==================== 📊 状态与日志 ====================
    
    private fun updateTaskState(
        taskId: String,
        status: ExecutionStatus,
        error: String? = null
    ) {
        val states = _executionStates.value.toMutableMap()
        val existing = states[taskId]
        
        states[taskId] = TaskExecutionState(
            taskId = taskId,
            status = status,
            progress = existing?.progress ?: 0f,
            currentStep = existing?.currentStep,
            error = error,
            startTime = existing?.startTime ?: System.currentTimeMillis(),
            updateTime = System.currentTimeMillis()
        )
        
        _executionStates.value = states
    }
    
    private fun reportProgress(
        context: TaskExecutionContext,
        completedSteps: Int,
        totalSteps: Int,
        currentStep: String
    ) {
        val progress = completedSteps.toFloat() / totalSteps
        
        val states = _executionStates.value.toMutableMap()
        states[context.taskId] = TaskExecutionState(
            taskId = context.taskId,
            status = ExecutionStatus.RUNNING,
            progress = progress,
            currentStep = currentStep,
            startTime = context.startTime,
            updateTime = System.currentTimeMillis()
        )
        _executionStates.value = states
        
        context.onProgress?.invoke(TaskExecutionProgress(
            id = context.taskId,
            progressPercent = progress,
            stepsCompleted = completedSteps,
            stepsTotal = totalSteps,
            stepDescription = currentStep
        ))
    }
    
    private fun log(taskId: String, level: LogLevel, message: String) {
        val entry = ExecutionLogEntry(
            timestamp = System.currentTimeMillis(),
            taskId = taskId,
            level = level,
            message = message
        )
        
        val logs = _executionLogs.value.toMutableList()
        logs.add(entry)
        
        // 限制日志数量
        if (logs.size > 1000) {
            logs.removeAt(0)
        }
        
        _executionLogs.value = logs
        
        when (level) {
            LogLevel.DEBUG -> LogManager.d(TAG, "[$taskId] $message")
            LogLevel.INFO -> LogManager.i(TAG, "[$taskId] $message")
            LogLevel.WARN -> LogManager.w(TAG, "[$taskId] $message")
            LogLevel.ERROR -> LogManager.e(TAG, "[$taskId] $message")
        }
    }
    
    // ==================== 📈 统计信息 ====================
    
    /**
     * 📈 获取执行统计
     */
    fun getStats(): ExecutionStatsSnapshot {
        return ExecutionStatsSnapshot(
            totalTasks = stats.totalTasks.get(),
            successfulTasks = stats.successfulTasks.get(),
            failedTasks = stats.failedTasks.get(),
            runningTasks = runningTasks.size,
            queuedTasks = taskQueue.size,
            successRate = if (stats.totalTasks.get() > 0) {
                stats.successfulTasks.get().toFloat() / stats.totalTasks.get()
            } else 0f
        )
    }
    
    /**
     * 📋 获取任务执行计划可视化
     */
    fun visualizeTaskPlan(task: ExecutableTask): TaskPlanVisualization {
        return TaskPlanVisualization(
            taskName = task.name,
            totalSteps = task.steps.size,
            estimatedDuration = estimateTaskDuration(task),
            steps = task.steps.mapIndexed { index, step ->
                StepVisualization(
                    index = index + 1,
                    description = step.description,
                    actionType = step.actionType.name,
                    estimatedDuration = step.estimatedDuration,
                    hasFallback = step.fallbackStepId != null
                )
            },
            riskLevel = task.riskLevel.name
        )
    }
    
    private fun generateTaskId(): String {
        return "task_${System.currentTimeMillis()}_${(Math.random() * 1000).toInt()}"
    }
}

// ==================== 📦 数据类定义 ====================

/**
 * 🎯 可执行任务
 */
data class ExecutableTask(
    val id: String = "",
    val name: String,
    val type: String,
    val steps: List<ExecutionStep>,
    val dependencies: List<String> = emptyList(),
    val requiredPermissions: List<String> = emptyList(),
    val riskLevel: RiskLevel = RiskLevel.SAFE,
    val enableRollback: Boolean = true,
    val metadata: Map<String, Any> = emptyMap()
)

/**
 * 📝 执行步骤
 */
data class ExecutionStep(
    val id: String,
    val description: String,
    val actionType: ActionType,
    val target: String? = null,
    val value: String? = null,
    val estimatedDuration: Long = 500,
    val waitAfter: Long = 300,
    val retryCount: Int = 3,
    val retryDelay: Long = 500,
    val fallbackStepId: String? = null,
    val skippable: Boolean = false
)

/**
 * 🎬 动作类型
 */
enum class ActionType {
    CLICK, LONG_CLICK, DOUBLE_CLICK,
    INPUT, CLEAR_INPUT,
    SCROLL, SWIPE,
    BACK, HOME, RECENT_APPS,
    LAUNCH_APP, CLOSE_APP,
    WAIT, CHECK_STATE,
    DELETE, PAYMENT, SHARE,
    SCREENSHOT, CUSTOM
}

/**
 * ⚡ 任务优先级
 */
enum class TaskPriority {
    LOW, NORMAL, HIGH, CRITICAL
}

/**
 * ⚠️ 风险级别
 */
enum class RiskLevel {
    SAFE, LOW, MEDIUM, HIGH, CRITICAL
}

/**
 * 🔄 执行状态
 */
enum class ExecutionStatus {
    QUEUED, RUNNING, PAUSED, COMPLETED, FAILED, CANCELLED, ROLLING_BACK
}

/**
 * 🔧 恢复策略
 */
enum class ExecutorRecoveryStrategy {
    RETRY_WITH_SCROLL, WAIT_AND_RETRY, GO_BACK_AND_RETRY, SKIP, ABORT
}

/**
 * 📊 日志级别
 */
enum class LogLevel {
    DEBUG, INFO, WARN, ERROR
}

/**
 * 📋 预检查结果
 */
data class PreCheckResult(
    val canExecute: Boolean,
    val issues: List<PreCheckIssue>,
    val estimatedDuration: Long,
    val riskAssessment: RiskAssessment
)

/**
 * ⚠️ 预检查问题
 */
data class PreCheckIssue(
    val type: IssueType,
    val message: String,
    val severity: IssueSeverity
)

enum class IssueType {
    MISSING_STEPS, DEPENDENCY_NOT_MET, PERMISSION_WARNING, HIGH_RISK, KNOWN_ERROR_PATTERN
}

enum class IssueSeverity {
    INFO, WARNING, ERROR
}

/**
 * ⚖️ 风险评估
 */
data class RiskAssessment(
    val level: RiskLevel,
    val score: Int,
    val factors: List<String>
)

/**
 * 📊 任务执行状态
 */
data class TaskExecutionState(
    val taskId: String,
    val status: ExecutionStatus,
    val progress: Float,
    val currentStep: String?,
    val error: String? = null,
    val startTime: Long,
    val updateTime: Long
)

/**
 * 📈 任务进度
 */
data class TaskExecutionProgress(
    val id: String,
    val progressPercent: Float,
    val stepsCompleted: Int,
    val stepsTotal: Int,
    val stepDescription: String
)

/**
 * ✅ 任务结果
 */
data class TaskResult(
    val taskId: String,
    val success: Boolean,
    val message: String,
    val error: Exception? = null,
    val duration: Long,
    val stepsCompleted: Int
)

/**
 * 📝 步骤执行结果
 */
data class StepResult(
    val success: Boolean,
    val error: String? = null
)

/**
 * 📝 执行日志条目
 */
data class ExecutionLogEntry(
    val timestamp: Long,
    val taskId: String,
    val level: LogLevel,
    val message: String
)

/**
 * 🔄 任务执行上下文
 */
data class TaskExecutionContext(
    val taskId: String,
    val task: ExecutableTask,
    val priority: TaskPriority,
    val onProgress: ((TaskExecutionProgress) -> Unit)?,
    val onComplete: ((TaskResult) -> Unit)?,
    val isPaused: AtomicBoolean,
    val isCancelled: AtomicBoolean,
    val currentStepIndex: AtomicInteger,
    val completedSteps: MutableList<ExecutionStep>,
    val startTime: Long
)

/**
 * 📊 优先级任务包装
 */
data class PrioritizedExecutionTask(
    val task: ExecutableTask,
    val priority: TaskPriority,
    val taskId: String
)

/**
 * 📚 错误模式
 */
data class ErrorPattern(
    val taskType: String,
    val errorMessage: String,
    val description: String,
    val occurrenceCount: Int,
    val lastOccurrence: Long
)

/**
 * 📈 执行统计
 */
data class ExecutionStats(
    val totalTasks: AtomicInteger = AtomicInteger(0),
    val successfulTasks: AtomicInteger = AtomicInteger(0),
    val failedTasks: AtomicInteger = AtomicInteger(0)
)

/**
 * 📈 执行统计快照
 */
data class ExecutionStatsSnapshot(
    val totalTasks: Int,
    val successfulTasks: Int,
    val failedTasks: Int,
    val runningTasks: Int,
    val queuedTasks: Int,
    val successRate: Float
)

/**
 * 📋 任务计划可视化
 */
data class TaskPlanVisualization(
    val taskName: String,
    val totalSteps: Int,
    val estimatedDuration: Long,
    val steps: List<StepVisualization>,
    val riskLevel: String
)

/**
 * 📋 步骤可视化
 */
data class StepVisualization(
    val index: Int,
    val description: String,
    val actionType: String,
    val estimatedDuration: Long,
    val hasFallback: Boolean
)

/**
 * ❌ 任务执行异常
 */
class TaskExecutionException(message: String) : Exception(message)
