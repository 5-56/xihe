package com.example.xihe.core

import android.content.Context
import android.view.accessibility.AccessibilityNodeInfo
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.delay
import kotlinx.serialization.Serializable
import java.util.concurrent.ConcurrentHashMap

/**
 * 🛠️ 统一错误恢复管理器
 *
 * 整合了 ErrorRecovery、ErrorRecoveryManager、IntelligentErrorRecovery 的功能
 *
 * 功能:
 * - 智能错误分类和诊断
 * - 多策略自动恢复
 * - 学习失败模式并优化恢复策略
 * - 错误历史记录
 * - 用户友好提示
 *
 * @author Xihe AI Team
 */
class UnifiedErrorRecovery private constructor(private val context: Context) {

    companion object {
        private const val TAG = "UnifiedErrorRecovery"
        private const val MAX_RETRY_COUNT = 3
        private const val MAX_ERROR_HISTORY = 100
        private const val MAX_RECOVERY_ATTEMPTS = 3

        @Volatile
        private var instance: UnifiedErrorRecovery? = null

        fun getInstance(context: Context): UnifiedErrorRecovery {
            return instance ?: synchronized(this) {
                instance ?: UnifiedErrorRecovery(context.applicationContext).also { instance = it }
            }
        }
    }

    // ==================== 枚举定义 ====================

    /**
     * 错误类型枚举
     */
    enum class ErrorType {
        // UI 相关
        ELEMENT_NOT_FOUND,          // 元素未找到
        ELEMENT_NOT_CLICKABLE,      // 元素不可点击
        ELEMENT_NOT_VISIBLE,        // 元素不可见
        NODE_NOT_FOUND,             // 节点未找到

        // 屏幕状态
        SCREEN_CHANGED,             // 屏幕已变化
        SCREEN_UNCHANGED,           // 屏幕状态未改变
        UNEXPECTED_SCREEN,          // 出现意外的界面
        UNEXPECTED_DIALOG,          // 意外弹窗

        // 应用状态
        APP_NOT_RESPONDING,         // 应用无响应
        APP_CRASHED,                // 应用崩溃

        // 动作执行
        ACTION_FAILED,              // 动作执行失败
        INPUT_FAILED,               // 输入失败
        GESTURE_FAILED,             // 手势失败
        NAVIGATION_FAILED,          // 导航失败

        // 系统相关
        PERMISSION_DENIED,          // 权限被拒绝
        SERVICE_DISCONNECTED,       // 服务断开
        TIMEOUT,                    // 超时
        NETWORK_ERROR,              // 网络错误

        // 验证
        VERIFICATION_FAILED,        // 验证失败

        // 未知
        UNKNOWN                     // 未知错误
    }

    /**
     * 恢复策略枚举
     */
    enum class RecoveryStrategy(val displayName: String) {
        // 重试策略
        RETRY_SAME("重试相同操作"),
        RETRY_ALTERNATIVE("尝试替代方法"),
        WAIT_AND_RETRY("等待后重试"),
        WAIT_FOR_LOAD("等待页面加载"),

        // 滚动策略
        SCROLL_AND_RETRY("滚动后重试"),
        SCROLL_TO_FIND("滚动查找元素"),

        // 导航策略
        GO_BACK("返回上一页"),
        NAVIGATE_BACK("导航返回"),

        // 弹窗处理
        DISMISS_DIALOG("关闭弹窗"),
        CLOSE_POPUP("关闭弹窗"),

        // 应用操作
        RESTART_APP("重启应用"),
        RESTART_TASK("重启任务"),
        CLEAR_APP_DATA("清除应用数据"),

        // 降级策略
        USE_OCR_FALLBACK("使用OCR识别"),
        SWITCH_TO_OFFLINE("切换离线模式"),
        SIMPLIFY_TASK("简化任务"),
        SKIP_STEP("跳过当前步骤"),
        EXTEND_TIMEOUT("延长超时时间"),

        // 用户交互
        ASK_USER("询问用户"),
        ASK_USER_HELP("请求用户帮助"),
        ASK_LLM_HELP("请求AI协助"),
        NOTIFY_USER("通知用户"),
        GUIDE_TO_SETTINGS("引导到设置"),
        EXPLAIN_PERMISSION("解释权限需求"),
        OPEN_SETTINGS("打开设置"),

        // 终止
        ABORT("中止任务"),
        ABORT_TASK("中止任务")
    }

    /**
     * 错误严重级别
     */
    enum class Severity {
        LOW,        // 低：可忽略
        MEDIUM,     // 中：可恢复
        HIGH,       // 高：需要处理
        CRITICAL    // 严重：必须处理
    }

    /**
     * 恢复结果枚举
     */
    enum class RecoveryOutcome {
        RECOVERED,              // 已恢复
        PARTIALLY_RECOVERED,    // 部分恢复
        FAILED,                 // 恢复失败
        USER_INTERVENTION       // 需要用户介入
    }

    /**
     * 下一步动作
     */
    enum class NextAction {
        RETRY,          // 重试
        TRY_NEXT,       // 尝试下一个策略
        USE_OCR,        // 使用OCR
        RESTART_APP,    // 重启应用
        OPEN_SETTINGS,  // 打开设置
        ASK_LLM,        // 请求LLM
        ASK_USER,       // 请求用户
        ABORT           // 中止
    }

    // ==================== 数据类 ====================

    /**
     * 重试配置
     */
    data class RetryConfig(
        val maxRetries: Int = 3,
        val delayMs: Long = 1000,
        val exponentialBackoff: Boolean = true,
        val backoffMultiplier: Double = 2.0
    )

    /**
     * 错误上下文
     */
    data class ErrorContext(
        val currentApp: String? = null,
        val currentScreen: String? = null,
        val targetElement: String? = null,
        val action: String? = null,
        val stackTrace: String? = null,
        val attemptCount: Int = 0,
        val lastCommand: AICommand? = null
    )

    /**
     * 执行上下文
     */
    data class ExecutionContext(
        val taskId: String? = null,
        val currentApp: String? = null,
        val targetElement: String? = null,
        val action: String? = null,
        val step: Int = 0
    )

    /**
     * 执行错误
     */
    data class ExecutionError(
        val type: ErrorType,
        val message: String,
        val exception: Exception? = null,
        val context: ErrorContext? = null
    )

    /**
     * 诊断结果
     */
    data class Diagnosis(
        val type: ErrorType,
        val rootCause: String,
        val possibleReasons: List<String>,
        val recommendedStrategies: List<RecoveryStrategy>,
        val severity: Severity,
        val userMessage: String
    )

    /**
     * 恢复尝试记录
     */
    data class RecoveryAttempt(
        val strategy: RecoveryStrategy,
        val success: Boolean,
        val duration: Long,
        val details: String? = null
    )

    /**
     * 恢复结果
     */
    data class RecoveryResult(
        val success: Boolean,
        val strategy: RecoveryStrategy?,
        val attempts: Int = 0,
        val message: String,
        val shouldContinue: Boolean = true,
        val nextAction: NextAction? = null
    )

    /**
     * 策略执行结果
     */
    data class StrategyResult(
        val success: Boolean,
        val message: String,
        val nextAction: NextAction
    )

    /**
     * 错误记录
     */
    data class ErrorRecord(
        val timestamp: Long,
        val errorType: ErrorType,
        val description: String,
        val context: ErrorContext,
        val recoveryAttempts: List<RecoveryAttempt>,
        val finalOutcome: RecoveryOutcome
    )

    /**
     * 失败模式
     */
    @Serializable
    data class FailurePattern(
        val errorType: String,
        val context: String,
        val failedStrategies: List<String>,
        val successfulStrategy: String? = null,
        val timestamp: Long = System.currentTimeMillis()
    )

    // ==================== 状态存储 ====================

    // 错误历史记录
    private val errorHistory = mutableListOf<ErrorRecord>()

    // 错误模式学习 (错误类型 -> 成功恢复策略)
    private val learnedPatterns = ConcurrentHashMap<ErrorType, RecoveryStrategy>()

    // 失败模式学习库
    private val failurePatterns = mutableListOf<FailurePattern>()

    // ==================== 错误分类 ====================

    /**
     * 分析错误类型
     */
    fun classifyError(
        exception: Exception? = null,
        actionType: String? = null,
        elementInfo: String? = null,
        screenState: String? = null
    ): ErrorType {
        // 根据异常类型分类
        exception?.let {
            val message = it.message?.lowercase() ?: ""
            return when {
                message.contains("not found") || message.contains("null") -> ErrorType.ELEMENT_NOT_FOUND
                message.contains("not clickable") -> ErrorType.ELEMENT_NOT_CLICKABLE
                message.contains("not visible") -> ErrorType.ELEMENT_NOT_VISIBLE
                message.contains("timeout") -> ErrorType.TIMEOUT
                message.contains("network") || message.contains("connection") -> ErrorType.NETWORK_ERROR
                message.contains("permission") -> ErrorType.PERMISSION_DENIED
                message.contains("crash") -> ErrorType.APP_CRASHED
                else -> ErrorType.UNKNOWN
            }
        }

        // 根据动作类型和上下文推断
        return when {
            actionType == "CLICK" && elementInfo == null -> ErrorType.ELEMENT_NOT_FOUND
            actionType == "INPUT" -> ErrorType.INPUT_FAILED
            actionType == "SCROLL" -> ErrorType.GESTURE_FAILED
            screenState?.contains("dialog") == true -> ErrorType.UNEXPECTED_DIALOG
            else -> ErrorType.UNKNOWN
        }
    }

    /**
     * 智能诊断错误
     */
    fun diagnoseError(error: ExecutionError): Diagnosis {
        LogManager.d(TAG, "🔍 诊断错误: ${error.type} - ${error.message}")

        return when (error.type) {
            ErrorType.ELEMENT_NOT_FOUND, ErrorType.NODE_NOT_FOUND -> Diagnosis(
                type = error.type,
                rootCause = "目标UI元素未找到",
                possibleReasons = listOf(
                    "应用界面已更新",
                    "页面加载未完成",
                    "元素被遮挡",
                    "需要滚动才能看到"
                ),
                recommendedStrategies = listOf(
                    RecoveryStrategy.WAIT_FOR_LOAD,
                    RecoveryStrategy.SCROLL_TO_FIND,
                    RecoveryStrategy.USE_OCR_FALLBACK,
                    RecoveryStrategy.ASK_USER_HELP
                ),
                severity = Severity.MEDIUM,
                userMessage = "找不到目标元素，正在尝试其他方法..."
            )

            ErrorType.PERMISSION_DENIED -> Diagnosis(
                type = error.type,
                rootCause = "权限不足",
                possibleReasons = listOf(
                    "缺少必要权限",
                    "权限被用户拒绝",
                    "系统安全限制"
                ),
                recommendedStrategies = listOf(
                    RecoveryStrategy.GUIDE_TO_SETTINGS,
                    RecoveryStrategy.EXPLAIN_PERMISSION,
                    RecoveryStrategy.ASK_USER_HELP
                ),
                severity = Severity.HIGH,
                userMessage = "需要授予权限才能继续哦~"
            )

            ErrorType.NETWORK_ERROR -> Diagnosis(
                type = error.type,
                rootCause = "网络连接问题",
                possibleReasons = listOf(
                    "网络未连接",
                    "网络不稳定",
                    "服务器超时"
                ),
                recommendedStrategies = listOf(
                    RecoveryStrategy.WAIT_AND_RETRY,
                    RecoveryStrategy.SWITCH_TO_OFFLINE,
                    RecoveryStrategy.NOTIFY_USER
                ),
                severity = Severity.MEDIUM,
                userMessage = "网络似乎有点问题，稍后重试..."
            )

            ErrorType.UNEXPECTED_SCREEN, ErrorType.UNEXPECTED_DIALOG -> Diagnosis(
                type = error.type,
                rootCause = "出现了意外的界面",
                possibleReasons = listOf(
                    "弹出了广告",
                    "出现了错误提示",
                    "跳转到了错误页面",
                    "应用崩溃重启"
                ),
                recommendedStrategies = listOf(
                    RecoveryStrategy.CLOSE_POPUP,
                    RecoveryStrategy.NAVIGATE_BACK,
                    RecoveryStrategy.RESTART_APP,
                    RecoveryStrategy.ASK_LLM_HELP
                ),
                severity = Severity.HIGH,
                userMessage = "遇到了意外情况，正在处理..."
            )

            ErrorType.TIMEOUT -> Diagnosis(
                type = error.type,
                rootCause = "操作超时",
                possibleReasons = listOf(
                    "应用响应太慢",
                    "网络延迟",
                    "任务太复杂"
                ),
                recommendedStrategies = listOf(
                    RecoveryStrategy.EXTEND_TIMEOUT,
                    RecoveryStrategy.SIMPLIFY_TASK,
                    RecoveryStrategy.WAIT_AND_RETRY
                ),
                severity = Severity.MEDIUM,
                userMessage = "操作有点慢，请稍等..."
            )

            ErrorType.APP_CRASHED, ErrorType.APP_NOT_RESPONDING -> Diagnosis(
                type = error.type,
                rootCause = "应用异常",
                possibleReasons = listOf(
                    "应用bug",
                    "内存不足",
                    "系统不兼容"
                ),
                recommendedStrategies = listOf(
                    RecoveryStrategy.RESTART_APP,
                    RecoveryStrategy.CLEAR_APP_DATA,
                    RecoveryStrategy.NOTIFY_USER
                ),
                severity = Severity.CRITICAL,
                userMessage = "应用出现问题，正在尝试恢复..."
            )

            ErrorType.ACTION_FAILED, ErrorType.GESTURE_FAILED -> Diagnosis(
                type = error.type,
                rootCause = "动作执行失败",
                possibleReasons = listOf(
                    "元素状态变化",
                    "执行时机不对",
                    "系统响应延迟"
                ),
                recommendedStrategies = listOf(
                    RecoveryStrategy.RETRY_SAME,
                    RecoveryStrategy.WAIT_AND_RETRY,
                    RecoveryStrategy.RETRY_ALTERNATIVE
                ),
                severity = Severity.MEDIUM,
                userMessage = "操作未能完成，重试中..."
            )

            else -> Diagnosis(
                type = ErrorType.UNKNOWN,
                rootCause = "未知错误",
                possibleReasons = listOf("需要进一步分析"),
                recommendedStrategies = listOf(
                    RecoveryStrategy.RETRY_SAME,
                    RecoveryStrategy.ASK_USER_HELP,
                    RecoveryStrategy.ABORT_TASK
                ),
                severity = Severity.HIGH,
                userMessage = "遇到了未知错误..."
            )
        }
    }

    // ==================== 恢复执行 ====================

    /**
     * 尝试恢复 - 主入口
     */
    suspend fun tryRecover(
        errorType: ErrorType,
        errorContext: ErrorContext,
        service: CoreAccessibilityService? = CoreAccessibilityService.instance
    ): RecoveryResult {
        LogManager.w(TAG, "🔧 开始错误恢复: type=$errorType")

        val startTime = System.currentTimeMillis()
        val attempts = mutableListOf<RecoveryAttempt>()

        // 获取推荐的恢复策略
        val strategies = getRecoveryStrategies(errorType)

        for (strategy in strategies.take(MAX_RECOVERY_ATTEMPTS)) {
            val attemptStart = System.currentTimeMillis()

            val success = executeStrategy(strategy, errorContext, service)

            attempts.add(
                RecoveryAttempt(
                    strategy = strategy,
                    success = success,
                    duration = System.currentTimeMillis() - attemptStart
                )
            )

            if (success) {
                // 学习成功的模式
                learnPattern(errorType, strategy)
                recordError(errorType, errorContext, attempts, RecoveryOutcome.RECOVERED)

                LogManager.d(TAG, "✅ 恢复成功！使用策略: ${strategy.displayName}")
                return RecoveryResult(
                    success = true,
                    strategy = strategy,
                    attempts = attempts.size,
                    message = "通过 ${strategy.displayName} 成功恢复",
                    shouldContinue = true
                )
            }

            delay(500) // 策略之间等待
        }

        // 所有策略都失败了
        recordError(errorType, errorContext, attempts, RecoveryOutcome.FAILED)

        LogManager.e(TAG, "❌ 所有恢复策略都失败了")
        return RecoveryResult(
            success = false,
            strategy = RecoveryStrategy.ABORT,
            attempts = attempts.size,
            message = "所有恢复策略都失败了",
            shouldContinue = false,
            nextAction = NextAction.ASK_USER
        )
    }

    /**
     * 基于诊断的恢复
     */
    suspend fun recoverFromDiagnosis(
        diagnosis: Diagnosis,
        executionContext: ExecutionContext,
        service: CoreAccessibilityService? = CoreAccessibilityService.instance
    ): RecoveryResult {
        LogManager.d(TAG, "🔧 基于诊断恢复: ${diagnosis.type}")

        // 检查是否有已知的成功策略
        val knownStrategy = learnedPatterns[diagnosis.type]
        val strategies = if (knownStrategy != null) {
            listOf(knownStrategy) + diagnosis.recommendedStrategies.filter { it != knownStrategy }
        } else {
            diagnosis.recommendedStrategies
        }

        // 依次尝试恢复策略
        for ((index, strategy) in strategies.take(MAX_RECOVERY_ATTEMPTS).withIndex()) {
            LogManager.d(TAG, "尝试策略 ${index + 1}: ${strategy.displayName}")

            val result = tryStrategy(strategy, executionContext, service)

            if (result.success) {
                // 记录成功的策略
                learnedPatterns[diagnosis.type] = strategy

                LogManager.d(TAG, "✅ 恢复成功！使用策略: ${strategy.displayName}")
                return RecoveryResult(
                    success = true,
                    strategy = strategy,
                    attempts = index + 1,
                    message = result.message,
                    nextAction = result.nextAction
                )
            } else {
                LogManager.d(TAG, "❌ 策略失败: ${result.message}")
            }
        }

        // 所有策略都失败了，学习这个失败模式
        learnFailurePattern(diagnosis, executionContext)

        return RecoveryResult(
            success = false,
            strategy = null,
            message = "无法自动恢复，需要您的帮助",
            nextAction = NextAction.ASK_USER
        )
    }

    /**
     * 执行单个策略
     */
    private suspend fun executeStrategy(
        strategy: RecoveryStrategy,
        context: ErrorContext,
        service: CoreAccessibilityService?
    ): Boolean {
        LogManager.d(TAG, "执行恢复策略: ${strategy.displayName}")

        return try {
            when (strategy) {
                RecoveryStrategy.RETRY_SAME -> {
                    delay(300)
                    true
                }

                RecoveryStrategy.WAIT_AND_RETRY, RecoveryStrategy.WAIT_FOR_LOAD -> {
                    delay(2000)
                    true
                }

                RecoveryStrategy.SCROLL_AND_RETRY, RecoveryStrategy.SCROLL_TO_FIND -> {
                    service?.let {
                        val displayMetrics = it.resources.displayMetrics
                        val centerX = displayMetrics.widthPixels / 2f
                        val centerY = displayMetrics.heightPixels / 2f
                        it.performScroll(centerX, centerY + 300, centerX, centerY - 300)
                        delay(500)
                        true
                    } ?: false
                }

                RecoveryStrategy.DISMISS_DIALOG, RecoveryStrategy.CLOSE_POPUP -> {
                    dismissDialog(service)
                }

                RecoveryStrategy.GO_BACK, RecoveryStrategy.NAVIGATE_BACK -> {
                    service?.performGlobalBack()
                    delay(500)
                    true
                }

                RecoveryStrategy.RESTART_APP -> {
                    context.currentApp?.let { pkg ->
                        service?.performGlobalHome()
                        delay(500)
                        val intent = this.context.packageManager.getLaunchIntentForPackage(pkg)
                        intent?.let {
                            it.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                            this.context.startActivity(it)
                            delay(2000)
                            true
                        } ?: false
                    } ?: false
                }

                RecoveryStrategy.RETRY_ALTERNATIVE -> {
                    delay(500)
                    true // 标记为可以尝试替代方法
                }

                RecoveryStrategy.EXTEND_TIMEOUT -> {
                    delay(3000) // 更长的等待
                    true
                }

                RecoveryStrategy.SKIP_STEP -> {
                    true // 跳过当前步骤
                }

                else -> {
                    // 需要用户交互的策略，返回 true 表示需要进一步处理
                    true
                }
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "策略执行异常: ${strategy.displayName}", e)
            false
        }
    }

    /**
     * 尝试单个策略（带详细结果）
     */
    private suspend fun tryStrategy(
        strategy: RecoveryStrategy,
        context: ExecutionContext,
        service: CoreAccessibilityService?
    ): StrategyResult {
        return when (strategy) {
            RecoveryStrategy.WAIT_FOR_LOAD -> {
                delay(2000)
                StrategyResult(true, "等待页面加载完成", NextAction.RETRY)
            }

            RecoveryStrategy.SCROLL_TO_FIND -> {
                service?.let {
                    val found = scrollAndFind(it, context)
                    StrategyResult(
                        success = found,
                        message = if (found) "通过滚动找到了元素" else "滚动后仍未找到",
                        nextAction = if (found) NextAction.RETRY else NextAction.TRY_NEXT
                    )
                } ?: StrategyResult(false, "服务不可用", NextAction.TRY_NEXT)
            }

            RecoveryStrategy.USE_OCR_FALLBACK -> {
                StrategyResult(true, "切换到OCR识别模式", NextAction.USE_OCR)
            }

            RecoveryStrategy.NAVIGATE_BACK, RecoveryStrategy.GO_BACK -> {
                service?.performGlobalBack()
                delay(500)
                StrategyResult(true, "返回到上一页", NextAction.RETRY)
            }

            RecoveryStrategy.CLOSE_POPUP, RecoveryStrategy.DISMISS_DIALOG -> {
                service?.let {
                    val closed = dismissDialog(it)
                    StrategyResult(
                        success = closed,
                        message = if (closed) "关闭了弹窗" else "未找到弹窗",
                        nextAction = if (closed) NextAction.RETRY else NextAction.TRY_NEXT
                    )
                } ?: StrategyResult(false, "服务不可用", NextAction.TRY_NEXT)
            }

            RecoveryStrategy.RESTART_APP -> {
                StrategyResult(true, "准备重启应用", NextAction.RESTART_APP)
            }

            RecoveryStrategy.GUIDE_TO_SETTINGS, RecoveryStrategy.OPEN_SETTINGS -> {
                StrategyResult(true, "需要您手动授权", NextAction.OPEN_SETTINGS)
            }

            RecoveryStrategy.ASK_LLM_HELP -> {
                StrategyResult(true, "请求AI分析当前情况", NextAction.ASK_LLM)
            }

            RecoveryStrategy.ASK_USER_HELP, RecoveryStrategy.ASK_USER -> {
                StrategyResult(true, "需要您的帮助", NextAction.ASK_USER)
            }

            RecoveryStrategy.ABORT, RecoveryStrategy.ABORT_TASK -> {
                StrategyResult(true, "任务已中止", NextAction.ABORT)
            }

            else -> {
                StrategyResult(false, "未实现的策略", NextAction.TRY_NEXT)
            }
        }
    }

    // ==================== 策略获取 ====================

    /**
     * 获取恢复策略列表
     */
    private fun getRecoveryStrategies(errorType: ErrorType): List<RecoveryStrategy> {
        // 首先检查是否有学习到的成功模式
        learnedPatterns[errorType]?.let {
            return listOf(it) + getDefaultStrategies(errorType).filter { s -> s != it }
        }
        return getDefaultStrategies(errorType)
    }

    /**
     * 获取默认恢复策略
     */
    private fun getDefaultStrategies(errorType: ErrorType): List<RecoveryStrategy> {
        return when (errorType) {
            ErrorType.ELEMENT_NOT_FOUND, ErrorType.NODE_NOT_FOUND -> listOf(
                RecoveryStrategy.WAIT_AND_RETRY,
                RecoveryStrategy.SCROLL_AND_RETRY,
                RecoveryStrategy.GO_BACK,
                RecoveryStrategy.RETRY_ALTERNATIVE
            )

            ErrorType.ELEMENT_NOT_CLICKABLE -> listOf(
                RecoveryStrategy.WAIT_AND_RETRY,
                RecoveryStrategy.RETRY_ALTERNATIVE,
                RecoveryStrategy.SCROLL_AND_RETRY
            )

            ErrorType.ELEMENT_NOT_VISIBLE -> listOf(
                RecoveryStrategy.SCROLL_AND_RETRY,
                RecoveryStrategy.WAIT_AND_RETRY
            )

            ErrorType.SCREEN_CHANGED -> listOf(
                RecoveryStrategy.RETRY_SAME,
                RecoveryStrategy.GO_BACK,
                RecoveryStrategy.RESTART_TASK
            )

            ErrorType.SCREEN_UNCHANGED -> listOf(
                RecoveryStrategy.RETRY_SAME,
                RecoveryStrategy.RETRY_ALTERNATIVE
            )

            ErrorType.APP_NOT_RESPONDING -> listOf(
                RecoveryStrategy.WAIT_AND_RETRY,
                RecoveryStrategy.RESTART_APP
            )

            ErrorType.APP_CRASHED -> listOf(
                RecoveryStrategy.RESTART_APP,
                RecoveryStrategy.RESTART_TASK
            )

            ErrorType.UNEXPECTED_DIALOG, ErrorType.UNEXPECTED_SCREEN -> listOf(
                RecoveryStrategy.DISMISS_DIALOG,
                RecoveryStrategy.GO_BACK
            )

            ErrorType.TIMEOUT -> listOf(
                RecoveryStrategy.RETRY_SAME,
                RecoveryStrategy.WAIT_AND_RETRY,
                RecoveryStrategy.EXTEND_TIMEOUT
            )

            ErrorType.INPUT_FAILED -> listOf(
                RecoveryStrategy.RETRY_SAME,
                RecoveryStrategy.RETRY_ALTERNATIVE
            )

            ErrorType.GESTURE_FAILED, ErrorType.ACTION_FAILED -> listOf(
                RecoveryStrategy.RETRY_SAME,
                RecoveryStrategy.RETRY_ALTERNATIVE
            )

            ErrorType.NETWORK_ERROR -> listOf(
                RecoveryStrategy.WAIT_AND_RETRY,
                RecoveryStrategy.SWITCH_TO_OFFLINE,
                RecoveryStrategy.NOTIFY_USER
            )

            ErrorType.PERMISSION_DENIED -> listOf(
                RecoveryStrategy.GUIDE_TO_SETTINGS,
                RecoveryStrategy.ASK_USER_HELP
            )

            ErrorType.SERVICE_DISCONNECTED -> listOf(
                RecoveryStrategy.ASK_USER_HELP,
                RecoveryStrategy.ABORT
            )

            else -> listOf(
                RecoveryStrategy.RETRY_SAME,
                RecoveryStrategy.ASK_USER
            )
        }
    }

    // ==================== 辅助方法 ====================

    /**
     * 滚动查找元素
     */
    private suspend fun scrollAndFind(
        service: CoreAccessibilityService,
        context: ExecutionContext
    ): Boolean {
        for (i in 0 until 3) {
            // 向下滚动
            val displayMetrics = service.resources.displayMetrics
            val centerX = displayMetrics.widthPixels / 2f
            val centerY = displayMetrics.heightPixels / 2f
            service.performScroll(centerX, centerY + 300, centerX, centerY - 300)
            delay(500)

            // 检查是否找到目标元素
            val rootNode = service.rootInActiveWindow ?: continue
            val targetElement = context.targetElement ?: continue

            val found = findElementByText(rootNode, targetElement)

            if (found) {
                LogManager.d(TAG, "✅ 滚动后找到元素: $targetElement")
                return true
            }
        }
        LogManager.d(TAG, "⚠️ 滚动后未找到元素")
        return false
    }

    /**
     * 通过文本查找元素
     */
    private fun findElementByText(
        node: AccessibilityNodeInfo,
        targetText: String
    ): Boolean {
        val text = node.text?.toString() ?: ""
        val desc = node.contentDescription?.toString() ?: ""

        if (text.contains(targetText, ignoreCase = true) ||
            desc.contains(targetText, ignoreCase = true)
        ) {
            return true
        }

        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                if (findElementByText(child, targetText)) {
                    return true
                }
            }
        }
        return false
    }

    /**
     * 关闭弹窗
     */
    private fun dismissDialog(service: CoreAccessibilityService?): Boolean {
        service ?: return false
        val rootNode = service.rootInActiveWindow ?: return false

        // 查找常见的关闭按钮文字
        val closeTexts = listOf(
            "关闭", "取消", "我知道了", "确定", "跳过", "忽略",
            "close", "cancel", "ok", "skip", "dismiss", "×", "X"
        )

        for (closeText in closeTexts) {
            val nodes = rootNode.findAccessibilityNodeInfosByText(closeText)
            if (nodes.isNotEmpty()) {
                val closeNode = nodes.firstOrNull { it.isClickable }
                if (closeNode != null) {
                    val result = closeNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    if (result) {
                        LogManager.d(TAG, "✅ 成功点击关闭按钮: $closeText")
                        return true
                    }
                }
            }
        }

        return false
    }

    // ==================== 学习机制 ====================

    /**
     * 学习成功的恢复模式
     */
    private fun learnPattern(errorType: ErrorType, strategy: RecoveryStrategy) {
        learnedPatterns[errorType] = strategy
        LogManager.d(TAG, "📚 学习新模式: $errorType -> ${strategy.displayName}")
    }

    /**
     * 学习失败模式
     */
    private fun learnFailurePattern(diagnosis: Diagnosis, context: ExecutionContext) {
        val pattern = FailurePattern(
            errorType = diagnosis.type.name,
            context = "${context.currentApp}:${context.targetElement}",
            failedStrategies = diagnosis.recommendedStrategies.map { it.name }
        )
        failurePatterns.add(pattern)

        // 保持列表大小
        if (failurePatterns.size > MAX_ERROR_HISTORY) {
            failurePatterns.removeAt(0)
        }

        LogManager.d(TAG, "📚 记录失败模式: ${diagnosis.type}")
    }

    /**
     * 记录错误到历史
     */
    private fun recordError(
        errorType: ErrorType,
        context: ErrorContext,
        attempts: List<RecoveryAttempt>,
        outcome: RecoveryOutcome
    ) {
        val record = ErrorRecord(
            timestamp = System.currentTimeMillis(),
            errorType = errorType,
            description = "Error: $errorType in ${context.currentApp}",
            context = context,
            recoveryAttempts = attempts,
            finalOutcome = outcome
        )

        synchronized(errorHistory) {
            errorHistory.add(record)
            if (errorHistory.size > MAX_ERROR_HISTORY) {
                errorHistory.removeAt(0)
            }
        }
    }

    // ==================== 工具方法 ====================

    /**
     * 执行重试操作（带指数退避）
     */
    suspend fun <T> retryWithBackoff(
        config: RetryConfig = RetryConfig(),
        block: suspend (attemptNumber: Int) -> T
    ): Result<T> {
        var currentDelay = config.delayMs
        var lastException: Exception? = null

        repeat(config.maxRetries) { attempt ->
            try {
                val result = block(attempt + 1)
                return Result.success(result)
            } catch (e: Exception) {
                lastException = e
                LogManager.w(TAG, "Attempt ${attempt + 1} failed: ${e.message}")

                if (attempt < config.maxRetries - 1) {
                    delay(currentDelay)
                    if (config.exponentialBackoff) {
                        currentDelay = (currentDelay * config.backoffMultiplier).toLong()
                    }
                }
            }
        }

        return Result.failure(lastException ?: Exception("All retries failed"))
    }

    /**
     * 检查屏幕是否发生变化
     */
    fun hasScreenChanged(oldState: ScreenState?, newState: ScreenState?): Boolean {
        if (oldState == null || newState == null) return true

        // 比较包名和根节点类名
        if (oldState.packageName != newState.packageName) return true
        if (oldState.root.className != newState.root.className) return true

        // 检查可见元素数量变化
        val oldNodeCount = countNodes(oldState.root)
        val newNodeCount = countNodes(newState.root)

        // 如果节点数量变化超过10%，认为屏幕已改变
        if (oldNodeCount == 0) return newNodeCount > 0
        val changePercentage = kotlin.math.abs(newNodeCount - oldNodeCount).toFloat() / oldNodeCount
        return changePercentage > 0.1f
    }

    private fun countNodes(node: ScreenNode): Int {
        return 1 + node.children.sumOf { countNodes(it) }
    }

    /**
     * 智能等待（等待UI稳定）
     */
    suspend fun waitForUIStable(
        checkInterval: Long = 500,
        maxWaitTime: Long = 5000,
        stabilityCheck: suspend () -> Boolean
    ): Boolean {
        val startTime = System.currentTimeMillis()
        var consecutiveStable = 0
        val requiredStableChecks = 3

        while (System.currentTimeMillis() - startTime < maxWaitTime) {
            if (stabilityCheck()) {
                consecutiveStable++
                if (consecutiveStable >= requiredStableChecks) {
                    LogManager.d(TAG, "UI stable after ${System.currentTimeMillis() - startTime}ms")
                    return true
                }
            } else {
                consecutiveStable = 0
            }
            delay(checkInterval)
        }

        LogManager.w(TAG, "UI stability timeout after ${maxWaitTime}ms")
        return false
    }

    /**
     * 根据错误类型选择基本恢复策略（兼容旧API）
     */
    fun chooseBasicRecoveryStrategy(errorType: ErrorType, attemptCount: Int): RecoveryStrategy {
        return when (errorType) {
            ErrorType.NODE_NOT_FOUND, ErrorType.ELEMENT_NOT_FOUND -> {
                if (attemptCount < 2) RecoveryStrategy.RETRY_SAME
                else RecoveryStrategy.RETRY_ALTERNATIVE
            }
            ErrorType.ACTION_FAILED -> {
                if (attemptCount < 3) RecoveryStrategy.RETRY_SAME
                else RecoveryStrategy.GO_BACK
            }
            ErrorType.SCREEN_UNCHANGED -> {
                if (attemptCount < 2) RecoveryStrategy.RETRY_SAME
                else RecoveryStrategy.RETRY_ALTERNATIVE
            }
            ErrorType.TIMEOUT -> RecoveryStrategy.RETRY_SAME
            ErrorType.PERMISSION_DENIED -> RecoveryStrategy.ABORT
            ErrorType.SERVICE_DISCONNECTED -> RecoveryStrategy.ABORT
            ErrorType.NETWORK_ERROR -> {
                if (attemptCount < 3) RecoveryStrategy.RETRY_SAME
                else RecoveryStrategy.ABORT
            }
            else -> {
                if (attemptCount < 2) RecoveryStrategy.RETRY_SAME
                else RecoveryStrategy.ABORT
            }
        }
    }

    /**
     * 生成错误报告
     */
    fun generateErrorReport(
        errorType: ErrorType,
        context: ErrorContext
    ): String {
        val strategy = chooseBasicRecoveryStrategy(errorType, context.attemptCount)
        return buildString {
            appendLine("错误报告:")
            appendLine("- 类型: $errorType")
            appendLine("- 应用: ${context.currentApp ?: "未知"}")
            appendLine("- 动作: ${context.action ?: "未知"}")
            appendLine("- 尝试次数: ${context.attemptCount}")
            context.lastCommand?.let {
                appendLine("- 上次命令: ${it.action}")
                appendLine("- 上次思考: ${it.thought}")
            }
            appendLine("- 建议策略: ${strategy.displayName}")
        }
    }

    // ==================== 状态查询 ====================

    /**
     * 获取错误历史
     */
    fun getErrorHistory(): List<ErrorRecord> = synchronized(errorHistory) {
        errorHistory.toList()
    }

    /**
     * 获取最近的错误
     */
    fun getRecentErrors(count: Int = 10): List<ErrorRecord> = synchronized(errorHistory) {
        errorHistory.takeLast(count)
    }

    /**
     * 获取学习到的模式
     */
    fun getLearnedPatterns(): Map<ErrorType, RecoveryStrategy> {
        return learnedPatterns.toMap()
    }

    /**
     * 清除所有学习数据
     */
    fun clearLearningData() {
        learnedPatterns.clear()
        failurePatterns.clear()
        synchronized(errorHistory) {
            errorHistory.clear()
        }
        LogManager.d(TAG, "🗑️ 已清除所有学习数据")
    }

    /**
     * 获取统计信息
     */
    fun getStatistics(): Map<String, Any> {
        return mapOf(
            "totalErrors" to errorHistory.size,
            "learnedPatterns" to learnedPatterns.size,
            "failurePatterns" to failurePatterns.size,
            "recoveryRate" to calculateRecoveryRate()
        )
    }

    private fun calculateRecoveryRate(): Float {
        if (errorHistory.isEmpty()) return 0f
        val recovered = errorHistory.count { it.finalOutcome == RecoveryOutcome.RECOVERED }
        return recovered.toFloat() / errorHistory.size
    }
}
