package com.example.xihe.core

import android.content.Context
import com.example.xihe.utils.LogManager
import android.view.accessibility.AccessibilityNodeInfo
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.monitor.SystemMonitor
import com.example.xihe.safety.OperationSafetyManager
import com.example.xihe.scenarios.ScenarioManager
import com.example.xihe.ux.OnboardingGuide
import com.example.xihe.ux.UserFeedbackManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * 模块集成器
 * 统一管理和协调所有增强模块的初始化和调用
 */
object ModuleIntegration {
    
    private const val TAG = "ModuleIntegration"
    
    // 模块实例
    private var systemMonitor: SystemMonitor? = null
    private var safetyManager: OperationSafetyManager? = null
    private var errorRecoveryManager: ErrorRecoveryManager? = null
    private var feedbackManager: UserFeedbackManager? = null
    private var onboardingGuide: OnboardingGuide? = null
    private var scenarioManager: ScenarioManager? = null
    private var enhancedExecutor: EnhancedActionExecutor? = null
    private var actionVerifier: ActionVerifier? = null
    
    // 初始化状态
    private val _isInitialized = MutableStateFlow(false)
    val isInitialized: StateFlow<Boolean> = _isInitialized
    
    // ==================== 初始化 ====================
    
    /**
     * 初始化所有增强模块
     */
    fun initialize(context: Context) {
        LogManager.d(TAG, "开始初始化增强模块...")
        
        try {
            // 1. 系统监控
            systemMonitor = SystemMonitor.getInstance(context).apply {
                startMonitoring()
            }
            LogManager.d(TAG, "系统监控模块已初始化")
            
            // 2. 安全管理
            safetyManager = OperationSafetyManager.getInstance(context)
            LogManager.d(TAG, "安全管理模块已初始化")
            
            // 3. 错误恢复
            errorRecoveryManager = ErrorRecoveryManager.getInstance(context)
            LogManager.d(TAG, "错误恢复模块已初始化")
            
            // 4. 用户反馈
            feedbackManager = UserFeedbackManager.getInstance(context)
            LogManager.d(TAG, "用户反馈模块已初始化")
            
            // 5. 新手引导
            onboardingGuide = OnboardingGuide.getInstance(context)
            LogManager.d(TAG, "新手引导模块已初始化")
            
            // 6. 场景管理
            scenarioManager = ScenarioManager.getInstance(context)
            LogManager.d(TAG, "场景管理模块已初始化")
            
            // 7. 操作验证器
            actionVerifier = ActionVerifier()
            LogManager.d(TAG, "操作验证器已初始化")
            
            _isInitialized.value = true
            LogManager.d(TAG, "所有增强模块初始化完成！")
            
            // 检查是否首次使用
            if (onboardingGuide?.isFirstTime == true) {
                onboardingGuide?.startWelcomeGuide()
            }
            
        } catch (e: Exception) {
            LogManager.e(TAG, "模块初始化失败", e)
        }
    }
    
    /**
     * 初始化增强执行器（需要 AccessibilityService）
     */
    fun initializeExecutor(service: CoreAccessibilityService, context: Context) {
        enhancedExecutor = EnhancedActionExecutor(service, context)
        LogManager.d(TAG, "增强执行器已初始化")
    }
    
    // ==================== 获取模块实例 ====================
    
    fun getSystemMonitor(): SystemMonitor? = systemMonitor
    fun getSafetyManager(): OperationSafetyManager? = safetyManager
    fun getErrorRecoveryManager(): ErrorRecoveryManager? = errorRecoveryManager
    fun getFeedbackManager(): UserFeedbackManager? = feedbackManager
    fun getOnboardingGuide(): OnboardingGuide? = onboardingGuide
    fun getScenarioManager(): ScenarioManager? = scenarioManager
    fun getEnhancedExecutor(): EnhancedActionExecutor? = enhancedExecutor
    fun getActionVerifier(): ActionVerifier? = actionVerifier
    
    // ==================== 增强操作执行 ====================
    
    /**
     * 执行增强版操作
     */
    suspend fun executeEnhancedAction(
        command: AICommand,
        rootNode: AccessibilityNodeInfo?,
        context: Context
    ): EnhancedActionResult {
        val startTime = System.currentTimeMillis()
        
        // 1. 风险评估
        val riskAssessment = safetyManager?.assessRisk(
            operationType = mapActionToOperationType(command.action),
            targetApp = rootNode?.packageName?.toString(),
            actionDescription = command.thought
        )
        
        // 2. 高风险操作需要确认
        if (riskAssessment?.requireConfirmation == true) {
            LogManager.w(TAG, "高风险操作需要确认: ${command.action}")
            feedbackManager?.showWarning(
                title = "安全提醒",
                message = "${riskAssessment.suggestedAction}\n原因: ${riskAssessment.reasons.joinToString()}"
            )
            
            // 返回等待确认状态
            return EnhancedActionResult(
                success = false,
                requiresConfirmation = true,
                riskLevel = riskAssessment.level,
                message = "操作需要用户确认"
            )
        }
        
        // 3. 执行操作
        val executor = enhancedExecutor
        if (executor == null) {
            return EnhancedActionResult(
                success = false,
                message = "增强执行器未初始化"
            )
        }
        
        try {
            val targetIdStr = command.targetId?.toString()
            val result = when (command.action) {
                "CLICK" -> executor.smartClick(
                    rootNode = rootNode,
                    targetId = targetIdStr,
                    targetText = null
                )
                "SCROLL" -> executor.smartScroll(
                    rootNode = rootNode,
                    direction = when (command.direction) {
                        "UP" -> ScrollDirection.UP
                        "DOWN" -> ScrollDirection.DOWN
                        "LEFT" -> ScrollDirection.LEFT
                        "RIGHT" -> ScrollDirection.RIGHT
                        else -> ScrollDirection.DOWN
                    },
                    targetId = targetIdStr
                )
                "INPUT" -> executor.smartInput(
                    rootNode = rootNode,
                    targetId = targetIdStr,
                    text = command.inputText ?: ""
                )
                else -> {
                    // 回退到基础执行器
                    val service = CoreAccessibilityService.instance
                    if (service != null && rootNode != null) {
                        val basicExecutor = ActionExecutor(service, context)
                        val success = basicExecutor.execute(command, rootNode)
                        EnhancedActionExecutor.ActionResult(
                            success = success,
                            action = command.action
                        )
                    } else {
                        EnhancedActionExecutor.ActionResult(
                            success = false,
                            action = command.action,
                            errorMessage = "服务不可用"
                        )
                    }
                }
            }
            
            val latency = System.currentTimeMillis() - startTime
            
            // 4. 记录操作统计
            systemMonitor?.recordOperation(result.success, latency)
            
            // 5. 记录审计日志
            safetyManager?.recordAudit(
                operationType = mapActionToOperationType(command.action),
                description = command.thought,
                targetApp = rootNode?.packageName?.toString(),
                riskLevel = riskAssessment?.level ?: OperationSafetyManager.RiskLevel.SAFE,
                outcome = if (result.success) 
                    OperationSafetyManager.OperationOutcome.SUCCESS 
                else 
                    OperationSafetyManager.OperationOutcome.FAILED
            )
            
            // 6. 用户反馈
            if (result.success) {
                feedbackManager?.vibrate(UserFeedbackManager.VibrationPattern.LIGHT)
            }
            
            return EnhancedActionResult(
                success = result.success,
                action = command.action,
                retryCount = result.retryCount,
                latencyMs = latency,
                message = result.errorMessage
            )
            
        } catch (e: Exception) {
            LogManager.e(TAG, "操作执行异常", e)
            
            // 7. 尝试错误恢复
            val errorType = errorRecoveryManager?.classifyError(
                exception = e,
                actionType = command.action,
                elementInfo = command.targetId?.toString(),
                screenState = null
            ) ?: ErrorRecoveryManager.ErrorType.UNKNOWN
            
            val recoveryResult = errorRecoveryManager?.tryRecover(
                errorType = errorType,
                errorContext = ErrorRecoveryManager.ErrorContext(
                    currentApp = rootNode?.packageName?.toString(),
                    currentScreen = null,
                    targetElement = command.targetId?.toString(),
                    action = command.action,
                    stackTrace = e.stackTraceToString()
                ),
                service = CoreAccessibilityService.instance
            )
            
            return EnhancedActionResult(
                success = recoveryResult?.success ?: false,
                action = command.action,
                errorRecovered = recoveryResult?.success ?: false,
                message = recoveryResult?.message ?: e.message
            )
        }
    }
    
    /**
     * 映射操作类型
     */
    private fun mapActionToOperationType(action: String): OperationSafetyManager.OperationType {
        return when (action) {
            "CLICK" -> OperationSafetyManager.OperationType.CLICK
            "INPUT" -> OperationSafetyManager.OperationType.INPUT
            "SCROLL" -> OperationSafetyManager.OperationType.SCROLL
            else -> OperationSafetyManager.OperationType.OTHER
        }
    }
    
    // ==================== 状态报告 ====================
    
    /**
     * 生成系统状态报告
     */
    fun generateStatusReport(): SystemStatusReport {
        val monitorStats = systemMonitor?.currentMetrics?.value
        val safetyStats = safetyManager?.getRiskStatistics()
        val errorStats = errorRecoveryManager?.getErrorStatistics()
        val healthCheck = systemMonitor?.performHealthCheck()
        
        return SystemStatusReport(
            systemHealth = healthCheck?.overallHealth ?: SystemMonitor.SystemHealth.UNKNOWN,
            memoryUsagePercent = monitorStats?.memoryUsagePercent ?: 0f,
            successRate = monitorStats?.successRate ?: 1f,
            totalOperations = safetyStats?.totalOperations ?: 0,
            highRiskOperations = safetyStats?.highRiskOperations ?: 0,
            totalErrors = errorStats?.totalErrors ?: 0,
            errorRecoveryRate = errorStats?.recoveryRate ?: 0f,
            recommendations = systemMonitor?.generateReport()?.recommendations ?: emptyList()
        )
    }
    
    // ==================== 清理 ====================
    
    /**
     * 清理所有模块
     */
    fun cleanup() {
        systemMonitor?.stopMonitoring()
        feedbackManager?.destroy()
        _isInitialized.value = false
        LogManager.d(TAG, "所有模块已清理")
    }
}

/**
 * 增强操作结果
 */
data class EnhancedActionResult(
    val success: Boolean,
    val action: String = "",
    val retryCount: Int = 0,
    val latencyMs: Long = 0,
    val requiresConfirmation: Boolean = false,
    val riskLevel: OperationSafetyManager.RiskLevel? = null,
    val errorRecovered: Boolean = false,
    val message: String? = null
)

/**
 * 📋 系统状态报告
 */
data class SystemStatusReport(
    val systemHealth: SystemMonitor.SystemHealth,
    val memoryUsagePercent: Float,
    val successRate: Float,
    val totalOperations: Int,
    val highRiskOperations: Int,
    val totalErrors: Int,
    val errorRecoveryRate: Float,
    val recommendations: List<String>
)
