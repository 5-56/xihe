package com.example.xihe.core

import android.content.Context
import android.graphics.Rect
import android.os.SystemClock
import com.example.xihe.utils.LogManager
import android.view.accessibility.AccessibilityNodeInfo
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.screen.ScreenAnalyzer
import com.example.xihe.core.ScreenAnalyzer as CoreScreenAnalyzer
import kotlinx.coroutines.delay

/**
 * 🎮 增强版动作执行器
 * 提供操作验证、智能重试、结果检测等增强功能
 */
class EnhancedActionExecutor(
    private val service: CoreAccessibilityService,
    private val context: Context
) {
    
    companion object {
        private const val TAG = "EnhancedActionExecutor"
        
        // 默认配置
        const val DEFAULT_RETRY_COUNT = 3
        const val DEFAULT_RETRY_DELAY_MS = 300L
        const val DEFAULT_VERIFICATION_DELAY_MS = 200L
        const val DEFAULT_CLICK_DURATION_MS = 50L
        const val DEFAULT_LONG_PRESS_DURATION_MS = 800L
    }
    
    private val screenAnalyzer = ScreenAnalyzer()
    private val actionHistory = mutableListOf<ActionRecord>()
    
    // ==================== 📊 数据类定义 ====================
    
    /**
     * 🎯 操作结果
     */
    data class ActionResult(
        val success: Boolean,
        val action: String,
        val retryCount: Int = 0,
        val executionTime: Long = 0,
        val errorMessage: String? = null,
        val verificationResult: VerificationResult? = null
    )
    
    /**
     * ✅ 验证结果
     */
    data class VerificationResult(
        val verified: Boolean,
        val method: VerificationMethod,
        val details: String? = null
    )
    
    /**
     * 🔍 验证方法
     */
    enum class VerificationMethod {
        ELEMENT_STATE_CHANGE,   // 元素状态变化
        SCREEN_CHANGE,          // 屏幕变化
        ELEMENT_DISAPPEAR,      // 元素消失
        NEW_ELEMENT_APPEAR,     // 新元素出现
        CONTENT_CHANGE,         // 内容变化
        NONE                    // 不验证
    }
    
    /**
     * 📝 操作记录
     */
    data class ActionRecord(
        val timestamp: Long,
        val action: String,
        val target: String?,
        val success: Boolean,
        val details: Map<String, Any> = emptyMap()
    )
    
    /**
     * ⚙️ 操作配置
     */
    data class ActionConfig(
        val retryCount: Int = DEFAULT_RETRY_COUNT,
        val retryDelayMs: Long = DEFAULT_RETRY_DELAY_MS,
        val verificationDelayMs: Long = DEFAULT_VERIFICATION_DELAY_MS,
        val verificationMethod: VerificationMethod = VerificationMethod.SCREEN_CHANGE,
        val preCheck: Boolean = true,
        val postVerify: Boolean = true
    )
    
    // ==================== 🎯 点击操作 ====================
    
    /**
     * 🖱️ 智能点击 - 带验证和重试
     */
    suspend fun smartClick(
        rootNode: AccessibilityNodeInfo?,
        targetId: String?,
        targetText: String? = null,
        config: ActionConfig = ActionConfig()
    ): ActionResult {
        val startTime = System.currentTimeMillis()
        LogManager.d(TAG, "🖱️ 智能点击: targetId=$targetId, targetText=$targetText")
        
        // 预检查
        if (config.preCheck && rootNode == null) {
            return ActionResult(
                success = false,
                action = "CLICK",
                errorMessage = "根节点为空，无法执行点击"
            )
        }
        
        var lastError: String? = null
        
        for (attempt in 0 until config.retryCount) {
            try {
                // 查找目标元素
                val targetNode = findTargetNode(rootNode, targetId, targetText)
                
                if (targetNode == null) {
                    lastError = "未找到目标元素"
                    LogManager.w(TAG, "⚠️ 第${attempt + 1}次尝试: $lastError")
                    if (attempt < config.retryCount - 1) {
                        delay(config.retryDelayMs)
                    }
                    continue
                }
                
                // 检查元素是否可点击
                if (config.preCheck && !isElementClickable(targetNode)) {
                    lastError = "元素不可点击"
                    LogManager.w(TAG, "⚠️ 第${attempt + 1}次尝试: $lastError")
                    if (attempt < config.retryCount - 1) {
                        delay(config.retryDelayMs)
                    }
                    continue
                }
                
                // 计算最佳点击位置
                val clickPosition = calculateBestClickPosition(targetNode)
                
                // 记录点击前状态（用于验证）
                val beforeState = if (config.postVerify) captureNodeState(targetNode) else null
                
                // 执行点击
                val clicked = performClick(targetNode, clickPosition)
                
                if (!clicked) {
                    lastError = "点击执行失败"
                    LogManager.w(TAG, "⚠️ 第${attempt + 1}次尝试: $lastError")
                    if (attempt < config.retryCount - 1) {
                        delay(config.retryDelayMs)
                    }
                    continue
                }
                
                // 等待并验证
                if (config.postVerify) {
                    delay(config.verificationDelayMs)
                    val verificationResult = verifyClickResult(
                        targetNode, beforeState, config.verificationMethod
                    )
                    
                    if (!verificationResult.verified && attempt < config.retryCount - 1) {
                        lastError = "点击验证失败: ${verificationResult.details}"
                        LogManager.w(TAG, "⚠️ 第${attempt + 1}次尝试: $lastError")
                        delay(config.retryDelayMs)
                        continue
                    }
                    
                    val executionTime = System.currentTimeMillis() - startTime
                    recordAction("CLICK", targetId ?: targetText, true)
                    
                    return ActionResult(
                        success = true,
                        action = "CLICK",
                        retryCount = attempt,
                        executionTime = executionTime,
                        verificationResult = verificationResult
                    )
                }
                
                // 无验证，直接返回成功
                val executionTime = System.currentTimeMillis() - startTime
                recordAction("CLICK", targetId ?: targetText, true)
                
                return ActionResult(
                    success = true,
                    action = "CLICK",
                    retryCount = attempt,
                    executionTime = executionTime
                )
                
            } catch (e: Exception) {
                lastError = e.message
                LogManager.e(TAG, "❌ 点击异常: ${e.message}")
            }
        }
        
        recordAction("CLICK", targetId ?: targetText, false)
        return ActionResult(
            success = false,
            action = "CLICK",
            retryCount = config.retryCount,
            executionTime = System.currentTimeMillis() - startTime,
            errorMessage = lastError ?: "点击失败"
        )
    }
    
    /**
     * 📍 坐标点击 - 直接点击指定坐标
     */
    suspend fun clickAt(
        x: Float,
        y: Float,
        config: ActionConfig = ActionConfig()
    ): ActionResult {
        val startTime = System.currentTimeMillis()
        LogManager.d(TAG, "📍 坐标点击: ($x, $y)")
        
        try {
            service.performClick(x, y)
            
            if (config.postVerify) {
                delay(config.verificationDelayMs)
            }
            
            recordAction("CLICK_AT", "($x, $y)", true)
            return ActionResult(
                success = true,
                action = "CLICK_AT",
                executionTime = System.currentTimeMillis() - startTime
            )
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 坐标点击失败: ${e.message}")
            recordAction("CLICK_AT", "($x, $y)", false)
            return ActionResult(
                success = false,
                action = "CLICK_AT",
                errorMessage = e.message
            )
        }
    }
    
    // ==================== 📜 滑动操作 ====================
    
    /**
     * 📜 智能滑动
     */
    suspend fun smartScroll(
        rootNode: AccessibilityNodeInfo?,
        direction: ScrollDirection,
        targetId: String? = null,
        distance: Float? = null,
        config: ActionConfig = ActionConfig()
    ): ActionResult {
        val startTime = System.currentTimeMillis()
        LogManager.d(TAG, "📜 智能滑动: direction=$direction, targetId=$targetId")
        
        for (attempt in 0 until config.retryCount) {
            try {
                // 如果指定了目标，尝试在目标元素上滑动
                if (targetId != null && rootNode != null) {
                    val targetIdInt = targetId.toIntOrNull()
                    val targetNode = if (targetIdInt != null) CoreScreenAnalyzer.findNodeById(rootNode, targetIdInt) else null
                    if (targetNode != null && targetNode.isScrollable) {
                        val action = when (direction) {
                            ScrollDirection.DOWN -> AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                            ScrollDirection.UP -> AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                            ScrollDirection.LEFT -> AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                            ScrollDirection.RIGHT -> AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                        }
                        
                        if (targetNode.performAction(action)) {
                            delay(config.verificationDelayMs)
                            recordAction("SCROLL", direction.name, true)
                            return ActionResult(
                                success = true,
                                action = "SCROLL",
                                retryCount = attempt,
                                executionTime = System.currentTimeMillis() - startTime
                            )
                        }
                    }
                }
                
                // 使用手势滑动
                val scrollParams = calculateScrollParams(direction, distance)
                service.performScroll(
                    scrollParams.startX,
                    scrollParams.startY,
                    scrollParams.endX,
                    scrollParams.endY
                )
                
                delay(config.verificationDelayMs)
                recordAction("SCROLL", direction.name, true)
                
                return ActionResult(
                    success = true,
                    action = "SCROLL",
                    retryCount = attempt,
                    executionTime = System.currentTimeMillis() - startTime
                )
                
            } catch (e: Exception) {
                LogManager.e(TAG, "❌ 滑动失败: ${e.message}")
                if (attempt < config.retryCount - 1) {
                    delay(config.retryDelayMs)
                }
            }
        }
        
        recordAction("SCROLL", direction.name, false)
        return ActionResult(
            success = false,
            action = "SCROLL",
            errorMessage = "滑动失败"
        )
    }
    
    /**
     * 🔄 滑动查找元素
     */
    suspend fun scrollToFindElement(
        rootNode: AccessibilityNodeInfo?,
        targetText: String,
        direction: ScrollDirection = ScrollDirection.DOWN,
        maxScrolls: Int = 10
    ): ActionResult {
        val startTime = System.currentTimeMillis()
        LogManager.d(TAG, "🔄 滑动查找: targetText=$targetText, maxScrolls=$maxScrolls")
        
        for (scrollCount in 0 until maxScrolls) {
            // 检查当前屏幕是否有目标元素
            val currentRoot = service.rootInActiveWindow
            if (currentRoot != null) {
                val found = findTargetNode(currentRoot, null, targetText)
                if (found != null) {
                    LogManager.d(TAG, "✅ 找到目标元素，滑动了 $scrollCount 次")
                    return ActionResult(
                        success = true,
                        action = "SCROLL_TO_FIND",
                        retryCount = scrollCount,
                        executionTime = System.currentTimeMillis() - startTime
                    )
                }
            }
            
            // 滑动
            val scrollResult = smartScroll(rootNode, direction)
            if (!scrollResult.success) {
                return ActionResult(
                    success = false,
                    action = "SCROLL_TO_FIND",
                    errorMessage = "滑动失败"
                )
            }
            
            delay(300) // 等待内容加载
        }
        
        return ActionResult(
            success = false,
            action = "SCROLL_TO_FIND",
            errorMessage = "滑动 $maxScrolls 次后仍未找到: $targetText"
        )
    }
    
    // ==================== ⌨️ 输入操作 ====================
    
    /**
     * ⌨️ 智能输入
     */
    suspend fun smartInput(
        rootNode: AccessibilityNodeInfo?,
        targetId: String?,
        text: String,
        clearFirst: Boolean = true,
        config: ActionConfig = ActionConfig()
    ): ActionResult {
        val startTime = System.currentTimeMillis()
        LogManager.d(TAG, "⌨️ 智能输入: targetId=$targetId, text=${text.take(20)}...")
        
        for (attempt in 0 until config.retryCount) {
            try {
                val targetNode = if (targetId != null && rootNode != null) {
                    val targetIdInt = targetId.toIntOrNull()
                    if (targetIdInt != null) CoreScreenAnalyzer.findNodeById(rootNode, targetIdInt) else null
                } else {
                    // 查找当前焦点的输入框
                    findFocusedEditText(rootNode)
                }
                
                if (targetNode == null) {
                    LogManager.w(TAG, "⚠️ 未找到输入框")
                    if (attempt < config.retryCount - 1) {
                        delay(config.retryDelayMs)
                    }
                    continue
                }
                
                // 确保获得焦点
                if (!targetNode.isFocused) {
                    targetNode.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                    delay(100)
                }
                
                // 清空现有内容
                if (clearFirst) {
                    val selectAllArgs = android.os.Bundle()
                    selectAllArgs.putInt(
                        AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0
                    )
                    selectAllArgs.putInt(
                        AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT,
                        targetNode.text?.length ?: 0
                    )
                    targetNode.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, selectAllArgs)
                }
                
                // 输入文本
                val inputArgs = android.os.Bundle()
                inputArgs.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
                val inputSuccess = targetNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, inputArgs)
                
                if (inputSuccess) {
                    delay(config.verificationDelayMs)
                    
                    // 验证输入
                    if (config.postVerify) {
                        val currentText = targetNode.text?.toString() ?: ""
                        if (currentText.contains(text) || text.contains(currentText)) {
                            recordAction("INPUT", targetId, true)
                            return ActionResult(
                                success = true,
                                action = "INPUT",
                                retryCount = attempt,
                                executionTime = System.currentTimeMillis() - startTime,
                                verificationResult = VerificationResult(
                                    verified = true,
                                    method = VerificationMethod.CONTENT_CHANGE,
                                    details = "输入成功: $currentText"
                                )
                            )
                        }
                    } else {
                        recordAction("INPUT", targetId, true)
                        return ActionResult(
                            success = true,
                            action = "INPUT",
                            retryCount = attempt,
                            executionTime = System.currentTimeMillis() - startTime
                        )
                    }
                }
                
                LogManager.w(TAG, "⚠️ 第${attempt + 1}次输入尝试失败")
                delay(config.retryDelayMs)
                
            } catch (e: Exception) {
                LogManager.e(TAG, "❌ 输入异常: ${e.message}")
            }
        }
        
        recordAction("INPUT", targetId, false)
        return ActionResult(
            success = false,
            action = "INPUT",
            errorMessage = "输入失败"
        )
    }
    
    // ==================== 🔧 辅助方法 ====================
    
    /**
     * 🔍 查找目标节点
     */
    private fun findTargetNode(
        rootNode: AccessibilityNodeInfo?,
        targetId: String?,
        targetText: String?
    ): AccessibilityNodeInfo? {
        if (rootNode == null) return null
        
        // 优先通过ID查找
        if (targetId != null) {
            val targetIdInt = targetId.toIntOrNull()
            if (targetIdInt != null) {
                val byId = CoreScreenAnalyzer.findNodeById(rootNode, targetIdInt)
                if (byId != null) return byId
            }
        }
        
        // 通过文本查找
        if (targetText != null) {
            return findNodeByText(rootNode, targetText)
        }
        
        return null
    }
    
    /**
     * 🔍 通过文本查找节点
     */
    private fun findNodeByText(rootNode: AccessibilityNodeInfo, text: String): AccessibilityNodeInfo? {
        // 精确匹配
        val exactMatch = rootNode.findAccessibilityNodeInfosByText(text)
        if (exactMatch.isNotEmpty()) {
            return exactMatch.first()
        }
        
        // 递归查找
        return findNodeByTextRecursive(rootNode, text)
    }
    
    private fun findNodeByTextRecursive(node: AccessibilityNodeInfo, text: String): AccessibilityNodeInfo? {
        val nodeText = node.text?.toString() ?: ""
        val contentDesc = node.contentDescription?.toString() ?: ""
        
        if (nodeText.contains(text, ignoreCase = true) || 
            contentDesc.contains(text, ignoreCase = true)) {
            return node
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findNodeByTextRecursive(child, text)
            if (found != null) return found
        }
        
        return null
    }
    
    /**
     * 🔍 查找焦点输入框
     */
    private fun findFocusedEditText(rootNode: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (rootNode == null) return null
        
        val focused = rootNode.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (focused != null && focused.className?.toString()?.contains("EditText") == true) {
            return focused
        }
        
        // 递归查找 EditText
        return findEditTextRecursive(rootNode)
    }
    
    private fun findEditTextRecursive(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.className?.toString()?.contains("EditText") == true) {
            return node
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findEditTextRecursive(child)
            if (found != null) return found
        }
        
        return null
    }
    
    /**
     * ✅ 检查元素是否可点击
     */
    private fun isElementClickable(node: AccessibilityNodeInfo): Boolean {
        if (!node.isEnabled) return false
        if (!node.isVisibleToUser) return false
        
        // 检查是否可点击或可聚焦
        return node.isClickable || node.isFocusable
    }
    
    /**
     * 📍 计算最佳点击位置
     */
    private fun calculateBestClickPosition(node: AccessibilityNodeInfo): Pair<Float, Float> {
        val rect = Rect()
        node.getBoundsInScreen(rect)
        
        // 避免点击边缘，向内偏移一点
        val padding = 5
        val centerX = (rect.left + rect.right) / 2f
        val centerY = (rect.top + rect.bottom) / 2f
        
        // 确保在有效范围内
        val safeX = centerX.coerceIn(rect.left + padding.toFloat(), rect.right - padding.toFloat())
        val safeY = centerY.coerceIn(rect.top + padding.toFloat(), rect.bottom - padding.toFloat())
        
        return Pair(safeX, safeY)
    }
    
    /**
     * 🖱️ 执行点击
     */
    private fun performClick(node: AccessibilityNodeInfo, position: Pair<Float, Float>): Boolean {
        // 首先尝试 performAction
        if (node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            return true
        }
        
        // 回退到手势点击
        service.performClick(position.first, position.second)
        return true
    }
    
    /**
     * 📸 捕获节点状态
     */
    private fun captureNodeState(node: AccessibilityNodeInfo): Map<String, Any> {
        return mapOf(
            "text" to (node.text?.toString() ?: ""),
            "contentDescription" to (node.contentDescription?.toString() ?: ""),
            "isChecked" to node.isChecked,
            "isSelected" to node.isSelected,
            "isFocused" to node.isFocused
        )
    }
    
    /**
     * ✅ 验证点击结果
     */
    private fun verifyClickResult(
        node: AccessibilityNodeInfo,
        beforeState: Map<String, Any>?,
        method: VerificationMethod
    ): VerificationResult {
        if (beforeState == null) {
            return VerificationResult(verified = true, method = VerificationMethod.NONE)
        }
        
        return when (method) {
            VerificationMethod.ELEMENT_STATE_CHANGE -> {
                val currentState = captureNodeState(node)
                val changed = beforeState != currentState
                VerificationResult(
                    verified = changed,
                    method = method,
                    details = if (changed) "状态已变化" else "状态未变化"
                )
            }
            VerificationMethod.SCREEN_CHANGE -> {
                // 简单验证：假设点击成功
                VerificationResult(verified = true, method = method, details = "点击已执行")
            }
            else -> VerificationResult(verified = true, method = method)
        }
    }
    
    /**
     * 📏 计算滑动参数
     */
    private fun calculateScrollParams(
        direction: ScrollDirection,
        customDistance: Float? = null
    ): ScrollParams {
        val displayMetrics = service.resources.displayMetrics
        val width = displayMetrics.widthPixels
        val height = displayMetrics.heightPixels
        val centerX = width / 2f
        val centerY = height / 2f
        
        val distance = customDistance ?: (height * 0.3f)
        
        return when (direction) {
            ScrollDirection.DOWN -> ScrollParams(
                centerX, centerY + distance / 2,
                centerX, centerY - distance / 2
            )
            ScrollDirection.UP -> ScrollParams(
                centerX, centerY - distance / 2,
                centerX, centerY + distance / 2
            )
            ScrollDirection.LEFT -> ScrollParams(
                centerX - distance / 2, centerY,
                centerX + distance / 2, centerY
            )
            ScrollDirection.RIGHT -> ScrollParams(
                centerX + distance / 2, centerY,
                centerX - distance / 2, centerY
            )
        }
    }
    
    /**
     * 📝 记录操作
     */
    private fun recordAction(action: String, target: String?, success: Boolean) {
        val record = ActionRecord(
            timestamp = System.currentTimeMillis(),
            action = action,
            target = target,
            success = success
        )
        actionHistory.add(record)
        
        // 限制历史记录数量
        if (actionHistory.size > 100) {
            actionHistory.removeAt(0)
        }
    }
    
    /**
     * 📊 获取操作历史
     */
    fun getActionHistory(): List<ActionRecord> = actionHistory.toList()
    
    /**
     * 🧹 清理历史
     */
    fun clearHistory() {
        actionHistory.clear()
    }
}

/**
 * 📜 滑动方向
 */
enum class ScrollDirection {
    UP, DOWN, LEFT, RIGHT
}

/**
 * 📏 滑动参数
 */
data class ScrollParams(
    val startX: Float,
    val startY: Float,
    val endX: Float,
    val endY: Float
)
