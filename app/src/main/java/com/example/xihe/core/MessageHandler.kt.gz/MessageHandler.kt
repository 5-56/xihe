package com.example.xihe.core

import com.example.xihe.utils.LogManager
import com.example.xihe.core.model.ChatMessageDisplay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 💬 消息处理器
 * 
 * 从 AutomationEngine 中提取的消息管理模块
 * 负责聊天消息的增删改查和状态管理
 */
object MessageHandler {
    
    private const val TAG = "MessageHandler"
    private const val MAX_MESSAGES = 100  // 最大消息数量
    
    // 消息列表
    private val _messages = MutableStateFlow<List<ChatMessageDisplay>>(emptyList())
    val messages: StateFlow<List<ChatMessageDisplay>> = _messages.asStateFlow()
    
    // 当前会话ID
    private var _currentConversationId: String = java.util.UUID.randomUUID().toString()
    val currentConversationId: String get() = _currentConversationId
    
    // 时间格式化
    private val timeFormatter = SimpleDateFormat("HH:mm", Locale.getDefault())
    
    /**
     * 📝 添加用户消息
     */
    fun addUserMessage(content: String): ChatMessageDisplay {
        val message = ChatMessageDisplay(
            id = java.util.UUID.randomUUID().toString(),
            content = content,
            isUser = true,
            timestamp = System.currentTimeMillis()
        )
        addMessage(message)
        LogManager.d(TAG, "📤 用户消息: ${content.take(50)}...")
        return message
    }
    
    /**
     * 🤖 添加AI消息
     */
    fun addAIMessage(content: String): ChatMessageDisplay {
        val message = ChatMessageDisplay(
            id = java.util.UUID.randomUUID().toString(),
            content = content,
            isUser = false,
            timestamp = System.currentTimeMillis()
        )
        addMessage(message)
        LogManager.d(TAG, "📥 AI消息: ${content.take(50)}...")
        return message
    }
    
    /**
     * 添加思考中消息
     */
    fun addThinkingMessage(timestamp: Long): ChatMessageDisplay {
        val message = ChatMessageDisplay(
            id = "thinking_${System.currentTimeMillis()}",
            content = "思考中...",
            isUser = false,
            isThinking = true,
            timestamp = timestamp
        )
        addMessage(message)
        return message
    }
    
    /**
     * 更新消息内容
     * 🔄 更新消息内容
     */
    fun updateMessage(messageId: String, newContent: String) {
        val currentList = _messages.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == messageId }
        
        if (index != -1) {
            currentList[index] = currentList[index].copy(
                content = newContent,
                isThinking = false
            )
            _messages.value = currentList
        }
    }
    
    /**
     * ❌ 移除消息
     */
    fun removeMessage(messageId: String) {
        val currentList = _messages.value.toMutableList()
        currentList.removeAll { it.id == messageId }
        _messages.value = currentList
    }
    
    /**
     * 🗑️ 移除思考中消息
     */
    fun removeThinkingMessages() {
        val currentList = _messages.value.toMutableList()
        currentList.removeAll { it.isThinking }
        _messages.value = currentList
    }
    
    /**
     * ➕ 添加消息到列表
     */
    private fun addMessage(message: ChatMessageDisplay) {
        val currentList = _messages.value.toMutableList()
        currentList.add(message)
        
        // 限制最大消息数量
        while (currentList.size > MAX_MESSAGES) {
            currentList.removeAt(0)
        }
        
        _messages.value = currentList
    }
    
    /**
     * 🆕 开始新会话
     */
    fun startNewConversation() {
        _currentConversationId = java.util.UUID.randomUUID().toString()
        _messages.value = emptyList()
        LogManager.d(TAG, "🆕 新会话开始: $_currentConversationId")
    }
    
    /**
     * 🧹 清除所有消息
     */
    fun clearMessages() {
        _messages.value = emptyList()
        LogManager.d(TAG, "🧹 消息已清除")
    }
    
    /**
     * 📊 获取消息数量
     */
    fun getMessageCount(): Int = _messages.value.size
    
    /**
     * 🔍 获取最后N条消息
     */
    fun getLastMessages(count: Int): List<ChatMessageDisplay> {
        return _messages.value.takeLast(count)
    }
    
    /**
     * 📜 获取对话历史（用于LLM上下文）
     */
    fun getConversationHistory(maxMessages: Int = 10): List<Pair<String, String>> {
        return _messages.value
            .filter { !it.isThinking }
            .takeLast(maxMessages)
            .map { 
                if (it.isUser) "user" to it.content 
                else "assistant" to it.content 
            }
    }
    
    /**
     * 💾 导出消息为文本
     */
    fun exportAsText(): String {
        return _messages.value.joinToString("\n\n") { msg ->
            val role = if (msg.isUser) "用户" else "AI"
            "[$role ${msg.timestamp}]\n${msg.content}"
        }
    }
}
