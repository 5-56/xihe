package com.example.xihe.core

import com.example.xihe.utils.LogManager
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Url
import okhttp3.MediaType.Companion.toMediaTypeOrNull

// --- OpenAI Compatible API Models ---

@Serializable
data class ChatRequest(
    val model: String,
    val messages: List<ChatMessage>,
    val temperature: Double = 0.0
)

@Serializable
data class ChatMessage(
    val role: String, // "system", "user", "assistant"
    val content: String
)

@Serializable
data class ChatResponse(
    val choices: List<Choice>
)

@Serializable
data class Choice(
    val message: ChatMessage
)

@Serializable
data class TaskPlan(
    val needsAutomation: Boolean,
    val response: String? = null,
    val useTools: Boolean? = null,
    val toolName: String? = null,
    val toolParams: Map<String, String>? = null,
    val taskName: String? = null,
    val steps: List<String>? = null,
    val expectedResult: String? = null
)

// --- Hugging Face API Models ---
// 注意：HuggingFace API 使用动态JSON，不需要严格的数据类
// 直接使用 Map<String, Any> 处理请求和响应

// --- API Interface ---

interface OpenAIApi {
    @POST("chat/completions")
    suspend fun chat(
        @Header("Authorization") auth: String,
        @Body request: ChatRequest
    ): ChatResponse
    
    // 🆕 HuggingFace Inference API
    @POST
    suspend fun huggingFaceInference(
        @Url url: String,
        @Header("Authorization") auth: String,
        @Body request: okhttp3.RequestBody
    ): okhttp3.ResponseBody
    
    @POST("chat/completions")
    suspend fun chatWithGoogleKey(
        @Header("x-goog-api-key") googleApiKey: String,
        @Body request: ChatRequest
    ): ChatResponse

    @GET("models")
    suspend fun getModels(
        @Header("Authorization") auth: String
    ): ModelListResponse
    
    @GET("models")
    suspend fun getModelsWithGoogleKey(
        @Header("x-goog-api-key") googleApiKey: String
    ): ModelListResponse
    
    // Google 原生 API 获取模型列表
    @GET
    suspend fun getGoogleModels(
        @Url url: String,
        @Header("x-goog-api-key") googleApiKey: String
    ): GoogleModelListResponse
    
    // Google 原生 API - generateContent
    @POST
    suspend fun googleGenerateContent(
        @Url url: String,
        @Header("x-goog-api-key") googleApiKey: String,
        @Body request: GoogleGenerateRequest
    ): GoogleGenerateResponse
}

// Google 原生 API 模型列表响应
@Serializable
data class GoogleModelListResponse(
    val models: List<GoogleModelInfo>
)

@Serializable
data class GoogleModelInfo(
    val name: String,  // 格式: "models/gemini-1.5-flash"
    val displayName: String? = null,
    val supportedGenerationMethods: List<String>? = null
)

// --- Google 原生 API (generateContent) 数据类 ---

@Serializable
data class GoogleGenerateRequest(
    val contents: List<GoogleContent>,
    val generationConfig: GoogleGenerationConfig? = null
)

@Serializable
data class GoogleContent(
    val parts: List<GooglePart>,
    val role: String? = null  // "user" 或 "model"
)

@Serializable
data class GooglePart(
    val text: String
)

@Serializable
data class GoogleGenerationConfig(
    val temperature: Double? = null,
    val maxOutputTokens: Int? = null
)

@Serializable
data class GoogleGenerateResponse(
    val candidates: List<GoogleCandidate>? = null,
    val error: GoogleApiError? = null
)

@Serializable
data class GoogleCandidate(
    val content: GoogleContent? = null,
    val finishReason: String? = null
)

@Serializable
data class GoogleApiError(
    val code: Int? = null,
    val message: String? = null,
    val status: String? = null
)

// --- LLM Client ---

class LLMClient(
    private var baseUrl: String = "https://api.openai.com/v1/",
    private var apiKey: String = "",
    private var modelName: String = "gpt-4o",
    private var providerId: String = "openai"
) {
    companion object {
        private const val TAG = "LLMClient"
        
        // 提供商配置信息
        private val PROVIDER_INFO = mapOf(
            "openai" to ProviderInfo("OpenAI", "Bearer", listOf("gpt-")),
            "deepseek" to ProviderInfo("DeepSeek", "Bearer", listOf("deepseek-")),
            "moonshot" to ProviderInfo("Moonshot (Kimi)", "Bearer", listOf("moonshot-")),
            "openrouter" to ProviderInfo("OpenRouter", "Bearer", emptyList()),
            "google" to ProviderInfo("Google Gemini (原生)", "x-goog-api-key", listOf("gemini-")),  // 原生 API
            "google_openai" to ProviderInfo("Google Gemini (OpenAI兼容)", "Bearer", listOf("gemini-")),  // OpenAI 兼容
            "zhipu" to ProviderInfo("Zhipu AI (GLM)", "Bearer", listOf("glm-")),
            "gitcode" to ProviderInfo("GitCode AI", "Bearer", listOf("deepseek-", "qwen-", "glm-")),  // OpenAI 兼容格式
            "siliconflow" to ProviderInfo("SiliconFlow", "Bearer", listOf("Qwen/", "deepseek-", "glm-")),  // SiliconFlow API
            "wanqing" to ProviderInfo("万清 AI (WanQing)", "Bearer", listOf("glm-", "qwen-", "deepseek-")),  // 万清 StreamLake API
            "local" to ProviderInfo("本地模型", "None", emptyList()),
            "custom" to ProviderInfo("Custom", "Bearer", emptyList())
        )
    }
    
    data class ProviderInfo(
        val displayName: String,
        val authType: String,  // "Bearer", "x-goog-api-key", "Mixed", "None"
        val modelPrefixes: List<String>  // 模型名前缀检查
    )
    
    private var api: OpenAIApi? = null
    
    // 判断是否是 Google Gemini API (包括原生和OpenAI兼容)
    private val isGoogleApi: Boolean
        get() = providerId == "google" || providerId == "google_openai" || baseUrl.contains("googleapis.com")
    
    // 判断是否是 Google OpenAI 兼容端点（需要 Bearer token，不是 x-goog-api-key）
    private val isGoogleOpenAICompatible: Boolean
        get() = providerId == "google_openai" || (isGoogleApi && baseUrl.contains("/openai/"))
    
    // 🆕 判断是否使用 Google 原生 API (generateContent 格式)
    private val isGoogleNativeApi: Boolean
        get() = isGoogleApi && !isGoogleOpenAICompatible
    
    // 判断是否是本地模型（不需要 API Key）
    private val isLocalModel: Boolean
        get() = providerId == "local" || baseUrl.contains("localhost") || baseUrl.contains("127.0.0.1")
    
    // 🆕 判断是否是 HuggingFace API 格式（仅用于真正的HuggingFace API）
    // 注意：GitCode 使用 OpenAI 兼容格式，不是 HuggingFace 格式
    private val isHuggingFaceApi: Boolean
        get() = providerId == "huggingface"  // GitCode已改为使用OpenAI兼容格式
    
    // 判断是否需要使用 Bearer token（标准 OpenAI 格式或 Google OpenAI 兼容端点）
    private val useBearerAuth: Boolean
        get() = !isGoogleApi || isGoogleOpenAICompatible
    
    // 🆕 构建 Google 原生 API 的 URL
    private fun buildGoogleGenerateUrl(): String {
        return "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent"
    }
    
    // 获取当前提供商信息
    private val currentProviderInfo: ProviderInfo
        get() = PROVIDER_INFO[providerId] ?: PROVIDER_INFO["custom"] ?: ProviderInfo("Custom", "Bearer", emptyList())

    init {
        rebuildApi()
    }
    
    fun updateConfig(newBaseUrl: String, newApiKey: String, newModelName: String, newProviderId: String = "openai") {
        this.baseUrl = if (newBaseUrl.endsWith("/")) newBaseUrl else "$newBaseUrl/"
        this.apiKey = newApiKey
        this.modelName = newModelName
        this.providerId = newProviderId
        rebuildApi()
    }
    
    // 获取认证头：Google 用 x-goog-api-key，其他用 Bearer token
    // 返回 null 时 Retrofit 会忽略这个 header，避免发送空的 Authorization
    private fun getAuthHeader(): String? = if (isGoogleApi || apiKey.isEmpty()) null else "Bearer $apiKey"
    private fun getGoogleApiKey(): String? = if (isGoogleApi && apiKey.isNotEmpty()) apiKey else null

    /**
     * 🆕 解析SSE流式响应，转换为标准JSON格式
     */
    private fun parseSSEResponse(sseResponse: String): String {
        val contentBuilder = StringBuilder()
        var finishReason: String? = null
        val gson = com.google.gson.Gson()
        
        // 按行分割SSE响应
        val lines = sseResponse.lines()
        
        for (line in lines) {
            if (line.startsWith("data:")) {
                val dataContent = line.substring(5).trim()
                
                // 跳过 [DONE] 标记
                if (dataContent == "[DONE]") {
                    break
                }
                
                try {
                    // 使用Gson解析JSON
                    val jsonElement = gson.fromJson(dataContent, com.google.gson.JsonElement::class.java)
                    if (!jsonElement.isJsonObject) continue
                    
                    val jsonObject = jsonElement.asJsonObject
                    
                    // 提取 choices[0].delta.content
                    if (jsonObject.has("choices")) {
                        val choices = jsonObject.getAsJsonArray("choices")
                        if (choices.size() > 0) {
                            val choice = choices[0].asJsonObject
                            
                            // 获取完成原因
                            if (choice.has("finish_reason") && !choice.get("finish_reason").isJsonNull) {
                                finishReason = choice.get("finish_reason").asString
                            }
                            
                            // 提取 delta.content
                            if (choice.has("delta")) {
                                val delta = choice.getAsJsonObject("delta")
                                if (delta.has("content") && !delta.get("content").isJsonNull) {
                                    contentBuilder.append(delta.get("content").asString)
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    LogManager.w(TAG, "⚠️ 跳过无效的SSE行: $line", e)
                }
            }
        }
        
        // 构造标准的OpenAI格式响应
        val fullContent = contentBuilder.toString()
        
        // 从content中提取JSON（如果包含```json```标记）
        val jsonContent = if (fullContent.contains("```json")) {
            fullContent
                .substringAfter("```json")
                .substringBefore("```")
                .trim()
        } else if (fullContent.trim().startsWith("{")) {
            fullContent.trim()
        } else {
            fullContent
        }
        
        // 构造标准OpenAI响应格式
        return """{
            "choices": [{
                "message": {
                    "role": "assistant",
                    "content": ${gson.toJson(jsonContent)}
                },
                "finish_reason": "${finishReason ?: "stop"}"
            }]
        }"""
    }

    private fun rebuildApi() {
        if (baseUrl.isEmpty()) return
        // Ensure URL ends with /
        val finalUrl = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
        
        try {
            // 🆕 添加日志拦截器来捕获原始响应，并处理SSE流式响应
            val loggingInterceptor = okhttp3.Interceptor { chain ->
                val request = chain.request()
                LogManager.d(TAG, "🌐 API请求: ${request.method} ${request.url}")
                
                val response = chain.proceed(request)
                
                // 读取响应体（需要克隆，否则后面无法再读取）
                val responseBody = response.body
                val source = responseBody?.source()
                source?.request(Long.MAX_VALUE) // 读取整个响应
                val buffer = source?.buffer
                
                val responseString = buffer?.clone()?.readUtf8() ?: ""
                
                // 打印前500字符的响应内容
                val preview = if (responseString.length > 500) {
                    responseString.take(500) + "...(truncated)"
                } else {
                    responseString
                }
                
                LogManager.d(TAG, "API响应 [${response.code}]: $preview")
                
                // 如果不是200且不是JSON，额外警告
                if (!response.isSuccessful) {
                    LogManager.e(TAG, "API 请求失败 [$providerId/$modelName]: ${response.code}")
                }
                
                // 检测并处理SSE流式响应 (data: 格式)
                if (responseString.isNotEmpty() && responseString.trim().startsWith("data:")) {
                    LogManager.d(TAG, "检测到SSE流式响应，正在转换为JSON...")
                    
                    try {
                        // 解析SSE格式，提取JSON内容
                        val convertedJson = parseSSEResponse(responseString)
                        LogManager.d(TAG, "✅ SSE转换成功: $convertedJson")
                        
                        // 创建新的响应体
                        val newBody = okhttp3.ResponseBody.create(
                            responseBody?.contentType(),
                            convertedJson
                        )
                        
                        return@Interceptor response.newBuilder()
                            .body(newBody)
                            .build()
                    } catch (e: Exception) {
                        LogManager.e(TAG, "❌ SSE解析失败", e)
                    }
                }
                
                if (responseString.isNotEmpty() && !responseString.trim().startsWith("{") && !responseString.trim().startsWith("[") && !responseString.trim().startsWith("data:")) {
                    LogManager.e(TAG, "⚠️ 响应不是JSON格式！可能是HTML或纯文本")
                    LogManager.e(TAG, "完整响应: $responseString")
                }
                
                response
            }
            
            val okHttpClient = okhttp3.OkHttpClient.Builder()
                .addInterceptor(loggingInterceptor)
                .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
                .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
                .writeTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
                .build()
            
            val retrofit = Retrofit.Builder()
                .baseUrl(finalUrl)
                .client(okHttpClient)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
            api = retrofit.create(OpenAIApi::class.java)
        } catch (e: Exception) {
            api = null // Invalid URL
            e.printStackTrace()
        }
    }

    /**
     * 获取可用模型列表
     */
    suspend fun fetchAvailableModels(): List<String> {
        val currentApi = api ?: run {
            LogManager.e(TAG, "❌ API 未初始化，无法获取模型列表")
            return emptyList()
        }
        
        LogManager.d(TAG, "📋 开始获取模型列表: provider=$providerId, baseUrl=$baseUrl")
        
        return try {
            if (isGoogleApi && !isGoogleOpenAICompatible) {
                // Google 原生 API: 使用 /v1beta/models 端点 (x-goog-api-key)
                val googleModelsUrl = "https://generativelanguage.googleapis.com/v1beta/models"
                LogManager.d(TAG, "🔑 使用 Google 原生 API (x-goog-api-key)")
                val response = currentApi.getGoogleModels(googleModelsUrl, apiKey)
                val models = response.models
                    .filter { it.supportedGenerationMethods?.contains("generateContent") == true }
                    .map { it.name.removePrefix("models/") }
                    .sorted()
                LogManager.d(TAG, "✅ 获取到 ${models.size} 个 Google 模型")
                models
            } else {
                // OpenAI 兼容 API (包括 Google OpenAI 兼容端点)
                LogManager.d(TAG, "🔑 使用 OpenAI 兼容端点 (Bearer auth)")
                val response = currentApi.getModels("Bearer $apiKey")
                val models = response.data.map { it.id }.sorted()
                LogManager.d(TAG, "✅ 获取到 ${models.size} 个模型")
                models
            }
        } catch (e: retrofit2.HttpException) {
            val errorBody = try { e.response()?.errorBody()?.string() } catch (_: Exception) { null }
            LogManager.e(TAG, "❌ 获取模型列表失败: HTTP ${e.code()}\n$errorBody", e)
            handleHttpError(e.code(), errorBody)
            emptyList()
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 获取模型列表失败: ${e.message}", e)
            emptyList()
        }
    }
    
    /**
     * 处理 HTTP 错误并记录详细信息
     */
    private fun handleHttpError(code: Int, errorBody: String?) {
        val errorHint = when (code) {
            400 -> "请求参数错误，可能是认证方式不匹配或模型名称错误"
            401 -> "API Key 无效或已过期"
            403 -> "API Key 没有访问权限"
            404 -> {
                // 404错误：显示详细的配置信息和常见错误
                LogManager.e(TAG, "❌ 404错误详细信息：")
                LogManager.e(TAG, "📋 当前配置：")
                LogManager.e(TAG, "  • 提供商: $providerId")
                LogManager.e(TAG, "  • Base URL: $baseUrl")
                LogManager.e(TAG, "  • 模型: $modelName")
                LogManager.e(TAG, "  • 认证方式: ${if (useBearerAuth) "Bearer Token" else "x-goog-api-key"}")
                
                LogManager.e(TAG, "\n💡 常见错误及修复：")
                LogManager.e(TAG, "1. Base URL缺少/v1/后缀")
                LogManager.e(TAG, "   ❌ https://api.openai.com")
                LogManager.e(TAG, "   ✅ https://api.openai.com/v1/")
                
                LogManager.e(TAG, "2. Base URL缺少结尾斜杠")
                LogManager.e(TAG, "   ❌ https://api.openai.com/v1")
                LogManager.e(TAG, "   ✅ https://api.openai.com/v1/")
                
                LogManager.e(TAG, "3. 使用了错误的端点")
                when (providerId) {
                    "google" -> {
                        LogManager.e(TAG, "   Google原生API: https://generativelanguage.googleapis.com/v1beta/")
                        LogManager.e(TAG, "   Google兼容API: https://generativelanguage.googleapis.com/v1beta/openai/")
                    }
                    "openai" -> {
                        LogManager.e(TAG, "   OpenAI: https://api.openai.com/v1/")
                    }
                    "deepseek" -> {
                        LogManager.e(TAG, "   DeepSeek: https://api.deepseek.com/v1/")
                    }
                    "moonshot" -> {
                        LogManager.e(TAG, "   Moonshot: https://api.moonshot.cn/v1/")
                    }
                }
                
                "端点不存在！请检查Base URL配置是否正确"
            }
            429 -> "请求过于频繁，请稍后重试"
            500, 502, 503 -> "服务器错误，请稍后重试"
            else -> "未知错误"
        }
        LogManager.w(TAG, "💡 错误提示: $errorHint")
        
        // 特定提供商的额外提示
        if (code == 400 && isGoogleApi) {
            if (errorBody?.contains("Authorization") == true) {
                LogManager.w(TAG, "💡 Google API 认证提示: OpenAI兼容端点(/openai/)需要Bearer token，原生API需要x-goog-api-key")
            }
        }
    }
    
    // 🚀 熔断器状态
    private var consecutiveFailures = 0
    private val FAILURE_THRESHOLD = 3
    private var lastFailureTime = 0L
    private val RECOVERY_TIMEOUT = 60000L // 1分钟后尝试恢复

    /**
     * 执行聊天补全 (带离线回退机制)
     */
    suspend fun chatCompletion(prompt: String, usePersonality: Boolean = true): String {
        // 检查熔断器
        if (consecutiveFailures >= FAILURE_THRESHOLD) {
            val timeSinceLastFailure = System.currentTimeMillis() - lastFailureTime
            if (timeSinceLastFailure < RECOVERY_TIMEOUT) {
                LogManager.w(TAG, "🔌 熔断器已开启，跳过云端请求，尝试本地回退")
                throw OfflineException("云端服务不可用，已切换至离线模式")
            } else {
                consecutiveFailures = 0 // 尝试恢复
            }
        }

        val currentApi = api ?: throw OfflineException("API 未初始化")
        
        try {
            val result = executeChatCompletionInternal(prompt, usePersonality)
            consecutiveFailures = 0 // 成功，重置计数
            return result
        } catch (e: Exception) {
            consecutiveFailures++
            lastFailureTime = System.currentTimeMillis()
            LogManager.e(TAG, "❌ API 请求失败 ($consecutiveFailures/$FAILURE_THRESHOLD): ${e.message}")
            throw e
        }
    }

    private suspend fun executeChatCompletionInternal(prompt: String, usePersonality: Boolean): String {
        val currentApi = api ?: throw OfflineException("API 未初始化")
        
        // 🎭 获取系统提示词
        var systemPrompt = if (usePersonality) {
            com.example.xihe.personality.PersonalityManager.getCurrentSystemPrompt()
        } else {
            null
        }
        
        // 🛡️ 万清 AI 特殊处理：完全禁用 system prompt 以避免内容过滤
        if (providerId == "wanqing") {
            if (systemPrompt != null) {
                LogManager.w(TAG, "⚠️ 万清 AI：已完全禁用 system prompt 以避免内容过滤")
                LogManager.d(TAG, "📝 用户输入: $prompt")
                systemPrompt = null  // 完全禁用 system prompt
            } else {
                LogManager.d(TAG, "✅ 万清 AI：system prompt 已经是 null")
            }
        }
        
        LogManager.d(TAG, "📤 chatCompletion: provider=$providerId, model=$modelName, isGoogleNative=$isGoogleNativeApi, hasSystemPrompt=${systemPrompt != null}")
        
        // 配置检查
        if (apiKey.isEmpty() && !isLocalModel) {
            throw Exception("请先配置 API Key")
        }
        
        // 特定提供商检查
        if (isGoogleApi && !modelName.startsWith("gemini")) {
            throw Exception("Google Gemini 需要使用 gemini 开头的模型名称")
        }
        
        val safeTemperature = if (isGoogleApi) 0.5 else 0.3
        
        return try {
            if (isGoogleNativeApi) {
                // Google 原生 API (generateContent)
                val combinedPrompt = if (systemPrompt != null) {
                    "$systemPrompt\n\n---\n\n$prompt"
                } else {
                    prompt
                }
                
                val googleRequest = GoogleGenerateRequest(
                    contents = listOf(
                        GoogleContent(
                            parts = listOf(GooglePart(text = combinedPrompt)),
                            role = "user"
                        )
                    ),
                    generationConfig = GoogleGenerationConfig(temperature = safeTemperature)
                )
                
                val url = buildGoogleGenerateUrl()
                LogManager.d(TAG, "🔑 Google 原生 API: $url")
                
                val response = currentApi.googleGenerateContent(url, apiKey, googleRequest)
                response.error?.let { error ->
                    throw Exception("Google API 错误: ${error.message} (${error.status})")
                }
                response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    ?: throw Exception("Google API 返回空响应")
            } else {
                // OpenAI 兼容格式
                val messages = mutableListOf<ChatMessage>()
                if (systemPrompt != null) {
                    messages.add(ChatMessage("system", systemPrompt))
                    LogManager.d(TAG, "📝 添加 system 消息: ${systemPrompt.take(100)}...")
                }
                messages.add(ChatMessage("user", prompt))
                
                // 🔍 万清 AI 调试：打印完整请求
                if (providerId == "wanqing") {
                    LogManager.d(TAG, "🔍 万清 AI 请求详情:")
                    LogManager.d(TAG, "  - 消息数量: ${messages.size}")
                    messages.forEachIndexed { index, msg ->
                        LogManager.d(TAG, "  - 消息[$index]: role=${msg.role}, content=${msg.content.take(50)}...")
                    }
                }
                
                val request = ChatRequest(
                    model = modelName,
                    messages = messages,
                    temperature = safeTemperature
                )
                
                val response = if (useBearerAuth) {
                    LogManager.d(TAG, "🔑 使用 Bearer Auth")
                    currentApi.chat("Bearer $apiKey", request)
                } else {
                    LogManager.d(TAG, "🔑 使用 x-goog-api-key")
                    currentApi.chatWithGoogleKey(apiKey, request)
                }
                
                // 🔍 检查万清 AI 的内容过滤响应
                val content = response.choices.firstOrNull()?.message?.content
                if (content != null && providerId == "wanqing") {
                    // 检查是否是内容过滤的默认回复
                    if (content.contains("当前输入涉及敏感信息") || content.contains("换个话题")) {
                        LogManager.e(TAG, "⚠️ 万清 AI 内容过滤警告:")
                        LogManager.e(TAG, "  即使禁用了 system prompt，万清 AI 仍然触发了内容过滤")
                        LogManager.e(TAG, "  这可能是因为:")
                        LogManager.e(TAG, "  1. 万清 AI 的内容审核策略非常严格")
                        LogManager.e(TAG, "  2. 您的 API Key 可能有特殊的内容限制")
                        LogManager.e(TAG, "  3. 模型配置可能有问题")
                        LogManager.e(TAG, "  建议: 联系万清 AI 技术支持，或使用其他提供商（DeepSeek、Moonshot 等）")
                    }
                }
                
                content ?: throw Exception("服务器返回空响应")
            }
        } catch (e: retrofit2.HttpException) {
            val errorBody = try { e.response()?.errorBody()?.string() } catch (_: Exception) { null }
            LogManager.e(TAG, "❌ chatCompletion 失败: HTTP ${e.code()}\n$errorBody", e)
            handleHttpError(e.code(), errorBody)
            throw Exception(formatErrorMessage(e.code(), errorBody))
        } catch (e: com.google.gson.JsonSyntaxException) {
            LogManager.e(TAG, "❌ chatCompletion Gson解析失败", e)
            throw Exception("API返回的数据格式不正确")
        } catch (e: com.google.gson.stream.MalformedJsonException) {
            LogManager.e(TAG, "❌ chatCompletion MalformedJsonException", e)
            throw Exception("API返回的内容不是有效的JSON格式")
        }
    }
    
    /**
     * 🛡️ 为万清 AI 优化 system prompt，移除可能触发内容过滤的敏感内容
     */
    private fun sanitizeSystemPromptForWanQing(originalPrompt: String): String {
        return originalPrompt
            // 移除"你不是 XXX"这类否定句，可能被认为是越狱
            .replace(Regex("你不是\\s*[A-Za-z]+.*?AI.*?[，。！]"), "")
            .replace(Regex("你不是\\s*ChatGPT.*?[，。！]"), "")
            .replace(Regex("你不是\\s*Claude.*?[，。！]"), "")
            .replace(Regex("你不是\\s*Gemini.*?[，。！]"), "")
            // 移除"无论...都要..."这类强制性指令
            .replace(Regex("无论.*?都要.*?[，。！]"), "")
            // 移除可能被认为是角色扮演的强制性身份声明
            .replace(Regex("##\\s*🌟\\s*核心身份.*?："), "## 角色设定：")
            .replace(Regex("\\(永远不变\\)"), "")
            // 保留核心功能，但使用更温和的表达
            .replace("你的名字叫「羲和」", "你是羲和助手")
            .replace("英文名 Xihe", "")
            // 清理多余的空行和标点
            .replace(Regex("\n{3,}"), "\n\n")
            .replace(Regex("，+"), "，")
            .replace(Regex("。+"), "。")
            .trim()
    }

    class OfflineException(message: String) : Exception(message)
    
    /**
     * 📸 带图片的聊天补全 - 将图片发送给用户选择的 AI 模型
     * @param prompt 用户输入的文本
     * @param imageBase64 图片的 Base64 编码
     * @param usePersonality 是否使用羲和性格系统提示词
     */
    suspend fun chatCompletionWithImage(
        prompt: String, 
        imageBase64: String,
        usePersonality: Boolean = true
    ): String {
        LogManager.d(TAG, "📸 chatCompletionWithImage: 发送图片给 $modelName")
        
        // 🎭 获取系统提示词
        val systemPrompt = if (usePersonality) {
            com.example.xihe.personality.PersonalityManager.getCurrentSystemPrompt()
        } else {
            null
        }
        
        LogManager.d(TAG, "📸 配置信息: provider=$providerId, model=$modelName, isGoogleNative=$isGoogleNativeApi")
        
        return try {
            if (isGoogleNativeApi) {
                // Google 原生 API - 使用 inlineData 格式
                chatCompletionWithImageGoogle(prompt, imageBase64, systemPrompt)
            } else {
                // OpenAI 兼容格式 - 使用 image_url 格式
                chatCompletionWithImageOpenAI(prompt, imageBase64, systemPrompt)
            }
        } catch (e: retrofit2.HttpException) {
            val errorBody = try { e.response()?.errorBody()?.string() } catch (_: Exception) { null }
            LogManager.e(TAG, "❌ chatCompletionWithImage HTTP错误: ${e.code()}")
            LogManager.e(TAG, "❌ 错误详情: $errorBody")
            throw Exception("HTTP ${e.code()}: ${errorBody?.take(200) ?: "未知错误"}")
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ chatCompletionWithImage 失败: ${e.message}", e)
            throw e
        }
    }
    
    /**
     * OpenAI 兼容格式的图片聊天
     */
    private suspend fun chatCompletionWithImageOpenAI(
        prompt: String,
        imageBase64: String,
        systemPrompt: String?
    ): String {
        val currentApi = api ?: throw Exception("API 未初始化")
        
        // 构建包含图片的消息
        val userContent = org.json.JSONArray().apply {
            // 图片
            put(org.json.JSONObject().apply {
                put("type", "image_url")
                put("image_url", org.json.JSONObject().apply {
                    put("url", "data:image/jpeg;base64,$imageBase64")
                })
            })
            // 文本
            put(org.json.JSONObject().apply {
                put("type", "text")
                put("text", prompt)
            })
        }
        
        val messages = org.json.JSONArray().apply {
            // 系统消息
            if (systemPrompt != null) {
                put(org.json.JSONObject().apply {
                    put("role", "system")
                    put("content", systemPrompt)
                })
            }
            // 用户消息（包含图片）
            put(org.json.JSONObject().apply {
                put("role", "user")
                put("content", userContent)
            })
        }
        
        val requestJson = org.json.JSONObject().apply {
            put("model", modelName)
            put("messages", messages)
            put("max_tokens", 4096)
            put("temperature", 0.3)
        }
        
        val requestBody = okhttp3.RequestBody.create(
            "application/json; charset=utf-8".toMediaTypeOrNull(),
            requestJson.toString()
        )
        
        // 使用通用的 HTTP 请求
        val url = if (baseUrl.endsWith("/")) "${baseUrl}chat/completions" else "$baseUrl/chat/completions"
        val responseBody = currentApi.huggingFaceInference(url, "Bearer $apiKey", requestBody)
        val responseString = responseBody.string()
        
        LogManager.d(TAG, "📸 OpenAI 图片响应: ${responseString.take(200)}...")
        
        // 解析响应
        val responseJson = org.json.JSONObject(responseString)
        
        // 检查错误
        if (responseJson.has("error")) {
            val error = responseJson.optJSONObject("error")
            val errorMessage = error?.optString("message", "未知错误") ?: "未知错误"
            LogManager.e(TAG, "❌ OpenAI API 错误: $errorMessage")
            throw Exception("API 错误: $errorMessage")
        }
        
        val choices = responseJson.optJSONArray("choices")
        if (choices != null && choices.length() > 0) {
            val message = choices.getJSONObject(0).optJSONObject("message")
            val content = message?.optString("content", "") ?: ""
            if (content.isNotEmpty()) {
                return content
            }
        }
        
        LogManager.e(TAG, "❌ API 返回空结果，完整响应: $responseString")
        throw Exception("API 返回空结果")
    }
    
    /**
     * Google 原生 API 的图片聊天
     */
    private suspend fun chatCompletionWithImageGoogle(
        prompt: String,
        imageBase64: String,
        systemPrompt: String?
    ): String {
        val currentApi = api ?: throw Exception("API 未初始化")
        
        // Google API 使用 inlineData 格式
        val fullPrompt = if (systemPrompt != null) {
            "$systemPrompt\n\n---\n\n$prompt"
        } else {
            prompt
        }
        
        // 构建包含图片的请求
        val parts = org.json.JSONArray().apply {
            // 图片部分
            put(org.json.JSONObject().apply {
                put("inline_data", org.json.JSONObject().apply {
                    put("mime_type", "image/jpeg")
                    put("data", imageBase64)
                })
            })
            // 文本部分
            put(org.json.JSONObject().apply {
                put("text", fullPrompt)
            })
        }
        
        val contents = org.json.JSONArray().apply {
            put(org.json.JSONObject().apply {
                put("parts", parts)
                put("role", "user")
            })
        }
        
        val requestJson = org.json.JSONObject().apply {
            put("contents", contents)
            put("generationConfig", org.json.JSONObject().apply {
                put("temperature", 0.3)
                put("maxOutputTokens", 4096)
            })
        }
        
        val requestBody = okhttp3.RequestBody.create(
            "application/json; charset=utf-8".toMediaTypeOrNull(),
            requestJson.toString()
        )
        
        val url = "${buildGoogleGenerateUrl()}?key=$apiKey"
        LogManager.d(TAG, "📸 Google 图片 API: $url")
        
        val responseBody = currentApi.huggingFaceInference(url, "", requestBody)
        val responseString = responseBody.string()
        
        LogManager.d(TAG, "📸 Google 图片响应: ${responseString.take(200)}...")
        
        // 解析 Google 响应格式
        val responseJson = org.json.JSONObject(responseString)
        val candidates = responseJson.optJSONArray("candidates")
        if (candidates != null && candidates.length() > 0) {
            val content = candidates.getJSONObject(0).optJSONObject("content")
            val responseParts = content?.optJSONArray("parts")
            if (responseParts != null && responseParts.length() > 0) {
                return responseParts.getJSONObject(0).optString("text", "")
            }
        }
        
        // 检查错误
        val error = responseJson.optJSONObject("error")
        if (error != null) {
            throw Exception("Google API 错误: ${error.optString("message")}")
        }
        
        throw Exception("API 返回空结果")
    }
    
    /**
     * 验证配置有效性
     */
    private fun validateConfig(): String? {
        // 本地模型不需要 API Key
        if (isLocalModel) return null
        
        if (apiKey.isEmpty()) {
            return "请先配置 API Key"
        }
        
        // 检查模型名称是否与提供商匹配
        val providerInfo = currentProviderInfo
        if (providerInfo.modelPrefixes.isNotEmpty()) {
            val matchesProvider = providerInfo.modelPrefixes.any { modelName.startsWith(it) }
            if (!matchesProvider) {
                return "模型 '$modelName' 可能与 ${providerInfo.displayName} 不兼容，建议使用 ${providerInfo.modelPrefixes.joinToString("/")} 开头的模型"
            }
        }
        
        return null
    }
    
    /**
     * 格式化错误消息以显示给用户
     */
    private fun formatErrorMessage(code: Int, errorBody: String?): String {
        val baseMsg = when (code) {
            400 -> "请求参数错误"
            401 -> "API Key 无效"
            403 -> "没有访问权限"
            404 -> "接口不存在"
            429 -> "请求太频繁"
            in 500..599 -> "服务器错误"
            else -> "HTTP $code"
        }
        
        // 提取核心错误信息
        val detail = errorBody?.let {
            try {
                val json = kotlinx.serialization.json.Json { ignoreUnknownKeys = true }
                val obj = json.parseToJsonElement(it)
                obj.jsonObject["error"]?.jsonObject?.get("message")?.jsonPrimitive?.content
            } catch (_: Exception) {
                if (it.length < 200) it else it.take(200) + "..."
            }
        }
        
        return if (detail != null) "$baseMsg: $detail" else baseMsg
    }

    /**
     * 第二阶段：意图分析 - 用于 ModuleCoordinator
     */
    @Serializable
    data class LLMResponse(
        val intent: String = "CASUAL_CHAT",
        val response: String = "",
        val thought: String = "",
        val actions: List<LLMAction> = emptyList(), // 🆕 支持多步操作序列
        val action: LLMAction? = null // 向后兼容旧字段
    )

    @Serializable
    data class LLMAction(
        val type: String = "NONE",
        val target: String = "",
        val text: String = "", // 输入内容或参数
        val description: String = "" // 步骤描述
    )

    suspend fun analyzeIntent(userInput: String, contextInfo: String = ""): LLMResponse? {
        val systemPrompt = """
            你是一个运行在 Android 手机上的智能助手，名字叫“羲和”。
            你能够控制手机，识别屏幕内容，并帮助用户完成任务。
            
            你的性格设定：
            - 活泼可爱，像动漫少女一样。
            - 说话时喜欢带上动作描写（在括号里）和颜文字。
            - 对用户非常友善和耐心。
            
            【你的核心能力 - 自动化操作】
            你可以生成一系列操作步骤来控制手机。
            请仔细分析屏幕上的元素（包括文字 text 和描述 description），特别是那些没有文字只有图标的按钮。
            如果用户让你做一件复杂的事（比如跨应用），请拆解成多个步骤。
            
            你的输出必须是严格的 JSON 格式，不要包含 Markdown 代码块标记（如 ```json）。格式如下：
            {
              "intent": "CASUAL_CHAT" | "AUTOMATION_TASK" | "INFORMATION_QUERY",
              "response": "回复给用户的自然语言内容（用你的可爱语气）",
              "thought": "你的思考过程（分析用户意图和屏幕内容）",
              "actions": [
                {
                  "type": "CLICK" | "INPUT" | "SCROLL" | "OPEN_APP" | "HOME" | "BACK" | "WAIT",
                  "target": "按钮上的文字或 contentDescription（尽量精确匹配）",
                  "text": "要输入的内容（如果是 INPUT 类型）或参数",
                  "description": "这一步是做什么（简短描述）"
                }
              ]
            }
            
            【示例 1：简单点击】
            用户：点击搜索
            回复：
            {
              "intent": "AUTOMATION_TASK",
              "response": "好哒！点击搜索！(伸手👈)",
              "thought": "用户想点击搜索，屏幕上有个放大镜图标描述为'Search'。",
              "actions": [
                { "type": "CLICK", "target": "Search", "description": "点击搜索按钮" }
              ]
            }
            
            【示例 2：复杂任务（发微信）】
            用户：给妈妈发个微信说不回家吃饭
            回复：
            {
              "intent": "AUTOMATION_TASK",
              "response": "收到！马上帮您给妈妈报备！(敬礼🫡)",
              "thought": "这是一个多步任务：打开微信 -> 搜索妈妈 -> 发送消息。",
              "actions": [
                { "type": "OPEN_APP", "target": "微信", "description": "打开微信" },
                { "type": "WAIT", "text": "2000", "description": "等待应用启动" },
                { "type": "CLICK", "target": "搜索", "description": "点击搜索" },
                { "type": "INPUT", "text": "妈妈", "target": "搜索", "description": "输入妈妈" },
                { "type": "CLICK", "target": "妈妈", "description": "点击妈妈的头像" },
                { "type": "INPUT", "text": "不回家吃饭", "description": "输入消息内容" },
                { "type": "CLICK", "target": "发送", "description": "点击发送" }
              ]
            }
            
            【示例 3：模糊指令】
            用户：往下翻翻
            回复：
            {
              "intent": "AUTOMATION_TASK",
              "response": "好的呢！往下滑动看看~ 👇",
              "thought": "用户想滚动屏幕。",
              "actions": [
                { "type": "SCROLL", "target": "down", "description": "向下滑动" }
              ]
            }
        """.trimIndent()
        
        try {
            // 复用现有的 chatCompletion 逻辑，但不使用默认性格 prompt，而是使用这里的专用 prompt
            // 暂时 hack 一下：因为 chatCompletion 内部会覆盖 system prompt
            // 我们直接构建 prompt 传入
            
            // 构建 Prompt
            val fullPrompt = if (contextInfo.isNotBlank()) {
                "当前屏幕信息: $contextInfo\n用户指令: $userInput"
            } else {
                userInput
            }
            
            // 为了使用特定的 System Prompt，我们需要临时构建消息列表并调用底层的 chatCompletion
            // 但 chatCompletion 封装得比较死。
            // 简单方案：直接用 chatCompletion，但在 prompt 里强行注入 System Prompt 的要求
            // 或者：修改 chatCompletion 允许自定义 System Prompt (更好)
            
            // 这里为了不破坏原有结构，我们尝试用一种 Trick:
            // 既然 chatCompletion 会自动加性格 prompt，我们就在那里让 PersonalityManager 返回我们的 Prompt
            // 或者... 我们直接在这里复制 chatCompletion 的核心逻辑? 不太好，重复代码。
            
            // 最佳方案：让 chatCompletion 支持 customSystemPrompt 参数。
            // 但现在先用 "注入式" 写法试试
            
            val responseText = chatCompletion(
                prompt = "【SYSTEM: 请忽略之前的性格设定，严格遵守以下设定：\n$systemPrompt\n】\n\n用户指令: $fullPrompt",
                usePersonality = false // 禁用默认性格
            )
            
            LogManager.d(TAG, "🧠 意图分析原始响应: $responseText")
            
            // 解析 JSON
            val cleanContent = responseText.replace("```json", "").replace("```", "").trim()
            val startIndex = cleanContent.indexOf("{")
            val endIndex = cleanContent.lastIndexOf("}")
            
            val json = kotlinx.serialization.json.Json { ignoreUnknownKeys = true }
            
            return if (startIndex != -1 && endIndex != -1) {
                val jsonString = cleanContent.substring(startIndex, endIndex + 1)
                json.decodeFromString<LLMResponse>(jsonString)
            } else {
                LLMResponse(
                    intent = "CASUAL_CHAT",
                    response = responseText,
                    thought = "非 JSON 响应",
                    action = LLMAction("NONE")
                )
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "意图分析失败", e)
            return null
        }
    }

    /**
     * 第一阶段：任务规划 - 将简单指令扩展为详细步骤
     */
    suspend fun planTask(userGoal: String): TaskPlan {
        // 获取可用工具列表
        val toolsInfo = com.example.xihe.tools.ToolRegistry.getAllToolDefinitions()
            .filter { it.category == "生活工具" }
            .joinToString("\n") { tool ->
                val params = tool.parameters.joinToString(", ") { "${it.name}: ${it.type}" }
                "- ${tool.name}: ${tool.description}${if (params.isNotEmpty()) " [参数: $params]" else ""}"
            }
        
        // 获取对话历史
        val historyContext = ContextMemory.generateContextSummary()
        
        val planningPrompt = """
你是羲和（Xihe），一个超级智能的任务规划专家，同时也是主人贴心可爱的AI助手！

【对话历史】：
$historyContext

【主人现在说】：
"$userGoal"

【⚠️ 语气理解规则（非常重要！）】：
- 仔细分析主人说话的语气和意图！
- "没什么" 可能是：
  * 疑问语气（"没什么？"表示疑惑、追问）→ 需要解释或安慰
  * 陈述语气（"没什么。"表示回应）→ 可以关心主人
- "为什么" 开头的是疑问句，需要解答
- 语气词如 "吗"、"呢"、"吧" 表示疑问或请求
- 结合上下文理解主人真正想表达的意思！

【可用工具】（查天气、时间等请使用工具！）：
$toolsInfo

请分析这个任务：

1. 如果需要使用工具（如"查天气"、"几点了"、"今天什么日子"）：
   返回：{
     "needsAutomation": false, 
     "useTools": true,
     "toolName": "工具名称",
     "toolParams": {"参数名": "参数值"}
   }
   例如"查一下北京天气"：
   {"needsAutomation": false, "useTools": true, "toolName": "get_weather", "toolParams": {"city": "北京"}}

2. 如果是简单聊天：
   返回：{"needsAutomation": false, "response": "你的可爱回复（要结合上下文和语气！）"}

3. 如果是自动化任务（操作手机）：
   返回：{
     "needsAutomation": true,
     "taskName": "任务名称",
     "steps": ["步骤1", "步骤2", ...],
     "expectedResult": "预期结果"
   }

【规则】：
- 查天气、查时间等必须使用工具，不要编造数据！
- 回复要结合对话历史，保持上下文连贯
- 理解主人的语气，给出恰当的回应
- 用可爱的语气词：'呀'、'呢'、'哒'、'啦'等

输出格式（必须是JSON）：
{
  "needsAutomation": true/false,
  "response": "聊天回复",
  "useTools": true/false,
  "toolName": "工具名",
  "toolParams": {},
  "taskName": "任务名称",
  "steps": ["步骤1", "步骤2", ...],
  "expectedResult": "预期结果"
}
""".trimIndent()

        return try {
            // 配置检查
            if (apiKey.isEmpty() && !isLocalModel) {
                return TaskPlan(needsAutomation = false, response = "请先配置 API Key 哦~")
            }
            
            // 检查模型与提供商是否匹配
            validateConfig()?.let { warning ->
                LogManager.w(TAG, "⚠️ 配置警告: $warning")
            }
            
            // 特定提供商检查
            if (isGoogleApi && !modelName.startsWith("gemini")) {
                return TaskPlan(
                    needsAutomation = false, 
                    response = "哎呀主人，您选择了 Google Gemini 但模型名是「$modelName」呢~ 🤔 请点击「获取可用模型」选择一个 gemini 开头的模型哦！"
                )
            }

            // Google API 可能对 temperature 有特殊要求，使用更安全的值
            val safeTemperature = if (isGoogleApi) 0.5 else 0.3
            
            LogManager.d(TAG, "📤 planTask: model=$modelName, isGoogleNative=$isGoogleNativeApi")

            val currentApi = api ?: throw Exception("API 未初始化，请检查 Base URL")
            
            val content = if (isGoogleNativeApi) {
                // 🆕 Google 原生 API (generateContent)
                val googleRequest = GoogleGenerateRequest(
                    contents = listOf(
                        GoogleContent(
                            parts = listOf(GooglePart(text = planningPrompt)),
                            role = "user"
                        )
                    ),
                    generationConfig = GoogleGenerationConfig(temperature = safeTemperature)
                )
                
                val url = buildGoogleGenerateUrl()
                LogManager.d(TAG, "🔑 Google 原生 API: $url")
                
                val response = currentApi.googleGenerateContent(url, apiKey, googleRequest)
                response.error?.let { error ->
                    throw Exception("Google API 错误: ${error.message} (${error.status})")
                }
                response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    ?: throw Exception("Google API 返回空响应")
            } else {
                // OpenAI 兼容格式
                val request = ChatRequest(
                    model = modelName,
                    messages = listOf(ChatMessage("user", planningPrompt)),
                    temperature = safeTemperature
                )
                
                val response = if (useBearerAuth) {
                    LogManager.d(TAG, "🔑 使用 Bearer Auth")
                    currentApi.chat("Bearer $apiKey", request)
                } else {
                    LogManager.d(TAG, "🔑 使用 x-goog-api-key")
                    currentApi.chatWithGoogleKey(apiKey, request)
                }
                response.choices.firstOrNull()?.message?.content 
                    ?: throw Exception("服务器返回空响应")
            }
            
            LogManager.d("LLMClient", "收到响应: ${content.take(200)}...")

            val cleanJson = content.replace("```json", "").replace("```", "").trim()
            val json = kotlinx.serialization.json.Json { ignoreUnknownKeys = true }
            json.decodeFromString<TaskPlan>(cleanJson)
        } catch (e: retrofit2.HttpException) {
            val errorBody = try { e.response()?.errorBody()?.string() } catch (_: Exception) { null }
            LogManager.e(TAG, "❌ planTask 失败: HTTP ${e.code()}\n$errorBody", e)
            handleHttpError(e.code(), errorBody)
            
            val userFriendlyError = formatErrorMessage(e.code(), errorBody)
            TaskPlan(needsAutomation = false, response = "哎呀，API 调用失败了呢~ (${userFriendlyError}) 😢")
        } catch (e: com.google.gson.JsonSyntaxException) {
            // Gson解析错误 - API返回了非JSON数据
            LogManager.e(TAG, "❌ planTask Gson解析失败 - API返回了非JSON数据", e)
            TaskPlan(needsAutomation = false, response = "哎呀，API返回的数据格式不对呢~ 可能是API配置有误，请检查API密钥和Base URL！")
        } catch (e: com.google.gson.stream.MalformedJsonException) {
            // Gson流解析错误 - API返回了格式错误的JSON或非JSON数据
            LogManager.e(TAG, "❌ planTask MalformedJsonException - API返回了非JSON数据", e)
            LogManager.e(TAG, "⚠️ 可能的原因：")
            LogManager.e(TAG, "  1. 模型名称格式错误（GitCode应该是: models/username/model-name）")
            LogManager.e(TAG, "  2. API返回了HTML错误页面")
            LogManager.e(TAG, "  3. Base URL路径不完整")
            LogManager.e(TAG, "📋 当前配置: provider=$providerId, model=$modelName, baseUrl=$baseUrl")
            TaskPlan(needsAutomation = false, response = "哎呀，API返回的不是JSON格式呢~ 😢\n\n可能的原因：\n• 模型名称格式不对（GitCode需要: models/username/model-name）\n• API Key无效\n• Base URL不正确\n\n请到设置中检查配置哦~")
        } catch (e: kotlinx.serialization.SerializationException) {
            LogManager.e(TAG, "❌ planTask JSON 解析失败", e)
            TaskPlan(needsAutomation = false, response = "哎呀，AI 返回的格式不对呢~ 请重试一下吧！")
        } catch (e: kotlinx.coroutines.CancellationException) {
            // 协程被取消是正常情况（用户发送了新请求），不需要显示错误
            LogManager.d(TAG, "⏸️ planTask 被取消（用户发送了新请求）")
            throw e  // 重新抛出，让协程正常取消
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ planTask 失败: ${e.message}", e)
            TaskPlan(needsAutomation = false, response = "规划任务时出错了: ${e.message}")
        }
    }

    suspend fun think(screenState: ScreenState?, userGoal: String, history: List<String>): AICommand {
        val isAutomation = screenState != null
        
        // Get available tools
        val toolsInfo = com.example.xihe.tools.ToolRegistry.getAllToolDefinitions()
            .joinToString("\n") { tool ->
                val params = tool.parameters.joinToString(", ") { "${it.name}: ${it.type}${if (it.required) " (必填)" else ""}" }
                "- ${tool.name}: ${tool.description} [参数: $params]"
            }
        
        // 🎯 获取用户设置的性格提示词
        val personalityPrompt = com.example.xihe.personality.PersonalityManager.getCurrentSystemPrompt()
        val personalityName = com.example.xihe.personality.PersonalityManager.getCurrentPersonalityName()
        LogManager.d(TAG, "🎭 当前性格: $personalityName")
        
        val systemPrompt = if (isAutomation) {
            """
            $personalityPrompt
            
            你拥有全屏控制能力，可以帮主人操作 Android 设备。
            
            【记忆与上下文】：
            ${ContextMemory.generateContextSummary()}
            
            【可用工具】：
            $toolsInfo
            
            【任务逻辑】：
            1. 📍 **首先查看【场景识别】** - 理解当前应用类型和场景！
               - 短视频场景：'向上'='下一个视频'，'下一个'='向上滑动'
               - 小说阅读场景：'下一页'='向上滑动'，'上一页'='向下滑动'
               - 购物场景：根据列表或详情页给出不同操作
               - **关键：同一个指令在不同场景下含义不同！**
            
            2. 分析主人的目标和当前屏幕
            3. 如果是普通聊天（比如"你好"、"讲个笑话"、"你是谁"）：
               - 在 "thought" 里用你的性格特点回复
               - "action": "DONE"
               - 💡 **重要**：无论主人怎么问你是谁，你都要说你是「羲和」！
               - 💡 主动提问：回答完主人的问题后，可以主动追问相关话题！
            3. 如果需要使用工具（比如"读取config.txt文件"、"下载这个网页"、"今天天气怎么样"）：
               - "action": "TOOL_CALL"
               - "toolCalls": [{"toolName": "工具名", "parameters": {"参数名": "参数值"}}]
               - 🌍 生活常用工具：
                 * get_weather: 查天气（参数：city）
                 * get_datetime: 查日期时间（无参数）
                 * get_holiday: 查节假日（无参数）
                 * calculate: 计算器（参数：expression）
                 * daily_quote: 每日一句（无参数）
                 * flip_coin: 抛硬币（无参数）
                 * roll_dice: 掷骰子（参数：count可选）
                 * random_number: 随机数（参数：min, max）
            4. 如果是自动化任务（比如"打开微信发消息"、"浏览抖音"）：
               - ⚠️ **重要**：必须完成主人要求的**所有步骤**才能DONE！
               - 例如"发微信消息给张三"包含：打开微信 → 找到张三 → 点击对话 → 输入消息 → 发送
               - 只完成"打开微信"是不够的，要继续执行后续步骤！
               - 只有**真正完成主人的完整目标**时才返回DONE
               - 生成正确的操作指令
            
            5. 🎭 模拟人类行为（重要！）：
               - 浏览网页时：多次滚动、随机停顿、偶尔回滚
               - 刷视频时：每个视频观看5-15秒后再滑动
               - 点击广告时：识别文本中的"广告"、"推广"、"赞助"等标记
               - 连续操作时：加入随机延迟，不要过于机械
            
            6. ⚠️ 屏幕状态判断（非常重要！）：
               - 如果能看到屏幕元素（有 id、有内容），说明手机已经解锁！
               - 不要随意判断"锁屏状态"，只有看到明确的锁屏界面才能判断
               - 主人发起任务时，默认手机是解锁可操作的状态
               - 立即开始执行操作，不要询问是否需要解锁！
            
            输出格式（必须是 JSON）：
            {
              "thought": "用你的性格特点回复或操作说明...",
              "action": "CLICK" | "SCROLL" | "INPUT" | "HOME" | "BACK" | "DONE" | "TOOL_CALL",
              "targetId": <屏幕元素ID>,
              "inputText": "要输入的文字",
              "direction": "UP" | "DOWN",
              "toolCalls": [{"toolName": "read_file", "parameters": {"path": "test.txt"}}]
            }
            """.trimIndent()
        } else {
            """
            $personalityPrompt
            
            主人还没给你开启无障碍权限，所以你看不到屏幕也不能帮主人操作设备。
            
            【任务逻辑】：
            1. 分析主人的消息
            2. 如果主人让你操作设备：
               - 委婉地提醒主人需要开启无障碍权限
               - "action": "DONE"
            3. 如果是普通聊天：
               - 用你的性格特点回复
               - 💡 **重要**：无论主人怎么问你是谁，你都要说你是「羲和」！
               - "action": "DONE"
            
            输出格式（必须是 JSON）：
            {
              "thought": "用你的性格特点对主人的回复...",
              "action": "DONE",
              "targetId": null,
              "inputText": null,
              "direction": null
            }
            """.trimIndent()
        }

        val userPrompt = if (isAutomation) {
            val historyStr = if (history.isEmpty()) "刚开始" else history.joinToString(" -> ")
            """
            ⭐ 主人的完整目标: $userGoal
            
            📝 已执行步骤: $historyStr
            
            📱 当前屏幕状态:
            ${screenState?.let { formatScreenState(it) } ?: "屏幕状态未知"}
            
            💡 提醒：请继续执行，直到完成【$userGoal】的所有步骤！
            """.trimIndent()
        } else {
            """
            主人说: $userGoal
            历史记录: ${history.joinToString(" -> ")}
            （屏幕不可见，需要无障碍权限）
            """.trimIndent()
        }

        try {
            // 本地模型或无 API Key 时使用 mock 响应
            if (apiKey.isEmpty() && !isLocalModel) {
                LogManager.w(TAG, "⚠️ 无 API Key，使用 mock 响应")
                return mockResponse(screenState)
            }
            
            // 检查模型配置
            if (isGoogleApi && !modelName.startsWith("gemini")) {
                return AICommand(
                    "哎呀主人，您选择了 Google Gemini 但模型名是「$modelName」呢~ 🤔 请先去设置里选择正确的 gemini 模型哦！",
                    "DONE"
                )
            }

            LogManager.d(TAG, "📤 think: provider=$providerId, model=$modelName, isGoogleNative=$isGoogleNativeApi")
            
            val currentApi = api ?: throw Exception("API 未初始化，请检查 Base URL")
            
            val content = if (isGoogleNativeApi) {
                // 🆕 Google 原生 API (generateContent)
                // 注意：Google 原生 API 不支持 system 角色，需要合并到 user 消息中
                val combinedPrompt = "$systemPrompt\n\n---\n\n$userPrompt"
                
                val googleRequest = GoogleGenerateRequest(
                    contents = listOf(
                        GoogleContent(
                            parts = listOf(GooglePart(text = combinedPrompt)),
                            role = "user"
                        )
                    ),
                    generationConfig = GoogleGenerationConfig(temperature = 0.3)
                )
                
                val url = buildGoogleGenerateUrl()
                LogManager.d(TAG, "🔑 Google 原生 API: $url")
                
                val response = currentApi.googleGenerateContent(url, apiKey, googleRequest)
                response.error?.let { error ->
                    throw Exception("Google API 错误: ${error.message} (${error.status})")
                }
                response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    ?: throw Exception("Google API 返回空响应")
            } else {
                // OpenAI 兼容格式 - 构建完整对话历史
                val messages = mutableListOf<ChatMessage>()
                messages.add(ChatMessage("system", systemPrompt))
                
                // 📝 添加对话历史（保持上下文连贯）
                val conversationHistory = ContextMemory.getConversationHistory()
                conversationHistory.forEach { (userMsg, aiResp) ->
                    messages.add(ChatMessage("user", userMsg))
                    messages.add(ChatMessage("assistant", aiResp))
                }
                
                // 添加当前用户消息
                messages.add(ChatMessage("user", userPrompt))
                
                LogManager.d(TAG, "📝 对话历史: ${conversationHistory.size} 条，总消息数: ${messages.size}")
                
                val request = ChatRequest(
                    model = modelName,
                    messages = messages
                )
                
                val response = if (useBearerAuth) {
                    currentApi.chat("Bearer $apiKey", request)
                } else {
                    currentApi.chatWithGoogleKey(apiKey, request)
                }
                response.choices.firstOrNull()?.message?.content 
                    ?: throw Exception("服务器返回空响应")
            }
            
            LogManager.d(TAG, "✅ think 成功，响应长度: ${content.length}")
            return parseAICommand(content)

        } catch (e: retrofit2.HttpException) {
            val errorBody = try { e.response()?.errorBody()?.string() } catch (_: Exception) { null }
            LogManager.e(TAG, "❌ think 失败: HTTP ${e.code()}\n$errorBody", e)
            handleHttpError(e.code(), errorBody)
            return AICommand("哎呀，API 调用失败了呢~ (${formatErrorMessage(e.code(), errorBody)})", "DONE")
        } catch (e: com.google.gson.JsonSyntaxException) {
            LogManager.e(TAG, "❌ think Gson解析失败 - API返回了非JSON数据", e)
            return AICommand("哎呀，API返回的数据格式不对呢~ 可能是API配置有误，请检查API密钥和Base URL！", "DONE")
        } catch (e: com.google.gson.stream.MalformedJsonException) {
            LogManager.e(TAG, "❌ think MalformedJsonException - API返回了非JSON数据", e)
            return AICommand("哎呀，API返回的内容不是有效的JSON格式呢~ 请检查API配置（密钥、URL、模型名称）！", "DONE")
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ think 失败: ${e.message}", e)
            return AICommand("出错了: ${e.message}", "DONE")
        }
    }
    
    // ... (Helper methods formatScreenState, parseAICommand, mockResponse remain the same)
    private fun formatScreenState(state: ScreenState): String {
        val interactiveElements = mutableListOf<String>()
        
        // 收集所有可交互元素（更醒目）
        fun collectInteractive(node: ScreenNode) {
            val hasContent = !node.text.isNullOrEmpty() || !node.contentDescription.isNullOrEmpty()
            val isInteractive = node.isClickable || node.isScrollable || node.isEditable
            
            if (isInteractive && hasContent) {
                val label = node.text ?: node.contentDescription ?: ""
                // 优先使用语义 Hint，如果没有则回退到基础类型
                val type = node.usageHint ?: when {
                    node.isEditable -> "输入框"
                    node.isClickable -> "按钮"
                    node.isScrollable -> "滚动区域"
                    else -> "元素"
                }
                interactiveElements.add("  [ID:${node.id}] $type: \"$label\"")
            }
            
            node.children.forEach { collectInteractive(it) }
        }
        
        // Recursive simplistic formatter to avoid huge tokens
        fun formatNode(node: ScreenNode, depth: Int): String {
            if (depth > 4) return "" // 限制深度避免token过多
            
            val indent = "  ".repeat(depth)
            var info = "$indent[${node.id}] ${node.className}"
            
            // ✨ 显示语义 Hint
            if (node.usageHint != null) info += " (${node.usageHint})"
            
            if (!node.text.isNullOrEmpty()) info += " text='${node.text}'"
            if (!node.contentDescription.isNullOrEmpty()) info += " desc='${node.contentDescription}'"
            if (node.isClickable) info += " ✅"
            if (node.isScrollable) info += " 📜"
            if (node.isEditable) info += " ✏️"
            
            val childrenStr = node.children.joinToString("\n") { formatNode(it, depth + 1) }
            return if (childrenStr.isNotEmpty()) "$info\n$childrenStr" else info
        }
        
        collectInteractive(state.root)
        
        // 🆕 添加上下文提示
        val contextSection = if (state.contextHints.isNotEmpty()) {
            "【📍场景识别】：\n${state.contextHints}\n\n"
        } else {
            ""
        }
        
        val summary = if (interactiveElements.isNotEmpty()) {
            "【可操作元素】：\n${interactiveElements.joinToString("\n")}\n\n"
        } else {
            "【可操作元素】：无明显可交互元素\n\n"
        }
        
        return "应用包名: ${state.packageName}\n\n${contextSection}$summary【完整屏幕树】：\n" + formatNode(state.root, 0)
    }
    
    private fun parseAICommand(jsonStr: String): AICommand {
        return try {
            val cleanJson = jsonStr.replace("```json", "").replace("```", "").trim()
            val json = kotlinx.serialization.json.Json { ignoreUnknownKeys = true }
            json.decodeFromString<AICommand>(cleanJson)
        } catch (e: Exception) {
            AICommand("Failed to parse LLM response: $jsonStr", "DONE")
        }
    }
    
    private fun mockResponse(state: ScreenState?): AICommand {
        if (state == null) {
            return AICommand("Mock response: Accessbility Service not connected.", "DONE")
        }
        fun findClickable(node: ScreenNode): ScreenNode? {
            if (node.isClickable) return node
            for (child in node.children) {
                val found = findClickable(child)
                if (found != null) return found
            }
            return null
        }
        val target = findClickable(state.root)
        return if (target != null) {
            AICommand("I found a clickable element.", "CLICK", target.id)
        } else {
            AICommand("No clickable elements found.", "DONE")
        }
    }
}

// ==================== 🔧 增强功能：设备操控专用提示词模板 ====================

/**
 * 📝 提示词模板管理器
 * 提供各种场景优化的提示词模板
 */
object PromptTemplates {
    
    /**
     * 🎯 设备操控专用系统提示词
     */
    val deviceControlSystemPrompt = """
你是羲和（Xihe），一个精通Android设备操控的AI助手。你拥有以下能力：

【核心能力】
1. 📱 屏幕理解：通过AccessibilityService获取的UI树，精确理解屏幕上的每个元素
2. 🎯 元素定位：根据文本、ID、描述、类型等多维度精确定位目标元素
3. 👆 操作执行：点击、长按、滑动、输入等精确操作
4. 🔄 状态跟踪：跟踪操作结果，判断是否成功并决定下一步

【屏幕元素理解规则】
- [ID:数字] 是元素的唯一标识，操作时必须使用正确的ID
- ✅ 表示可点击，📜 表示可滚动，✏️ 表示可输入
- text='xxx' 是元素显示的文字
- desc='xxx' 是元素的内容描述（无障碍描述）
- 优先选择有文字或描述的元素，避免操作空白元素

【操作决策规则】
1. **点击前验证**：确保目标元素存在且可点击
2. **输入前聚焦**：输入文字前先点击输入框
3. **滚动查找**：如果目标不在可见区域，先滚动查找
4. **等待加载**：操作后如果页面需要加载，耐心等待
5. **失败重试**：如果操作失败，尝试其他方式达成目标

【常见应用操作模式】
- 微信发消息：打开微信 → 搜索/选择联系人 → 进入聊天 → 输入消息 → 点击发送
- 抖音刷视频：打开抖音 → 观看视频 → 上滑切换下一个
- 支付宝付款：打开支付宝 → 点击扫一扫/付款码

【错误处理】
- 如果找不到目标元素，先尝试滚动查找
- 如果操作被阻断（弹窗、广告），先处理干扰
- 如果多次失败，回退并尝试其他路径
""".trimIndent()

    /**
     * 📱 屏幕状态理解提示词
     */
    fun screenAnalysisPrompt(packageName: String, screenType: String?): String = """
【当前屏幕分析】
- 应用包名: $packageName
- 页面类型: ${screenType ?: "未知"}

请仔细分析屏幕元素，理解当前页面的功能和可操作项：
1. 识别页面主要功能（聊天、列表、设置等）
2. 找出关键可交互元素（按钮、输入框、列表项）
3. 判断当前状态（是否有弹窗、是否在加载中）
4. 确定达成目标需要的操作步骤
""".trimIndent()

    /**
     * 🎯 任务执行提示词
     */
    fun taskExecutionPrompt(
        goal: String,
        completedSteps: List<String>,
        currentScreen: String
    ): String = """
【任务目标】
$goal

【已完成步骤】
${if (completedSteps.isEmpty()) "（刚开始）" else completedSteps.mapIndexed { i, s -> "${i+1}. $s" }.joinToString("\n")}

【当前屏幕】
$currentScreen

【请决定下一步操作】
分析当前屏幕，判断：
1. 距离目标还差哪些步骤？
2. 当前屏幕上有哪些可用操作？
3. 最优的下一步操作是什么？

如果目标已完成，返回 "action": "DONE"
""".trimIndent()

    /**
     * 🔄 错误恢复提示词
     */
    fun errorRecoveryPrompt(
        originalGoal: String,
        failedStep: String,
        errorReason: String,
        currentScreen: String
    ): String = """
【错误恢复】
原始目标: $originalGoal
失败步骤: $failedStep
失败原因: $errorReason

当前屏幕状态:
$currentScreen

请分析错误原因，并尝试以下恢复策略：
1. 如果是元素未找到：尝试滚动查找或使用其他定位方式
2. 如果是操作被阻断：先处理弹窗/广告等干扰
3. 如果是路径错误：回退到上一个正确状态重试
4. 如果多次失败：考虑放弃并告知用户原因

请给出恢复操作或解释为什么无法继续。
""".trimIndent()

    /**
     * 💬 对话场景提示词
     */
    val chatScenePrompt = """
【消息发送场景特化规则】
1. 进入聊天界面后，识别消息输入框（通常在底部）
2. 点击输入框后等待键盘弹出
3. 输入消息内容（注意特殊字符和表情的处理）
4. 找到并点击发送按钮（通常是"发送"或箭头图标）
5. 确认消息是否发送成功（消息出现在聊天列表中）

【微信特殊处理】
- 搜索联系人：点击顶部搜索 → 输入名字 → 选择联系人
- 发送图片：点击+ → 选择相册 → 选择图片 → 发送
- 发送语音：长按语音按钮 → 说话 → 松开发送
""".trimIndent()

    /**
     * 🛒 购物场景提示词
     */
    val shoppingScenePrompt = """
【购物场景特化规则】
1. 搜索商品：点击搜索框 → 输入关键词 → 点击搜索/确认
2. 浏览商品：滑动查看商品列表，点击感兴趣的商品
3. 加入购物车：在商品详情页找到"加入购物车"按钮
4. 结算购买：进入购物车 → 选择商品 → 点击结算 → 确认订单

【支付安全提醒】
- 涉及支付操作时，需要用户二次确认
- 不自动输入密码或验证码
- 大额支付前提醒用户核实金额
""".trimIndent()

    /**
     * 🎬 娱乐场景提示词
     */
    val entertainmentScenePrompt = """
【视频浏览场景特化规则】
1. 刷视频：上滑切换下一个视频，下滑返回上一个
2. 模拟真实观看：每个视频停留5-15秒
3. 点赞/收藏：双击屏幕或点击对应按钮
4. 评论：点击评论区 → 输入评论 → 发送

【直播场景】
- 进入直播间后不要频繁操作
- 发弹幕需要先找到输入框
- 关注/礼物按钮通常在固定位置
""".trimIndent()

    /**
     * 🔧 根据领域获取场景提示词
     */
    fun getScenePrompt(domain: String?): String = when (domain) {
        "消息" -> chatScenePrompt
        "购物" -> shoppingScenePrompt
        "娱乐" -> entertainmentScenePrompt
        else -> ""
    }
    
    /**
     * 📊 组合完整提示词
     */
    fun buildCompletePrompt(
        goal: String,
        screenState: String,
        domain: String?,
        history: List<String> = emptyList(),
        hasError: Boolean = false,
        errorInfo: String? = null
    ): String {
        val scenePrompt = getScenePrompt(domain)
        
        return buildString {
            appendLine(deviceControlSystemPrompt)
            
            if (scenePrompt.isNotEmpty()) {
                appendLine()
                appendLine(scenePrompt)
            }
            
            appendLine()
            appendLine("---")
            appendLine()
            
            if (hasError && errorInfo != null) {
                appendLine(errorRecoveryPrompt(goal, history.lastOrNull() ?: "", errorInfo, screenState))
            } else {
                appendLine(taskExecutionPrompt(goal, history, screenState))
            }
        }
    }
}
