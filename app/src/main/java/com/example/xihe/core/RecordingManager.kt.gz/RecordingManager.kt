package com.example.xihe.core

import android.content.Context
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

/**
 * 录制管理器
 * 
 * 从 AutomationEngine 中提取的宏录制模块
 * 负责动作录制、保存和回放
 */
object RecordingManager {
    
    private const val TAG = "RecordingManager"
    private const val RECORDINGS_DIR = "recordings"
    
    // 录制状态
    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()
    
    // 当前录制的动作列表
    private val recordedActions = mutableListOf<RecordedAction>()
    
    // 当前录制名称
    private var recordingName: String? = null
    
    // 录制开始时间
    private var recordingStartTime: Long = 0L
    
    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }
    
    private var context: Context? = null
    
    /**
     * 初始化
     */
    fun init(ctx: Context) {
        context = ctx.applicationContext
        getRecordingsDir().mkdirs()
    }
    
    private fun getRecordingsDir(): File {
        return File(context?.filesDir, RECORDINGS_DIR)
    }
    
    /**
     * 开始录制
     */
    fun startRecording(name: String): Boolean {
        if (_isRecording.value) {
            LogManager.w(TAG, "已经在录制中")
            return false
        }
        
        recordingName = name
        recordedActions.clear()
        recordingStartTime = System.currentTimeMillis()
        _isRecording.value = true
        
        LogManager.d(TAG, "开始录制: $name")
        return true
    }
    
    /**
     * 停止录制
     */
    fun stopRecording(): Recording? {
        if (!_isRecording.value) {
            LogManager.w(TAG, "没有进行中的录制")
            return null
        }
        
        val name = recordingName ?: "未命名录制"
        val duration = System.currentTimeMillis() - recordingStartTime
        
        val recording = Recording(
            id = java.util.UUID.randomUUID().toString(),
            name = name,
            actions = recordedActions.toList(),
            createdAt = recordingStartTime,
            duration = duration
        )
        
        // 保存录制
        saveRecording(recording)
        
        // 重置状态
        _isRecording.value = false
        recordingName = null
        recordedActions.clear()
        
        LogManager.d(TAG, "录制完成: $name, ${recording.actions.size}个动作, 耗时${duration/1000}秒")
        return recording
    }
    
    /**
     * 取消录制
     */
    fun cancelRecording() {
        if (!_isRecording.value) return
        
        _isRecording.value = false
        recordingName = null
        recordedActions.clear()
        
        LogManager.d(TAG, "录制已取消")
    }
    
    /**
     * 记录动作
     */
    fun recordAction(action: RecordedAction) {
        if (!_isRecording.value) return
        
        val actionWithTimestamp = action.copy(
            timestamp = System.currentTimeMillis() - recordingStartTime
        )
        recordedActions.add(actionWithTimestamp)
        
        LogManager.d(TAG, "记录动作: ${action.type} at ${actionWithTimestamp.timestamp}ms")
    }
    
    /**
     * 记录点击动作
     */
    fun recordTap(x: Float, y: Float, elementText: String? = null) {
        recordAction(RecordedAction(
            type = com.example.xihe.core.ActionType.CLICK,
            x = x,
            y = y,
            text = elementText
        ))
    }
    
    /**
     * 记录滑动动作
     */
    fun recordSwipe(startX: Float, startY: Float, endX: Float, endY: Float, duration: Long) {
        recordAction(RecordedAction(
            type = ActionType.SWIPE,
            x = startX,
            y = startY,
            endX = endX,
            endY = endY,
            duration = duration
        ))
    }
    
    /**
     * 记录文本输入
     */
    fun recordTextInput(text: String) {
        recordAction(RecordedAction(
            type = com.example.xihe.core.ActionType.INPUT,
            text = text
        ))
    }
    
    /**
     * 记录等待
     */
    fun recordWait(duration: Long) {
        recordAction(RecordedAction(
            type = ActionType.WAIT,
            duration = duration
        ))
    }
    
    /**
     * 保存录制
     */
    private fun saveRecording(recording: Recording) {
        try {
            val file = File(getRecordingsDir(), "${recording.id}.json")
            file.writeText(json.encodeToString(recording))
            LogManager.d(TAG, "录制已保存: ${file.absolutePath}")
        } catch (e: Exception) {
            LogManager.e(TAG, "保存录制失败: ${e.message}", e)
        }
    }
    
    /**
     * 加载录制
     */
    fun loadRecording(id: String): Recording? {
        return try {
            val file = File(getRecordingsDir(), "$id.json")
            if (file.exists()) {
                json.decodeFromString<Recording>(file.readText())
            } else null
        } catch (e: Exception) {
            LogManager.e(TAG, "加载录制失败: ${e.message}", e)
            null
        }
    }
    
    /**
     * 获取所有录制
     */
    fun getAllRecordings(): List<Recording> {
        val recordings = mutableListOf<Recording>()
        
        getRecordingsDir().listFiles { file -> file.extension == "json" }?.forEach { file ->
            try {
                val recording = json.decodeFromString<Recording>(file.readText())
                recordings.add(recording)
            } catch (e: Exception) {
                LogManager.w(TAG, "跳过无效录制: ${file.name}")
            }
        }
        
        return recordings.sortedByDescending { it.createdAt }
    }
    
    /**
     * 删除录制
     */
    fun deleteRecording(id: String): Boolean {
        return try {
            val file = File(getRecordingsDir(), "$id.json")
            file.delete()
        } catch (e: Exception) {
            LogManager.e(TAG, "删除录制失败: ${e.message}", e)
            false
        }
    }
    
    /**
     * 获取录制统计
     */
    fun getStats(): RecordingStats {
        val recordings = getAllRecordings()
        return RecordingStats(
            totalCount = recordings.size,
            totalDuration = recordings.sumOf { it.duration },
            totalActions = recordings.sumOf { it.actions.size }
        )
    }
}

/**
 * 🎬 录制数据类
 */
@Serializable
data class Recording(
    val id: String,
    val name: String,
    val actions: List<RecordedAction>,
    val createdAt: Long,
    val duration: Long,
    val description: String = ""
)

/**
 * 📝 录制的动作
 */
@Serializable
data class RecordedAction(
    val type: com.example.xihe.core.ActionType,
    val x: Float = 0f,
    val y: Float = 0f,
    val endX: Float = 0f,
    val endY: Float = 0f,
    val text: String? = null,
    val duration: Long = 0L,
    val timestamp: Long = 0L
)

/**
 * 📊 录制统计
 */
data class RecordingStats(
    val totalCount: Int,
    val totalDuration: Long,
    val totalActions: Int
)
