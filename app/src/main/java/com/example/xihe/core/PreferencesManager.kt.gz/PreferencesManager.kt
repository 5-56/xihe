package com.example.xihe.core

import android.content.Context
import android.content.SharedPreferences
import com.example.xihe.core.model.ChatMessageDisplay
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import com.example.xihe.utils.ApiKeyHelper
import com.example.xihe.utils.LogManager

/**
 * 🗄️ 数据持久化管理器
 * 负责保存和读取API配置、历史记录等数据
 */
object PreferencesManager {
    private const val PREF_NAME = "xihe_preferences"
    private const val KEY_API_BASE_URL = "api_base_url"
    private const val KEY_API_KEY = "api_key"
    private const val KEY_MODEL_NAME = "model_name"
    private const val KEY_PROVIDER_ID = "provider_id"
    private const val KEY_CHAT_HISTORY = "chat_history"
    private const val KEY_USER_NAME = "user_name"
    private const val KEY_FIRST_LAUNCH = "first_launch"

    private val json = Json {
        ignoreUnknownKeys = true
        prettyPrint = true
    }

    private fun getPreferences(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    }

    private fun normalizeProviderId(providerId: String): String {
        return providerId.trim().lowercase().ifBlank { "openai" }
    }

    private fun saveProviderApiKey(context: Context, providerId: String, apiKey: String) {
        val normalizedProviderId = normalizeProviderId(providerId)
        if (apiKey.isBlank()) {
            ApiKeyHelper.clearApiKey(context, normalizedProviderId)
        } else {
            ApiKeyHelper.saveApiKey(context, normalizedProviderId, apiKey)
        }
    }

    private fun getProviderApiKey(context: Context, providerId: String): String {
        val normalizedProviderId = normalizeProviderId(providerId)
        val prefs = getPreferences(context)
        val secureApiKey = ApiKeyHelper.getApiKey(context, normalizedProviderId)
        if (secureApiKey.isNotBlank()) {
            return secureApiKey
        }

        val legacyProviderKeyName = normalizedProviderId + "_api_key"
        val legacyProviderApiKey = prefs.getString(legacyProviderKeyName, "") ?: ""
        val legacyGlobalApiKey = if (normalizedProviderId == "openai") {
            prefs.getString(KEY_API_KEY, "") ?: ""
        } else {
            ""
        }
        val migratedApiKey = legacyProviderApiKey.ifBlank { legacyGlobalApiKey }
        if (migratedApiKey.isNotBlank()) {
            ApiKeyHelper.saveApiKey(context, normalizedProviderId, migratedApiKey)
            prefs.edit().apply {
                if (legacyProviderApiKey.isNotBlank()) remove(legacyProviderKeyName)
                if (legacyGlobalApiKey.isNotBlank()) remove(KEY_API_KEY)
                apply()
            }
        }
        return migratedApiKey
    }

    // ==================== API 配置 ====================

    /**
     * 🆕 保存指定提供商的配置（独立存储）
     */
    fun saveProviderConfig(context: Context, providerId: String, baseUrl: String, apiKey: String, modelName: String) {
        val normalizedProviderId = normalizeProviderId(providerId)
        getPreferences(context).edit().apply {
            putString(normalizedProviderId + "_base_url", baseUrl)
            putString(normalizedProviderId + "_model_name", modelName)
            remove(normalizedProviderId + "_api_key")
            apply()
        }
        saveProviderApiKey(context, normalizedProviderId, apiKey)
        LogManager.d("PreferencesManager", "💾 已保存提供商配置: $normalizedProviderId")
    }

    /**
     * 🆕 读取指定提供商的配置（独立读取）
     */
    fun getProviderConfig(context: Context, providerId: String): ProviderApiConfig? {
        val normalizedProviderId = normalizeProviderId(providerId)
        val prefs = getPreferences(context)
        val baseUrl = prefs.getString(normalizedProviderId + "_base_url", null)
        val modelName = prefs.getString(normalizedProviderId + "_model_name", null)
        val apiKey = getProviderApiKey(context, normalizedProviderId)

        return if (baseUrl != null || modelName != null || apiKey.isNotBlank()) {
            ProviderApiConfig(
                baseUrl = baseUrl ?: "",
                apiKey = apiKey,
                modelName = modelName ?: ""
            )
        } else {
            null
        }
    }

    /**
     * 保存当前使用的提供商ID
     */
    fun saveCurrentProviderId(context: Context, providerId: String) {
        val normalizedProviderId = normalizeProviderId(providerId)
        getPreferences(context).edit().apply {
            putString(KEY_PROVIDER_ID, normalizedProviderId)
            apply()
        }
    }

    /**
     * 获取当前使用的提供商ID
     */
    fun getCurrentProviderId(context: Context): String {
        return normalizeProviderId(getPreferences(context).getString(KEY_PROVIDER_ID, "openai") ?: "openai")
    }

    fun currentProviderIdFlow(context: Context): Flow<String> {
        val prefs = getPreferences(context)
        return callbackFlow {
            val listener = SharedPreferences.OnSharedPreferenceChangeListener { sharedPreferences, key ->
                if (key == KEY_PROVIDER_ID) {
                    trySend(normalizeProviderId(sharedPreferences.getString(KEY_PROVIDER_ID, "openai") ?: "openai"))
                }
            }
            trySend(normalizeProviderId(prefs.getString(KEY_PROVIDER_ID, "openai") ?: "openai"))
            prefs.registerOnSharedPreferenceChangeListener(listener)
            awaitClose { prefs.unregisterOnSharedPreferenceChangeListener(listener) }
        }.distinctUntilChanged()
    }

    /**
     * 保存 API 配置（兼容旧版本）
     */
    fun saveApiConfig(context: Context, baseUrl: String, apiKey: String, modelName: String, providerId: String = "openai") {
        val normalizedProviderId = normalizeProviderId(providerId)
        saveProviderConfig(context, normalizedProviderId, baseUrl, apiKey, modelName)
        saveCurrentProviderId(context, normalizedProviderId)

        getPreferences(context).edit().apply {
            putString(KEY_API_BASE_URL, baseUrl)
            remove(KEY_API_KEY)
            putString(KEY_MODEL_NAME, modelName)
            putString(KEY_PROVIDER_ID, normalizedProviderId)
            apply()
        }
    }

    /**
     * 读取 API 配置
     */
    fun getApiConfig(context: Context): ApiConfig {
        val prefs = getPreferences(context)
        val providerId = normalizeProviderId(prefs.getString(KEY_PROVIDER_ID, "openai") ?: "openai")
        val providerConfig = getProviderConfig(context, providerId)

        val baseUrl = providerConfig?.baseUrl?.takeIf { it.isNotBlank() }
            ?: (prefs.getString(KEY_API_BASE_URL, "") ?: "")
        val modelName = providerConfig?.modelName?.takeIf { it.isNotBlank() }
            ?: (prefs.getString(KEY_MODEL_NAME, "gpt-4o") ?: "gpt-4o")
        val apiKey = providerConfig?.apiKey?.takeIf { it.isNotBlank() }
            ?: getProviderApiKey(context, providerId)

        return ApiConfig(
            baseUrl = baseUrl,
            apiKey = apiKey,
            modelName = modelName,
            providerId = providerId
        )
    }

    /**
     * 检查 API 是否已配置
     */
    fun isApiConfigured(context: Context): Boolean {
        val config = getApiConfig(context)
        return config.baseUrl.isNotEmpty() && config.apiKey.isNotEmpty()
    }

    // ==================== 聊天历史 ====================

    /**
     * 保存聊天历史
     */
    fun saveChatHistory(context: Context, messages: List<ChatMessageDisplay>) {
        try {
            val jsonString = json.encodeToString(messages)
            getPreferences(context).edit().apply {
                putString(KEY_CHAT_HISTORY, jsonString)
                apply()
            }
        } catch (e: Exception) {
            LogManager.e("PreferencesManager", "保存聊天历史失败", e)
        }
    }

    /**
     * 读取聊天历史
     */
    fun getChatHistory(context: Context): List<ChatMessageDisplay> {
        return try {
            val jsonString = getPreferences(context).getString(KEY_CHAT_HISTORY, null)
            if (jsonString.isNullOrEmpty()) {
                emptyList()
            } else {
                json.decodeFromString<List<ChatMessageDisplay>>(jsonString)
            }
        } catch (e: Exception) {
            LogManager.e("PreferencesManager", "读取聊天历史失败", e)
            emptyList()
        }
    }

    /**
     * 清空聊天历史
     */
    fun clearChatHistory(context: Context) {
        getPreferences(context).edit().apply {
            remove(KEY_CHAT_HISTORY)
            apply()
        }
    }

    // ==================== 用户设置 ====================

    /**
     * 保存用户名称
     */
    fun saveUserName(context: Context, name: String) {
        getPreferences(context).edit().apply {
            putString(KEY_USER_NAME, name)
            apply()
        }
    }

    /**
     * 读取用户名称
     */
    fun getUserName(context: Context): String {
        return getPreferences(context).getString(KEY_USER_NAME, "主人") ?: "主人"
    }

    /**
     * 是否首次启动
     */
    fun isFirstLaunch(context: Context): Boolean {
        val isFirst = getPreferences(context).getBoolean(KEY_FIRST_LAUNCH, true)
        if (isFirst) {
            getPreferences(context).edit().apply {
                putBoolean(KEY_FIRST_LAUNCH, false)
                apply()
            }
        }
        return isFirst
    }

    /**
     * 保存布尔值
     */
    fun setBoolean(context: Context, key: String, value: Boolean) {
        getPreferences(context).edit().apply {
            putBoolean(key, value)
            apply()
        }
    }

    /**
     * 读取布尔值
     */
    fun getBoolean(context: Context, key: String, defaultValue: Boolean = false): Boolean {
        return getPreferences(context).getBoolean(key, defaultValue)
    }

    /**
     * 保存字符串
     */
    fun setString(context: Context, key: String, value: String) {
        getPreferences(context).edit().apply {
            putString(key, value)
            apply()
        }
    }

    /**
     * 读取字符串
     */
    fun getString(context: Context, key: String, defaultValue: String = ""): String {
        return getPreferences(context).getString(key, defaultValue) ?: defaultValue
    }

    /**
     * 保存整数
     */
    fun setInt(context: Context, key: String, value: Int) {
        getPreferences(context).edit().apply {
            putInt(key, value)
            apply()
        }
    }

    /**
     * 读取整数
     */
    fun getInt(context: Context, key: String, defaultValue: Int = 0): Int {
        return getPreferences(context).getInt(key, defaultValue)
    }

    // ==================== 数据导出/导入 ====================

    /**
     * 导出所有数据
     */
    fun exportAllData(context: Context): String {
        val config = getApiConfig(context)
        val history = getChatHistory(context)
        val userName = getUserName(context)

        val exportData = ExportData(
            apiConfig = config,
            chatHistory = history,
            userName = userName,
            exportTime = System.currentTimeMillis()
        )

        return json.encodeToString(exportData)
    }

    /**
     * 导入所有数据
     */
    fun importAllData(context: Context, jsonString: String): Boolean {
        return try {
            val data = json.decodeFromString<ExportData>(jsonString)

            saveApiConfig(context, data.apiConfig.baseUrl, data.apiConfig.apiKey, data.apiConfig.modelName, data.apiConfig.providerId)
            saveChatHistory(context, data.chatHistory)
            saveUserName(context, data.userName)

            true
        } catch (e: Exception) {
            LogManager.e("PreferencesManager", "导入数据失败", e)
            false
        }
    }

    // ==================== 数据类 ====================

    @Serializable
    data class ApiConfig(
        val baseUrl: String,
        val apiKey: String,
        val modelName: String,
        val providerId: String = "openai"
    )

    /**
     * 🆕 单个提供商的API配置
     */
    @Serializable
    data class ProviderApiConfig(
        val baseUrl: String,
        val apiKey: String,
        val modelName: String
    )

    @Serializable
    data class ExportData(
        val apiConfig: ApiConfig,
        val chatHistory: List<ChatMessageDisplay>,
        val userName: String,
        val exportTime: Long
    )
}
