package com.example.xihe.core

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import com.example.xihe.core.SafetyGuard
import com.example.xihe.core.model.ChatMessageDisplay
import com.example.xihe.utils.LogManager
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * 🛰️ 引擎状态管理器
 *
 * 将核心状态从 AutomationEngine 中剥离，实现关注点分离
 * 负责维护聊天记录、任务进度、安全确认等全局 UI 状态
 *
 * ✅ 优化：更严格的内存管理，防止消息列表无限增长
 */
object EngineStateManager {
    
    // 消息列表最大容量（优化：从1000减少到100）
    private const val MAX_MESSAGES = 100
    // 消息最大保留时间：24小时
    private val MAX_MESSAGE_AGE_MS = TimeUnit.HOURS.toMillis(24)
    private const val MESSAGE_CLEANUP_INTERVAL_MS = 60_000L
    private val messageLock = Any()
    private var lastCleanupTimestamp = 0L
    
    // 基础状态 (internal 以便 AutomationEngine 访问)
    internal val _status = MutableStateFlow("Idle")
    val status = _status.asStateFlow()

    // 消息列表
    internal val _messages = MutableStateFlow<List<ChatMessageDisplay>>(emptyList())
    val messages = _messages.asStateFlow()

    // 任务进度
    internal val _taskProgress = MutableStateFlow(TaskProgress())
    val taskProgress = _taskProgress.asStateFlow()

    // 🛡️ 安全确认
    internal val _isWaitingForConfirmation = MutableStateFlow<SafetyGuard.SafetyResult?>(null)
    val isWaitingForConfirmation = _isWaitingForConfirmation.asStateFlow()

    // 暂停/恢复状态
    internal val _isPaused = MutableStateFlow(false)
    val isPaused = _isPaused.asStateFlow()

    // 会话 ID
    private val _currentConversationId = MutableStateFlow(java.util.UUID.randomUUID().toString())
    val currentConversationId = _currentConversationId.asStateFlow()

    /**
     * 开始新会话
     */
    fun startNewConversation() {
        _currentConversationId.value = java.util.UUID.randomUUID().toString()
        clearMessages()
        _status.value = "待机"
    }

    /**
     * 设置当前会话 ID
     */
    fun setCurrentConversationId(id: String) {
        _currentConversationId.value = id
    }

    /**
     * 更新全局状态描述
     */
    fun updateStatus(newStatus: String) {
        _status.value = newStatus
    }

    /**
     * 添加新消息（带容量和时间限制）
     *
     * 当消息数量超过 MAX_MESSAGES 时，自动移除最旧的消息
     * 同时清理超过24小时的消息
     */
    fun addMessage(message: ChatMessageDisplay) {
        val updated = synchronized(messageLock) {
            val current = _messages.value
            val now = System.currentTimeMillis()
            val shouldCleanup = current.size >= MAX_MESSAGES || (now - lastCleanupTimestamp) >= MESSAGE_CLEANUP_INTERVAL_MS
            val sourceMessages = if (shouldCleanup) {
                lastCleanupTimestamp = now
                current.filter { msg ->
                    (now - msg.timestamp) < MAX_MESSAGE_AGE_MS
                }
            } else {
                current
            }
            val trimmedMessages = if (sourceMessages.size >= MAX_MESSAGES) {
                sourceMessages.takeLast(MAX_MESSAGES - 1)
            } else {
                sourceMessages
            }
            val merged = trimmedMessages + message.copy(
                id = message.id.ifBlank { UUID.randomUUID().toString() }
            )
            _messages.value = merged
            merged
        }

        if (updated.size % 10 == 0) {
            logMemoryUsage("addMessage")
        }
    }
    
    /**
     * 清理过期消息（可手动调用）
     */
    fun cleanupOldMessages() {
        val shouldLog = synchronized(messageLock) {
            val now = System.currentTimeMillis()
            lastCleanupTimestamp = now
            val current = _messages.value
            val validMessages = current.filter { msg ->
                (now - msg.timestamp) < MAX_MESSAGE_AGE_MS
            }
            if (validMessages.size < current.size) {
                _messages.value = validMessages
                true
            } else {
                false
            }
        }

        if (shouldLog) {
            logMemoryUsage("cleanupOldMessages")
        }
    }
    
    /**
     * 记录内存使用情况
     */
    private fun logMemoryUsage(tag: String) {
        val runtime = Runtime.getRuntime()
        val usedMemory = (runtime.totalMemory() - runtime.freeMemory()) / 1024 / 1024
        val maxMemory = runtime.maxMemory() / 1024 / 1024
        val messageCount = synchronized(messageLock) { _messages.value.size }
        LogManager.d("EngineStateManager", "[$tag] 消息数: $messageCount, 内存: ${usedMemory}MB/${maxMemory}MB")
    }

    /**
     * 清空消息记录
     */
    fun clearMessages() {
        synchronized(messageLock) {
            _messages.value = emptyList()
            lastCleanupTimestamp = 0L
        }
    }

    /**
     * 更新任务进度
     */
    fun updateProgress(progress: TaskProgress) {
        _taskProgress.value = progress
    }

    /**
     * 设置暂停状态
     */
    fun setPaused(paused: Boolean) {
        _isPaused.value = paused
    }

    /**
     * 设置安全确认状态
     */
    fun setSafetyConfirmation(result: SafetyGuard.SafetyResult?) {
        _isWaitingForConfirmation.value = result
    }
    
    /**
     * 获取当前消息数量
     */
    fun getMessageCount(): Int = synchronized(messageLock) { _messages.value.size }
    
    /**
     * 🔄 更新指定消息的状态
     */
    fun updateMessageStatus(
        messageId: String, 
        status: com.example.xihe.core.model.MessageStatus,
        errorMessage: String? = null
    ) {
        synchronized(messageLock) {
            val current = _messages.value
            val updated = current.map { msg ->
                if (msg.id == messageId) {
                    msg.copy(
                        status = status,
                        errorMessage = errorMessage
                    )
                } else {
                    msg
                }
            }
            _messages.value = updated
        }
    }
    
    /**
     * 🔄 标记消息为失败状态
     */
    fun markMessageFailed(messageId: String, errorMessage: String) {
        updateMessageStatus(messageId, com.example.xihe.core.model.MessageStatus.FAILED, errorMessage)
    }
    
    /**
     * 🔄 标记消息为发送中状态
     */
    fun markMessageSending(messageId: String) {
        updateMessageStatus(messageId, com.example.xihe.core.model.MessageStatus.SENDING, null)
    }
    
    /**
     * 🔄 标记消息为成功状态
     */
    fun markMessageSuccess(messageId: String) {
        updateMessageStatus(messageId, com.example.xihe.core.model.MessageStatus.SUCCESS, null)
    }
    
    /**
     * 🔄 增加消息重试次数
     */
    fun incrementRetryCount(messageId: String) {
        synchronized(messageLock) {
            val current = _messages.value
            val updated = current.map { msg ->
                if (msg.id == messageId) {
                    msg.copy(
                        retryCount = msg.retryCount + 1,
                        status = com.example.xihe.core.model.MessageStatus.SENDING,
                        errorMessage = null
                    )
                } else {
                    msg
                }
            }
            _messages.value = updated
        }
    }
    
    /**
     * 🔍 根据ID获取消息
     */
    fun getMessageById(messageId: String): ChatMessageDisplay? {
        return synchronized(messageLock) {
            _messages.value.find { it.id == messageId }
        }
    }
    
    /**
     * 🗑️ 删除指定消息（用于重试时删除失败的AI回复）
     */
    fun removeMessage(messageId: String) {
        synchronized(messageLock) {
            val current = _messages.value
            _messages.value = current.filter { it.id != messageId }
        }
    }
    
    /**
     * 🔄 获取最后一条用户消息（用于重试）
     */
    fun getLastUserMessage(): ChatMessageDisplay? {
        return synchronized(messageLock) {
            _messages.value.lastOrNull { it.isUser }
        }
    }
    
    /**
     * 🔄 获取指定用户消息之后的AI回复ID列表
     */
    fun getAIResponsesAfterMessage(userMessageId: String): List<String> {
        return synchronized(messageLock) {
            val messages = _messages.value
            val userMsgIndex = messages.indexOfFirst { it.id == userMessageId }
            if (userMsgIndex == -1) {
                emptyList()
            } else {
                messages.drop(userMsgIndex + 1)
                    .takeWhile { !it.isUser }
                    .map { it.id }
            }
        }
    }

    /**
     * 👤 添加用户消息
     */
    fun addUserMessage(
        text: String,
        imageUri: String? = null,
        fileName: String? = null,
        status: com.example.xihe.core.model.MessageStatus = com.example.xihe.core.model.MessageStatus.PENDING
    ): String {
        val message = ChatMessageDisplay(
            content = text,
            isUser = true,
            imageUri = imageUri,
            fileName = fileName,
            status = status
        )
        addMessage(message)
        return message.id
    }

    /**
     * 💬 添加 AI 回复消息
     */
    fun addAIResponse(
        text: String,
        imageUri: String? = null,
        rawOcrText: String? = null
    ) {
        val message = ChatMessageDisplay(
            content = text,
            isUser = false,
            imageUri = imageUri,
            rawOcrText = rawOcrText
        )
        addMessage(message)
    }

    /**
     * 🧠 解析并添加带打字机效果的消息 (主要由 UI 处理动画)
     */
    fun addMessageWithTypewriter(
        text: String, 
        isUser: Boolean, 
        action: String? = null,
        onSpeak: ((String) -> Unit)? = null
    ) {
        // 🧠 解析思考内容（仅 AI 回复）
        val (thinkingContent, cleanContent) = if (!isUser) {
            com.example.xihe.utils.ThinkingParser.parse(text)
        } else {
            Pair(null, text)
        }
        
        val msg = ChatMessageDisplay(
            content = cleanContent,
            isUser = isUser, 
            action = action,
            thinkingContent = thinkingContent
        )
        addMessage(msg)

        // 🔊 语音播报回调
        if (!isUser) {
            onSpeak?.invoke(cleanContent)
        }
    }
}

/**
 * 任务进度数据类
 */
data class TaskProgress(
    val currentStep: Int = 0,
    val totalSteps: Int = 0,
    val description: String = "",
    val percentage: Float = 0f,
    val taskName: String = "",
    val currentAction: String = "",
    val isRunning: Boolean = false,
    val progress: Float = 0f,
    val startTime: Long = 0L,
    val endTime: Long = 0L,
    val error: String? = null
)
