package com.example.xihe.core

import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.ai.IntentClassifier
import com.example.xihe.ai.TaskPlanner
import com.example.xihe.collaboration.CrossAppCoordinator
import com.example.xihe.context.ContextAwarenessEngine
import com.example.xihe.context.ProactiveDialogueManager
import com.example.xihe.interaction.VoiceInteractionManager
import com.example.xihe.learning.AdaptiveLearningSystem
import com.example.xihe.optimization.PerformanceOptimizer
import com.example.xihe.screen.ScreenAnalyzer
import com.example.xihe.security.SecurityManager
import com.example.xihe.service.EnhancedAccessibilityService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

/**
 * 模块协调器
 * 负责协调新旧系统的集成，提供统一的接口
 */
object ModuleCoordinator {
    
    private const val TAG = "ModuleCoordinator"
    
    /**
     * 模块状态
     */
    enum class ModuleStatus {
        NOT_INITIALIZED,
        INITIALIZING,
        READY,
        ERROR
    }
    
    // 模块实例
    private var intentClassifier: IntentClassifier? = null
    private var taskPlanner: TaskPlanner? = null
    private var screenAnalyzer: ScreenAnalyzer? = null
    private var voiceManager: VoiceInteractionManager? = null
    private var learningSystem: AdaptiveLearningSystem? = null
    private var performanceOptimizer: PerformanceOptimizer? = null
    private var crossAppCoordinator: CrossAppCoordinator? = null
    private var proactiveDialogue: ProactiveDialogueManager? = null
    private var contextEngine: ContextAwarenessEngine? = null
    
    // 核心 LLM 客户端 (复用项目配置)
    private var llmClient: com.example.xihe.core.LLMClient? = null
    
    // 状态管理
    private val _status = MutableStateFlow(ModuleStatus.NOT_INITIALIZED)
    val status = _status.asStateFlow()
    
    private val _availableModules = MutableStateFlow<Set<String>>(emptySet())
    val availableModules = _availableModules.asStateFlow()
    
    // 实时部分识别结果
    private val _partialRecognitionResult = MutableStateFlow("")
    val partialRecognitionResult = _partialRecognitionResult.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeakingFlow = _isSpeaking.asStateFlow()
    
    // 🎤 语音状态流（用于UI显示）
    private val _voiceState = MutableStateFlow("IDLE")
    val voiceState = _voiceState.asStateFlow()
    
    // 🎵 TTS队列状态
    private val _ttsQueueSize = MutableStateFlow(0)
    val ttsQueueSize = _ttsQueueSize.asStateFlow()
    
    private val _currentTTSText = MutableStateFlow<String?>(null)
    val currentTTSText = _currentTTSText.asStateFlow()
    
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    
    // 唤醒词回调
    private var onWakeWordDetectedCallback: (() -> Unit)? = null
    
    private var appContext: Context? = null
    private var defaultOnCommandReceived: ((VoiceInteractionManager.VoiceCommand) -> Unit)? = null
    
    /**
     * 判断是否已初始化
     */
    fun isInitialized(): Boolean = _status.value == ModuleStatus.READY
    
    /**
     * 设置唤醒词检测回调
     */
    fun setOnWakeWordDetected(callback: () -> Unit) {
        onWakeWordDetectedCallback = callback
        LogManager.d(TAG, "✅ 已设置唤醒词检测回调")
    }
    
    /**
     * 触发唤醒词检测回调
     */
    fun triggerWakeWordDetected() {
        LogManager.i(TAG, "🎉 触发唤醒词回调...")
        onWakeWordDetectedCallback?.invoke()
    }
    
    /**
     * 初始化协调器
     */
    fun initialize(context: Context, config: ModuleConfig = ModuleConfig()) {
        if (_status.value != ModuleStatus.NOT_INITIALIZED) {
            LogManager.w(TAG, "模块协调器已初始化")
            return
        }
        
        appContext = context.applicationContext
        
        _status.value = ModuleStatus.INITIALIZING
        LogManager.d(TAG, "开始初始化模块协调器...")
        
        val modules = mutableSetOf<String>()
        
        // 初始化AI模块
        if (config.enableAI) {
            try {
                intentClassifier = IntentClassifier()
                taskPlanner = TaskPlanner()
                screenAnalyzer = ScreenAnalyzer()
                
                // 初始化 LLM 客户端并加载配置
                llmClient = com.example.xihe.core.LLMClient()
                val apiConfig = com.example.xihe.core.PreferencesManager.getApiConfig(context)
                if (apiConfig.apiKey.isNotEmpty()) {
                    llmClient?.updateConfig(
                        newBaseUrl = apiConfig.baseUrl,
                        newApiKey = apiConfig.apiKey,
                        newModelName = apiConfig.modelName,
                        newProviderId = apiConfig.providerId
                    )
                    LogManager.d(TAG, "🧠 LLMClient 已加载配置: ${apiConfig.providerId}")
                } else {
                    LogManager.w(TAG, "⚠️ LLMClient 未配置 API Key，将使用本地规则")
                }
                
                modules.add("AI")
                modules.add("TaskPlanner")
                modules.add("ScreenAnalyzer")
                LogManager.d(TAG, "✅ AI模块初始化成功")
            } catch (e: Exception) {
                LogManager.e(TAG, "AI模块初始化失败", e)
            }
        }
        
        // 初始化性格管理器（用于自定义系统提示词）
        try {
            com.example.xihe.personality.PersonalityManager.getInstance(context)
            modules.add("Personality")
            LogManager.d(TAG, "✅ 性格管理器初始化成功")
        } catch (e: Exception) {
            LogManager.e(TAG, "性格管理器初始化失败", e)
        }
        
        // 初始化生活工具（天气、定位等）
        try {
            com.example.xihe.tools.LifeApiTools.init(context)
            com.example.xihe.service.LocationManager.init(context)
            modules.add("LifeTools")
            LogManager.d(TAG, "✅ 生活工具初始化成功")
        } catch (e: Exception) {
            LogManager.e(TAG, "生活工具初始化失败", e)
        }
        
        // 初始化语音模块
        if (config.enableVoice) {
            try {
                val appCtx = context.applicationContext
                val defaultHandler: (VoiceInteractionManager.VoiceCommand) -> Unit = { command ->
                    LogManager.d(TAG, "🎤 语音识别结果: ${command.text}, 是唤醒词: ${command.isWakeWord}")
                    
                    if (command.text.isNotBlank()) {
                        LogManager.d(TAG, "✅ 发送到 AutomationEngine 处理: ${command.text}")
                        AutomationEngine.start(command.text, appCtx)
                    } else {
                        LogManager.w(TAG, "⚠️ 忽略空白命令")
                    }
                }
                
                defaultOnCommandReceived = defaultHandler
                
                voiceManager = VoiceInteractionManager(context)
                voiceManager?.initialize(
                    onCommandReceived = defaultHandler,
                    onWakeWordDetected = {
                        // 检测到唤醒词
                        LogManager.i(TAG, "🎉 唤醒词被检测到！")
                        // 启用连续对话模式
                        voiceManager?.setContinuousMode(true)
                        // 播放回复语音，完成后开始监听用户指令
                        scope.launch {
                            speak("我在~主人有什么吩咐？") {
                                // 播报完成后强制开始监听
                                LogManager.d(TAG, "🎤 回复播放完成，开始监听用户指令...")
                                voiceManager?.startListening()
                            }
                        }
                    }
                )
                modules.add("Voice")
                
                // 启动协程转发部分识别结果
                scope.launch {
                    voiceManager?.partialRecognitionResult?.collect {
                        _partialRecognitionResult.value = it
                    }
                }

                scope.launch {
                    voiceManager?.state?.collect { state ->
                        _isSpeaking.value = state == VoiceInteractionManager.VoiceState.SPEAKING
                        // 🎤 更新语音状态字符串（用于UI）
                        _voiceState.value = when (state) {
                            VoiceInteractionManager.VoiceState.IDLE -> "IDLE"
                            VoiceInteractionManager.VoiceState.LISTENING -> "LISTENING"
                            VoiceInteractionManager.VoiceState.PROCESSING -> "PROCESSING"
                            VoiceInteractionManager.VoiceState.SPEAKING -> "SPEAKING"
                            VoiceInteractionManager.VoiceState.ERROR -> "ERROR"
                        }
                    }
                }
                
                LogManager.d(TAG, "✅ 语音模块初始化成功")
            } catch (e: Exception) {
                LogManager.e(TAG, "语音模块初始化失败", e)
            }
        }
        
        // 初始化学习系统
        if (config.enableLearning) {
            try {
                learningSystem = AdaptiveLearningSystem(context)
                learningSystem?.initialize()
                modules.add("Learning")
                LogManager.d(TAG, "✅ 学习系统初始化成功")
            } catch (e: Exception) {
                LogManager.e(TAG, "学习系统初始化失败", e)
            }
        }
        
        // 初始化性能优化器
        if (config.enablePerformance) {
            try {
                performanceOptimizer = PerformanceOptimizer(context)
                performanceOptimizer?.initialize()
                modules.add("Performance")
                LogManager.d(TAG, "✅ 性能优化器初始化成功")
            } catch (e: Exception) {
                LogManager.e(TAG, "性能优化器初始化失败", e)
            }
        }
        
        // 初始化跨应用协调器
        if (config.enableCrossApp) {
            try {
                crossAppCoordinator = CrossAppCoordinator(context)
                modules.add("CrossApp")
                LogManager.d(TAG, "✅ 跨应用协调器初始化成功")
            } catch (e: Exception) {
                LogManager.e(TAG, "跨应用协调器初始化失败", e)
            }
        }
        
        // 安全管理器是静态的，不需要初始化
        if (config.enableSecurity) {
            SecurityManager.setStrictMode(config.strictSecurityMode)
            modules.add("Security")
            LogManager.d(TAG, "✅ 安全管理器已配置")
        }
        
        // 初始化情境感知和主动对话系统
        if (config.enableProactiveDialogue) {
            try {
                contextEngine = ContextAwarenessEngine.getInstance(context)
                proactiveDialogue = ProactiveDialogueManager.getInstance(context)
                modules.add("ProactiveDialogue")
                LogManager.d(TAG, "✅ 主动对话系统已初始化")
            } catch (e: Exception) {
                LogManager.e(TAG, "主动对话系统初始化失败", e)
            }
        }
        
        _availableModules.value = modules
        _status.value = ModuleStatus.READY
        
        LogManager.d(TAG, "模块协调器初始化完成，可用模块: $modules")
    }
    
    /**
     * 配置类
     */
    data class ModuleConfig(
        val enableAI: Boolean = true,
        val enableVoice: Boolean = true,
        val enableLearning: Boolean = true,
        val enablePerformance: Boolean = true,
        val enableCrossApp: Boolean = true,
        val enableSecurity: Boolean = true,
        val strictSecurityMode: Boolean = false,
        val enableProactiveDialogue: Boolean = true
    )
    
    // ===== 对外接口方法 =====
    
    /**
     * 分析用户意图
     */
    suspend fun analyzeIntent(input: String): IntentClassifier.IntentResult? {
        // 1. 尝试使用 LLM 大脑 (优先)
        try {
            // 确保 LLMClient 已初始化
            if (llmClient == null) {
                LogManager.w(TAG, "LLMClient 未初始化，跳过 LLM 分析")
            } else {
                val llmResponse = llmClient?.analyzeIntent(input)
                if (llmResponse != null) {
                    LogManager.d(TAG, "🧠 LLM 意图识别成功: ${llmResponse.intent}")
                    
                    // 将 LLM 响应转换为 IntentResult
                    val intentEnum = try {
                        IntentClassifier.UserIntent.valueOf(llmResponse.intent)
                    } catch (e: Exception) {
                        // 默认回退
                        if (llmResponse.intent == "greeting") IntentClassifier.UserIntent.CASUAL_CHAT
                        else IntentClassifier.UserIntent.CASUAL_CHAT 
                    }
                    
                    // 构建实体参数
                    val entities = mutableMapOf<String, Any>()
                    
                    // 处理多步操作序列
                    if (llmResponse.actions.isNotEmpty()) {
                        // 将动作列表转为 JSON 字符串存储，以便传递给 TaskPlanner
                        val json = kotlinx.serialization.json.Json { ignoreUnknownKeys = true }
                        val actionsJson = json.encodeToString(
                            kotlinx.serialization.builtins.ListSerializer(com.example.xihe.core.LLMClient.LLMAction.serializer()),
                            llmResponse.actions
                        )
                        entities["llm_actions"] = actionsJson
                        
                        // 为了兼容，也将第一个动作的属性放入顶层实体
                        val firstAction = llmResponse.actions.first()
                        if (firstAction.target.isNotEmpty()) entities["target"] = firstAction.target
                        if (firstAction.text.isNotEmpty()) entities["text"] = firstAction.text
                        if (firstAction.type == "OPEN_APP") entities["app"] = firstAction.target
                        entities["action_type"] = firstAction.type
                    } else {
                        // 兼容旧的单步操作
                        llmResponse.action?.let { action ->
                            if (action.target.isNotEmpty()) entities["target"] = action.target
                            if (action.text.isNotEmpty()) entities["text"] = action.text
                            if (action.type == "OPEN_APP") entities["app"] = action.target
                            entities["action_type"] = action.type
                        }
                    }
                    
                    return IntentClassifier.IntentResult(
                        intent = intentEnum,
                        confidence = 0.95f, // LLM 通常比较自信
                        entities = entities,
                        suggestedAction = llmResponse.response, // 这里借用 response 字段
                        needsClarification = false
                    )
                }
            }
        } catch (e: Exception) {
            LogManager.w(TAG, "LLM 分析失败，回退到本地规则: ${e.message}")
        }
        
        // 2. 回退到本地规则 (兜底)
        return try {
            intentClassifier?.classifyIntent(input)
        } catch (e: Exception) {
            LogManager.e(TAG, "意图分析失败", e)
            null
        }
    }
    
    /**
     * 规划任务
     */
    fun planTask(
        request: String, 
        intent: IntentClassifier.IntentResult?,
        screenState: ScreenAnalyzer.ScreenState? = null
    ): TaskPlanner.TaskPlan? {
        return try {
            intent?.let {
                taskPlanner?.planTask(request, it, screenState)
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "任务规划失败", e)
            null
        }
    }
    
    /**
     * 分析屏幕
     */
    fun analyzeScreen(): ScreenAnalyzer.ScreenState? {
        return try {
            val accessibilityService = EnhancedAccessibilityService.getInstance()
            accessibilityService?.rootInActiveWindow?.let { rootNode ->
                screenAnalyzer?.analyzeScreen(rootNode)
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "屏幕分析失败", e)
            null
        }
    }
    
    // 保存用户回调
    private var userResultCallback: ((String) -> Unit)? = null
    
    private fun restoreDefaultOnCommandReceived() {
        val handler = defaultOnCommandReceived ?: return
        voiceManager?.setOnCommandReceived(handler)
    }
    
    /**
     * 开始语音识别
     */
    fun startVoiceRecognition(onResult: ((String) -> Unit)? = null) {
        LogManager.d(TAG, "🎤 启动语音识别...")
        userResultCallback = onResult
        
        if (onResult == null) {
            restoreDefaultOnCommandReceived()
        }
        
        // 将回调传递给 VoiceInteractionManager
        if (onResult != null) {
            voiceManager?.setOnCommandReceived { command ->
                LogManager.d(TAG, "📥 接收到语音命令: ${command.text}")
                // 调用用户回调
                userResultCallback?.invoke(command.text)
                
                userResultCallback = null
                restoreDefaultOnCommandReceived()
            }
        }
        
        voiceManager?.startListening()
    }
    
    /**
     * 停止语音识别
     * @param disableContinuous 是否同时禁用持续监听模式（默认 false，保持持续监听状态）
     */
    fun stopVoiceRecognition(disableContinuous: Boolean = false) {
        LogManager.d(TAG, "🛑 停止语音识别 (禁用持续模式: $disableContinuous)...")
        voiceManager?.stopListening(disableContinuous)
        
        userResultCallback = null
        restoreDefaultOnCommandReceived()
    }
    
    /**
     * 获取语音识别状态
     */
    fun getVoiceState(): VoiceInteractionManager.VoiceState? {
        return voiceManager?.state?.value
    }
    
    /**
     * 文字转语音
     * @param onComplete 播报完成后的回调（用于恢复监听等）
     */
    fun speak(
        text: String, 
        emotion: VoiceInteractionManager.Emotion = VoiceInteractionManager.Emotion.NEUTRAL,
        onComplete: (() -> Unit)? = null
    ) {
        if (voiceManager == null) {
            LogManager.w(TAG, "⚠️ 语音模块未初始化，无法播报: ${text.take(30)}...")
            onComplete?.invoke()
            return
        }
        LogManager.d(TAG, "🔊 播报文字: ${text.take(50)}...")
        // 传递 onComplete 回调，播报完成后会自动恢复监听
        voiceManager?.speak(text, emotion, onComplete)
    }
    
    /**
     * 启动持续监听模式（唤醒词检测）
     */
    fun startContinuousListening() {
        LogManager.i(TAG, "🎤 启动持续监听模式...")
        voiceManager?.startContinuousListening()
    }
    
    /**
     * 停止持续监听模式
     */
    fun stopContinuousListening() {
        LogManager.i(TAG, "🛑 停止持续监听模式...")
        voiceManager?.stopContinuousListening()
    }
    
    /**
     * 设置语音识别引擎类型
     * @param useOffline true = 使用 Vosk 离线识别，false = 使用系统识别
     */
    fun setRecognizerType(useOffline: Boolean) {
        LogManager.i(TAG, "🎤 切换语音识别引擎: ${if (useOffline) "Vosk 离线" else "系统"}")
        voiceManager?.setUseOfflineRecognizer(useOffline)
    }
    
    /**
     * 判断是否正在监听
     */
    fun isListening(): Boolean {
        return voiceManager?.state?.value == VoiceInteractionManager.VoiceState.LISTENING
    }
    
    /**
     * 启动持续语音识别（实时对话模式）
     * 识别完成后自动重新开始监听
     */
    fun startContinuousVoiceRecognition() {
        LogManager.i(TAG, "🔄 启动持续语音识别模式...")
        
        userResultCallback = null
        restoreDefaultOnCommandReceived()
        
        // 先确保停止之前的监听，避免状态冲突
        voiceManager?.stopListening(disableContinuous = false)
        
        // 设置持续监听模式
        voiceManager?.setContinuousMode(true)
        
        // 📞 启用打断检测
        voiceManager?.setInterruptEnabled(true)
        
        // 📞 优化：极短延迟后开始监听，实现无缝对话
        CoroutineScope(Dispatchers.Main).launch {
            kotlinx.coroutines.delay(100)  // 缩短到100ms
            voiceManager?.startListening()
            LogManager.d(TAG, "🎤 持续语音识别已启动")
        }
        
        // 🧠 启动主动对话系统
        proactiveDialogue?.start()
        proactiveDialogue?.setRealTimeMode(true)
        LogManager.d(TAG, "🤖 主动对话系统已启动")
    }
    
    /**
     * 🛑 停止持续语音识别
     */
    fun stopContinuousVoiceRecognition() {
        LogManager.i(TAG, "🛑 停止持续语音识别模式...")
        voiceManager?.setContinuousMode(false)
        voiceManager?.stopListening()
        
        // 🛑 停止主动对话系统
        proactiveDialogue?.setRealTimeMode(false)
        proactiveDialogue?.stop()
        LogManager.d(TAG, "🛑 主动对话系统已停止")
    }
    
    /**
     * 🗣️ 更新用户发言时间（用于静默检测）
     */
    fun updateUserSpeechTime() {
        proactiveDialogue?.updateLastSpeechTime()
    }
    
    /**
     * 🎯 获取主动对话触发器流
     */
    fun getProactiveTriggerFlow() = proactiveDialogue?.proactiveTrigger
    
    /**
     * ✅ 确认主动对话已处理
     */
    fun acknowledgeProactive() {
        proactiveDialogue?.acknowledgeProactive()
    }
    
    /**
     * 📊 获取主动对话统计
     */
    fun getProactiveStatistics() = proactiveDialogue?.getStatistics()
    
    /**
     * 🛑 停止语音播报
     */
    fun stopSpeaking() {
        LogManager.i(TAG, "🛑 停止语音播报...")
        voiceManager?.stopSpeaking()
        _isSpeaking.value = false
        _voiceState.value = "IDLE"
        _currentTTSText.value = null
        _ttsQueueSize.value = 0
    }
    
    /**
     * 🔄 设置持续监听模式
     */
    fun setContinuousListening(enabled: Boolean) {
        LogManager.i(TAG, "🔄 设置持续监听: ${if (enabled) "启用" else "禁用"}")
        voiceManager?.setContinuousMode(enabled)
    }
    
    /**
     * 🎤 启动唤醒词检测
     */
    fun startWakeWordDetection() {
        LogManager.i(TAG, "🎤 启动唤醒词检测...")
        voiceManager?.startWakeWordDetection()
    }
    
    /**
     * 🛑 停止唤醒词检测
     */
    fun stopWakeWordDetection() {
        LogManager.i(TAG, "🛑 停止唤醒词检测...")
        voiceManager?.stopWakeWordDetection()
    }
    
    /**
     * 🔊 设置是否使用本地TTS
     */
    fun setUseLocalTTS(enabled: Boolean) {
        LogManager.i(TAG, "🔊 设置本地TTS: ${if (enabled) "启用" else "禁用"}")
        voiceManager?.setUseLocalTTS(enabled)
    }
    
    /**
     * 🔊 获取是否使用本地TTS
     */
    fun isUsingLocalTTS(): Boolean {
        return voiceManager?.isUsingLocalTTS() ?: false
    }
    
    /**
     * 🔊 设置 TTS 引擎类型
     */
    fun setTTSEngine(engine: String) {
        val ttsEngine = when (engine) {
            "local" -> VoiceInteractionManager.TTSEngine.LOCAL
            "online" -> VoiceInteractionManager.TTSEngine.ONLINE
            else -> VoiceInteractionManager.TTSEngine.SYSTEM
        }
        LogManager.i(TAG, "🔊 设置TTS引擎: $engine")
        voiceManager?.setTTSEngine(ttsEngine)
    }
    
    /**
     * 🔊 获取当前 TTS 引擎类型
     */
    fun getCurrentTTSEngine(): String {
        return when (voiceManager?.getCurrentTTSEngine()) {
            VoiceInteractionManager.TTSEngine.LOCAL -> "local"
            VoiceInteractionManager.TTSEngine.ONLINE -> "online"
            else -> "system"
        }
    }
    
    /**
     * 🌐 配置在线 TTS API
     */
    fun configureOnlineTTS(url: String, apiKey: String = "", engine: String = "custom", voice: String = "zh-CN-XiaoxiaoNeural") {
        LogManager.i(TAG, "🌐 配置在线TTS: $url")
        val prefs = appContext?.getSharedPreferences("voice_settings", android.content.Context.MODE_PRIVATE)
        prefs?.edit()
            ?.putString("online_tts_url", url)
            ?.putString("online_tts_key", apiKey)
            ?.putString("online_tts_engine", engine)
            ?.putString("online_tts_voice", voice)
            ?.apply()
    }
    
    /**
     * 🎵 跳过当前TTS播放
     */
    fun skipCurrentTTS() {
        LogManager.i(TAG, "⏭️ 跳过当前TTS播放...")
        voiceManager?.skipCurrentTTS()
    }
    
    /**
     * 🎵 清空TTS播放队列
     */
    fun clearTTSQueue() {
        LogManager.i(TAG, "🗑️ 清空TTS播放队列...")
        voiceManager?.clearTTSQueue()
        _ttsQueueSize.value = 0
    }
    
    /**
     * 🎵 获取TTS队列大小
     */
    fun getTTSQueueSize(): Int {
        return voiceManager?.getTTSQueueSize() ?: 0
    }
    
    /**
     * 🔊 设置是否启用语音播报
     */
    fun setEnableTTSResponse(enabled: Boolean) {
        LogManager.i(TAG, "🔊 设置语音播报: ${if (enabled) "启用" else "禁用"}")
        voiceManager?.setEnableTTSResponse(enabled)
    }
    
    /**
     * 🔊 获取是否启用语音播报
     */
    fun isEnableTTSResponse(): Boolean {
        return voiceManager?.isEnableTTSResponse() ?: true
    }
    
    /**
     * 🔊 检查是否正在播报
     */
    fun isSpeaking(): Boolean {
        return voiceManager?.isSpeaking() ?: false
    }
    
    /**
     * 记录用户行为（学习系统）
     */
    fun recordUserAction(input: String, action: String, success: Boolean, executionTime: Long) {
        learningSystem?.recordUserAction(input, action, success, executionTime)
    }
    
    /**
     * 预测下一步操作
     */
    fun predictNextAction(context: Map<String, String>): List<AdaptiveLearningSystem.Prediction> {
        return learningSystem?.predictNextAction(context) ?: emptyList()
    }
    
    /**
     * 优化性能
     */
    fun optimizePerformance() {
        performanceOptimizer?.optimizeMemory()
    }
    
    /**
     * 检查操作安全性
     */
    fun checkSafety(operation: String): SecurityManager.SecurityCheckResult {
        return SecurityManager.checkOperationSafety(operation)
    }
    
    /**
     * 执行跨应用任务
     */
    suspend fun executeCrossAppTask(taskName: String, parameters: Map<String, String>): CrossAppCoordinator.ExecutionResult? {
        return crossAppCoordinator?.executeTask(taskName, parameters)
    }
    
    /**
     * 检查模块是否可用
     */
    fun isModuleAvailable(module: String): Boolean {
        return _availableModules.value.contains(module)
    }
    
    /**
     * 获取模块状态报告
     */
    fun getStatusReport(): StatusReport {
        return StatusReport(
            coordinatorStatus = _status.value,
            availableModules = _availableModules.value,
            aiReady = intentClassifier != null && taskPlanner != null,
            voiceReady = voiceManager != null,
            learningReady = learningSystem != null,
            performanceReady = performanceOptimizer != null,
            crossAppReady = crossAppCoordinator != null,
            accessibilityConnected = EnhancedAccessibilityService.isConnected.value
        )
    }
    
    /**
     * 状态报告
     */
    data class StatusReport(
        val coordinatorStatus: ModuleStatus,
        val availableModules: Set<String>,
        val aiReady: Boolean,
        val voiceReady: Boolean,
        val learningReady: Boolean,
        val performanceReady: Boolean,
        val crossAppReady: Boolean,
        val accessibilityConnected: Boolean
    )
    
    /**
     * 释放资源
     */
    fun release() {
        LogManager.d(TAG, "释放模块协调器资源...")
        
        voiceManager?.release()
        learningSystem?.release()
        performanceOptimizer?.release()
        crossAppCoordinator?.release()
        
        intentClassifier = null
        taskPlanner = null
        screenAnalyzer = null
        voiceManager = null
        learningSystem = null
        performanceOptimizer = null
        crossAppCoordinator = null
        
        _availableModules.value = emptySet()
        _status.value = ModuleStatus.NOT_INITIALIZED
    }
}
