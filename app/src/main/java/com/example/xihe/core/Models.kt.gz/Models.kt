package com.example.xihe.core

import kotlinx.serialization.Serializable

/**
 * Screen Description Protocol (SDP)
 * Simplified representation of the UI for the LLM.
 */
@Serializable
data class ScreenNode(
    val id: Int,
    val className: String,
    val text: String?,
    val contentDescription: String?,
    val bounds: List<Int>, // [left, top, right, bottom]
    val isClickable: Boolean,
    val isScrollable: Boolean,
    val isEditable: Boolean,
    val usageHint: String? = null, // 💡 语义增强：猜测该组件的用途 (e.g. "搜索框", "提交按钮")
    val children: List<ScreenNode> = emptyList()
)

@Serializable
data class ScreenState(
    val packageName: String,
    val root: ScreenNode,
    val contextHints: String = "" // 🆕 场景上下文提示
)

/**
 * Action Instruction Protocol (AIP)
 * Commands returned by the LLM.
 */
@Serializable
data class AICommand(
    val thought: String,
    val action: String, // "CLICK", "SCROLL", "INPUT", "HOME", "BACK", "DONE", "TOOL_CALL", "LONG_PRESS", "DOUBLE_CLICK", "DRAG", "PINCH"
    val targetId: Int? = null,
    val inputText: String? = null,
    val direction: String? = null, // "UP", "DOWN", "LEFT", "RIGHT"
    val toolCalls: List<com.example.xihe.tools.ToolCall>? = null, // Tool calling support
    val duration: Long? = null, // For LONG_PRESS (milliseconds)
    val startX: Float? = null, // For DRAG start X
    val startY: Float? = null, // For DRAG start Y
    val endX: Float? = null, // For DRAG end X
    val endY: Float? = null, // For DRAG end Y
    val scaleIn: Boolean? = null // For PINCH (true=zoom in, false=zoom out)
)

/**
 * 用户意图分类结果
 * 兼容IntentAnalyzer和其他模块的使用
 */
@Serializable
data class UserIntent(
    val type: String = "", // "chat", "task", "query", "control" (新版) 或 intent类型(旧版)
    val confidence: Double = 1.0,
    val entities: Map<String, String> = emptyMap(), // 新版使用
    val parameters: kotlinx.serialization.json.JsonObject? = null, // IntentAnalyzer使用
    val reasoning: String = "", // IntentAnalyzer使用
    val originalText: String = "" // 原始文本
) {
    // 兼容性构造函数
    constructor(
        intent: String,
        confidence: Double,
        parameters: kotlinx.serialization.json.JsonObject,
        reasoning: String
    ) : this(
        type = intent,
        confidence = confidence,
        parameters = parameters,
        reasoning = reasoning
    )
}
