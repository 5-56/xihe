package com.example.xihe.core

import android.content.Context
import com.example.xihe.utils.LogManager
import android.view.accessibility.AccessibilityNodeInfo
import com.example.xihe.CoreAccessibilityService
import kotlinx.coroutines.delay
import java.util.concurrent.ConcurrentHashMap

/**
 * 错误恢复管理器
 * 提供智能错误分类、自动恢复、学习机制等功能
 */
class ErrorRecoveryManager(private val context: Context) {
    
    companion object {
        private const val TAG = "ErrorRecoveryManager"
        private const val MAX_RETRY_COUNT = 3
        private const val MAX_ERROR_HISTORY = 100
        
        @Volatile
        private var instance: ErrorRecoveryManager? = null
        
        fun getInstance(context: Context): ErrorRecoveryManager {
            return instance ?: synchronized(this) {
                instance ?: ErrorRecoveryManager(context.applicationContext).also { instance = it }
            }
        }
    }
    
    // 错误历史记录
    private val errorHistory = mutableListOf<ErrorRecord>()
    
    // 错误模式学习 (错误类型 -> 成功恢复策略)
    private val learnedPatterns = ConcurrentHashMap<ErrorType, ManagerRecoveryStrategy>()
    
    // ==================== 数据类 ====================
    
    /**
     * 错误类型
     */
    enum class ErrorType {
        ELEMENT_NOT_FOUND,          // 元素未找到
        ELEMENT_NOT_CLICKABLE,      // 元素不可点击
        ELEMENT_NOT_VISIBLE,        // 元素不可见
        SCREEN_CHANGED,             // 屏幕已变化
        APP_NOT_RESPONDING,         // 应用无响应
        APP_CRASHED,                // 应用崩溃
        PERMISSION_DENIED,          // 权限被拒绝
        NETWORK_ERROR,              // 网络错误
        TIMEOUT,                    // 超时
        INPUT_FAILED,               // 输入失败
        GESTURE_FAILED,             // 手势失败
        UNEXPECTED_DIALOG,          // 意外弹窗
        NAVIGATION_FAILED,          // 导航失败
        VERIFICATION_FAILED,        // 验证失败
        UNKNOWN                     // 未知错误
    }
    
    /**
     * 恢复策略
     */
    enum class ManagerRecoveryStrategy {
        RETRY_SAME,                 // 重试相同操作
        RETRY_ALTERNATIVE,          // 尝试替代方法
        SCROLL_AND_RETRY,           // 滑动后重试
        WAIT_AND_RETRY,             // 等待后重试
        DISMISS_DIALOG,             // 关闭弹窗
        GO_BACK,                    // 返回上一页
        RESTART_APP,                // 重启应用
        RESTART_TASK,               // 重启任务
        SKIP_STEP,                  // 跳过当前步骤
        ASK_USER,                   // 询问用户
        ABORT                       // 中止任务
    }
    
    /**
     * 错误记录
     */
    data class ErrorRecord(
        val timestamp: Long,
        val errorType: ErrorType,
        val description: String,
        val context: ErrorContext,
        val recoveryAttempts: List<RecoveryAttempt>,
        val finalOutcome: RecoveryOutcome
    )
    
    /**
     * 错误上下文
     */
    data class ErrorContext(
        val currentApp: String?,
        val currentScreen: String?,
        val targetElement: String?,
        val action: String?,
        val stackTrace: String? = null
    )
    
    /**
     * 恢复尝试
     */
    data class RecoveryAttempt(
        val strategy: ManagerRecoveryStrategy,
        val success: Boolean,
        val duration: Long,
        val details: String? = null
    )
    
    /**
     * 恢复结果
     */
    enum class RecoveryOutcome {
        RECOVERED,          // 已恢复
        PARTIALLY_RECOVERED,// 部分恢复
        FAILED,             // 恢复失败
        USER_INTERVENTION   // 需要用户介入
    }
    
    /**
     * 恢复结果详情
     */
    data class RecoveryResult(
        val success: Boolean,
        val strategy: ManagerRecoveryStrategy,
        val attempts: Int,
        val message: String,
        val shouldContinue: Boolean = true
    )
    
    // ==================== 错误分类 ====================
    
    /**
     * 分析错误类型
     */
    fun classifyError(
        exception: Exception?,
        actionType: String?,
        elementInfo: String?,
        screenState: String?
    ): ErrorType {
        // 根据异常类型分类
        exception?.let {
            val message = it.message?.lowercase() ?: ""
            return when {
                message.contains("not found") || message.contains("null") -> ErrorType.ELEMENT_NOT_FOUND
                message.contains("not clickable") -> ErrorType.ELEMENT_NOT_CLICKABLE
                message.contains("not visible") -> ErrorType.ELEMENT_NOT_VISIBLE
                message.contains("timeout") -> ErrorType.TIMEOUT
                message.contains("network") || message.contains("connection") -> ErrorType.NETWORK_ERROR
                message.contains("permission") -> ErrorType.PERMISSION_DENIED
                else -> ErrorType.UNKNOWN
            }
        }
        
        // 根据动作类型和上下文推断
        return when {
            actionType == "CLICK" && elementInfo == null -> ErrorType.ELEMENT_NOT_FOUND
            actionType == "INPUT" -> ErrorType.INPUT_FAILED
            actionType == "SCROLL" -> ErrorType.GESTURE_FAILED
            screenState?.contains("dialog") == true -> ErrorType.UNEXPECTED_DIALOG
            else -> ErrorType.UNKNOWN
        }
    }
    
    // ==================== 智能恢复 ====================
    
    /**
     * 尝试恢复
     */
    suspend fun tryRecover(
        errorType: ErrorType,
        errorContext: ErrorContext,
        service: CoreAccessibilityService?
    ): RecoveryResult {
        LogManager.w(TAG, "开始错误恢复: type=$errorType")
        
        val startTime = System.currentTimeMillis()
        val attempts = mutableListOf<RecoveryAttempt>()
        
        // 获取推荐的恢复策略
        val strategies = getRecoveryStrategies(errorType)
        
        for (strategy in strategies) {
            val attemptStart = System.currentTimeMillis()
            
            val success = executeRecoveryStrategy(strategy, errorContext, service)
            
            attempts.add(RecoveryAttempt(
                strategy = strategy,
                success = success,
                duration = System.currentTimeMillis() - attemptStart
            ))
            
            if (success) {
                // 学习成功的模式
                learnPattern(errorType, strategy)
                
                recordError(errorType, errorContext, attempts, RecoveryOutcome.RECOVERED)
                
                return RecoveryResult(
                    success = true,
                    strategy = strategy,
                    attempts = attempts.size,
                    message = "通过 ${strategy.name} 成功恢复",
                    shouldContinue = true
                )
            }
            
            delay(500) // 策略之间等待
        }
        
        // 所有策略都失败了
        recordError(errorType, errorContext, attempts, RecoveryOutcome.FAILED)
        
        return RecoveryResult(
            success = false,
            strategy = ManagerRecoveryStrategy.ABORT,
            attempts = attempts.size,
            message = "所有恢复策略都失败了",
            shouldContinue = false
        )
    }
    
    /**
     * 获取恢复策略列表
     */
    private fun getRecoveryStrategies(errorType: ErrorType): List<ManagerRecoveryStrategy> {
        // 首先检查是否有学习到的成功模式
        learnedPatterns[errorType]?.let {
            return listOf(it) + getDefaultStrategies(errorType).filter { s -> s != it }
        }
        
        return getDefaultStrategies(errorType)
    }
    
    /**
     * 获取默认恢复策略
     */
    private fun getDefaultStrategies(errorType: ErrorType): List<ManagerRecoveryStrategy> {
        return when (errorType) {
            ErrorType.ELEMENT_NOT_FOUND -> listOf(
                ManagerRecoveryStrategy.WAIT_AND_RETRY,
                ManagerRecoveryStrategy.SCROLL_AND_RETRY,
                ManagerRecoveryStrategy.GO_BACK,
                ManagerRecoveryStrategy.RETRY_ALTERNATIVE
            )
            ErrorType.ELEMENT_NOT_CLICKABLE -> listOf(
                ManagerRecoveryStrategy.WAIT_AND_RETRY,
                ManagerRecoveryStrategy.RETRY_ALTERNATIVE,
                ManagerRecoveryStrategy.SCROLL_AND_RETRY
            )
            ErrorType.ELEMENT_NOT_VISIBLE -> listOf(
                ManagerRecoveryStrategy.SCROLL_AND_RETRY,
                ManagerRecoveryStrategy.WAIT_AND_RETRY
            )
            ErrorType.SCREEN_CHANGED -> listOf(
                ManagerRecoveryStrategy.RETRY_SAME,
                ManagerRecoveryStrategy.GO_BACK,
                ManagerRecoveryStrategy.RESTART_TASK
            )
            ErrorType.APP_NOT_RESPONDING -> listOf(
                ManagerRecoveryStrategy.WAIT_AND_RETRY,
                ManagerRecoveryStrategy.RESTART_APP
            )
            ErrorType.APP_CRASHED -> listOf(
                ManagerRecoveryStrategy.RESTART_APP,
                ManagerRecoveryStrategy.RESTART_TASK
            )
            ErrorType.UNEXPECTED_DIALOG -> listOf(
                ManagerRecoveryStrategy.DISMISS_DIALOG,
                ManagerRecoveryStrategy.GO_BACK
            )
            ErrorType.TIMEOUT -> listOf(
                ManagerRecoveryStrategy.RETRY_SAME,
                ManagerRecoveryStrategy.WAIT_AND_RETRY
            )
            ErrorType.INPUT_FAILED -> listOf(
                ManagerRecoveryStrategy.RETRY_SAME,
                ManagerRecoveryStrategy.RETRY_ALTERNATIVE
            )
            ErrorType.GESTURE_FAILED -> listOf(
                ManagerRecoveryStrategy.RETRY_SAME,
                ManagerRecoveryStrategy.RETRY_ALTERNATIVE
            )
            else -> listOf(
                ManagerRecoveryStrategy.RETRY_SAME,
                ManagerRecoveryStrategy.ASK_USER
            )
        }
    }
    
    /**
     * 执行恢复策略
     */
    private suspend fun executeRecoveryStrategy(
        strategy: ManagerRecoveryStrategy,
        context: ErrorContext,
        service: CoreAccessibilityService?
    ): Boolean {
        LogManager.w(TAG, "执行恢复策略: $strategy")
        
        return try {
            when (strategy) {
                ManagerRecoveryStrategy.RETRY_SAME -> {
                    delay(300)
                    true // 标记为可以重试
                }
                
                ManagerRecoveryStrategy.WAIT_AND_RETRY -> {
                    delay(2000)
                    true
                }
                
                ManagerRecoveryStrategy.SCROLL_AND_RETRY -> {
                    service?.let {
                        val displayMetrics = it.resources.displayMetrics
                        val centerX = displayMetrics.widthPixels / 2f
                        val centerY = displayMetrics.heightPixels / 2f
                        it.performScroll(centerX, centerY + 300, centerX, centerY - 300)
                        delay(500)
                        true
                    } ?: false
                }
                
                ManagerRecoveryStrategy.DISMISS_DIALOG -> {
                    dismissDialog(service)
                }
                
                ManagerRecoveryStrategy.GO_BACK -> {
                    service?.performGlobalBack()
                    delay(500)
                    true
                }
                
                ManagerRecoveryStrategy.RESTART_APP -> {
                    context.currentApp?.let { pkg ->
                        // 先返回主屏幕
                        service?.performGlobalHome()
                        delay(500)
                        // 重新启动应用
                        val intent = this.context.packageManager.getLaunchIntentForPackage(pkg)
                        intent?.let {
                            this.context.startActivity(it)
                            delay(2000)
                            true
                        } ?: false
                    } ?: false
                }
                
                ManagerRecoveryStrategy.RESTART_TASK -> {
                    service?.performGlobalHome()
                    delay(500)
                    true
                }
                
                ManagerRecoveryStrategy.SKIP_STEP -> {
                    true // 直接标记为可以跳过
                }
                
                ManagerRecoveryStrategy.RETRY_ALTERNATIVE -> {
                    delay(500)
                    true
                }
                
                ManagerRecoveryStrategy.ASK_USER -> {
                    false // 需要用户介入
                }
                
                ManagerRecoveryStrategy.ABORT -> {
                    false
                }
            }
        } catch (e: Exception) {
            LogManager.w(TAG, "恢复策略执行失败: ${e.message}")
            false
        }
    }
    
    /**
     * 关闭对话框
     */
    private suspend fun dismissDialog(service: CoreAccessibilityService?): Boolean {
        if (service == null) return false
        
        val root = service.rootInActiveWindow ?: return false
        
        // 查找常见的关闭按钮
        val dismissTexts = listOf("取消", "关闭", "不了", "以后再说", "知道了", "确定", "OK", "Cancel", "Close")
        
        for (text in dismissTexts) {
            val node = findNodeByText(root, text)
            if (node != null && node.isClickable) {
                node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                delay(300)
                return true
            }
        }
        
        // 尝试返回键
        service.performGlobalBack()
        delay(300)
        return true
    }
    
    /**
     * 通过文本查找节点
     */
    private fun findNodeByText(node: AccessibilityNodeInfo, text: String): AccessibilityNodeInfo? {
        val nodeText = node.text?.toString() ?: ""
        if (nodeText.equals(text, ignoreCase = true)) {
            return node
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findNodeByText(child, text)
            if (found != null) return found
        }
        
        return null
    }
    
    // ==================== 学习机制 ====================
    
    /**
     * 学习成功模式
     */
    private fun learnPattern(errorType: ErrorType, successStrategy: ManagerRecoveryStrategy) {
        learnedPatterns[errorType] = successStrategy
        LogManager.w(TAG, "学习新模式: $errorType -> $successStrategy")
    }
    
    /**
     * 记录错误
     */
    private fun recordError(
        errorType: ErrorType,
        context: ErrorContext,
        attempts: List<RecoveryAttempt>,
        outcome: RecoveryOutcome
    ) {
        val record = ErrorRecord(
            timestamp = System.currentTimeMillis(),
            errorType = errorType,
            description = "Error in ${context.action} on ${context.targetElement}",
            context = context,
            recoveryAttempts = attempts,
            finalOutcome = outcome
        )
        
        errorHistory.add(record)
        
        // 限制历史记录大小
        if (errorHistory.size > MAX_ERROR_HISTORY) {
            errorHistory.removeAt(0)
        }
    }
    
    // ==================== 📊 统计信息 ====================
    
    /**
     * 📊 获取错误统计
     */
    fun getErrorStatistics(): ErrorStatistics {
        val records = errorHistory.toList()
        
        val typeDistribution = records.groupBy { it.errorType }
            .mapValues { it.value.size }
        
        val recoveryRate = if (records.isNotEmpty()) {
            records.count { it.finalOutcome == RecoveryOutcome.RECOVERED }.toFloat() / records.size
        } else 0f
        
        return ErrorStatistics(
            totalErrors = records.size,
            recoveredCount = records.count { it.finalOutcome == RecoveryOutcome.RECOVERED },
            failedCount = records.count { it.finalOutcome == RecoveryOutcome.FAILED },
            recoveryRate = recoveryRate,
            typeDistribution = typeDistribution,
            learnedPatterns = learnedPatterns.size
        )
    }
    
    /**
     * 📜 获取错误历史
     */
    fun getErrorHistory(): List<ErrorRecord> = errorHistory.toList()
    
    /**
     * 🧹 清空数据
     */
    fun clearData() {
        errorHistory.clear()
        learnedPatterns.clear()
    }
}

/**
 * 📊 错误统计
 */
data class ErrorStatistics(
    val totalErrors: Int,
    val recoveredCount: Int,
    val failedCount: Int,
    val recoveryRate: Float,
    val typeDistribution: Map<ErrorRecoveryManager.ErrorType, Int>,
    val learnedPatterns: Int
)
