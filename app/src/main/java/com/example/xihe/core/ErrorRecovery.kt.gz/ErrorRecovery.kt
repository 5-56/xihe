package com.example.xihe.core

import com.example.xihe.utils.LogManager
import kotlinx.coroutines.delay

/**
 * 错误恢复策略
 *
 * 用于自动化任务中的智能错误处理和重试
 *
 * @deprecated 此类已废弃，请使用 [UnifiedErrorRecovery] 替代。
 * 新类整合了 ErrorRecovery、ErrorRecoveryManager、IntelligentErrorRecovery 的功能，
 * 提供更完善的错误处理和恢复机制。
 *
 * @see UnifiedErrorRecovery
 */
@Deprecated(
    message = "请使用 UnifiedErrorRecovery 替代",
    replaceWith = ReplaceWith("UnifiedErrorRecovery.getInstance(context)")
)
object ErrorRecovery {
    private const val TAG = "ErrorRecovery"

    /**
     * 重试配置
     */
    data class RetryConfig(
        val maxRetries: Int = 3,
        val delayMs: Long = 1000,
        val exponentialBackoff: Boolean = true,
        val backoffMultiplier: Double = 2.0
    )

    /**
     * 错误类型
     */
    enum class ErrorType {
        NODE_NOT_FOUND,      // 目标节点未找到
        ACTION_FAILED,       // 动作执行失败
        SCREEN_UNCHANGED,    // 屏幕状态未改变
        TIMEOUT,             // 操作超时
        PERMISSION_DENIED,   // 权限被拒绝
        SERVICE_DISCONNECTED,// 服务断开
        NETWORK_ERROR,       // 网络错误
        UNKNOWN              // 未知错误
    }

    /**
     * 错误恢复策略
     */
    enum class BasicRecoveryStrategy {
        RETRY,               // 重试相同操作
        ALTERNATIVE,         // 尝试替代方案
        BACK_AND_RETRY,      // 返回后重试
        RESTART_APP,         // 重启应用
        GIVE_UP              // 放弃任务
    }

    /**
     * 错误上下文
     */
    data class ErrorContext(
        val errorType: ErrorType,
        val message: String,
        val attemptCount: Int = 0,
        val lastCommand: AICommand? = null
    )

    /**
     * 根据错误类型选择恢复策略
     */
    fun chooseRecoveryStrategy(context: ErrorContext): BasicRecoveryStrategy {
        return when (context.errorType) {
            ErrorType.NODE_NOT_FOUND -> {
                if (context.attemptCount < 2) {
                    BasicRecoveryStrategy.RETRY // 等待元素出现
                } else {
                    BasicRecoveryStrategy.ALTERNATIVE // 尝试其他方式
                }
            }
            ErrorType.ACTION_FAILED -> {
                if (context.attemptCount < 3) {
                    BasicRecoveryStrategy.RETRY
                } else {
                    BasicRecoveryStrategy.BACK_AND_RETRY // 返回重试
                }
            }
            ErrorType.SCREEN_UNCHANGED -> {
                if (context.attemptCount < 2) {
                    BasicRecoveryStrategy.RETRY
                } else {
                    BasicRecoveryStrategy.ALTERNATIVE
                }
            }
            ErrorType.TIMEOUT -> {
                BasicRecoveryStrategy.RETRY
            }
            ErrorType.PERMISSION_DENIED -> {
                BasicRecoveryStrategy.GIVE_UP // 权限问题需要用户介入
            }
            ErrorType.SERVICE_DISCONNECTED -> {
                BasicRecoveryStrategy.GIVE_UP // 服务断开需要重新连接
            }
            ErrorType.NETWORK_ERROR -> {
                if (context.attemptCount < 3) {
                    BasicRecoveryStrategy.RETRY
                } else {
                    BasicRecoveryStrategy.GIVE_UP
                }
            }
            ErrorType.UNKNOWN -> {
                if (context.attemptCount < 2) {
                    BasicRecoveryStrategy.RETRY
                } else {
                    BasicRecoveryStrategy.GIVE_UP
                }
            }
        }
    }

    /**
     * 执行重试操作（带指数退避）
     */
    suspend fun <T> retryWithBackoff(
        config: RetryConfig = RetryConfig(),
        block: suspend (attemptNumber: Int) -> T
    ): Result<T> {
        var currentDelay = config.delayMs
        var lastException: Exception? = null

        repeat(config.maxRetries) { attempt ->
            try {
                val result = block(attempt + 1)
                return Result.success(result)
            } catch (e: Exception) {
                lastException = e
                LogManager.w(TAG, "Attempt ${attempt + 1} failed: ${e.message}")

                if (attempt < config.maxRetries - 1) {
                    delay(currentDelay)

                    if (config.exponentialBackoff) {
                        currentDelay = (currentDelay * config.backoffMultiplier).toLong()
                    }
                }
            }
        }

        return Result.failure(lastException ?: Exception("All retries failed"))
    }

    /**
     * 检查屏幕是否发生变化
     */
    fun hasScreenChanged(oldState: ScreenState?, newState: ScreenState?): Boolean {
        if (oldState == null || newState == null) return true

        // 简单比较：检查包名和根节点类名
        if (oldState.packageName != newState.packageName) return true
        if (oldState.root.className != newState.root.className) return true

        // 检查可见元素数量
        val oldNodeCount = countNodes(oldState.root)
        val newNodeCount = countNodes(newState.root)

        // 如果节点数量变化超过10%，认为屏幕已改变
        val changePercentage = kotlin.math.abs(newNodeCount - oldNodeCount).toFloat() / oldNodeCount
        return changePercentage > 0.1f
    }

    private fun countNodes(node: ScreenNode): Int {
        return 1 + node.children.sumOf { countNodes(it) }
    }

    /**
     * 生成错误报告（用于AI分析）
     */
    fun generateErrorReport(context: ErrorContext): String {
        return buildString {
            appendLine("错误报告:")
            appendLine("- 类型: ${context.errorType}")
            appendLine("- 消息: ${context.message}")
            appendLine("- 尝试次数: ${context.attemptCount}")
            context.lastCommand?.let {
                appendLine("- 上次命令: ${it.action}")
                appendLine("- 上次思考: ${it.thought}")
            }
            appendLine("- 建议策略: ${chooseRecoveryStrategy(context)}")
        }
    }

    /**
     * 智能等待（等待UI稳定）
     */
    suspend fun waitForUIStable(
        checkInterval: Long = 500,
        maxWaitTime: Long = 5000,
        stabilityCheck: suspend () -> Boolean
    ): Boolean {
        val startTime = System.currentTimeMillis()
        var consecutiveStable = 0
        val requiredStableChecks = 3 // 连续3次检查都稳定

        while (System.currentTimeMillis() - startTime < maxWaitTime) {
            if (stabilityCheck()) {
                consecutiveStable++
                if (consecutiveStable >= requiredStableChecks) {
                    LogManager.d(TAG, "UI stable after ${System.currentTimeMillis() - startTime}ms")
                    return true
                }
            } else {
                consecutiveStable = 0
            }

            delay(checkInterval)
        }

        LogManager.w(TAG, "UI stability timeout after ${maxWaitTime}ms")
        return false
    }
}
