package com.example.xihe.core

import android.graphics.Rect
import com.example.xihe.utils.LogManager
import android.view.accessibility.AccessibilityNodeInfo
import com.example.xihe.screen.ScreenAnalyzer
import kotlinx.coroutines.delay

/**
 * ✅ 操作验证器
 * 验证设备操作是否成功执行
 */
class ActionVerifier {
    
    companion object {
        private const val TAG = "ActionVerifier"
    }
    
    private val screenAnalyzer = ScreenAnalyzer()
    
    // ==================== 📊 数据类 ====================
    
    /**
     * 🔍 验证结果
     */
    data class VerifyResult(
        val success: Boolean,
        val confidence: Float,  // 0-1 置信度
        val reason: String,
        val details: Map<String, Any> = emptyMap()
    )
    
    /**
     * 📸 屏幕快照
     */
    data class ScreenSnapshot(
        val packageName: String,
        val elementCount: Int,
        val clickableElements: List<ElementSnapshot>,
        val visibleTexts: Set<String>,
        val timestamp: Long = System.currentTimeMillis()
    )
    
    /**
     * 📦 元素快照
     */
    data class ElementSnapshot(
        val id: String,
        val text: String?,
        val bounds: Rect,
        val isChecked: Boolean,
        val isSelected: Boolean
    )
    
    // ==================== 🖱️ 点击验证 ====================
    
    /**
     * 🖱️ 验证点击操作
     */
    suspend fun verifyClick(
        beforeSnapshot: ScreenSnapshot?,
        afterRoot: AccessibilityNodeInfo?,
        targetElement: ElementSnapshot?,
        expectedChanges: List<ExpectedChange> = emptyList()
    ): VerifyResult {
        LogManager.d(TAG, "🖱️ 验证点击操作")
        
        if (afterRoot == null) {
            return VerifyResult(
                success = false,
                confidence = 0f,
                reason = "无法获取操作后的屏幕状态"
            )
        }
        
        val afterSnapshot = takeSnapshot(afterRoot)
        
        // 检查期望的变化
        if (expectedChanges.isNotEmpty()) {
            val matchedChanges = expectedChanges.filter { change ->
                verifyExpectedChange(beforeSnapshot, afterSnapshot, change)
            }
            
            if (matchedChanges.isNotEmpty()) {
                return VerifyResult(
                    success = true,
                    confidence = matchedChanges.size.toFloat() / expectedChanges.size,
                    reason = "检测到期望的变化: ${matchedChanges.map { it.type }}",
                    details = mapOf("matchedChanges" to matchedChanges.size)
                )
            }
        }
        
        // 默认验证：检查屏幕是否有变化
        if (beforeSnapshot != null) {
            val changes = detectChanges(beforeSnapshot, afterSnapshot)
            
            if (changes.isNotEmpty()) {
                return VerifyResult(
                    success = true,
                    confidence = 0.8f,
                    reason = "检测到屏幕变化: $changes",
                    details = mapOf("changes" to changes)
                )
            }
            
            // 如果目标元素消失，也算成功
            if (targetElement != null) {
                val stillExists = findElementInSnapshot(afterSnapshot, targetElement)
                if (!stillExists) {
                    return VerifyResult(
                        success = true,
                        confidence = 0.7f,
                        reason = "目标元素已消失（可能触发了导航）"
                    )
                }
            }
        }
        
        // 无法确定，返回中等置信度
        return VerifyResult(
            success = true,
            confidence = 0.5f,
            reason = "无法检测到明显变化，假设操作成功"
        )
    }
    
    /**
     * 📜 验证滑动操作
     */
    suspend fun verifyScroll(
        beforeSnapshot: ScreenSnapshot?,
        afterRoot: AccessibilityNodeInfo?,
        direction: ScrollDirection
    ): VerifyResult {
        LogManager.d(TAG, "📜 验证滑动操作: $direction")
        
        if (afterRoot == null || beforeSnapshot == null) {
            return VerifyResult(
                success = true,
                confidence = 0.5f,
                reason = "无法比较，假设滑动成功"
            )
        }
        
        val afterSnapshot = takeSnapshot(afterRoot)
        
        // 检查可见文本是否变化
        val textsBefore = beforeSnapshot.visibleTexts
        val textsAfter = afterSnapshot.visibleTexts
        
        val newTexts = textsAfter - textsBefore
        val removedTexts = textsBefore - textsAfter
        
        if (newTexts.isNotEmpty() || removedTexts.isNotEmpty()) {
            return VerifyResult(
                success = true,
                confidence = 0.9f,
                reason = "内容已滚动: 新增${newTexts.size}项, 移除${removedTexts.size}项",
                details = mapOf(
                    "newTexts" to newTexts.take(5),
                    "removedTexts" to removedTexts.take(5)
                )
            )
        }
        
        // 检查元素位置是否变化
        val positionChanged = checkPositionChange(beforeSnapshot, afterSnapshot)
        if (positionChanged) {
            return VerifyResult(
                success = true,
                confidence = 0.8f,
                reason = "元素位置已变化"
            )
        }
        
        return VerifyResult(
            success = true,
            confidence = 0.4f,
            reason = "未检测到明显滚动效果，可能已到边界"
        )
    }
    
    /**
     * ⌨️ 验证输入操作
     */
    suspend fun verifyInput(
        targetNode: AccessibilityNodeInfo?,
        expectedText: String
    ): VerifyResult {
        LogManager.d(TAG, "⌨️ 验证输入操作")
        
        if (targetNode == null) {
            return VerifyResult(
                success = false,
                confidence = 0f,
                reason = "无法获取输入框状态"
            )
        }
        
        val currentText = targetNode.text?.toString() ?: ""
        
        return when {
            currentText == expectedText -> VerifyResult(
                success = true,
                confidence = 1.0f,
                reason = "输入内容完全匹配"
            )
            currentText.contains(expectedText) -> VerifyResult(
                success = true,
                confidence = 0.9f,
                reason = "输入内容包含期望文本"
            )
            expectedText.contains(currentText) && currentText.isNotEmpty() -> VerifyResult(
                success = true,
                confidence = 0.7f,
                reason = "部分输入成功"
            )
            else -> VerifyResult(
                success = false,
                confidence = 0.1f,
                reason = "输入内容不匹配: 期望'$expectedText', 实际'$currentText'"
            )
        }
    }
    
    // ==================== 📸 快照相关 ====================
    
    /**
     * 📸 拍摄屏幕快照
     */
    fun takeSnapshot(rootNode: AccessibilityNodeInfo): ScreenSnapshot {
        val clickableElements = mutableListOf<ElementSnapshot>()
        val visibleTexts = mutableSetOf<String>()
        var elementCount = 0
        
        traverseNode(rootNode) { node ->
            elementCount++
            
            // 收集文本
            node.text?.toString()?.let { 
                if (it.isNotBlank()) visibleTexts.add(it) 
            }
            node.contentDescription?.toString()?.let { 
                if (it.isNotBlank()) visibleTexts.add(it) 
            }
            
            // 收集可点击元素
            if (node.isClickable && node.isVisibleToUser) {
                val rect = Rect()
                node.getBoundsInScreen(rect)
                clickableElements.add(ElementSnapshot(
                    id = generateElementId(node),
                    text = node.text?.toString(),
                    bounds = rect,
                    isChecked = node.isChecked,
                    isSelected = node.isSelected
                ))
            }
        }
        
        return ScreenSnapshot(
            packageName = rootNode.packageName?.toString() ?: "",
            elementCount = elementCount,
            clickableElements = clickableElements,
            visibleTexts = visibleTexts
        )
    }
    
    /**
     * 🔄 遍历节点
     */
    private fun traverseNode(node: AccessibilityNodeInfo, action: (AccessibilityNodeInfo) -> Unit) {
        action(node)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            traverseNode(child, action)
        }
    }
    
    /**
     * 🆔 生成元素ID
     */
    private fun generateElementId(node: AccessibilityNodeInfo): String {
        val rect = Rect()
        node.getBoundsInScreen(rect)
        return "${node.className}_${rect.centerX()}_${rect.centerY()}"
    }
    
    // ==================== 🔍 变化检测 ====================
    
    /**
     * 🔍 检测屏幕变化
     */
    private fun detectChanges(before: ScreenSnapshot, after: ScreenSnapshot): List<String> {
        val changes = mutableListOf<String>()
        
        // 应用包名变化
        if (before.packageName != after.packageName) {
            changes.add("APP_CHANGED")
        }
        
        // 元素数量显著变化
        val elementDiff = kotlin.math.abs(before.elementCount - after.elementCount)
        if (elementDiff > 5) {
            changes.add("ELEMENT_COUNT_CHANGED")
        }
        
        // 可见文本变化
        val newTexts = after.visibleTexts - before.visibleTexts
        val removedTexts = before.visibleTexts - after.visibleTexts
        if (newTexts.size > 2 || removedTexts.size > 2) {
            changes.add("TEXT_CONTENT_CHANGED")
        }
        
        // 可点击元素变化
        val clickableDiff = kotlin.math.abs(
            before.clickableElements.size - after.clickableElements.size
        )
        if (clickableDiff > 2) {
            changes.add("CLICKABLE_ELEMENTS_CHANGED")
        }
        
        return changes
    }
    
    /**
     * ✅ 验证期望的变化
     */
    private fun verifyExpectedChange(
        before: ScreenSnapshot?,
        after: ScreenSnapshot,
        expectedChange: ExpectedChange
    ): Boolean {
        return when (expectedChange.type) {
            ChangeType.ELEMENT_DISAPPEAR -> {
                expectedChange.targetText?.let { text ->
                    before?.visibleTexts?.contains(text) == true &&
                    !after.visibleTexts.contains(text)
                } ?: false
            }
            ChangeType.ELEMENT_APPEAR -> {
                expectedChange.targetText?.let { text ->
                    before?.visibleTexts?.contains(text) != true &&
                    after.visibleTexts.contains(text)
                } ?: false
            }
            ChangeType.APP_SWITCH -> {
                before?.packageName != after.packageName
            }
            ChangeType.DIALOG_APPEAR -> {
                // 简化检测：元素数量增加且有新的可点击元素
                before != null && after.clickableElements.size > before.clickableElements.size
            }
            ChangeType.DIALOG_DISAPPEAR -> {
                before != null && after.clickableElements.size < before.clickableElements.size
            }
            ChangeType.CHECKBOX_TOGGLE -> {
                expectedChange.targetText?.let { text ->
                    val beforeElement = before?.clickableElements?.find { it.text == text }
                    val afterElement = after.clickableElements.find { it.text == text }
                    beforeElement != null && afterElement != null &&
                    beforeElement.isChecked != afterElement.isChecked
                } ?: false
            }
            ChangeType.ANY_CHANGE -> {
                before?.let { detectChanges(it, after).isNotEmpty() } ?: true
            }
        }
    }
    
    /**
     * 🔍 在快照中查找元素
     */
    private fun findElementInSnapshot(snapshot: ScreenSnapshot, target: ElementSnapshot): Boolean {
        return snapshot.clickableElements.any { element ->
            element.id == target.id ||
            (element.text == target.text && element.text != null)
        }
    }
    
    /**
     * 📍 检查位置变化
     */
    private fun checkPositionChange(before: ScreenSnapshot, after: ScreenSnapshot): Boolean {
        // 找到相同文本的元素，检查位置是否变化
        for (beforeElement in before.clickableElements.take(10)) {
            val text = beforeElement.text ?: continue
            val afterElement = after.clickableElements.find { it.text == text } ?: continue
            
            val yDiff = kotlin.math.abs(beforeElement.bounds.centerY() - afterElement.bounds.centerY())
            if (yDiff > 50) {
                return true
            }
        }
        return false
    }
}

/**
 * 🔄 期望的变化
 */
data class ExpectedChange(
    val type: ChangeType,
    val targetText: String? = null,
    val targetId: String? = null
)

/**
 * 📋 变化类型
 */
enum class ChangeType {
    ELEMENT_DISAPPEAR,    // 元素消失
    ELEMENT_APPEAR,       // 元素出现
    APP_SWITCH,           // 应用切换
    DIALOG_APPEAR,        // 对话框出现
    DIALOG_DISAPPEAR,     // 对话框消失
    CHECKBOX_TOGGLE,      // 复选框切换
    ANY_CHANGE            // 任意变化
}
