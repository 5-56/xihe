package com.example.xihe.core

import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.intelligence.MemorySystem
import com.example.xihe.training.OnDeviceLearner

/**
 * 统一记忆管理器
 * 
 * 解决问题：ContextMemory 和 MemorySystem 功能重叠
 * 
 * 设计说明：
 * ============
 * 1. ContextMemory - 主要记忆系统（短期+长期记忆、用户画像、上下文生成）
 * 2. MemorySystem - 辅助系统（知识图谱、习惯学习、深度分析）
 * 3. OnDeviceLearner - 学习系统（意图分类、模式匹配）
 * 
 * 本类作为统一入口，协调三个系统的工作，避免重复存储和不一致。
 * 
 * 使用方式：
 * ```kotlin
 * val memory = UnifiedMemoryManager.getInstance(context)
 * 
 * // 记录对话（自动同步到所有系统）
 * memory.recordConversation(userInput, aiResponse)
 * 
 * // 获取上下文（整合所有系统的信息）
 * val context = memory.getUnifiedContext()
 * ```
 */
object UnifiedMemoryManager {
    private const val TAG = "UnifiedMemory"
    
    private var isInitialized = false
    private lateinit var appContext: Context
    
    // 三个子系统
    private val contextMemory: ContextMemory get() = ContextMemory
    private val memorySystem: MemorySystem by lazy { MemorySystem.getInstance(appContext) }
    private val learner: OnDeviceLearner by lazy { OnDeviceLearner.getInstance(appContext) }
    
    /**
     * 初始化统一记忆管理器
     */
    fun init(context: Context) {
        if (isInitialized) return
        
        appContext = context.applicationContext
        
        // 初始化 ContextMemory
        contextMemory.init(appContext)
        
        // MemorySystem 和 OnDeviceLearner 使用懒加载
        
        isInitialized = true
        LogManager.d(TAG, "统一记忆管理器初始化完成")
    }
    
    /**
     * 记录对话（同步到所有系统）
     * 
     * 这是添加对话记忆的统一入口，会自动：
     * 1. 保存到 ContextMemory（短期+长期记忆）
     * 2. 同步到 MemorySystem（知识提取）
     * 3. 发送到 OnDeviceLearner（模式学习）
     */
    fun recordConversation(
        userInput: String,
        aiResponse: String,
        tags: List<String> = emptyList()
    ) {
        checkInitialized()
        
        // 1. ContextMemory - 主记忆存储
        contextMemory.addMemory(appContext, userInput, aiResponse, tags)
        
        // 2. MemorySystem - 知识提取（异步）
        try {
            memorySystem.learnFromConversation(userInput, aiResponse)
        } catch (e: Exception) {
            LogManager.w(TAG, "MemorySystem 学习失败", e)
        }
        
        // 3. OnDeviceLearner - 模式学习（异步）
        try {
            learner.learnFromConversation(userInput, aiResponse)
        } catch (e: Exception) {
            LogManager.w(TAG, "OnDeviceLearner 学习失败", e)
        }
        
        LogManager.d(TAG, "对话已同步到所有记忆系统")
    }
    
    /**
     * 获取统一上下文（整合所有系统）
     * 
     * 返回格式化的上下文字符串，可直接用于 LLM prompt
     */
    fun getUnifiedContext(): String {
        checkInitialized()
        
        val sb = StringBuilder()
        
        // 1. 从 ContextMemory 获取基础上下文
        sb.append(contextMemory.generateContextSummary())
        
        // 2. 从 MemorySystem 获取补充信息
        try {
            val profile = memorySystem.userProfile.value
            if (profile.habits.isNotEmpty()) {
                sb.append("\n【用户习惯】\n")
                profile.habits.take(5).forEach { habit ->
                    sb.append("- ${habit.description}\n")
                }
            }
        } catch (e: Exception) {
            LogManager.w(TAG, "获取 MemorySystem 信息失败", e)
        }
        
        return sb.toString()
    }
    
    /**
     * 获取精简上下文（用于系统提示词）
     */
    fun getCompactContext(): String {
        checkInitialized()
        return contextMemory.generateCompactSummary()
    }
    
    /**
     * 智能查询记忆
     */
    fun queryMemory(keyword: String): List<MemoryQueryResult> {
        checkInitialized()
        
        val results = mutableListOf<MemoryQueryResult>()
        
        // 从 ContextMemory 查询长期记忆
        contextMemory.queryLongTermMemory(keyword).forEach { memory ->
            results.add(MemoryQueryResult(
                source = "长期记忆",
                key = memory.key,
                value = memory.value,
                confidence = memory.confidence
            ))
        }
        
        // 从 OnDeviceLearner 查询相似模式
        try {
            learner.findSimilarPatterns(keyword, topK = 3).forEach { pattern ->
                results.add(MemoryQueryResult(
                    source = "历史对话",
                    key = pattern.input,
                    value = pattern.response,
                    confidence = pattern.similarity
                ))
            }
        } catch (e: Exception) {
            LogManager.w(TAG, "OnDeviceLearner 查询失败", e)
        }
        
        return results.sortedByDescending { it.confidence }
    }
    
    /**
     * 设置用户昵称
     */
    fun setUserNickname(nickname: String) {
        checkInitialized()
        contextMemory.setUserNickname(appContext, nickname)
    }
    
    /**
     * 设置AI名字
     */
    fun setAIName(name: String) {
        checkInitialized()
        contextMemory.setAIName(appContext, name)
    }
    
    /**
     * 获取用户昵称
     */
    fun getUserNickname(): String = contextMemory.getUserNickname()
    
    /**
     * 获取AI名字
     */
    fun getAIName(): String = contextMemory.getAIName()
    
    /**
     * 获取记忆统计
     */
    fun getMemoryStats(): UnifiedMemoryStats {
        checkInitialized()
        
        val contextStats = contextMemory.getMemoryStats()
        val learnerStats = try { learner.getStatistics() } catch (e: Exception) { null }
        
        return UnifiedMemoryStats(
            shortTermCount = contextStats["shortTermCount"] as? Int ?: 0,
            longTermCount = contextStats["longTermCount"] as? Int ?: 0,
            importantPeopleCount = contextStats["importantPeopleCount"] as? Int ?: 0,
            learnedPatternsCount = learnerStats?.patternCount ?: 0,
            vocabularySize = learnerStats?.vocabularySize ?: 0,
            totalInteractions = contextStats["totalInteractions"] as? Int ?: 0
        )
    }
    
    /**
     * 清除所有记忆（谨慎使用）
     */
    fun clearAllMemory() {
        checkInitialized()
        contextMemory.clearAllMemory(appContext)
        LogManager.w(TAG, "所有记忆已清除")
    }
    
    private fun checkInitialized() {
        if (!isInitialized) {
            throw IllegalStateException("UnifiedMemoryManager 未初始化，请先调用 init()")
        }
    }
}

/**
 * 记忆查询结果
 */
data class MemoryQueryResult(
    val source: String,      // 来源：长期记忆、历史对话
    val key: String,         // 键/问题
    val value: String,       // 值/回答
    val confidence: Float    // 置信度
)

/**
 * 统一记忆统计
 */
data class UnifiedMemoryStats(
    val shortTermCount: Int,        // 短期记忆数量
    val longTermCount: Int,         // 长期记忆数量
    val importantPeopleCount: Int,  // 重要人物数量
    val learnedPatternsCount: Int,  // 学习到的模式数量
    val vocabularySize: Int,        // 词汇表大小
    val totalInteractions: Int      // 总交互次数
)
