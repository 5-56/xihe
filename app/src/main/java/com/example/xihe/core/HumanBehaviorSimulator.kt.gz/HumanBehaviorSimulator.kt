package com.example.xihe.core

import kotlinx.coroutines.delay
import kotlin.random.Random

/**
 * 人类行为模拟器 🤖→👤
 * 让 AI 的操作更像真人，避免被检测为机器人
 */
object HumanBehaviorSimulator {
    
    /**
     * 模拟人类浏览网页
     * - 随机滚动
     * - 随机停顿
     * - 偶尔回滚
     */
    suspend fun simulateBrowsing(
        scrollAction: suspend (direction: String) -> Unit,
        durationSeconds: Int = 10
    ) {
        val startTime = System.currentTimeMillis()
        val endTime = startTime + (durationSeconds * 1000)
        
        while (System.currentTimeMillis() < endTime) {
            // 随机滚动方向（90% 向下，10% 向上）
            val direction = if (Random.nextFloat() < 0.9f) "DOWN" else "UP"
            scrollAction(direction)
            
            // 随机停顿 1-3 秒（模拟阅读）
            delay(Random.nextLong(1000, 3000))
            
            // 10% 概率快速连续滚动（模拟快速浏览）
            if (Random.nextFloat() < 0.1f) {
                repeat(Random.nextInt(2, 5)) {
                    scrollAction("DOWN")
                    delay(300)
                }
            }
        }
    }
    
    /**
     * 模拟人类刷视频
     * - 观看时长随机（5-15秒）
     * - 偶尔快速跳过
     * - 模拟真实滑动速度
     */
    suspend fun simulateVideoSwiping(
        swipeAction: suspend () -> Unit,
        videoCount: Int = 10
    ) {
        repeat(videoCount) { index ->
            // 80% 的视频会正常观看
            if (Random.nextFloat() < 0.8f) {
                // 随机观看时长 5-15 秒
                val watchDuration = Random.nextLong(5000, 15000)
                delay(watchDuration)
            } else {
                // 20% 的视频快速跳过（0.5-2秒）
                delay(Random.nextLong(500, 2000))
            }
            
            // 滑动到下一个视频
            swipeAction()
            
            // 滑动后短暂停顿（模拟视频加载）
            delay(Random.nextLong(300, 800))
        }
    }
    
    /**
     * 模拟人类输入延迟
     * 返回每个字符之间的延迟时间（毫秒）
     */
    fun getTypingDelay(): Long {
        // 人类打字速度：50-150ms 每个字符
        return Random.nextLong(50, 150)
    }
    
    /**
     * 模拟人类点击前的犹豫
     */
    suspend fun hesitateBeforeClick() {
        // 随机犹豫 100-500ms
        delay(Random.nextLong(100, 500))
    }
}
