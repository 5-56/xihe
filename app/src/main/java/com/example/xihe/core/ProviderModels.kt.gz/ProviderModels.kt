package com.example.xihe.core

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.SerialName
import kotlinx.serialization.encodeToString
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import com.example.xihe.utils.LogManager

@Serializable
data class ProviderConfig(
    val id: String,
    val name: String,
    val defaultBaseUrl: String,
    val requiresModelFetch: Boolean = false,
    val isCustom: Boolean = false,  // 🆕 标记是否为自定义提供商
    val apiFormat: String = "openai"  // 🆕 API格式: "openai" 或 "huggingface"
)

object ProviderRegistry {
    private const val CUSTOM_PROVIDERS_KEY = "custom_providers"
    
    // 预定义的提供商列表
    private val builtInProviders = listOf(
        ProviderConfig("openai", "OpenAI", "https://api.openai.com/v1/"),
        ProviderConfig("deepseek", "DeepSeek", "https://api.deepseek.com/v1/"),
        ProviderConfig("moonshot", "Kimi (Moonshot)", "https://api.moonshot.cn/v1/"),
        ProviderConfig("openrouter", "OpenRouter", "https://openrouter.ai/api/v1/"),
        // Google 原生 API (generateContent) - 使用 x-goog-api-key 认证
        ProviderConfig("google", "Google Gemini (原生)", "https://generativelanguage.googleapis.com/v1beta/"),
        // Google OpenAI 兼容端点 - 使用 Bearer token 认证
        ProviderConfig("google_openai", "Google Gemini (OpenAI兼容)", "https://generativelanguage.googleapis.com/v1beta/openai/"),
        ProviderConfig("zhipu", "Zhipu AI (GLM)", "https://open.bigmodel.cn/api/paas/v4/"),
        // GitCode AI - 使用 Hugging Face Inference API 格式
        // Base URL 格式: https://api.gitcode.com/v1/models/username/model-name
        // 请求格式: {"inputs": "..."} 而不是 {"messages": [...]}
        ProviderConfig(
            id = "gitcode", 
            name = "GitCode AI (HuggingFace)", 
            defaultBaseUrl = "https://api.gitcode.com/v1/models/",
            apiFormat = "huggingface"
        ),
        // SiliconFlow - 支持 Qwen、DeepSeek 等模型，使用 OpenAI 兼容格式
        ProviderConfig("siliconflow", "SiliconFlow", "https://api.siliconflow.cn/v1/"),
        // 万清 AI - StreamLake API Gateway，使用 OpenAI 兼容格式
        ProviderConfig("wanqing", "万清 AI (WanQing)", "https://wanqing.streamlakeapi.com/api/gateway/v1/endpoints/"),
        ProviderConfig("local", "💻 本地模型 (Ollama)", "http://localhost:11434/v1/", requiresModelFetch = true)
    )
    
    // 自定义提供商列表（从持久化存储中加载）
    private var customProviders = mutableListOf<ProviderConfig>()
    
    private val json = Json { 
        ignoreUnknownKeys = true
        prettyPrint = true 
    }
    
    // 获取所有提供商（内置 + 自定义）
    val providers: List<ProviderConfig>
        get() = builtInProviders + customProviders
    
    /**
     * 🆕 初始化 - 从 SharedPreferences 加载自定义提供商
     */
    fun initialize(context: Context) {
        loadCustomProviders(context)
    }
    
    /**
     * 🆕 添加自定义提供商
     */
    fun addCustomProvider(context: Context, name: String, baseUrl: String): Boolean {
        // 生成唯一 ID
        val id = "custom_${System.currentTimeMillis()}"
        
        // 检查名称是否已存在
        if (providers.any { it.name.equals(name, ignoreCase = true) }) {
            return false
        }
        
        val provider = ProviderConfig(
            id = id,
            name = name,
            defaultBaseUrl = baseUrl,
            requiresModelFetch = false,
            isCustom = true
        )
        
        customProviders.add(provider)
        saveCustomProviders(context)
        return true
    }
    
    /**
     * 🆕 更新自定义提供商
     */
    fun updateCustomProvider(context: Context, id: String, name: String, baseUrl: String): Boolean {
        val index = customProviders.indexOfFirst { it.id == id }
        if (index == -1) return false
        
        customProviders[index] = customProviders[index].copy(
            name = name,
            defaultBaseUrl = baseUrl
        )
        
        saveCustomProviders(context)
        return true
    }
    
    /**
     * 🆕 删除自定义提供商
     */
    fun deleteCustomProvider(context: Context, id: String): Boolean {
        val removed = customProviders.removeIf { it.id == id }
        if (removed) {
            saveCustomProviders(context)
        }
        return removed
    }
    
    /**
     * 🆕 根据 ID 获取提供商
     */
    fun getProviderById(id: String): ProviderConfig? {
        return providers.find { it.id == id }
    }
    
    /**
     * 🆕 获取所有提供商（便捷方法）
     */
    fun getAllProviders(): List<ProviderConfig> {
        return providers
    }
    
    /**
     * 🆕 获取当前使用的提供商
     */
    fun getCurrentProvider(context: Context): ProviderConfig? {
        val currentId = com.example.xihe.core.PreferencesManager.getCurrentProviderId(context)
        val provider = getProviderById(currentId)
        
        // 如果提供商不存在（比如已被移除），切换到默认提供商
        if (provider == null && currentId.isNotEmpty()) {
            LogManager.w("ProviderRegistry", "⚠️ 提供商 '$currentId' 不存在，切换到默认提供商")
            setCurrentProvider(context, "deepseek")
            return getProviderById("deepseek")
        }
        
        return provider
    }
    
    /**
     * 🆕 设置当前使用的提供商
     */
    fun setCurrentProvider(context: Context, providerId: String) {
        com.example.xihe.core.PreferencesManager.saveCurrentProviderId(context, providerId)
    }
    
    /**
     * 保存自定义提供商到 SharedPreferences
     */
    private fun saveCustomProviders(context: Context) {
        try {
            val jsonString = json.encodeToString(customProviders)
            context.getSharedPreferences("xihe_preferences", Context.MODE_PRIVATE)
                .edit()
                .putString(CUSTOM_PROVIDERS_KEY, jsonString)
                .apply()
        } catch (e: Exception) {
            LogManager.e("ProviderRegistry", "保存自定义提供商失败", e)
        }
    }
    
    /**
     * 从 SharedPreferences 加载自定义提供商
     */
    private fun loadCustomProviders(context: Context) {
        try {
            val prefs = context.getSharedPreferences("xihe_preferences", Context.MODE_PRIVATE)
            val jsonString = prefs.getString(CUSTOM_PROVIDERS_KEY, null)
            if (!jsonString.isNullOrEmpty()) {
                customProviders = json.decodeFromString<MutableList<ProviderConfig>>(jsonString)
            }
        } catch (e: Exception) {
            LogManager.e("ProviderRegistry", "加载自定义提供商失败", e)
            customProviders = mutableListOf()
        }
    }
}

@Serializable
data class ModelListResponse(
    val data: List<ModelInfo>
)

@Serializable
data class ModelInfo(
    val id: String
)
