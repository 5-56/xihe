package com.example.xihe.core

import com.example.xihe.utils.LogManager
import com.example.xihe.understanding.ContextAwareIntentEngine
import com.example.xihe.data.ConversationDataManager
import com.example.xihe.data.ConversationRecord

/**
 * 🔧 AutomationEngine 辅助工具
 * 用于更新执行结果到上下文引擎和对话数据管理器
 */
object AutomationEngineHelper {
    private const val TAG = "EngineHelper"
    
    /**
     * 更新任务执行结果到深度理解系统和对话数据管理器
     */
    fun updateExecutionResult(
        contextEngine: ContextAwareIntentEngine?,
        dataManager: ConversationDataManager?,
        userInput: String,
        intent: UserIntent?,
        systemResponse: String,
        success: Boolean
    ) {
        // 1. 更新到上下文引擎
        if (contextEngine != null) {
            try {
                contextEngine.updateExecutionResult(
                    userInput = userInput,
                    intent = intent,
                    systemResponse = systemResponse,
                    success = success
                )
                LogManager.d(TAG, "✅ 执行结果已更新到上下文")
            } catch (e: Exception) {
                LogManager.w(TAG, "更新上下文失败", e)
            }
        }
        
        // 2. 记录到对话数据管理器
        if (dataManager != null) {
            try {
                // 获取上下文摘要
                val contextSummary = contextEngine?.getHistorySummary(3) ?: ""
                
                // 创建对话记录
                val record = ConversationRecord(
                    userInput = userInput,
                    systemResponse = systemResponse,
                    recognizedIntent = intent?.type,
                    entities = intent?.entities ?: emptyMap(),
                    executionSuccess = success,
                    contextSummary = contextSummary
                )
                
                // 保存记录
                dataManager.recordConversation(record)
                LogManager.d(TAG, "✅ 对话记录已保存: $userInput")
            } catch (e: Exception) {
                LogManager.w(TAG, "保存对话记录失败", e)
            }
        }
    }
}
