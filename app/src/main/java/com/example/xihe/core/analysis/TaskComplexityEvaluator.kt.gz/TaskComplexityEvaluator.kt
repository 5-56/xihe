package com.example.xihe.core.analysis

import com.example.xihe.core.model.TaskComplexity
import com.example.xihe.core.model.TaskComplexityLevel
import com.example.xihe.core.UserIntent

/**
 * 🧠 任务复杂度评估器
 * 用于评估用户目标的执行难度，决定是否使用智能 Agent
 */
object TaskComplexityEvaluator {

    /**
     * 评估任务复杂度
     * 
     * @param goal 用户目标
     * @param intent 意图识别结果（可选）
     * @return 复杂度评估结果
     */
    fun evaluate(goal: String, intent: UserIntent?): TaskComplexity {
        val reasons = mutableListOf<String>()
        var score = 0f
        var estimatedSteps = 1
        
        val lowerGoal = goal.lowercase()
        
        // 1. 基于关键词的复杂度评估
        val multiStepKeywords = listOf(
            "然后", "接着", "之后", "完成后", "最后",
            "先.*再", "一边.*一边", "同时"
        )
        if (multiStepKeywords.any { Regex(it).containsMatchIn(lowerGoal) }) {
            score += 0.4f
            estimatedSteps += 2
            reasons.add("包含多步骤关键词")
        }
        
        // 2. 基于动词数量
        val actionVerbs = listOf(
            "打开", "启动", "搜索", "查找", "点击", "输入", "发送",
            "下载", "上传", "分享", "复制", "粘贴", "截图", "录屏"
        )
        val verbCount = actionVerbs.count { lowerGoal.contains(it) }
        if (verbCount >= 2) {
            score += 0.3f * verbCount
            estimatedSteps += verbCount - 1
            reasons.add("包含${verbCount}个操作动词")
        }
        
        // 3. 基于意图识别置信度
        if (intent != null) {
            if (intent.confidence < 0.6f) {
                score += 0.3f
                reasons.add("意图识别置信度较低(${intent.confidence})")
            }
            if (intent.type == "unknown" || intent.type.contains("complex")) {
                score += 0.4f
                reasons.add("意图类型未知或复杂")
            }
        } else {
            score += 0.2f
            reasons.add("无意图识别结果")
        }
        
        // 4. 基于任务描述长度（越长越复杂）
        if (goal.length > 30) {
            score += 0.2f
            reasons.add("任务描述较长(${goal.length}字符)")
        }
        
        // 5. 需要跨应用操作
        val appMentions = listOf("微信", "qq", "抖音", "淘宝", "支付宝", "浏览器").count { lowerGoal.contains(it) }
        if (appMentions >= 2) {
            score += 0.3f
            estimatedSteps += appMentions
            reasons.add("涉及${appMentions}个应用")
        }
        
        // 6. 包含条件判断
        val conditionalKeywords = listOf("如果", "假如", "要是", "当", "的时候", "直到")
        if (conditionalKeywords.any { lowerGoal.contains(it) }) {
            score += 0.4f
            reasons.add("包含条件判断")
        }
        
        // 7. 包含循环操作
        val loopKeywords = listOf("一直", "持续", "不停", "重复", "每", "所有")
        if (loopKeywords.any { lowerGoal.contains(it) }) {
            score += 0.3f
            reasons.add("包含循环操作")
        }
        
        // 限制分数范围
        score = score.coerceIn(0f, 1f)
        
        // 确定复杂度级别
        val level = when {
            score >= 0.7f -> TaskComplexityLevel.COMPLEX
            score >= 0.5f -> TaskComplexityLevel.MULTI_STEP
            score >= 0.3f -> TaskComplexityLevel.MODERATE
            intent?.type == "unknown" -> TaskComplexityLevel.UNKNOWN
            else -> TaskComplexityLevel.SIMPLE
        }
        
        if (reasons.isEmpty()) {
            reasons.add("简单单步任务")
        }
        
        return TaskComplexity(level, score, reasons, estimatedSteps)
    }
}
