package com.example.xihe.core

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import com.example.xihe.utils.LogManager
import com.example.xihe.CoreAccessibilityService

/**
 * 快速指令执行器 ⚡
 * 识别并直接执行简单指令，无需AI分析
 */
object QuickCommandExecutor {
    private const val TAG = "QuickCommandExecutor"
    
    /**
     * 应用名称映射表（超级增强版）🚀
     */
    private val APP_PACKAGE_MAP = mapOf(
        // 社交通讯 💬
        "微信" to "com.tencent.mm",
        "wechat" to "com.tencent.mm",
        "wx" to "com.tencent.mm",
        "qq" to "com.tencent.mobileqq",
        "QQ" to "com.tencent.mobileqq",
        
        // 支付工具 💰
        "支付宝" to "com.eg.android.AlipayGphone",
        "alipay" to "com.eg.android.AlipayGphone",
        "支付" to "com.eg.android.AlipayGphone",
        
        // 短视频 🎬
        "抖音" to "com.ss.android.ugc.aweme",
        "douyin" to "com.ss.android.ugc.aweme",
        "斗音" to "com.ss.android.ugc.aweme",
        "快手" to "com.smile.gifmaker",
        "kuaishou" to "com.smile.gifmaker",
        
        // 电商购物 🛒
        "淘宝" to "com.taobao.taobao",
        "taobao" to "com.taobao.taobao",
        "淘包" to "com.taobao.taobao",
        "京东" to "com.jingdong.app.mall",
        "jd" to "com.jingdong.app.mall",
        "拼多多" to "com.xunmeng.pinduoduo",
        "pdd" to "com.xunmeng.pinduoduo",
        
        // 外卖服务 🍔
        "美团" to "com.sankuai.meituan",
        "meituan" to "com.sankuai.meituan",
        "饿了么" to "me.ele",
        "eleme" to "me.ele",
        "饿了吗" to "me.ele",
        
        // 地图导航 🗺️
        "高德地图" to "com.autonavi.minimap",
        "高德" to "com.autonavi.minimap",
        "gaode" to "com.autonavi.minimap",
        "百度地图" to "com.baidu.BaiduMap",
        "baidu" to "com.baidu.BaiduMap",
        "地图" to "com.autonavi.minimap",
        
        // 视频娱乐 📺
        "哔哩哔哩" to "tv.danmaku.bili",
        "bilibili" to "tv.danmaku.bili",
        "b站" to "tv.danmaku.bili",
        "小红书" to "com.xingin.xhs",
        "xhs" to "com.xingin.xhs",
        
        // 音乐播放 🎵
        "网易云音乐" to "com.netease.cloudmusic",
        "网易云" to "com.netease.cloudmusic",
        "qq音乐" to "com.tencent.qqmusic",
        "qqmusic" to "com.tencent.qqmusic",
        "酷狗音乐" to "com.kugou.android",
        "酷狗" to "com.kugou.android",
        "音乐" to "com.netease.cloudmusic",
        
        // 办公协作 💼
        "钉钉" to "com.alibaba.android.rimet",
        "dingtalk" to "com.alibaba.android.rimet",
        "企业微信" to "com.tencent.wework",
        "wework" to "com.tencent.wework",
        
        // 浏览器 🌐
        "chrome" to "com.android.chrome",
        "浏览器" to "com.android.chrome",
        "browser" to "com.android.chrome",
        
        // 系统应用 📱
        "设置" to "com.android.settings",
        "settings" to "com.android.settings",
        "相机" to "com.android.camera2",
        "camera" to "com.android.camera2",
        "照相机" to "com.android.camera2",
        "拍照" to "com.android.camera2",
        "图库" to "com.google.android.apps.photos",
        "photos" to "com.google.android.apps.photos",
        "照片" to "com.google.android.apps.photos",
        "相册" to "com.google.android.apps.photos",
        "计算器" to "com.android.calculator2",
        "calculator" to "com.android.calculator2",
        "短信" to "com.google.android.apps.messaging",
        "messaging" to "com.google.android.apps.messaging",
        "信息" to "com.google.android.apps.messaging",
        "电话" to "com.google.android.dialer",
        "dialer" to "com.google.android.dialer",
        "拨号" to "com.google.android.dialer",
        "通讯录" to "com.android.contacts",
        "联系人" to "com.android.contacts",
        "contacts" to "com.android.contacts",
        "日历" to "com.google.android.calendar",
        "calendar" to "com.google.android.calendar",
        "时钟" to "com.google.android.deskclock",
        "clock" to "com.google.android.deskclock",
        "闹钟" to "com.google.android.deskclock",
        "文件" to "com.google.android.documentsui",
        "files" to "com.google.android.documentsui",
        "文件管理" to "com.google.android.documentsui",
        "下载" to "com.android.documentsui",
        "downloads" to "com.android.documentsui",
        
        // 资讯阅读 📰
        "知乎" to "com.zhihu.android",
        "zhihu" to "com.zhihu.android",
        "今日头条" to "com.ss.android.article.news",
        "头条" to "com.ss.android.article.news",
        "toutiao" to "com.ss.android.article.news"
    )
    
    /**
     * 应用别名映射（语音识别常见错误纠正）🎤
     */
    private val APP_ALIAS_MAP = mapOf(
        "威信" to "微信",
        "扣扣" to "qq",
        "淘包" to "淘宝",
        "斗音" to "抖音",
        "饿了吗" to "饿了么",
        "支付包" to "支付宝",
        "相机" to "camera",
        "照相" to "camera",
        "图片" to "photos"
    )
    
    /**
     * 快速指令类型
     */
    sealed class QuickCommand {
        data class OpenApp(val packageName: String, val appName: String) : QuickCommand()
        object GoBack : QuickCommand()
        object GoHome : QuickCommand()
        object OpenRecent : QuickCommand()
        data class Unknown(val reason: String) : QuickCommand()
    }
    
    /**
     * 识别快速指令
     * @return QuickCommand 如果识别成功，返回相应的指令；否则返回Unknown
     */
    fun recognizeCommand(userInput: String, context: Context): QuickCommand {
        val input = userInput.trim().lowercase()
        
        // 1. 打开应用类指令
        if (input.matches(Regex("(打开|启动|开启|open|start|launch)\\s*(.+)"))) {
            val appName = input.replace(Regex("(打开|启动|开启|open|start|launch)\\s*"), "").trim()
            val packageName = findPackageName(appName, context)
            return if (packageName != null) {
                QuickCommand.OpenApp(packageName, appName)
            } else {
                QuickCommand.Unknown("未找到应用: $appName")
            }
        }
        
        // 2. 简单匹配应用名
        APP_PACKAGE_MAP.forEach { (name, pkg) ->
            if (input.contains(name.lowercase())) {
                // 检查是否真的是要打开应用
                if (input.matches(Regex(".*打开.*|.*启动.*|.*open.*")) || input == name.lowercase()) {
                    if (isAppInstalled(context, pkg)) {
                        return QuickCommand.OpenApp(pkg, name)
                    } else {
                        return QuickCommand.Unknown("应用未安装: $name")
                    }
                }
            }
        }
        
        // 3. 返回操作
        if (input.matches(Regex(".*(返回|back|退出).*"))) {
            return QuickCommand.GoBack
        }
        
        // 4. 回到主页
        if (input.matches(Regex(".*(主页|首页|桌面|home|主屏幕).*"))) {
            return QuickCommand.GoHome
        }
        
        // 5. 最近任务
        if (input.matches(Regex(".*(最近|recent|任务列表|多任务).*"))) {
            return QuickCommand.OpenRecent
        }
        
        // 未识别为快速指令
        return QuickCommand.Unknown("需要AI分析的复杂任务")
    }
    
    /**
     * 查找包名（超级智能版）🧠
     * 支持：别名、模糊匹配、拼音首字母等多种匹配方式
     */
    private fun findPackageName(appName: String, context: Context): String? {
        val normalizedInput = appName.lowercase().trim()
        LogManager.d(TAG, "🔍 智能查找应用: $normalizedInput")
        
        // 1️⃣ 别名纠正（处理语音识别错误）
        val correctedName = APP_ALIAS_MAP[normalizedInput] ?: normalizedInput
        if (correctedName != normalizedInput) {
            LogManager.d(TAG, "✅ 纠正应用名: $normalizedInput → $correctedName")
        }
        
        // 2️⃣ 在预设映射表中精确查找
        val packageFromMap = APP_PACKAGE_MAP[correctedName.lowercase()]
        if (packageFromMap != null && isAppInstalled(context, packageFromMap)) {
            LogManager.d(TAG, "✅ 从映射表找到: $correctedName → $packageFromMap")
            return packageFromMap
        }
        
        // 3️⃣ 在已安装应用中智能搜索
        val pm = context.packageManager
        val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        
        // 3.1 完全匹配（最高优先级）
        for (app in installedApps) {
            val label = pm.getApplicationLabel(app).toString().lowercase()
            if (label == correctedName) {
                LogManager.d(TAG, "✅ 完全匹配: $label → ${app.packageName}")
                return app.packageName
            }
        }
        
        // 3.2 包含匹配（双向）
        for (app in installedApps) {
            val label = pm.getApplicationLabel(app).toString().lowercase()
            if (label.contains(correctedName) || correctedName.contains(label)) {
                LogManager.d(TAG, "✅ 包含匹配: $label → ${app.packageName}")
                return app.packageName
            }
        }
        
        // 3.3 模糊匹配（去除空格和标点）
        val cleanInput = correctedName.replace(Regex("[\\s\\p{Punct}]"), "")
        for (app in installedApps) {
            val cleanLabel = pm.getApplicationLabel(app).toString().lowercase()
                .replace(Regex("[\\s\\p{Punct}]"), "")
            if (cleanLabel.contains(cleanInput) && cleanInput.length >= 2) {
                LogManager.d(TAG, "✅ 模糊匹配: $cleanLabel → ${app.packageName}")
                return app.packageName
            }
        }
        
        LogManager.w(TAG, "❌ 未找到应用: $appName (已尝试纠正为: $correctedName)")
        return null
    }
    
    /**
     * 检查应用是否已安装
     */
    private fun isAppInstalled(context: Context, packageName: String): Boolean {
        return try {
            context.packageManager.getPackageInfo(packageName, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }
    
    /**
     * 执行快速指令（智能备用方案版）🎯
     */
    suspend fun executeCommand(command: QuickCommand, context: Context): ExecutionResult {
        LogManager.d(TAG, "🚀 执行快速指令: $command")
        
        return when (command) {
            is QuickCommand.OpenApp -> {
                openAppWithFallback(command.packageName, command.appName, context)
            }
            
            is QuickCommand.GoBack -> {
                CoreAccessibilityService.instance?.performGlobalAction(
                    android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK
                )
                ExecutionResult.Success("已返回 ⬅️")
            }
            
            is QuickCommand.GoHome -> {
                CoreAccessibilityService.instance?.performGlobalAction(
                    android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME
                )
                ExecutionResult.Success("已回到主页 🏠")
            }
            
            is QuickCommand.OpenRecent -> {
                CoreAccessibilityService.instance?.performGlobalAction(
                    android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS
                )
                ExecutionResult.Success("已打开最近任务 📱")
            }
            
            is QuickCommand.Unknown -> {
                ExecutionResult.NotRecognized(command.reason)
            }
        }
    }
    
    /**
     * 🎯 智能打开应用（带备用方案）
     * 方案1: 直接启动 → 方案2: 通过桌面搜索
     */
    private suspend fun openAppWithFallback(
        packageName: String,
        appName: String,
        context: Context
    ): ExecutionResult {
        // 🎯 方案1: 直接启动应用
        try {
            val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                LogManager.d(TAG, "✅ 直接启动成功: $appName")
                return ExecutionResult.Success("已打开 $appName ✅")
            }
        } catch (e: Exception) {
            LogManager.w(TAG, "⚠️ 直接启动失败: ${e.message}")
        }
        
        // 🎯 方案2: 通过桌面/应用抽屉搜索
        LogManager.d(TAG, "🔄 尝试备用方案: 通过桌面搜索")
        return openAppViaLauncher(appName, context)
    }
    
    /**
     * 📱 通过桌面搜索并打开应用
     */
    private suspend fun openAppViaLauncher(
        appName: String,
        context: Context
    ): ExecutionResult {
        try {
            val service = CoreAccessibilityService.instance
            if (service == null) {
                LogManager.e(TAG, "❌ 无障碍服务未开启")
                return ExecutionResult.Failure("需要开启无障碍服务才能通过桌面搜索应用")
            }
            
            // 步骤1: 返回桌面
            LogManager.d(TAG, "📱 第1步: 返回桌面")
            service.performGlobalAction(
                android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME
            )
            kotlinx.coroutines.delay(800) // 等待桌面加载
            
            // 步骤2: 打开应用列表（向上滑动）
            LogManager.d(TAG, "📱 第2步: 打开应用抽屉")
            // 尝试点击屏幕中下方区域向上滑动
            val displayMetrics = context.resources.displayMetrics
            val centerX = displayMetrics.widthPixels / 2
            val startY = (displayMetrics.heightPixels * 0.8).toInt()
            val endY = (displayMetrics.heightPixels * 0.2).toInt()
            
            val path = android.graphics.Path()
            path.moveTo(centerX.toFloat(), startY.toFloat())
            path.lineTo(centerX.toFloat(), endY.toFloat())
            
            val gestureBuilder = android.accessibilityservice.GestureDescription.Builder()
            val strokeDescription = android.accessibilityservice.GestureDescription.StrokeDescription(
                path, 0, 300
            )
            gestureBuilder.addStroke(strokeDescription)
            
            var gestureCompleted = false
            service.dispatchGesture(
                gestureBuilder.build(),
                object : android.accessibilityservice.AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(gestureDescription: android.accessibilityservice.GestureDescription?) {
                        gestureCompleted = true
                    }
                },
                null
            )
            
            kotlinx.coroutines.delay(1000) // 等待应用抽屉打开
            
            // 步骤3: 查找搜索框或应用图标
            LogManager.d(TAG, "📱 第3步: 查找应用: $appName")
            val rootNode = service.rootInActiveWindow
            if (rootNode != null) {
                // 尝试查找搜索框
                val searchNodes = rootNode.findAccessibilityNodeInfosByText("搜索")
                if (searchNodes.isNotEmpty()) {
                    LogManager.d(TAG, "📱 找到搜索框，输入应用名")
                    val searchNode = searchNodes[0]
                    searchNode.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK)
                    kotlinx.coroutines.delay(500)
                    
                    // 输入应用名
                    val arguments = android.os.Bundle()
                    arguments.putCharSequence(
                        android.view.accessibility.AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                        appName
                    )
                    searchNode.performAction(
                        android.view.accessibility.AccessibilityNodeInfo.ACTION_SET_TEXT,
                        arguments
                    )
                    kotlinx.coroutines.delay(800)
                }
                
                // 查找应用图标
                val appNodes = rootNode.findAccessibilityNodeInfosByText(appName)
                if (appNodes.isNotEmpty()) {
                    LogManager.d(TAG, "✅ 找到应用图标: $appName")
                    val appNode = appNodes[0]
                    appNode.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK)
                    return ExecutionResult.Success("通过桌面搜索打开了 $appName ✅")
                }
            }
            
            LogManager.w(TAG, "❌ 桌面搜索也未找到应用")
            return ExecutionResult.Failure("找不到 $appName 应用，请检查应用名称或确认已安装")
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 桌面搜索出错: ${e.message}", e)
            return ExecutionResult.Failure("桌面搜索出错: ${e.message}")
        }
    }
    
    /**
     * 执行结果
     */
    sealed class ExecutionResult {
        data class Success(val message: String) : ExecutionResult()
        data class Failure(val message: String) : ExecutionResult()
        data class NotRecognized(val reason: String) : ExecutionResult()
    }
}
