package com.example.xihe.core

import android.graphics.Rect
import com.example.xihe.utils.LogManager
import com.example.xihe.utils.GeometryUtils
import com.example.xihe.utils.SanitizationUtils
import android.view.accessibility.AccessibilityNodeInfo

/**
 * 🛰️ 屏幕多模态上下文
 */
data class ScreenContext(
    val packageName: String,
    val appName: String,
    val pageTitle: String,
    val nodes: List<ScreenNode>,
    val visualFocusBase64: String? = null // 🚀 可选的视觉切片
)

/**
 * 🔍 增强版屏幕分析器
 * 支持屏幕内容识别、多模态上下文提取和语义感知
 * 
 * 优化：
 * - 缓存机制：相同屏幕内容不重复分析
 * - 使用 GeometryUtils 进行几何计算
 */
object ScreenAnalyzer {

    private const val TAG = "ScreenAnalyzer"
    private const val MAX_CONTEXT_NODES = 150
    private var nodeIdCounter = 0
    
    // 缓存机制
    private var cachedScreenState: ScreenState? = null
    private var cachedScreenContext: ScreenContext? = null
    private var lastScreenHash: Int = 0
    private val cacheLock = Any()

    /**
     * 🧠 提取完整多模态上下文（带缓存）
     */
    fun extractContext(rootNode: AccessibilityNodeInfo?, packageName: String): ScreenContext {
        if (rootNode == null) {
            return ScreenContext(
                packageName = packageName,
                appName = getAppNameFromPackage(packageName),
                pageTitle = "未知页面",
                nodes = emptyList()
            )
        }
        
        val currentHash = computeScreenHash(rootNode, packageName)
        
        synchronized(cacheLock) {
            // 检查缓存
            if (currentHash == lastScreenHash) {
                LogManager.d(TAG, "📦 使用缓存的屏幕上下文")
                cachedScreenContext?.let { cachedContext ->
                    return cachedContext
                }
            }
            
            val summary = getScreenSummary(rootNode, packageName)
            nodeIdCounter = 0
            val nodes = mutableListOf<ScreenNode>()
            flattenNodes(rootNode, nodes, MAX_CONTEXT_NODES)
            
            val context = ScreenContext(
                packageName = packageName,
                appName = summary.appName,
                pageTitle = summary.currentPage,
                nodes = nodes.take(150) // 限制节点数，防止 Token 溢出
            )
            
            // 更新缓存
            cachedScreenContext = context
            lastScreenHash = currentHash
            
            return context
        }
    }
    
    /**
     * 计算屏幕内容哈希值（用于缓存判断）
     */
    private fun computeScreenHash(node: AccessibilityNodeInfo, packageName: String): Int {
        var hash = packageName.hashCode()
        hash = 31 * hash + (node.className?.hashCode() ?: 0)
        hash = 31 * hash + (node.text?.hashCode() ?: 0)
        hash = 31 * hash + (node.contentDescription?.hashCode() ?: 0)
        hash = 31 * hash + node.childCount
        
        // 递归计算前几个子节点的哈希（避免过深递归）
        val maxChildren = minOf(node.childCount, 5)
        for (i in 0 until maxChildren) {
            node.getChild(i)?.let { child ->
                hash = 31 * hash + (child.text?.hashCode() ?: 0)
                hash = 31 * hash + (child.contentDescription?.hashCode() ?: 0)
            }
        }
        
        return hash
    }
    
    /**
     * 清除缓存（屏幕变化时调用）
     */
    fun invalidateCache() {
        synchronized(cacheLock) {
            cachedScreenState = null
            cachedScreenContext = null
            lastScreenHash = 0
            LogManager.d(TAG, "🗑️ 屏幕缓存已清除")
        }
    }

    private fun flattenNodes(
        node: AccessibilityNodeInfo,
        list: MutableList<ScreenNode>,
        maxNodes: Int
    ) {
        if (list.size >= maxNodes) return

        val rect = Rect()
        node.getBoundsInScreen(rect)
        
        // 仅收集有意义的节点（可交互或有文本）
        val rawText = node.text?.toString() ?: node.contentDescription?.toString() ?: ""
        val text = SanitizationUtils.sanitizeScreenText(rawText)
        
        if (node.isClickable || node.isEditable || text.isNotBlank()) {
            list.add(ScreenNode(
                id = nodeIdCounter++,
                className = node.className?.toString() ?: "View",
                text = node.text?.toString()?.let { SanitizationUtils.sanitizeScreenText(it) },
                contentDescription = node.contentDescription?.toString()?.let { SanitizationUtils.sanitizeScreenText(it) },
                bounds = listOf(rect.left, rect.top, rect.right, rect.bottom),
                isClickable = node.isClickable,
                isScrollable = node.isScrollable,
                isEditable = node.isEditable,
                usageHint = inferUsage(node)
            ))
            if (list.size >= maxNodes) return
        }
        
        for (i in 0 until node.childCount) {
            if (list.size >= maxNodes) return
            node.getChild(i)?.let { flattenNodes(it, list, maxNodes) }
        }
    }
    
    /**
     * 👁️ 获取视觉焦点区域坐标
     * 返回当前用户可能关注的区域（如屏幕中心或最顶层的可点击元素）
     */
    fun getVisualFocusRect(rootNode: AccessibilityNodeInfo?): Rect {
        val defaultRect = Rect(0, 0, 1080, 1920) // 默认值
        // 逻辑：寻找屏幕中心区域的可点击元素
        // 暂时返回屏幕中心 500x500 区域
        return Rect(290, 710, 790, 1210) 
    }
    
    /**
     * 🆕 获取屏幕内容摘要（用于播报）
     */
    fun getScreenSummary(rootNode: AccessibilityNodeInfo?, packageName: String): ScreenSummary {
        if (rootNode == null) {
            return ScreenSummary(
                appName = getAppNameFromPackage(packageName),
                currentPage = "未知页面",
                mainContent = "无法获取屏幕内容",
                interactiveElements = emptyList(),
                textContent = emptyList()
            )
        }
        
        val texts = mutableListOf<String>()
        val buttons = mutableListOf<String>()
        val inputs = mutableListOf<String>()
        var pageTitle: String? = null
        
        // 遍历收集屏幕信息
        collectScreenInfo(rootNode, texts, buttons, inputs) { title ->
            if (pageTitle == null && title.isNotBlank()) {
                pageTitle = title
            }
        }
        
        // 生成摘要
        val appName = getAppNameFromPackage(packageName)
        val currentPage = pageTitle ?: inferPageType(texts, buttons)
        
        // 主要内容总结
        val mainContent = generateMainContent(texts, buttons, inputs)
        
        LogManager.d(TAG, "📱 屏幕摘要: $appName - $currentPage")
        
        return ScreenSummary(
            appName = appName,
            currentPage = currentPage,
            mainContent = mainContent,
            interactiveElements = buttons.take(10),
            textContent = texts.take(20)
        )
    }
    
    /**
     * 🆕 生成屏幕内容的自然语言描述（用于AI播报）
     */
    fun describeScreen(rootNode: AccessibilityNodeInfo?, packageName: String): String {
        val summary = getScreenSummary(rootNode, packageName)
        
        val sb = StringBuilder()
        sb.append("当前在${summary.appName}")
        
        if (summary.currentPage.isNotBlank()) {
            sb.append("的${summary.currentPage}")
        }
        sb.append("。")
        
        // 描述主要内容
        if (summary.mainContent.isNotBlank()) {
            sb.append(summary.mainContent)
        }
        
        // 描述可交互元素
        if (summary.interactiveElements.isNotEmpty()) {
            val topButtons = summary.interactiveElements.take(5)
            sb.append("可以点击的有：${topButtons.joinToString("、")}。")
        }
        
        return sb.toString()
    }
    
    /**
     * 收集屏幕信息
     */
    private fun collectScreenInfo(
        node: AccessibilityNodeInfo,
        texts: MutableList<String>,
        buttons: MutableList<String>,
        inputs: MutableList<String>,
        onTitleFound: (String) -> Unit
    ) {
        val rawText = node.text?.toString()?.trim() ?: ""
        val rawDesc = node.contentDescription?.toString()?.trim() ?: ""
        val text = SanitizationUtils.sanitizeScreenText(rawText)
        val desc = SanitizationUtils.sanitizeScreenText(rawDesc)
        val className = node.className?.toString()?.lowercase() ?: ""
        
        // 检测页面标题
        if (className.contains("toolbar") || className.contains("actionbar")) {
            if (text.isNotBlank()) onTitleFound(text)
            if (desc.isNotBlank()) onTitleFound(desc)
        }
        
        // 收集文本内容
        if (text.isNotBlank() && text.length in 1..100) {
            texts.add(text)
        }
        
        // 收集按钮
        if (node.isClickable) {
            val buttonText = text.ifBlank { desc }
            if (buttonText.isNotBlank() && buttonText.length <= 20) {
                buttons.add(buttonText)
            }
        }
        
        // 收集输入框
        if (node.isEditable) {
            val hint = desc.ifBlank { "输入框" }
            inputs.add(hint)
        }
        
        // 递归子节点
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectScreenInfo(child, texts, buttons, inputs, onTitleFound)
        }
    }
    
    /**
     * 从包名推断应用名称
     */
    private fun getAppNameFromPackage(packageName: String): String {
        return when {
            packageName.contains("wechat") || packageName.contains("mm") -> "微信"
            packageName.contains("qq") && !packageName.contains("qqmusic") -> "QQ"
            packageName.contains("taobao") -> "淘宝"
            packageName.contains("alipay") -> "支付宝"
            packageName.contains("jd") -> "京东"
            packageName.contains("douyin") || packageName.contains("tiktok") -> "抖音"
            packageName.contains("kuaishou") -> "快手"
            packageName.contains("bilibili") -> "哔哩哔哩"
            packageName.contains("weibo") -> "微博"
            packageName.contains("zhihu") -> "知乎"
            packageName.contains("meituan") -> "美团"
            packageName.contains("eleme") -> "饿了么"
            packageName.contains("didi") -> "滴滴"
            packageName.contains("baidu") -> "百度"
            packageName.contains("chrome") -> "Chrome浏览器"
            packageName.contains("browser") -> "浏览器"
            packageName.contains("settings") -> "设置"
            packageName.contains("launcher") -> "桌面"
            packageName.contains("xihe") -> "羲和"
            else -> packageName.substringAfterLast(".").replaceFirstChar { it.uppercase() }
        }
    }
    
    /**
     * 推断页面类型
     */
    private fun inferPageType(texts: List<String>, buttons: List<String>): String {
        val allText = (texts + buttons).joinToString(" ").lowercase()
        
        return when {
            allText.contains("登录") || allText.contains("login") -> "登录页面"
            allText.contains("注册") || allText.contains("register") -> "注册页面"
            allText.contains("搜索") || allText.contains("search") -> "搜索页面"
            allText.contains("设置") || allText.contains("setting") -> "设置页面"
            allText.contains("个人") || allText.contains("我的") || allText.contains("profile") -> "个人中心"
            allText.contains("聊天") || allText.contains("消息") -> "聊天页面"
            allText.contains("首页") || allText.contains("home") -> "首页"
            allText.contains("详情") || allText.contains("detail") -> "详情页面"
            allText.contains("列表") -> "列表页面"
            allText.contains("购物车") || allText.contains("cart") -> "购物车"
            allText.contains("订单") || allText.contains("order") -> "订单页面"
            allText.contains("支付") || allText.contains("pay") -> "支付页面"
            else -> "主页面"
        }
    }
    
    /**
     * 生成主要内容描述
     */
    private fun generateMainContent(
        texts: List<String>,
        buttons: List<String>,
        inputs: List<String>
    ): String {
        val parts = mutableListOf<String>()
        
        // 描述文本内容
        val meaningfulTexts = texts.filter { it.length >= 4 }.take(5)
        if (meaningfulTexts.isNotEmpty()) {
            parts.add("页面显示：${meaningfulTexts.joinToString("，")}")
        }
        
        // 描述输入框
        if (inputs.isNotEmpty()) {
            parts.add("有${inputs.size}个输入框")
        }
        
        // 描述按钮数量
        if (buttons.isNotEmpty()) {
            parts.add("有${buttons.size}个可点击的元素")
        }
        
        return if (parts.isNotEmpty()) {
            parts.joinToString("。") + "。"
        } else {
            "页面内容较少。"
        }
    }
    
    /**
     * 🆕 屏幕摘要数据类
     */
    data class ScreenSummary(
        val appName: String,
        val currentPage: String,
        val mainContent: String,
        val interactiveElements: List<String>,
        val textContent: List<String>
    )

    private fun traverse(node: AccessibilityNodeInfo): ScreenNode {
        val rect = Rect()
        node.getBoundsInScreen(rect)
        
        val currentNodeId = nodeIdCounter++
        
        // Map AccessibilityNodeInfo to our simplified ScreenNode
        // We only care about nodes that are interactive or have content
        val children = mutableListOf<ScreenNode>()
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            if (child != null) {
                children.add(traverse(child))
                // child.recycle() // In a real app, we should be careful with recycling, but for recursion it's tricky
            }
        }

        return ScreenNode(
            id = currentNodeId,
            className = node.className?.toString() ?: "Unknown",
            text = node.text?.toString(),
            contentDescription = node.contentDescription?.toString(),
            bounds = listOf(rect.left, rect.top, rect.right, rect.bottom),
            isClickable = node.isClickable,
            isScrollable = node.isScrollable,
            isEditable = node.isEditable,
            usageHint = inferUsage(node), // 🧠 注入语义猜测
            children = children
        )
    }
    
    // 🧠 语义感知核心：推测组件用途
    private fun inferUsage(node: AccessibilityNodeInfo): String? {
        val className = node.className?.toString()?.lowercase() ?: ""
        val text = (node.text?.toString() ?: "").lowercase()
        val desc = (node.contentDescription?.toString() ?: "").lowercase()
        val combinedText = "$text $desc"
        
        // 1. 输入类
        if (node.isEditable) {
            if (combinedText.contains("search") || combinedText.contains("搜索")) return "搜索框"
            if (combinedText.contains("password") || combinedText.contains("密码")) return "密码输入框"
            if (combinedText.contains("phone") || combinedText.contains("手机")) return "手机号输入框"
            return "输入框"
        }
        
        // 2. 列表/滚动类
        if (node.isScrollable) {
            if (className.contains("recycler") || className.contains("list")) return "列表容器"
            if (className.contains("pager") || className.contains("viewpager")) return "翻页容器"
            if (className.contains("scroll")) return "滚动区域"
        }
        
        // 3. 按钮类 (Clickable)
        if (node.isClickable) {
            // 特殊按钮识别
            if (combinedText.contains("login") || combinedText.contains("登录")) return "登录按钮"
            if (combinedText.contains("send") || combinedText.contains("发送")) return "发送按钮"
            if (combinedText.contains("confirm") || combinedText.contains("确定") || combinedText.contains("完成")) return "确认按钮"
            if (combinedText.contains("cancel") || combinedText.contains("取消")) return "取消按钮"
            if (combinedText.contains("back") || combinedText.contains("返回")) return "返回按钮"
            if (combinedText.contains("setting") || combinedText.contains("设置")) return "设置入口"
            
            if (className.contains("button")) return "按钮"
            if (className.contains("image")) return "图标按钮" // ImageView + Clickable 通常是图标按钮
            if (className.contains("text")) return "文本链接" // TextView + Clickable 通常是文字按钮
            
            return "可点击区域"
        }
        
        // 4. 展示类
        if (className.contains("image")) return "图片"
        if (className.contains("text") && text.isNotEmpty()) return "文本标签"
        
        return null
    }
    
    // Helper to find a node by ID in the original AccessibilityNodeInfo tree
    // (In a real implementation, we would need to cache the mapping between our ID and the actual AccessibilityNodeInfo)
    fun findNodeById(root: AccessibilityNodeInfo, targetId: Int): AccessibilityNodeInfo? {
        // Re-traversal to find the node. 
        // NOTE: This assumes the tree hasn't changed since the last analyze call.
        // A better approach is to store a map<Int, AccessibilityNodeInfo> during the first traversal.
        var currentId = 0
        
        fun search(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
            if (currentId == targetId) return node
            currentId++
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                val result = search(child)
                if (result != null) return result
            }
            return null
        }
        
        return search(root)
    }
    
    /**
     * 🔍 分析屏幕并返回 ScreenState（带缓存）
     * 用于 LLM 交互和任务执行
     */
    fun analyze(rootNode: AccessibilityNodeInfo?, packageName: String): ScreenState? {
        if (rootNode == null) return null
        
        val currentHash = computeScreenHash(rootNode, packageName)
        
        synchronized(cacheLock) {
            // 检查缓存
            if (currentHash == lastScreenHash && cachedScreenState != null) {
                LogManager.d(TAG, "📦 使用缓存的屏幕状态")
                return cachedScreenState
            }
            
            nodeIdCounter = 0
            val rootScreenNode = traverse(rootNode)
            
            // 获取上下文提示
            val summary = getScreenSummary(rootNode, packageName)
            val contextHints = "${summary.appName} - ${summary.currentPage}: ${summary.mainContent}"
            
            val state = ScreenState(
                packageName = packageName,
                root = rootScreenNode,
                contextHints = contextHints
            )
            
            // 更新缓存
            cachedScreenState = state
            lastScreenHash = currentHash
            
            return state
        }
    }
}
