package com.example.xihe.core

import com.example.xihe.utils.LogManager
import com.example.xihe.service.EnhancedAccessibilityService
import kotlinx.coroutines.delay
import kotlinx.serialization.Serializable

/**
 * 🛠️ 智能错误恢复系统
 * 
 * 功能:
 * - 智能诊断执行错误
 * - 多策略自动恢复
 * - 学习失败模式
 * - 用户友好提示
 * 
 * 优化点:
 * 1. 从单一重试 -> 多策略恢复
 * 2. 从被动失败 -> 主动诊断
 * 3. 从固定策略 -> 学习优化
 */
class IntelligentErrorRecovery {
    
    companion object {
        private const val TAG = "ErrorRecovery"
        private const val MAX_RECOVERY_ATTEMPTS = 3
    }
    
    // 失败模式学习库
    private val failurePatterns = mutableListOf<FailurePattern>()
    
    // 成功的恢复策略缓存
    private val successfulStrategies = mutableMapOf<ErrorType, RecoveryStrategy>()
    
    /**
     * 🔍 智能诊断错误
     */
    fun diagnoseError(error: ExecutionError): Diagnosis {
        LogManager.d(TAG, "🔍 诊断错误: ${error.message}")
        
        return when (error.type) {
            ErrorType.ELEMENT_NOT_FOUND -> {
                Diagnosis(
                    type = error.type,
                    rootCause = "目标UI元素未找到",
                    possibleReasons = listOf(
                        "应用界面已更新",
                        "页面加载未完成",
                        "元素被遮挡",
                        "需要滚动才能看到"
                    ),
                    recommendedStrategies = listOf(
                        RecoveryStrategy.WAIT_FOR_LOAD,
                        RecoveryStrategy.SCROLL_TO_FIND,
                        RecoveryStrategy.USE_OCR_FALLBACK,
                        RecoveryStrategy.ASK_USER_HELP
                    ),
                    severity = Severity.MEDIUM,
                    userMessage = "找不到目标元素，正在尝试其他方法..."
                )
            }
            
            ErrorType.PERMISSION_DENIED -> {
                Diagnosis(
                    type = error.type,
                    rootCause = "权限不足",
                    possibleReasons = listOf(
                        "缺少必要权限",
                        "权限被用户拒绝",
                        "系统安全限制"
                    ),
                    recommendedStrategies = listOf(
                        RecoveryStrategy.GUIDE_TO_SETTINGS,
                        RecoveryStrategy.EXPLAIN_PERMISSION
                    ),
                    severity = Severity.HIGH,
                    userMessage = "需要授予权限才能继续哦~"
                )
            }
            
            ErrorType.NETWORK_ERROR -> {
                Diagnosis(
                    type = error.type,
                    rootCause = "网络连接问题",
                    possibleReasons = listOf(
                        "网络未连接",
                        "网络不稳定",
                        "服务器超时"
                    ),
                    recommendedStrategies = listOf(
                        RecoveryStrategy.WAIT_AND_RETRY,
                        RecoveryStrategy.SWITCH_TO_OFFLINE,
                        RecoveryStrategy.NOTIFY_USER
                    ),
                    severity = Severity.MEDIUM,
                    userMessage = "网络似乎有点问题，稍后重试..."
                )
            }
            
            ErrorType.UNEXPECTED_SCREEN -> {
                Diagnosis(
                    type = error.type,
                    rootCause = "出现了意外的界面",
                    possibleReasons = listOf(
                        "弹出了广告",
                        "出现了错误提示",
                        "跳转到了错误页面",
                        "应用崩溃重启"
                    ),
                    recommendedStrategies = listOf(
                        RecoveryStrategy.CLOSE_POPUP,
                        RecoveryStrategy.NAVIGATE_BACK,
                        RecoveryStrategy.RESTART_APP,
                        RecoveryStrategy.ASK_LLM_HELP
                    ),
                    severity = Severity.HIGH,
                    userMessage = "遇到了意外情况，正在处理..."
                )
            }
            
            ErrorType.TIMEOUT -> {
                Diagnosis(
                    type = error.type,
                    rootCause = "操作超时",
                    possibleReasons = listOf(
                        "应用响应太慢",
                        "网络延迟",
                        "任务太复杂"
                    ),
                    recommendedStrategies = listOf(
                        RecoveryStrategy.EXTEND_TIMEOUT,
                        RecoveryStrategy.SIMPLIFY_TASK,
                        RecoveryStrategy.WAIT_AND_RETRY
                    ),
                    severity = Severity.MEDIUM,
                    userMessage = "操作有点慢，请稍等..."
                )
            }
            
            ErrorType.APP_CRASH -> {
                Diagnosis(
                    type = error.type,
                    rootCause = "应用崩溃",
                    possibleReasons = listOf(
                        "应用bug",
                        "内存不足",
                        "系统不兼容"
                    ),
                    recommendedStrategies = listOf(
                        RecoveryStrategy.RESTART_APP,
                        RecoveryStrategy.CLEAR_APP_DATA,
                        RecoveryStrategy.NOTIFY_USER
                    ),
                    severity = Severity.CRITICAL,
                    userMessage = "应用崩溃了，正在重启..."
                )
            }
            
            else -> {
                Diagnosis(
                    type = ErrorType.UNKNOWN,
                    rootCause = "未知错误",
                    possibleReasons = listOf("需要进一步分析"),
                    recommendedStrategies = listOf(
                        RecoveryStrategy.ASK_USER_HELP,
                        RecoveryStrategy.ABORT_TASK
                    ),
                    severity = Severity.HIGH,
                    userMessage = "遇到了未知错误..."
                )
            }
        }
    }
    
    /**
     * 🔧 执行恢复策略
     */
    suspend fun executeRecovery(
        diagnosis: Diagnosis,
        context: ExecutionContext
    ): RecoveryResult {
        LogManager.d(TAG, "🔧 开始恢复: ${diagnosis.type}")
        
        // 检查是否有已知的成功策略
        val knownStrategy = successfulStrategies[diagnosis.type]
        val strategies = if (knownStrategy != null) {
            listOf(knownStrategy) + diagnosis.recommendedStrategies
        } else {
            diagnosis.recommendedStrategies
        }
        
        // 依次尝试恢复策略
        for ((index, strategy) in strategies.take(MAX_RECOVERY_ATTEMPTS).withIndex()) {
            LogManager.d(TAG, "尝试策略 ${index + 1}: $strategy")
            
            val result = tryRecoveryStrategy(strategy, context)
            
            if (result.success) {
                // 记录成功的策略
                successfulStrategies[diagnosis.type] = strategy
                
                LogManager.d(TAG, "✅ 恢复成功！使用策略: $strategy")
                return RecoveryResult(
                    success = true,
                    strategy = strategy,
                    message = result.message,
                    nextAction = result.nextAction
                )
            } else {
                LogManager.d(TAG, "❌ 策略失败: ${result.message}")
            }
        }
        
        // 所有策略都失败了
        LogManager.e(TAG, "❌ 所有恢复策略都失败了")
        
        // 学习这个失败模式
        learnFailurePattern(diagnosis, context)
        
        return RecoveryResult(
            success = false,
            strategy = null,
            message = "无法自动恢复，需要您的帮助",
            nextAction = NextAction.ASK_USER
        )
    }
    
    /**
     * 🎯 尝试单个恢复策略
     */
    private suspend fun tryRecoveryStrategy(
        strategy: RecoveryStrategy,
        context: ExecutionContext
    ): StrategyResult {
        val service = EnhancedAccessibilityService.getInstance()
        
        return when (strategy) {
            RecoveryStrategy.WAIT_FOR_LOAD -> {
                // 等待页面加载
                delay(2000)
                StrategyResult(
                    success = true,
                    message = "等待页面加载完成",
                    nextAction = NextAction.RETRY
                )
            }
            
            RecoveryStrategy.SCROLL_TO_FIND -> {
                // 滚动查找元素
                service?.let {
                    val found = scrollAndFind(it, context)
                    StrategyResult(
                        success = found,
                        message = if (found) "通过滚动找到了元素" else "滚动后仍未找到",
                        nextAction = if (found) NextAction.RETRY else NextAction.TRY_NEXT
                    )
                } ?: StrategyResult(false, "服务不可用", NextAction.TRY_NEXT)
            }
            
            RecoveryStrategy.USE_OCR_FALLBACK -> {
                // 使用OCR识别
                StrategyResult(
                    success = true,
                    message = "切换到OCR识别模式",
                    nextAction = NextAction.USE_OCR
                )
            }
            
            RecoveryStrategy.NAVIGATE_BACK -> {
                // 返回上一页
                service?.performGlobalAction(
                    android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK
                )
                delay(500)
                StrategyResult(
                    success = true,
                    message = "返回到上一页",
                    nextAction = NextAction.RETRY
                )
            }
            
            RecoveryStrategy.CLOSE_POPUP -> {
                // 关闭弹窗
                service?.let {
                    val closed = closePopup(it)
                    StrategyResult(
                        success = closed,
                        message = if (closed) "关闭了弹窗" else "未找到弹窗",
                        nextAction = if (closed) NextAction.RETRY else NextAction.TRY_NEXT
                    )
                } ?: StrategyResult(false, "服务不可用", NextAction.TRY_NEXT)
            }
            
            RecoveryStrategy.RESTART_APP -> {
                // 重启应用
                StrategyResult(
                    success = true,
                    message = "准备重启应用",
                    nextAction = NextAction.RESTART_APP
                )
            }
            
            RecoveryStrategy.GUIDE_TO_SETTINGS -> {
                // 引导用户到设置
                StrategyResult(
                    success = true,
                    message = "需要您手动授权",
                    nextAction = NextAction.OPEN_SETTINGS
                )
            }
            
            RecoveryStrategy.ASK_LLM_HELP -> {
                // 请求LLM协助
                StrategyResult(
                    success = true,
                    message = "请求AI分析当前情况",
                    nextAction = NextAction.ASK_LLM
                )
            }
            
            RecoveryStrategy.ASK_USER_HELP -> {
                // 请求用户帮助
                StrategyResult(
                    success = true,
                    message = "需要您的帮助",
                    nextAction = NextAction.ASK_USER
                )
            }
            
            else -> {
                StrategyResult(
                    success = false,
                    message = "未实现的策略",
                    nextAction = NextAction.TRY_NEXT
                )
            }
        }
    }
    
    /**
     * 📜 滚动查找元素
     */
    private suspend fun scrollAndFind(
        service: EnhancedAccessibilityService,
        context: ExecutionContext
    ): Boolean {
        for (i in 0 until 3) {
            // 向下滚动
            service.performGlobalAction(
                android.accessibilityservice.AccessibilityService.GESTURE_SWIPE_UP
            )
            delay(500)
            
            // 检查是否找到目标元素
            val rootNode = service.rootInActiveWindow ?: continue
            val targetElement = context.targetElement ?: continue
            
            val found = findElementByText(rootNode, targetElement)
            rootNode.recycle()
            
            if (found) {
                LogManager.d(TAG, "✅ 滚动后找到元素: $targetElement")
                return true
            }
        }
        LogManager.d(TAG, "⚠️ 滚动后未找到元素")
        return false
    }
    
    private fun findElementByText(
        node: android.view.accessibility.AccessibilityNodeInfo,
        targetText: String
    ): Boolean {
        val text = node.text?.toString() ?: ""
        val desc = node.contentDescription?.toString() ?: ""
        
        if (text.contains(targetText, ignoreCase = true) || 
            desc.contains(targetText, ignoreCase = true)) {
            return true
        }
        
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                if (findElementByText(child, targetText)) {
                    child.recycle()
                    return true
                }
                child.recycle()
            }
        }
        return false
    }
    
    /**
     * ❌ 关闭弹窗
     */
    private fun closePopup(service: EnhancedAccessibilityService): Boolean {
        val rootNode = service.rootInActiveWindow ?: return false
        
        // 查找常见的关闭按钮文字
        val closeKeywords = listOf("关闭", "取消", "跳过", "×", "✕", "我知道了", "不再提醒", "X")
        
        val closeButton = findCloseButton(rootNode, closeKeywords)
        val result = closeButton?.performAction(
            android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK
        ) ?: false
        
        rootNode.recycle()
        
        if (result) {
            LogManager.d(TAG, "✅ 成功关闭弹窗")
        } else {
            // 尝试按返回键关闭
            service.performGlobalAction(
                android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK
            )
            LogManager.d(TAG, "ℹ️ 尝试使用返回键关闭弹窗")
        }
        return result
    }
    
    private fun findCloseButton(
        node: android.view.accessibility.AccessibilityNodeInfo,
        keywords: List<String>
    ): android.view.accessibility.AccessibilityNodeInfo? {
        val text = node.text?.toString() ?: ""
        val desc = node.contentDescription?.toString() ?: ""
        val viewId = node.viewIdResourceName ?: ""
        
        // 检查是否是关闭按钮
        val isCloseButton = node.isClickable && (
            keywords.any { text.contains(it, ignoreCase = true) } ||
            keywords.any { desc.contains(it, ignoreCase = true) } ||
            viewId.contains("close", ignoreCase = true) ||
            viewId.contains("cancel", ignoreCase = true) ||
            viewId.contains("dismiss", ignoreCase = true)
        )
        
        if (isCloseButton) {
            return node
        }
        
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                findCloseButton(child, keywords)?.let { return it }
            }
        }
        return null
    }
    
    /**
     * 📚 学习失败模式
     */
    private fun learnFailurePattern(diagnosis: Diagnosis, context: ExecutionContext) {
        val pattern = FailurePattern(
            errorType = diagnosis.type,
            taskType = context.taskType,
            appPackage = context.appPackage,
            timestamp = System.currentTimeMillis(),
            attemptedStrategies = diagnosis.recommendedStrategies,
            contextInfo = context.toString()
        )
        
        failurePatterns.add(pattern)
        
        // 保持最近100个失败模式
        if (failurePatterns.size > 100) {
            failurePatterns.removeAt(0)
        }
        
        LogManager.d(TAG, "📚 已记录失败模式: ${pattern.errorType}")
    }
    
    /**
     * 🔍 检查是否见过类似失败
     */
    fun hasSeenSimilarFailure(diagnosis: Diagnosis, context: ExecutionContext): Boolean {
        return failurePatterns.any {
            it.errorType == diagnosis.type &&
            it.appPackage == context.appPackage &&
            it.taskType == context.taskType
        }
    }
    
    /**
     * 💡 获取已知解决方案
     */
    fun getKnownSolution(diagnosis: Diagnosis): RecoveryStrategy? {
        return successfulStrategies[diagnosis.type]
    }
}

// ==================== 数据类 ====================

/**
 * ⚠️ 执行错误
 */
data class ExecutionError(
    val type: ErrorType,
    val message: String,
    val stackTrace: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * 🏷️ 错误类型
 */
enum class ErrorType {
    ELEMENT_NOT_FOUND,      // 元素未找到
    PERMISSION_DENIED,      // 权限拒绝
    NETWORK_ERROR,          // 网络错误
    TIMEOUT,                // 超时
    UNEXPECTED_SCREEN,      // 意外界面
    APP_CRASH,              // 应用崩溃
    ACTION_FAILED,          // 操作失败
    UNKNOWN                 // 未知错误
}

/**
 * 🔍 诊断结果
 */
data class Diagnosis(
    val type: ErrorType,
    val rootCause: String,
    val possibleReasons: List<String>,
    val recommendedStrategies: List<RecoveryStrategy>,
    val severity: Severity,
    val userMessage: String
)

/**
 * ⚖️ 严重程度
 */
enum class Severity {
    LOW,        // 轻微
    MEDIUM,     // 中等
    HIGH,       // 严重
    CRITICAL    // 致命
}

/**
 * 🔧 恢复策略
 */
enum class RecoveryStrategy {
    WAIT_FOR_LOAD,          // 等待加载
    SCROLL_TO_FIND,         // 滚动查找
    USE_OCR_FALLBACK,       // OCR备用
    NAVIGATE_BACK,          // 返回
    CLOSE_POPUP,            // 关闭弹窗
    RESTART_APP,            // 重启应用
    CLEAR_APP_DATA,         // 清除数据
    GUIDE_TO_SETTINGS,      // 引导到设置
    EXPLAIN_PERMISSION,     // 解释权限
    WAIT_AND_RETRY,         // 等待重试
    SWITCH_TO_OFFLINE,      // 切换离线
    EXTEND_TIMEOUT,         // 延长超时
    SIMPLIFY_TASK,          // 简化任务
    ASK_LLM_HELP,          // LLM协助
    ASK_USER_HELP,         // 用户帮助
    NOTIFY_USER,           // 通知用户
    ABORT_TASK             // 放弃任务
}

/**
 * 📊 恢复结果
 */
data class RecoveryResult(
    val success: Boolean,
    val strategy: RecoveryStrategy?,
    val message: String,
    val nextAction: NextAction
)

/**
 * 🎯 下一步行动
 */
enum class NextAction {
    RETRY,              // 重试
    TRY_NEXT,           // 尝试下一个策略
    USE_OCR,            // 使用OCR
    RESTART_APP,        // 重启应用
    OPEN_SETTINGS,      // 打开设置
    ASK_LLM,            // 询问LLM
    ASK_USER,           // 询问用户
    ABORT               // 放弃
}

/**
 * 🎬 策略执行结果
 */
data class StrategyResult(
    val success: Boolean,
    val message: String,
    val nextAction: NextAction
)

/**
 * 📝 执行上下文
 */
data class ExecutionContext(
    val taskType: String,
    val appPackage: String,
    val targetElement: String?,
    val currentScreen: String?,
    val attemptCount: Int = 0
)

/**
 * 📚 失败模式
 */
@Serializable
data class FailurePattern(
    val errorType: ErrorType,
    val taskType: String,
    val appPackage: String,
    val timestamp: Long,
    val attemptedStrategies: List<RecoveryStrategy>,
    val contextInfo: String
)

