package com.example.xihe.core

import android.content.Context
import android.content.Intent
import com.example.xihe.utils.LogManager
import com.example.xihe.ai.IntentClassifier
import com.example.xihe.ai.ConversationContext
import com.example.xihe.ai.TaskPlanner
import com.example.xihe.collaboration.CrossAppCoordinator
import com.example.xihe.interaction.VoiceInteractionManager
import com.example.xihe.automation.AdaptiveExecutionEngine
import com.example.xihe.automation.ExecutionEngineState
import com.example.xihe.learning.AdaptiveLearningSystem
import com.example.xihe.optimization.PerformanceOptimizer
import com.example.xihe.screen.ScreenAnalyzer
import com.example.xihe.security.SecurityManager
import com.example.xihe.service.EnhancedAccessibilityService
import com.example.xihe.core.ModuleCoordinator
import com.example.xihe.core.model.ChatMessageDisplay
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.serialization.Serializable

/**
 * 🚀 增强版自动化引擎
 * 整合所有高级功能模块的中央控制系统
 */
object EnhancedAutomationEngine {
    
    private const val TAG = "EnhancedEngine"
    
    /**
     * 引擎状态
     */
    enum class EngineState {
        UNINITIALIZED,
        INITIALIZING,
        READY,
        PROCESSING,
        EXECUTING,
        LEARNING,
        ERROR,
        SUSPENDED
    }
    
    /**
     * 执行模式
     */
    enum class ExecutionMode {
        NORMAL,         // 正常模式
        SAFE,           // 安全模式
        LEARNING,       // 学习模式
        DEMO,           // 演示模式
        DEBUG           // 调试模式
    }
    
    /**
     * 任务执行上下文
     */
    data class ExecutionContext(
        val taskId: String,
        val userRequest: String,
        val intent: IntentClassifier.UserIntent,
        val mode: ExecutionMode,
        val startTime: Long = System.currentTimeMillis(),
        val metadata: Map<String, Any> = emptyMap()
    )
    
    /**
     * 执行报告
     */
    @Serializable
    data class ExecutionReport(
        val taskId: String,
        val success: Boolean,
        val duration: Long,
        val stepsCompleted: Int,
        val totalSteps: Int,
        val errors: List<String> = emptyList(),
        val learnings: List<String> = emptyList(),
        val securityEvents: List<String> = emptyList()
        // 移除performanceMetrics以避免序列化Any类型
    )
    
    // 状态管理
    private val _engineState = MutableStateFlow(EngineState.UNINITIALIZED)
    val engineState = _engineState.asStateFlow()
    
    private val _currentMode = MutableStateFlow(ExecutionMode.NORMAL)
    val currentMode = _currentMode.asStateFlow()
    
    private val _isProcessing = MutableStateFlow(false)
    val isProcessing = _isProcessing.asStateFlow()
    
    // 核心模块实例
    private lateinit var context: Context
    private lateinit var intentClassifier: IntentClassifier
    private lateinit var taskPlanner: TaskPlanner
    private lateinit var screenAnalyzer: ScreenAnalyzer
    private lateinit var voiceManager: VoiceInteractionManager
    private lateinit var learningSystem: AdaptiveLearningSystem
    private lateinit var performanceOptimizer: PerformanceOptimizer
    private lateinit var crossAppCoordinator: CrossAppCoordinator
    private lateinit var adaptiveExecutionEngine: AdaptiveExecutionEngine
    
    // 执行管理
    private val mainScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var currentContext: ExecutionContext? = null
    private val executionHistory = mutableListOf<ExecutionReport>()
    
    // 🧠 对话上下文维护
    private var conversationContext = ConversationContext()
    private val recentUserInputs = mutableListOf<String>()
    private val recentAIResponses = mutableListOf<String>()
    private const val MAX_CONTEXT_MESSAGES = 10
    
    // 配置
    private var config = EngineConfig()
    
    /**
     * 引擎配置
     */
    data class EngineConfig(
        val enableVoice: Boolean = true,
        val enableLearning: Boolean = true,
        val enableSecurity: Boolean = true,
        val enablePerformanceOptimization: Boolean = true,
        val maxConcurrentTasks: Int = 3,
        val defaultTimeout: Long = 30000L,
        val debugMode: Boolean = false
    )
    
    /**
     * 🎯 初始化引擎
     */
    fun initialize(appContext: Context, engineConfig: EngineConfig = EngineConfig()) {
        if (_engineState.value != EngineState.UNINITIALIZED) {
            LogManager.w(TAG, "引擎已初始化")
            return
        }
        
        _engineState.value = EngineState.INITIALIZING
        EngineStateManager.updateStatus("初始化增强引擎...")
        context = appContext
        config = engineConfig
        
        LogManager.i(TAG, "========================================")
        LogManager.i(TAG, "🚀 羲和AI增强引擎 v2.0 初始化中...")
        LogManager.i(TAG, "========================================")
        
        try {
            // 初始化核心模块
            initializeModules()
            
            // 配置模块间通信
            setupModuleCommunication()
            
            // 加载用户数据
            loadUserData()
            
            // 启动后台服务
            startBackgroundServices()
            
            _engineState.value = EngineState.READY
            EngineStateManager.updateStatus("Idle")
            
            LogManager.i(TAG, "✅ 引擎初始化完成！")
            LogManager.i(TAG, "========================================")
            
            // 发送欢迎消息
            if (config.enableVoice) {
                ModuleCoordinator.speak("羲和AI助手已准备就绪，随时为您服务！")
            }
            
        } catch (e: Exception) {
            LogManager.e(TAG, "引擎初始化失败", e)
            _engineState.value = EngineState.ERROR
        }
    }
    
    /**
     * 💬 处理用户输入
     * @param input 用户输入
     * @param existingMessageId 已存在的消息ID（用于重试场景）
     */
    suspend fun processUserInput(input: String, existingMessageId: String? = null): ExecutionReport {
        if (_engineState.value != EngineState.READY) {
            return ExecutionReport(
                taskId = "error",
                success = false,
                duration = 0,
                stepsCompleted = 0,
                totalSteps = 0,
                errors = listOf("引擎未就绪")
            )
        }
        
        _isProcessing.value = true
        EngineStateManager.updateStatus("思考中...")
        
        // 添加用户消息到UI（或更新已存在消息的状态）
        val userMessageId = if (existingMessageId != null) {
            // 重试场景：更新已存在消息状态
            EngineStateManager.markMessageSending(existingMessageId)
            existingMessageId
        } else {
            // 新消息场景
            EngineStateManager.addUserMessage(
                text = input,
                status = com.example.xihe.core.model.MessageStatus.PENDING
            )
        }
        
        val taskId = generateTaskId()
        val startTime = System.currentTimeMillis()
        
        try {
            LogManager.d(TAG, "处理用户输入: $input")
            
            // 1. 意图识别（传入对话上下文）
            val intentResult = intentClassifier.classifyIntent(input, conversationContext)
            LogManager.d(TAG, "识别意图: ${intentResult.intent}, 上下文轮数: ${conversationContext.conversationTurns}")
            
            // 🧠 更新对话上下文
            updateConversationContext(input, intentResult)
            
            // 2. 安全检查
            if (config.enableSecurity) {
                val securityCheck = SecurityManager.checkOperationSafety(input)
                if (securityCheck.level == SecurityManager.SafetyLevel.FORBIDDEN) {
                    return createErrorReport(taskId, "操作被安全系统阻止", startTime)
                }
                
                if (securityCheck.requiresConfirmation) {
                    val confirmed = requestUserConfirmation(securityCheck)
                    if (!confirmed) {
                        return createErrorReport(taskId, "用户取消操作", startTime)
                    }
                }
            }
            
            // 3. 创建执行上下文
            currentContext = ExecutionContext(
                taskId = taskId,
                userRequest = input,
                intent = intentResult.intent,
                mode = _currentMode.value
            )
            
            // 4. 执行任务
            val result = when (intentResult.intent) {
                IntentClassifier.UserIntent.AUTOMATION_TASK -> {
                    executeAutomationTask(input, intentResult)
                }
                IntentClassifier.UserIntent.CASUAL_CHAT -> {
                    handleCasualChat(input)
                }
                IntentClassifier.UserIntent.INFORMATION_QUERY -> {
                    handleInformationQuery(input)
                }
                IntentClassifier.UserIntent.SYSTEM_CONTROL -> {
                    executeSystemControl(input, intentResult)
                }
                else -> {
                    createErrorReport(taskId, "无法理解的请求", startTime)
                }
            }
            
            // 5. 学习和优化
            if (config.enableLearning) {
                learningSystem.recordUserAction(
                    input = input,
                    action = intentResult.intent.name,
                    result = result.success,
                    executionTime = result.duration
                )
            }
            
            // 6. 记录执行历史
            executionHistory.add(result)
            
            // ✅ 标记用户消息成功
            EngineStateManager.markMessageSuccess(userMessageId)
            
            return result
            
        } catch (e: Exception) {
            LogManager.e(TAG, "处理用户输入失败", e)
            // ❌ 标记用户消息失败
            EngineStateManager.markMessageFailed(userMessageId, e.message ?: "未知错误")
            return createErrorReport(taskId, e.message ?: "未知错误", startTime)
        } finally {
            _isProcessing.value = false
            currentContext = null
        }
    }
    
    /**
     * 🔄 重试失败的消息
     * @param messageId 要重试的用户消息ID
     */
    suspend fun retryMessage(messageId: String): ExecutionReport {
        val message = EngineStateManager.getMessageById(messageId)
        if (message == null || !message.isUser) {
            return ExecutionReport(
                taskId = "error",
                success = false,
                duration = 0,
                stepsCompleted = 0,
                totalSteps = 0,
                errors = listOf("找不到要重试的消息")
            )
        }
        
        // 删除该消息之后的所有AI回复
        val aiResponseIds = EngineStateManager.getAIResponsesAfterMessage(messageId)
        aiResponseIds.forEach { EngineStateManager.removeMessage(it) }
        
        // 增加重试次数
        EngineStateManager.incrementRetryCount(messageId)
        
        // 重新处理消息
        return processUserInput(message.content, messageId)
    }
    
    /**
     * 🎤 处理语音输入
     */
    fun startVoiceInput() {
        if (!config.enableVoice) {
            LogManager.w(TAG, "语音功能未启用")
            return
        }
        
        voiceManager.startListening()
    }
    
    /**
     * 🔄 切换执行模式
     */
    fun setExecutionMode(mode: ExecutionMode) {
        LogManager.d(TAG, "切换执行模式: $mode")
        _currentMode.value = mode
        
        when (mode) {
            ExecutionMode.SAFE -> {
                SecurityManager.setStrictMode(true)
                performanceOptimizer.setPerformanceMode(PerformanceOptimizer.PerformanceMode.BALANCED)
            }
            ExecutionMode.LEARNING -> {
                learningSystem.initialize()
                EnhancedAccessibilityService.getInstance()?.setLearningMode(true)
            }
            ExecutionMode.DEMO -> {
                // 演示模式设置
            }
            ExecutionMode.DEBUG -> {
                // 调试模式设置
            }
            else -> {
                // 正常模式
            }
        }
    }
    
    /**
     * 📊 获取系统状态
     */
    fun getSystemStatus(): SystemStatus {
        return SystemStatus(
            engineState = _engineState.value,
            currentMode = _currentMode.value,
            isProcessing = _isProcessing.value,
            performanceScore = performanceOptimizer.getPerformanceReport().overallScore,
            securityScore = SecurityManager.getSecurityStatistics().safetyScore.toInt(),
            learningProgress = calculateLearningProgress(),
            activeModules = getActiveModules(),
            recentTasks = executionHistory.takeLast(5)
        )
    }
    
    /**
     * 系统状态
     */
    data class SystemStatus(
        val engineState: EngineState,
        val currentMode: ExecutionMode,
        val isProcessing: Boolean,
        val performanceScore: Int,
        val securityScore: Int,
        val learningProgress: Int,
        val activeModules: List<String>,
        val recentTasks: List<ExecutionReport>
    )
    
    // ==================== 私有方法 ====================
    
    /**
     * 初始化模块
     */
    private fun initializeModules() {
        LogManager.d(TAG, "初始化核心模块...")
        
        // AI模块
        intentClassifier = IntentClassifier()
        taskPlanner = TaskPlanner()
        screenAnalyzer = ScreenAnalyzer()
        
        // 交互模块
        voiceManager = VoiceInteractionManager(context)
        if (config.enableVoice) {
            voiceManager.initialize(
                config = VoiceInteractionManager.VoiceConfig(),
                onCommandReceived = { command ->
                    mainScope.launch {
                        processUserInput(command.text)
                    }
                }
            )
        }
        
        // 优化模块
        learningSystem = AdaptiveLearningSystem(context)
        if (config.enableLearning) {
            learningSystem.initialize()
        }
        
        performanceOptimizer = PerformanceOptimizer(context)
        if (config.enablePerformanceOptimization) {
            performanceOptimizer.initialize()
        }
        
        // 协作模块
        crossAppCoordinator = CrossAppCoordinator(context)
        adaptiveExecutionEngine = AdaptiveExecutionEngine.getInstance(context)
        
        LogManager.d(TAG, "✅ 模块初始化完成")
    }
    
    /**
     * 设置模块间通信
     */
    private fun setupModuleCommunication() {
        LogManager.d(TAG, "配置模块间通信...")
        
        // 学习系统与意图分类器通信
        mainScope.launch {
            learningSystem.currentModel.collect { model ->
                model?.let {
                    // 根据学习结果调整意图识别
                    LogManager.d(TAG, "更新意图识别模型")
                }
            }
        }
        
        // 性能优化器与其他模块通信
        mainScope.launch {
            performanceOptimizer.currentMode.collect { mode ->
                // 根据性能模式调整其他模块
                adjustModulesForPerformance(mode)
            }
        }
        
        LogManager.d(TAG, "✅ 模块通信配置完成")
    }
    
    /**
     * 加载用户数据
     */
    private fun loadUserData() {
        LogManager.d(TAG, "加载用户数据...")
        
        // 从AutomationEngine加载现有数据
        AutomationEngine.init(context)
        
        LogManager.d(TAG, "✅ 用户数据加载完成")
    }
    
    /**
     * 启动后台服务
     */
    private fun startBackgroundServices() {
        LogManager.d(TAG, "启动后台服务...")
        
        // 启动监控任务
        mainScope.launch {
            while (isActive) {
                delay(60000) // 每分钟检查一次
                performSystemMaintenance()
            }
        }
        
        LogManager.d(TAG, "✅ 后台服务已启动")
    }
    
    /**
     * 执行自动化任务
     */
    private suspend fun executeAutomationTask(
        input: String,
        intentResult: IntentClassifier.IntentResult
    ): ExecutionReport {
        val taskId = currentContext?.taskId ?: generateTaskId()
        val startTime = System.currentTimeMillis()

        val adaptiveReport = executeAutomationTaskWithAdaptiveEngine(input, taskId, startTime)
        if (adaptiveReport != null) {
            return adaptiveReport
        }
        
        try {
            // 获取屏幕状态
            val screenState = EnhancedAccessibilityService.getInstance()?.let { service ->
                screenAnalyzer.analyzeScreen(service.rootInActiveWindow)
            }
            
            // 规划任务
            val taskPlan = taskPlanner.planTask(input, intentResult, screenState)
            
            // 检查任务安全性
            if (config.enableSecurity) {
                val safetyCheck = SecurityManager.checkTaskPlanSafety(taskPlan)
                if (safetyCheck.level >= SecurityManager.SafetyLevel.HIGH_RISK) {
                    val confirmed = requestUserConfirmation(safetyCheck)
                    if (!confirmed) {
                        return createErrorReport(taskId, "任务被用户取消", startTime)
                    }
                }
            }
            
            // 执行任务步骤
            var completedSteps = 0
            val errors = mutableListOf<String>()
            
            for ((index, step) in taskPlan.steps.withIndex()) {
                LogManager.d(TAG, "执行步骤: ${step.description}")
                
                // 更新任务进度
                EngineStateManager.updateProgress(
                    TaskProgress(
                        currentStep = index + 1,
                        totalSteps = taskPlan.steps.size,
                        description = step.description,
                        percentage = (index + 1).toFloat() / taskPlan.steps.size,
                        taskName = "执行任务",
                        isRunning = true,
                        currentAction = step.action.name
                    )
                )
                EngineStateManager.updateStatus("执行中: ${step.description}")
                
                
                val stepSuccess = executeStep(step)
                if (stepSuccess) {
                    completedSteps++
                } else if (step.fallbackStepId != null) {
                    // 尝试备选步骤
                    val fallbackStep = taskPlan.steps.find { it.id == step.fallbackStepId }
                    if (fallbackStep != null && executeStep(fallbackStep)) {
                        completedSteps++
                    } else {
                        errors.add("步骤失败: ${step.description}")
                    }
                } else {
                    errors.add("步骤失败: ${step.description}")
                }
                
                delay(step.waitAfter)
            }
            
            return ExecutionReport(
                taskId = taskId,
                success = completedSteps == taskPlan.steps.size,
                duration = System.currentTimeMillis() - startTime,
                stepsCompleted = completedSteps,
                totalSteps = taskPlan.steps.size,
                errors = errors
            )
            
        } catch (e: Exception) {
            LogManager.e(TAG, "任务执行失败", e)
            return createErrorReport(taskId, e.message ?: "执行失败", startTime)
        }
    }
    
    private suspend fun executeAutomationTaskWithAdaptiveEngine(
        input: String,
        taskId: String,
        startTime: Long
    ): ExecutionReport? {
        return try {
            val finalState = CompletableDeferred<ExecutionEngineState>()
            var started = false
            var stepsCompleted = 0
            var totalSteps = 0
            val progressMessages = mutableListOf<String>()

            val watcher = mainScope.launch {
                adaptiveExecutionEngine.state.collect { state ->
                    when (state) {
                        ExecutionEngineState.Analyzing -> {
                            started = true
                            EngineStateManager.updateStatus("思考中...")
                        }
                        is ExecutionEngineState.Executing -> {
                            started = true
                            stepsCompleted = state.current
                            totalSteps = state.total
                            EngineStateManager.updateStatus(state.message)
                            EngineStateManager.updateProgress(
                                TaskProgress(
                                    currentStep = state.current,
                                    totalSteps = state.total,
                                    description = state.message,
                                    percentage = if (state.total > 0) state.current.toFloat() / state.total else 0f,
                                    taskName = "智能执行",
                                    isRunning = true,
                                    currentAction = state.message
                                )
                            )
                        }
                        is ExecutionEngineState.Completed,
                        is ExecutionEngineState.Failed,
                        ExecutionEngineState.Cancelled -> {
                            if (started && !finalState.isCompleted) {
                                finalState.complete(state)
                            }
                        }
                        ExecutionEngineState.Idle -> Unit
                    }
                }
            }

            adaptiveExecutionEngine.executeCommand(input) { message ->
                if (message.isNotBlank()) {
                    progressMessages.add(message)
                    EngineStateManager.updateStatus(message)
                }
            }

            val terminalState = withTimeoutOrNull(maxOf(config.defaultTimeout, 180000L)) {
                finalState.await()
            }

            watcher.cancel()

            if (terminalState == null) {
                adaptiveExecutionEngine.stop()
                LogManager.w(TAG, "自适应执行超时，回退到规划执行")
                return null
            }

            when (terminalState) {
                is ExecutionEngineState.Completed -> ExecutionReport(
                    taskId = taskId,
                    success = true,
                    duration = System.currentTimeMillis() - startTime,
                    stepsCompleted = if (totalSteps > 0) totalSteps else stepsCompleted,
                    totalSteps = if (totalSteps > 0) totalSteps else stepsCompleted.coerceAtLeast(1),
                    learnings = progressMessages.takeLast(5)
                )
                is ExecutionEngineState.Failed -> {
                    LogManager.w(TAG, "自适应执行失败，回退到规划执行: ${terminalState.error}")
                    null
                }
                ExecutionEngineState.Cancelled -> {
                    LogManager.w(TAG, "自适应执行被取消，回退到规划执行")
                    null
                }
                else -> null
            }
        } catch (e: Exception) {
            LogManager.w(TAG, "自适应执行不可用，回退到规划执行: ${e.message}")
            null
        }
    }

    /**
     * 执行任务步骤
     */
    private suspend fun executeStep(step: TaskPlanner.ExecutionStep): Boolean {
        val accessibilityService = EnhancedAccessibilityService.getInstance()
        if (accessibilityService == null && step.action != TaskPlanner.ActionType.LAUNCH_APP) {
            return false
        }
        
        return try {
            when (step.action) {
                TaskPlanner.ActionType.LAUNCH_APP -> {
                    step.target?.let { target ->
                        if (accessibilityService != null) {
                            accessibilityService.launchApp(target) || launchAppLocally(target)
                        } else {
                            launchAppLocally(target)
                        }
                    } ?: false
                }
                TaskPlanner.ActionType.CLICK -> {
                    step.target?.let { accessibilityService?.smartClick(it) ?: false } ?: false
                }
                TaskPlanner.ActionType.INPUT_TEXT -> {
                    step.value?.let { accessibilityService?.smartInputText(it, step.target) ?: false } ?: false
                }
                TaskPlanner.ActionType.SWIPE -> {
                    step.value?.let { accessibilityService?.smartScroll(it) ?: false } ?: false
                }
                TaskPlanner.ActionType.BACK -> {
                    accessibilityService?.performBack() ?: false
                }
                TaskPlanner.ActionType.HOME -> {
                    accessibilityService?.performHome() ?: false
                }
                else -> false
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "步骤执行失败: ${step.description}", e)
            false
        }
    }
    
    /**
     * 处理闲聊
     */
    private suspend fun launchAppLocally(target: String): Boolean {
        return try {
            val packageCandidates = buildLocalPackageCandidates(target)
            if (packageCandidates.any { launchPackageWithContext(it) }) {
                delay(2000)
                return true
            }
            val launcherIntent = findLocalLauncherIntentByKeywords(buildLocalSearchKeywords(target)) ?: return false
            launcherIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launcherIntent)
            delay(2000)
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "本地启动应用失败: " + target, e)
            false
        }
    }

    private fun launchPackageWithContext(packageName: String): Boolean {
        if (packageName.isBlank()) {
            return false
        }
        return try {
            val intent = context.packageManager.getLaunchIntentForPackage(packageName) ?: return false
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun buildLocalPackageCandidates(query: String): List<String> {
        val normalizedQuery = normalizeLocalAppKeyword(query)
        val candidates = LinkedHashSet<String>()
        if (query.contains('.')) {
            candidates.add(query)
        }
        knownLocalAppMappings().forEach { (aliases, packages) ->
            if (aliases.any { alias ->
                    val normalizedAlias = normalizeLocalAppKeyword(alias)
                    normalizedQuery == normalizedAlias || normalizedQuery.contains(normalizedAlias)
                }) {
                candidates.addAll(packages)
            }
        }
        return candidates.toList()
    }

    private fun buildLocalSearchKeywords(query: String): List<String> {
        val normalizedQuery = normalizeLocalAppKeyword(query)
        val keywords = LinkedHashSet<String>()
        keywords.add(query.trim())
        knownLocalAppMappings().forEach { (aliases, packages) ->
            if (aliases.any { alias ->
                    val normalizedAlias = normalizeLocalAppKeyword(alias)
                    normalizedQuery == normalizedAlias || normalizedQuery.contains(normalizedAlias)
                }) {
                keywords.addAll(aliases)
                keywords.addAll(packages)
            }
        }
        return keywords.filter { it.isNotBlank() }
    }

    private fun findLocalLauncherIntentByKeywords(keywords: List<String>): Intent? {
        if (keywords.isEmpty()) {
            return null
        }
        val launcherIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val activities = context.packageManager.queryIntentActivities(launcherIntent, 0)
        val matchedActivity = activities.firstOrNull { info ->
            val label = info.loadLabel(context.packageManager)?.toString().orEmpty()
            val packageName = info.activityInfo?.packageName.orEmpty()
            keywords.any { keyword ->
                keyword.isNotBlank() && (
                    label.contains(keyword, ignoreCase = true) ||
                        packageName.contains(keyword, ignoreCase = true)
                    )
            }
        } ?: return null
        return Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            setClassName(matchedActivity.activityInfo.packageName, matchedActivity.activityInfo.name)
        }
    }

    private fun normalizeLocalAppKeyword(value: String): String {
        return value.trim()
            .lowercase()
            .replace(Regex("\\s+"), "")
            .removeSuffix("应用")
            .removeSuffix("app")
    }

    private fun knownLocalAppMappings(): List<Pair<List<String>, List<String>>> {
        return listOf(
            listOf("微信", "wechat") to listOf("com.tencent.mm"),
            listOf("QQ", "qq", "腾讯qq") to listOf("com.tencent.mobileqq"),
            listOf("支付宝", "alipay") to listOf("com.eg.android.AlipayGphone"),
            listOf("淘宝", "taobao") to listOf("com.taobao.taobao"),
            listOf("抖音", "douyin") to listOf("com.ss.android.ugc.aweme"),
            listOf("快手", "kuaishou") to listOf("com.kuaishou.nebula", "com.smile.gifmaker"),
            listOf("哔哩哔哩", "B站", "b站", "bilibili") to listOf("tv.danmaku.bili"),
            listOf("小红书", "xiaohongshu", "redbook") to listOf("com.xingin.xhs"),
            listOf("京东", "jd", "jingdong") to listOf("com.jingdong.app.mall"),
            listOf("拼多多", "pdd", "pinduoduo") to listOf("com.xunmeng.pinduoduo")
        )
    }

    private suspend fun handleCasualChat(input: String): ExecutionReport {
        val taskId = currentContext?.taskId ?: generateTaskId()
        val startTime = System.currentTimeMillis()
        
        // 🆕 获取上下文信息（位置、时间、活动等）
        val contextEngine = com.example.xihe.context.ContextAwarenessEngine.getInstance(context)
        val userContext = contextEngine.currentContext.value
        
        // 🆕 构建上下文信息字符串
        val contextInfo = buildContextInfo(userContext)
        
        // 使用配置好的LLM客户端生成回复
        val llmClient = LLMClient(
            AutomationEngine.baseUrl,
            AutomationEngine.apiKey,
            AutomationEngine.modelName,
            AutomationEngine.providerId
        )
        
        var isError = false
        var errorMsg: String? = null
        
        val rawResponse = try {
            // 🆕 将上下文信息添加到用户输入中
            val enrichedInput = if (contextInfo.isNotBlank()) {
                "【当前上下文】\n$contextInfo\n\n【用户问题】\n$input"
            } else {
                input
            }
            
            LogManager.d(TAG, "📍 发送给LLM的完整输入: $enrichedInput")
            
            val llmResponse = llmClient.chatCompletion(enrichedInput)
            if (llmResponse.isBlank()) {
                "抱歉，我暂时无法回答这个问题"
            } else {
                llmResponse
            }
        } catch (e: LLMClient.OfflineException) {
            LogManager.w(TAG, "LLM离线: ${e.message}")
            isError = true
            errorMsg = e.message
            "抱歉，网络连接出现问题，请稍后再试"
        } catch (e: Exception) {
            LogManager.e(TAG, "LLM调用失败", e)
            isError = true
            errorMsg = e.message
            "抱歉，服务暂时不可用: ${e.message}"
        }
        
        // 🧠 解析思考内容，分离显示内容和思考过程
        val (thinkingContent, displayContent) = AutomationEngine.parseThinkingContent(rawResponse)
        val response = displayContent.ifBlank { rawResponse }
        
        LogManager.d(TAG, "💬 回复: $response")
        if (thinkingContent != null) {
            LogManager.d(TAG, "🧠 思考内容: ${thinkingContent.take(100)}...")
        }
        
        // 🧠 记录AI回复到上下文
        recordAIResponse(response)
        
        // 添加AI回复消息（带状态）
        EngineStateManager.addMessage(
            ChatMessageDisplay(
                content = response, 
                isUser = false,
                thinkingContent = thinkingContent,
                status = if (isError) com.example.xihe.core.model.MessageStatus.FAILED 
                        else com.example.xihe.core.model.MessageStatus.SUCCESS,
                errorMessage = errorMsg
            )
        )
        EngineStateManager.updateStatus("Idle")
        
        // 语音播报（仅成功时）
        if (config.enableVoice && !isError) {
            ModuleCoordinator.speak(response)
        }
        
        // 📚 记录学习数据
        if (config.enableLearning) {
            learningSystem.recordUserAction(
                input = input,
                action = "chat",
                result = !isError,
                executionTime = System.currentTimeMillis() - startTime,
                context = mapOf("type" to "casual_chat")
            )
        }
        
        // 如果是错误，抛出异常让上层处理
        if (isError) {
            throw Exception(errorMsg ?: "AI回复失败")
        }
        
        return ExecutionReport(
            taskId = taskId,
            success = true,
            duration = System.currentTimeMillis() - startTime,
            stepsCompleted = 1,
            totalSteps = 1
        )
    }
    
    /**
     * 处理信息查询
     */
    private suspend fun handleInformationQuery(input: String): ExecutionReport {
        val taskId = currentContext?.taskId ?: generateTaskId()
        val startTime = System.currentTimeMillis()
        
        // 🆕 获取上下文信息（位置、时间、活动等）
        val contextEngine = com.example.xihe.context.ContextAwarenessEngine.getInstance(context)
        val userContext = contextEngine.currentContext.value
        
        // 🆕 构建上下文信息字符串
        val contextInfo = buildContextInfo(userContext)
        
        // 使用配置好的LLM客户端处理信息查询
        val llmClient = LLMClient(
            AutomationEngine.baseUrl,
            AutomationEngine.apiKey,
            AutomationEngine.modelName,
            AutomationEngine.providerId
        )
        
        var isError = false
        var errorMsg: String? = null
        
        val rawResponse = try {
            // 🆕 将上下文信息添加到用户输入中
            val enrichedInput = if (contextInfo.isNotBlank()) {
                "【当前上下文】\n$contextInfo\n\n【用户问题】\n$input"
            } else {
                input
            }
            
            LogManager.d(TAG, "📍 发送给LLM的完整输入: $enrichedInput")
            
            val llmResponse = llmClient.chatCompletion(enrichedInput)
            if (llmResponse.isBlank()) {
                when {
                    input.contains("天气") -> "抱歉，暂时无法获取天气信息"
                    input.contains("新闻") -> "抱歉，暂时无法获取新闻"
                    else -> "抱歉，暂时无法查询相关信息"
                }
            } else {
                llmResponse
            }
        } catch (e: LLMClient.OfflineException) {
            LogManager.w(TAG, "LLM离线: ${e.message}")
            isError = true
            errorMsg = e.message
            "抱歉，网络连接出现问题，请稍后再试"
        } catch (e: Exception) {
            LogManager.e(TAG, "LLM调用失败", e)
            isError = true
            errorMsg = e.message
            "抱歉，服务暂时不可用: ${e.message}"
        }
        
        // 🧠 解析思考内容，分离显示内容和思考过程
        val (thinkingContent, displayContent) = AutomationEngine.parseThinkingContent(rawResponse)
        val response = displayContent.ifBlank { rawResponse }
        
        LogManager.d(TAG, "🔍 查询结果: $response")
        
        // 🧠 记录AI回复到上下文
        recordAIResponse(response)
        
        EngineStateManager.addMessage(
            ChatMessageDisplay(
                content = response, 
                isUser = false,
                thinkingContent = thinkingContent,
                status = if (isError) com.example.xihe.core.model.MessageStatus.FAILED 
                        else com.example.xihe.core.model.MessageStatus.SUCCESS,
                errorMessage = errorMsg
            )
        )
        EngineStateManager.updateStatus("Idle")
        
        // 语音播报（仅成功时）
        if (config.enableVoice && !isError) {
            ModuleCoordinator.speak(response)
        }
        
        // 如果是错误，抛出异常让上层处理
        if (isError) {
            throw Exception(errorMsg ?: "查询失败")
        }
        
        return ExecutionReport(
            taskId = taskId,
            success = true,
            duration = System.currentTimeMillis() - startTime,
            stepsCompleted = 1,
            totalSteps = 1
        )
    }
    
    /**
     * 执行系统控制
     */
    private suspend fun executeSystemControl(
        input: String,
        intentResult: IntentClassifier.IntentResult
    ): ExecutionReport {
        val taskId = currentContext?.taskId ?: generateTaskId()
        val startTime = System.currentTimeMillis()
        
        // 执行系统操作
        val success = when {
            input.contains("音量") -> adjustVolume(intentResult.entities["direction"] as? String)
            input.contains("亮度") -> adjustBrightness(intentResult.entities["value"] as? Int)
            input.contains("WiFi") -> toggleWiFi()
            else -> false
        }
        
        return ExecutionReport(
            taskId = taskId,
            success = success,
            duration = System.currentTimeMillis() - startTime,
            stepsCompleted = if (success) 1 else 0,
            totalSteps = 1
        )
    }
    
    /**
     * 请求用户确认
     */
    private suspend fun requestUserConfirmation(
        securityCheck: SecurityManager.SecurityCheckResult
    ): Boolean {
        // 实现用户确认逻辑
        LogManager.d(TAG, "请求用户确认: ${securityCheck.warnings}")
        return true // 示例实现
    }
    
    /**
     * 创建错误报告
     */
    private fun createErrorReport(taskId: String, error: String, startTime: Long): ExecutionReport {
        return ExecutionReport(
            taskId = taskId,
            success = false,
            duration = System.currentTimeMillis() - startTime,
            stepsCompleted = 0,
            totalSteps = 0,
            errors = listOf(error)
        )
    }
    
    /**
     * 生成任务ID
     */
    private fun generateTaskId(): String {
        return "task_${System.currentTimeMillis()}_${(0..9999).random()}"
    }
    
    /**
     * 计算学习进度
     */
    private fun calculateLearningProgress(): Int {
        val model = learningSystem.currentModel.value ?: return 0
        return minOf(100, model.totalInteractions / 10)
    }
    
    /**
     * 获取活动模块
     */
    private fun getActiveModules(): List<String> {
        val modules = mutableListOf("Core")
        
        if (config.enableVoice) modules.add("Voice")
        if (config.enableLearning) modules.add("Learning")
        if (config.enableSecurity) modules.add("Security")
        if (config.enablePerformanceOptimization) modules.add("Performance")
        if (EnhancedAccessibilityService.isConnected.value) modules.add("Accessibility")
        
        return modules
    }
    
    /**
     * 根据性能模式调整模块
     */
    private fun adjustModulesForPerformance(mode: PerformanceOptimizer.PerformanceMode) {
        when (mode) {
            PerformanceOptimizer.PerformanceMode.ULTRA_SAVING -> {
                // 超级省电模式：关闭非必要功能
                voiceManager.release()
            }
            PerformanceOptimizer.PerformanceMode.POWER_SAVING -> {
                // 省电模式：降低功能频率
            }
            else -> {
                // 正常或高性能模式
            }
        }
    }
    
    /**
     * 系统维护
     */
    private suspend fun performSystemMaintenance() {
        // 清理过期数据
        if (executionHistory.size > 100) {
            executionHistory.subList(0, executionHistory.size - 100).clear()
        }
        
        // 优化内存
        if (performanceOptimizer.systemStatus.value?.memoryUsage ?: 0f > 70f) {
            performanceOptimizer.optimizeMemory()
        }
        
        // 保存学习数据
        if (config.enableLearning && executionHistory.size % 10 == 0) {
            // 触发学习系统保存
        }
    }
    
    // 系统控制辅助方法
    private fun adjustVolume(direction: String?): Boolean {
        // 实现音量调节
        return true
    }
    
    private fun adjustBrightness(value: Int?): Boolean {
        // 实现亮度调节
        return true
    }
    
    private fun toggleWiFi(): Boolean {
        // 实现WiFi切换
        return true
    }
    
    /**
     * 🧠 更新对话上下文
     */
    private fun updateConversationContext(userInput: String, intentResult: IntentClassifier.IntentResult) {
        // 更新最近消息列表
        recentUserInputs.add(userInput)
        if (recentUserInputs.size > MAX_CONTEXT_MESSAGES) {
            recentUserInputs.removeAt(0)
        }
        
        // 合并消息列表（用户输入和AI回复交替）
        val allMessages = mutableListOf<String>()
        val maxSize = maxOf(recentUserInputs.size, recentAIResponses.size)
        for (i in 0 until maxSize) {
            if (i < recentAIResponses.size) allMessages.add(recentAIResponses[i])
            if (i < recentUserInputs.size) allMessages.add(recentUserInputs[i])
        }
        
        // 推断当前话题
        val currentTopic = inferCurrentTopic(userInput, intentResult)
        
        // 更新上下文
        conversationContext = ConversationContext(
            lastIntent = intentResult.intent,
            lastEntities = intentResult.entities,
            conversationTurns = conversationContext.conversationTurns + 1,
            currentTopic = currentTopic,
            recentMessages = allMessages.takeLast(MAX_CONTEXT_MESSAGES),
            currentApp = intentResult.entities["app"] as? String ?: conversationContext.currentApp,
            screenType = conversationContext.screenType
        )
        
        LogManager.d(TAG, "🧠 上下文已更新: 轮数=${conversationContext.conversationTurns}, 话题=$currentTopic")
    }
    
    /**
     * 🧠 记录AI回复到上下文
     */
    private fun recordAIResponse(response: String) {
        recentAIResponses.add(response)
        if (recentAIResponses.size > MAX_CONTEXT_MESSAGES) {
            recentAIResponses.removeAt(0)
        }
    }
    
    /**
     * 🎯 推断当前话题
     */
    private fun inferCurrentTopic(input: String, intentResult: IntentClassifier.IntentResult): String {
        // 根据实体推断话题
        intentResult.entities["app"]?.let { return "关于${it}的操作" }
        intentResult.entities["contact"]?.let { return "与${it}的消息" }
        intentResult.entities["topic"]?.let { return it.toString() }
        
        // 根据意图推断话题
        return when (intentResult.intent) {
            IntentClassifier.UserIntent.CASUAL_CHAT -> "日常闲聊"
            IntentClassifier.UserIntent.AUTOMATION_TASK -> "自动化任务"
            IntentClassifier.UserIntent.INFORMATION_QUERY -> "信息查询"
            IntentClassifier.UserIntent.SYSTEM_CONTROL -> "系统控制"
            else -> conversationContext.currentTopic ?: "一般对话"
        }
    }
    
    /**
     * 🔄 重置对话上下文（开始新会话时调用）
     */
    fun resetConversationContext() {
        conversationContext = ConversationContext()
        recentUserInputs.clear()
        recentAIResponses.clear()
        LogManager.d(TAG, "🔄 对话上下文已重置")
    }
    
    /**
     * 📍 构建上下文信息字符串
     * 将用户的位置、时间、活动等信息格式化为可读的字符串
     */
    private fun buildContextInfo(userContext: com.example.xihe.context.UserContext): String {
        val parts = mutableListOf<String>()
        
        // 位置信息
        userContext.location?.let { location ->
            val placeTypeStr = when (location.placeType) {
                com.example.xihe.context.PlaceType.HOME -> "家"
                com.example.xihe.context.PlaceType.OFFICE -> "办公室"
                com.example.xihe.context.PlaceType.RESTAURANT -> "餐厅"
                com.example.xihe.context.PlaceType.SHOPPING_MALL -> "商场"
                com.example.xihe.context.PlaceType.TRANSPORT -> "交通工具中"
                com.example.xihe.context.PlaceType.PARK -> "公园"
                com.example.xihe.context.PlaceType.GYM -> "健身房"
                com.example.xihe.context.PlaceType.HOSPITAL -> "医院"
                com.example.xihe.context.PlaceType.SCHOOL -> "学校"
                com.example.xihe.context.PlaceType.AIRPORT -> "机场"
                com.example.xihe.context.PlaceType.TRAIN_STATION -> "火车站"
                else -> null
            }
            
            val locationStr = if (location.placeName != null) {
                "位置: ${location.placeName}"
            } else if (placeTypeStr != null) {
                "位置: $placeTypeStr"
            } else {
                "位置: 纬度${String.format("%.4f", location.latitude)}, 经度${String.format("%.4f", location.longitude)}"
            }
            parts.add(locationStr)
        }
        
        // 时间信息
        val timeStr = when (userContext.timeOfDay) {
            com.example.xihe.context.TimeOfDay.LATE_NIGHT -> "深夜"
            com.example.xihe.context.TimeOfDay.EARLY_MORNING -> "清晨"
            com.example.xihe.context.TimeOfDay.MORNING -> "上午"
            com.example.xihe.context.TimeOfDay.NOON -> "中午"
            com.example.xihe.context.TimeOfDay.AFTERNOON -> "下午"
            com.example.xihe.context.TimeOfDay.EVENING -> "傍晚"
            com.example.xihe.context.TimeOfDay.NIGHT -> "晚上"
            else -> null
        }
        timeStr?.let { parts.add("时间: $it") }
        
        // 活动信息
        val activityStr = when (userContext.activity) {
            com.example.xihe.context.ActivityType.STILL -> "静止"
            com.example.xihe.context.ActivityType.WALKING -> "步行中"
            com.example.xihe.context.ActivityType.RUNNING -> "跑步中"
            com.example.xihe.context.ActivityType.CYCLING -> "骑行中"
            com.example.xihe.context.ActivityType.IN_VEHICLE -> "在车内"
            else -> null
        }
        activityStr?.let { parts.add("活动: $it") }
        
        // 电量信息（低电量时提醒）
        if (userContext.batteryLevel in 1..20) {
            parts.add("电量: ${userContext.batteryLevel}% (低电量)")
        }
        
        // 网络信息
        val networkStr = when (userContext.networkType) {
            com.example.xihe.context.NetworkType.WIFI -> "WiFi"
            com.example.xihe.context.NetworkType.MOBILE_5G -> "5G"
            com.example.xihe.context.NetworkType.MOBILE_4G -> "4G"
            com.example.xihe.context.NetworkType.MOBILE_3G -> "3G"
            com.example.xihe.context.NetworkType.NO_NETWORK -> "无网络"
            else -> null
        }
        networkStr?.let { parts.add("网络: $it") }
        
        return parts.joinToString(", ")
    }
    
    /**
     * 🧹 释放资源
     */
    fun release() {
        LogManager.d(TAG, "释放引擎资源...")
        
        voiceManager.release()
        learningSystem.release()
        performanceOptimizer.release()
        crossAppCoordinator.release()
        
        mainScope.cancel()
        _engineState.value = EngineState.UNINITIALIZED
        
        LogManager.d(TAG, "引擎资源已释放")
    }
}
