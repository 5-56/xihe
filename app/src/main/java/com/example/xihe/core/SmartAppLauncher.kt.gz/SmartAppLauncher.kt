package com.example.xihe.core

import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.core.QuickCommandExecutor
import kotlinx.coroutines.delay

/**
 * 🚀 智能应用启动器
 * 负责智能理解用户意图并打开应用
 * 
 * 核心能力：
 * 1. 多种方式识别应用（中英文、简称、别名）
 * 2. 自动纠错（语音识别错误）
 * 3. 智能备用方案（找不到时通过桌面搜索）
 * 4. 友好的反馈信息
 */
object SmartAppLauncher {
    private const val TAG = "SmartAppLauncher"
    
    /**
     * 🎯 智能打开应用（主入口）
     * 
     * @param userInput 用户输入（如："打开微信"、"启动相机"、"相册"等）
     * @param context Android上下文
     * @param onProgress 进度回调
     * @return 执行结果消息
     */
    suspend fun launchApp(
        userInput: String,
        context: Context,
        onProgress: ((String) -> Unit)? = null
    ): LaunchResult {
        LogManager.i(TAG, "🚀 智能启动应用: $userInput")
        onProgress?.invoke("正在理解您的指令...")
        
        // 1️⃣ 提取应用名
        val appName = extractAppName(userInput)
        if (appName.isEmpty()) {
            LogManager.w(TAG, "❌ 无法提取应用名")
            return LaunchResult.Failure("没听清您要打开哪个应用呢~ 可以再说一次吗？🥺")
        }
        
        LogManager.d(TAG, "📝 提取到应用名: $appName")
        onProgress?.invoke("正在查找 $appName ...")
        
        // 2️⃣ 尝试识别为快速指令
        val command = QuickCommandExecutor.recognizeCommand("打开 $appName", context)
        
        // 3️⃣ 执行指令
        onProgress?.invoke("正在打开 $appName ...")
        val result = when (command) {
            is QuickCommandExecutor.QuickCommand.OpenApp -> {
                LogManager.d(TAG, "✅ 识别为打开应用指令: ${command.appName}")
                val execResult = QuickCommandExecutor.executeCommand(command, context)
                
                when (execResult) {
                    is QuickCommandExecutor.ExecutionResult.Success -> {
                        LaunchResult.Success(execResult.message)
                    }
                    is QuickCommandExecutor.ExecutionResult.Failure -> {
                        LaunchResult.Failure(execResult.message)
                    }
                    is QuickCommandExecutor.ExecutionResult.NotRecognized -> {
                        LaunchResult.Failure("找不到 $appName 应用呢~ 😢")
                    }
                }
            }
            is QuickCommandExecutor.QuickCommand.Unknown -> {
                // 如果没识别为打开应用，尝试直接搜索
                LogManager.d(TAG, "⚠️ 未识别为标准指令，尝试直接搜索应用")
                searchAndLaunchApp(appName, context)
            }
            else -> {
                LaunchResult.Failure("这个指令我还不太会呢~ 🥺")
            }
        }
        
        return result
    }
    
    /**
     * 📝 从用户输入中提取应用名
     */
    private fun extractAppName(userInput: String): String {
        val input = userInput.trim()
        
        // 移除常见的打开指令前缀
        val prefixes = listOf(
            "打开", "启动", "开启", "运行", "打开一下", "帮我打开",
            "我想打开", "帮忙打开", "给我打开",
            "open", "start", "launch"
        )
        
        var appName = input
        for (prefix in prefixes) {
            if (input.lowercase().startsWith(prefix.lowercase())) {
                appName = input.substring(prefix.length).trim()
                break
            }
        }
        
        return appName
    }
    
    /**
     * 🔍 搜索并启动应用（备用方案）
     */
    private suspend fun searchAndLaunchApp(
        appName: String,
        context: Context
    ): LaunchResult {
        try {
            LogManager.d(TAG, "🔍 搜索应用: $appName")
            
            // 查找包名
            val packageName = findPackageNameFuzzy(appName, context)
            if (packageName != null) {
                LogManager.d(TAG, "✅ 找到应用包名: $packageName")
                
                // 尝试启动
                try {
                    val intent = context.packageManager.getLaunchIntentForPackage(packageName)
                    if (intent != null) {
                        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(intent)
                        return LaunchResult.Success("已经帮您打开 $appName 啦~ ✅")
                    }
                } catch (e: Exception) {
                    LogManager.e(TAG, "启动失败: ${e.message}")
                }
            }
            
            // 如果还是失败，返回友好提示
            return LaunchResult.Failure(
                "找不到 $appName 应用呢~ 😢\n" +
                "请检查：\n" +
                "1. 应用名称是否正确？\n" +
                "2. 应用是否已安装？\n" +
                "3. 可以试试说完整的应用名哦~"
            )
            
        } catch (e: Exception) {
            LogManager.e(TAG, "搜索应用出错", e)
            return LaunchResult.Failure("搜索应用时出错了: ${e.message}")
        }
    }
    
    /**
     * 🧠 模糊查找包名
     */
    private fun findPackageNameFuzzy(appName: String, context: Context): String? {
        val pm = context.packageManager
        val installedApps = pm.getInstalledApplications(android.content.pm.PackageManager.GET_META_DATA)
        val normalizedInput = appName.lowercase().trim()
        
        // 1. 完全匹配
        for (app in installedApps) {
            val label = pm.getApplicationLabel(app).toString().lowercase()
            if (label == normalizedInput) {
                return app.packageName
            }
        }
        
        // 2. 包含匹配
        for (app in installedApps) {
            val label = pm.getApplicationLabel(app).toString().lowercase()
            if (label.contains(normalizedInput) || normalizedInput.contains(label)) {
                return app.packageName
            }
        }
        
        return null
    }
    
    /**
     * 📊 启动结果
     */
    sealed class LaunchResult {
        data class Success(val message: String) : LaunchResult()
        data class Failure(val message: String) : LaunchResult()
    }
}
