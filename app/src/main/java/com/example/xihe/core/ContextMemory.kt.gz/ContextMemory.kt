package com.example.xihe.core

import android.content.Context
import com.example.xihe.utils.LogManager
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/**
 * 🧠 增强版上下文记忆管理器 (Enhanced Context Memory Manager)
 * 让羲和能永久记住主人说过的话、做过的事情，实现真正的长期记忆！
 * 
 * 记忆类型：
 * 1. 短期记忆 - 最近的对话（会话内）
 * 2. 长期记忆 - 永久存储的重要信息
 * 3. 用户画像 - 用户偏好、习惯、常用联系人等
 * 4. 事实记忆 - 具体的事实信息（生日、地址等）
 * 5. 情感记忆 - 用户的情绪状态和喜好
 */
object ContextMemory {
    private const val TAG = "ContextMemory"
    private const val MEMORY_FILE_NAME = "context_memory.json"
    private const val LONG_TERM_FILE_NAME = "long_term_memory.json"
    private const val USER_PROFILE_FILE_NAME = "user_profile.json"
    
    private const val MAX_SHORT_TERM_SIZE = 50  // 短期记忆最多保留50条
    private const val MAX_LONG_TERM_SIZE = 500  // 长期记忆最多保留500条
    
    // JSON解析器配置
    private val json = Json { 
        ignoreUnknownKeys = true 
        prettyPrint = true
    }
    
    // ==================== 数据结构定义 ====================
    
    /**
     * 记忆条目
     */
    @Serializable
    data class MemoryItem(
        val id: String = UUID.randomUUID().toString(),
        val timestamp: Long,
        val userMessage: String,
        val aiResponse: String,
        val contextTags: List<String> = emptyList(),
        val importance: Int = 1,  // 重要性 1-5
        val category: MemoryCategory = MemoryCategory.GENERAL
    )
    
    /**
     * 记忆分类
     */
    @Serializable
    enum class MemoryCategory {
        GENERAL,      // 一般对话
        TASK,         // 任务执行
        PERSONAL,     // 个人信息
        PREFERENCE,   // 偏好设置
        RELATIONSHIP, // 人际关系
        SCHEDULE,     // 日程相关
        LEARNING      // 学习记录
    }
    
    /**
     * 长期记忆条目 - 永久存储
     */
    @Serializable
    data class LongTermMemory(
        val id: String = UUID.randomUUID().toString(),
        val createdAt: Long,
        val updatedAt: Long = createdAt,
        val category: MemoryCategory,
        val key: String,           // 记忆键（如"妈妈的生日"）
        val value: String,         // 记忆值（如"3月15日"）
        val source: String = "",   // 来源（哪次对话）
        val confidence: Float = 1.0f,  // 置信度
        val accessCount: Int = 0   // 访问次数
    )
    
    /**
     * 用户画像
     */
    @Serializable
    data class UserProfile(
        // 基本信息
        var nickname: String = "",           // 用户昵称
        var preferredName: String = "",      // 喜欢被称呼的方式
        
        // 偏好设置
        val appPreferences: MutableMap<String, String> = mutableMapOf(),  // 常用应用偏好
        val contactPreferences: MutableMap<String, String> = mutableMapOf(), // 常用联系人
        val communicationStyle: MutableMap<String, String> = mutableMapOf(), // 沟通风格偏好
        
        // 习惯记录
        val dailyPatterns: MutableMap<String, String> = mutableMapOf(),  // 日常习惯
        val frequentTasks: MutableList<String> = mutableListOf(),        // 常用任务
        
        // 兴趣爱好
        val interests: MutableList<String> = mutableListOf(),
        val dislikes: MutableList<String> = mutableListOf(),
        
        // 重要人物
        val importantPeople: MutableMap<String, PersonInfo> = mutableMapOf(),
        
        // 统计信息
        var totalInteractions: Int = 0,
        var lastInteractionTime: Long = 0
    )
    
    /**
     * 人物信息
     */
    @Serializable
    data class PersonInfo(
        val name: String,
        val relationship: String = "",  // 关系：朋友、家人、同事等
        val contactMethod: String = "", // 联系方式：微信、QQ等
        val notes: String = ""          // 备注
    )
    
    /**
     * 上下文数据（短期）
     */
    @Serializable
    data class ContextData(
        val shortTermMemory: MutableList<MemoryItem> = mutableListOf(),
        val userPreferences: MutableMap<String, String> = mutableMapOf(),
        val keyFacts: MutableMap<String, String> = mutableMapOf(),
        val sessionStartTime: Long = System.currentTimeMillis()
    )
    
    /**
     * 长期记忆数据
     */
    @Serializable
    data class LongTermData(
        val memories: MutableList<LongTermMemory> = mutableListOf(),
        val lastCleanupTime: Long = System.currentTimeMillis()
    )
    
    // ==================== 内存数据 ====================
    
    // 🔒 线程安全：使用 synchronized 保护共享数据
    private val memoryLock = Any()
    private var contextData = ContextData()
    private var longTermData = LongTermData()
    private var userProfile = UserProfile()
    private var isInitialized = false
    
    // ==================== 初始化 ====================
    
    fun init(appContext: Context) {
        if (isInitialized) return
        
        loadAllMemory(appContext)
        isInitialized = true
        LogManager.d(TAG, "🧠 记忆系统初始化完成！短期记忆: ${contextData.shortTermMemory.size}条, 长期记忆: ${longTermData.memories.size}条")
    }
    
    // ==================== 短期记忆操作 ====================
    
    fun addMemory(appContext: Context, userMsg: String, aiResp: String, tags: List<String> = emptyList()) {
        synchronized(memoryLock) {
            val item = MemoryItem(
                timestamp = System.currentTimeMillis(),
                userMessage = userMsg,
                aiResponse = aiResp,
                contextTags = tags,
                importance = calculateImportance(userMsg, aiResp),
                category = categorizeMemory(userMsg)
            )
            contextData.shortTermMemory.add(item)
            
            // 保持短期记忆在限制内
            while (contextData.shortTermMemory.size > MAX_SHORT_TERM_SIZE) {
                // 移除最旧且重要性最低的
                val toRemove = contextData.shortTermMemory
                    .sortedWith(compareBy({ it.importance }, { it.timestamp }))
                    .firstOrNull()
                if (toRemove != null) {
                    contextData.shortTermMemory.remove(toRemove)
                } else {
                    contextData.shortTermMemory.removeAt(0)
                }
            }
            
            // 更新用户画像
            userProfile.totalInteractions++
            userProfile.lastInteractionTime = System.currentTimeMillis()
            
            // 🆕 智能提取重要信息到长期记忆
            extractAndSaveLongTermMemory(appContext, userMsg, aiResp)
            
            saveAllMemory(appContext)
        }
    }
    
    // ==================== 长期记忆操作 ====================
    
    /**
     * 🆕 添加长期记忆（永久保存，支持实时更新）
     */
    fun addLongTermMemory(
        appContext: Context,
        key: String,
        value: String,
        category: MemoryCategory = MemoryCategory.GENERAL,
        source: String = ""
    ) {
        synchronized(memoryLock) {
            // 🔄 智能匹配：不仅匹配完全相同的key，还匹配语义相似的key
            val existing = findSimilarMemory(key)
            
            if (existing != null) {
                // 🆕 记录更新历史
                val oldValue = existing.value
                
                // 更新现有记忆
                val updated = existing.copy(
                    key = key,  // 使用新的key（可能表达方式不同）
                    value = value,
                    updatedAt = System.currentTimeMillis(),
                    accessCount = existing.accessCount + 1
                )
                longTermData.memories.remove(existing)
                longTermData.memories.add(updated)
                LogManager.d(TAG, "📝 更新长期记忆: $key: $oldValue → $value")
            } else {
                // 添加新记忆
                val newMemory = LongTermMemory(
                    createdAt = System.currentTimeMillis(),
                    category = category,
                    key = key,
                    value = value,
                    source = source
                )
                longTermData.memories.add(newMemory)
                LogManager.d(TAG, "💾 新增长期记忆: $key = $value")
            }
            
            // 保持长期记忆在限制内
            while (longTermData.memories.size > MAX_LONG_TERM_SIZE) {
                val toRemove = longTermData.memories
                    .sortedWith(compareBy({ it.accessCount }, { it.createdAt }))
                    .firstOrNull()
                if (toRemove != null) {
                    longTermData.memories.remove(toRemove)
                }
            }
            
            saveAllMemory(appContext)
        }
    }
    
    /**
     * 🆕 智能查找语义相似的记忆
     */
    private fun findSimilarMemory(key: String): LongTermMemory? {
        val normalizedKey = key.lowercase().trim()
        
        // 1. 精确匹配
        val exactMatch = longTermData.memories.find { 
            it.key.equals(key, ignoreCase = true) 
        }
        if (exactMatch != null) return exactMatch
        
        // 2. 语义相似匹配 - 同类信息应该更新而不是新增
        val similarityPatterns = mapOf(
            // 用户称呼相关
            listOf("用户昵称", "用户名字", "主人叫", "我叫", "名字") to "用户昵称",
            // AI称呼相关  
            listOf("ai名字", "助手名字", "你叫", "叫你", "你的名字") to "AI名字",
            // 生日相关
            listOf("生日", "birthday") to "生日",
            // 地址相关
            listOf("地址", "住址", "家在", "住在") to "地址",
            // 工作相关
            listOf("工作", "职业", "公司", "上班") to "工作"
        )
        
        for ((keywords, _) in similarityPatterns) {
            if (keywords.any { normalizedKey.contains(it) }) {
                // 查找同类记忆
                val similar = longTermData.memories.find { memory ->
                    keywords.any { memory.key.lowercase().contains(it) }
                }
                if (similar != null) return similar
            }
        }
        
        return null
    }
    
    /**
     * 🆕 查询长期记忆
     */
    fun queryLongTermMemory(query: String): List<LongTermMemory> {
        synchronized(memoryLock) {
            val normalizedQuery = query.lowercase()
            return longTermData.memories.filter { memory ->
                memory.key.lowercase().contains(normalizedQuery) ||
                memory.value.lowercase().contains(normalizedQuery)
            }.sortedByDescending { it.accessCount }
        }
    }
    
    /**
     * 🆕 获取长期记忆
     */
    fun getLongTermMemory(key: String): String? {
        synchronized(memoryLock) {
            val memory = longTermData.memories.find { it.key.equals(key, ignoreCase = true) }
            if (memory != null) {
                // 增加访问计数
                val updated = memory.copy(accessCount = memory.accessCount + 1)
                longTermData.memories.remove(memory)
                longTermData.memories.add(updated)
            }
            return memory?.value
        }
    }
    
    /**
     * 🆕 删除长期记忆
     */
    fun removeLongTermMemory(appContext: Context, key: String): Boolean {
        synchronized(memoryLock) {
            val memory = longTermData.memories.find { it.key.equals(key, ignoreCase = true) }
            return if (memory != null) {
                longTermData.memories.remove(memory)
                saveAllMemory(appContext)
                LogManager.d(TAG, "🗑️ 删除长期记忆: $key")
                true
            } else {
                false
            }
        }
    }
    
    // ==================== 用户画像操作 ====================
    
    /**
     * 🆕 记住用户昵称（实时更新）
     */
    fun setUserNickname(appContext: Context, nickname: String) {
        val oldNickname = userProfile.nickname
        userProfile.nickname = nickname
        addLongTermMemory(appContext, "用户昵称", nickname, MemoryCategory.PERSONAL)
        saveAllMemory(appContext)
        if (oldNickname.isNotBlank() && oldNickname != nickname) {
            LogManager.d(TAG, "🔄 用户昵称更新: $oldNickname → $nickname")
        }
    }
    
    fun getUserNickname(): String = userProfile.nickname
    
    /**
     * 🆕 记住AI的名字（用户给AI起的名字，实时更新）
     */
    fun setAIName(appContext: Context, name: String) {
        val oldName = userProfile.preferredName
        userProfile.preferredName = name
        addLongTermMemory(appContext, "AI名字", name, MemoryCategory.PERSONAL)
        saveAllMemory(appContext)
        if (oldName.isNotBlank() && oldName != name) {
            LogManager.d(TAG, "🔄 AI名字更新: $oldName → $name")
        }
    }
    
    fun getAIName(): String = userProfile.preferredName.ifBlank { "羲和" }
    
    /**
     * 🆕 记住重要人物
     */
    fun rememberPerson(appContext: Context, name: String, relationship: String, contactMethod: String = "", notes: String = "") {
        userProfile.importantPeople[name] = PersonInfo(name, relationship, contactMethod, notes)
        addLongTermMemory(appContext, "认识的人:$name", "$relationship, $contactMethod", MemoryCategory.RELATIONSHIP)
        saveAllMemory(appContext)
    }
    
    fun getPersonInfo(name: String): PersonInfo? = userProfile.importantPeople[name]
    
    /**
     * 🆕 记住用户偏好
     */
    fun setPreference(appContext: Context, key: String, value: String) {
        contextData.userPreferences[key] = value
        userProfile.appPreferences[key] = value
        addLongTermMemory(appContext, "偏好:$key", value, MemoryCategory.PREFERENCE)
        saveAllMemory(appContext)
    }
    
    fun getPreference(key: String): String? = contextData.userPreferences[key] ?: userProfile.appPreferences[key]
    
    /**
     * 🆕 记住关键事实
     */
    fun setKeyFact(appContext: Context, key: String, value: String) {
        contextData.keyFacts[key] = value
        addLongTermMemory(appContext, key, value, MemoryCategory.PERSONAL)
        saveAllMemory(appContext)
    }
    
    fun getKeyFact(key: String): String? = contextData.keyFacts[key] ?: getLongTermMemory(key)
    
    /**
     * 🆕 添加用户兴趣
     */
    fun addInterest(appContext: Context, interest: String) {
        if (!userProfile.interests.contains(interest)) {
            userProfile.interests.add(interest)
            saveAllMemory(appContext)
        }
    }
    
    /**
     * 🆕 记录常用任务
     */
    fun recordFrequentTask(appContext: Context, task: String) {
        if (!userProfile.frequentTasks.contains(task)) {
            userProfile.frequentTasks.add(task)
            if (userProfile.frequentTasks.size > 20) {
                userProfile.frequentTasks.removeAt(0)
            }
            saveAllMemory(appContext)
        }
    }
    
    // ==================== 智能提取 ====================
    
    /**
     * 🆕 智能提取并保存长期记忆
     */
    private fun extractAndSaveLongTermMemory(appContext: Context, userMsg: String, aiResp: String) {
        // 提取人物关系
        extractPersonRelationship(appContext, userMsg)
        
        // 提取日期相关信息
        extractDateInfo(appContext, userMsg)
        
        // 提取偏好信息
        extractPreferences(appContext, userMsg)
        
        // 提取"记住"指令
        extractRememberCommand(appContext, userMsg)
    }
    
    /**
     * 提取人物关系
     */
    private fun extractPersonRelationship(appContext: Context, msg: String) {
        val patterns = listOf(
            Regex("(我)?(妈妈?|母亲|老妈)叫?(.{2,4})"),
            Regex("(我)?(爸爸?|父亲|老爸)叫?(.{2,4})"),
            Regex("(我)?(老婆|妻子|媳妇)叫?(.{2,4})"),
            Regex("(我)?(老公|丈夫)叫?(.{2,4})"),
            Regex("(我)?(女朋友|男朋友|对象)叫?(.{2,4})"),
            Regex("(.{2,4})是我的?(朋友|同事|同学|闺蜜|哥们|兄弟)"),
            Regex("(我)?(姐姐?|妹妹?|哥哥?|弟弟?)叫?(.{2,4})")
        )
        
        for (pattern in patterns) {
            val match = pattern.find(msg)
            if (match != null) {
                val groups = match.groupValues
                val relationship = when {
                    msg.contains("妈") || msg.contains("母亲") -> "妈妈"
                    msg.contains("爸") || msg.contains("父亲") -> "爸爸"
                    msg.contains("老婆") || msg.contains("妻子") -> "老婆"
                    msg.contains("老公") || msg.contains("丈夫") -> "老公"
                    msg.contains("女朋友") -> "女朋友"
                    msg.contains("男朋友") -> "男朋友"
                    msg.contains("姐") -> "姐姐"
                    msg.contains("妹") -> "妹妹"
                    msg.contains("哥") -> "哥哥"
                    msg.contains("弟") -> "弟弟"
                    msg.contains("朋友") -> "朋友"
                    msg.contains("同事") -> "同事"
                    msg.contains("同学") -> "同学"
                    else -> "认识的人"
                }
                
                val name = groups.lastOrNull { it.length in 2..4 && !it.contains("我") } ?: continue
                rememberPerson(appContext, name, relationship)
                LogManager.d(TAG, "🔍 提取到人物关系: $name 是 $relationship")
            }
        }
    }
    
    /**
     * 提取日期信息
     */
    private fun extractDateInfo(appContext: Context, msg: String) {
        val patterns = listOf(
            Regex("(我|我的)?(.{2,6})(的)?(生日|birthday)是?(.{2,10}日?)"),
            Regex("(.{2,10}日?)是(我|我的)?(.{2,6})(的)?(生日|birthday)"),
            Regex("(我|我们)?(的)?(结婚)?纪念日是?(.{2,10}日?)"),
            Regex("(.{2,6})(每年|每月|每周)?(.{2,10})要?(.{2,10})")
        )
        
        // 生日提取
        val birthdayPattern = Regex("(.{2,4})(的)?生日是?([0-9一二三四五六七八九十]+月[0-9一二三四五六七八九十]+[日号]?)")
        val birthdayMatch = birthdayPattern.find(msg)
        if (birthdayMatch != null) {
            val person = birthdayMatch.groupValues[1]
            val date = birthdayMatch.groupValues[3]
            addLongTermMemory(appContext, "${person}的生日", date, MemoryCategory.PERSONAL, msg)
            LogManager.d(TAG, "🔍 提取到生日: ${person}的生日是$date")
        }
    }
    
    /**
     * 提取偏好信息
     */
    private fun extractPreferences(appContext: Context, msg: String) {
        val likePatterns = listOf(
            Regex("我(喜欢|爱|偏好|习惯)(.{2,20})"),
            Regex("我(不喜欢|讨厌|不爱|不习惯)(.{2,20})")
        )
        
        for (pattern in likePatterns) {
            val match = pattern.find(msg)
            if (match != null) {
                val verb = match.groupValues[1]
                val thing = match.groupValues[2].trim()
                
                if (verb.contains("不") || verb.contains("讨厌")) {
                    if (!userProfile.dislikes.contains(thing)) {
                        userProfile.dislikes.add(thing)
                        addLongTermMemory(appContext, "不喜欢", thing, MemoryCategory.PREFERENCE, msg)
                        LogManager.d(TAG, "🔍 提取到不喜欢: $thing")
                    }
                } else {
                    if (!userProfile.interests.contains(thing)) {
                        userProfile.interests.add(thing)
                        addLongTermMemory(appContext, "喜欢", thing, MemoryCategory.PREFERENCE, msg)
                        LogManager.d(TAG, "🔍 提取到喜欢: $thing")
                    }
                }
            }
        }
    }
    
    /**
     * 🆕 提取"记住"指令和命名指令（支持实时更新）
     */
    private fun extractRememberCommand(appContext: Context, msg: String) {
        // 1. "你叫xxx" / "叫你xxx" / "以后叫你xxx" - 给AI起名字（实时更新）
        val aiNamePatterns = listOf(
            Regex("(你|以后)?叫你(.{1,10})"),
            Regex("你(的)?名字(叫|是)(.{1,10})"),
            Regex("(以后|从现在开始)?(你)?叫(.{1,10})"),
            Regex("(给你|帮你)?(起|取)(个|一个)?名字?[叫是]?(.{1,10})"),
            Regex("(以后|现在开始)?你就叫(.{1,10})")
        )
        
        for (pattern in aiNamePatterns) {
            val match = pattern.find(msg)
            if (match != null) {
                // 取最后一个捕获组（名字）
                val name = match.groupValues.lastOrNull { it.length in 1..10 && !it.contains("你") && !it.contains("以后") }?.trim()
                if (!name.isNullOrBlank() && name.length <= 10) {
                    setAIName(appContext, name)
                    LogManager.d(TAG, "🔍 提取到AI名字: $name (实时更新)")
                    return  // 找到就返回，避免重复处理
                }
            }
        }
        
        // 2. "我叫xxx" - 用户自我介绍（实时更新）
        val userNamePatterns = listOf(
            Regex("我(的)?名字?(叫|是)(.{2,10})"),
            Regex("我叫(.{2,10})"),
            Regex("(大家|你)?叫我(.{2,10})")
        )
        
        for (pattern in userNamePatterns) {
            val match = pattern.find(msg)
            if (match != null) {
                val name = match.groupValues.lastOrNull { it.length in 2..10 && !it.contains("我") && !it.contains("叫") }?.trim()
                if (!name.isNullOrBlank() && name.length <= 10) {
                    setUserNickname(appContext, name)
                    LogManager.d(TAG, "🔍 提取到用户名字: $name (实时更新)")
                    return
                }
            }
        }
        
        // 3. "记住xxx" - 通用记忆指令
        val rememberPattern = Regex("(记住|记一下|帮我记|你要记得|别忘了)[：:]?\\s*(.+)")
        val rememberMatch = rememberPattern.find(msg)
        if (rememberMatch != null) {
            val content = rememberMatch.groupValues[2].trim()
            if (content.isNotBlank() && content.length >= 2) {
                // 智能解析记住的内容
                parseAndSaveRememberContent(appContext, content, msg)
            }
        }
        
        // 4. "xxx是xxx" - 定义式记忆
        val definitionPattern = Regex("(.{2,15})(是|就是|等于)(.{2,30})")
        val defMatch = definitionPattern.find(msg)
        if (defMatch != null && (msg.contains("记住") || msg.contains("记一下"))) {
            val key = defMatch.groupValues[1].trim()
            val value = defMatch.groupValues[3].trim()
            if (key.isNotBlank() && value.isNotBlank()) {
                addLongTermMemory(appContext, key, value, MemoryCategory.GENERAL, msg)
                LogManager.d(TAG, "🔍 提取到定义: $key = $value")
            }
        }
    }
    
    /**
     * 🆕 智能解析并保存"记住"的内容
     */
    private fun parseAndSaveRememberContent(appContext: Context, content: String, source: String) {
        // 尝试解析 "xxx是xxx" 格式
        val isPattern = Regex("(.+?)(是|叫|等于)(.+)")
        val isMatch = isPattern.find(content)
        
        if (isMatch != null) {
            val key = isMatch.groupValues[1].trim()
            val value = isMatch.groupValues[3].trim()
            addLongTermMemory(appContext, key, value, MemoryCategory.GENERAL, source)
            LogManager.d(TAG, "🔍 解析记住内容: $key = $value")
        } else {
            // 无法解析，直接存储
            addLongTermMemory(appContext, "用户要求记住", content, MemoryCategory.GENERAL, source)
            LogManager.d(TAG, "🔍 用户要求记住: $content")
        }
    }
    
    // ==================== 辅助方法 ====================
    
    /**
     * 计算记忆重要性
     */
    private fun calculateImportance(userMsg: String, aiResp: String): Int {
        var importance = 1
        
        // 包含个人信息
        if (userMsg.contains("我") && (userMsg.contains("喜欢") || userMsg.contains("是") || userMsg.contains("叫"))) {
            importance += 2
        }
        
        // 包含任务执行
        if (userMsg.contains("发消息") || userMsg.contains("打开") || userMsg.contains("搜索")) {
            importance += 1
        }
        
        // 包含记住指令
        if (userMsg.contains("记住") || userMsg.contains("记一下")) {
            importance += 3
        }
        
        // 包含日期信息
        if (userMsg.contains("生日") || userMsg.contains("纪念日") || userMsg.contains("日期")) {
            importance += 2
        }
        
        return importance.coerceIn(1, 5)
    }
    
    /**
     * 分类记忆
     */
    private fun categorizeMemory(msg: String): MemoryCategory {
        return when {
            msg.contains("发消息") || msg.contains("打开") || msg.contains("关闭") -> MemoryCategory.TASK
            msg.contains("我是") || msg.contains("我叫") || msg.contains("我的") -> MemoryCategory.PERSONAL
            msg.contains("喜欢") || msg.contains("偏好") || msg.contains("习惯") -> MemoryCategory.PREFERENCE
            msg.contains("朋友") || msg.contains("家人") || msg.contains("同事") -> MemoryCategory.RELATIONSHIP
            msg.contains("提醒") || msg.contains("日程") || msg.contains("计划") -> MemoryCategory.SCHEDULE
            else -> MemoryCategory.GENERAL
        }
    }
    
    // ==================== 上下文生成 ====================
    
    /**
     * 生成上下文摘要，供 LLM 使用（包含实时更新的记忆）
     */
    fun generateContextSummary(): String {
        val sb = StringBuilder()
        
        // 0. AI身份信息（最重要！）
        val aiName = getAIName()
        sb.append("【我的身份】\n")
        sb.append("- 我的名字: $aiName\n")
        if (userProfile.nickname.isNotBlank()) {
            sb.append("- 主人的名字: ${userProfile.nickname}\n")
        }
        sb.append("\n")
        
        // 1. 用户画像
        if (userProfile.nickname.isNotBlank() || userProfile.interests.isNotEmpty()) {
            sb.append("【主人信息】\n")
            if (userProfile.nickname.isNotBlank()) {
                sb.append("- 称呼: ${userProfile.nickname}\n")
            }
            if (userProfile.interests.isNotEmpty()) {
                sb.append("- 兴趣: ${userProfile.interests.take(5).joinToString(", ")}\n")
            }
            if (userProfile.dislikes.isNotEmpty()) {
                sb.append("- 不喜欢: ${userProfile.dislikes.take(3).joinToString(", ")}\n")
            }
            sb.append("\n")
        }
        
        // 2. 重要人物
        if (userProfile.importantPeople.isNotEmpty()) {
            sb.append("【主人的重要人物】\n")
            userProfile.importantPeople.entries.take(10).forEach { (name, info) ->
                sb.append("- $name (${info.relationship})\n")
            }
            sb.append("\n")
        }
        
        // 3. 长期记忆中的重要事实
        val importantFacts = longTermData.memories
            .filter { it.category == MemoryCategory.PERSONAL || it.accessCount > 2 }
            .sortedByDescending { it.accessCount }
            .take(10)
        
        if (importantFacts.isNotEmpty()) {
            sb.append("【我永久记住的事情】\n")
            importantFacts.forEach { 
                sb.append("- ${it.key}: ${it.value}\n")
            }
            sb.append("\n")
        }
        
        // 4. 最近对话
        if (contextData.shortTermMemory.isNotEmpty()) {
            sb.append("【最近对话】\n")
            contextData.shortTermMemory.takeLast(5).forEach { 
                sb.append("主人: ${it.userMessage}\n")
                sb.append("羲和: ${it.aiResponse}\n\n")
            }
        }
        
        // 5. 用户偏好
        val prefs = contextData.userPreferences + userProfile.appPreferences
        if (prefs.isNotEmpty()) {
            sb.append("【主人的偏好】\n")
            prefs.entries.take(10).forEach { (k, v) -> 
                sb.append("- $k: $v\n")
            }
        }
        
        return sb.toString()
    }
    
    /**
     * 🆕 生成精简的记忆摘要（用于系统提示词）
     */
    fun generateCompactSummary(): String {
        val parts = mutableListOf<String>()
        
        // AI名字（最重要！）
        val aiName = getAIName()
        if (aiName != "羲和") {  // 如果不是默认名字
            parts.add("我的名字是$aiName")
        }
        
        // 用户称呼
        if (userProfile.nickname.isNotBlank()) {
            parts.add("主人叫${userProfile.nickname}")
        }
        
        // 重要人物
        userProfile.importantPeople.entries.take(5).forEach { (name, info) ->
            parts.add("${name}是主人的${info.relationship}")
        }
        
        // 重要事实（排除已经包含的AI名字和用户昵称）
        longTermData.memories
            .filter { it.accessCount > 1 && !it.key.contains("AI名字") && !it.key.contains("用户昵称") }
            .sortedByDescending { it.accessCount }
            .take(5)
            .forEach { parts.add("${it.key}是${it.value}") }
        
        return if (parts.isNotEmpty()) {
            "【记忆摘要】" + parts.joinToString("；")
        } else {
            ""
        }
    }
    
    /**
     * 获取完整对话历史
     */
    fun getConversationHistory(): List<Pair<String, String>> {
        return contextData.shortTermMemory.takeLast(10).map { 
            Pair(it.userMessage, it.aiResponse)
        }
    }
    
    /**
     * 获取最近的对话数量
     */
    fun getHistoryCount(): Int = contextData.shortTermMemory.size
    
    /**
     * 🆕 获取所有长期记忆（用于UI显示）
     */
    fun getAllLongTermMemories(): List<LongTermMemory> = longTermData.memories.toList()
    
    /**
     * 🆕 获取用户画像
     */
    fun getUserProfile(): UserProfile = userProfile
    
    /**
     * 🆕 清除所有记忆（谨慎使用）
     */
    fun clearAllMemory(appContext: Context) {
        contextData = ContextData()
        longTermData = LongTermData()
        userProfile = UserProfile()
        saveAllMemory(appContext)
        LogManager.w(TAG, "⚠️ 已清除所有记忆")
    }
    
    /**
     * 🆕 获取记忆统计
     */
    fun getMemoryStats(): Map<String, Any> {
        return mapOf(
            "shortTermCount" to contextData.shortTermMemory.size,
            "longTermCount" to longTermData.memories.size,
            "importantPeopleCount" to userProfile.importantPeople.size,
            "interestsCount" to userProfile.interests.size,
            "totalInteractions" to userProfile.totalInteractions
        )
    }
    
    // ==================== 持久化 ====================
    
    private fun saveAllMemory(appContext: Context) {
        try {
            // 保存短期记忆
            val contextFile = File(appContext.filesDir, MEMORY_FILE_NAME)
            contextFile.writeText(json.encodeToString(contextData))
            
            // 保存长期记忆
            val longTermFile = File(appContext.filesDir, LONG_TERM_FILE_NAME)
            longTermFile.writeText(json.encodeToString(longTermData))
            
            // 保存用户画像
            val profileFile = File(appContext.filesDir, USER_PROFILE_FILE_NAME)
            profileFile.writeText(json.encodeToString(userProfile))
            
            LogManager.d(TAG, "💾 记忆保存成功")
        } catch (e: Exception) {
            LogManager.e(TAG, "保存记忆失败", e)
        }
    }
    
    private fun loadAllMemory(appContext: Context) {
        try {
            // 加载短期记忆
            val contextFile = File(appContext.filesDir, MEMORY_FILE_NAME)
            if (contextFile.exists()) {
                contextData = json.decodeFromString<ContextData>(contextFile.readText())
            }
            
            // 加载长期记忆
            val longTermFile = File(appContext.filesDir, LONG_TERM_FILE_NAME)
            if (longTermFile.exists()) {
                longTermData = json.decodeFromString<LongTermData>(longTermFile.readText())
            }
            
            // 加载用户画像
            val profileFile = File(appContext.filesDir, USER_PROFILE_FILE_NAME)
            if (profileFile.exists()) {
                userProfile = json.decodeFromString<UserProfile>(profileFile.readText())
            }
            
            LogManager.d(TAG, "📖 记忆加载成功")
        } catch (e: Exception) {
            LogManager.e(TAG, "加载记忆失败", e)
        }
    }
}
