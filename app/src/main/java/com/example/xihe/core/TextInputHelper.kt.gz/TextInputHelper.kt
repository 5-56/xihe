package com.example.xihe.core

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import com.example.xihe.utils.LogManager
import android.view.accessibility.AccessibilityNodeInfo
import com.example.xihe.CoreAccessibilityService
import kotlinx.coroutines.delay

/**
 * 文本输入助手 - 提供更可靠的文本输入方法
 * 
 * 实现多种输入策略：
 * 1. ACTION_SET_TEXT（最快，但不是所有应用都支持）
 * 2. 剪贴板粘贴（通用方案）
 * 3. 输入法模拟（最后备选）
 */
object TextInputHelper {
    private const val TAG = "TextInputHelper"
    
    /**
     * 输入策略
     */
    enum class InputStrategy {
        SET_TEXT,           // 使用 ACTION_SET_TEXT
        CLIPBOARD_PASTE,    // 使用剪贴板粘贴
        KEYBOARD_TYPE,      // 模拟键盘输入（未实现）
        AUTO                // 自动选择最佳策略
    }
    
    /**
     * 智能输入文本
     * @param service 无障碍服务实例
     * @param node 目标输入框节点
     * @param text 要输入的文本
     * @param strategy 输入策略
     * @return 是否成功
     */
    suspend fun inputText(
        service: CoreAccessibilityService,
        context: Context,
        node: AccessibilityNodeInfo,
        text: String,
        strategy: InputStrategy = InputStrategy.AUTO
    ): Boolean {
        LogManager.i(TAG, "Inputting text: $text with strategy: $strategy")
        
        // 首先确保输入框获得焦点
        if (!node.isFocused) {
            node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            delay(300) // 等待焦点生效
        }
        
        return when (strategy) {
            InputStrategy.SET_TEXT -> trySetText(node, text)
            InputStrategy.CLIPBOARD_PASTE -> tryClipboardPaste(service, context, node, text)
            InputStrategy.KEYBOARD_TYPE -> tryKeyboardType(service, node, text)
            InputStrategy.AUTO -> tryAutoInput(service, context, node, text)
        }
    }
    
    /**
     * 尝试使用 ACTION_SET_TEXT
     */
    private suspend fun trySetText(node: AccessibilityNodeInfo, text: String): Boolean {
        return try {
            // 先清空现有文本
            val arguments = Bundle()
            arguments.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
            node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
            delay(100)
            
            // 设置新文本
            val setArguments = Bundle()
            setArguments.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            val success = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, setArguments)
            
            if (success) {
                LogManager.i(TAG, "SET_TEXT succeeded")
                delay(200) // 等待文本生效
            } else {
                LogManager.i(TAG, "SET_TEXT returned false")
            }
            
            success
        } catch (e: Exception) {
            LogManager.i(TAG, "SET_TEXT failed: ${e.message}")
            false
        }
    }
    
    /**
     * 尝试使用剪贴板粘贴
     */
    private suspend fun tryClipboardPaste(
        service: CoreAccessibilityService,
        context: Context,
        node: AccessibilityNodeInfo,
        text: String
    ): Boolean {
        return try {
            // 1. 复制到剪贴板
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("羲和输入", text)
            clipboard.setPrimaryClip(clip)
            delay(100)
            
            // 2. 先清空输入框（全选+删除）
            node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            delay(100)
            
            // 尝试全选
            val selectAllArgs = Bundle()
            selectAllArgs.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0)
            selectAllArgs.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, node.text?.length ?: 0)
            node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, selectAllArgs)
            delay(100)
            
            // 3. 执行粘贴
            val pasted = node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
            
            if (pasted) {
                LogManager.i(TAG, "CLIPBOARD_PASTE succeeded")
                delay(300) // 等待粘贴完成
                return true
            } else {
                LogManager.i(TAG, "ACTION_PASTE returned false, trying alternative")
                
                // 备选方案：尝试点击输入框，然后发送粘贴手势
                val rect = android.graphics.Rect()
                node.getBoundsInScreen(rect)
                service.performClick(rect.exactCenterX(), rect.exactCenterY())
                delay(300)
                
                // 尝试长按唤出粘贴菜单
                service.performLongPress(rect.exactCenterX(), rect.exactCenterY())
                delay(500)
                
                // 这里可以尝试查找"粘贴"按钮并点击
                // 但这需要更复杂的屏幕分析
                
                false
            }
        } catch (e: Exception) {
            LogManager.i(TAG, "CLIPBOARD_PASTE failed: ${e.message}", e)
            false
        }
    }
    
    /**
     * 尝试模拟键盘输入
     * 使用sendKeys方法逐字符输入（适用于简单场景）
     */
    private suspend fun tryKeyboardType(
        service: CoreAccessibilityService,
        node: AccessibilityNodeInfo,
        text: String
    ): Boolean {
        return try {
            LogManager.i(TAG, "Attempting KEYBOARD_TYPE input")
            
            // 1. 确保输入框获得焦点
            if (!node.isFocused) {
                node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                delay(300)
            }
            
            // 2. 使用ACTION_SEND_EVENT逐字符输入
            // 注意：这个方法不是最可靠的，但可以作为后备方案
            var success = true
            for (char in text) {
                val charBundle = Bundle()
                charBundle.putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                    char.toString()
                )
                
                // 尝试追加字符到现有文本
                val currentText = node.text?.toString() ?: ""
                val newText = currentText + char
                
                val appendBundle = Bundle()
                appendBundle.putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                    newText
                )
                
                if (!node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, appendBundle)) {
                    LogManager.i(TAG, "Failed to input character: $char")
                    success = false
                    break
                }
                
                // 短暂延迟以模拟真实输入速度
                delay(50)
            }
            
            if (success) {
                LogManager.i(TAG, "KEYBOARD_TYPE succeeded")
                delay(200) // 等待输入完成
            } else {
                LogManager.i(TAG, "KEYBOARD_TYPE partially failed")
            }
            
            success
        } catch (e: Exception) {
            LogManager.i(TAG, "KEYBOARD_TYPE failed: ${e.message}", e)
            false
        }
    }
    
    /**
     * 自动选择最佳输入策略
     */
    private suspend fun tryAutoInput(
        service: CoreAccessibilityService,
        context: Context,
        node: AccessibilityNodeInfo,
        text: String
    ): Boolean {
        // 策略1: 先尝试 SET_TEXT（最快）
        if (trySetText(node, text)) {
            // 验证是否真的设置成功
            delay(200)
            if (node.refresh()) {
                val currentText = node.text?.toString() ?: ""
                if (currentText == text || currentText.contains(text)) {
                    return true
                }
            }
        }
        
        LogManager.i(TAG, "SET_TEXT failed or incomplete, trying CLIPBOARD_PASTE")
        
        // 策略2: 使用剪贴板粘贴
        if (tryClipboardPaste(service, context, node, text)) {
            return true
        }
        
        LogManager.i(TAG, "All input strategies failed")
        return false
    }
    
    /**
     * 清空输入框
     */
    suspend fun clearText(node: AccessibilityNodeInfo): Boolean {
        return try {
            val arguments = Bundle()
            arguments.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
            val success = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
            delay(100)
            success
        } catch (e: Exception) {
            LogManager.i(TAG, "Failed to clear text: ${e.message}")
            false
        }
    }
    
    /**
     * 追加文本（不清空原有内容）
     */
    suspend fun appendText(node: AccessibilityNodeInfo, text: String): Boolean {
        return try {
            val currentText = node.text?.toString() ?: ""
            val newText = currentText + text
            
            val arguments = Bundle()
            arguments.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, newText)
            val success = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
            delay(100)
            success
        } catch (e: Exception) {
            LogManager.i(TAG, "Failed to append text: ${e.message}")
            false
        }
    }
    
    /**
     * 替换选中文本
     */
    suspend fun replaceSelectedText(node: AccessibilityNodeInfo, text: String): Boolean {
        return try {
            // 直接粘贴会替换选中的文本
            node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
            delay(100)
            true
        } catch (e: Exception) {
            LogManager.i(TAG, "Failed to replace selected text: ${e.message}")
            false
        }
    }
}
