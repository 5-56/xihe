package com.example.xihe.core

import android.content.Context
import android.content.Intent
import com.example.xihe.utils.LogManager
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.OverlayService
import com.example.xihe.core.MacroManager
import com.example.xihe.tools.ToolRegistry
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.json.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.coroutines.CompletableDeferred
import com.example.xihe.scenarios.*
import com.example.xihe.ai.IntentClassifier
import com.example.xihe.ai.TaskPlanner
import com.example.xihe.security.SecurityManager
import com.example.xihe.core.model.*
import com.example.xihe.core.model.ChatMessageDisplay
import com.example.xihe.core.analysis.*
import com.example.xihe.core.ModuleCoordinator
import com.example.xihe.understanding.*  // 🧠 深度理解系统
import com.example.xihe.data.*  // 📚 对话数据管理
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import com.example.xihe.utils.NavigationHelper
import com.example.xihe.utils.NavigationResult
import com.example.xihe.utils.ReminderHelper
import com.example.xihe.utils.ReminderResult
import com.example.xihe.service.BasicQueryHandler
import com.example.xihe.ai.SmartModeSwitch
import com.example.xihe.ai.IntentFeedbackSystem
import com.example.xihe.chat.ProactiveChatManager
import com.example.xihe.automation.PhoneAgent
import com.example.xihe.data.TaskExecutionLogger
import com.example.xihe.core.ModuleIntegration
import com.example.xihe.automation.flow.IntelligentTaskAgent
import com.example.xihe.automation.script.SmartScriptManager

object AutomationEngine {
    private const val TAG = "AutomationEngine"

    // 使用 SupervisorJob 确保子协程失败不会影响其他协程
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var job: Job? = null

    // 🔒 线程安全锁
    private val engineLock = Any()
    
    // 标记是否已初始化
    @Volatile
    private var isInitialized = false

    // 🚀 状态管理已迁移至 EngineStateManager
    val status = EngineStateManager.status
    val messages = EngineStateManager.messages
    val taskProgress = EngineStateManager.taskProgress
    val isWaitingForConfirmation = EngineStateManager.isWaitingForConfirmation
    val isPaused = EngineStateManager.isPaused
    val currentConversationId = EngineStateManager.currentConversationId
    
    // 🔧 内部状态引用（用于简化代码迁移）
    private val _status get() = EngineStateManager._status
    private val _messages get() = EngineStateManager._messages
    private val _taskProgress get() = EngineStateManager._taskProgress
    private val _isPaused get() = EngineStateManager._isPaused
    private val _isWaitingForConfirmation get() = EngineStateManager._isWaitingForConfirmation

    private val _currentScreenState = MutableStateFlow<String?>(null)
    val currentScreenState = _currentScreenState.asStateFlow()

    private var confirmationSignal: kotlinx.coroutines.CompletableDeferred<Boolean>? = null

    // 🎓 自主学习 (Macro) 状态
    private val _isRecording = MutableStateFlow(false)
    val isRecording = _isRecording.asStateFlow()
    // 🔒 使用线程安全的集合
    private val recordedActions = java.util.Collections.synchronizedList(mutableListOf<AICommand>())
    @Volatile
    private var recordingTaskName: String? = null
    
    // ==================== 🧠 思考内容解析 ====================
    
    /**
     * 🧠 解析 LLM 响应中的思考内容
     * 代理到 ThinkingParser
     */
    fun parseThinkingContent(response: String): Pair<String?, String> {
        return com.example.xihe.utils.ThinkingParser.parse(response)
    }
    
    /**
     * 🔊 获取用于 TTS 播报的内容（移除思考过程）
     */
    fun getContentForTTS(response: String): String {
        return com.example.xihe.utils.ThinkingParser.getContentForTTS(response)
    }
    
    // ==================== 任务复杂度评估 ====================
    
    /**
     * 评估任务复杂度
     * 代理到 TaskComplexityEvaluator
     */
    fun evaluateTaskComplexity(goal: String, intent: UserIntent? = null): TaskComplexity {
        return com.example.xihe.core.analysis.TaskComplexityEvaluator.evaluate(goal, intent)
    }
    


    // Conversation Management
    // 🚀 已迁移至 EngineStateManager

    // 🗣️ 主动对话已迁移至 ProactiveChatManager
    var enableProactiveChat: Boolean 
        get() = com.example.xihe.chat.ProactiveChatManager.getInstance(com.example.xihe.XiheApplication.getInstance()?.applicationContext ?: throw IllegalStateException("Context not available")).proactiveEnabled.value
        set(value) {
            com.example.xihe.XiheApplication.getInstance()?.applicationContext?.let {
                com.example.xihe.chat.ProactiveChatManager.getInstance(it).setProactiveEnabled(value)
            }
        }
    
    // 🆕 增强功能模块
    // 🆕 增强功能模块 - 统一使用 EnhancedAutomationEngine
    // private var intentClassifier: IntentClassifier? = null // Removed duplicate
    // private var taskPlanner: TaskPlanner? = null // Removed duplicate
    private var useEnhancedFeatures = true

    // 🧠 深度理解系统
    private var contextEngine: ContextAwareIntentEngine? = null

    // 📚 对话数据管理
    private var dataManager: ConversationDataManager? = null

    // 🆕 智能确认机制
    private var pendingConfirmationIntent: com.example.xihe.ai.LocalIntentRecognizer.IntentResult? = null
    private val confirmKeywords = listOf("对", "是", "好", "确认", "没错", "对的", "yes", "ok", "行")
    private val cancelKeywords = listOf("不对", "不是", "错了", "取消", "算了", "不要", "no", "cancel")

    fun init(context: Context) {
        // 防止重复初始化
        if (isInitialized) {
            LogManager.d(TAG, "ℹ️ AutomationEngine 已初始化，跳过")
            return
        }

        LogManager.d(TAG, "🚀 开始初始化 AutomationEngine...")

        MacroManager.init(context)
        ContextMemory.init(context)

        // 📖 加载保存的配置和历史记录
        loadSavedData(context)

        // 🚀 初始化模块协调器（检查是否已初始化，避免重复）
        try {
            if (!ModuleCoordinator.isInitialized()) {
                ModuleCoordinator.initialize(
                    context,
                    ModuleCoordinator.ModuleConfig(
                        enableAI = true,
                        enableVoice = true,
                        enableLearning = true,
                        enablePerformance = true,
                        enableCrossApp = true,
                        enableSecurity = true
                    )
                )
                LogManager.d(TAG, "✅ 模块协调器初始化完成")
            } else {
                LogManager.d(TAG, "ℹ️ 模块协调器已初始化，跳过")
            }

            // 如果AI模块可用，设置标志
            if (ModuleCoordinator.isModuleAvailable("AI")) {
                // intentClassifier = IntentClassifier() // Removed
                // taskPlanner = TaskPlanner() // Removed
                useEnhancedFeatures = true
                
                // 确保增强引擎已初始化
                EnhancedAutomationEngine.initialize(context)
            }

            LogManager.d(TAG, "✅ 可用模块: ${ModuleCoordinator.availableModules.value}")
        } catch (e: Exception) {
            LogManager.w(TAG, "模块协调器初始化失败，使用基础功能", e)
            useEnhancedFeatures = false
        }

        // 🎯 初始化意图反馈系统
        IntentFeedbackSystem.init(context)
        LogManager.d(TAG, "✅ 意图反馈系统已初始化")

        // 🗣️ 启动主动对话监控（已迁移至 ProactiveChatManager）
        ProactiveChatManager.getInstance(context).apply {
            setProactiveCallback { message ->
                scope.launch {
                    addMessageWithTypewriter(message, false)
                    if (enableVoiceResponse) {
                        ModuleCoordinator.speak(message)
                    }
                }
            }
            startMonitor()
        }

        // 🧠 初始化深度理解系统
        try {
            contextEngine = ContextAwareIntentEngine.getInstance(context)
            LogManager.d(TAG, "✅ 深度理解系统已初始化")
        } catch (e: Exception) {
            LogManager.w(TAG, "深度理解系统初始化失败", e)
        }

        // 📚 初始化对话数据管理器
        try {
            dataManager = ConversationDataManager.getInstance(context)
            LogManager.d(TAG, "✅ 对话数据管理器已初始化")
        } catch (e: Exception) {
            LogManager.w(TAG, "对话数据管理器初始化失败", e)
        }

        isInitialized = true
        LogManager.i(TAG, "✅ AutomationEngine 初始化完成")
    }

    /**
     * 🧹 清理资源
     * 应在应用退出时调用
     */
    fun cleanup() {
        synchronized(engineLock) {
            LogManager.d(TAG, "🧹 开始清理 AutomationEngine 资源...")

            // 🔴 取消所有协程
            job?.cancel()
            scope.cancel() // 取消整个协程作用域
            
            com.example.xihe.XiheApplication.getInstance()?.applicationContext?.let {
                ProactiveChatManager.getInstance(it).stopMonitor()
            }

            // 重置状态
            _messages.value = emptyList()
            _status.value = "Idle"
            _taskProgress.value = TaskProgress()
            _isPaused.value = false
            _isWaitingForConfirmation.value = null
            _currentScreenState.value = null
            _isRecording.value = false
            _attachedImageUri.value = null

            // 清理引用
            contextEngine = null
            dataManager = null
            pendingConfirmationIntent = null
            confirmationSignal = null
            
            // 清理录制数据
            recordedActions.clear()
            recordingTaskName = null

            isInitialized = false
            LogManager.d(TAG, "✅ AutomationEngine 资源已清理")
        }
    }

    /**
     * 统一本地/规则意图为核心 UserIntent 模型
     */
    private fun classifyUserIntent(goal: String): UserIntent? {
        // 1. 优先使用本地规则意图（高精度快捷指令）
        val localResult = com.example.xihe.ai.LocalIntentRecognizer.recognize(goal)
        val localCore = localResult.toCoreUserIntent(goal)
        if (localCore != null && localResult.confidence >= 0.8f) {
            return localCore
        }

        // 2. 使用增强引擎进行分类 (这里仅作兼容性保留，实际逻辑已移至 EnhancedAutomationEngine)
        // 简单返回 null 让 EnhancedEngine 处理，或者如果需要同步结果则需调用
        return null 
    }




    /**
     * 🗣️ 更新用户互动时间
     * 同时通知 ProactiveChatManager 用户在主动聊天
     */
    fun updateUserInteraction(context: Context? = null) {
        val targetContext = context ?: com.example.xihe.XiheApplication.getInstance()?.applicationContext
        
        // 📱 通知 ProactiveChatManager 用户正在互动
        targetContext?.let {
            try {
                ProactiveChatManager.getInstance(it).recordUserActive()
            } catch (e: Exception) {
                LogManager.w(TAG, "记录用户活跃状态失败: ${e.message}")
            }
        }
    }

    /**
     * 📖 加载保存的数据
     */
    private fun loadSavedData(context: Context) {
        // 加载API配置
        val config = PreferencesManager.getApiConfig(context)
        if (config.baseUrl.isNotEmpty()) {
            providerId = config.providerId
            baseUrl = config.baseUrl
            apiKey = config.apiKey
            modelName = config.modelName
            llmClient.updateConfig(baseUrl, apiKey, modelName, providerId)
            LogManager.d(TAG, "✅ 已加载API配置: provider=$providerId, baseUrl=$baseUrl, model=$modelName")
        }

        // 加载聊天历史（最多保留最近50条）
        val savedHistory = PreferencesManager.getChatHistory(context)
        if (savedHistory.isNotEmpty()) {
            _messages.value = savedHistory.takeLast(50)
            LogManager.d(TAG, "✅ 已加载 ${savedHistory.size} 条聊天历史")
        }
    }

    /**
     * 💾 保存数据到本地
     */
    private fun saveData(context: Context) {
        // 保存API配置
        PreferencesManager.saveApiConfig(context, baseUrl, apiKey, modelName, providerId)
        
        // 聊天历史现在由 PreferencesManager 独立处理或通过 ConversationManager 管理
        // 这里暂时保留对 API 配置的保存
    }

    // User Actions to Confirm/Cancel
    fun confirmAction() {
        confirmationSignal?.complete(true)
        _isWaitingForConfirmation.value = null
    }

    fun cancelAction() {
        confirmationSignal?.complete(false)
        _isWaitingForConfirmation.value = null
    }

    // Macro Recording Control (🏗️ 待重构迁移至 MacroManager/RecordingManager)
    fun startRecording(taskName: String) {
        _isRecording.value = true
        recordingTaskName = taskName
        recordedActions.clear()
        EngineStateManager.addAIResponse("🎓 开始学习【$taskName】啦！请主人演示一遍操作，我会认真记住每一步的！(录制中...)")
    }

    fun stopRecording(context: Context) {
        val taskName = recordingTaskName
        if (_isRecording.value && taskName != null) {
            if (recordingTaskName != null && recordedActions.isNotEmpty()) {
                MacroManager.saveMacro(
                    context,
                    taskName,
                    "User recorded macro",
                    listOf(taskName),
                    recordedActions.toList()
                )
                EngineStateManager.addAIResponse("学会啦！以后只要说【$taskName】，我就能自动帮主人完成哦！(保存了 ${recordedActions.size} 步)")
            } else {
                EngineStateManager.addAIResponse("啼？主人好像什么都没做呢，这次就不保存啦。")
            }
        }
        _isRecording.value = false
        recordingTaskName = null
        recordedActions.clear()
    }

    fun cancelRecording() {
        if (_isRecording.value) {
            EngineStateManager.addAIResponse("已取消学习。")
            _isRecording.value = false
            recordingTaskName = null
            recordedActions.clear()
        }
    }

    /**
     * 📸 捕获视觉焦点区域 (用于多模态分析)
     */
    private suspend fun captureFocusArea(context: Context?): String? {
        if (context == null) return null
        return try {
            // 这里调用 ScreenCaptureService 进行实际截图
            // 目前先返回 null，待后续完善截图权限流
            null 
        } catch (e: Exception) {
            LogManager.e(TAG, "截图失败", e)
            null
        }
    }

    // Configuration
    var providerId: String = "openai"
    var baseUrl: String = "https://api.openai.com/v1/"
    var modelName: String = "gpt-4o"
    var apiKey: String = ""

    fun updateConfig(newProviderId: String, newBaseUrl: String, newApiKey: String, newModelName: String, context: Context? = null) {
        this.providerId = newProviderId
        this.baseUrl = newBaseUrl
        this.apiKey = newApiKey
        this.modelName = newModelName
        llmClient.updateConfig(newBaseUrl, newApiKey, newModelName, newProviderId)

        // 💾 保存API配置到本地
        context?.let {
            PreferencesManager.saveApiConfig(it, newBaseUrl, newApiKey, newModelName, newProviderId)
            LogManager.d(TAG, "💾 已保存API配置到本地")
        }
    }

    suspend fun fetchModels(tempApiKey: String, tempBaseUrl: String, tempProviderId: String = "openai"): List<String> {
        // 通过 API 实时获取模型列表
        val tempClient = LLMClient(tempBaseUrl, tempApiKey, "", tempProviderId)
        return tempClient.fetchAvailableModels()
    }

    private var llmClient = LLMClient()

    // 📸 附件图片状态
    private val _attachedImageUri = MutableStateFlow<String?>(null)
    val attachedImageUri = _attachedImageUri.asStateFlow()

    fun setAttachedImage(uri: String?) {
        _attachedImageUri.value = uri
    }

    /**
     * 🚀 启动自动化任务 (已统一至 EnhancedAutomationEngine)
     */
    fun start(goal: String, context: Context? = null) {
        scope.launch {
            try {
                // Ensure context is available
                val appContext = context ?: com.example.xihe.XiheApplication.getInstance()?.applicationContext ?: throw IllegalStateException("Application context not available")
                
                // Ensure EnhancedEngine is initialized
                EnhancedAutomationEngine.initialize(appContext)

                // Delegate to EnhancedEngine
                LogManager.d(TAG, "➡️ 转发任务至增强引擎: $goal")
                EnhancedAutomationEngine.processUserInput(goal)
                
            } catch (e: Exception) {
                LogManager.e(TAG, "转发任务失败", e)
                EngineStateManager.updateStatus("出错: ${e.message}")
                EngineStateManager.addMessage(ChatMessageDisplay(content = "出错了: ${e.message}", isUser = false))
            }
        }
    }

    /**
     * 执行宏指令 (Delegated to MacroManager)
     */
    private suspend fun executeMacro(macro: MacroManager.Macro, context: Context) {
        MacroManager.executeMacro(context, macro, llmClient)
    }

    private fun countNodes(node: ScreenNode): Int {
        return 1 + node.children.sumOf { countNodes(it) }
    }

    fun stop() {
        job?.cancel()
        _status.value = "Stopped"
        _taskProgress.value = _taskProgress.value.copy(
            isRunning = false,
            currentAction = "已停止"
        )
    }

    // 暂停/恢复任务 ✨
    fun pause() {
        if (_isPaused.value) {
            LogManager.w(TAG, "任务已经处于暂停状态")
            return
        }

        _isPaused.value = true
        _status.value = "已暂停"
        LogManager.i(TAG, "⏸️ 任务已暂停")

        // 添加暂停消息
        val pauseMsg = ChatMessageDisplay(
            content = "⏸️ 任务已暂停，点击恢复按钮继续执行哦~",
            isUser = false
        )
        addMessage(pauseMsg)
    }

    fun resume() {
        if (!_isPaused.value) {
            LogManager.w(TAG, "任务没有暂停，无需恢复")
            return
        }

        _isPaused.value = false
        _status.value = "恢复执行"
        LogManager.i(TAG, "▶️ 任务已恢复")

        // 添加恢复消息
        val resumeMsg = ChatMessageDisplay(
            content = "▶️ 任务已恢复，继续执行中...",
            isUser = false
        )
        addMessage(resumeMsg)
    }

    /**
     * 🛑 停止当前任务（用于中断AI回复）
     */
    fun stopCurrentTask() {
        if (job?.isActive == true) {
            LogManager.i(TAG, "🛑 用户中断AI回复")
            job?.cancel()
            _status.value = "待机"
            val stopMsg = ChatMessageDisplay(
                content = "🛑 已停止回复",
                isUser = false
            )
            addMessage(stopMsg)
        } else {
            LogManager.w(TAG, "没有正在执行的任务")
        }
    }

    internal fun addMessage(message: ChatMessageDisplay, context: Context? = null) {
        EngineStateManager.addMessage(message)

        // 💾 自动保存聊天历史 (🏗️ 待迁移至 DataStore)
        context?.let {
            scope.launch {
                try {
                    saveData(it)
                } catch (e: Exception) {
                    LogManager.e(TAG, "保存数据失败", e)
                }
            }
        }
    }

    // 添加消息 - 代理至 EngineStateManager
    private suspend fun addMessageWithTypewriter(text: String, isUser: Boolean, action: String? = null) {
        EngineStateManager.addMessageWithTypewriter(
            text, isUser, action,
            onSpeak = { cleanText ->
                if (enableVoiceResponse) {
                    ModuleCoordinator.speak(cleanText)
                }
            }
        )
    }

    // 🔊 是否启用语音播报 AI 回复
    var enableVoiceResponse: Boolean = true

    /**
     * 更新状态
     */
    private fun updateStatus(newStatus: String) {
        EngineStateManager.updateStatus(newStatus)
    }

    /**
     * 更新任务进度
     */
    private fun updateProgress(current: Int, total: Int, desc: String) {
        EngineStateManager.updateProgress(TaskProgress(current, total, desc, if (total > 0) current.toFloat() / total else 0f))
    }

    /**
     * 💬 公开方法: 添加 AI 回复消息
     */
    fun addAIResponse(
        text: String,
        context: Context? = null,
        imageUri: String? = null,
        rawOcrText: String? = null
    ) {
        EngineStateManager.addAIResponse(text, imageUri, rawOcrText)
    }

    /**
     * 👤 公开方法: 添加用户消息
     */
    fun addUserMessage(
        text: String,
        context: Context? = null,
        imageUri: String? = null,
        fileName: String? = null
    ) {
        EngineStateManager.addUserMessage(text, imageUri, fileName)
    }

    fun newConversation() {
        EngineStateManager.startNewConversation()
    }

    fun loadConversation(conversation: Conversation) {
        EngineStateManager.setCurrentConversationId(conversation.id)
        EngineStateManager._messages.value = conversation.messages
        EngineStateManager.updateStatus("待机")
    }
    
    /**
     * 🔄 重试失败的消息
     * @param messageId 要重试的用户消息ID
     */
    fun retryMessage(messageId: String, context: Context? = null) {
        scope.launch {
            try {
                val appContext = context ?: com.example.xihe.XiheApplication.getInstance()?.applicationContext 
                    ?: throw IllegalStateException("Application context not available")
                
                // 确保 EnhancedEngine 已初始化
                EnhancedAutomationEngine.initialize(appContext)
                
                // 调用 EnhancedEngine 的重试方法
                LogManager.d(TAG, "🔄 重试消息: $messageId")
                EnhancedAutomationEngine.retryMessage(messageId)
                
            } catch (e: Exception) {
                LogManager.e(TAG, "重试消息失败", e)
                EngineStateManager.markMessageFailed(messageId, e.message ?: "重试失败")
            }
        }
    }

    /**
     * 📊 保存对话为训练数据
     */
    private fun saveConversationForTraining(
        context: Context,
        userInput: String,
        systemResponse: String,
        intent: com.example.xihe.ai.IntentClassifier.IntentResult?,
        success: Boolean
    ) {
        val entitiesMap = intent?.entities?.mapValues { it.value.toString() } ?: emptyMap()
        com.example.xihe.data.ConversationDataManager.getInstance(context).recordTrainingData(
            userInput, systemResponse, intent?.intent?.name, entitiesMap, success
        )
    }

    /**
     * 💾 自动保存当前对话（应用暂停时调用）
     */
    suspend fun saveCurrentConversation(context: Context) {
        val currentMessages = _messages.value
        if (currentMessages.isNotEmpty()) {
            val firstUserMsg = currentMessages.firstOrNull { it.isUser }?.content
            val firstAIMsg = currentMessages.firstOrNull { !it.isUser }?.content

            val title = when {
                firstUserMsg != null -> {
                    if (firstUserMsg.length > 30) firstUserMsg.take(30) + "..."
                    else firstUserMsg
                }
                firstAIMsg != null -> {
                    if (firstAIMsg.length > 30) firstAIMsg.take(30) + "..."
                    else firstAIMsg
                }
                else -> "自动保存 - ${java.text.SimpleDateFormat("HH:mm", java.util.Locale.CHINA).format(java.util.Date())}"
            }

            val conversation = Conversation(
                id = currentConversationId.value,
                title = title,
                timestamp = System.currentTimeMillis(),
                messages = currentMessages
            )
            ConversationManager.saveConversation(context, conversation)
            LogManager.d(TAG, "✅ 自动保存对话: $title")
        }
    }
}

/**
 * 🛠️ 扩展函数：将本地意图识别结果转换为核心 UserIntent
 */
private fun com.example.xihe.ai.LocalIntentRecognizer.IntentResult.toCoreUserIntent(originalText: String): UserIntent? {
    if (!this.isRecognized) return null
    
    return UserIntent(
        type = this.intent ?: "unknown",
        confidence = this.confidence.toDouble(),
        entities = this.params,
        originalText = originalText
    )
}
