package com.example.xihe.core

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import com.example.xihe.core.model.ChatMessageDisplay
import com.example.xihe.utils.LogManager

val Context.conversationDataStore by preferencesDataStore(name = "conversations")

@Serializable
data class Conversation(
    val id: String,
    var title: String, // Can be edited
    val timestamp: Long,
    val messages: List<ChatMessageDisplay>
)

object ConversationManager {
    private val CONVERSATIONS_KEY = stringPreferencesKey("conversations_list")
    
    suspend fun saveConversation(context: Context, conversation: Conversation) {
        context.conversationDataStore.edit { prefs ->
            val existing = prefs[CONVERSATIONS_KEY] ?: "[]"
            val list = try {
                Json.decodeFromString<List<Conversation>>(existing).toMutableList()
            } catch (e: Exception) {
                mutableListOf()
            }
            
            // Check if conversation with same ID exists
            val existingIndex = list.indexOfFirst { it.id == conversation.id }
            
            if (existingIndex >= 0) {
                // Update existing conversation in place
                list[existingIndex] = conversation
                LogManager.d("ConversationManager", "更新已存在的对话: ${conversation.title}")
            } else {
                // Add new conversation at the beginning
                list.add(0, conversation)
                LogManager.d("ConversationManager", "保存新对话: ${conversation.title}")
            }
            
            // Keep only last 50 conversations
            if (list.size > 50) {
                list.subList(50, list.size).clear()
            }
            
            prefs[CONVERSATIONS_KEY] = Json.encodeToString(list)
        }
    }
    
    fun getConversations(context: Context): Flow<List<Conversation>> {
        return context.conversationDataStore.data.map { prefs ->
            val json = prefs[CONVERSATIONS_KEY] ?: "[]"
            try {
                Json.decodeFromString<List<Conversation>>(json)
            } catch (e: Exception) {
                emptyList()
            }
        }
    }
    
    suspend fun updateConversationTitle(context: Context, conversationId: String, newTitle: String) {
        context.conversationDataStore.edit { prefs ->
            val json = prefs[CONVERSATIONS_KEY] ?: "[]"
            val list = try {
                Json.decodeFromString<List<Conversation>>(json).toMutableList()
            } catch (e: Exception) {
                mutableListOf()
            }
            
            list.find { it.id == conversationId }?.title = newTitle
            prefs[CONVERSATIONS_KEY] = Json.encodeToString(list)
        }
    }
    
    suspend fun deleteConversation(context: Context, conversationId: String) {
        context.conversationDataStore.edit { prefs ->
            val json = prefs[CONVERSATIONS_KEY] ?: "[]"
            val list = try {
                Json.decodeFromString<List<Conversation>>(json).toMutableList()
            } catch (e: Exception) {
                mutableListOf()
            }
            
            list.removeAll { it.id == conversationId }
            prefs[CONVERSATIONS_KEY] = Json.encodeToString(list)
        }
    }
}
