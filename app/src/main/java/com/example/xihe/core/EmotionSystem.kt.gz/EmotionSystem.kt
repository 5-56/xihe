package com.example.xihe.core

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.random.Random

/**
 * 情感系统 (Emotion System) 💖
 * 让羲和拥有情绪变化，更像一个有灵魂的伙伴！
 */
object EmotionSystem {
    
    enum class Mood {
        HAPPY,      // 😊 开心
        EXCITED,    // 🤩 兴奋
        WORRIED,    // 😟 担心
        TIRED,      // 😴 疲惫
        PROUD,      // 😎 自豪
        SAD         // 😢 难过
    }
    
    private val _currentMood = MutableStateFlow(Mood.HAPPY)
    val currentMood = _currentMood.asStateFlow()
    
    private var taskSuccessCount = 0
    private var taskFailureCount = 0
    
    /**
     * 根据事件更新情绪
     */
    fun onTaskStart() {
        _currentMood.value = Mood.EXCITED
    }
    
    fun onTaskSuccess() {
        taskSuccessCount++
        taskFailureCount = 0
        _currentMood.value = when {
            taskSuccessCount > 3 -> Mood.PROUD // 连续成功多次，很自豪
            else -> Mood.HAPPY
        }
    }
    
    fun onTaskFailure() {
        taskFailureCount++
        _currentMood.value = when {
            taskFailureCount >= 3 -> Mood.WORRIED // 连续失败，开始担心
            else -> Mood.SAD
        }
    }
    
    fun onTaskTimeout() {
        _currentMood.value = Mood.TIRED // 任务太久了，累了
    }
    
    fun onUserPraise() {
        taskSuccessCount += 2 // 主人夸奖效果加倍！
        _currentMood.value = Mood.EXCITED
    }
    
    /**
     * 根据当前情绪生成表情和语气
     */
    fun getEmotionExpression(): String {
        return when (_currentMood.value) {
            Mood.HAPPY -> listOf("(◕‿◕✿)", "ヾ(≧▽≦*)o", "٩(◕‿◕｡)۶", "(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧").random()
            Mood.EXCITED -> listOf("(ﾉ≧∀≦)ﾉ", "\\(★ω★)/", "ヽ(♡‿♡)ノ", "(☆▽☆)").random()
            Mood.WORRIED -> listOf("(｡•́︿•̀｡)", "(⌣̩̩́_⌣̩̩̀)", "(；′⌒`)", "( ◞•̥̥̥ ﹏ •̥̥̥◟ )").random()
            Mood.TIRED -> listOf("(´ρ`)", "(¬_¬;)", "(｡-ω-)zzz", "(-‿-)zzZ").random()
            Mood.PROUD -> listOf("(￣︶￣)↗ ", "ᕙ(⇀‸↼‶)ᕗ", "(•̀ᴗ•́)و", "ヽ(•̀ω•́ )ゝ").random()
            Mood.SAD -> listOf("(╥﹏╥)", "(｡•́︿•̀｡)", "( ；∀；)", "｡･ﾟ･(ノД`)･ﾟ･｡").random()
        }
    }
    
    fun getMoodModifier(): String {
        return when (_currentMood.value) {
            Mood.HAPPY -> "开心地"
            Mood.EXCITED -> "兴奋地"
            Mood.WORRIED -> "担心地"
            Mood.TIRED -> "疲惫地"
            Mood.PROUD -> "自豪地"
            Mood.SAD -> "难过地"
        }
    }
}
