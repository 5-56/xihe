package com.example.xihe.core

import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.core.AICommand
import com.example.xihe.core.EngineStateManager
import com.example.xihe.core.TaskProgress
import kotlinx.coroutines.delay
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

object MacroManager {
    private const val TAG = "MacroManager"
    private const val MACRO_FILE_NAME = "macros.json"
    
    private var macros = mutableMapOf<String, Macro>()
    
    @Serializable
    data class Macro(
        val name: String,
        val description: String,
        val triggers: List<String>, // 触发词，如 "打卡", "报销"
        val actions: List<SimplifiedCommand> // 简化的动作序列（只保存关键信息）
    )
    
    // 简化的命令，只保存核心字段，避免序列化问题
    @Serializable
    data class SimplifiedCommand(
        val thought: String,
        val action: String,
        val targetId: Int? = null,
        val inputText: String? = null,
        val direction: String? = null
    )
    
    fun init(context: Context) {
        loadMacros(context)
    }
    
    fun saveMacro(context: Context, name: String, description: String, triggers: List<String>, actions: List<AICommand>) {
        // 转换为简化版本
        val simplifiedActions = actions.map { cmd ->
            SimplifiedCommand(
                thought = cmd.thought,
                action = cmd.action,
                targetId = cmd.targetId,
                inputText = cmd.inputText,
                direction = cmd.direction
            )
        }
        
        val macro = Macro(name, description, triggers, simplifiedActions)
        macros[name] = macro
        persistMacros(context)
        LogManager.w(TAG, "Saved macro: $name with ${actions.size} actions")
    }
    
    fun findMacro(query: String): Macro? {
        // 简单匹配：如果 query 包含触发词
        return macros.values.find { macro -> 
            macro.triggers.any { trigger -> query.contains(trigger, ignoreCase = true) } ||
            macro.name.equals(query, ignoreCase = true)
        }
    }
    
    fun getAllMacros(): List<Macro> = macros.values.toList()

    /**
     * 🎓 执行宏指令 (Semantic Macro Execution)
     * 
     * 从 AutomationEngine 迁移，支持语义重定向和智能匹配
     */
    suspend fun executeMacro(
        context: Context,
        macro: Macro,
        llmClient: com.example.xihe.core.LLMClient
    ) {
        val service = CoreAccessibilityService.instance ?: return
        val executor = ActionExecutor(service, context)

        EngineStateManager.updateProgress(TaskProgress(
            currentStep = 0,
            totalSteps = macro.actions.size,
            taskName = macro.name,
            currentAction = "准备施展技能...",
            isRunning = true
        ))

        val history = mutableListOf<String>()

        for ((index, simplifiedCmd) in macro.actions.withIndex()) {
            EngineStateManager.updateStatus("执行步骤 ${index + 1}/${macro.actions.size}")

            // 1. 获取当前屏幕
            val root = service.rootInActiveWindow
            if (root == null) {
                EngineStateManager.addAIResponse("执行中断：无法获取屏幕。")
                break
            }
            val state = ScreenAnalyzer.analyze(root, root.packageName?.toString() ?: "")

            // 2. 语义重定向 (Semantic Retargeting) 🎯
            EngineStateManager.updateStatus("校准目标中...")
            val adaptedCommand = if (state != null) {
                llmClient.think(state, "请执行这一步：${simplifiedCmd.thought}", history)
            } else {
                // Fallback: 转换回 AICommand
                AICommand(
                    thought = simplifiedCmd.thought,
                    action = simplifiedCmd.action,
                    targetId = simplifiedCmd.targetId,
                    inputText = simplifiedCmd.inputText,
                    direction = simplifiedCmd.direction
                )
            }

            LogManager.d(TAG, "Macro Step $index: Original='${simplifiedCmd.thought}' -> Adapted='${adaptedCommand.action}'")
            EngineStateManager.addAIResponse("技能步骤 ${index + 1}: ${adaptedCommand.thought}")

            // 3. 执行
            val success = executor.execute(adaptedCommand, root)
            if (!success) {
                EngineStateManager.addAIResponse("技能施展失败：第 ${index + 1} 步卡住了...")
                break
            }

            // 4. 记录历史并等待
            history.add("Step ${index + 1}: ${adaptedCommand.thought} -> Success")

            EngineStateManager.updateProgress(EngineStateManager.taskProgress.value.copy(
                currentStep = index + 1,
                currentAction = adaptedCommand.thought
            ))

            delay(1500)
        }

        EngineStateManager.updateStatus("技能完成")
        EngineStateManager.updateProgress(EngineStateManager.taskProgress.value.copy(
            isRunning = false,
            currentAction = "技能施展完毕！✨"
        ))
        EngineStateManager.addAIResponse("【${macro.name}】技能施展完毕！哒哒！🎉")
    }
    
    private fun persistMacros(context: Context) {
        try {
            val file = File(context.filesDir, MACRO_FILE_NAME)
            val jsonString = Json.encodeToString(macros)
            file.writeText(jsonString)
        } catch (e: Exception) {
            LogManager.e(TAG, "Failed to save macros", e)
        }
    }
    
    private fun loadMacros(context: Context) {
        try {
            val file = File(context.filesDir, MACRO_FILE_NAME)
            if (file.exists()) {
                val jsonString = file.readText()
                val loadedMacros = Json.decodeFromString<Map<String, Macro>>(jsonString)
                macros.clear()
                macros.putAll(loadedMacros)
                LogManager.w(TAG, "Loaded ${macros.size} macros")
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "Failed to load macros", e)
        }
    }
}
