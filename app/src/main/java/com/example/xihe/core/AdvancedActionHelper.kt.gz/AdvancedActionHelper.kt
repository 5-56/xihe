package com.example.xihe.core

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import com.example.xihe.utils.LogManager
import android.view.accessibility.AccessibilityNodeInfo
import com.example.xihe.CoreAccessibilityService
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.min
import kotlin.random.Random

/**
 * 🎮 高级操作辅助器
 * 
 * 补充功能：
 * - 📍 智能点击位置计算
 * - 🔄 惯性滑动模拟
 * - ⌨️ 模拟真实输入速度
 * - 🎯 多点触控支持
 * - 📏 滑动边界检测
 */
object AdvancedActionHelper {
    
    private const val TAG = "AdvancedAction"
    
    // ==================== 📍 智能点击 ====================
    
    /**
     * 📍 计算智能点击位置
     * 考虑元素实际可点击区域，避免边缘
     */
    fun calculateSmartClickPosition(
        node: AccessibilityNodeInfo,
        strategy: ClickPositionStrategy = ClickPositionStrategy.CENTER_SAFE
    ): ClickPosition {
        val rect = Rect()
        node.getBoundsInScreen(rect)
        
        // 检查元素是否有有效尺寸
        if (rect.width() <= 0 || rect.height() <= 0) {
            LogManager.w(TAG, "⚠️ 元素尺寸无效")
            return ClickPosition(
                x = rect.centerX().toFloat(),
                y = rect.centerY().toFloat(),
                confidence = 0.5f
            )
        }
        
        return when (strategy) {
            ClickPositionStrategy.CENTER_SAFE -> {
                // 安全中心：避免边缘10%区域
                val paddingX = (rect.width() * 0.1f).coerceAtLeast(5f)
                val paddingY = (rect.height() * 0.1f).coerceAtLeast(5f)
                
                ClickPosition(
                    x = rect.centerX().toFloat(),
                    y = rect.centerY().toFloat(),
                    confidence = 0.95f,
                    safeZone = Rect(
                        (rect.left + paddingX).toInt(),
                        (rect.top + paddingY).toInt(),
                        (rect.right - paddingX).toInt(),
                        (rect.bottom - paddingY).toInt()
                    )
                )
            }
            
            ClickPositionStrategy.RANDOM_IN_BOUNDS -> {
                // 随机位置：模拟真实用户行为
                val paddingX = (rect.width() * 0.15f).coerceAtLeast(8f)
                val paddingY = (rect.height() * 0.15f).coerceAtLeast(8f)
                
                val randomX = Random.nextFloat() * (rect.width() - 2 * paddingX) + rect.left + paddingX
                val randomY = Random.nextFloat() * (rect.height() - 2 * paddingY) + rect.top + paddingY
                
                ClickPosition(
                    x = randomX,
                    y = randomY,
                    confidence = 0.9f
                )
            }
            
            ClickPositionStrategy.TEXT_AREA -> {
                // 文字区域：偏向文字所在位置（通常在左侧或中心）
                val textBiasX = rect.left + rect.width() * 0.4f
                ClickPosition(
                    x = textBiasX,
                    y = rect.centerY().toFloat(),
                    confidence = 0.85f
                )
            }
            
            ClickPositionStrategy.ICON_AREA -> {
                // 图标区域：偏向图标位置（通常在左侧）
                val iconBiasX = rect.left + min(rect.width() * 0.25f, 50f)
                ClickPosition(
                    x = iconBiasX,
                    y = rect.centerY().toFloat(),
                    confidence = 0.85f
                )
            }
        }
    }
    
    /**
     * 🎯 验证点击区域有效性
     */
    fun validateClickArea(
        node: AccessibilityNodeInfo,
        screenWidth: Int,
        screenHeight: Int
    ): ClickValidation {
        val rect = Rect()
        node.getBoundsInScreen(rect)
        
        val issues = mutableListOf<String>()
        var isValid = true
        
        // 检查是否在屏幕内
        if (rect.left < 0 || rect.top < 0 || 
            rect.right > screenWidth || rect.bottom > screenHeight) {
            issues.add("元素部分在屏幕外")
        }
        
        // 检查尺寸是否太小
        if (rect.width() < 20 || rect.height() < 20) {
            issues.add("元素尺寸过小 (${rect.width()}x${rect.height()})")
            isValid = false
        }
        
        // 检查是否被遮挡（简单检测）
        if (!node.isVisibleToUser) {
            issues.add("元素不可见")
            isValid = false
        }
        
        // 检查是否可点击
        if (!node.isClickable && !node.isEnabled) {
            issues.add("元素不可点击")
            isValid = false
        }
        
        return ClickValidation(
            isValid = isValid,
            bounds = rect,
            issues = issues,
            recommendedAction = when {
                issues.isEmpty() -> "可以点击"
                issues.contains("元素不可见") -> "等待元素可见后重试"
                issues.contains("元素尺寸过小") -> "尝试点击父元素"
                else -> "尝试滚动使元素完全可见"
            }
        )
    }
    
    // ==================== 🔄 惯性滑动 ====================
    
    /**
     * 🔄 执行惯性滑动（模拟真实手指滑动）
     */
    suspend fun performInertiaScroll(
        service: CoreAccessibilityService,
        direction: ScrollDirection,
        intensity: ScrollIntensity = ScrollIntensity.NORMAL
    ): Boolean {
        val displayMetrics = service.resources.displayMetrics
        val width = displayMetrics.widthPixels
        val height = displayMetrics.heightPixels
        
        // 根据强度计算滑动参数
        val params = calculateInertiaScrollParams(direction, intensity, width, height)
        
        LogManager.d(TAG, "🔄 惯性滑动: $direction, 强度=$intensity")
        
        // 创建曲线路径模拟惯性
        val path = Path()
        path.moveTo(params.startX, params.startY)
        
        // 添加贝塞尔曲线实现惯性效果
        val controlX = (params.startX + params.endX) / 2
        val controlY = (params.startY + params.endY) / 2
        
        // 根据方向调整控制点偏移
        val offsetRatio = when (intensity) {
            ScrollIntensity.LIGHT -> 0.05f
            ScrollIntensity.NORMAL -> 0.1f
            ScrollIntensity.STRONG -> 0.15f
            ScrollIntensity.FLING -> 0.2f
        }
        
        when (direction) {
            ScrollDirection.UP, ScrollDirection.DOWN -> {
                path.quadTo(
                    controlX + width * offsetRatio * (if (Random.nextBoolean()) 1 else -1),
                    controlY,
                    params.endX,
                    params.endY
                )
            }
            ScrollDirection.LEFT, ScrollDirection.RIGHT -> {
                path.quadTo(
                    controlX,
                    controlY + height * offsetRatio * (if (Random.nextBoolean()) 1 else -1),
                    params.endX,
                    params.endY
                )
            }
        }
        
        // 计算滑动时长（惯性滑动更快）
        val duration = when (intensity) {
            ScrollIntensity.LIGHT -> 400L
            ScrollIntensity.NORMAL -> 300L
            ScrollIntensity.STRONG -> 200L
            ScrollIntensity.FLING -> 150L
        }
        
        val gestureBuilder = GestureDescription.Builder()
        val stroke = GestureDescription.StrokeDescription(path, 0, duration)
        gestureBuilder.addStroke(stroke)
        
        return dispatchGestureSync(service, gestureBuilder.build())
    }
    
    /**
     * 📏 计算惯性滑动参数
     */
    private fun calculateInertiaScrollParams(
        direction: ScrollDirection,
        intensity: ScrollIntensity,
        screenWidth: Int,
        screenHeight: Int
    ): ScrollParams {
        val centerX = screenWidth / 2f
        val centerY = screenHeight / 2f
        
        // 根据强度计算滑动距离
        val distanceRatio = when (intensity) {
            ScrollIntensity.LIGHT -> 0.2f
            ScrollIntensity.NORMAL -> 0.35f
            ScrollIntensity.STRONG -> 0.5f
            ScrollIntensity.FLING -> 0.7f
        }
        
        val verticalDistance = screenHeight * distanceRatio
        val horizontalDistance = screenWidth * distanceRatio
        
        return when (direction) {
            ScrollDirection.DOWN -> ScrollParams(
                startX = centerX + Random.nextFloat() * 50 - 25,
                startY = centerY + verticalDistance / 2,
                endX = centerX + Random.nextFloat() * 30 - 15,
                endY = centerY - verticalDistance / 2
            )
            ScrollDirection.UP -> ScrollParams(
                startX = centerX + Random.nextFloat() * 50 - 25,
                startY = centerY - verticalDistance / 2,
                endX = centerX + Random.nextFloat() * 30 - 15,
                endY = centerY + verticalDistance / 2
            )
            ScrollDirection.LEFT -> ScrollParams(
                startX = centerX - horizontalDistance / 2,
                startY = centerY + Random.nextFloat() * 50 - 25,
                endX = centerX + horizontalDistance / 2,
                endY = centerY + Random.nextFloat() * 30 - 15
            )
            ScrollDirection.RIGHT -> ScrollParams(
                startX = centerX + horizontalDistance / 2,
                startY = centerY + Random.nextFloat() * 50 - 25,
                endX = centerX - horizontalDistance / 2,
                endY = centerY + Random.nextFloat() * 30 - 15
            )
        }
    }
    
    /**
     * 📏 检测滑动边界
     */
    fun detectScrollBoundary(
        rootNode: AccessibilityNodeInfo?,
        direction: ScrollDirection
    ): ScrollBoundaryInfo {
        if (rootNode == null) {
            return ScrollBoundaryInfo(canScroll = false, atBoundary = true)
        }
        
        // 查找可滚动元素
        val scrollable = findScrollableNode(rootNode)
        
        if (scrollable == null) {
            return ScrollBoundaryInfo(
                canScroll = false,
                atBoundary = true,
                reason = "未找到可滚动元素"
            )
        }
        
        // 检查是否可以继续滚动
        val canScrollForward = scrollable.actionList?.any { 
            it.id == AccessibilityNodeInfo.ACTION_SCROLL_FORWARD 
        } ?: false
        
        val canScrollBackward = scrollable.actionList?.any { 
            it.id == AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD 
        } ?: false
        
        val canScroll = when (direction) {
            ScrollDirection.DOWN, ScrollDirection.RIGHT -> canScrollForward
            ScrollDirection.UP, ScrollDirection.LEFT -> canScrollBackward
        }
        
        return ScrollBoundaryInfo(
            canScroll = canScroll,
            atBoundary = !canScroll,
            canScrollForward = canScrollForward,
            canScrollBackward = canScrollBackward
        )
    }
    
    private fun findScrollableNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable) return node
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findScrollableNode(child)
            if (found != null) return found
        }
        
        return null
    }
    
    // ==================== ⌨️ 真实输入模拟 ====================
    
    /**
     * ⌨️ 模拟真实输入速度
     * 逐字符输入，带随机延迟
     */
    suspend fun performRealisticInput(
        service: CoreAccessibilityService,
        node: AccessibilityNodeInfo,
        text: String,
        speed: InputSpeed = InputSpeed.NORMAL
    ): InputResult {
        LogManager.d(TAG, "⌨️ 开始真实输入: ${text.take(20)}... (${text.length}字符)")
        val startTime = System.currentTimeMillis()
        
        // 确保聚焦
        if (!node.isFocused) {
            node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            delay(100)
        }
        
        // 清空现有内容
        val currentText = node.text?.toString() ?: ""
        if (currentText.isNotEmpty()) {
            val selectArgs = Bundle().apply {
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0)
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, currentText.length)
            }
            node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, selectArgs)
            delay(50)
        }
        
        // 计算输入延迟范围
        val (minDelay, maxDelay) = when (speed) {
            InputSpeed.SLOW -> 150L to 300L
            InputSpeed.NORMAL -> 50L to 150L
            InputSpeed.FAST -> 20L to 80L
            InputSpeed.INSTANT -> 0L to 0L
        }
        
        var inputText = ""
        var errorCount = 0
        
        for ((index, char) in text.withIndex()) {
            inputText += char
            
            // 设置文本
            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, inputText)
            }
            
            val success = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            
            if (!success) {
                errorCount++
                LogManager.w(TAG, "⚠️ 输入字符失败: '$char' at $index")
            }
            
            // 添加随机延迟（模拟真实打字）
            if (minDelay > 0) {
                val delayTime = Random.nextLong(minDelay, maxDelay + 1)
                delay(delayTime)
            }
            
            // 偶尔增加额外延迟（模拟思考）
            if (speed != InputSpeed.INSTANT && Random.nextFloat() < 0.1f) {
                delay(Random.nextLong(100, 300))
            }
        }
        
        val duration = System.currentTimeMillis() - startTime
        val finalText = node.text?.toString() ?: ""
        val success = finalText == text || finalText.contains(text)
        
        LogManager.d(TAG, "✅ 输入完成: success=$success, duration=${duration}ms, errors=$errorCount")
        
        return InputResult(
            success = success,
            inputText = text,
            finalText = finalText,
            duration = duration,
            errorCount = errorCount,
            speed = speed
        )
    }
    
    /**
     * 🔤 处理特殊字符输入
     */
    fun processSpecialCharacters(text: String): ProcessedText {
        val specialChars = mutableListOf<SpecialCharInfo>()
        val processedBuilder = StringBuilder()
        
        for ((index, char) in text.withIndex()) {
            when {
                // Emoji检测
                Character.isHighSurrogate(char) || isEmoji(char.code) -> {
                    specialChars.add(SpecialCharInfo(
                        char = char.toString(),
                        index = index,
                        type = SpecialCharType.EMOJI
                    ))
                    processedBuilder.append(char)
                }
                // 特殊符号
                char in listOf('©', '®', '™', '℃', '℉', '°') -> {
                    specialChars.add(SpecialCharInfo(
                        char = char.toString(),
                        index = index,
                        type = SpecialCharType.SYMBOL
                    ))
                    processedBuilder.append(char)
                }
                // 换行符
                char == '\n' -> {
                    specialChars.add(SpecialCharInfo(
                        char = "\\n",
                        index = index,
                        type = SpecialCharType.NEWLINE
                    ))
                    processedBuilder.append(char)
                }
                // 普通字符
                else -> {
                    processedBuilder.append(char)
                }
            }
        }
        
        return ProcessedText(
            original = text,
            processed = processedBuilder.toString(),
            specialChars = specialChars,
            hasSpecialChars = specialChars.isNotEmpty()
        )
    }
    
    private fun isEmoji(codePoint: Int): Boolean {
        return codePoint in 0x1F600..0x1F64F ||  // Emoticons
               codePoint in 0x1F300..0x1F5FF ||  // Misc Symbols
               codePoint in 0x1F680..0x1F6FF ||  // Transport
               codePoint in 0x2600..0x26FF ||    // Misc symbols
               codePoint in 0x2700..0x27BF       // Dingbats
    }
    
    // ==================== 🎯 多点触控 ====================
    
    /**
     * 🤏 双指缩放手势
     */
    suspend fun performPinchGesture(
        service: CoreAccessibilityService,
        centerX: Float,
        centerY: Float,
        zoomIn: Boolean,
        scale: Float = 0.5f
    ): Boolean {
        LogManager.d(TAG, "🤏 双指缩放: center=($centerX, $centerY), zoomIn=$zoomIn, scale=$scale")
        
        val startDistance = 100f
        val endDistance = if (zoomIn) startDistance * (1 + scale) else startDistance * (1 - scale)
        
        // 创建两条路径
        val path1 = Path()
        val path2 = Path()
        
        if (zoomIn) {
            // 放大：从内向外
            path1.moveTo(centerX - startDistance / 2, centerY)
            path1.lineTo(centerX - endDistance / 2, centerY)
            
            path2.moveTo(centerX + startDistance / 2, centerY)
            path2.lineTo(centerX + endDistance / 2, centerY)
        } else {
            // 缩小：从外向内
            path1.moveTo(centerX - endDistance / 2, centerY)
            path1.lineTo(centerX - startDistance / 2, centerY)
            
            path2.moveTo(centerX + endDistance / 2, centerY)
            path2.lineTo(centerX + startDistance / 2, centerY)
        }
        
        val gestureBuilder = GestureDescription.Builder()
        gestureBuilder.addStroke(GestureDescription.StrokeDescription(path1, 0, 300))
        gestureBuilder.addStroke(GestureDescription.StrokeDescription(path2, 0, 300))
        
        return dispatchGestureSync(service, gestureBuilder.build())
    }
    
    /**
     * ✌️ 双指滑动手势
     */
    suspend fun performTwoFingerScroll(
        service: CoreAccessibilityService,
        startY: Float,
        endY: Float,
        screenWidth: Int
    ): Boolean {
        LogManager.d(TAG, "✌️ 双指滑动: startY=$startY, endY=$endY")
        
        val finger1X = screenWidth * 0.35f
        val finger2X = screenWidth * 0.65f
        
        val path1 = Path()
        path1.moveTo(finger1X, startY)
        path1.lineTo(finger1X, endY)
        
        val path2 = Path()
        path2.moveTo(finger2X, startY)
        path2.lineTo(finger2X, endY)
        
        val gestureBuilder = GestureDescription.Builder()
        gestureBuilder.addStroke(GestureDescription.StrokeDescription(path1, 0, 300))
        gestureBuilder.addStroke(GestureDescription.StrokeDescription(path2, 0, 300))
        
        return dispatchGestureSync(service, gestureBuilder.build())
    }
    
    /**
     * 🔄 旋转手势
     */
    suspend fun performRotateGesture(
        service: CoreAccessibilityService,
        centerX: Float,
        centerY: Float,
        clockwise: Boolean,
        degrees: Float = 90f
    ): Boolean {
        LogManager.d(TAG, "🔄 旋转手势: center=($centerX, $centerY), clockwise=$clockwise, degrees=$degrees")
        
        val radius = 100f
        val steps = 10
        val angleStep = Math.toRadians((if (clockwise) degrees else -degrees).toDouble() / steps)
        
        val path1 = Path()
        val path2 = Path()
        
        // 初始位置：水平对称
        var angle1 = 0.0
        var angle2 = Math.PI
        
        path1.moveTo(
            centerX + (radius * Math.cos(angle1)).toFloat(),
            centerY + (radius * Math.sin(angle1)).toFloat()
        )
        path2.moveTo(
            centerX + (radius * Math.cos(angle2)).toFloat(),
            centerY + (radius * Math.sin(angle2)).toFloat()
        )
        
        for (i in 1..steps) {
            angle1 += angleStep
            angle2 += angleStep
            
            path1.lineTo(
                centerX + (radius * Math.cos(angle1)).toFloat(),
                centerY + (radius * Math.sin(angle1)).toFloat()
            )
            path2.lineTo(
                centerX + (radius * Math.cos(angle2)).toFloat(),
                centerY + (radius * Math.sin(angle2)).toFloat()
            )
        }
        
        val gestureBuilder = GestureDescription.Builder()
        gestureBuilder.addStroke(GestureDescription.StrokeDescription(path1, 0, 500))
        gestureBuilder.addStroke(GestureDescription.StrokeDescription(path2, 0, 500))
        
        return dispatchGestureSync(service, gestureBuilder.build())
    }
    
    // ==================== 🔧 辅助方法 ====================
    
    private suspend fun dispatchGestureSync(
        service: CoreAccessibilityService,
        gesture: GestureDescription
    ): Boolean {
        var result = false
        var completed = false
        
        service.dispatchGesture(
            gesture,
            object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    result = true
                    completed = true
                }
                
                override fun onCancelled(gestureDescription: GestureDescription?) {
                    result = false
                    completed = true
                }
            },
            null
        )
        
        // 等待手势完成
        var waitTime = 0
        while (!completed && waitTime < 2000) {
            delay(50)
            waitTime += 50
        }
        
        return result
    }
}

// ==================== 📦 数据类定义 ====================

/**
 * 📍 点击位置策略
 */
enum class ClickPositionStrategy {
    CENTER_SAFE,        // 安全中心（避开边缘）
    RANDOM_IN_BOUNDS,   // 边界内随机
    TEXT_AREA,          // 文字区域
    ICON_AREA           // 图标区域
}

/**
 * 📍 点击位置
 */
data class ClickPosition(
    val x: Float,
    val y: Float,
    val confidence: Float,
    val safeZone: Rect? = null
)

/**
 * ✅ 点击验证结果
 */
data class ClickValidation(
    val isValid: Boolean,
    val bounds: Rect,
    val issues: List<String>,
    val recommendedAction: String
)

/**
 * 🔄 滑动强度
 */
enum class ScrollIntensity {
    LIGHT,      // 轻触滑动
    NORMAL,     // 普通滑动
    STRONG,     // 强力滑动
    FLING       // 快速滑动（惯性）
}

/**
 * 📏 滑动边界信息
 */
data class ScrollBoundaryInfo(
    val canScroll: Boolean,
    val atBoundary: Boolean,
    val canScrollForward: Boolean = false,
    val canScrollBackward: Boolean = false,
    val reason: String? = null
)

/**
 * ⌨️ 输入速度
 */
enum class InputSpeed {
    SLOW,       // 慢速（模拟新手）
    NORMAL,     // 正常速度
    FAST,       // 快速
    INSTANT     // 瞬间（无延迟）
}

/**
 * ⌨️ 输入结果
 */
data class InputResult(
    val success: Boolean,
    val inputText: String,
    val finalText: String,
    val duration: Long,
    val errorCount: Int,
    val speed: InputSpeed
)

/**
 * 🔤 处理后的文本
 */
data class ProcessedText(
    val original: String,
    val processed: String,
    val specialChars: List<SpecialCharInfo>,
    val hasSpecialChars: Boolean
)

/**
 * 🔤 特殊字符信息
 */
data class SpecialCharInfo(
    val char: String,
    val index: Int,
    val type: SpecialCharType
)

/**
 * 🔤 特殊字符类型
 */
enum class SpecialCharType {
    EMOJI, SYMBOL, NEWLINE, OTHER
}
