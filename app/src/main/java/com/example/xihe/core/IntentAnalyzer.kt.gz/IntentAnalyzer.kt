package com.example.xihe.core

import com.example.xihe.utils.LogManager
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.*

/**
 * 🧠 AI 意图分析器
 * 使用 LLM 理解用户的真实意图，而不是依赖固定的正则表达式
 */
object IntentAnalyzer {
    private const val TAG = "IntentAnalyzer"
    
    /**
     * 分析用户意图
     */
    suspend fun analyzeIntent(
        userInput: String,
        llmClient: LLMClient
    ): UserIntent? {
        LogManager.w(TAG, "===== 开始分析用户意图 =====")
        LogManager.w(TAG, "用户输入: $userInput")
        
        val prompt = buildIntentAnalysisPrompt(userInput)
        
        return try {
            // 调用 LLM 分析意图（不使用性格系统提示词）
            val response = llmClient.chatCompletion(prompt, usePersonality = false)
            LogManager.w(TAG, "LLM 原始响应: $response")
            
            // 解析 JSON 响应
            parseIntentResponse(response, userInput)
        } catch (e: Exception) {
            LogManager.w(TAG, "意图分析失败", e)
            null
        }
    }
    
    /**
     * 构建意图分析的 Prompt
     */
    private fun buildIntentAnalysisPrompt(userInput: String): String {
        return """你是一个智能意图识别助手。请分析用户的指令，判断用户想要做什么。

**用户指令**: "$userInput"

**你需要识别的意图类型**:
1. **send_message** - 发送消息（微信、QQ等）
   - 关键词: 发消息、发微信、给xxx发、聊天
   - 提取: app(微信/QQ), contactName(联系人), message(消息内容)

2. **watch_video** - 刷视频
   - 关键词: 刷视频、看视频、抖音、快手、B站
   - 提取: app(抖音/快手/B站), keyword(搜索关键词，可选), count(视频数量)

3. **search_and_browse** - 搜索并浏览
   - 关键词: 搜索、查找、百度、谷歌、浏览
   - 提取: platform(百度/谷歌/浏览器), keyword(搜索关键词), count(浏览数量), clickAds(是否点广告)
   - **重要**: 
     - 如果用户说"打开百度/谷歌，搜索xxx"，platform应该是"百度APP"或"谷歌APP"
     - 如果用户说"在浏览器搜索xxx"，platform应该是"浏览器"

4. **open_app** - 打开应用（优先级高）
   - 关键词: 打开、启动、运行、开启、打开一下、帮我打开
   - 提取: appName(应用名称)
   - **重要**: 即使不确定应用是否存在，也要返回 open_app 意图，让系统智能搜索

5. **other** - 其他指令（需要 AI 自动化执行）

**请以 JSON 格式回复**（只输出JSON，不要其他内容）:
```json
{
  "intent": "意图类型",
  "confidence": 0.95,
  "parameters": {
    // 根据意图类型提取的参数
  },
  "reasoning": "你的判断理由"
}
```

**示例1**:
用户: "打开百度，帮我搜索胃疼应该吃什么药，并且连续查看5个推荐内容"
回复:
```json
{
  "intent": "search_and_browse",
  "confidence": 0.98,
  "parameters": {
    "platform": "百度APP",
    "keyword": "胃疼应该吃什么药",
    "count": 5,
    "clickAds": false
  },
  "reasoning": "用户明确说打开百度，所以应该用百度APP，而不是浏览器。搜索关键词是'胃疼应该吃什么药'，要查看5个内容。"
}
```

**示例2**:
用户: "给张三发微信说明天开会"
回复:
```json
{
  "intent": "send_message",
  "confidence": 0.99,
  "parameters": {
    "app": "微信",
    "contactName": "张三",
    "message": "明天开会"
  },
  "reasoning": "用户要给张三发微信，消息内容是'明天开会'"
}
```

**示例3**:
用户: "在抖音搜索美食刷10个视频"
回复:
```json
{
  "intent": "watch_video",
  "confidence": 0.98,
  "parameters": {
    "app": "抖音",
    "keyword": "美食",
    "count": 10
  },
  "reasoning": "用户想在抖音看视频，搜索关键词是美食，要刷10个"
}
```

现在请分析上面的用户指令，只输出JSON，不要其他解释。"""
    }
    
    /**
     * 解析 LLM 的响应
     */
    private fun parseIntentResponse(response: String, originalText: String): UserIntent? {
        return try {
            // 提取 JSON 部分（可能被包裹在 ```json ``` 中）
            val jsonText = response
                .replace("```json", "")
                .replace("```", "")
                .trim()
            
            val json = Json.parseToJsonElement(jsonText).jsonObject
            
            val intentType = json["intent"]?.jsonPrimitive?.content ?: return null
            val confidence = json["confidence"]?.jsonPrimitive?.doubleOrNull ?: 0.0
            val parameters = json["parameters"]?.jsonObject ?: return null
            val reasoning = json["reasoning"]?.jsonPrimitive?.content ?: ""

            val entities = mutableMapOf<String, String>()
            if (intentType == "send_message") {
                parameters["app"]?.jsonPrimitive?.content?.let { entities["app"] = it }
                // 兼容 contactName 和 contact 两种字段名，并同时填充
                val contactValue = parameters["contactName"]?.jsonPrimitive?.content
                    ?: parameters["contact"]?.jsonPrimitive?.content
                contactValue?.let {
                    entities["contactName"] = it
                    entities["contact"] = it
                }
                parameters["message"]?.jsonPrimitive?.content?.let { entities["message"] = it }
            }
            
            LogManager.w(TAG, "解析成功 - 意图: $intentType, 置信度: $confidence")
            LogManager.w(TAG, "理由: $reasoning")
            
            UserIntent(
                type = intentType,
                confidence = confidence,
                entities = entities,
                parameters = parameters,
                reasoning = reasoning,
                originalText = originalText
            )
        } catch (e: Exception) {
            LogManager.w(TAG, "解析 JSON 失败", e)
            null
        }
    }
}

// UserIntent已在Models.kt中定义，此处不再重复定义
