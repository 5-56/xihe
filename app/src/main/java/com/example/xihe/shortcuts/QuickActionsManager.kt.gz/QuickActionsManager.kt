package com.example.xihe.shortcuts

import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.health.HealthManager
import com.example.xihe.intelligence.MemorySystem
import com.example.xihe.intelligence.PersonalizedRecommender

/**
 * ⚡ 快捷操作管理器
 * 提供一键快速操作，提升使用便利性
 */
class QuickActionsManager(private val context: Context) {
    
    companion object {
        private const val TAG = "QuickActions"
        
        @Volatile
        private var instance: QuickActionsManager? = null
        
        fun getInstance(context: Context): QuickActionsManager {
            return instance ?: synchronized(this) {
                instance ?: QuickActionsManager(context.applicationContext).also {
                    instance = it
                }
            }
        }
    }
    
    private val healthManager = HealthManager.getInstance(context)
    private val memorySystem = MemorySystem.getInstance(context)
    private val recommender = PersonalizedRecommender.getInstance(context)
    
    /**
     * 📋 获取所有快捷操作
     */
    fun getAllQuickActions(): List<QuickAction> {
        return listOf(
            // 健康相关
            QuickAction(
                id = "quick_water",
                icon = "💧",
                title = "快速喝水",
                description = "记录喝水一杯",
                category = QuickActionCategory.HEALTH,
                action = { quickRecordWater() }
            ),
            
            QuickAction(
                id = "start_exercise",
                icon = "💪",
                title = "开始运动",
                description = "开始记录运动",
                category = QuickActionCategory.HEALTH,
                action = { quickStartExercise() }
            ),
            
            QuickAction(
                id = "health_report",
                icon = "📊",
                title = "健康报告",
                description = "查看今日健康报告",
                category = QuickActionCategory.HEALTH,
                action = { quickHealthReport() }
            ),
            
            // 个人相关
            QuickAction(
                id = "daily_summary",
                icon = "📅",
                title = "今日总结",
                description = "查看今日活动总结",
                category = QuickActionCategory.PERSONAL,
                action = { quickDailySummary() }
            ),
            
            QuickAction(
                id = "memory_stats",
                icon = "🧠",
                title = "记忆统计",
                description = "查看记忆统计",
                category = QuickActionCategory.PERSONAL,
                action = { quickMemoryStats() }
            ),
            
            // 推荐相关
            QuickAction(
                id = "get_recommendations",
                icon = "🎯",
                title = "获取推荐",
                description = "查看个性化推荐",
                category = QuickActionCategory.RECOMMEND,
                action = { quickGetRecommendations() }
            ),
            
            QuickAction(
                id = "music_recommend",
                icon = "🎵",
                title = "音乐推荐",
                description = "根据心情推荐音乐",
                category = QuickActionCategory.RECOMMEND,
                action = { quickMusicRecommend() }
            ),
            
            QuickAction(
                id = "food_recommend",
                icon = "🍽️",
                title = "美食推荐",
                description = "推荐附近美食",
                category = QuickActionCategory.RECOMMEND,
                action = { quickFoodRecommend() }
            ),
            
            // 设置相关
            QuickAction(
                id = "toggle_proactive",
                icon = "🤖",
                title = "主动对话",
                description = "开启/关闭主动对话",
                category = QuickActionCategory.SETTINGS,
                action = { quickToggleProactive() }
            ),
            
            QuickAction(
                id = "clear_memory",
                icon = "🗑️",
                title = "清空记忆",
                description = "清空所有记忆数据",
                category = QuickActionCategory.SETTINGS,
                action = { quickClearMemory() },
                requiresConfirmation = true
            )
        )
    }
    
    /**
     * 📋 按分类获取快捷操作
     */
    fun getQuickActionsByCategory(category: QuickActionCategory): List<QuickAction> {
        return getAllQuickActions().filter { it.category == category }
    }
    
    /**
     * ⚡ 执行快捷操作
     */
    fun executeQuickAction(actionId: String, onResult: (QuickActionResult) -> Unit) {
        val action = getAllQuickActions().find { it.id == actionId }
        
        if (action == null) {
            LogManager.i(TAG, "⚠️ 未找到快捷操作: $actionId")
            onResult(QuickActionResult.Error("未找到该操作"))
            return
        }
        
        try {
            LogManager.d(TAG, "⚡ 执行快捷操作: ${action.title}")
            action.action.invoke()
            onResult(QuickActionResult.Success(action.title))
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 执行失败", e)
            onResult(QuickActionResult.Error(e.message ?: "执行失败"))
        }
    }
    
    // ==================== 快捷操作实现 ====================
    
    /**
     * 💧 快速记录喝水
     */
    private fun quickRecordWater() {
        healthManager.recordWater(1)
        LogManager.d(TAG, "💧 快速记录喝水")
    }
    
    /**
     * 💪 快速开始运动
     */
    private fun quickStartExercise() {
        try {
            healthManager.startExercise("quick_exercise")
            LogManager.d(TAG, "💪 快速开始运动 - 已启动记录")
        } catch (e: Exception) {
            LogManager.e(TAG, "启动运动记录失败", e)
        }
    }
    
    /**
     * 📊 快速查看健康报告
     */
    private fun quickHealthReport() {
        val report = healthManager.getHealthReport()
        LogManager.d(TAG, "📊 快速查看健康报告: ${report.overallScore}分")
    }
    
    /**
     * 📅 快速查看今日总结
     */
    private fun quickDailySummary() {
        val conversations = memorySystem.getTodayConversations()
        LogManager.d(TAG, "📅 今日对话: ${conversations.size}条")
    }
    
    /**
     * 🧠 快速查看记忆统计
     */
    private fun quickMemoryStats() {
        val stats = memorySystem.getStatistics()
        LogManager.d(TAG, "🧠 记忆统计: ${stats.totalMemories}条记忆")
    }
    
    /**
     * 🎯 快速获取推荐
     */
    private fun quickGetRecommendations() {
        val recommendations = recommender.generateRecommendations()
        LogManager.d(TAG, "🎯 获取推荐: ${recommendations.size}条")
    }
    
    /**
     * 🎵 快速音乐推荐
     */
    private fun quickMusicRecommend() {
        val profile = memorySystem.userProfile.value
        if (profile.preferences.musicLikes.isNotEmpty()) {
            val artist = profile.preferences.musicLikes.random()
            LogManager.d(TAG, "🎵 推荐: ${artist}的歌")
        }
    }
    
    /**
     * 🍽️ 快速美食推荐
     */
    private fun quickFoodRecommend() {
        val profile = memorySystem.userProfile.value
        if (profile.preferences.foodLikes.isNotEmpty()) {
            val food = profile.preferences.foodLikes.random()
            LogManager.d(TAG, "🍽️ 推荐: ${food}餐厅")
        }
    }
    
    /**
     * 🤖 快速切换主动对话
     */
    private fun quickToggleProactive() {
        try {
            val currentState = com.example.xihe.core.AutomationEngine.enableProactiveChat
            com.example.xihe.core.AutomationEngine.enableProactiveChat = !currentState
            val newStateText = if (!currentState) "已开启" else "已关闭"
            LogManager.d(TAG, "🤖 主动对话$newStateText")
        } catch (e: Exception) {
            LogManager.e(TAG, "切换主动对话失败", e)
        }
    }
    
    /**
     * 🗑️ 快速清空记忆
     */
    private fun quickClearMemory() {
        try {
            memorySystem.clearAllMemories()
            LogManager.d(TAG, "🗑️ 记忆已清空")
        } catch (e: Exception) {
            LogManager.e(TAG, "清空记忆失败", e)
        }
    }
}

/**
 * ⚡ 快捷操作
 */
data class QuickAction(
    val id: String,
    val icon: String,
    val title: String,
    val description: String,
    val category: QuickActionCategory,
    val action: () -> Unit,
    val requiresConfirmation: Boolean = false
)

/**
 * 📋 快捷操作分类
 */
enum class QuickActionCategory(val displayName: String, val icon: String) {
    HEALTH("健康管理", "💪"),
    PERSONAL("个人信息", "👤"),
    RECOMMEND("智能推荐", "🎯"),
    SETTINGS("设置", "⚙️")
}

/**
 * 📊 快捷操作结果
 */
sealed class QuickActionResult {
    data class Success(val message: String) : QuickActionResult()
    data class Error(val message: String) : QuickActionResult()
}

/**
 * 🎤 语音快捷指令
 */
object VoiceShortcuts {
    
    /**
     * 语音快捷词映射
     */
    val shortcuts = mapOf(
        // 唤醒
        "小羲" to "wake_up",
        "嘿羲和" to "wake_up",
        
        // 健康
        "喝水了" to "record_water",
        "运动了" to "record_exercise",
        "健康报告" to "health_report",
        
        // 查询
        "今天怎么样" to "daily_summary",
        "推荐一下" to "get_recommendations",
        "放首歌" to "play_music",
        
        // 控制
        "开启主动对话" to "enable_proactive",
        "关闭主动对话" to "disable_proactive",
        
        // 礼貌用语
        "谢谢" to "thanks",
        "拜拜" to "goodbye",
        "晚安" to "good_night"
    )
    
    /**
     * 匹配语音快捷词
     */
    fun matchShortcut(voiceInput: String): String? {
        val normalized = voiceInput.lowercase().trim()
        
        // 完全匹配
        shortcuts[normalized]?.let { return it }
        
        // 包含匹配
        for ((keyword, action) in shortcuts) {
            if (normalized.contains(keyword)) {
                return action
            }
        }
        
        return null
    }
    
    /**
     * 获取快捷词建议
     */
    fun getSuggestions(): List<String> {
        return shortcuts.keys.toList()
    }
}

/**
 * 🎨 快捷操作UI辅助
 */
object QuickActionsUI {
    
    /**
     * 获取分类颜色
     */
    fun getCategoryColor(category: QuickActionCategory): Long {
        return when (category) {
            QuickActionCategory.HEALTH -> 0xFF4CAF50      // 绿色
            QuickActionCategory.PERSONAL -> 0xFF2196F3    // 蓝色
            QuickActionCategory.RECOMMEND -> 0xFFFF9800   // 橙色
            QuickActionCategory.SETTINGS -> 0xFF9E9E9E    // 灰色
        }
    }
    
    /**
     * 获取操作图标
     */
    fun getActionIcon(actionId: String): String {
        return when (actionId) {
            "quick_water" -> "💧"
            "start_exercise" -> "💪"
            "health_report" -> "📊"
            "daily_summary" -> "📅"
            "memory_stats" -> "🧠"
            "get_recommendations" -> "🎯"
            "music_recommend" -> "🎵"
            "food_recommend" -> "🍽️"
            "toggle_proactive" -> "🤖"
            "clear_memory" -> "🗑️"
            else -> "⚡"
        }
    }
}
