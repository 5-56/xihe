package com.example.xihe.database

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

/**
 * 💾 用户数据库
 * 使用Room进行高效的本地数据存储
 */
@Database(
    entities = [
        UserPreferenceEntity::class,
        RelationshipEntity::class,
        HabitEntity::class,
        ImportantDateEntity::class,
        EmotionRecordEntity::class,
        HealthRecordEntity::class,
        ConversationEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class UserDatabase : RoomDatabase() {
    
    abstract fun preferenceDao(): PreferenceDao
    abstract fun relationshipDao(): RelationshipDao
    abstract fun habitDao(): HabitDao
    abstract fun importantDateDao(): ImportantDateDao
    abstract fun emotionDao(): EmotionDao
    abstract fun healthDao(): HealthDao
    abstract fun conversationDao(): ConversationDao
    
    companion object {
        @Volatile
        private var INSTANCE: UserDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
            }
        }
        
        fun getInstance(context: Context): UserDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    UserDatabase::class.java,
                    "xihe_user_database"
                )
                    .addMigrations(MIGRATION_1_2)
                    .fallbackToDestructiveMigrationOnDowngrade()
                    .build()
                
                INSTANCE = instance
                instance
            }
        }
    }
}

// ==================== 实体类 ====================

/**
 * 👤 用户偏好
 */
@Entity(tableName = "user_preferences")
data class UserPreferenceEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val type: String, // "music_like", "food_like", "music_dislike", "food_dislike"
    val value: String,
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * 👥 人际关系
 */
@Entity(tableName = "relationships")
data class RelationshipEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val type: String, // "FATHER", "MOTHER", "FRIEND", etc.
    val phone: String? = null,
    val notes: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * 🔄 生活习惯
 */
@Entity(tableName = "habits")
data class HabitEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val description: String,
    val frequency: String, // "DAILY", "WEEKLY", "MONTHLY"
    val time: String? = null,
    val dayOfWeek: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * 📅 重要日期
 */
@Entity(tableName = "important_dates")
data class ImportantDateEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val date: String,
    val type: String, // "BIRTHDAY", "ANNIVERSARY", etc.
    val reminder: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * 🎭 情绪记录
 */
@Entity(tableName = "emotion_records")
data class EmotionRecordEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val emotion: String, // "HAPPY", "SAD", "TIRED", etc.
    val intensity: Float,
    val confidence: Float,
    val timestamp: Long
)

/**
 * 💪 健康记录
 */
@Entity(tableName = "health_records")
data class HealthRecordEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val date: String, // "2024-12-05"
    val waterCount: Int = 0,
    val steps: Int = 0,
    val exerciseMinutes: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * 💬 对话记录
 */
@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userInput: String,
    val aiResponse: String,
    val timestamp: Long
)

// ==================== DAO ====================

/**
 * 👤 偏好DAO
 */
@Dao
interface PreferenceDao {
    @Query("SELECT * FROM user_preferences WHERE type = :type")
    suspend fun getPreferences(type: String): List<UserPreferenceEntity>
    
    @Query("SELECT * FROM user_preferences WHERE type = :type")
    fun getPreferencesFlow(type: String): Flow<List<UserPreferenceEntity>>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(preference: UserPreferenceEntity)
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(preferences: List<UserPreferenceEntity>)
    
    @Query("DELETE FROM user_preferences WHERE type = :type AND value = :value")
    suspend fun delete(type: String, value: String)
    
    @Query("DELETE FROM user_preferences")
    suspend fun deleteAll()
}

/**
 * 👥 关系DAO
 */
@Dao
interface RelationshipDao {
    @Query("SELECT * FROM relationships ORDER BY createdAt DESC")
    suspend fun getAll(): List<RelationshipEntity>
    
    @Query("SELECT * FROM relationships ORDER BY createdAt DESC")
    fun getAllFlow(): Flow<List<RelationshipEntity>>
    
    @Query("SELECT * FROM relationships WHERE type = :type")
    suspend fun getByType(type: String): List<RelationshipEntity>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(relationship: RelationshipEntity)
    
    @Delete
    suspend fun delete(relationship: RelationshipEntity)
    
    @Query("DELETE FROM relationships")
    suspend fun deleteAll()
}

/**
 * 🔄 习惯DAO
 */
@Dao
interface HabitDao {
    @Query("SELECT * FROM habits ORDER BY createdAt DESC")
    suspend fun getAll(): List<HabitEntity>
    
    @Query("SELECT * FROM habits ORDER BY createdAt DESC")
    fun getAllFlow(): Flow<List<HabitEntity>>
    
    @Query("SELECT * FROM habits WHERE frequency = :frequency")
    suspend fun getByFrequency(frequency: String): List<HabitEntity>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(habit: HabitEntity)
    
    @Delete
    suspend fun delete(habit: HabitEntity)
    
    @Query("DELETE FROM habits")
    suspend fun deleteAll()
}

/**
 * 📅 重要日期DAO
 */
@Dao
interface ImportantDateDao {
    @Query("SELECT * FROM important_dates ORDER BY createdAt DESC")
    suspend fun getAll(): List<ImportantDateEntity>
    
    @Query("SELECT * FROM important_dates ORDER BY createdAt DESC")
    fun getAllFlow(): Flow<List<ImportantDateEntity>>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(date: ImportantDateEntity)
    
    @Delete
    suspend fun delete(date: ImportantDateEntity)
    
    @Query("DELETE FROM important_dates")
    suspend fun deleteAll()
}

/**
 * 🎭 情绪DAO
 */
@Dao
interface EmotionDao {
    @Query("SELECT * FROM emotion_records ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecent(limit: Int = 100): List<EmotionRecordEntity>
    
    @Query("SELECT * FROM emotion_records WHERE timestamp >= :startTime ORDER BY timestamp DESC")
    suspend fun getRecordsSince(startTime: Long): List<EmotionRecordEntity>
    
    @Query("SELECT * FROM emotion_records WHERE timestamp >= :startTime AND timestamp <= :endTime")
    suspend fun getRecordsInRange(startTime: Long, endTime: Long): List<EmotionRecordEntity>
    
    @Insert
    suspend fun insert(record: EmotionRecordEntity)
    
    @Query("DELETE FROM emotion_records WHERE timestamp < :cutoffTime")
    suspend fun deleteOldRecords(cutoffTime: Long)
    
    @Query("DELETE FROM emotion_records")
    suspend fun deleteAll()
}

/**
 * 💪 健康DAO
 */
@Dao
interface HealthDao {
    @Query("SELECT * FROM health_records WHERE date = :date LIMIT 1")
    suspend fun getByDate(date: String): HealthRecordEntity?
    
    @Query("SELECT * FROM health_records ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecent(limit: Int = 30): List<HealthRecordEntity>
    
    @Query("SELECT * FROM health_records ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentFlow(limit: Int = 30): Flow<List<HealthRecordEntity>>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(record: HealthRecordEntity)
    
    @Update
    suspend fun update(record: HealthRecordEntity)
    
    @Query("DELETE FROM health_records WHERE timestamp < :cutoffTime")
    suspend fun deleteOldRecords(cutoffTime: Long)
    
    @Query("DELETE FROM health_records")
    suspend fun deleteAll()
}

/**
 * 💬 对话DAO
 */
@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversations ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecent(limit: Int = 100): List<ConversationEntity>
    
    @Query("SELECT * FROM conversations WHERE timestamp >= :startTime ORDER BY timestamp DESC")
    suspend fun getSince(startTime: Long): List<ConversationEntity>
    
    @Query("SELECT COUNT(*) FROM conversations WHERE timestamp >= :startTime")
    suspend fun getCountSince(startTime: Long): Int
    
    @Insert
    suspend fun insert(conversation: ConversationEntity)
    
    @Query("DELETE FROM conversations WHERE timestamp < :cutoffTime")
    suspend fun deleteOldRecords(cutoffTime: Long)
    
    @Query("DELETE FROM conversations")
    suspend fun deleteAll()
}
