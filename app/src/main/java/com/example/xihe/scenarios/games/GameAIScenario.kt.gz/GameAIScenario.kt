package com.example.xihe.scenarios.games

import android.content.Context
import android.graphics.Bitmap
import com.example.xihe.core.AutomationEngine
import android.util.Base64
import com.example.xihe.utils.LogManager
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.core.LLMClient
import com.example.xihe.ocr.OCRManager
import com.example.xihe.scenarios.ScenarioBase
import com.example.xihe.scenarios.ScenarioConfig
import com.example.xihe.scenarios.ScenarioResult
import kotlinx.coroutines.delay
import java.io.ByteArrayOutputStream
import kotlin.random.Random

/**
 * 🎮 通用游戏AI场景
 * 
 * 使用视觉AI分析游戏画面并做出决策
 * 
 * 支持：
 * - 回合制游戏（RPG、卡牌等）
 * - 简单操作的网游（自动任务、日常）
 * - 模拟经营类游戏
 * 
 * ⚠️ 警告：
 * - 不适用于实时对战类游戏
 * - 在线游戏使用可能违反用户协议
 * - 有反作弊系统的游戏会被检测
 */
class GameAIScenario(context: Context) : ScenarioBase(context, "通用游戏AI") {
    
    companion object {
        private const val TAG = "GameAIScenario"
        
        // 游戏类型
        enum class GameType {
            TURN_BASED,     // 回合制
            IDLE,           // 放置/挂机
            SIMULATION,     // 模拟经营
            CARD,           // 卡牌
            MMORPG,         // 大型网游
            ACTION,         // 动作游戏
            PUZZLE,         // 解谜
            RHYTHM,         // 音游
            MATCH3,         // 消消乐
            TOWER_DEFENSE,  // 塔防
            GACHA,          // 抽卡游戏
            CUSTOM          // 自定义
        }
        
        // 常见游戏包名映射
        val KNOWN_GAMES = mapOf(
            // 回合制
            "阴阳师" to Pair("com.netease.onmyoji", GameType.TURN_BASED),
            "梦幻西游" to Pair("com.netease.my", GameType.TURN_BASED),
            "神武" to Pair("com.duoyi.sw4.mi", GameType.TURN_BASED),
            // 卡牌
            "炉石传说" to Pair("com.blizzard.wtcg.hearthstone", GameType.CARD),
            "皇室战争" to Pair("com.supercell.clashroyale", GameType.CARD),
            // MMORPG
            "原神" to Pair("com.miHoYo.Yuanshen", GameType.MMORPG),
            "天涯明月刀" to Pair("com.tencent.tmgp.wuxia", GameType.MMORPG),
            // 放置
            "最强蜗牛" to Pair("com.qingcigame.snail", GameType.IDLE),
            "一念逍遥" to Pair("com.rayneo.yinianxy", GameType.IDLE),
            // 模拟经营
            "开心消消乐" to Pair("com.happyelements.AndroidAnimal", GameType.MATCH3),
            "明日方舟" to Pair("com.hypergryph.arknights", GameType.TOWER_DEFENSE)
        )
    }
    
    /**
     * ⚙️ 通用游戏AI配置
     */
    data class GameAIConfig(
        val gamePackage: String? = null,        // 游戏包名
        val gameName: String = "",              // 游戏名称
        val gameType: GameType = GameType.CUSTOM,
        val objective: String = "",             // 目标描述
        val maxSteps: Int = 1000,               // 最大步数
        val useVisionAI: Boolean = true,        // 是否使用视觉AI
        val actionDelay: Long = 1000L,          // 动作间隔
        val customPrompt: String? = null,       // 自定义提示词
        val safeMode: Boolean = true,           // 安全模式（避免危险操作）
        val macros: List<GameMacro> = emptyList() // 预设宏
    ) : ScenarioConfig(maxIterations = maxSteps)
    
    /**
     * 🎯 游戏宏
     */
    data class GameMacro(
        val name: String,
        val trigger: String,            // 触发条件（OCR文字）
        val actions: List<MacroAction>
    )
    
    sealed class MacroAction {
        data class Tap(val x: Float, val y: Float, val relative: Boolean = true) : MacroAction()
        data class TapText(val text: String) : MacroAction()
        data class Swipe(val startX: Float, val startY: Float, val endX: Float, val endY: Float) : MacroAction()
        data class Wait(val ms: Long) : MacroAction()
        object Back : MacroAction()
    }
    
    private val ocrManager by lazy { OCRManager.getInstance(context) }
    private val tutorialLearner by lazy { GameTutorialLearner.getInstance(context) }
    private var stepCount = 0
    private var currentTutorial: GameTutorialLearner.TutorialInfo? = null
    private var tutorialStep = 0
    private var learningAttempted = false
    
    /**
     * 🔍 检测用户意图
     */
    fun detectIntent(userInput: String): GameAIConfig? {
        val input = userInput.lowercase()
        
        // 检测是否是通用游戏AI意图
        val isGameAIIntent = input.contains(Regex("(游戏|网游|mmo|rpg).*(自动|ai|帮我|挂机)")) ||
                input.contains(Regex("(自动|ai|帮我).*(游戏|网游|刷|打)")) ||
                input.contains("自动打怪") || input.contains("自动做任务") ||
                input.contains("自动日常")
        
        if (!isGameAIIntent) return null
        
        // 提取目标
        val objective = when {
            input.contains("打怪") || input.contains("刷怪") -> "自动寻找并攻击怪物"
            input.contains("任务") || input.contains("主线") -> "自动完成任务"
            input.contains("日常") -> "完成日常活动"
            input.contains("副本") || input.contains("刷本") -> "自动完成副本"
            input.contains("升级") -> "自动升级角色"
            else -> "按照游戏提示自动操作"
        }
        
        // 检测游戏类型
        val gameType = when {
            input.contains("mmo") || input.contains("网游") -> GameType.MMORPG
            input.contains("回合") || input.contains("rpg") -> GameType.TURN_BASED
            input.contains("卡牌") -> GameType.CARD
            input.contains("放置") || input.contains("挂机") -> GameType.IDLE
            else -> GameType.CUSTOM
        }
        
        LogManager.d(TAG, "✅ 检测到通用游戏AI意图: 类型=$gameType, 目标=$objective")
        
        return GameAIConfig(
            gameType = gameType,
            objective = objective
        )
    }
    
    /**
     * 🎯 执行游戏AI
     */
    override suspend fun execute(config: ScenarioConfig): ScenarioResult {
        val gameConfig = config as? GameAIConfig
            ?: return ScenarioResult.Failure("配置类型错误")
        
        val service = CoreAccessibilityService.instance
            ?: return ScenarioResult.Failure("无障碍服务未启动")
        
        // 启动游戏
        if (!gameConfig.gamePackage.isNullOrEmpty()) {
            updateProgress(message = "正在启动游戏... 🎮")
            service.launchApp(gameConfig.gamePackage)
            delay(5000)
        }
        
        stepCount = 0
        var lastAction = ""
        var stuckCount = 0
        currentTutorial = null
        tutorialStep = 0
        learningAttempted = false
        
        updateProgress(message = "游戏AI启动，目标: ${gameConfig.objective} 🤖")
        
        // 尝试加载或学习教程
        if (gameConfig.gameName.isNotEmpty() && gameConfig.objective.isNotEmpty()) {
            updateProgress(message = "🔍 搜索 ${gameConfig.gameName} 教程中...")
            currentTutorial = tutorialLearner.learnGameTutorial(gameConfig.gameName, gameConfig.objective)
            if (currentTutorial != null) {
                updateProgress(message = "📚 已学习教程，共 ${currentTutorial!!.steps.size} 个步骤")
                log("教程提示: ${currentTutorial!!.tips.joinToString("; ")}")
            }
        }
        
        // 主循环
        while (stepCount < gameConfig.maxSteps) {
            if (shouldStop()) {
                return ScenarioResult.Stopped(
                    message = "游戏AI已停止，执行了 $stepCount 步",
                    completedSteps = stepCount,
                    totalSteps = gameConfig.maxSteps
                )
            }
            
            stepCount++
            
            // 1. 截图
            val screenshot = service.takeScreenshotAsync()
            if (screenshot == null) {
                delay(500)
                continue
            }
            
            // 2. 检查预设宏触发
            val triggeredMacro = checkMacroTriggers(screenshot, gameConfig.macros)
            if (triggeredMacro != null) {
                log("🎯 触发宏: ${triggeredMacro.name}")
                executeMacro(service, triggeredMacro, screenshot)
                continue
            }
            
            // 3. OCR分析屏幕
            val ocrResult = ocrManager.recognizeText(screenshot)
            val screenText = ocrResult.textBlocks.joinToString(" ") { it.text }
            
            // 4. 优先使用教程指导
            var action: String
            val tutorialAction = handleWithTutorial(service, screenText)
            if (tutorialAction != null) {
                action = tutorialAction
            } else {
                // 5. 根据游戏类型选择策略
                action = when (gameConfig.gameType) {
                    GameType.TURN_BASED -> handleTurnBasedGame(service, screenshot, screenText, gameConfig)
                    GameType.IDLE -> handleIdleGame(service, screenshot, screenText, gameConfig)
                    GameType.MMORPG -> handleMMORPG(service, screenshot, screenText, gameConfig)
                    GameType.CARD -> handleCardGame(service, screenshot, screenText, gameConfig)
                    GameType.SIMULATION -> handleSimulationGame(service, screenshot, screenText, gameConfig)
                    GameType.MATCH3 -> handleMatch3Game(service, screenshot, screenText, gameConfig)
                    GameType.TOWER_DEFENSE -> handleTowerDefenseGame(service, screenshot, screenText, gameConfig)
                    GameType.GACHA -> handleGachaGame(service, screenshot, screenText, gameConfig)
                    GameType.PUZZLE -> handlePuzzleGame(service, screenshot, screenText, gameConfig)
                    else -> handleGenericGame(service, screenshot, screenText, gameConfig)
                }
            }
            
            // 5. 检测是否卡住
            if (action == lastAction) {
                stuckCount++
                if (stuckCount > 5) {
                    log("⚠️ 检测到可能卡住，尝试恢复...")
                    handleStuck(service)
                    stuckCount = 0
                }
            } else {
                stuckCount = 0
                lastAction = action
            }
            
            updateProgress(
                currentStep = stepCount,
                message = "第 $stepCount 步: $action",
                successCount = stepCount
            )
            
            // 随机延迟
            delay(gameConfig.actionDelay + Random.nextLong(-200, 200))
        }
        
        return ScenarioResult.Success(
            message = "游戏AI完成，共执行 $stepCount 步",
            completedSteps = stepCount,
            totalSteps = gameConfig.maxSteps
        )
    }
    
    /**
     * 📚 根据教程执行操作
     */
    private suspend fun handleWithTutorial(
        service: CoreAccessibilityService,
        screenText: String
    ): String? {
        val tutorial = currentTutorial ?: return null
        
        // 检查是否有待执行的教程步骤
        if (tutorialStep < tutorial.steps.size) {
            val step = tutorial.steps[tutorialStep]
            
            // 检查目标是否可见
            val targetVisible = step.targetText?.let { target ->
                screenText.contains(target, ignoreCase = true)
            } ?: true
            
            if (targetVisible) {
                // 执行教程步骤
                val success = when {
                    step.targetText != null -> {
                        service.findAndClick(step.targetText)
                    }
                    step.targetPosition != null -> {
                        // 根据位置描述点击
                        val (x, y) = parsePositionDescription(step.targetPosition, service.getScreenSize())
                        service.tapAsync(x, y)
                        true
                    }
                    else -> false
                }
                
                if (success) {
                    tutorialStep++
                    delay(step.waitAfter.toLong())
                    return "📖 教程步骤 $tutorialStep: ${step.action}"
                }
            }
        }
        
        // 尝试使用教程中的按钮关键词
        val matchingButton = tutorialLearner.findMatchingButton(tutorial, screenText)
        if (matchingButton != null) {
            if (service.findAndClick(matchingButton)) {
                return "📖 教程按钮: $matchingButton"
            }
        }
        
        return null
    }
    
    /**
     * 📍 解析位置描述为坐标
     */
    private fun parsePositionDescription(
        description: String,
        screenSize: Pair<Int, Int>
    ): Pair<Float, Float> {
        val (w, h) = screenSize
        
        // 解析位置描述
        val x = when {
            description.contains("左") -> w * 0.2f
            description.contains("右") -> w * 0.8f
            description.contains("中") || description.contains("中间") -> w * 0.5f
            else -> w * 0.5f
        }
        
        val y = when {
            description.contains("上") || description.contains("顶") -> h * 0.2f
            description.contains("下") || description.contains("底") -> h * 0.8f
            description.contains("中") || description.contains("中间") -> h * 0.5f
            else -> h * 0.5f
        }
        
        return x to y
    }
    
    /**
     * 🔍 检查宏触发
     */
    private suspend fun checkMacroTriggers(screenshot: Bitmap, macros: List<GameMacro>): GameMacro? {
        if (macros.isEmpty()) return null
        
        val ocrResult = ocrManager.recognizeText(screenshot)
        val screenText = ocrResult.textBlocks.joinToString(" ") { it.text }
        
        for (macro in macros) {
            if (screenText.contains(macro.trigger, ignoreCase = true)) {
                return macro
            }
        }
        
        return null
    }
    
    /**
     * 🎬 执行宏
     */
    private suspend fun executeMacro(
        service: CoreAccessibilityService,
        macro: GameMacro,
        screenshot: Bitmap
    ) {
        val (screenWidth, screenHeight) = service.getScreenSize()
        
        for (action in macro.actions) {
            when (action) {
                is MacroAction.Tap -> {
                    val x = if (action.relative) action.x * screenWidth else action.x
                    val y = if (action.relative) action.y * screenHeight else action.y
                    service.tapAsync(x, y)
                }
                is MacroAction.TapText -> {
                    service.findAndClick(action.text)
                }
                is MacroAction.Swipe -> {
                    val startX = action.startX * screenWidth
                    val startY = action.startY * screenHeight
                    val endX = action.endX * screenWidth
                    val endY = action.endY * screenHeight
                    service.swipeAsync(startX, startY, endX, endY, 300)
                }
                is MacroAction.Wait -> {
                    delay(action.ms)
                }
                MacroAction.Back -> {
                    service.performGlobalBack()
                }
            }
            delay(200)
        }
    }
    
    /**
     * ⚔️ 处理回合制游戏
     */
    private suspend fun handleTurnBasedGame(
        service: CoreAccessibilityService,
        screenshot: Bitmap,
        screenText: String,
        config: GameAIConfig
    ): String {
        // 常见回合制游戏按钮
        val actionButtons = listOf(
            "攻击", "普攻", "技能", "战斗", "开始战斗",
            "自动", "自动战斗", "跳过", "确定", "继续",
            "下一步", "完成", "领取", "关闭"
        )
        
        // 优先点击自动战斗
        if (screenText.contains("自动") && !screenText.contains("已开启")) {
            if (service.findAndClick("自动")) {
                return "开启自动战斗"
            }
        }
        
        // 尝试点击战斗相关按钮
        for (button in actionButtons) {
            if (screenText.contains(button, ignoreCase = true)) {
                if (service.findAndClick(button)) {
                    return "点击: $button"
                }
            }
        }
        
        // 没找到按钮，点击屏幕中心继续
        val (w, h) = service.getScreenSize()
        service.tapAsync(w / 2f, h / 2f)
        return "点击屏幕继续"
    }
    
    /**
     * 💤 处理放置/挂机游戏
     */
    private suspend fun handleIdleGame(
        service: CoreAccessibilityService,
        screenshot: Bitmap,
        screenText: String,
        config: GameAIConfig
    ): String {
        // 挂机游戏常见操作
        val collectButtons = listOf(
            "领取", "收集", "领奖", "一键领取", "全部领取",
            "升级", "强化", "购买", "抽奖", "关闭", "确定"
        )
        
        // 检查并点击可领取的奖励
        for (button in collectButtons) {
            if (screenText.contains(button, ignoreCase = true)) {
                if (service.findAndClick(button)) {
                    return "领取/操作: $button"
                }
            }
        }
        
        // 检测红点（有新内容）
        // 简化处理：随机点击屏幕边缘的图标区域
        if (Random.nextFloat() < 0.1f) {
            val (w, h) = service.getScreenSize()
            val x = Random.nextFloat() * w
            val y = h * 0.9f // 底部菜单区域
            service.tapAsync(x, y)
            return "检查底部菜单"
        }
        
        return "等待中..."
    }
    
    /**
     * 🌍 处理大型网游
     */
    private suspend fun handleMMORPG(
        service: CoreAccessibilityService,
        screenshot: Bitmap,
        screenText: String,
        config: GameAIConfig
    ): String {
        // MMORPG 常见操作
        val autoButtons = listOf(
            "自动", "自动战斗", "自动寻路", "挂机", "自动任务",
            "一键扫荡", "扫荡", "快速战斗"
        )
        
        val questButtons = listOf(
            "接受", "领取任务", "前往", "传送", "对话", "完成",
            "提交", "下一步", "跳过", "继续"
        )
        
        val commonButtons = listOf(
            "确定", "确认", "关闭", "取消", "返回", "是", "好的"
        )
        
        // 1. 优先开启自动功能
        for (button in autoButtons) {
            if (screenText.contains(button, ignoreCase = true)) {
                if (service.findAndClick(button)) {
                    return "开启: $button"
                }
            }
        }
        
        // 2. 处理任务相关
        for (button in questButtons) {
            if (screenText.contains(button, ignoreCase = true)) {
                if (service.findAndClick(button)) {
                    return "任务操作: $button"
                }
            }
        }
        
        // 3. 处理弹窗
        for (button in commonButtons) {
            if (screenText.contains(button, ignoreCase = true)) {
                if (service.findAndClick(button)) {
                    return "关闭弹窗: $button"
                }
            }
        }
        
        // 4. 点击任务追踪区域（通常在右侧）
        if (Random.nextFloat() < 0.2f) {
            val (w, h) = service.getScreenSize()
            service.tapAsync(w * 0.85f, h * 0.3f) // 右侧任务区域
            return "点击任务追踪"
        }
        
        return "巡逻中..."
    }
    
    /**
     * 🃏 处理卡牌游戏
     */
    private suspend fun handleCardGame(
        service: CoreAccessibilityService,
        screenshot: Bitmap,
        screenText: String,
        config: GameAIConfig
    ): String {
        val battleButtons = listOf(
            "战斗", "挑战", "开始", "出战", "自动", "跳过"
        )
        
        val endButtons = listOf(
            "确定", "继续", "再来一次", "返回", "完成", "领取"
        )
        
        // 战斗操作
        for (button in battleButtons) {
            if (screenText.contains(button, ignoreCase = true)) {
                if (service.findAndClick(button)) {
                    return "战斗: $button"
                }
            }
        }
        
        // 结算操作
        for (button in endButtons) {
            if (screenText.contains(button, ignoreCase = true)) {
                if (service.findAndClick(button)) {
                    return "结算: $button"
                }
            }
        }
        
        // 随机点击中间（选卡/确认）
        val (w, h) = service.getScreenSize()
        service.tapAsync(w / 2f, h / 2f)
        return "点击确认"
    }
    
    /**
     * 🏠 处理模拟经营游戏
     */
    private suspend fun handleSimulationGame(
        service: CoreAccessibilityService,
        screenshot: Bitmap,
        screenText: String,
        config: GameAIConfig
    ): String {
        val collectButtons = listOf(
            "收获", "收集", "领取", "完成", "加速", "升级",
            "建造", "生产", "确定"
        )
        
        for (button in collectButtons) {
            if (screenText.contains(button, ignoreCase = true)) {
                if (service.findAndClick(button)) {
                    return "操作: $button"
                }
            }
        }
        
        // 随机点击屏幕（收集资源）
        val (w, h) = service.getScreenSize()
        val x = w * (0.2f + Random.nextFloat() * 0.6f)
        val y = h * (0.3f + Random.nextFloat() * 0.4f)
        service.tapAsync(x, y)
        return "收集资源"
    }
    
    /**
     * 🧩 处理消消乐游戏
     */
    private suspend fun handleMatch3Game(
        service: CoreAccessibilityService,
        screenshot: Bitmap,
        screenText: String,
        config: GameAIConfig
    ): String {
        val actionButtons = listOf(
            "开始", "继续", "重玩", "下一关", "领取", "确定", "关闭"
        )
        
        // 检测弹窗按钮
        for (button in actionButtons) {
            if (screenText.contains(button, ignoreCase = true)) {
                if (service.findAndClick(button)) {
                    return "点击: $button"
                }
            }
        }
        
        // 消消乐核心：随机交换相邻格子
        val (w, h) = service.getScreenSize()
        val gridStartX = w * 0.1f
        val gridEndX = w * 0.9f
        val gridStartY = h * 0.25f
        val gridEndY = h * 0.75f
        
        val cellWidth = (gridEndX - gridStartX) / 7  // 假设7列
        val cellHeight = (gridEndY - gridStartY) / 7  // 假设7行
        
        // 随机选择一个位置并滑动
        val col = Random.nextInt(6)
        val row = Random.nextInt(6)
        val startX = gridStartX + col * cellWidth + cellWidth / 2
        val startY = gridStartY + row * cellHeight + cellHeight / 2
        
        // 随机方向滑动
        val direction = Random.nextInt(4)
        val (endX, endY) = when (direction) {
            0 -> startX + cellWidth to startY      // 右
            1 -> startX - cellWidth to startY      // 左
            2 -> startX to startY + cellHeight     // 下
            else -> startX to startY - cellHeight  // 上
        }
        
        service.swipeAsync(startX, startY, endX, endY, 200)
        return "消除尝试: ($col,$row) 方向$direction"
    }
    
    /**
     * 🏰 处理塔防游戏
     */
    private suspend fun handleTowerDefenseGame(
        service: CoreAccessibilityService,
        screenshot: Bitmap,
        screenText: String,
        config: GameAIConfig
    ): String {
        val actionButtons = listOf(
            "开始", "开始行动", "自动", "代理指挥", "2x", "加速",
            "确定", "完成", "继续", "下一关", "领取", "关闭"
        )
        
        // 优先开启自动/代理
        if (screenText.contains("代理") || screenText.contains("自动")) {
            if (service.findAndClick("代理指挥") || service.findAndClick("自动")) {
                return "开启代理指挥"
            }
        }
        
        // 检测按钮
        for (button in actionButtons) {
            if (screenText.contains(button, ignoreCase = true)) {
                if (service.findAndClick(button)) {
                    return "点击: $button"
                }
            }
        }
        
        // 默认等待（塔防游戏主要是等待）
        return "等待战斗..."
    }
    
    /**
     * 🎰 处理抽卡游戏
     */
    private suspend fun handleGachaGame(
        service: CoreAccessibilityService,
        screenshot: Bitmap,
        screenText: String,
        config: GameAIConfig
    ): String {
        val collectButtons = listOf(
            "领取", "一键领取", "全部领取", "确定", "确认", "关闭",
            "跳过", "继续", "完成"
        )
        
        val gachaButtons = listOf(
            "十连", "单抽", "抽取", "召唤", "祈愿"
        )
        
        // 优先领取奖励
        for (button in collectButtons) {
            if (screenText.contains(button, ignoreCase = true)) {
                if (service.findAndClick(button)) {
                    return "领取: $button"
                }
            }
        }
        
        // 抽卡操作（如果配置允许）
        if (config.objective.contains("抽卡") || config.objective.contains("召唤")) {
            for (button in gachaButtons) {
                if (screenText.contains(button, ignoreCase = true)) {
                    if (service.findAndClick(button)) {
                        return "抽卡: $button"
                    }
                }
            }
        }
        
        // 点击屏幕继续
        val (w, h) = service.getScreenSize()
        service.tapAsync(w / 2f, h / 2f)
        return "点击继续"
    }
    
    /**
     * 🧠 处理解谜游戏
     */
    private suspend fun handlePuzzleGame(
        service: CoreAccessibilityService,
        screenshot: Bitmap,
        screenText: String,
        config: GameAIConfig
    ): String {
        val actionButtons = listOf(
            "提示", "跳过", "确定", "继续", "下一关", "重玩", "关闭"
        )
        
        // 检测按钮
        for (button in actionButtons) {
            if (screenText.contains(button, ignoreCase = true)) {
                if (service.findAndClick(button)) {
                    return "点击: $button"
                }
            }
        }
        
        // 解谜游戏需要视觉AI分析
        if (config.useVisionAI) {
            return handleWithVisionAI(service, screenshot, config)
        }
        
        // 随机点击尝试
        val (w, h) = service.getScreenSize()
        val x = w * (0.2f + Random.nextFloat() * 0.6f)
        val y = h * (0.3f + Random.nextFloat() * 0.4f)
        service.tapAsync(x, y)
        return "尝试点击"
    }
    
    /**
     * 🎲 处理通用游戏
     */
    private suspend fun handleGenericGame(
        service: CoreAccessibilityService,
        screenshot: Bitmap,
        screenText: String,
        config: GameAIConfig
    ): String {
        // 通用按钮优先级
        val priorityButtons = listOf(
            // 高优先级 - 确认/继续
            "确定", "确认", "OK", "是", "好", "继续", "下一步",
            // 中优先级 - 操作
            "开始", "战斗", "挑战", "领取", "完成",
            // 低优先级 - 关闭
            "关闭", "取消", "返回", "跳过"
        )
        
        for (button in priorityButtons) {
            if (screenText.contains(button, ignoreCase = true)) {
                if (service.findAndClick(button)) {
                    return "点击: $button"
                }
            }
        }
        
        // 使用视觉AI（如果启用且有自定义目标）
        if (config.useVisionAI && config.objective.isNotEmpty()) {
            return handleWithVisionAI(service, screenshot, config)
        }
        
        // 默认：点击屏幕中心
        val (w, h) = service.getScreenSize()
        service.tapAsync(w / 2f, h / 2f)
        return "点击屏幕"
    }
    
    /**
     * 🤖 使用视觉AI处理
     */
    private suspend fun handleWithVisionAI(
        service: CoreAccessibilityService,
        screenshot: Bitmap,
        config: GameAIConfig
    ): String {
        // 构建提示词
        val prompt = config.customPrompt ?: """
            你是一个游戏AI助手。当前目标是：${config.objective}
            
            请分析这个游戏画面，告诉我应该执行什么操作。
            回复格式：
            - 如果需要点击某个按钮，回复：TAP 按钮文字
            - 如果需要点击某个坐标（相对坐标0-1），回复：TAP_XY 0.5 0.5
            - 如果需要滑动，回复：SWIPE 起始X 起始Y 结束X 结束Y
            - 如果需要等待，回复：WAIT
            - 如果任务已完成，回复：DONE
            
            只回复一个操作，不要解释。
        """.trimIndent()
        
        // 调用视觉AI
        try {
            // 将 Bitmap 转换为 Base64
            val imageBase64 = bitmapToBase64(screenshot)
            val llmClient = LLMClient(AutomationEngine.baseUrl, AutomationEngine.apiKey, AutomationEngine.modelName)
            val response = llmClient.chatCompletionWithImage(prompt, imageBase64, usePersonality = false)
            
            // 解析响应
            val action = response.trim().uppercase()
            val (w, h) = service.getScreenSize()
            
            when {
                action.startsWith("TAP_XY") -> {
                    val parts = action.split(" ")
                    if (parts.size >= 3) {
                        val x = parts[1].toFloatOrNull() ?: 0.5f
                        val y = parts[2].toFloatOrNull() ?: 0.5f
                        service.tapAsync(x * w, y * h)
                        return "AI点击: ($x, $y)"
                    }
                }
                action.startsWith("TAP") -> {
                    val text = action.removePrefix("TAP").trim()
                    if (text.isNotEmpty() && service.findAndClick(text)) {
                        return "AI点击: $text"
                    }
                }
                action.startsWith("SWIPE") -> {
                    val parts = action.split(" ")
                    if (parts.size >= 5) {
                        val startX = parts[1].toFloatOrNull() ?: 0.5f
                        val startY = parts[2].toFloatOrNull() ?: 0.5f
                        val endX = parts[3].toFloatOrNull() ?: 0.5f
                        val endY = parts[4].toFloatOrNull() ?: 0.5f
                        service.swipeAsync(startX * w, startY * h, endX * w, endY * h, 300)
                        return "AI滑动"
                    }
                }
                action == "WAIT" -> {
                    delay(2000)
                    return "AI等待"
                }
                action == "DONE" -> {
                    return "AI认为任务完成"
                }
            }
        } catch (e: Exception) {
            log("视觉AI调用失败: ${e.message}")
        }
        
        return "AI分析中..."
    }
    
    /**
     * 🔧 处理卡住情况
     */
    private suspend fun handleStuck(service: CoreAccessibilityService) {
        // 尝试多种恢复方法
        service.performGlobalBack()
        delay(500)
        
        val (w, h) = service.getScreenSize()
        service.tapAsync(w / 2f, h / 2f)
        delay(500)
        
        service.findAndClick("确定")
        delay(500)
        
        service.findAndClick("关闭")
        delay(500)
        
        service.findAndClick("取消")
        delay(500)
        
        service.swipeAsync(w / 2f, h * 0.7f, w / 2f, h * 0.3f, 300)
        delay(500)
    }
    
    /**
     * 🖼️ Bitmap 转 Base64
     */
    private fun bitmapToBase64(bitmap: Bitmap): String {
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
        val byteArray = outputStream.toByteArray()
        return Base64.encodeToString(byteArray, Base64.NO_WRAP)
    }
}
