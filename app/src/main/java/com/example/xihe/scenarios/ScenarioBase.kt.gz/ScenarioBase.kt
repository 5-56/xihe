package com.example.xihe.scenarios

import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.CoreAccessibilityService
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * 🎯 场景执行基础框架
 * 
 * 提供统一的场景生命周期管理、状态监控、安全护栏
 * 所有自动化场景（刷视频/填数据/游戏等）都继承此基类
 */
abstract class ScenarioBase(
    protected val context: Context,
    protected val scenarioName: String
) {
    companion object {
        private const val TAG = "ScenarioBase"
    }
    
    // ==================== 状态管理 ====================
    
    protected val _state = MutableStateFlow(ScenarioState.IDLE)
    val state: StateFlow<ScenarioState> = _state
    
    protected val _progress = MutableStateFlow(ScenarioProgress())
    val progress: StateFlow<ScenarioProgress> = _progress
    
    // 是否请求停止
    @Volatile
    protected var stopRequested = false
    
    // ==================== 生命周期 ====================
    
    /**
     * 🚀 启动场景
     */
    suspend fun start(config: ScenarioConfig): ScenarioResult {
        if (_state.value == ScenarioState.RUNNING) {
            LogManager.w(TAG, "⚠️ 场景 $scenarioName 已在运行中")
            return ScenarioResult.Failure("场景已在运行中")
        }
        
        stopRequested = false
        _state.value = ScenarioState.RUNNING
        _progress.value = ScenarioProgress(totalSteps = config.maxIterations)
        
        LogManager.i(TAG, "🚀 启动场景: $scenarioName")
        
        return try {
            // 前置检查
            val preCheckResult = preCheck()
            if (!preCheckResult.success) {
                _state.value = ScenarioState.ERROR
                return preCheckResult
            }
            
            // 执行主逻辑
            val result = execute(config)
            
            _state.value = if (result.isSuccess()) ScenarioState.COMPLETED else ScenarioState.ERROR
            result
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 场景执行异常: ${e.message}", e)
            _state.value = ScenarioState.ERROR
            ScenarioResult.Failure("执行异常: ${e.message}")
        }
    }
    
    /**
     * 🛑 请求停止
     */
    fun requestStop() {
        LogManager.i(TAG, "🛑 请求停止场景: $scenarioName")
        stopRequested = true
        _state.value = ScenarioState.STOPPING
    }
    
    /**
     * 🔄 重置状态
     */
    fun reset() {
        stopRequested = false
        _state.value = ScenarioState.IDLE
        _progress.value = ScenarioProgress()
    }
    
    // ==================== 抽象方法（子类实现） ====================
    
    /**
     * ✅ 前置检查（权限、服务状态等）
     */
    protected open suspend fun preCheck(): ScenarioResult {
        val service = CoreAccessibilityService.instance
        if (service == null) {
            return ScenarioResult.Failure("❌ 无障碍服务未启动，请先开启")
        }
        return ScenarioResult.Success("前置检查通过")
    }
    
    /**
     * 🎯 执行主逻辑（子类必须实现）
     */
    protected abstract suspend fun execute(config: ScenarioConfig): ScenarioResult
    
    // ==================== 工具方法 ====================
    
    /**
     * 📊 更新进度
     */
    protected fun updateProgress(
        currentStep: Int? = null,
        message: String? = null,
        successCount: Int? = null,
        failCount: Int? = null
    ) {
        val current = _progress.value
        _progress.value = current.copy(
            currentStep = currentStep ?: current.currentStep,
            message = message ?: current.message,
            successCount = successCount ?: current.successCount,
            failCount = failCount ?: current.failCount
        )
    }
    
    /**
     * ⏳ 带随机扰动的等待（模拟人类行为）
     */
    protected suspend fun humanDelay(baseMs: Long, randomRange: Long = 500L) {
        val actualDelay = baseMs + (Math.random() * randomRange).toLong()
        delay(actualDelay)
    }
    
    /**
     * 🔍 检查是否应该停止
     */
    protected fun shouldStop(): Boolean = stopRequested
    
    /**
     * 📝 日志记录（子类使用）
     */
    protected fun log(message: String) {
        LogManager.d(TAG, "[$scenarioName] $message")
    }
    
    /**
     * 🔍 高效查找按钮（带缓存和系统优化）
     */
    protected fun findButtonOptimized(
        keywords: List<String>,
        root: android.view.accessibility.AccessibilityNodeInfo? = null
    ): android.view.accessibility.AccessibilityNodeInfo? {
        val rootNode = root ?: CoreAccessibilityService.instance?.rootInActiveWindow ?: return null
        
        // 🚀 尝试使用系统 API 加速
        for (keyword in keywords) {
            val nodes = rootNode.findAccessibilityNodeInfosByText(keyword)
            if (!nodes.isNullOrEmpty()) {
                for (node in nodes) {
                    if (node.isClickable && node.isVisibleToUser) return node
                    // 向上查找可点击的父节点
                    var parent = node.parent
                    while (parent != null) {
                        if (parent.isClickable) return parent
                        parent = parent.parent
                    }
                }
            }
        }
        
        // 递归保底查找
        return findNodeRecursive(rootNode, keywords)
    }

    private fun findNodeRecursive(
        node: android.view.accessibility.AccessibilityNodeInfo,
        keywords: List<String>
    ): android.view.accessibility.AccessibilityNodeInfo? {
        val text = node.text?.toString()?.lowercase() ?: ""
        val desc = node.contentDescription?.toString()?.lowercase() ?: ""
        
        if (node.isClickable && node.isVisibleToUser && keywords.any { text.contains(it, ignoreCase = true) || desc.contains(it, ignoreCase = true) }) {
            return node
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findNodeRecursive(child, keywords)
            if (result != null) return result
        }
        return null
    }
}

/**
 * 📊 场景状态
 */
enum class ScenarioState {
    IDLE,       // 空闲
    RUNNING,    // 运行中
    STOPPING,   // 停止中
    COMPLETED,  // 已完成
    ERROR       // 错误
}

/**
 * 📊 场景进度
 */
data class ScenarioProgress(
    val currentStep: Int = 0,
    val totalSteps: Int = 0,
    val message: String = "",
    val successCount: Int = 0,
    val failCount: Int = 0
) {
    val progressPercent: Float
        get() = if (totalSteps > 0) currentStep.toFloat() / totalSteps else 0f
}

/**
 * ⚙️ 场景配置基类
 */
open class ScenarioConfig(
    val maxIterations: Int = 100,           // 最大迭代次数
    val delayBetweenActions: Long = 1000L,  // 动作间隔(ms)
    val enableRandomDelay: Boolean = true,   // 启用随机延迟
    val confirmBeforeSubmit: Boolean = true  // 提交前确认
)


/**
 * 🛡️ 安全护栏 - 危险操作检测
 */
object SafetyGuard {
    
    private val dangerousKeywords = listOf(
        "支付", "付款", "转账", "汇款", "银行卡", "密码",
        "验证码", "删除", "注销", "永久", "不可恢复"
    )
    
    private val submitKeywords = listOf(
        "提交", "确认", "发送", "保存", "完成", "支付",
        "Submit", "Confirm", "Send", "Save", "Pay"
    )
    
    /**
     * 🔍 检测是否包含危险内容
     */
    fun containsDangerousContent(text: String): Boolean {
        return dangerousKeywords.any { text.contains(it, ignoreCase = true) }
    }
    
    /**
     * 🔍 检测是否是提交类操作
     */
    fun isSubmitAction(text: String): Boolean {
        return submitKeywords.any { text.contains(it, ignoreCase = true) }
    }
    
    /**
     * ⚠️ 生成安全警告
     */
    fun generateWarning(text: String): String? {
        val triggered = dangerousKeywords.filter { text.contains(it, ignoreCase = true) }
        return if (triggered.isNotEmpty()) {
            "⚠️ 检测到敏感内容: ${triggered.joinToString(", ")}，请谨慎操作"
        } else null
    }
}
