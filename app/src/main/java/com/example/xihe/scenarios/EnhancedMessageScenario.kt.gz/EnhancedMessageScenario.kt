package com.example.xihe.scenarios

import android.content.Context
import com.example.xihe.utils.LogManager
import android.view.accessibility.AccessibilityNodeInfo
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.core.*
import com.example.xihe.core.model.ChatMessageDisplay
import com.example.xihe.screen.ScreenAnalyzer
import com.example.xihe.core.ModuleCoordinator
import kotlinx.coroutines.delay

/**
 * 📱 增强版消息场景
 * 提供更智能的消息发送、联系人查找、发送验证等功能
 */
object EnhancedMessageScenario {
    private const val TAG = "EnhancedMessageScenario"
    
    // ==================== 📊 数据类 ====================
    
    /**
     * 📨 消息发送请求
     */
    data class MessageRequest(
        val app: MessageApp,
        val contactName: String,
        val message: String,
        val messageType: MessageType = MessageType.TEXT,
        val confirmBeforeSend: Boolean = false,
        val retryOnFail: Boolean = true
    )
    
    /**
     * 📱 支持的消息应用
     */
    enum class MessageApp(val packageName: String, val displayName: String) {
        WECHAT("com.tencent.mm", "微信"),
        QQ("com.tencent.mobileqq", "QQ"),
        DINGTALK("com.alibaba.android.rimet", "钉钉"),
        FEISHU("com.ss.android.lark", "飞书"),
        TELEGRAM("org.telegram.messenger", "Telegram")
    }
    
    /**
     * 📝 消息类型
     */
    enum class MessageType {
        TEXT,           // 文本消息
        VOICE,          // 语音消息
        IMAGE,          // 图片消息
        FILE,           // 文件消息
        LOCATION        // 位置消息
    }
    
    /**
     * 📊 发送状态
     */
    data class SendStatus(
        val step: SendStep,
        val success: Boolean,
        val message: String,
        val retryCount: Int = 0
    )
    
    /**
     * 📍 发送步骤
     */
    enum class SendStep {
        LAUNCHING_APP,          // 启动应用
        SEARCHING_CONTACT,      // 搜索联系人
        OPENING_CHAT,           // 打开聊天
        FOCUSING_INPUT,         // 聚焦输入框
        TYPING_MESSAGE,         // 输入消息
        CONFIRMING_SEND,        // 确认发送
        CLICKING_SEND,          // 点击发送
        VERIFYING_SENT,         // 验证发送
        COMPLETED               // 完成
    }
    
    /**
     * ⚠️ 消息风险级别
     */
    enum class MessageRiskLevel {
        SAFE,       // 安全
        LOW,        // 低风险
        MEDIUM,     // 中风险
        HIGH,       // 高风险
        CRITICAL    // 严重风险
    }
    
    /**
     * 📊 风险检测结果
     */
    data class RiskDetectionResult(
        val level: MessageRiskLevel,
        val triggeredKeywords: List<String>,
        val warningMessage: String
    )
    
    /**
     * 📋 联系人匹配结果
     */
    data class ContactMatch(
        val name: String,
        val similarity: Float,
        val nodeInfo: AccessibilityNodeInfo?
    )
    
    // ==================== 🔍 智能检测 ====================
    
    /**
     * 🔍 增强版消息意图检测
     */
    fun detectMessageIntent(userInput: String): MessageRequest? {
        val input = userInput.trim().lowercase()
        
        // 检测应用
        val app = detectApp(input)
        
        // 检测联系人和消息内容
        val patterns = listOf(
            // "给张三发微信说晚上吃饭" / "给张三发消息说晚上吃饭"
            Regex("""给\s*(.+?)\s*发\s*(?:微信|qq|钉钉|飞书|消息|信息)?\s*(?:说|：|:)\s*(.+)""", RegexOption.IGNORE_CASE),
            // "给张三发微信晚上吃饭"（省略“说”）
            Regex("""给\s*(.+?)\s*发\s*(?:微信|qq|钉钉|飞书|消息|信息)\s*(.+)""", RegexOption.IGNORE_CASE),
            // "发微信给张三：晚上吃饭" / "发消息给张三说晚上吃饭"
            Regex("""发\s*(?:微信|qq|钉钉|飞书|消息|信息)\s*给\s*(.+?)\s*(?:说|：|:)\s*(.+)""", RegexOption.IGNORE_CASE),
            // "用微信给张三发消息晚上吃饭" / "在微信给张三发消息晚上吃饭"
            Regex("""(?:在|用)\s*(?:微信|qq|钉钉|飞书)\s*给\s*(.+?)\s*(?:发条|发个|发)?\s*(?:微信|消息|信息)?\s*(?:说|：|:)?\s*(.+)""", RegexOption.IGNORE_CASE),
            // "告诉张三：晚上吃饭" / "告诉张三说晚上吃饭"
            Regex("""告诉\s*(.+?)\s*(?:说|：|:)\s*(.+)""", RegexOption.IGNORE_CASE),
            // "跟张三说晚上吃饭"
            Regex("""跟\s*(.+?)\s*说\s*(.+)""", RegexOption.IGNORE_CASE),
            // "微信张三：晚上吃饭" / "QQ张三: 晚上吃饭"
            Regex("""(?:微信|qq)\s*(.+?)\s*(?:：|:)\s*(.+)""", RegexOption.IGNORE_CASE),
            // 英文风格："send message to Tom: hello"
            Regex("""send\s+(?:a\s+)?message\s+to\s+(.+?):\s*(.+)""", RegexOption.IGNORE_CASE)
        )
        
        for (pattern in patterns) {
            val match = pattern.find(input)
            if (match != null && match.groupValues.size >= 3) {
                val contactName = match.groupValues[1].trim()
                val message = match.groupValues[2].trim()
                
                if (contactName.isNotEmpty() && message.isNotEmpty()) {
                    // 🎯 智能联系人映射
                    val normalizedContactName = normalizeContactName(contactName)
                    
                    LogManager.d(TAG, "✅ 检测到消息意图: app=$app, contact=$normalizedContactName (原始: $contactName), message=$message")
                    return MessageRequest(
                        app = app,
                        contactName = normalizedContactName,
                        message = message
                    )
                }
            }
        }
        
        return null
    }
    
    /**
     * 🎯 智能联系人名称规范化
     * 将"自己"相关的表达映射到"文件传输助手"
     */
    private fun normalizeContactName(contact: String): String {
        val normalized = contact.trim().lowercase()
        
        // 自我指代的各种表达方式
        val selfExpressions = listOf(
            "自己", "我自己", "我", 
            "me", "myself", "self",
            "我的", "本人"
        )
        
        // 如果是自我指代，映射到文件传输助手
        if (selfExpressions.any { normalized.contains(it) }) {
            LogManager.d(TAG, "💡 智能映射: \"$contact\" → \"文件传输助手\"")
            return "文件传输助手"
        }
        
        // 其他特殊别名映射（可扩展）
        val aliasMap = mapOf(
            "老婆" to "老婆",
            "老公" to "老公", 
            "爸爸" to "爸爸",
            "妈妈" to "妈妈",
            "爸" to "爸爸",
            "妈" to "妈妈"
        )
        
        return aliasMap[normalized] ?: contact
    }
    
    /**
     * 🔍 检测目标应用
     */
    private fun detectApp(input: String): MessageApp {
        return when {
            input.contains("qq") -> MessageApp.QQ
            input.contains("钉钉") -> MessageApp.DINGTALK
            input.contains("飞书") -> MessageApp.FEISHU
            input.contains("telegram") || input.contains("电报") -> MessageApp.TELEGRAM
            else -> MessageApp.WECHAT // 默认微信
        }
    }
    
    // ==================== 📨 消息发送 ====================
    
    /**
     * 📨 执行增强版消息发送
     */
    suspend fun sendMessage(
        request: MessageRequest,
        context: Context,
        onStatusUpdate: (SendStatus) -> Unit
    ): ScenarioResult {
        LogManager.d(TAG, "📨 开始发送消息: ${request.app.displayName} -> ${request.contactName}")
        
        // Step 0: 风险检测 🛡️
        val riskResult = detectMessageRisk(request.message)
        when (riskResult.level) {
            MessageRiskLevel.HIGH, MessageRiskLevel.CRITICAL -> {
                LogManager.w(TAG, "⚠️ 检测到高风险消息内容: ${riskResult.warningMessage}")
                LogManager.w(TAG, "⚠️ 触发关键词: ${riskResult.triggeredKeywords.joinToString(", ")}")
                onStatusUpdate(SendStatus(
                    SendStep.CONFIRMING_SEND, 
                    true, 
                    "⚠️ 警告：检测到敏感内容（${riskResult.triggeredKeywords.joinToString(", ")}），请谨慎发送"
                ))
                delay(2000) // 给用户看到警告的时间
            }
            MessageRiskLevel.MEDIUM -> {
                LogManager.i(TAG, "⚡ 检测到中风险内容: ${riskResult.warningMessage}")
                onStatusUpdate(SendStatus(SendStep.CONFIRMING_SEND, true, "⚡ 提示：${riskResult.warningMessage}"))
                delay(1000)
            }
            else -> {
                LogManager.d(TAG, "✅ 消息内容安全检查通过")
            }
        }
        
        val service = CoreAccessibilityService.instance
            ?: return ScenarioResult.Failure("无障碍服务未启动")
        
        val enhancedExecutor = EnhancedActionExecutor(service, context)
        val maxRetries = if (request.retryOnFail) 2 else 0
        
        try {
            LogManager.d(TAG, "==================== 开始发送消息流程 ====================")
            LogManager.d(TAG, "应用: ${request.app.displayName}")
            LogManager.d(TAG, "联系人: ${request.contactName}")
            LogManager.d(TAG, "消息: ${request.message}")
            
            // Step 1: 启动应用
            onStatusUpdate(SendStatus(SendStep.LAUNCHING_APP, true, "正在启动${request.app.displayName}..."))
            LogManager.d(TAG, "[步骤 1/7] 启动应用...")
            val launchResult = launchApp(request.app, context)
            if (!launchResult) {
                LogManager.e(TAG, "❌ 步骤1失败: 无法启动应用")
                return ScenarioResult.Failure("无法启动${request.app.displayName}，请确认应用已安装")
            }
            LogManager.d(TAG, "✅ 应用已启动，等待界面加载...")
            delay(3000) // 增加等待时间
            
            // Step 2: 搜索联系人
            onStatusUpdate(SendStatus(SendStep.SEARCHING_CONTACT, true, "正在搜索联系人: ${request.contactName}"))
            LogManager.d(TAG, "[步骤 2/7] 搜索联系人...")
            val searchResult = searchContact(service, enhancedExecutor, request.contactName, request.app, context)
            if (!searchResult.success) {
                LogManager.e(TAG, "❌ 步骤2失败: 未找到联系人")
                return ScenarioResult.Failure("未找到联系人: ${request.contactName}。请确认联系人名称正确且已添加好友")
            }
            LogManager.d(TAG, "✅ 联系人搜索成功")
            delay(1200)
            
            // Step 3: 打开聊天
            onStatusUpdate(SendStatus(SendStep.OPENING_CHAT, true, "正在打开聊天窗口..."))
            LogManager.d(TAG, "[步骤 3/7] 打开聊天窗口...")
            val openResult = openChat(service, enhancedExecutor, searchResult.contactMatch)
            if (!openResult) {
                LogManager.e(TAG, "❌ 步骤3失败: 无法打开聊天窗口")
                return ScenarioResult.Failure("无法打开与 ${request.contactName} 的聊天窗口")
            }
            LogManager.d(TAG, "✅ 聊天窗口已打开")
            delay(2000) // 增加等待时间
            
            // Step 4: 输入消息
            onStatusUpdate(SendStatus(SendStep.TYPING_MESSAGE, true, "正在输入消息..."))
            LogManager.d(TAG, "[步骤 4/7] 输入消息...")
            val inputResult = inputMessage(service, enhancedExecutor, request.message, request.app)
            if (!inputResult) {
                LogManager.e(TAG, "❌ 步骤4失败: 消息输入失败")
                return ScenarioResult.Failure("消息输入失败。请检查输入框是否被其他内容遮挡")
            }
            LogManager.d(TAG, "✅ 消息输入完成")
            delay(800)
            
            // Step 5: 确认发送（如果需要）
            if (request.confirmBeforeSend) {
                onStatusUpdate(SendStatus(SendStep.CONFIRMING_SEND, true, "等待确认发送..."))
                // 这里可以添加用户确认逻辑
            }
            
            // Step 6: 点击发送
            onStatusUpdate(SendStatus(SendStep.CLICKING_SEND, true, "正在发送消息..."))
            LogManager.d(TAG, "[步骤 6/7] 点击发送按钮...")
            val sendResult = clickSendButton(service, enhancedExecutor, request.app)
            if (!sendResult) {
                LogManager.e(TAG, "❌ 步骤6失败: 发送按钮点击失败")
                return ScenarioResult.Failure("发送按钮点击失败。请检查发送按钮是否可见")
            }
            LogManager.d(TAG, "✅ 发送按钮已点击")
            delay(1500) // 增加等待时间
            
            // Step 7: 验证发送
            onStatusUpdate(SendStatus(SendStep.VERIFYING_SENT, true, "正在验证发送状态..."))
            LogManager.d(TAG, "[步骤 7/7] 验证消息是否发送成功...")
            val verified = verifySent(service, request.message)
            
            if (verified) {
                LogManager.d(TAG, "✅ 消息发送成功！")
                LogManager.d(TAG, "==================== 流程完成 ====================")
                onStatusUpdate(SendStatus(SendStep.COMPLETED, true, "消息发送成功！"))
                return ScenarioResult.Success("已成功给 ${request.contactName} 发送${request.app.displayName}消息")
            } else {
                LogManager.w(TAG, "⚠️ 无法确认消息是否发送成功")
                LogManager.d(TAG, "==================== 流程结束（部分成功） ====================")
                return ScenarioResult.PartialSuccess("消息可能已发送，但无法在聊天记录中确认", completedSteps = 6, totalSteps = 7)
            }
            
        } catch (e: Exception) {
            LogManager.e(TAG, "发送消息异常", e)
            return ScenarioResult.Failure("发送失败: ${e.message}")
        }
    }
    
    // ==================== 🔧 辅助方法 ====================
    
    /**
     * 🚀 启动应用
     */
    private suspend fun launchApp(app: MessageApp, context: Context): Boolean {
        return try {
            val intent = context.packageManager.getLaunchIntentForPackage(app.packageName)
            if (intent != null) {
                context.startActivity(intent)
                true
            } else {
                LogManager.e(TAG, "未安装应用: ${app.packageName}")
                false
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "启动应用失败", e)
            false
        }
    }
    
    /**
     * 🔍 搜索联系人（增强版 - 添加详细日志和多重重试）
     */
    private suspend fun searchContact(
        service: CoreAccessibilityService,
        executor: EnhancedActionExecutor,
        contactName: String,
        app: MessageApp,
        context: Context? = null
    ): ContactSearchResult {
        LogManager.d(TAG, "🔍 开始搜索联系人: $contactName")
        
        // 🆕 先确保返回到主界面（按返回键最多3次）
        for (i in 1..3) {
            val currentRoot = service.rootInActiveWindow
            // 检查是否在聊天界面（有返回按钮或在聊天窗口）
            val hasBackButton = currentRoot?.let { findNodeByTextOrDesc(it, "返回") } != null
            val hasChatInput = currentRoot?.let { findNodeByTextOrDesc(it, "发送") } != null
            
            if (hasBackButton || hasChatInput) {
                LogManager.d(TAG, "📱 检测到可能在聊天界面，尝试返回主界面 ($i/3)")
                service.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
                delay(500)
            } else {
                break
            }
        }
        
        delay(500) // 等待界面稳定
        
        // 获取搜索框位置（不同应用位置不同）
        val searchHints = getSearchHints(app)
        LogManager.d(TAG, "搜索提示词: ${searchHints.joinToString(", ")}")
        
        var rootNode = service.rootInActiveWindow
        if (rootNode == null) {
            LogManager.e(TAG, "❌ 无法获取根节点，无障碍服务可能未正常工作")
            return ContactSearchResult(false, null)
        }
        
        // 🆕 打印当前界面所有可点击元素，帮助调试
        LogManager.d(TAG, "📋 当前界面可点击元素:")
        printClickableNodes(rootNode, 0)
        
        // 🆕 微信特殊处理：先尝试点击右上角搜索图标
        if (app == MessageApp.WECHAT) {
            LogManager.d(TAG, "📱 微信特殊处理：尝试点击搜索图标...")
            
            // 方法1：通过contentDescription找搜索按钮
            val searchIconNode = findNodeByContentDescription(rootNode, "搜索") 
                ?: findNodeByContentDescription(rootNode, "Search")
            
            if (searchIconNode != null) {
                LogManager.d(TAG, "✅ 找到搜索图标，点击...")
                clickNodeOrParent(searchIconNode)
                delay(1000)
                rootNode = service.rootInActiveWindow ?: return ContactSearchResult(false, null)
            } else {
                // 方法2：尝试点击右上角区域（搜索图标通常在右上角）
                LogManager.d(TAG, "⚠️ 未找到搜索图标，尝试点击右上角区域...")
                val displayMetrics = android.content.res.Resources.getSystem().displayMetrics
                val screenWidth = displayMetrics.widthPixels
                val gesture = android.accessibilityservice.GestureDescription.Builder()
                    .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(
                        android.graphics.Path().apply {
                            moveTo(screenWidth - 80f, 150f)
                        },
                        0, 50
                    ))
                    .build()
                service.dispatchGesture(gesture, null, null)
                delay(1000)
                rootNode = service.rootInActiveWindow ?: return ContactSearchResult(false, null)
            }
            
            // 🆕 再次打印界面，查看搜索页面元素
            LogManager.d(TAG, "📋 搜索页面可点击元素:")
            printClickableNodes(rootNode, 0)
        }
        
        // 尝试点击搜索框/输入框
        var searchActivated = false
        for ((index, hint) in searchHints.withIndex()) {
            LogManager.d(TAG, "尝试查找搜索框 [${index + 1}/${searchHints.size}]: '$hint'")
            
            // 每次循环刷新根节点
            rootNode = service.rootInActiveWindow ?: continue
            
            val searchNode = findNodeByTextOrDesc(rootNode, hint)
            if (searchNode == null) {
                LogManager.w(TAG, "⚠️ 未找到搜索框: '$hint'")
                continue
            }
            
            LogManager.d(TAG, "找到搜索框，尝试点击...")
            val clickResult = executor.smartClick(rootNode, null, hint)
            if (!clickResult.success) {
                LogManager.w(TAG, "⚠️ 点击搜索框失败: ${clickResult.errorMessage}")
                // 尝试直接点击节点
                clickNodeOrParent(searchNode)
            }
            
            searchActivated = true
            delay(800) // 增加等待时间
            LogManager.d(TAG, "搜索框已激活，准备输入联系人名字...")
            break
        }
        
        // 🆕 如果没有找到搜索框，尝试查找EditText输入框
        if (!searchActivated) {
            LogManager.d(TAG, "🔍 尝试查找可编辑的输入框...")
            rootNode = service.rootInActiveWindow ?: return ContactSearchResult(false, null)
            val editNode = findEditableNode(rootNode)
            if (editNode != null) {
                LogManager.d(TAG, "✅ 找到输入框，点击激活...")
                editNode.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                editNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                delay(500)
                searchActivated = true
            }
        }
        
        if (!searchActivated) {
            LogManager.e(TAG, "❌ 无法激活搜索框")
            return ContactSearchResult(false, null)
        }
        
        // 继续搜索逻辑
        for (attempt in 1..2) {
            LogManager.d(TAG, "📝 输入联系人名字尝试 $attempt/2...")
            
            // 输入联系人名字
            val inputResult = executor.smartInput(
                service.rootInActiveWindow,
                null,
                contactName,
                clearFirst = true
            )
            
            if (!inputResult.success) {
                LogManager.w(TAG, "⚠️ 输入联系人名字失败: ${inputResult.errorMessage}")
                continue
            }
            
            LogManager.d(TAG, "✅ 已输入联系人名字: $contactName，等待搜索结果...")
            delay(1500) // 增加等待时间，确保搜索结果加载
            
            // 查找联系人
            val newRoot = service.rootInActiveWindow
            if (newRoot == null) {
                LogManager.w(TAG, "⚠️ 无法获取搜索结果页面")
                continue
            }
            
            // 🆕 获取所有匹配的联系人
            val allCandidates = findAllContacts(newRoot, contactName)
            
            if (allCandidates.isNotEmpty()) {
                LogManager.d(TAG, "✅ 找到 ${allCandidates.size} 个匹配联系人")
                
                // 如果有多个候选且没有精确匹配，进行语音确认
                val confirmedContact = if (allCandidates.size > 1 && allCandidates.first().similarity < 0.95f && context != null) {
                    // 需要语音确认
                    confirmContactWithVoice(context, allCandidates, contactName)
                } else {
                    // 只有一个或有精确匹配，或无法进行语音确认
                    allCandidates.first()
                }
                
                if (confirmedContact != null) {
                    LogManager.d(TAG, "✅ 确认联系人: ${confirmedContact.name}")
                    return ContactSearchResult(true, confirmedContact)
                }
            } else {
                LogManager.w(TAG, "⚠️ 搜索结果中未找到匹配的联系人")
            }
        }
        
        LogManager.e(TAG, "❌ 搜索联系人失败：尝试了所有搜索策略")
        return ContactSearchResult(false, null)
    }
    
    /**
     * 🔍 获取搜索框提示词
     */
    private fun getSearchHints(app: MessageApp): List<String> {
        return when (app) {
            // 微信搜索框可能的文案
            MessageApp.WECHAT -> listOf(
                "搜索", "Search", "微信号/手机号", 
                "搜一搜", "放大镜", "🔍",
                "通讯录", "联系人"
            )
            MessageApp.QQ -> listOf("搜索", "找人", "Search", "搜一搜")
            MessageApp.DINGTALK -> listOf("搜索", "找人", "Search")
            MessageApp.FEISHU -> listOf("搜索", "Search")
            MessageApp.TELEGRAM -> listOf("Search", "搜索")
        }
    }
    
    /**
     * 🔍 查找联系人 (返回所有匹配的候选人)
     */
    private fun findAllContacts(rootNode: AccessibilityNodeInfo?, contactName: String): List<ContactMatch> {
        if (rootNode == null) return emptyList()
        
        val candidates = mutableListOf<ContactMatch>()
        findContactsRecursive(rootNode, contactName, candidates)
        
        // 按相似度排序，去重
        return candidates
            .distinctBy { it.name }
            .sortedByDescending { it.similarity }
            .take(5) // 最多返回5个候选
    }
    
    /**
     * 🔍 查找联系人 (返回最佳匹配)
     */
    private fun findContact(rootNode: AccessibilityNodeInfo?, contactName: String): ContactMatch? {
        return findAllContacts(rootNode, contactName).firstOrNull()
    }
    
    /**
     * 🎤 语音确认联系人选择
     * 当有多个相似联系人时，通过语音询问用户选择
     */
    private suspend fun confirmContactWithVoice(
        context: Context,
        candidates: List<ContactMatch>,
        originalName: String
    ): ContactMatch? {
        if (candidates.isEmpty()) return null
        if (candidates.size == 1) return candidates.first()
        
        // 检查是否有完全匹配的
        val exactMatch = candidates.find { it.similarity >= 0.95f }
        if (exactMatch != null) {
            LogManager.d(TAG, "✅ 找到精确匹配: ${exactMatch.name}")
            return exactMatch
        }
        
        // 构建询问语句
        val question = buildString {
            append("我找到了 ${candidates.size} 个相似的联系人：")
            candidates.forEachIndexed { index, match ->
                append("第${index + 1}个是 ${match.name}，")
            }
            append("你要发给哪一个？可以说序号或者名字。")
        }
        
        LogManager.d(TAG, "🎤 语音询问: $question")
        
        // 添加消息到聊天
        EngineStateManager.addMessage(ChatMessageDisplay(
            content = "🤔 找到多个相似联系人，请确认发送给谁：\n" +
                    candidates.mapIndexed { i, m -> "${i + 1}. ${m.name}" }.joinToString("\n"),
            isUser = false
        ))
        
        // 播报询问
        ModuleCoordinator.speak(question)
        
        // 等待语音播报完成
        delay(question.length * 100L + 1000)
        
        // 使用 AutomationEngine 的待确认联系人机制
        pendingContactConfirmation = candidates
        
        // 开始语音识别
        ModuleCoordinator.startVoiceRecognition { recognizedText ->
            if (recognizedText.isNotBlank()) {
                EngineStateManager.addMessage(ChatMessageDisplay(
                    content = recognizedText,
                    isUser = true
                ))
            }
            ModuleCoordinator.stopVoiceRecognition(disableContinuous = false)
        }
        
        // 等待用户回答（最多等待 10 秒）
        var waitTime = 0
        while (waitTime < 10000 && pendingContactConfirmation != null) {
            delay(500)
            waitTime += 500
            
            // 检查是否有用户输入
            val lastMessage = EngineStateManager.messages.value.lastOrNull { it.isUser }
            if (lastMessage != null && lastMessage.content.isNotBlank()) {
                val selectedContact = parseUserSelection(lastMessage.content, candidates)
                if (selectedContact != null) {
                    pendingContactConfirmation = null
                    EngineStateManager.addMessage(ChatMessageDisplay(
                        content = "好的，发送给 ${selectedContact.name} ✅",
                        isUser = false
                    ))
                    return selectedContact
                }
            }
        }
        
        // 超时，选择相似度最高的
        pendingContactConfirmation = null
        val first = candidates.first()
        EngineStateManager.addMessage(ChatMessageDisplay(
            content = "没收到回复，默认发送给 ${first.name}",
            isUser = false
        ))
        return first
    }
    
    // 待确认的联系人列表
    private var pendingContactConfirmation: List<ContactMatch>? = null
    
    /**
     * 🔍 解析用户选择
     */
    private fun parseUserSelection(userInput: String, candidates: List<ContactMatch>): ContactMatch? {
        val input = userInput.lowercase().trim()
        
        // 检查序号
        val numberPatterns = listOf(
            "第一" to 0, "1" to 0, "一" to 0, "第1" to 0,
            "第二" to 1, "2" to 1, "二" to 1, "第2" to 1,
            "第三" to 2, "3" to 2, "三" to 2, "第3" to 2,
            "第四" to 3, "4" to 3, "四" to 3, "第4" to 3,
            "第五" to 4, "5" to 4, "五" to 4, "第5" to 4
        )
        
        for ((pattern, index) in numberPatterns) {
            if (input.contains(pattern) && index < candidates.size) {
                return candidates[index]
            }
        }
        
        // 检查名字匹配
        for (candidate in candidates) {
            if (input.contains(candidate.name.lowercase()) || 
                candidate.name.lowercase().contains(input)) {
                return candidate
            }
        }
        
        return null
    }
    
    private fun findContactsRecursive(
        node: AccessibilityNodeInfo,
        targetName: String,
        candidates: MutableList<ContactMatch>
    ) {
        val nodeText = node.text?.toString() ?: ""
        val similarity = calculateNameSimilarity(nodeText, targetName)
        
        // 降低阈值到 0.4，支持更模糊的匹配
        if (similarity > 0.4f && node.isClickable) {
            candidates.add(ContactMatch(nodeText, similarity, node))
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findContactsRecursive(child, targetName, candidates)
        }
    }
    
    /**
     * 📊 计算名字相似度 (增强版模糊匹配)
     */
    private fun calculateNameSimilarity(name1: String, name2: String): Float {
        if (name1.isEmpty() || name2.isEmpty()) return 0f
        if (name1 == name2) return 1f
        
        val s1 = name1.lowercase().replace(" ", "")
        val s2 = name2.lowercase().replace(" ", "")
        
        // 完全匹配
        if (s1 == s2) return 1f
        
        // 包含关系 - 任意一方包含另一方即可
        if (s1.contains(s2) || s2.contains(s1)) {
            return 0.95f
        }
        
        // 前缀/后缀匹配 - 用户可能只说了名字的一部分
        if (s1.startsWith(s2) || s1.endsWith(s2) || s2.startsWith(s1) || s2.endsWith(s1)) {
            return 0.85f
        }
        
        // 连续子串匹配 - 检查是否有连续的字符匹配
        val minLen = minOf(s1.length, s2.length)
        var maxContinuous = 0
        var current = 0
        var j = 0
        for (i in s1.indices) {
            if (j < s2.length && s1[i] == s2[j]) {
                current++
                j++
                maxContinuous = maxOf(maxContinuous, current)
            } else {
                current = 0
            }
        }
        if (maxContinuous >= 2 && maxContinuous.toFloat() / minLen >= 0.5f) {
            return 0.75f + (maxContinuous.toFloat() / minLen) * 0.2f
        }
        
        // 字符匹配率
        var matches = 0
        for (char in s2) {
            if (s1.contains(char)) matches++
        }
        
        return matches.toFloat() / s2.length * 0.7f
    }
    
    /**
     * 💬 打开聊天
     */
    private suspend fun openChat(
        service: CoreAccessibilityService,
        executor: EnhancedActionExecutor,
        contactMatch: ContactMatch?
    ): Boolean {
        if (contactMatch?.nodeInfo == null) return false
        
        val result = executor.smartClick(
            service.rootInActiveWindow,
            null,
            contactMatch.name
        )
        
        return result.success
    }
    
    /**
     * ⌨️ 输入消息（增强版 - 多种输入策略）
     */
    private suspend fun inputMessage(
        service: CoreAccessibilityService,
        executor: EnhancedActionExecutor,
        message: String,
        app: MessageApp
    ): Boolean {
        LogManager.d(TAG, "⌨️ 开始输入消息: ${message.take(20)}...")
        
        val inputHints = getInputHints(app)
        val rootNode = service.rootInActiveWindow
        if (rootNode == null) {
            LogManager.e(TAG, "❌ 无法获取聊天窗口")
            return false
        }
        
        // 策略1: 通过提示词查找并点击输入框
        for ((index, hint) in inputHints.withIndex()) {
            LogManager.d(TAG, "尝试策略1 [${index + 1}/${inputHints.size}]: 查找输入框 '$hint'")
            
            val inputNode = findNodeByTextOrDesc(rootNode, hint)
            if (inputNode != null) {
                LogManager.d(TAG, "找到输入框，尝试点击激活...")
                val clickResult = executor.smartClick(rootNode, null, hint)
                if (clickResult.success) {
                    delay(500)
                    
                    // 输入消息
                    LogManager.d(TAG, "输入框已激活，开始输入消息...")
                    val inputResult = executor.smartInput(
                        service.rootInActiveWindow,
                        null,
                        message,
                        clearFirst = false
                    )
                    
                    if (inputResult.success) {
                        LogManager.d(TAG, "✅ 消息输入成功")
                        return true
                    } else {
                        LogManager.w(TAG, "⚠️ 消息输入失败: ${inputResult.errorMessage}")
                    }
                }
            }
        }
        
        // 策略2: 直接查找 EditText 组件
        LogManager.d(TAG, "策略1失败，尝试策略2: 直接查找 EditText...")
        val editText = findEditText(rootNode)
        if (editText != null) {
            LogManager.d(TAG, "找到 EditText，尝试直接输入...")
            val result = executor.smartInput(rootNode, null, message)
            if (result.success) {
                LogManager.d(TAG, "✅ 通过 EditText 输入成功")
                return true
            } else {
                LogManager.w(TAG, "⚠️ EditText 输入失败: ${result.errorMessage}")
            }
        } else {
            LogManager.w(TAG, "⚠️ 未找到 EditText")
        }
        
        LogManager.e(TAG, "❌ 所有输入策略均失败")
        return false
    }
    
    /**
     * 🔍 获取输入框提示词
     */
    private fun getInputHints(app: MessageApp): List<String> {
        return when (app) {
            MessageApp.WECHAT -> listOf("发送消息", "请输入", "输入")
            MessageApp.QQ -> listOf("发送消息", "请输入", "输入")
            MessageApp.DINGTALK -> listOf("说点什么", "输入")
            MessageApp.FEISHU -> listOf("发送消息", "输入")
            MessageApp.TELEGRAM -> listOf("Message", "Write a message")
        }
    }
    
    /**
     * 📤 点击发送按钮
     */
    private suspend fun clickSendButton(
        service: CoreAccessibilityService,
        executor: EnhancedActionExecutor,
        app: MessageApp
    ): Boolean {
        val sendButtonTexts = getSendButtonTexts(app)
        val rootNode = service.rootInActiveWindow ?: return false
        
        for (text in sendButtonTexts) {
            val result = executor.smartClick(rootNode, null, text)
            if (result.success) {
                return true
            }
        }
        
        return false
    }
    
    /**
     * 🔍 获取发送按钮文本
     */
    private fun getSendButtonTexts(app: MessageApp): List<String> {
        return when (app) {
            MessageApp.WECHAT -> listOf("发送", "Send")
            MessageApp.QQ -> listOf("发送", "Send")
            MessageApp.DINGTALK -> listOf("发送", "Send")
            MessageApp.FEISHU -> listOf("发送", "Send")
            MessageApp.TELEGRAM -> listOf("Send", "发送")
        }
    }
    
    /**
     * ✅ 验证消息是否发送成功
     */
    private fun verifySent(service: CoreAccessibilityService, message: String): Boolean {
        val rootNode = service.rootInActiveWindow ?: return false
        
        // 查找消息是否出现在聊天记录中
        val messageNode = findNodeByTextOrDesc(rootNode, message)
        return messageNode != null
    }
    
    /**
     * 🔍 通过文本或描述查找节点（增强版 - 支持多种匹配方式）
     */
    private fun findNodeByTextOrDesc(node: AccessibilityNodeInfo, text: String): AccessibilityNodeInfo? {
        try {
            val nodeText = node.text?.toString() ?: ""
            val nodeDesc = node.contentDescription?.toString() ?: ""
            val nodeId = try { node.viewIdResourceName ?: "" } catch (e: Exception) { "" }
            
            // 完全匹配
            if (nodeText.equals(text, ignoreCase = true) || 
                nodeDesc.equals(text, ignoreCase = true)) {
                LogManager.d(TAG, "✅ 完全匹配找到节点: text='$nodeText', desc='$nodeDesc'")
                return node
            }
            
            // 包含匹配
            if (nodeText.contains(text, ignoreCase = true) || 
                nodeDesc.contains(text, ignoreCase = true)) {
                LogManager.d(TAG, "✅ 包含匹配找到节点: text='$nodeText', desc='$nodeDesc'")
                return node
            }
            
            // 通过 viewId 匹配（如 "search"、"input"）
            if (nodeId.contains(text, ignoreCase = true)) {
                LogManager.d(TAG, "✅ ViewId 匹配找到节点: id='$nodeId'")
                return node
            }
            
            // 递归查找子节点
            for (i in 0 until node.childCount) {
                try {
                    val child = node.getChild(i) ?: continue
                    val found = findNodeByTextOrDesc(child, text)
                    if (found != null) return found
                } catch (e: Exception) {
                    // 节点可能已被回收，跳过
                    continue
                }
            }
        } catch (e: Exception) {
            LogManager.w(TAG, "查找节点时异常: ${e.message}")
        }
        
        return null
    }
    
    /**
     * 🔍 查找 EditText（增强版 - 支持多种输入框类型）
     */
    private fun findEditText(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        try {
            val className = node.className?.toString() ?: ""
            
            // 检查是否是输入框类型
            if (className.contains("EditText", ignoreCase = true) ||
                className.contains("TextInputEditText", ignoreCase = true) ||
                className.contains("AppCompatEditText", ignoreCase = true)) {
                
                // 确保可以输入
                if (node.isEditable || node.isFocusable) {
                    LogManager.d(TAG, "✅ 找到输入框: className='$className', editable=${node.isEditable}")
                    return node
                }
            }
            
            // 递归查找
            for (i in 0 until node.childCount) {
                try {
                    val child = node.getChild(i) ?: continue
                    val found = findEditText(child)
                    if (found != null) return found
                } catch (e: Exception) {
                    continue
                }
            }
        } catch (e: Exception) {
            LogManager.w(TAG, "查找输入框时异常: ${e.message}")
        }
        
        return null
    }
    
    /**
     * 📊 联系人搜索结果
     */
    private data class ContactSearchResult(
        val success: Boolean,
        val contactMatch: ContactMatch?
    )
    
    // ==================== 🛡️ 风险检测 ====================
    
    /**
     * 🛡️ 检测消息内容风险
     */
    private fun detectMessageRisk(message: String): RiskDetectionResult {
        val lowerMessage = message.lowercase()
        
        // 严重风险关键词（涉及金钱、账号安全）
        val criticalKeywords = listOf(
            "转账", "汇款", "打款", "银行卡号", "支付宝账号", "微信支付密码",
            "支付密码", "验证码", "动态密码", "身份证号", "银行密码"
        )
        
        // 高风险关键词（重要决策、敏感操作）
        val highRiskKeywords = listOf(
            "辞职", "离职", "分手", "离婚", "借钱", "贷款",
            "投资", "股票", "赌", "删除所有", "清空", "注销账号"
        )
        
        // 中风险关键词（可能引起误会或需谨慎）
        val mediumRiskKeywords = listOf(
            "拉黑", "举报", "投诉", "删除好友", "屏蔽",
            "不要联系", "最后一次", "永远不", "从此"
        )
        
        val triggered = mutableListOf<String>()
        var level = MessageRiskLevel.SAFE
        var warning = ""
        
        // 检测严重风险
        for (keyword in criticalKeywords) {
            if (lowerMessage.contains(keyword)) {
                triggered.add(keyword)
                level = MessageRiskLevel.CRITICAL
            }
        }
        
        // 如果没有严重风险，检测高风险
        if (level != MessageRiskLevel.CRITICAL) {
            for (keyword in highRiskKeywords) {
                if (lowerMessage.contains(keyword)) {
                    triggered.add(keyword)
                    level = MessageRiskLevel.HIGH
                }
            }
        }
        
        // 如果没有高风险，检测中风险
        if (level == MessageRiskLevel.SAFE) {
            for (keyword in mediumRiskKeywords) {
                if (lowerMessage.contains(keyword)) {
                    triggered.add(keyword)
                    level = MessageRiskLevel.MEDIUM
                }
            }
        }
        
        // 生成警告信息
        warning = when (level) {
            MessageRiskLevel.CRITICAL -> "消息涉及金钱或账号安全，请务必确认收件人和内容无误"
            MessageRiskLevel.HIGH -> "消息包含敏感内容，可能产生重要影响，请谨慎发送"
            MessageRiskLevel.MEDIUM -> "消息包含需要注意的内容，建议再次检查"
            else -> "消息内容正常"
        }
        
        return RiskDetectionResult(
            level = level,
            triggeredKeywords = triggered,
            warningMessage = warning
        )
    }
    
    /**
     * 🔍 打印所有可点击节点（调试用）
     */
    private fun printClickableNodes(node: AccessibilityNodeInfo, depth: Int) {
        val indent = "  ".repeat(depth)
        val text = node.text?.toString() ?: ""
        val desc = node.contentDescription?.toString() ?: ""
        val className = node.className?.toString()?.substringAfterLast(".") ?: ""
        
        if (node.isClickable || text.isNotEmpty() || desc.isNotEmpty()) {
            val clickable = if (node.isClickable) "[可点击]" else ""
            LogManager.d(TAG, "$indent$clickable $className: text='$text' desc='$desc'")
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            printClickableNodes(child, depth + 1)
        }
    }
    
    /**
     * 🔍 通过contentDescription查找节点
     */
    private fun findNodeByContentDescription(node: AccessibilityNodeInfo, description: String): AccessibilityNodeInfo? {
        val desc = node.contentDescription?.toString() ?: ""
        if (desc.contains(description, ignoreCase = true)) {
            return node
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findNodeByContentDescription(child, description)
            if (found != null) return found
        }
        
        return null
    }
    
    /**
     * 🖱️ 点击节点或其可点击的父节点
     */
    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        if (node.isClickable) {
            return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        
        var parent = node.parent
        var depth = 0
        while (parent != null && depth < 5) {
            if (parent.isClickable) {
                return parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            parent = parent.parent
            depth++
        }
        
        // 如果没有可点击的父节点，尝试点击当前节点
        return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }
    
    /**
     * 🔍 查找可编辑的输入框
     */
    private fun findEditableNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable) return node
        
        val className = node.className?.toString() ?: ""
        if (className.contains("EditText")) return node
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findEditableNode(child)
            if (found != null) return found
        }
        
        return null
    }
}
