package com.example.xihe.scenarios

/**
 * 场景执行结果
 */
sealed class ScenarioResult(open val message: String, open val completedSteps: Int = 0, open val totalSteps: Int = 0) {
    data class Success(override val message: String, override val completedSteps: Int = 0, override val totalSteps: Int = 0) : ScenarioResult(message, completedSteps, totalSteps)
    data class Failure(val error: String, override val message: String = error, override val completedSteps: Int = 0, override val totalSteps: Int = 0) : ScenarioResult(message, completedSteps, totalSteps)
    data class PartialSuccess(override val message: String, override val completedSteps: Int, override val totalSteps: Int) : ScenarioResult(message, completedSteps, totalSteps)
    data class Stopped(override val message: String, override val completedSteps: Int = 0, override val totalSteps: Int = 0) : ScenarioResult(message, completedSteps, totalSteps)
    
    val success: Boolean
        get() = this is Success || this is PartialSuccess
    
    fun isSuccess(): Boolean = this is Success || this is PartialSuccess
}
