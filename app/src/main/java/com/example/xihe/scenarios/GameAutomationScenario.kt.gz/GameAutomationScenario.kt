package com.example.xihe.scenarios

import android.content.Context
import android.graphics.Bitmap
import com.example.xihe.utils.LogManager
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.ocr.OCRManager
import kotlinx.coroutines.delay
import kotlin.random.Random

/**
 * 🎮 游戏自动化场景
 * 
 * 支持：
 * - 坐标点击宏（固定位置循环点击）
 * - 手势宏（滑动、长按等）
 * - 图像/文字触发（OCR 检测特定内容后执行动作）
 * - 随机扰动（模拟人类操作，降低检测风险）
 * 
 * ⚠️ 仅用于单机/放置类游戏的辅助，不支持对抗反作弊
 * ⚠️ 在线游戏使用自动化可能违反用户协议，风险自负
 */
class GameAutomationScenario(context: Context) : ScenarioBase(context, "游戏自动化") {
    
    companion object {
        private const val TAG = "GameAutomationScenario"
    }
    
    private val ocrManager by lazy { OCRManager.getInstance(context) }
    
    /**
     * ⚙️ 游戏自动化配置
     */
    data class GameConfig(
        val gameName: String = "",                      // 游戏名称（可选）
        val gamePackage: String? = null,               // 游戏包名（可选，用于启动）
        val actions: List<GameAction>,                  // 动作序列
        val loopCount: Int = 100,                       // 循环次数（-1 表示无限）
        val loopDelayMs: Long = 1000L,                 // 每轮循环间隔
        val enableRandomOffset: Boolean = true,         // 启用随机偏移
        val randomOffsetRange: Int = 20,               // 随机偏移范围(像素)
        val enableGameRandomDelay: Boolean = true,      // 启用游戏随机延迟
        val randomDelayRange: Long = 500L,             // 随机延迟范围(ms)
        val stopOnError: Boolean = false,              // 出错时停止
        val triggers: List<Trigger> = emptyList()      // 触发器列表
    ) : ScenarioConfig(maxIterations = if (loopCount > 0) loopCount else Int.MAX_VALUE)
    
    /**
     * 🎯 游戏动作
     */
    sealed class GameAction {
        abstract val delayAfterMs: Long  // 执行后延迟
        
        /**
         * 📍 点击动作
         */
        data class Tap(
            val x: Float,                   // X 坐标（绝对像素或相对比例 0-1）
            val y: Float,                   // Y 坐标
            val isRelative: Boolean = false, // 是否是相对坐标
            override val delayAfterMs: Long = 200L
        ) : GameAction()
        
        /**
         * 👆 长按动作
         */
        data class LongPress(
            val x: Float,
            val y: Float,
            val isRelative: Boolean = false,
            val durationMs: Long = 1000L,
            override val delayAfterMs: Long = 200L
        ) : GameAction()
        
        /**
         * 👆👆 双击动作
         */
        data class DoubleTap(
            val x: Float,
            val y: Float,
            val isRelative: Boolean = false,
            override val delayAfterMs: Long = 200L
        ) : GameAction()
        
        /**
         * 📲 滑动动作
         */
        data class Swipe(
            val startX: Float,
            val startY: Float,
            val endX: Float,
            val endY: Float,
            val isRelative: Boolean = false,
            val durationMs: Int = 300,
            override val delayAfterMs: Long = 200L
        ) : GameAction()
        
        /**
         * ⏳ 等待动作
         */
        data class Wait(
            override val delayAfterMs: Long
        ) : GameAction()
        
        /**
         * 🔙 返回键
         */
        data class Back(
            override val delayAfterMs: Long = 500L
        ) : GameAction()
        
        /**
         * 🔍 点击文字（OCR 查找）
         */
        data class TapText(
            val text: String,               // 要点击的文字
            val fuzzyMatch: Boolean = true, // 模糊匹配
            override val delayAfterMs: Long = 500L
        ) : GameAction()
        
        /**
         * 📦 条件动作（根据屏幕内容决定是否执行）
         */
        data class Conditional(
            val condition: Trigger,
            val thenActions: List<GameAction>,
            val elseActions: List<GameAction> = emptyList(),
            override val delayAfterMs: Long = 0L
        ) : GameAction()
    }
    
    /**
     * 🎯 触发器（条件检测）
     */
    sealed class Trigger {
        /**
         * 📝 文字出现触发
         */
        data class TextAppears(
            val text: String,
            val fuzzyMatch: Boolean = true
        ) : Trigger()
        
        /**
         * 📝 文字消失触发
         */
        data class TextDisappears(
            val text: String,
            val fuzzyMatch: Boolean = true
        ) : Trigger()
        
        /**
         * ⏰ 定时触发
         */
        data class TimeElapsed(
            val intervalMs: Long
        ) : Trigger()
        
        /**
         * 🔢 计数触发
         */
        data class CountReached(
            val count: Int
        ) : Trigger()
    }
    
    /**
     * 📋 宏模板（预设常用操作）
     */
    object MacroTemplates {
        
        /**
         * 🔄 简单循环点击
         */
        fun simpleLoopTap(
            x: Float, y: Float,
            isRelative: Boolean = true,
            intervalMs: Long = 1000L,
            count: Int = 100
        ): GameConfig {
            return GameConfig(
                actions = listOf(GameAction.Tap(x, y, isRelative, intervalMs)),
                loopCount = count
            )
        }
        
        /**
         * 🎯 多点循环点击
         */
        fun multiPointTap(
            points: List<Pair<Float, Float>>,
            isRelative: Boolean = true,
            intervalMs: Long = 500L,
            count: Int = 100
        ): GameConfig {
            val actions = points.map { (x, y) ->
                GameAction.Tap(x, y, isRelative, intervalMs)
            }
            return GameConfig(actions = actions, loopCount = count)
        }
        
        /**
         * 📦 领取奖励模板
         */
        fun collectRewards(
            collectButtonText: String = "领取",
            closeButtonText: String = "关闭",
            count: Int = 50
        ): GameConfig {
            return GameConfig(
                actions = listOf(
                    GameAction.TapText(collectButtonText, true, 1000L),
                    GameAction.TapText(closeButtonText, true, 500L),
                    GameAction.Wait(1000L)
                ),
                loopCount = count
            )
        }
        
        /**
         * 🔁 刷关卡模板
         */
        fun farmStage(
            startButtonText: String = "开始",
            autoButtonText: String = "自动",
            waitTimeMs: Long = 60000L,  // 每关等待时间
            count: Int = 20
        ): GameConfig {
            return GameConfig(
                actions = listOf(
                    GameAction.TapText(startButtonText, true, 2000L),
                    GameAction.TapText(autoButtonText, true, 1000L),
                    GameAction.Wait(waitTimeMs)
                ),
                loopCount = count
            )
        }
    }
    
    /**
     * 🔍 检测用户意图
     */
    fun detectIntent(userInput: String): GameConfig? {
        val input = userInput.lowercase()
        
        // 检测是否是游戏自动化意图
        val isGameIntent = input.contains(Regex("(游戏|挂机|自动|循环|刷).*(点击|点|按|领|收|打|刷)"))
            || input.contains(Regex("(点击|点|按|领取|收集).*(循环|自动|重复)"))
        
        if (!isGameIntent) return null
        
        // 检测循环次数
        val countMatch = Regex("""(\d+)\s*(次|遍|轮|下)""").find(input)
        val count = countMatch?.groupValues?.get(1)?.toIntOrNull() ?: 100
        
        // 检测间隔时间
        val intervalMatch = Regex("""(每|间隔)\s*(\d+)\s*(秒|毫秒|ms|s)""").find(input)
        val interval = intervalMatch?.let {
            val value = it.groupValues[2].toLongOrNull() ?: 1000L
            val unit = it.groupValues[3]
            if (unit == "秒" || unit == "s") value * 1000 else value
        } ?: 1000L
        
        // 检测坐标
        val coordMatch = Regex("""(\d+)[,，\s]+(\d+)""").find(input)
        val (x, y) = if (coordMatch != null) {
            coordMatch.groupValues[1].toFloat() to coordMatch.groupValues[2].toFloat()
        } else {
            0.5f to 0.5f // 默认屏幕中心
        }
        
        val isRelative = x <= 1f && y <= 1f
        
        LogManager.d(TAG, "✅ 检测到游戏自动化意图: 坐标=($x,$y), 次数=$count, 间隔=${interval}ms")
        
        return GameConfig(
            actions = listOf(GameAction.Tap(x, y, isRelative, interval)),
            loopCount = count
        )
    }
    
    /**
     * 🎯 执行游戏自动化
     */
    override suspend fun execute(config: ScenarioConfig): ScenarioResult {
        val gameConfig = config as? GameConfig
            ?: return ScenarioResult.Failure("配置类型错误", "配置类型错误")
        
        val service = CoreAccessibilityService.instance
            ?: return ScenarioResult.Failure("无障碍服务未启动", "无障碍服务未启动")
        
        // 启动游戏（如果指定了包名）
        if (!gameConfig.gamePackage.isNullOrEmpty()) {
            updateProgress(message = "正在启动游戏... 🎮")
            log("启动游戏: ${gameConfig.gamePackage}")
            
            val launched = service.launchApp(gameConfig.gamePackage)
            if (!launched) {
                return ScenarioResult.Failure("无法启动游戏", "无法启动游戏")
            }
            delay(5000) // 等待游戏启动
        }
        
        val (screenWidth, screenHeight) = service.getScreenSize()
        val totalLoops = if (gameConfig.loopCount > 0) gameConfig.loopCount else Int.MAX_VALUE
        
        var successCount = 0
        var failCount = 0
        var loopIndex = 0
        var lastTriggerTime = System.currentTimeMillis()
        
        log("🎮 开始游戏自动化: ${gameConfig.actions.size} 个动作, 循环 $totalLoops 次")
        
        while (loopIndex < totalLoops) {
            if (shouldStop()) {
                return ScenarioResult.Stopped(
                    message = "已停止，完成 $loopIndex 轮",
                    completedSteps = loopIndex,
                    totalSteps = totalLoops
                )
            }
            
            loopIndex++
            updateProgress(
                currentStep = loopIndex,
                message = "执行第 $loopIndex/$totalLoops 轮... 🎮",
                successCount = successCount,
                failCount = failCount
            )
            
            // 检查触发器
            for (trigger in gameConfig.triggers) {
                val triggered = checkTrigger(trigger, service, loopIndex, lastTriggerTime)
                if (triggered) {
                    log("🎯 触发器激活: $trigger")
                    lastTriggerTime = System.currentTimeMillis()
                }
            }
            
            // 执行动作序列
            for ((actionIndex, action) in gameConfig.actions.withIndex()) {
                if (shouldStop()) break
                
                val result = executeAction(
                    action = action,
                    service = service,
                    screenWidth = screenWidth,
                    screenHeight = screenHeight,
                    config = gameConfig
                )
                
                if (result) {
                    successCount++
                } else {
                    failCount++
                    log("⚠️ 动作 ${actionIndex + 1} 执行失败")
                    
                    if (gameConfig.stopOnError) {
                        return ScenarioResult.Failure(
                            message = "动作执行失败，已停止",
                            error = "动作执行失败",
                            completedSteps = loopIndex,
                            totalSteps = totalLoops
                        )
                    }
                }
                
                // 动作后延迟
                val delay = action.delayAfterMs + if (gameConfig.enableGameRandomDelay) {
                    Random.nextLong(0, gameConfig.randomDelayRange)
                } else 0
                
                delay(delay)
            }
            
            // 循环间隔
            if (loopIndex < totalLoops) {
                delay(gameConfig.loopDelayMs)
            }
        }
        
        updateProgress(
            currentStep = totalLoops,
            message = "✅ 自动化完成！共执行 $loopIndex 轮",
            successCount = successCount,
            failCount = failCount
        )
        
        return ScenarioResult.Success(
            message = "游戏自动化完成，共执行 $loopIndex 轮，成功 $successCount 次动作",
            completedSteps = loopIndex,
            totalSteps = totalLoops
        )
    }
    
    /**
     * 🎬 执行单个动作
     */
    private suspend fun executeAction(
        action: GameAction,
        service: CoreAccessibilityService,
        screenWidth: Int,
        screenHeight: Int,
        config: GameConfig
    ): Boolean {
        return when (action) {
            is GameAction.Tap -> {
                val (x, y) = convertCoordinates(
                    action.x, action.y, action.isRelative,
                    screenWidth, screenHeight, config
                )
                log("点击: ($x, $y)")
                service.tapAsync(x, y)
            }
            
            is GameAction.LongPress -> {
                val (x, y) = convertCoordinates(
                    action.x, action.y, action.isRelative,
                    screenWidth, screenHeight, config
                )
                log("长按: ($x, $y), ${action.durationMs}ms")
                service.longPressAsync(x, y, action.durationMs)
            }
            
            is GameAction.DoubleTap -> {
                val (x, y) = convertCoordinates(
                    action.x, action.y, action.isRelative,
                    screenWidth, screenHeight, config
                )
                log("双击: ($x, $y)")
                service.performDoubleClick(x, y)
                true
            }
            
            is GameAction.Swipe -> {
                val (startX, startY) = convertCoordinates(
                    action.startX, action.startY, action.isRelative,
                    screenWidth, screenHeight, config
                )
                val (endX, endY) = convertCoordinates(
                    action.endX, action.endY, action.isRelative,
                    screenWidth, screenHeight, config
                )
                log("滑动: ($startX,$startY) -> ($endX,$endY)")
                service.swipeAsync(startX, startY, endX, endY, action.durationMs.toLong())
            }
            
            is GameAction.Wait -> {
                log("等待: ${action.delayAfterMs}ms")
                delay(action.delayAfterMs.toLong())
                true
            }
            
            is GameAction.Back -> {
                log("返回键")
                service.performGlobalBack()
                true
            }
            
            is GameAction.TapText -> {
                log("点击文字: ${action.text}")
                
                // 尝试通过无障碍节点查找
                if (service.findAndClick(action.text)) {
                    return true
                }
                
                // 回退到 OCR
                try {
                    val screenshot = service.takeScreenshotAsync()
                    if (screenshot != null) {
                        val ocrResult = ocrManager.recognizeText(screenshot)
                        val matches = ocrManager.findTextInResult(ocrResult, action.text, action.fuzzyMatch)
                        
                        if (matches.isNotEmpty()) {
                            val match = matches[0]
                            service.tapAsync(match.centerX.toFloat(), match.centerY.toFloat())
                            return true
                        }
                    }
                } catch (e: Exception) {
                    log("❌ OCR 查找失败: ${e.message}")
                }
                
                false
            }
            
            is GameAction.Conditional -> {
                val conditionMet = checkTrigger(action.condition, service, 0, 0)
                val actionsToExecute = if (conditionMet) action.thenActions else action.elseActions
                
                for (subAction in actionsToExecute) {
                    executeAction(subAction, service, screenWidth, screenHeight, config)
                }
                true
            }
        }
    }
    
    /**
     * 📐 坐标转换（支持相对坐标和随机偏移）
     */
    private fun convertCoordinates(
        x: Float, y: Float,
        isRelative: Boolean,
        screenWidth: Int,
        screenHeight: Int,
        config: GameConfig
    ): Pair<Float, Float> {
        var actualX = if (isRelative) x * screenWidth else x
        var actualY = if (isRelative) y * screenHeight else y
        
        // 添加随机偏移
        if (config.enableRandomOffset) {
            actualX += Random.nextInt(-config.randomOffsetRange, config.randomOffsetRange + 1)
            actualY += Random.nextInt(-config.randomOffsetRange, config.randomOffsetRange + 1)
        }
        
        // 确保在屏幕范围内
        actualX = actualX.coerceIn(0f, screenWidth.toFloat())
        actualY = actualY.coerceIn(0f, screenHeight.toFloat())
        
        return actualX to actualY
    }
    
    /**
     * 🔍 检查触发器
     */
    private suspend fun checkTrigger(
        trigger: Trigger,
        service: CoreAccessibilityService,
        loopCount: Int,
        lastTriggerTime: Long
    ): Boolean {
        return when (trigger) {
            is Trigger.TextAppears -> {
                try {
                    val screenshot = service.takeScreenshotAsync() ?: return false
                    val ocrResult = ocrManager.recognizeText(screenshot)
                    ocrManager.findTextInResult(ocrResult, trigger.text, trigger.fuzzyMatch).isNotEmpty()
                } catch (e: Exception) {
                    false
                }
            }
            
            is Trigger.TextDisappears -> {
                try {
                    val screenshot = service.takeScreenshotAsync() ?: return true
                    val ocrResult = ocrManager.recognizeText(screenshot)
                    ocrManager.findTextInResult(ocrResult, trigger.text, trigger.fuzzyMatch).isEmpty()
                } catch (e: Exception) {
                    true
                }
            }
            
            is Trigger.TimeElapsed -> {
                System.currentTimeMillis() - lastTriggerTime >= trigger.intervalMs
            }
            
            is Trigger.CountReached -> {
                loopCount >= trigger.count
            }
        }
    }
    
    /**
     * 🎯 快捷方法：简单循环点击
     */
    suspend fun startLoopTap(
        x: Float, y: Float,
        isRelative: Boolean = true,
        intervalMs: Long = 1000L,
        count: Int = 100,
        onProgress: (String) -> Unit = {}
    ): ScenarioResult {
        val config = MacroTemplates.simpleLoopTap(x, y, isRelative, intervalMs, count)
        return start(config)
    }
    
    /**
     * 🎯 快捷方法：多点循环点击
     */
    suspend fun startMultiPointTap(
        points: List<Pair<Float, Float>>,
        isRelative: Boolean = true,
        intervalMs: Long = 500L,
        count: Int = 100,
        onProgress: (String) -> Unit = {}
    ): ScenarioResult {
        val config = MacroTemplates.multiPointTap(points, isRelative, intervalMs, count)
        return start(config)
    }
    
    /**
     * 🎯 快捷方法：执行自定义动作序列
     */
    suspend fun startCustomActions(
        actions: List<GameAction>,
        loopCount: Int = 1,
        loopDelayMs: Long = 1000L,
        onProgress: (String) -> Unit = {}
    ): ScenarioResult {
        val config = GameConfig(
            actions = actions,
            loopCount = loopCount,
            loopDelayMs = loopDelayMs
        )
        return start(config)
    }
}
