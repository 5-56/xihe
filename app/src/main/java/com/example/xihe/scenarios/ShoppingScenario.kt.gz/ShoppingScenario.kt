package com.example.xihe.scenarios

import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.core.*
import com.example.xihe.tools.ToolRegistry
import kotlinx.coroutines.delay
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/**
 * 🛒 购物自动化场景
 * 支持淘宝、京东、拼多多等电商平台
 */
object ShoppingScenario {
    private const val TAG = "ShoppingScenario"
    
    /**
     * 检测是否是购物指令
     */
    fun detectShopping(userInput: String): ShoppingSearchRequest? {
        val input = userInput.trim()
        
        // 匹配模式：
        // "在淘宝搜索iPhone"
        // "帮我在京东找笔记本电脑"
        // "拼多多搜索水果"
        
        val patterns = listOf(
            // "在淘宝搜索iPhone"
            Regex("""在?\s*(淘宝|京东|拼多多|pdd)\s*(搜索|找|买|看看)\s*(.+)"""),
            // "淘宝搜索iPhone"
            Regex("""(淘宝|京东|拼多多|pdd)\s*(搜索|找|买|看看)\s*(.+)"""),
            // "搜索iPhone在淘宝"
            Regex("""(搜索|找|买)\s*(.+?)\s*在?\s*(淘宝|京东|拼多多|pdd)""")
        )
        
        for (pattern in patterns) {
            val match = pattern.find(input)
            if (match != null) {
                val groups = match.groupValues
                
                val app = when {
                    groups.any { it.contains("淘宝") } -> "淘宝"
                    groups.any { it.contains("京东") } -> "京东"
                    groups.any { it.contains(Regex("拼多多|pdd")) } -> "拼多多"
                    else -> "淘宝"
                }
                
                // 提取商品关键词
                val keyword = when {
                    groups.size > 3 && groups[3].isNotEmpty() -> groups[3]
                    groups.size > 2 && groups[2].isNotEmpty() && !groups[2].contains(Regex("搜索|找|买|看看")) -> groups[2]
                    else -> ""
                }.trim()
                
                if (keyword.isEmpty() || keyword.length < 2) {
                    continue
                }
                
                // 检测是否要执行购买操作
                val shouldBuy = input.contains(Regex("购买|下单|买|加入购物车"))
                val sortBy = when {
                    input.contains("销量") -> "sales"
                    input.contains("价格") -> "price"
                    input.contains("好评") -> "rating"
                    else -> null
                }
                
                return ShoppingSearchRequest(app, keyword, shouldBuy, sortBy)
            }
        }
        
        return null
    }
    
    /**
     * 执行购物搜索任务
     */
    suspend fun executeShoppingSearch(
        request: ShoppingSearchRequest,
        context: Context,
        onProgress: (String) -> Unit
    ): ScenarioResult {
        val appPackage = when (request.app) {
            "淘宝" -> "com.taobao.taobao"
            "京东" -> "com.jingdong.app.mall"
            "拼多多" -> "com.xunmeng.pinduoduo"
            else -> return ScenarioResult.Failure("不支持的应用: ${request.app}")
        }
        
        try {
            // Step 1: 打开购物应用
            onProgress("正在打开${request.app}... 🛒")
            val launchResult = ToolRegistry.executeTool(
                com.example.xihe.tools.ToolCall(
                    "launch_app",
                    buildJsonObject { put("appNameOrPackage", appPackage) }
                )
            )
            
            if (!launchResult.success) {
                return ScenarioResult.Failure("无法打开${request.app}")
            }
            
            delay(3000) // 等待应用启动
            
            val service = CoreAccessibilityService.instance
                ?: return ScenarioResult.Failure("无障碍服务未启动")
            
            val executor = ActionExecutor(service, context)
            val llmClient = LLMClient(
                AutomationEngine.baseUrl,
                AutomationEngine.apiKey,
                AutomationEngine.modelName,
                AutomationEngine.providerId
            )
            
            // Step 2: 搜索商品
            onProgress("正在搜索：${request.keyword}... 🔍")
            
            val searchSteps = listOf(
                "找到搜索框或搜索图标并点击",
                "在搜索框输入商品名称：${request.keyword}",
                "点击搜索按钮或确认搜索"
            )
            
            for (stepGoal in searchSteps) {
                val root = service.rootInActiveWindow ?: continue
                val screenState = ScreenAnalyzer.analyze(root, appPackage)
                
                if (screenState != null) {
                    val command = llmClient.think(screenState, stepGoal, emptyList())
                    executor.execute(command, root)
                    delay(1500)
                }
            }
            
            delay(2000) // 等待搜索结果加载
            
            // Step 3: 提取商品信息
            onProgress("正在分析商品信息... 📦")
            val rootNode = service.rootInActiveWindow
            val productInfo = ShoppingIntelligence.extractProductInfo(rootNode)
            
            if (productInfo != null) {
                onProgress("找到商品: ${productInfo.title}")
                onProgress("价格: ${productInfo.currentPrice?.formatted ?: "未知"}")
                
                if (productInfo.rating != null) {
                    onProgress("评分: ${productInfo.rating} ⭐")
                }
                
                if (productInfo.salesCount != null) {
                    onProgress("销量: ${productInfo.salesCount}+")
                }
            }
            
            // Step 4: 如果需要排序
            if (request.sortBy != null) {
                onProgress("正在按${getSortName(request.sortBy)}排序... 📊")
                
                val sortGoal = when (request.sortBy) {
                    "sales" -> "找到并点击按销量排序的选项"
                    "price" -> "找到并点击按价格排序的选项"
                    "rating" -> "找到并点击按好评排序的选项"
                    else -> ""
                }
                
                if (sortGoal.isNotEmpty()) {
                    val root = service.rootInActiveWindow
                    if (root != null) {
                        val screenState = ScreenAnalyzer.analyze(root, appPackage)
                        if (screenState != null) {
                            val command = llmClient.think(screenState, sortGoal, emptyList())
                            executor.execute(command, root)
                            delay(2000)
                        }
                    }
                }
            }
            
            // Step 5: 如果需要购买
            if (request.shouldBuy) {
                onProgress("准备购买商品... 💳")
                
                val buySteps = listOf(
                    "点击第一个商品进入详情页",
                    "在详情页找到并点击购买或加入购物车按钮"
                )
                
                for (stepGoal in buySteps) {
                    val root = service.rootInActiveWindow ?: continue
                    val screenState = ScreenAnalyzer.analyze(root, appPackage)
                    
                    if (screenState != null) {
                        val command = llmClient.think(screenState, stepGoal, emptyList())
                        executor.execute(command, root)
                        delay(2000)
                    }
                }
                
                onProgress("✅ 已添加到购物车，请确认订单信息")
            }
            
            return ScenarioResult.Success(
                "已在${request.app}搜索「${request.keyword}」${if (request.shouldBuy) "并添加到购物车" else ""}"
            )
            
        } catch (e: Exception) {
            LogManager.e(TAG, "购物场景执行失败", e)
            return ScenarioResult.Failure("购物操作失败: ${e.message}")
        }
    }
    
    private fun getSortName(sortBy: String): String {
        return when (sortBy) {
            "sales" -> "销量"
            "price" -> "价格"
            "rating" -> "好评"
            else -> "默认"
        }
    }
    
    /**
     * 💰 检测是否是比价指令
     */
    fun detectPriceComparison(userInput: String): PriceComparisonRequest? {
        val input = userInput.trim()
        
        val patterns = listOf(
            Regex("""比价\s*(.+)"""),
            Regex("""(.+?)\s*(哪个平台|哪里|哪家)便宜"""),
            Regex("""(.+?)\s*价格对比"""),
            Regex("""帮我比价?\s*(.+)"""),
            Regex("""(.+?)\s*多少钱"""),
            Regex("""(淘宝|京东|拼多多).+(淘宝|京东|拼多多).+比.*(.+)""")
        )
        
        for (pattern in patterns) {
            val match = pattern.find(input)
            if (match != null) {
                val keyword = match.groupValues.lastOrNull { it.isNotBlank() && it.length >= 2 }
                    ?.replace(Regex("(帮我|在|的|哪个|平台|便宜|价格)"), "")
                    ?.trim()
                
                if (keyword != null && keyword.length >= 2) {
                    // 检测要比较的平台
                    val platforms = mutableListOf<String>()
                    if (input.contains("淘宝")) platforms.add("淘宝")
                    if (input.contains("京东")) platforms.add("京东")
                    if (input.contains("拼多多") || input.contains("pdd")) platforms.add("拼多多")
                    
                    // 默认比较所有平台
                    if (platforms.isEmpty()) {
                        platforms.addAll(listOf("淘宝", "京东", "拼多多"))
                    }
                    
                    LogManager.d(TAG, "检测到比价意图: 关键词=$keyword, 平台=$platforms")
                    return PriceComparisonRequest(keyword, platforms)
                }
            }
        }
        
        return null
    }
    
    /**
     * 💰 执行跨平台比价
     */
    suspend fun executePriceComparison(
        request: PriceComparisonRequest,
        context: Context,
        onProgress: (String) -> Unit
    ): PriceComparisonResult {
        val results = mutableListOf<PlatformPrice>()
        
        onProgress("💰 开始跨平台比价: ${request.keyword}")
        
        for (platform in request.platforms) {
            try {
                onProgress("🔍 正在查询 $platform...")
                
                // 执行搜索并提取价格
                val searchRequest = ShoppingSearchRequest(
                    app = platform,
                    keyword = request.keyword,
                    shouldBuy = false,
                    sortBy = "price"
                )
                
                val searchResult = executeShoppingSearch(searchRequest, context) { }
                
                if (searchResult is ScenarioResult.Success) {
                    // 从当前屏幕提取价格信息
                    val service = CoreAccessibilityService.instance
                    if (service != null) {
                        val rootNode = service.rootInActiveWindow
                        val productInfo = ShoppingIntelligence.extractProductInfo(rootNode)
                        
                        if (productInfo != null && productInfo.currentPrice != null) {
                            results.add(PlatformPrice(
                                platform = platform,
                                price = productInfo.currentPrice.value,
                                originalPrice = productInfo.originalPrice?.value,
                                productTitle = productInfo.title,
                                shopName = productInfo.shopName,
                                salesCount = productInfo.salesCount?.toString(),
                                rating = productInfo.rating
                            ))
                            
                            onProgress("✅ $platform: ￥${productInfo.currentPrice.formatted}")
                        } else {
                            onProgress("⚠️ $platform: 未找到价格信息")
                        }
                    }
                }
                
                delay(1000) // 平台间间隔
                
            } catch (e: Exception) {
                LogManager.e(TAG, "查询 $platform 失败", e)
                onProgress("❌ $platform: 查询失败")
            }
        }
        
        val bestPrice = results.minByOrNull { it.price }
        val comparisonResult = PriceComparisonResult(
            keyword = request.keyword,
            results = results,
            bestPrice = bestPrice
        )
        
        onProgress(comparisonResult.getSummary())
        
        return comparisonResult
    }
}

/**
 * 💰 比价请求
 */
data class PriceComparisonRequest(
    val keyword: String,
    val platforms: List<String> = listOf("淘宝", "京东", "拼多多")
)

/**
 * 购物搜索请求
 */
data class ShoppingSearchRequest(
    val app: String,           // 应用名称：淘宝、京东、拼多多
    val keyword: String,       // 搜索关键词
    val shouldBuy: Boolean = false,  // 是否购买
    val sortBy: String? = null,      // 排序方式：sales/price/rating
    val comparePrice: Boolean = false // 是否跨平台比价
)

/**
 * 💰 比价结果
 */
data class PriceComparisonResult(
    val keyword: String,
    val results: List<PlatformPrice>,
    val bestPrice: PlatformPrice?,
    val timestamp: Long = System.currentTimeMillis()
) {
    fun getSummary(): String {
        if (results.isEmpty()) return "未找到比价结果"
        
        val summary = StringBuilder()
        summary.appendLine("📊 「$keyword」跨平台比价结果:")
        summary.appendLine()
        
        results.sortedBy { it.price }.forEachIndexed { index, result ->
            val icon = when (index) {
                0 -> "🥇"
                1 -> "🥈"
                2 -> "🥉"
                else -> "•"
            }
            summary.appendLine("$icon ${result.platform}: ￥${result.price}")
            if (result.originalPrice != null && result.originalPrice > result.price) {
                val discount = ((1 - result.price / result.originalPrice) * 100).toInt()
                summary.appendLine("   原价￥${result.originalPrice} 省${discount}%")
            }
        }
        
        bestPrice?.let {
            summary.appendLine()
            summary.appendLine("✅ 最低价: ${it.platform} ￥${it.price}")
        }
        
        return summary.toString()
    }
}

/**
 * 🏪 平台价格
 */
data class PlatformPrice(
    val platform: String,      // 平台名称
    val price: Double,         // 当前价格
    val originalPrice: Double? = null,  // 原价
    val productTitle: String? = null,   // 商品标题
    val shopName: String? = null,       // 店铺名称
    val salesCount: String? = null,     // 销量
    val rating: Float? = null           // 评分
)
