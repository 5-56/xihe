package com.example.xihe.scenarios

import com.example.xihe.utils.LogManager
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.regex.Pattern

/**
 * 📄 办公智能处理模块
 * 
 * 功能：
 * - 📄 文档内容提取
 * - ✏️ 文档编辑自动化
 * - 🔄 文档格式转换
 * - 📤 文档分享自动化
 * - 📧 邮件内容理解
 * - 🏷️ 邮件自动分类
 * - 💬 邮件自动回复
 * - 📎 邮件附件处理
 */
object OfficeIntelligence {
    
    private const val TAG = "OfficeIntelligence"
    
    // 邮件分类规则
    private val emailClassificationRules = mutableListOf<EmailClassificationRule>()
    
    // 自动回复模板
    private val autoReplyTemplates = mutableMapOf<EmailCategory, List<String>>()
    
    // 文档历史
    private val documentHistory = mutableListOf<DocumentRecord>()
    
    // 邮件处理状态
    private val _emailProcessingStatus = MutableStateFlow<EmailProcessingStatus?>(null)
    val emailProcessingStatus = _emailProcessingStatus.asStateFlow()
    
    init {
        initDefaultClassificationRules()
        initDefaultReplyTemplates()
    }
    
    // ==================== 📄 文档内容提取 ====================
    
    /**
     * 📄 提取文档内容
     */
    fun extractDocumentContent(rootNode: AccessibilityNodeInfo?): DocumentContent {
        if (rootNode == null) return DocumentContent.empty()
        
        LogManager.d(TAG, "📄 提取文档内容")
        
        val paragraphs = mutableListOf<String>()
        val headings = mutableListOf<HeadingInfo>()
        val tables = mutableListOf<TableInfo>()
        val images = mutableListOf<ImageInfo>()
        val links = mutableListOf<LinkInfo>()
        var title: String? = null
        
        traverseNodes(rootNode) { node ->
            val text = node.text?.toString() ?: ""
            val className = node.className?.toString() ?: ""
            val desc = node.contentDescription?.toString() ?: ""
            
            // 提取标题
            if (title == null && isDocumentTitle(text, className)) {
                title = text
            }
            
            // 提取段落
            if (isParagraph(text, className)) {
                paragraphs.add(text)
            }
            
            // 提取标题层级
            val headingLevel = detectHeadingLevel(text, className)
            if (headingLevel > 0) {
                headings.add(HeadingInfo(text, headingLevel))
            }
            
            // 检测表格
            if (className.contains("Table") || className.contains("Grid")) {
                extractTableInfo(node)?.let { tables.add(it) }
            }
            
            // 检测图片
            if (className.contains("Image")) {
                images.add(ImageInfo(desc, node.isClickable))
            }
            
            // 检测链接
            if (node.isClickable && (text.contains("http") || desc.contains("链接"))) {
                links.add(LinkInfo(text, extractUrl(text)))
            }
        }
        
        // 检测文档类型
        val documentType = detectDocumentType(title, paragraphs)
        
        return DocumentContent(
            title = title ?: "未命名文档",
            documentType = documentType,
            paragraphs = paragraphs,
            headings = headings,
            tables = tables,
            images = images,
            links = links,
            wordCount = paragraphs.sumOf { it.length },
            extractedAt = System.currentTimeMillis()
        )
    }
    
    private fun isDocumentTitle(text: String, className: String): Boolean {
        return (text.length in 2..100 && 
                (className.contains("Title") || 
                 className.contains("Heading") ||
                 text.matches(Regex("""^[一二三四五六七八九十\d]+[、.．]\s*.+"""))))
    }
    
    private fun isParagraph(text: String, className: String): Boolean {
        return text.length >= 20 && 
               !text.startsWith("http") &&
               className.contains("Text", ignoreCase = true)
    }
    
    private fun detectHeadingLevel(text: String, className: String): Int {
        // H1-H6 标题检测
        val headingMatch = Regex("""[Hh](\d)""").find(className)
        if (headingMatch != null) {
            return headingMatch.groupValues[1].toIntOrNull() ?: 0
        }
        
        // 中文标题检测
        return when {
            text.matches(Regex("""^第[一二三四五六七八九十]+章.*""")) -> 1
            text.matches(Regex("""^第[一二三四五六七八九十]+节.*""")) -> 2
            text.matches(Regex("""^[一二三四五六七八九十]+[、.．].*""")) -> 2
            text.matches(Regex("""^[（(][一二三四五六七八九十]+[）)].*""")) -> 3
            text.matches(Regex("""^\d+[、.．].*""")) -> 3
            text.matches(Regex("""^[（(]\d+[）)].*""")) -> 4
            else -> 0
        }
    }
    
    private fun extractTableInfo(node: AccessibilityNodeInfo): TableInfo? {
        var rowCount = 0
        var colCount = 0
        val cells = mutableListOf<String>()
        
        traverseNodes(node) { child ->
            val text = child.text?.toString()
            if (text != null) {
                cells.add(text)
            }
        }
        
        if (cells.isEmpty()) return null
        
        // 估算行列数
        rowCount = kotlin.math.sqrt(cells.size.toDouble()).toInt().coerceAtLeast(1)
        colCount = (cells.size / rowCount).coerceAtLeast(1)
        
        return TableInfo(rowCount, colCount, cells.take(20))
    }
    
    private fun extractUrl(text: String): String? {
        val pattern = Pattern.compile("""https?://[^\s<>"{}|\\^`\[\]]+""")
        val matcher = pattern.matcher(text)
        return if (matcher.find()) matcher.group() else null
    }
    
    private fun detectDocumentType(title: String?, paragraphs: List<String>): DocumentType {
        val content = (title ?: "") + paragraphs.joinToString(" ")
        val lowerContent = content.lowercase()
        
        return when {
            lowerContent.contains("合同") || lowerContent.contains("协议") -> DocumentType.CONTRACT
            lowerContent.contains("报告") || lowerContent.contains("report") -> DocumentType.REPORT
            lowerContent.contains("简历") || lowerContent.contains("resume") -> DocumentType.RESUME
            lowerContent.contains("方案") || lowerContent.contains("计划") -> DocumentType.PROPOSAL
            lowerContent.contains("说明") || lowerContent.contains("手册") -> DocumentType.MANUAL
            lowerContent.contains("会议") || lowerContent.contains("纪要") -> DocumentType.MEETING_NOTES
            lowerContent.contains("ppt") || lowerContent.contains("演示") -> DocumentType.PRESENTATION
            lowerContent.contains("表格") || lowerContent.contains("excel") -> DocumentType.SPREADSHEET
            else -> DocumentType.GENERAL
        }
    }
    
    // ==================== ✏️ 文档编辑自动化 ====================
    
    /**
     * ✏️ 生成编辑操作
     */
    fun generateEditOperations(
        currentContent: DocumentContent,
        editRequest: EditRequest
    ): List<EditOperation> {
        LogManager.d(TAG, "✏️ 生成编辑操作: ${editRequest.type}")
        
        val operations = mutableListOf<EditOperation>()
        
        when (editRequest.type) {
            EditType.INSERT_TEXT -> {
                operations.add(EditOperation(
                    type = EditOperationType.CLICK,
                    description = "点击插入位置",
                    target = editRequest.position
                ))
                operations.add(EditOperation(
                    type = EditOperationType.INPUT,
                    description = "输入文本",
                    value = editRequest.content
                ))
            }
            
            EditType.REPLACE_TEXT -> {
                operations.add(EditOperation(
                    type = EditOperationType.SELECT,
                    description = "选择要替换的文本",
                    target = editRequest.targetText
                ))
                operations.add(EditOperation(
                    type = EditOperationType.INPUT,
                    description = "输入新文本",
                    value = editRequest.content
                ))
            }
            
            EditType.DELETE_TEXT -> {
                operations.add(EditOperation(
                    type = EditOperationType.SELECT,
                    description = "选择要删除的文本",
                    target = editRequest.targetText
                ))
                operations.add(EditOperation(
                    type = EditOperationType.DELETE,
                    description = "删除选中内容"
                ))
            }
            
            EditType.FORMAT_TEXT -> {
                operations.add(EditOperation(
                    type = EditOperationType.SELECT,
                    description = "选择要格式化的文本",
                    target = editRequest.targetText
                ))
                operations.add(EditOperation(
                    type = EditOperationType.FORMAT,
                    description = "应用格式",
                    value = editRequest.formatStyle
                ))
            }
            
            EditType.ADD_IMAGE -> {
                operations.add(EditOperation(
                    type = EditOperationType.CLICK,
                    description = "点击插入图片按钮"
                ))
                operations.add(EditOperation(
                    type = EditOperationType.SELECT_FILE,
                    description = "选择图片文件",
                    value = editRequest.content
                ))
            }
        }
        
        return operations
    }
    
    // ==================== 🔄 文档格式转换 ====================
    
    /**
     * 🔄 获取格式转换步骤
     */
    fun getFormatConversionSteps(
        sourceFormat: DocumentFormat,
        targetFormat: DocumentFormat
    ): List<ConversionStep> {
        LogManager.d(TAG, "🔄 格式转换: $sourceFormat -> $targetFormat")
        
        val steps = mutableListOf<ConversionStep>()
        
        // 通用步骤
        steps.add(ConversionStep(1, "打开源文档", "打开要转换的文档"))
        
        when {
            // 导出为PDF
            targetFormat == DocumentFormat.PDF -> {
                steps.add(ConversionStep(2, "打开导出菜单", "点击文件->导出/另存为"))
                steps.add(ConversionStep(3, "选择PDF格式", "选择PDF作为目标格式"))
                steps.add(ConversionStep(4, "确认导出", "点击确定/导出按钮"))
            }
            
            // 转为Word
            targetFormat == DocumentFormat.DOCX -> {
                steps.add(ConversionStep(2, "打开另存为", "点击文件->另存为"))
                steps.add(ConversionStep(3, "选择Word格式", "选择.docx格式"))
                steps.add(ConversionStep(4, "保存文件", "点击保存"))
            }
            
            // 转为图片
            targetFormat == DocumentFormat.IMAGE -> {
                steps.add(ConversionStep(2, "截图或导出", "使用截图或导出图片功能"))
                steps.add(ConversionStep(3, "选择图片格式", "选择PNG/JPG格式"))
                steps.add(ConversionStep(4, "保存图片", "保存到指定位置"))
            }
            
            else -> {
                steps.add(ConversionStep(2, "选择导出格式", "选择目标格式"))
                steps.add(ConversionStep(3, "执行转换", "确认转换"))
            }
        }
        
        return steps
    }
    
    // ==================== 📤 文档分享自动化 ====================
    
    /**
     * 📤 生成分享操作
     */
    fun generateShareOperations(
        shareRequest: ShareRequest
    ): List<ShareOperation> {
        LogManager.d(TAG, "📤 生成分享操作: ${shareRequest.method}")
        
        val operations = mutableListOf<ShareOperation>()
        
        when (shareRequest.method) {
            ShareMethod.WECHAT -> {
                operations.add(ShareOperation("点击分享按钮", "找到并点击分享/发送按钮"))
                operations.add(ShareOperation("选择微信", "在分享选项中选择微信"))
                operations.add(ShareOperation("选择联系人", "选择要发送的联系人或群"))
                operations.add(ShareOperation("确认发送", "点击发送按钮"))
            }
            
            ShareMethod.EMAIL -> {
                operations.add(ShareOperation("点击分享按钮", "找到并点击分享按钮"))
                operations.add(ShareOperation("选择邮件", "选择通过邮件发送"))
                operations.add(ShareOperation("填写收件人", "输入收件人邮箱"))
                operations.add(ShareOperation("编辑邮件", "添加主题和正文"))
                operations.add(ShareOperation("发送邮件", "点击发送"))
            }
            
            ShareMethod.LINK -> {
                operations.add(ShareOperation("生成链接", "点击生成分享链接"))
                operations.add(ShareOperation("复制链接", "复制生成的链接"))
                operations.add(ShareOperation("发送链接", "将链接发送给他人"))
            }
            
            ShareMethod.QR_CODE -> {
                operations.add(ShareOperation("生成二维码", "点击生成二维码"))
                operations.add(ShareOperation("展示二维码", "展示给他人扫描"))
            }
            
            ShareMethod.AIRDROP -> {
                operations.add(ShareOperation("打开AirDrop", "点击AirDrop分享"))
                operations.add(ShareOperation("选择设备", "选择要接收的设备"))
                operations.add(ShareOperation("等待接收", "等待对方确认接收"))
            }
        }
        
        return operations
    }
    
    // ==================== 📧 邮件内容理解 ====================
    
    /**
     * 📧 分析邮件内容
     */
    fun analyzeEmailContent(rootNode: AccessibilityNodeInfo?): EmailContent {
        if (rootNode == null) return EmailContent.empty()
        
        LogManager.d(TAG, "📧 分析邮件内容")
        
        var subject: String? = null
        var sender: String? = null
        var recipients: List<String> = emptyList()
        var body: String? = null
        var date: String? = null
        val attachments = mutableListOf<AttachmentInfo>()
        
        val allText = mutableListOf<String>()
        
        traverseNodes(rootNode) { node ->
            val text = node.text?.toString() ?: ""
            val hint = node.hintText?.toString() ?: ""
            val resourceId = node.viewIdResourceName ?: ""
            
            allText.add(text)
            
            // 提取主题
            if (subject == null && (resourceId.contains("subject", ignoreCase = true) ||
                hint.contains("主题") || hint.contains("subject"))) {
                subject = text
            }
            
            // 提取发件人
            if (sender == null && (resourceId.contains("from", ignoreCase = true) ||
                text.contains("发件人") || text.contains("From:"))) {
                sender = extractEmail(text) ?: text
            }
            
            // 提取收件人
            if (resourceId.contains("to", ignoreCase = true) ||
                text.contains("收件人") || text.contains("To:")) {
                extractEmail(text)?.let { recipients = listOf(it) }
            }
            
            // 提取日期
            if (date == null && isDateLike(text)) {
                date = text
            }
            
            // 提取附件
            if (text.contains("附件") || resourceId.contains("attachment")) {
                attachments.add(AttachmentInfo(text, detectFileType(text)))
            }
        }
        
        // 提取正文（最长的文本块）
        body = allText.maxByOrNull { it.length }?.takeIf { it.length > 20 }
        
        // 分析邮件类型和紧急程度
        val emailType = classifyEmail(subject, body)
        val urgency = detectUrgency(subject, body)
        
        // 提取关键信息
        val keyInfo = extractKeyInfo(body)
        
        return EmailContent(
            subject = subject ?: "无主题",
            sender = sender,
            recipients = recipients,
            body = body ?: "",
            date = date,
            attachments = attachments,
            emailType = emailType,
            urgency = urgency,
            keyInfo = keyInfo
        )
    }
    
    private fun extractEmail(text: String): String? {
        val pattern = Pattern.compile("""[\w.-]+@[\w.-]+\.\w+""")
        val matcher = pattern.matcher(text)
        return if (matcher.find()) matcher.group() else null
    }
    
    private fun isDateLike(text: String): Boolean {
        return text.matches(Regex(""".*\d{4}[年/-]\d{1,2}[月/-]\d{1,2}.*""")) ||
               text.matches(Regex(""".*\d{1,2}:\d{2}.*"""))
    }
    
    private fun detectFileType(text: String): FileType {
        val lowerText = text.lowercase()
        return when {
            lowerText.contains(".pdf") -> FileType.PDF
            lowerText.contains(".doc") || lowerText.contains(".docx") -> FileType.WORD
            lowerText.contains(".xls") || lowerText.contains(".xlsx") -> FileType.EXCEL
            lowerText.contains(".ppt") || lowerText.contains(".pptx") -> FileType.PPT
            lowerText.contains(".jpg") || lowerText.contains(".png") || lowerText.contains(".gif") -> FileType.IMAGE
            lowerText.contains(".zip") || lowerText.contains(".rar") -> FileType.ARCHIVE
            else -> FileType.OTHER
        }
    }
    
    // ==================== 🏷️ 邮件自动分类 ====================
    
    /**
     * 🏷️ 分类邮件
     */
    fun classifyEmail(subject: String?, body: String?): EmailCategory {
        val content = "${subject ?: ""} ${body ?: ""}".lowercase()
        
        // 应用分类规则
        for (rule in emailClassificationRules) {
            if (rule.keywords.any { content.contains(it) }) {
                return rule.category
            }
        }
        
        // 默认分类逻辑
        return when {
            content.contains("会议") || content.contains("meeting") -> EmailCategory.MEETING
            content.contains("发票") || content.contains("报销") -> EmailCategory.FINANCE
            content.contains("项目") || content.contains("任务") || content.contains("进度") -> EmailCategory.PROJECT
            content.contains("招聘") || content.contains("面试") || content.contains("简历") -> EmailCategory.HR
            content.contains("订单") || content.contains("发货") || content.contains("物流") -> EmailCategory.ORDER
            content.contains("广告") || content.contains("促销") || content.contains("优惠") -> EmailCategory.PROMOTION
            content.contains("验证码") || content.contains("密码") -> EmailCategory.VERIFICATION
            content.contains("通知") || content.contains("公告") -> EmailCategory.NOTIFICATION
            else -> EmailCategory.OTHER
        }
    }
    
    /**
     * 📊 检测紧急程度
     */
    private fun detectUrgency(subject: String?, body: String?): EmailUrgency {
        val content = "${subject ?: ""} ${body ?: ""}".lowercase()
        
        return when {
            content.contains("紧急") || content.contains("urgent") || content.contains("asap") ||
            content.contains("立即") || content.contains("马上") -> EmailUrgency.URGENT
            
            content.contains("重要") || content.contains("important") ||
            content.contains("请注意") -> EmailUrgency.HIGH
            
            content.contains("请查收") || content.contains("fyi") ||
            content.contains("供参考") -> EmailUrgency.LOW
            
            else -> EmailUrgency.NORMAL
        }
    }
    
    /**
     * 🔑 提取关键信息
     */
    private fun extractKeyInfo(body: String?): Map<String, String> {
        if (body == null) return emptyMap()
        
        val keyInfo = mutableMapOf<String, String>()
        
        // 提取日期时间
        val datePattern = Pattern.compile("""\d{4}[年/-]\d{1,2}[月/-]\d{1,2}[日]?\s*\d{0,2}:?\d{0,2}""")
        datePattern.matcher(body).let { if (it.find()) keyInfo["日期"] = it.group() }
        
        // 提取金额
        val amountPattern = Pattern.compile("""[¥￥$]\s*\d+(?:\.\d{1,2})?|\d+(?:\.\d{1,2})?\s*元""")
        amountPattern.matcher(body).let { if (it.find()) keyInfo["金额"] = it.group() }
        
        // 提取电话
        val phonePattern = Pattern.compile("""\d{11}|(\d{3,4}[-\s]?\d{7,8})""")
        phonePattern.matcher(body).let { if (it.find()) keyInfo["电话"] = it.group() }
        
        // 提取地址
        val addressPattern = Pattern.compile("""(?:地址[：:])?\s*(.{2,4}(?:省|市|区|县).{5,30})""")
        addressPattern.matcher(body).let { if (it.find()) keyInfo["地址"] = it.group(1) ?: it.group() }
        
        return keyInfo
    }
    
    /**
     * ➕ 添加分类规则
     */
    fun addClassificationRule(rule: EmailClassificationRule) {
        emailClassificationRules.add(rule)
    }
    
    private fun initDefaultClassificationRules() {
        emailClassificationRules.addAll(listOf(
            EmailClassificationRule(EmailCategory.MEETING, listOf("会议邀请", "日程", "meeting")),
            EmailClassificationRule(EmailCategory.FINANCE, listOf("发票", "报销", "付款")),
            EmailClassificationRule(EmailCategory.PROJECT, listOf("项目进度", "任务分配", "deadline")),
            EmailClassificationRule(EmailCategory.PROMOTION, listOf("限时", "折扣", "优惠券"))
        ))
    }
    
    // ==================== 💬 邮件自动回复 ====================
    
    /**
     * 💬 生成自动回复
     */
    fun generateAutoReply(email: EmailContent): EmailAutoReplyResult {
        LogManager.d(TAG, "💬 生成自动回复: ${email.emailType}")
        
        // 获取模板
        val templates = autoReplyTemplates[email.emailType] 
            ?: autoReplyTemplates[EmailCategory.OTHER] 
            ?: listOf("感谢您的邮件，我会尽快回复。")
        
        // 选择模板并填充
        var reply = templates.random()
        
        // 替换变量
        reply = reply.replace("{sender}", email.sender ?: "您")
        reply = reply.replace("{subject}", email.subject)
        
        // 根据紧急程度调整
        val prefix = when (email.urgency) {
            EmailUrgency.URGENT -> "收到您的紧急邮件，"
            EmailUrgency.HIGH -> "收到您的重要邮件，"
            else -> ""
        }
        
        return EmailAutoReplyResult(
            reply = prefix + reply,
            emailCategory = email.emailType,
            confidence = 0.8f,
            suggestedActions = getSuggestedActions(email)
        )
    }
    
    private fun getSuggestedActions(email: EmailContent): List<String> {
        return when (email.emailType) {
            EmailCategory.MEETING -> listOf("接受会议", "拒绝会议", "建议其他时间")
            EmailCategory.PROJECT -> listOf("回复进度", "请求延期", "确认收到")
            EmailCategory.FINANCE -> listOf("确认收到", "提供发票信息", "查询状态")
            EmailCategory.ORDER -> listOf("确认订单", "查询物流", "申请售后")
            else -> listOf("回复确认", "转发相关人", "标记重要")
        }
    }
    
    private fun initDefaultReplyTemplates() {
        autoReplyTemplates[EmailCategory.MEETING] = listOf(
            "感谢您的会议邀请，我会准时参加。",
            "收到会议通知，我已添加到日程中。",
            "好的，我会参加此次会议。"
        )
        autoReplyTemplates[EmailCategory.PROJECT] = listOf(
            "收到，我会尽快处理并回复进度。",
            "感谢通知，我已了解项目情况。",
            "好的，我会按时完成相关任务。"
        )
        autoReplyTemplates[EmailCategory.FINANCE] = listOf(
            "收到，我会尽快处理相关事宜。",
            "感谢通知，如有问题我会及时联系您。"
        )
        autoReplyTemplates[EmailCategory.OTHER] = listOf(
            "收到您的邮件，感谢！",
            "感谢您的来信，我已知悉。",
            "好的，收到！"
        )
    }
    
    // ==================== 📎 邮件附件处理 ====================
    
    /**
     * 📎 分析附件
     */
    fun analyzeAttachments(attachments: List<AttachmentInfo>): AttachmentAnalysis {
        val totalSize = attachments.size
        val typeDistribution = attachments.groupBy { it.fileType }.mapValues { it.value.size }
        
        val suggestions = mutableListOf<String>()
        
        if (attachments.any { it.fileType == FileType.ARCHIVE }) {
            suggestions.add("包含压缩文件，建议解压后查看")
        }
        if (attachments.size > 5) {
            suggestions.add("附件较多，建议分类整理")
        }
        if (attachments.any { it.fileType == FileType.PDF }) {
            suggestions.add("包含PDF文件，可直接预览")
        }
        
        return AttachmentAnalysis(
            totalCount = totalSize,
            typeDistribution = typeDistribution,
            suggestions = suggestions
        )
    }
    
    /**
     * 📥 生成附件下载操作
     */
    fun generateDownloadOperations(attachment: AttachmentInfo): List<String> {
        return listOf(
            "点击附件名称",
            "选择下载位置",
            "等待下载完成",
            "打开文件查看"
        )
    }
    
    // ==================== 🔧 辅助方法 ====================
    
    private fun traverseNodes(node: AccessibilityNodeInfo, action: (AccessibilityNodeInfo) -> Unit) {
        action(node)
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { traverseNodes(it, action) }
        }
    }
}

// ==================== 📦 数据类定义 ====================

// 文档内容
data class DocumentContent(
    val title: String,
    val documentType: DocumentType,
    val paragraphs: List<String>,
    val headings: List<HeadingInfo>,
    val tables: List<TableInfo>,
    val images: List<ImageInfo>,
    val links: List<LinkInfo>,
    val wordCount: Int,
    val extractedAt: Long
) {
    companion object {
        fun empty() = DocumentContent("", DocumentType.GENERAL, emptyList(), emptyList(), emptyList(), emptyList(), emptyList(), 0, 0)
    }
}

enum class DocumentType { CONTRACT, REPORT, RESUME, PROPOSAL, MANUAL, MEETING_NOTES, PRESENTATION, SPREADSHEET, GENERAL }

data class HeadingInfo(val text: String, val level: Int)
data class TableInfo(val rowCount: Int, val colCount: Int, val cells: List<String>)
data class ImageInfo(val description: String, val isClickable: Boolean)
data class LinkInfo(val text: String, val url: String?)
data class DocumentRecord(val title: String, val type: DocumentType, val accessTime: Long)

// 编辑操作
data class EditRequest(
    val type: EditType,
    val content: String? = null,
    val targetText: String? = null,
    val position: String? = null,
    val formatStyle: String? = null
)

enum class EditType { INSERT_TEXT, REPLACE_TEXT, DELETE_TEXT, FORMAT_TEXT, ADD_IMAGE }

data class EditOperation(
    val type: EditOperationType,
    val description: String,
    val target: String? = null,
    val value: String? = null
)

enum class EditOperationType { CLICK, INPUT, SELECT, DELETE, FORMAT, SELECT_FILE }

// 格式转换
enum class DocumentFormat { PDF, DOCX, XLSX, PPTX, TXT, HTML, IMAGE }
data class ConversionStep(val step: Int, val name: String, val description: String)

// 分享操作
data class ShareRequest(val method: ShareMethod, val recipients: List<String> = emptyList())
enum class ShareMethod { WECHAT, EMAIL, LINK, QR_CODE, AIRDROP }
data class ShareOperation(val name: String, val description: String)

// 邮件内容
data class EmailContent(
    val subject: String,
    val sender: String?,
    val recipients: List<String>,
    val body: String,
    val date: String?,
    val attachments: List<AttachmentInfo>,
    val emailType: EmailCategory,
    val urgency: EmailUrgency,
    val keyInfo: Map<String, String>
) {
    companion object {
        fun empty() = EmailContent("", null, emptyList(), "", null, emptyList(), EmailCategory.OTHER, EmailUrgency.NORMAL, emptyMap())
    }
}

// 邮件分类
enum class EmailCategory { MEETING, PROJECT, FINANCE, HR, ORDER, PROMOTION, VERIFICATION, NOTIFICATION, OTHER }
enum class EmailUrgency { URGENT, HIGH, NORMAL, LOW }
data class EmailClassificationRule(val category: EmailCategory, val keywords: List<String>)

// 邮件自动回复结果
data class EmailAutoReplyResult(
    val reply: String,
    val emailCategory: EmailCategory,
    val confidence: Float,
    val suggestedActions: List<String>
)

// 附件
data class AttachmentInfo(val name: String, val fileType: FileType)
enum class FileType { PDF, WORD, EXCEL, PPT, IMAGE, ARCHIVE, OTHER }
data class AttachmentAnalysis(
    val totalCount: Int,
    val typeDistribution: Map<FileType, Int>,
    val suggestions: List<String>
)

// 处理状态
data class EmailProcessingStatus(
    val emailId: String,
    val status: String,
    val progress: Float
)
