package com.example.xihe.scenarios

import android.content.Context
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.core.ActionExecutor
import com.example.xihe.core.AutomationEngine
import com.example.xihe.core.LLMClient
import com.example.xihe.core.ScreenAnalyzer
import com.example.xihe.tools.ToolRegistry
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.delay
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

object OfficeScenario {
    private const val TAG = "OfficeScenario"

    fun detectOffice(userInput: String): OfficeTaskRequest? {
        val input = userInput.trim()

        val patterns = listOf(
            Regex("""在?\s*(wps|WPS|office|Office)\s*(新建|创建|写|编辑|打开)\s*(.+)"""),
            Regex("""(新建|创建|写|编辑|打开)\s*(.+?)\s*在?\s*(wps|WPS|office|Office)"""),
            Regex("""(写|编辑)\s*(一份|一个)?\s*(.+)""")
        )

        for (pattern in patterns) {
            val match = pattern.find(input) ?: continue
            val groups = match.groupValues

            val app = when {
                groups.any { it.equals("wps", ignoreCase = true) } -> OfficeTargetApp.WPS
                groups.any { it.equals("office", ignoreCase = true) } -> OfficeTargetApp.OFFICE
                else -> OfficeTargetApp.WPS
            }

            val action = when {
                input.contains("打开") -> OfficeTaskAction.OPEN_DOCUMENT
                input.contains("编辑") || input.contains("写") -> OfficeTaskAction.EDIT
                input.contains("新建") || input.contains("创建") -> OfficeTaskAction.CREATE_DOCUMENT
                else -> OfficeTaskAction.CREATE_DOCUMENT
            }

            val documentName = groups.lastOrNull()?.trim().orEmpty()
                .replace(Regex("^(一份|一个)"), "")
                .trim()

            if (documentName.isEmpty() || documentName.length < 2) continue

            return OfficeTaskRequest(
                app = app,
                action = action,
                documentName = documentName
            )
        }

        return null
    }

    suspend fun executeOfficeTask(
        request: OfficeTaskRequest,
        context: Context,
        onProgress: (String) -> Unit
    ): ScenarioResult {
        val appPackage = when (request.app) {
            OfficeTargetApp.WPS -> "cn.wps.moffice_eng"
            OfficeTargetApp.OFFICE -> "com.microsoft.office.officehubrow"
        }

        return try {
            onProgress("正在打开${request.app.displayName}...")
            val launchResult = ToolRegistry.executeTool(
                com.example.xihe.tools.ToolCall(
                    "launch_app",
                    buildJsonObject { put("appNameOrPackage", appPackage) }
                )
            )

            if (!launchResult.success) {
                return ScenarioResult.Failure("无法打开${request.app.displayName}")
            }

            delay(3500)

            val service = CoreAccessibilityService.instance
                ?: return ScenarioResult.Failure("无障碍服务未启动")

            val executor = ActionExecutor(service, context)
            val llmClient = LLMClient(
                AutomationEngine.baseUrl,
                AutomationEngine.apiKey,
                AutomationEngine.modelName,
                AutomationEngine.providerId
            )

            val goals = when (request.action) {
                OfficeTaskAction.CREATE_DOCUMENT -> listOf(
                    "找到并点击新建按钮，创建一个空白文档",
                    "如果出现模板选择，选择空白文档",
                    "将文档命名为：${request.documentName} 并保存（如果界面要求保存）"
                )
                OfficeTaskAction.OPEN_DOCUMENT -> listOf(
                    "找到打开或最近文档列表，搜索并打开文档：${request.documentName}"
                )
                OfficeTaskAction.EDIT -> listOf(
                    "找到并打开或新建文档：${request.documentName}",
                    "进入编辑模式（如果需要）"
                )
            }

            for (goal in goals) {
                onProgress(goal)
                val root = service.rootInActiveWindow
                if (root == null) {
                    delay(1200)
                    continue
                }

                val pkg = root.packageName?.toString() ?: appPackage
                val screenState = ScreenAnalyzer.analyze(root, pkg)
                if (screenState == null) {
                    delay(1200)
                    continue
                }

                val cmd = llmClient.think(screenState, goal, emptyList())
                executor.execute(cmd, root)
                delay(2000)
            }

            ScenarioResult.Success("已在${request.app.displayName}处理文档：${request.documentName}")
        } catch (e: Exception) {
            LogManager.e(TAG, "办公场景执行失败", e)
            ScenarioResult.Failure("办公操作失败: ${e.message}")
        }
    }
}

enum class OfficeTargetApp(val displayName: String) {
    WPS("WPS"),
    OFFICE("Office")
}

enum class OfficeTaskAction {
    CREATE_DOCUMENT,
    OPEN_DOCUMENT,
    EDIT
}

data class OfficeTaskRequest(
    val app: OfficeTargetApp,
    val action: OfficeTaskAction,
    val documentName: String
)
