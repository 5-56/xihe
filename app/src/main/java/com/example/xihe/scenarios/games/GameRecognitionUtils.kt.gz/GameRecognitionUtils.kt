package com.example.xihe.scenarios.games

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import com.example.xihe.utils.LogManager
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * 游戏识别工具类
 * 
 * 提供统一的图像识别、棋盘检测、牌面识别等功能
 */
object GameRecognitionUtils {
    
    private const val TAG = "GameRecognitionUtils"
    
    // ==================== 棋盘检测 ====================
    
    /**
     * 智能检测棋盘区域
     * 
     * 使用边缘检测 + 网格线识别来定位棋盘
     */
    fun detectBoardRect(
        bitmap: Bitmap,
        gridSize: Int = 15,  // 棋盘格数（五子棋15x15，围棋19x19）
        minBoardRatio: Float = 0.3f,  // 棋盘最小占屏幕比例
        maxBoardRatio: Float = 0.95f   // 棋盘最大占屏幕比例
    ): Rect? {
        val width = bitmap.width
        val height = bitmap.height
        
        // 1. 转换为灰度图并进行边缘检测
        val edges = detectEdges(bitmap)
        
        // 2. 检测水平和垂直线
        val horizontalLines = detectHorizontalLines(edges, width, height)
        val verticalLines = detectVerticalLines(edges, width, height)
        
        LogManager.d(TAG, "检测到水平线: ${horizontalLines.size}, 垂直线: ${verticalLines.size}")
        
        // 3. 如果检测到足够的网格线，使用网格线定位
        if (horizontalLines.size >= gridSize - 2 && verticalLines.size >= gridSize - 2) {
            val left = verticalLines.minOrNull() ?: 0
            val right = verticalLines.maxOrNull() ?: width
            val top = horizontalLines.minOrNull() ?: 0
            val bottom = horizontalLines.maxOrNull() ?: height
            
            // 验证棋盘比例
            val boardWidth = right - left
            val boardHeight = bottom - top
            val ratio = min(boardWidth, boardHeight).toFloat() / max(width, height)
            
            if (ratio in minBoardRatio..maxBoardRatio) {
                LogManager.d(TAG, "✅ 通过网格线检测到棋盘: left=$left, top=$top, right=$right, bottom=$bottom")
                return Rect(left, top, right, bottom)
            }
        }
        
        // 4. 备选方案：使用颜色区域检测
        val colorBasedRect = detectBoardByColor(bitmap, gridSize)
        if (colorBasedRect != null) {
            LogManager.d(TAG, "✅ 通过颜色检测到棋盘")
            return colorBasedRect
        }
        
        // 5. 最后备选：假设棋盘在屏幕中央
        LogManager.d(TAG, "⚠️ 使用默认中央棋盘位置")
        val size = (min(width, height) * 0.85f).toInt()
        val left = (width - size) / 2
        val top = (height - size) / 2
        return Rect(left, top, left + size, top + size)
    }
    
    /**
     * 🔍 边缘检测（Sobel算子简化版）
     */
    private fun detectEdges(bitmap: Bitmap): Array<IntArray> {
        val width = bitmap.width
        val height = bitmap.height
        val result = Array(height) { IntArray(width) }
        
        // 转换为灰度
        val gray = Array(height) { y ->
            IntArray(width) { x ->
                val pixel = bitmap.getPixel(x, y)
                (Color.red(pixel) * 0.299 + Color.green(pixel) * 0.587 + Color.blue(pixel) * 0.114).toInt()
            }
        }
        
        // Sobel边缘检测
        for (y in 1 until height - 1) {
            for (x in 1 until width - 1) {
                val gx = (-gray[y-1][x-1] + gray[y-1][x+1] 
                         - 2*gray[y][x-1] + 2*gray[y][x+1]
                         - gray[y+1][x-1] + gray[y+1][x+1])
                         
                val gy = (-gray[y-1][x-1] - 2*gray[y-1][x] - gray[y-1][x+1]
                         + gray[y+1][x-1] + 2*gray[y+1][x] + gray[y+1][x+1])
                
                result[y][x] = min(255, sqrt((gx * gx + gy * gy).toDouble()).toInt())
            }
        }
        
        return result
    }
    
    /**
     * ➖ 检测水平线
     */
    private fun detectHorizontalLines(
        edges: Array<IntArray>,
        width: Int,
        height: Int,
        threshold: Int = 100,
        minLineRatio: Float = 0.5f
    ): List<Int> {
        val lines = mutableListOf<Int>()
        val minLineLength = (width * minLineRatio).toInt()
        
        for (y in 0 until height) {
            var lineLength = 0
            for (x in 0 until width) {
                if (edges[y][x] > threshold) {
                    lineLength++
                } else {
                    if (lineLength > minLineLength) {
                        lines.add(y)
                        break
                    }
                    lineLength = 0
                }
            }
            if (lineLength > minLineLength) {
                lines.add(y)
            }
        }
        
        // 合并相近的线
        return mergeCloseLines(lines, height / 50)
    }
    
    /**
     * | 检测垂直线
     */
    private fun detectVerticalLines(
        edges: Array<IntArray>,
        width: Int,
        height: Int,
        threshold: Int = 100,
        minLineRatio: Float = 0.5f
    ): List<Int> {
        val lines = mutableListOf<Int>()
        val minLineLength = (height * minLineRatio).toInt()
        
        for (x in 0 until width) {
            var lineLength = 0
            for (y in 0 until height) {
                if (edges[y][x] > threshold) {
                    lineLength++
                } else {
                    if (lineLength > minLineLength) {
                        lines.add(x)
                        break
                    }
                    lineLength = 0
                }
            }
            if (lineLength > minLineLength) {
                lines.add(x)
            }
        }
        
        return mergeCloseLines(lines, width / 50)
    }
    
    /**
     * 🔗 合并相近的线
     */
    private fun mergeCloseLines(lines: List<Int>, threshold: Int): List<Int> {
        if (lines.isEmpty()) return emptyList()
        
        val sorted = lines.sorted()
        val merged = mutableListOf(sorted[0])
        
        for (i in 1 until sorted.size) {
            if (sorted[i] - merged.last() > threshold) {
                merged.add(sorted[i])
            }
        }
        
        return merged
    }
    
    /**
     * 🎨 通过颜色检测棋盘（木色/棕色区域）
     */
    private fun detectBoardByColor(bitmap: Bitmap, gridSize: Int): Rect? {
        val width = bitmap.width
        val height = bitmap.height
        
        // 棋盘常见颜色范围（木色/棕色）
        var minX = width
        var maxX = 0
        var minY = height
        var maxY = 0
        var boardPixels = 0
        
        val step = 5  // 采样步长
        for (y in 0 until height step step) {
            for (x in 0 until width step step) {
                val pixel = bitmap.getPixel(x, y)
                val r = Color.red(pixel)
                val g = Color.green(pixel)
                val b = Color.blue(pixel)
                
                // 检测木色/棕色/浅色棋盘
                val isWoodColor = r in 150..240 && g in 120..200 && b in 80..160 && 
                                  r > g && g > b
                val isLightBoard = r in 200..255 && g in 200..255 && b in 180..240 &&
                                   abs(r - g) < 30 && abs(g - b) < 40
                
                if (isWoodColor || isLightBoard) {
                    minX = min(minX, x)
                    maxX = max(maxX, x)
                    minY = min(minY, y)
                    maxY = max(maxY, y)
                    boardPixels++
                }
            }
        }
        
        // 验证检测结果
        val boardWidth = maxX - minX
        val boardHeight = maxY - minY
        val boardArea = boardWidth * boardHeight
        val screenArea = width * height
        
        if (boardArea > screenArea * 0.1 && boardArea < screenArea * 0.9) {
            // 确保是正方形（允许10%误差）
            val ratio = boardWidth.toFloat() / boardHeight
            if (ratio in 0.9f..1.1f) {
                return Rect(minX, minY, maxX, maxY)
            }
        }
        
        return null
    }
    
    // ==================== ⚫⚪ 棋子识别 ====================
    
    /**
     * 🔍 识别棋子颜色（改进版）
     * 
     * 使用多点采样和颜色聚类来提高准确率
     */
    fun recognizePieceColor(
        bitmap: Bitmap,
        centerX: Int,
        centerY: Int,
        sampleRadius: Int = 8
    ): PieceColor {
        val samples = mutableListOf<Triple<Int, Int, Int>>()  // R, G, B
        
        // 多点采样
        for (dy in -sampleRadius..sampleRadius step 2) {
            for (dx in -sampleRadius..sampleRadius step 2) {
                val x = (centerX + dx).coerceIn(0, bitmap.width - 1)
                val y = (centerY + dy).coerceIn(0, bitmap.height - 1)
                
                // 只采样中心区域（圆形）
                if (dx * dx + dy * dy <= sampleRadius * sampleRadius) {
                    val pixel = bitmap.getPixel(x, y)
                    samples.add(Triple(Color.red(pixel), Color.green(pixel), Color.blue(pixel)))
                }
            }
        }
        
        if (samples.isEmpty()) return PieceColor.EMPTY
        
        // 计算平均颜色
        val avgR = samples.map { it.first }.average()
        val avgG = samples.map { it.second }.average()
        val avgB = samples.map { it.third }.average()
        val brightness = (avgR + avgG + avgB) / 3
        
        // 计算颜色方差（用于判断是否是棋子而非棋盘）
        val variance = samples.map { 
            val b = (it.first + it.second + it.third) / 3.0
            (b - brightness) * (b - brightness)
        }.average()
        
        // 方差太大说明不是实心棋子
        if (variance > 1000) {
            return PieceColor.EMPTY
        }
        
        // 判断颜色
        return when {
            brightness < 60 -> PieceColor.BLACK      // 黑棋
            brightness > 200 -> PieceColor.WHITE     // 白棋
            brightness < 100 && variance < 500 -> PieceColor.BLACK  // 深色棋子
            brightness > 180 && variance < 500 -> PieceColor.WHITE  // 浅色棋子
            else -> PieceColor.EMPTY                 // 空位
        }
    }
    
    enum class PieceColor {
        BLACK, WHITE, EMPTY
    }
    
    // ==================== 🃏 扑克牌识别 ====================
    
    /**
     * 🔍 识别扑克牌面值
     * 
     * 支持的牌面：3-10, J, Q, K, A, 2, 小王, 大王
     */
    data class CardInfo(
        val value: String,       // 牌面值
        val suit: String?,       // 花色（可选）
        val position: Rect,      // 位置
        val confidence: Float    // 置信度
    )
    
    /**
     * 🎴 从OCR结果中解析扑克牌
     */
    fun parseCardsFromOCR(
        ocrText: String,
        textBlocks: List<TextBlockInfo>
    ): List<CardInfo> {
        val cards = mutableListOf<CardInfo>()
        
        // 牌面匹配模式
        val cardPatterns = mapOf(
            "大王" to listOf("大王", "大", "JOKER", "BIG"),
            "小王" to listOf("小王", "小", "joker", "SMALL"),
            "2" to listOf("2", "二"),
            "A" to listOf("A", "1", "一"),
            "K" to listOf("K", "13"),
            "Q" to listOf("Q", "12"),
            "J" to listOf("J", "11"),
            "10" to listOf("10", "十"),
            "9" to listOf("9", "九"),
            "8" to listOf("8", "八"),
            "7" to listOf("7", "七"),
            "6" to listOf("6", "六"),
            "5" to listOf("5", "五"),
            "4" to listOf("4", "四"),
            "3" to listOf("3", "三")
        )
        
        for (block in textBlocks) {
            val text = block.text.uppercase().trim()
            
            for ((cardValue, patterns) in cardPatterns) {
                for (pattern in patterns) {
                    if (text.contains(pattern, ignoreCase = true)) {
                        cards.add(CardInfo(
                            value = cardValue,
                            suit = detectSuit(text),
                            position = block.bounds,
                            confidence = if (text == pattern) 1.0f else 0.8f
                        ))
                        break
                    }
                }
            }
        }
        
        // 去重（相近位置的牌只保留一张）
        return deduplicateCards(cards)
    }
    
    /**
     * 🔍 检测花色
     */
    private fun detectSuit(text: String): String? {
        return when {
            text.contains("♠") || text.contains("黑桃") -> "♠"
            text.contains("♥") || text.contains("红心") || text.contains("红桃") -> "♥"
            text.contains("♣") || text.contains("梅花") -> "♣"
            text.contains("♦") || text.contains("方块") -> "♦"
            else -> null
        }
    }
    
    /**
     * 🔄 去除重复的牌
     */
    private fun deduplicateCards(cards: List<CardInfo>): List<CardInfo> {
        if (cards.isEmpty()) return emptyList()
        
        val result = mutableListOf<CardInfo>()
        val sorted = cards.sortedBy { it.position.left }
        
        for (card in sorted) {
            val isDuplicate = result.any { existing ->
                val xOverlap = abs(existing.position.centerX() - card.position.centerX()) < 50
                val yOverlap = abs(existing.position.centerY() - card.position.centerY()) < 50
                xOverlap && yOverlap && existing.value == card.value
            }
            
            if (!isDuplicate) {
                result.add(card)
            }
        }
        
        return result
    }
    
    data class TextBlockInfo(
        val text: String,
        val bounds: Rect
    )
    
    // ==================== 🎮 通用游戏UI识别 ====================
    
    /**
     * 🔍 检测游戏按钮区域
     */
    fun detectButtonRegions(
        bitmap: Bitmap,
        minButtonSize: Int = 50,
        maxButtonSize: Int = 300
    ): List<Rect> {
        val width = bitmap.width
        val height = bitmap.height
        val buttons = mutableListOf<Rect>()
        
        // 扫描可能的按钮区域（通过颜色变化检测）
        val step = 20
        for (y in 0 until height - minButtonSize step step) {
            for (x in 0 until width - minButtonSize step step) {
                val region = analyzeRegion(bitmap, x, y, minButtonSize)
                if (region.isButton) {
                    // 扩展找到完整按钮边界
                    val fullBounds = expandButtonBounds(bitmap, x, y, region.avgColor, maxButtonSize)
                    if (fullBounds.width() in minButtonSize..maxButtonSize &&
                        fullBounds.height() in minButtonSize..maxButtonSize) {
                        buttons.add(fullBounds)
                    }
                }
            }
        }
        
        // 合并重叠区域
        return mergeOverlappingRects(buttons)
    }
    
    private data class RegionAnalysis(
        val isButton: Boolean,
        val avgColor: Int,
        val colorVariance: Float
    )
    
    private fun analyzeRegion(bitmap: Bitmap, startX: Int, startY: Int, size: Int): RegionAnalysis {
        var totalR = 0
        var totalG = 0
        var totalB = 0
        var count = 0
        
        for (y in startY until min(startY + size, bitmap.height)) {
            for (x in startX until min(startX + size, bitmap.width)) {
                val pixel = bitmap.getPixel(x, y)
                totalR += Color.red(pixel)
                totalG += Color.green(pixel)
                totalB += Color.blue(pixel)
                count++
            }
        }
        
        if (count == 0) return RegionAnalysis(false, 0, 0f)
        
        val avgR = totalR / count
        val avgG = totalG / count
        val avgB = totalB / count
        val avgColor = Color.rgb(avgR, avgG, avgB)
        
        // 计算颜色方差
        var variance = 0f
        for (y in startY until min(startY + size, bitmap.height)) {
            for (x in startX until min(startX + size, bitmap.width)) {
                val pixel = bitmap.getPixel(x, y)
                val dr = Color.red(pixel) - avgR
                val dg = Color.green(pixel) - avgG
                val db = Color.blue(pixel) - avgB
                variance += dr * dr + dg * dg + db * db
            }
        }
        variance /= count
        
        // 按钮通常颜色较均匀，且不是纯灰色
        val isButton = variance < 2000 && 
                       !(abs(avgR - avgG) < 10 && abs(avgG - avgB) < 10) &&
                       (avgR + avgG + avgB) / 3 in 50..220
        
        return RegionAnalysis(isButton, avgColor, variance)
    }
    
    private fun expandButtonBounds(
        bitmap: Bitmap,
        startX: Int,
        startY: Int,
        targetColor: Int,
        maxSize: Int
    ): Rect {
        val targetR = Color.red(targetColor)
        val targetG = Color.green(targetColor)
        val targetB = Color.blue(targetColor)
        val tolerance = 30
        
        fun isSimilarColor(x: Int, y: Int): Boolean {
            if (x < 0 || x >= bitmap.width || y < 0 || y >= bitmap.height) return false
            val pixel = bitmap.getPixel(x, y)
            return abs(Color.red(pixel) - targetR) < tolerance &&
                   abs(Color.green(pixel) - targetG) < tolerance &&
                   abs(Color.blue(pixel) - targetB) < tolerance
        }
        
        var left = startX
        var right = startX
        var top = startY
        var bottom = startY
        
        // 扩展边界
        while (left > 0 && left > startX - maxSize && isSimilarColor(left - 1, startY)) left--
        while (right < bitmap.width - 1 && right < startX + maxSize && isSimilarColor(right + 1, startY)) right++
        while (top > 0 && top > startY - maxSize && isSimilarColor(startX, top - 1)) top--
        while (bottom < bitmap.height - 1 && bottom < startY + maxSize && isSimilarColor(startX, bottom + 1)) bottom++
        
        return Rect(left, top, right, bottom)
    }
    
    private fun mergeOverlappingRects(rects: List<Rect>): List<Rect> {
        if (rects.isEmpty()) return emptyList()
        
        val result = mutableListOf<Rect>()
        val used = BooleanArray(rects.size)
        
        for (i in rects.indices) {
            if (used[i]) continue
            
            var merged = Rect(rects[i])
            used[i] = true
            
            var changed = true
            while (changed) {
                changed = false
                for (j in rects.indices) {
                    if (used[j]) continue
                    if (Rect.intersects(merged, rects[j])) {
                        merged.union(rects[j])
                        used[j] = true
                        changed = true
                    }
                }
            }
            
            result.add(merged)
        }
        
        return result
    }
}
