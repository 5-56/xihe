package com.example.xihe.scenarios

import android.view.accessibility.AccessibilityNodeInfo
import com.example.xihe.utils.LogManager

/**
 * 🎯 任务步骤定义
 * 
 * 定义各种日常自动化任务的执行步骤，供羲和参考执行
 * 当界面不匹配时，会智能分析界面并调整执行策略
 */
object TaskStepDefinitions {
    
    private const val TAG = "TaskStepDefinitions"
    
    // ==================== 📱 发信息步骤定义 ====================
    
    /**
     * 微信发消息步骤
     */
    val WECHAT_SEND_MESSAGE = TaskDefinition(
        taskName = "微信发消息",
        appPackage = "com.tencent.mm",
        steps = listOf(
            TaskStep(
                stepId = "launch_app",
                description = "启动微信",
                action = StepAction.LAUNCH_APP,
                expectedElements = listOf("微信", "通讯录", "发现", "我"),
                fallbackActions = listOf(
                    FallbackAction("等待启动", StepAction.WAIT, 2000),
                    FallbackAction("重试启动", StepAction.LAUNCH_APP)
                )
            ),
            TaskStep(
                stepId = "go_to_home",
                description = "确保在主界面",
                action = StepAction.ENSURE_HOME,
                expectedElements = listOf("微信", "通讯录"),
                checkConditions = listOf(
                    Condition("有返回按钮", "返回", ConditionType.CONTAINS_TEXT, true),
                    Condition("在聊天界面", "发送", ConditionType.CONTAINS_TEXT, true)
                ),
                fallbackActions = listOf(
                    FallbackAction("按返回键", StepAction.PRESS_BACK),
                    FallbackAction("等待", StepAction.WAIT, 500)
                )
            ),
            TaskStep(
                stepId = "click_search",
                description = "点击搜索框",
                action = StepAction.CLICK,
                targetElements = listOf("搜索", "Search", "🔍"),
                expectedElements = listOf("搜索", "取消"),
                fallbackActions = listOf(
                    FallbackAction("尝试点击放大镜图标", StepAction.CLICK_BY_DESC, "搜索"),
                    FallbackAction("滑动到顶部再搜索", StepAction.SCROLL_UP)
                )
            ),
            TaskStep(
                stepId = "input_contact",
                description = "输入联系人名称",
                action = StepAction.INPUT_TEXT,
                targetElements = listOf("搜索", "输入框"),
                parameters = mapOf("text" to "{contactName}", "clearFirst" to "true"),
                expectedElements = listOf("联系人", "搜索结果"),
                fallbackActions = listOf(
                    FallbackAction("等待输入框", StepAction.WAIT, 500),
                    FallbackAction("点击输入框", StepAction.CLICK_EDITABLE)
                )
            ),
            TaskStep(
                stepId = "wait_search_result",
                description = "等待搜索结果",
                action = StepAction.WAIT,
                parameters = mapOf("duration" to "1500"),
                expectedElements = listOf("{contactName}")
            ),
            TaskStep(
                stepId = "click_contact",
                description = "点击联系人",
                action = StepAction.CLICK,
                targetElements = listOf("{contactName}"),
                expectedElements = listOf("发送", "输入", "语音"),
                fallbackActions = listOf(
                    FallbackAction("模糊匹配联系人", StepAction.CLICK_FUZZY, "{contactName}"),
                    FallbackAction("询问用户选择", StepAction.ASK_USER_CHOICE)
                )
            ),
            TaskStep(
                stepId = "click_input_box",
                description = "点击输入框",
                action = StepAction.CLICK,
                targetElements = listOf("请输入", "发消息", "输入框"),
                expectedElements = listOf("键盘", "发送"),
                fallbackActions = listOf(
                    FallbackAction("点击可编辑区域", StepAction.CLICK_EDITABLE)
                )
            ),
            TaskStep(
                stepId = "input_message",
                description = "输入消息内容",
                action = StepAction.INPUT_TEXT,
                parameters = mapOf("text" to "{message}"),
                expectedElements = listOf("发送")
            ),
            TaskStep(
                stepId = "click_send",
                description = "点击发送按钮",
                action = StepAction.CLICK,
                targetElements = listOf("发送", "Send"),
                expectedElements = listOf("{message}"),
                fallbackActions = listOf(
                    FallbackAction("按回车发送", StepAction.PRESS_ENTER)
                )
            ),
            TaskStep(
                stepId = "verify_sent",
                description = "验证发送成功",
                action = StepAction.VERIFY,
                checkConditions = listOf(
                    Condition("消息已显示", "{message}", ConditionType.CONTAINS_TEXT, false)
                )
            )
        )
    )
    
    /**
     * QQ发消息步骤
     */
    val QQ_SEND_MESSAGE = TaskDefinition(
        taskName = "QQ发消息",
        appPackage = "com.tencent.mobileqq",
        steps = listOf(
            TaskStep(
                stepId = "launch_app",
                description = "启动QQ",
                action = StepAction.LAUNCH_APP,
                expectedElements = listOf("消息", "联系人", "动态")
            ),
            TaskStep(
                stepId = "click_search",
                description = "点击搜索",
                action = StepAction.CLICK,
                targetElements = listOf("搜索", "找人", "🔍"),
                expectedElements = listOf("搜索", "取消")
            ),
            TaskStep(
                stepId = "input_contact",
                description = "输入联系人",
                action = StepAction.INPUT_TEXT,
                parameters = mapOf("text" to "{contactName}"),
                expectedElements = listOf("{contactName}")
            ),
            TaskStep(
                stepId = "click_contact",
                description = "点击联系人",
                action = StepAction.CLICK,
                targetElements = listOf("{contactName}"),
                expectedElements = listOf("发送", "输入")
            ),
            TaskStep(
                stepId = "input_message",
                description = "输入消息",
                action = StepAction.INPUT_TEXT,
                parameters = mapOf("text" to "{message}")
            ),
            TaskStep(
                stepId = "click_send",
                description = "发送消息",
                action = StepAction.CLICK,
                targetElements = listOf("发送")
            )
        )
    )
    
    // ==================== 📹 刷视频步骤定义 ====================
    
    /**
     * 抖音刷视频步骤
     */
    val DOUYIN_WATCH_VIDEO = TaskDefinition(
        taskName = "抖音刷视频",
        appPackage = "com.ss.android.ugc.aweme",
        steps = listOf(
            TaskStep(
                stepId = "launch_app",
                description = "启动抖音",
                action = StepAction.LAUNCH_APP,
                expectedElements = listOf("首页", "推荐", "关注"),
                fallbackActions = listOf(
                    FallbackAction("等待启动", StepAction.WAIT, 3000)
                )
            ),
            TaskStep(
                stepId = "ensure_home",
                description = "确保在首页",
                action = StepAction.ENSURE_HOME,
                checkConditions = listOf(
                    Condition("在首页", "首页", ConditionType.CONTAINS_TEXT, false),
                    Condition("在推荐页", "推荐", ConditionType.CONTAINS_TEXT, false)
                ),
                fallbackActions = listOf(
                    FallbackAction("点击首页", StepAction.CLICK, "首页"),
                    FallbackAction("按返回键", StepAction.PRESS_BACK)
                )
            ),
            TaskStep(
                stepId = "search_keyword",
                description = "搜索关键词（可选）",
                action = StepAction.CONDITIONAL,
                checkConditions = listOf(
                    Condition("有搜索关键词", "{searchKeyword}", ConditionType.NOT_EMPTY)
                ),
                subSteps = listOf(
                    TaskStep("click_search", "点击搜索", StepAction.CLICK, targetElements = listOf("搜索", "🔍")),
                    TaskStep("input_keyword", "输入关键词", StepAction.INPUT_TEXT, parameters = mapOf("text" to "{searchKeyword}")),
                    TaskStep("click_search_btn", "点击搜索按钮", StepAction.CLICK, targetElements = listOf("搜索", "Search")),
                    TaskStep("click_video_tab", "点击视频标签", StepAction.CLICK, targetElements = listOf("视频", "综合"))
                )
            ),
            TaskStep(
                stepId = "watch_video_loop",
                description = "循环观看视频",
                action = StepAction.LOOP,
                parameters = mapOf("count" to "{videoCount}", "variable" to "i"),
                subSteps = listOf(
                    TaskStep(
                        stepId = "watch_current",
                        description = "观看当前视频",
                        action = StepAction.WAIT,
                        parameters = mapOf("duration" to "{watchDuration}", "random" to "true")
                    ),
                    TaskStep(
                        stepId = "random_interact",
                        description = "随机互动（可选）",
                        action = StepAction.RANDOM_ACTION,
                        parameters = mapOf("probability" to "0.3"),
                        subSteps = listOf(
                            TaskStep("like", "点赞", StepAction.CLICK, targetElements = listOf("点赞", "❤️")),
                            TaskStep("comment", "查看评论", StepAction.CLICK, targetElements = listOf("评论", "💬"))
                        )
                    ),
                    TaskStep(
                        stepId = "swipe_next",
                        description = "滑动到下一个视频",
                        action = StepAction.SWIPE_UP,
                        parameters = mapOf("duration" to "300")
                    ),
                    TaskStep(
                        stepId = "report_progress",
                        description = "报告进度",
                        action = StepAction.REPORT_PROGRESS,
                        parameters = mapOf("message" to "已观看 {i}/{videoCount} 个视频")
                    )
                )
            )
        )
    )
    
    /**
     * 快手刷视频步骤
     */
    val KUAISHOU_WATCH_VIDEO = TaskDefinition(
        taskName = "快手刷视频",
        appPackage = "com.kuaishou.nebula",
        steps = listOf(
            TaskStep(
                stepId = "launch_app",
                description = "启动快手",
                action = StepAction.LAUNCH_APP,
                expectedElements = listOf("精选", "关注", "发现")
            ),
            TaskStep(
                stepId = "watch_video_loop",
                description = "循环观看视频",
                action = StepAction.LOOP,
                parameters = mapOf("count" to "{videoCount}"),
                subSteps = listOf(
                    TaskStep("watch", "观看", StepAction.WAIT, parameters = mapOf("duration" to "{watchDuration}")),
                    TaskStep("swipe", "滑动", StepAction.SWIPE_UP)
                )
            )
        )
    )
    
    /**
     * B站刷视频步骤
     */
    val BILIBILI_WATCH_VIDEO = TaskDefinition(
        taskName = "B站刷视频",
        appPackage = "tv.danmaku.bili",
        steps = listOf(
            TaskStep(
                stepId = "launch_app",
                description = "启动B站",
                action = StepAction.LAUNCH_APP,
                expectedElements = listOf("首页", "动态", "会员购")
            ),
            TaskStep(
                stepId = "click_recommend",
                description = "点击推荐",
                action = StepAction.CLICK,
                targetElements = listOf("推荐", "首页")
            ),
            TaskStep(
                stepId = "watch_video_loop",
                description = "循环观看视频",
                action = StepAction.LOOP,
                parameters = mapOf("count" to "{videoCount}"),
                subSteps = listOf(
                    TaskStep("click_video", "点击视频", StepAction.CLICK_FIRST_VIDEO),
                    TaskStep("watch", "观看", StepAction.WAIT, parameters = mapOf("duration" to "{watchDuration}")),
                    TaskStep("back", "返回", StepAction.PRESS_BACK),
                    TaskStep("scroll", "滚动", StepAction.SCROLL_DOWN)
                )
            )
        )
    )
    
    // ==================== 🔍 搜索资料步骤定义 ====================
    
    /**
     * 百度搜索步骤
     */
    val BAIDU_SEARCH = TaskDefinition(
        taskName = "百度搜索",
        appPackage = "com.baidu.searchbox",
        steps = listOf(
            TaskStep(
                stepId = "launch_app",
                description = "启动百度",
                action = StepAction.LAUNCH_APP,
                expectedElements = listOf("搜索", "百度"),
                fallbackActions = listOf(
                    FallbackAction("打开浏览器访问百度", StepAction.OPEN_URL, "https://www.baidu.com")
                )
            ),
            TaskStep(
                stepId = "click_search_box",
                description = "点击搜索框",
                action = StepAction.CLICK,
                targetElements = listOf("搜索框", "搜索", "百度一下"),
                expectedElements = listOf("取消", "搜索")
            ),
            TaskStep(
                stepId = "input_keyword",
                description = "输入搜索关键词",
                action = StepAction.INPUT_TEXT,
                parameters = mapOf("text" to "{keyword}", "clearFirst" to "true"),
                expectedElements = listOf("{keyword}")
            ),
            TaskStep(
                stepId = "click_search",
                description = "点击搜索按钮",
                action = StepAction.CLICK,
                targetElements = listOf("百度一下", "搜索", "Search"),
                fallbackActions = listOf(
                    FallbackAction("按回车搜索", StepAction.PRESS_ENTER)
                )
            ),
            TaskStep(
                stepId = "wait_results",
                description = "等待搜索结果",
                action = StepAction.WAIT,
                parameters = mapOf("duration" to "2000"),
                expectedElements = listOf("搜索结果", "相关搜索")
            ),
            TaskStep(
                stepId = "browse_results",
                description = "浏览搜索结果",
                action = StepAction.LOOP,
                parameters = mapOf("count" to "{browseCount}"),
                subSteps = listOf(
                    TaskStep("click_result", "点击结果", StepAction.CLICK_NTH_RESULT, parameters = mapOf("index" to "{i}")),
                    TaskStep("read_content", "阅读内容", StepAction.WAIT, parameters = mapOf("duration" to "3000")),
                    TaskStep("back", "返回", StepAction.PRESS_BACK)
                )
            )
        )
    )
    
    /**
     * 浏览器搜索步骤
     */
    val BROWSER_SEARCH = TaskDefinition(
        taskName = "浏览器搜索",
        appPackage = "com.android.browser",
        alternativePackages = listOf(
            "com.android.chrome",
            "org.mozilla.firefox",
            "com.UCMobile",
            "com.qihoo.browser"
        ),
        steps = listOf(
            TaskStep(
                stepId = "launch_browser",
                description = "启动浏览器",
                action = StepAction.LAUNCH_APP,
                expectedElements = listOf("地址栏", "搜索", "网址")
            ),
            TaskStep(
                stepId = "click_address_bar",
                description = "点击地址栏",
                action = StepAction.CLICK,
                targetElements = listOf("地址栏", "搜索或输入网址", "网址"),
                expectedElements = listOf("输入", "取消")
            ),
            TaskStep(
                stepId = "input_search",
                description = "输入搜索内容",
                action = StepAction.INPUT_TEXT,
                parameters = mapOf("text" to "{keyword}")
            ),
            TaskStep(
                stepId = "search",
                description = "搜索",
                action = StepAction.PRESS_ENTER
            )
        )
    )
    
    // ==================== 🛒 购物步骤定义 ====================
    
    /**
     * 淘宝购物步骤
     */
    val TAOBAO_SHOPPING = TaskDefinition(
        taskName = "淘宝购物",
        appPackage = "com.taobao.taobao",
        steps = listOf(
            TaskStep(
                stepId = "launch_app",
                description = "启动淘宝",
                action = StepAction.LAUNCH_APP,
                expectedElements = listOf("首页", "消息", "购物车", "我的淘宝"),
                fallbackActions = listOf(
                    FallbackAction("等待启动", StepAction.WAIT, 3000),
                    FallbackAction("关闭弹窗", StepAction.CLOSE_POPUP)
                )
            ),
            TaskStep(
                stepId = "close_popup",
                description = "关闭可能的弹窗",
                action = StepAction.CLOSE_POPUP,
                targetElements = listOf("关闭", "×", "跳过", "我知道了")
            ),
            TaskStep(
                stepId = "click_search",
                description = "点击搜索框",
                action = StepAction.CLICK,
                targetElements = listOf("搜索", "搜索宝贝", "🔍"),
                expectedElements = listOf("搜索", "取消")
            ),
            TaskStep(
                stepId = "input_product",
                description = "输入商品名称",
                action = StepAction.INPUT_TEXT,
                parameters = mapOf("text" to "{productName}", "clearFirst" to "true")
            ),
            TaskStep(
                stepId = "click_search_btn",
                description = "点击搜索按钮",
                action = StepAction.CLICK,
                targetElements = listOf("搜索", "Search"),
                fallbackActions = listOf(
                    FallbackAction("按回车", StepAction.PRESS_ENTER)
                )
            ),
            TaskStep(
                stepId = "wait_results",
                description = "等待商品列表",
                action = StepAction.WAIT,
                parameters = mapOf("duration" to "2000")
            ),
            TaskStep(
                stepId = "filter_sort",
                description = "筛选排序（可选）",
                action = StepAction.CONDITIONAL,
                checkConditions = listOf(
                    Condition("需要筛选", "{needFilter}", ConditionType.EQUALS)
                ),
                subSteps = listOf(
                    TaskStep("click_sort", "点击排序", StepAction.CLICK, targetElements = listOf("销量", "价格", "综合")),
                    TaskStep("wait", "等待", StepAction.WAIT, parameters = mapOf("duration" to "1000"))
                )
            ),
            TaskStep(
                stepId = "click_product",
                description = "点击商品",
                action = StepAction.CLICK_PRODUCT,
                parameters = mapOf("index" to "{productIndex}"),
                expectedElements = listOf("加入购物车", "立即购买", "商品详情")
            ),
            TaskStep(
                stepId = "view_details",
                description = "查看商品详情",
                action = StepAction.SCROLL_DOWN,
                parameters = mapOf("times" to "2")
            ),
            TaskStep(
                stepId = "add_to_cart",
                description = "加入购物车（可选）",
                action = StepAction.CONDITIONAL,
                checkConditions = listOf(
                    Condition("加入购物车", "add_cart", ConditionType.EQUALS)
                ),
                subSteps = listOf(
                    TaskStep("click_add", "点击加入购物车", StepAction.CLICK, targetElements = listOf("加入购物车", "加购")),
                    TaskStep("select_spec", "选择规格", StepAction.SELECT_SPECIFICATION),
                    TaskStep("confirm", "确认", StepAction.CLICK, targetElements = listOf("确定", "确认"))
                )
            ),
            TaskStep(
                stepId = "buy_now",
                description = "立即购买（可选）",
                action = StepAction.CONDITIONAL,
                checkConditions = listOf(
                    Condition("立即购买", "buy_now", ConditionType.EQUALS)
                ),
                subSteps = listOf(
                    TaskStep("click_buy", "点击立即购买", StepAction.CLICK, targetElements = listOf("立即购买", "马上抢")),
                    TaskStep("select_spec", "选择规格", StepAction.SELECT_SPECIFICATION),
                    TaskStep("confirm_order", "确认订单", StepAction.CLICK, targetElements = listOf("提交订单", "确认"))
                )
            )
        )
    )
    
    /**
     * 京东购物步骤
     */
    val JD_SHOPPING = TaskDefinition(
        taskName = "京东购物",
        appPackage = "com.jingdong.app.mall",
        steps = listOf(
            TaskStep(
                stepId = "launch_app",
                description = "启动京东",
                action = StepAction.LAUNCH_APP,
                expectedElements = listOf("首页", "分类", "购物车", "我的")
            ),
            TaskStep(
                stepId = "click_search",
                description = "点击搜索",
                action = StepAction.CLICK,
                targetElements = listOf("搜索", "搜索商品")
            ),
            TaskStep(
                stepId = "input_product",
                description = "输入商品",
                action = StepAction.INPUT_TEXT,
                parameters = mapOf("text" to "{productName}")
            ),
            TaskStep(
                stepId = "search",
                description = "搜索",
                action = StepAction.CLICK,
                targetElements = listOf("搜索")
            ),
            TaskStep(
                stepId = "click_product",
                description = "点击商品",
                action = StepAction.CLICK_PRODUCT
            ),
            TaskStep(
                stepId = "add_to_cart",
                description = "加入购物车",
                action = StepAction.CLICK,
                targetElements = listOf("加入购物车", "加购")
            )
        )
    )
    
    /**
     * 拼多多购物步骤
     */
    val PDD_SHOPPING = TaskDefinition(
        taskName = "拼多多购物",
        appPackage = "com.xunmeng.pinduoduo",
        steps = listOf(
            TaskStep(
                stepId = "launch_app",
                description = "启动拼多多",
                action = StepAction.LAUNCH_APP,
                expectedElements = listOf("首页", "推荐", "个人中心")
            ),
            TaskStep(
                stepId = "click_search",
                description = "点击搜索",
                action = StepAction.CLICK,
                targetElements = listOf("搜索", "搜索商品")
            ),
            TaskStep(
                stepId = "input_product",
                description = "输入商品",
                action = StepAction.INPUT_TEXT,
                parameters = mapOf("text" to "{productName}")
            ),
            TaskStep(
                stepId = "search",
                description = "搜索",
                action = StepAction.PRESS_ENTER
            ),
            TaskStep(
                stepId = "click_product",
                description = "点击商品",
                action = StepAction.CLICK_PRODUCT
            )
        )
    )
    
    // ==================== 🎯 步骤获取方法 ====================
    
    /**
     * 根据任务类型获取步骤定义
     */
    fun getTaskDefinition(taskType: TaskType, appName: String? = null): TaskDefinition? {
        return when (taskType) {
            TaskType.SEND_MESSAGE -> when (appName?.lowercase()) {
                "微信", "wechat" -> WECHAT_SEND_MESSAGE
                "qq" -> QQ_SEND_MESSAGE
                else -> WECHAT_SEND_MESSAGE
            }
            TaskType.WATCH_VIDEO -> when (appName?.lowercase()) {
                "抖音", "douyin" -> DOUYIN_WATCH_VIDEO
                "快手", "kuaishou" -> KUAISHOU_WATCH_VIDEO
                "b站", "bilibili" -> BILIBILI_WATCH_VIDEO
                else -> DOUYIN_WATCH_VIDEO
            }
            TaskType.SEARCH -> when (appName?.lowercase()) {
                "百度", "baidu" -> BAIDU_SEARCH
                "浏览器", "browser" -> BROWSER_SEARCH
                else -> BAIDU_SEARCH
            }
            TaskType.SHOPPING -> when (appName?.lowercase()) {
                "淘宝", "taobao" -> TAOBAO_SHOPPING
                "京东", "jd" -> JD_SHOPPING
                "拼多多", "pdd" -> PDD_SHOPPING
                else -> TAOBAO_SHOPPING
            }
        }
    }
    
    /**
     * 获取所有任务定义
     */
    fun getAllTaskDefinitions(): List<TaskDefinition> {
        return listOf(
            WECHAT_SEND_MESSAGE,
            QQ_SEND_MESSAGE,
            DOUYIN_WATCH_VIDEO,
            KUAISHOU_WATCH_VIDEO,
            BILIBILI_WATCH_VIDEO,
            BAIDU_SEARCH,
            BROWSER_SEARCH,
            TAOBAO_SHOPPING,
            JD_SHOPPING,
            PDD_SHOPPING
        )
    }
}

// ==================== 📦 数据类定义 ====================

/**
 * 任务类型
 */
enum class TaskType {
    SEND_MESSAGE,
    WATCH_VIDEO,
    SEARCH,
    SHOPPING
}

/**
 * 任务定义
 */
data class TaskDefinition(
    val taskName: String,
    val appPackage: String,
    val alternativePackages: List<String> = emptyList(),
    val steps: List<TaskStep>
)

/**
 * 任务步骤
 */
data class TaskStep(
    val stepId: String,
    val description: String,
    val action: StepAction,
    val targetElements: List<String> = emptyList(),
    val expectedElements: List<String> = emptyList(),
    val parameters: Map<String, String> = emptyMap(),
    val checkConditions: List<Condition> = emptyList(),
    val fallbackActions: List<FallbackAction> = emptyList(),
    val subSteps: List<TaskStep> = emptyList()
)

/**
 * 步骤动作类型
 */
enum class StepAction {
    LAUNCH_APP,
    CLICK,
    CLICK_BY_DESC,
    CLICK_EDITABLE,
    CLICK_FUZZY,
    CLICK_FIRST_VIDEO,
    CLICK_PRODUCT,
    CLICK_NTH_RESULT,
    INPUT_TEXT,
    WAIT,
    SWIPE_UP,
    SWIPE_DOWN,
    SCROLL_UP,
    SCROLL_DOWN,
    PRESS_BACK,
    PRESS_ENTER,
    PRESS_HOME,
    ENSURE_HOME,
    CLOSE_POPUP,
    OPEN_URL,
    VERIFY,
    LOOP,
    CONDITIONAL,
    RANDOM_ACTION,
    SELECT_SPECIFICATION,
    REPORT_PROGRESS,
    ASK_USER_CHOICE
}

/**
 * 条件
 */
data class Condition(
    val name: String,
    val value: String,
    val type: ConditionType,
    val triggerFallback: Boolean = false
)

/**
 * 条件类型
 */
enum class ConditionType {
    CONTAINS_TEXT,
    EQUALS,
    NOT_EMPTY,
    ELEMENT_EXISTS,
    ELEMENT_CLICKABLE
}

/**
 * 备用动作
 */
data class FallbackAction(
    val description: String,
    val action: StepAction,
    val parameter: Any? = null
)
