package com.example.xihe.scenarios

import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.core.*
import com.example.xihe.tools.ToolRegistry
import kotlinx.coroutines.delay
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlin.random.Random

/**
 * 自动刷视频场景
 * 支持抖音、快手、B站等短视频应用
 */
object VideoScenario {
    private const val TAG = "VideoScenario"
    
    /**
     * 检测是否是刷视频指令
     */
    fun detectWatchVideo(userInput: String): WatchVideoRequest? {
        val input = userInput.trim()
        
        // 匹配模式：
        // "在抖音刷10个视频"
        // "抖音搜索美食然后刷视频"
        // "帮我在快手刷20个视频"
        
        val patterns = listOf(
            // "在抖音搜索美食刷10个视频"
            Regex("""在?\s*(抖音|快手|bilibili|b站)\s*搜索\s*(.+?)\s*(刷|看|浏览)\s*(\d+)\s*(个|条)?\s*视频"""),
            // "抖音刷10个视频"
            Regex("""(抖音|快手|bilibili|b站)\s*(刷|看|浏览)\s*(\d+)\s*(个|条)?\s*视频"""),
            // "帮我在抖音刷视频"（默认10个）
            Regex("""(在|帮我在)?\s*(抖音|快手|bilibili|b站)\s*(刷|看|浏览)\s*视频""")
        )
        
        for (pattern in patterns) {
            val match = pattern.find(input)
            if (match != null) {
                val groups = match.groupValues
                
                val app = when {
                    groups[1].contains("抖音") -> "抖音"
                    groups[1].contains("快手") -> "快手"
                    groups[1].contains(Regex("bilibili|b站")) -> "B站"
                    groups[2].contains("抖音") -> "抖音"
                    groups[2].contains("快手") -> "快手"
                    groups[2].contains(Regex("bilibili|b站")) -> "B站"
                    else -> "抖音"
                }
                
                val searchKeyword = if (groups.size > 2 && groups[2].isNotEmpty() && !groups[2].contains(Regex("刷|看|浏览"))) {
                    groups[2]
                } else null
                
                val count = groups.find { it.matches(Regex("\\d+")) }?.toIntOrNull() ?: 10
                
                return WatchVideoRequest(app, searchKeyword, count)
            }
        }
        
        return null
    }
    
    /**
     * 执行刷视频任务
     */
    suspend fun executeWatchVideo(
        request: WatchVideoRequest,
        context: Context,
        onProgress: (String) -> Unit
    ): ScenarioResult {
        val appPackage = when (request.app) {
            "抖音" -> "com.ss.android.ugc.aweme"
            "快手" -> "com.kuaishou.nebula"
            "B站" -> "tv.danmaku.bili"
            else -> return ScenarioResult.Failure("不支持的应用: ${request.app}")
        }
        
        try {
            // Step 1: 打开应用
            onProgress("正在打开${request.app}... 🎬")
            val launchResult = ToolRegistry.executeTool(
                com.example.xihe.tools.ToolCall(
                    "launch_app",
                    buildJsonObject { put("appNameOrPackage", appPackage) }
                )
            )
            
            if (!launchResult.success) {
                return ScenarioResult.Failure("无法打开${request.app}")
            }
            
            delay(3000) // 等待应用启动
            
            val service = CoreAccessibilityService.instance
                ?: return ScenarioResult.Failure("无障碍服务未启动")
            
            val executor = ActionExecutor(service, context)
            val llmClient = LLMClient(
                AutomationEngine.baseUrl,
                AutomationEngine.apiKey,
                AutomationEngine.modelName,
                AutomationEngine.providerId  // 传入 providerId 以正确识别 Google API
            )
            
            // Step 2: 如果有搜索关键词，先搜索
            if (request.searchKeyword != null) {
                onProgress("正在搜索：${request.searchKeyword}... 🔍")
                
                val searchSteps = listOf(
                    "找到搜索图标或搜索框并点击",
                    "在搜索框输入：${request.searchKeyword}",
                    "点击搜索按钮或确认搜索"
                )
                
                for (stepGoal in searchSteps) {
                    val root = service.rootInActiveWindow ?: continue
                    val screenState = ScreenAnalyzer.analyze(root, appPackage)
                    
                    if (screenState != null) {
                        val command = llmClient.think(screenState, stepGoal, emptyList())
                        executor.execute(command, root)
                        delay(1500)
                    }
                }
                
                delay(2000) // 等待搜索结果加载
            }
            
            // Step 3: 开始刷视频
            onProgress("开始模拟人类刷视频... 📱")
            
            HumanBehaviorSimulator.simulateVideoSwiping(
                swipeAction = {
                    val root = service.rootInActiveWindow
                    if (root != null) {
                        // 向上滑动（下一个视频）
                        val displayMetrics = service.resources.displayMetrics
                        val width = displayMetrics.widthPixels
                        val height = displayMetrics.heightPixels
                        val centerX = width / 2f
                        val startY = height * 0.7f
                        val endY = height * 0.3f
                        
                        service.performScroll(centerX, startY, centerX, endY)
                        
                        val currentVideo = (request.count - 9) + 1 // 粗略计数
                        if (currentVideo % 3 == 0) {
                            onProgress("已刷 $currentVideo/${request.count} 个视频... 🎥")
                        }
                    }
                },
                videoCount = request.count
            )
            
            onProgress("刷视频完成！已浏览 ${request.count} 个视频 ✅")
            return ScenarioResult.Success("已在${request.app}成功刷了 ${request.count} 个视频")
            
        } catch (e: Exception) {
            LogManager.d(TAG, "刷视频失败", e)
            return ScenarioResult.Failure("刷视频失败: ${e.message}")
        }
    }
    
    data class WatchVideoRequest(
        val app: String,            // "抖音"、"快手"、"B站"
        val searchKeyword: String?, // 搜索关键词（可选）
        val count: Int              // 视频数量
    )
}
