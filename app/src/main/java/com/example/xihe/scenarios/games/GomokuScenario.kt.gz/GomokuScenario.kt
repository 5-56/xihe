package com.example.xihe.scenarios.games

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import com.example.xihe.utils.LogManager
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.scenarios.ScenarioBase
import com.example.xihe.scenarios.ScenarioConfig
import com.example.xihe.scenarios.ScenarioResult
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * ⚫⚪ 五子棋自动下棋场景
 * 
 * 功能：
 * - 自动识别棋盘状态（通过图像分析）
 * - 使用 Alpha-Beta 剪枝算法计算最优落子
 * - 自动点击落子
 * - 支持先手/后手
 * 
 * 支持的五子棋 App：
 * - 欢乐五子棋
 * - 五子棋大师
 * - 天天五子棋
 * - 其他标准15x15棋盘的五子棋
 */
class GomokuScenario(context: Context) : ScenarioBase(context, "五子棋") {
    
    companion object {
        private const val TAG = "GomokuScenario"
        const val BOARD_SIZE = 15  // 标准五子棋棋盘大小
        
        // 棋子状态
        const val EMPTY = 0
        const val BLACK = 1
        const val WHITE = 2
        
        // 评分权重
        private val SCORE_TABLE = mapOf(
            "five" to 100000,      // 五连
            "liveFour" to 10000,   // 活四
            "deadFour" to 1000,    // 冲四
            "liveThree" to 1000,   // 活三
            "deadThree" to 100,    // 眠三
            "liveTwo" to 100,      // 活二
            "deadTwo" to 10        // 眠二
        )
    }
    
    /**
     * ⚙️ 五子棋配置
     */
    data class GomokuConfig(
        val appPackage: String? = null,         // App 包名（可选，用于启动）
        val playAs: Int = BLACK,                // 执黑/执白
        val searchDepth: Int = 4,               // 搜索深度（越大越强但越慢）
        val autoPlay: Boolean = true,           // 是否自动连续下棋
        val maxMoves: Int = 100,                // 最大步数
        val boardDetectionMode: BoardDetectionMode = BoardDetectionMode.AUTO
    ) : ScenarioConfig(maxIterations = maxMoves)
    
    enum class BoardDetectionMode {
        AUTO,           // 自动检测棋盘位置
        MANUAL,         // 手动指定棋盘区域
        TEMPLATE        // 模板匹配
    }
    
    // 棋盘状态
    private var board = Array(BOARD_SIZE) { IntArray(BOARD_SIZE) }
    private var boardRect: BoardRect? = null
    private var myColor = BLACK
    private var moveCount = 0
    
    data class BoardRect(
        val left: Int,
        val top: Int,
        val right: Int,
        val bottom: Int
    ) {
        val width: Int get() = right - left
        val height: Int get() = bottom - top
        val cellWidth: Float get() = width.toFloat() / (BOARD_SIZE - 1)
        val cellHeight: Float get() = height.toFloat() / (BOARD_SIZE - 1)
    }
    
    data class Move(val row: Int, val col: Int, val score: Int = 0)
    
    /**
     * 🔍 检测用户意图
     */
    fun detectIntent(userInput: String): GomokuConfig? {
        val input = userInput.lowercase()
        
        val isGomokuIntent = input.contains(Regex("(五子棋|gomoku|下棋|对弈).*(自动|帮我|ai)")) ||
                input.contains(Regex("(自动|帮我|ai).*(五子棋|gomoku|下棋)"))
        
        if (!isGomokuIntent) return null
        
        // 检测执黑/执白
        val playAs = when {
            input.contains("执白") || input.contains("白棋") -> WHITE
            else -> BLACK
        }
        
        // 检测难度
        val depth = when {
            input.contains("简单") -> 2
            input.contains("困难") || input.contains("最强") -> 6
            else -> 4
        }
        
        LogManager.d(TAG, "✅ 检测到五子棋意图: 执${if (playAs == BLACK) "黑" else "白"}, 深度=$depth")
        
        return GomokuConfig(playAs = playAs, searchDepth = depth)
    }
    
    /**
     * 🎯 执行五子棋对弈
     */
    override suspend fun execute(config: ScenarioConfig): ScenarioResult {
        val gomokuConfig = config as? GomokuConfig
            ?: return ScenarioResult.Failure("配置类型错误")
        
        val service = CoreAccessibilityService.instance
            ?: return ScenarioResult.Failure("无障碍服务未启动")
        
        myColor = gomokuConfig.playAs
        resetBoard()
        
        // 启动 App（如果指定）
        if (!gomokuConfig.appPackage.isNullOrEmpty()) {
            updateProgress(message = "正在启动五子棋游戏... 🎮")
            service.launchApp(gomokuConfig.appPackage)
            delay(3000)
        }
        
        updateProgress(message = "开始五子棋对弈，我执${if (myColor == BLACK) "黑" else "白"}棋... ⚫⚪")
        
        // 主循环
        while (moveCount < gomokuConfig.maxMoves) {
            if (shouldStop()) {
                return ScenarioResult.Stopped(
                    message = "对弈中止，共下 $moveCount 步",
                    completedSteps = moveCount,
                    totalSteps = gomokuConfig.maxMoves
                )
            }
            
            // 1. 截图识别棋盘
            val screenshot = service.takeScreenshotAsync()
            if (screenshot == null) {
                log("⚠️ 截图失败，等待重试...")
                delay(1000)
                continue
            }
            
            // 2. 检测棋盘区域（首次）
            if (boardRect == null) {
                boardRect = detectBoardRect(screenshot)
                if (boardRect == null) {
                    updateProgress(message = "⚠️ 未检测到棋盘，请确保棋盘完整显示...")
                    delay(2000)
                    continue
                }
                log("✅ 检测到棋盘区域: $boardRect")
            }
            
            // 3. 识别当前棋盘状态
            val currentBoardRect = boardRect ?: continue
            val currentBoard = recognizeBoard(screenshot, currentBoardRect)
            
            // 4. 检查是否轮到我下
            val myTurn = isMyTurn(currentBoard)
            if (!myTurn) {
                updateProgress(message = "等待对手落子... 👀")
                delay(500)
                continue
            }
            
            // 5. 计算最佳落子位置
            updateProgress(message = "思考中... 🤔 (第 ${moveCount + 1} 步)")
            val bestMove = findBestMove(currentBoard, myColor, gomokuConfig.searchDepth)
            
            if (bestMove == null) {
                log("⚠️ 无法找到有效落子位置")
                delay(1000)
                continue
            }
            
            log("💡 最佳落子: (${bestMove.row}, ${bestMove.col}), 评分: ${bestMove.score}")
            
            // 6. 执行落子
            val clickX = currentBoardRect.left + bestMove.col * currentBoardRect.cellWidth
            val clickY = currentBoardRect.top + bestMove.row * currentBoardRect.cellHeight
            
            val clicked = service.tapAsync(clickX, clickY)
            if (clicked) {
                moveCount++
                board[bestMove.row][bestMove.col] = myColor
                updateProgress(
                    currentStep = moveCount,
                    message = "落子 (${bestMove.row + 1}, ${bestMove.col + 1})，共 $moveCount 步 ⚫",
                    successCount = moveCount
                )
            }
            
            // 7. 检查是否获胜
            if (checkWin(board, bestMove.row, bestMove.col, myColor)) {
                return ScenarioResult.Success(
                    message = "🎉 恭喜获胜！共下 $moveCount 步",
                    completedSteps = moveCount,
                    totalSteps = gomokuConfig.maxMoves
                )
            }
            
            delay(500)
        }
        
        return ScenarioResult.Success(
            message = "对弈完成，共下 $moveCount 步",
            completedSteps = moveCount,
            totalSteps = gomokuConfig.maxMoves
        )
    }
    
    /**
     * 🔄 重置棋盘
     */
    private fun resetBoard() {
        board = Array(BOARD_SIZE) { IntArray(BOARD_SIZE) }
        boardRect = null
        moveCount = 0
    }
    
    /**
     * 📐 检测棋盘区域（智能检测版）
     */
    private fun detectBoardRect(bitmap: Bitmap): BoardRect? {
        // 使用智能棋盘检测
        val rect = GameRecognitionUtils.detectBoardRect(
            bitmap = bitmap,
            gridSize = BOARD_SIZE,
            minBoardRatio = 0.3f,
            maxBoardRatio = 0.95f
        )
        
        return rect?.let {
            BoardRect(
                left = it.left,
                top = it.top,
                right = it.right,
                bottom = it.bottom
            )
        }
    }
    
    /**
     * 👁️ 识别棋盘状态（使用改进的识别算法）
     */
    private fun recognizeBoard(bitmap: Bitmap, rect: BoardRect): Array<IntArray> {
        val result = Array(BOARD_SIZE) { IntArray(BOARD_SIZE) }
        
        // 计算采样半径（根据格子大小自适应）
        val sampleRadius = (min(rect.cellWidth, rect.cellHeight) / 4).toInt().coerceIn(3, 15)
        
        for (row in 0 until BOARD_SIZE) {
            for (col in 0 until BOARD_SIZE) {
                val x = (rect.left + col * rect.cellWidth).toInt().coerceIn(0, bitmap.width - 1)
                val y = (rect.top + row * rect.cellHeight).toInt().coerceIn(0, bitmap.height - 1)
                
                // 使用改进的棋子识别
                val pieceColor = GameRecognitionUtils.recognizePieceColor(bitmap, x, y, sampleRadius)
                result[row][col] = when (pieceColor) {
                    GameRecognitionUtils.PieceColor.BLACK -> BLACK
                    GameRecognitionUtils.PieceColor.WHITE -> WHITE
                    GameRecognitionUtils.PieceColor.EMPTY -> EMPTY
                }
            }
        }
        
        return result
    }
    
    /**
     * 🤔 判断是否轮到我下
     */
    private fun isMyTurn(currentBoard: Array<IntArray>): Boolean {
        var blackCount = 0
        var whiteCount = 0
        
        for (row in 0 until BOARD_SIZE) {
            for (col in 0 until BOARD_SIZE) {
                when (currentBoard[row][col]) {
                    BLACK -> blackCount++
                    WHITE -> whiteCount++
                }
            }
        }
        
        // 黑棋先手，所以黑棋数 <= 白棋数时轮到黑棋
        return if (myColor == BLACK) {
            blackCount <= whiteCount
        } else {
            blackCount > whiteCount
        }
    }
    
    /**
     * 🧠 寻找最佳落子（Alpha-Beta 剪枝）
     */
    private fun findBestMove(currentBoard: Array<IntArray>, player: Int, depth: Int): Move? {
        // 复制棋盘
        for (row in 0 until BOARD_SIZE) {
            for (col in 0 until BOARD_SIZE) {
                board[row][col] = currentBoard[row][col]
            }
        }
        
        // 获取候选位置（已有棋子周围的空位）
        val candidates = getCandidateMoves(board)
        if (candidates.isEmpty()) {
            // 棋盘为空，下中心
            return Move(BOARD_SIZE / 2, BOARD_SIZE / 2)
        }
        
        var bestMove: Move? = null
        var bestScore = Int.MIN_VALUE
        
        for (move in candidates) {
            board[move.row][move.col] = player
            
            val score = -alphaBeta(
                board = board,
                depth = depth - 1,
                alpha = Int.MIN_VALUE,
                beta = Int.MAX_VALUE,
                player = opponent(player)
            )
            
            board[move.row][move.col] = EMPTY
            
            if (score > bestScore) {
                bestScore = score
                bestMove = Move(move.row, move.col, score)
            }
        }
        
        return bestMove
    }
    
    /**
     * 🔄 Alpha-Beta 剪枝搜索
     */
    private fun alphaBeta(
        board: Array<IntArray>,
        depth: Int,
        alpha: Int,
        beta: Int,
        player: Int
    ): Int {
        if (depth == 0) {
            return evaluate(board, player)
        }
        
        val candidates = getCandidateMoves(board)
        if (candidates.isEmpty()) {
            return evaluate(board, player)
        }
        
        var currentAlpha = alpha
        
        for (move in candidates) {
            board[move.row][move.col] = player
            
            val score = -alphaBeta(
                board = board,
                depth = depth - 1,
                alpha = -beta,
                beta = -currentAlpha,
                player = opponent(player)
            )
            
            board[move.row][move.col] = EMPTY
            
            if (score >= beta) {
                return beta
            }
            if (score > currentAlpha) {
                currentAlpha = score
            }
        }
        
        return currentAlpha
    }
    
    /**
     * 📊 评估棋盘局面
     */
    private fun evaluate(board: Array<IntArray>, player: Int): Int {
        var score = 0
        
        // 评估所有行、列、对角线
        for (row in 0 until BOARD_SIZE) {
            for (col in 0 until BOARD_SIZE) {
                if (board[row][col] == player) {
                    score += evaluatePosition(board, row, col, player)
                } else if (board[row][col] == opponent(player)) {
                    score -= evaluatePosition(board, row, col, opponent(player))
                }
            }
        }
        
        return score
    }
    
    /**
     * 📍 评估单个位置
     */
    private fun evaluatePosition(board: Array<IntArray>, row: Int, col: Int, player: Int): Int {
        var score = 0
        val directions = listOf(
            0 to 1,   // 水平
            1 to 0,   // 垂直
            1 to 1,   // 对角线
            1 to -1   // 反对角线
        )
        
        for ((dr, dc) in directions) {
            val count = countInDirection(board, row, col, dr, dc, player)
            val blocked = isBlocked(board, row, col, dr, dc, count, player)
            
            score += when {
                count >= 5 -> SCORE_TABLE["five"] ?: 100000
                count == 4 && !blocked -> SCORE_TABLE["liveFour"] ?: 10000
                count == 4 -> SCORE_TABLE["deadFour"] ?: 1000
                count == 3 && !blocked -> SCORE_TABLE["liveThree"] ?: 1000
                count == 3 -> SCORE_TABLE["deadThree"] ?: 100
                count == 2 && !blocked -> SCORE_TABLE["liveTwo"] ?: 100
                count == 2 -> SCORE_TABLE["deadTwo"] ?: 10
                else -> 0
            }
        }
        
        return score
    }
    
    /**
     * 📏 计算某方向连续棋子数
     */
    private fun countInDirection(
        board: Array<IntArray>,
        row: Int, col: Int,
        dr: Int, dc: Int,
        player: Int
    ): Int {
        var count = 1
        
        // 正向
        var r = row + dr
        var c = col + dc
        while (r in 0 until BOARD_SIZE && c in 0 until BOARD_SIZE && board[r][c] == player) {
            count++
            r += dr
            c += dc
        }
        
        // 反向
        r = row - dr
        c = col - dc
        while (r in 0 until BOARD_SIZE && c in 0 until BOARD_SIZE && board[r][c] == player) {
            count++
            r -= dr
            c -= dc
        }
        
        return count
    }
    
    /**
     * 🚫 检查是否被封堵
     */
    private fun isBlocked(
        board: Array<IntArray>,
        row: Int, col: Int,
        dr: Int, dc: Int,
        count: Int,
        player: Int
    ): Boolean {
        val opp = opponent(player)
        
        // 检查两端是否被封堵
        var blockedEnds = 0
        
        // 正向端点
        var r = row + dr * count
        var c = col + dc * count
        if (r !in 0 until BOARD_SIZE || c !in 0 until BOARD_SIZE || board[r][c] == opp) {
            blockedEnds++
        }
        
        // 反向端点
        r = row - dr
        c = col - dc
        if (r !in 0 until BOARD_SIZE || c !in 0 until BOARD_SIZE || board[r][c] == opp) {
            blockedEnds++
        }
        
        return blockedEnds >= 2
    }
    
    /**
     * 🎯 获取候选落子位置
     */
    private fun getCandidateMoves(board: Array<IntArray>): List<Move> {
        val candidates = mutableSetOf<Move>()
        
        for (row in 0 until BOARD_SIZE) {
            for (col in 0 until BOARD_SIZE) {
                if (board[row][col] != EMPTY) {
                    // 添加周围的空位
                    for (dr in -2..2) {
                        for (dc in -2..2) {
                            val nr = row + dr
                            val nc = col + dc
                            if (nr in 0 until BOARD_SIZE && nc in 0 until BOARD_SIZE 
                                && board[nr][nc] == EMPTY) {
                                candidates.add(Move(nr, nc))
                            }
                        }
                    }
                }
            }
        }
        
        return candidates.toList()
    }
    
    /**
     * ✅ 检查是否获胜
     */
    private fun checkWin(board: Array<IntArray>, row: Int, col: Int, player: Int): Boolean {
        val directions = listOf(0 to 1, 1 to 0, 1 to 1, 1 to -1)
        
        for ((dr, dc) in directions) {
            if (countInDirection(board, row, col, dr, dc, player) >= 5) {
                return true
            }
        }
        
        return false
    }
    
    /**
     * 🔄 获取对手
     */
    private fun opponent(player: Int): Int = if (player == BLACK) WHITE else BLACK
}
