package com.example.xihe.scenarios

import android.content.Context
import com.example.xihe.utils.LogManager
import android.view.accessibility.AccessibilityNodeInfo
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.utils.DocumentParser
import kotlinx.coroutines.delay
import java.io.File

/**
 * 📝 表单填充/批量填数据场景
 * 
 * 支持：
 * - 从 Excel/CSV 导入数据
 * - 自动识别表单字段并填充
 * - 支持多条记录批量处理
 * - 提交前二次确认（默认开启）
 * - 失败重试与执行报告
 * 
 * 适用场景：OA系统录入、报销单填写、信息登记等
 */
class FormFillerScenario(context: Context) : ScenarioBase(context, "填数据") {
    
    companion object {
        private const val TAG = "FormFillerScenario"
    }
    
    /**
     * ⚙️ 表单填充配置
     */
    data class FormFillerConfig(
        val dataSource: DataSource,                     // 数据来源
        val fieldMappings: List<FieldMapping>,          // 字段映射
        val submitAfterFill: Boolean = false,           // 填完后自动提交
        val confirmBeforeFormSubmit: Boolean = true,    // 提交前确认
        val delayBetweenRecords: Long = 2000L,         // 记录间隔(ms)
        val retryOnFail: Boolean = true,               // 失败重试
        val maxRetries: Int = 3                         // 最大重试次数
    ) : ScenarioConfig(
        maxIterations = when (dataSource) {
            is DataSource.Manual -> 1
            is DataSource.ExcelFile -> dataSource.rowCount
            is DataSource.CsvFile -> dataSource.rowCount
            is DataSource.JsonData -> dataSource.records.size
        }
    )
    
    /**
     * 📊 数据来源
     */
    sealed class DataSource {
        data class Manual(val fields: Map<String, String>) : DataSource()
        data class ExcelFile(val filePath: String, val sheetIndex: Int = 0, val rowCount: Int = 1) : DataSource()
        data class CsvFile(val filePath: String, val rowCount: Int = 1) : DataSource()
        data class JsonData(val records: List<Map<String, String>>) : DataSource()
    }
    
    /**
     * 🔗 字段映射
     */
    data class FieldMapping(
        val sourceField: String,        // 数据源字段名
        val targetHint: String,         // 目标输入框提示文本
        val targetResourceId: String? = null,  // 目标输入框 resourceId（可选）
        val inputType: InputType = InputType.TEXT
    )
    
    enum class InputType {
        TEXT,           // 普通文本
        NUMBER,         // 数字
        DATE,           // 日期
        DROPDOWN,       // 下拉选择
        CHECKBOX,       // 复选框
        RADIO           // 单选框
    }
    
    /**
     * 📋 执行报告
     */
    data class ExecutionReport(
        val totalRecords: Int,
        val successCount: Int,
        val failCount: Int,
        val failedRecords: List<FailedRecord>,
        val startTime: Long,
        val endTime: Long
    ) {
        val duration: Long get() = endTime - startTime
        val successRate: Float get() = if (totalRecords > 0) successCount.toFloat() / totalRecords else 0f
    }
    
    data class FailedRecord(
        val index: Int,
        val data: Map<String, String>,
        val errorMessage: String
    )
    
    // 执行报告
    private var report: ExecutionReport? = null
    private val failedRecords = mutableListOf<FailedRecord>()
    
    /**
     * 🔍 检测用户意图
     */
    fun detectIntent(userInput: String): FormFillerConfig? {
        val input = userInput.lowercase()
        
        // 检测是否是填数据意图
        val isFormIntent = input.contains(Regex("填(写|充|数据|表|表单)|录入|批量(填|输入)|自动填"))
        if (!isFormIntent) return null
        
        // 检测数据来源
        val excelMatch = Regex("""从?\s*(excel|xlsx?|表格)\s*[：:]\s*(.+?)(?:\s|$)""").find(input)
        val csvMatch = Regex("""从?\s*csv\s*[：:]\s*(.+?)(?:\s|$)""").find(input)
        
        // 简单检测，实际使用时需要更详细的配置
        LogManager.d(TAG, "✅ 检测到填数据意图")
        
        return null // 需要更多信息才能构建完整配置
    }
    
    /**
     * 🎯 执行表单填充
     */
    override suspend fun execute(config: ScenarioConfig): ScenarioResult {
        val formConfig = config as? FormFillerConfig
            ?: return ScenarioResult.Failure("配置类型错误")
        
        val service = CoreAccessibilityService.instance
            ?: return ScenarioResult.Failure("无障碍服务未启动")
        
        // 重置状态
        failedRecords.clear()
        val startTime = System.currentTimeMillis()
        
        // 加载数据
        val records = loadData(formConfig.dataSource)
        if (records.isEmpty()) {
            return ScenarioResult.Failure("没有要填充的数据")
        }
        
        log("📊 共 ${records.size} 条记录待填充")
        updateProgress(message = "开始填充 ${records.size} 条记录... 📝")
        
        var successCount = 0
        var failCount = 0
        
        // 逐条处理
        for ((index, record) in records.withIndex()) {
            if (shouldStop()) {
                return ScenarioResult.Stopped(
                    message = "已停止，完成 $successCount/${records.size} 条",
                    completedSteps = successCount,
                    totalSteps = records.size
                )
            }
            
            updateProgress(
                currentStep = index + 1,
                message = "正在填充第 ${index + 1}/${records.size} 条记录... 📝",
                successCount = successCount,
                failCount = failCount
            )
            
            // 填充单条记录
            val result = fillSingleRecord(
                service = service,
                record = record,
                mappings = formConfig.fieldMappings,
                config = formConfig
            )
            
            if (result.success) {
                successCount++
                
                // 是否提交
                if (formConfig.submitAfterFill) {
                    if (formConfig.confirmBeforeFormSubmit) {
                        // 需要确认（这里可以通过回调让用户确认）
                        updateProgress(message = "⚠️ 等待确认提交第 ${index + 1} 条...")
                        delay(2000) // 给用户看的时间
                    }
                    
                    val submitted = clickSubmitButton(service)
                    if (!submitted) {
                        log("⚠️ 提交按钮点击失败")
                    }
                    delay(1000)
                }
            } else {
                failCount++
                failedRecords.add(FailedRecord(index, record, result.message))
                
                // 重试逻辑
                if (formConfig.retryOnFail) {
                    var retrySuccess = false
                    for (retry in 1..formConfig.maxRetries) {
                        log("🔄 重试第 $retry 次...")
                        delay(1000)
                        
                        val retryResult = fillSingleRecord(service, record, formConfig.fieldMappings, formConfig)
                        if (retryResult.success) {
                            retrySuccess = true
                            successCount++
                            failCount--
                            failedRecords.removeAt(failedRecords.lastIndex)
                            break
                        }
                    }
                    
                    if (!retrySuccess) {
                        log("❌ 重试失败，跳过此条记录")
                    }
                }
            }
            
            // 记录间隔
            if (index < records.size - 1) {
                delay(formConfig.delayBetweenRecords)
            }
        }
        
        // 生成报告
        report = ExecutionReport(
            totalRecords = records.size,
            successCount = successCount,
            failCount = failCount,
            failedRecords = failedRecords.toList(),
            startTime = startTime,
            endTime = System.currentTimeMillis()
        )
        
        updateProgress(
            currentStep = records.size,
            message = "✅ 完成！成功 $successCount 条，失败 $failCount 条",
            successCount = successCount,
            failCount = failCount
        )
        
        return if (failCount == 0) {
            ScenarioResult.Success(
                message = "全部 ${records.size} 条记录填充成功",
                completedSteps = successCount,
                totalSteps = records.size
            )
        } else if (successCount > 0) {
            ScenarioResult.PartialSuccess(
                message = "完成 $successCount/${records.size} 条，$failCount 条失败",
                completedSteps = successCount,
                totalSteps = records.size
            )
        } else {
            ScenarioResult.Failure(
                error = "全部失败",
                message = "全部 ${records.size} 条记录填充失败",
                completedSteps = 0,
                totalSteps = records.size
            )
        }
    }
    
    /**
     * 📂 加载数据
     */
    private fun loadData(dataSource: DataSource): List<Map<String, String>> {
        return when (dataSource) {
            is DataSource.Manual -> listOf(dataSource.fields)
            is DataSource.JsonData -> dataSource.records
            is DataSource.ExcelFile -> loadExcelData(dataSource.filePath, dataSource.sheetIndex)
            is DataSource.CsvFile -> loadCsvData(dataSource.filePath)
        }
    }
    
    /**
     * 📊 加载 Excel 数据
     */
    private fun loadExcelData(filePath: String, sheetIndex: Int): List<Map<String, String>> {
        return try {
            val file = File(filePath)
            if (!file.exists()) {
                log("❌ Excel 文件不存在: $filePath")
                return emptyList()
            }
            
            // 简化：直接读取文件内容
            val content = file.readText()
            
            // 解析为结构化数据（这里需要根据实际格式处理）
            // 简化：假设每行是 "字段1:值1, 字段2:值2" 格式
            content.split("\n")
                .filter { it.isNotBlank() }
                .map { line: String ->
                    line.split(",")
                        .mapNotNull { part: String ->
                            val parts = part.split(":")
                            if (parts.size == 2) parts[0].trim() to parts[1].trim() else null
                        }
                        .toMap()
                }
        } catch (e: Exception) {
            log("❌ 加载 Excel 失败: ${e.message}")
            emptyList()
        }
    }
    
    /**
     * 📄 加载 CSV 数据
     */
    private fun loadCsvData(filePath: String): List<Map<String, String>> {
        return try {
            val file = File(filePath)
            if (!file.exists()) {
                log("❌ CSV 文件不存在: $filePath")
                return emptyList()
            }
            
            val lines = file.readLines()
            if (lines.size < 2) return emptyList()
            
            val headers = lines[0].split(",").map { it.trim() }
            
            lines.drop(1).map { line ->
                val values = line.split(",").map { it.trim() }
                headers.zip(values).toMap()
            }
        } catch (e: Exception) {
            log("❌ 加载 CSV 失败: ${e.message}")
            emptyList()
        }
    }
    
    /**
     * 📝 填充单条记录
     */
    private suspend fun fillSingleRecord(
        service: CoreAccessibilityService,
        record: Map<String, String>,
        mappings: List<FieldMapping>,
        config: FormFillerConfig
    ): FillResult {
        val rootNode = service.rootInActiveWindow
            ?: return FillResult(false, "无法获取屏幕内容")
        
        var filledCount = 0
        var errorMessage = ""
        
        for (mapping in mappings) {
            val value = record[mapping.sourceField]
            if (value.isNullOrEmpty()) {
                log("⚠️ 字段 ${mapping.sourceField} 值为空，跳过")
                continue
            }
            
            // 安全检查
            if (SafetyGuard.containsDangerousContent(value)) {
                val warning = SafetyGuard.generateWarning(value)
                log("⚠️ $warning")
                // 可以在这里添加用户确认逻辑
            }
            
            // 查找目标输入框
            val targetNode = findInputField(rootNode, mapping)
            
            if (targetNode != null) {
                val filled = fillField(service, targetNode, value, mapping.inputType)
                if (filled) {
                    filledCount++
                    log("✅ 填充字段 ${mapping.sourceField} = $value")
                } else {
                    errorMessage = "填充字段 ${mapping.sourceField} 失败"
                    log("❌ $errorMessage")
                }
            } else {
                errorMessage = "未找到字段 ${mapping.targetHint}"
                log("❌ $errorMessage")
            }
            
            // 字段间延迟
            humanDelay(200, 100)
        }
        
        return FillResult(
            success = filledCount > 0 && errorMessage.isEmpty(),
            message = if (errorMessage.isEmpty()) "成功填充 $filledCount 个字段" else errorMessage
        )
    }
    
    /**
     * 🔍 查找输入框
     */
    private fun findInputField(root: AccessibilityNodeInfo, mapping: FieldMapping): AccessibilityNodeInfo? {
        // 优先通过 resourceId 查找
        if (!mapping.targetResourceId.isNullOrEmpty()) {
            val byId = root.findAccessibilityNodeInfosByViewId(mapping.targetResourceId)
            if (byId.isNotEmpty()) return byId[0]
        }
        
        // 通过提示文本查找
        return findNodeByHint(root, mapping.targetHint)
    }
    
    /**
     * 🔍 通过提示文本查找节点
     */
    private fun findNodeByHint(node: AccessibilityNodeInfo, hint: String): AccessibilityNodeInfo? {
        val nodeText = node.text?.toString() ?: ""
        val nodeHint = node.hintText?.toString() ?: ""
        val nodeDesc = node.contentDescription?.toString() ?: ""
        
        // 检查是否匹配
        if (nodeText.contains(hint, ignoreCase = true) ||
            nodeHint.contains(hint, ignoreCase = true) ||
            nodeDesc.contains(hint, ignoreCase = true)) {
            
            // 如果是可编辑的，直接返回
            if (node.isEditable) return node
            
            // 否则查找附近的可编辑节点
            val parent = node.parent
            if (parent != null) {
                for (i in 0 until parent.childCount) {
                    val sibling = parent.getChild(i)
                    if (sibling?.isEditable == true) return sibling
                }
            }
        }
        
        // 递归查找子节点
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findNodeByHint(child, hint)
            if (found != null) return found
        }
        
        return null
    }
    
    /**
     * ⌨️ 填充字段
     */
    private suspend fun fillField(
        service: CoreAccessibilityService,
        node: AccessibilityNodeInfo,
        value: String,
        inputType: InputType
    ): Boolean {
        return when (inputType) {
            InputType.TEXT, InputType.NUMBER, InputType.DATE -> {
                // 聚焦并输入
                node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                delay(100)
                node.performAction(AccessibilityNodeInfo.ACTION_CLEAR_SELECTION)
                
                // 清空现有内容
                val arguments = android.os.Bundle()
                arguments.putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                    value
                )
                node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
            }
            InputType.DROPDOWN -> {
                // 点击展开下拉框
                node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                delay(500)
                // 需要在弹出的列表中查找并点击目标选项
                service.findAndClick(value)
            }
            InputType.CHECKBOX, InputType.RADIO -> {
                // 如果需要选中且当前未选中，则点击
                if (!node.isChecked) {
                    node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                }
                true
            }
        }
    }
    
    /**
     * 📤 点击提交按钮
     */
    private suspend fun clickSubmitButton(service: CoreAccessibilityService): Boolean {
        val submitTexts = listOf("提交", "保存", "确认", "完成", "Submit", "Save", "Confirm", "Done")
        
        for (text in submitTexts) {
            if (service.findAndClick(text)) {
                return true
            }
        }
        
        return false
    }
    
    /**
     * 📋 获取执行报告
     */
    fun getReport(): ExecutionReport? = report
    
    /**
     * 🎯 快捷方法：填充单条数据
     */
    suspend fun fillSingle(
        fields: Map<String, String>,
        mappings: List<FieldMapping>,
        submitAfterFill: Boolean = false,
        onProgress: (String) -> Unit = {}
    ): ScenarioResult {
        val config = FormFillerConfig(
            dataSource = DataSource.Manual(fields),
            fieldMappings = mappings,
            submitAfterFill = submitAfterFill
        )
        
        return start(config)
    }
    
    /**
     * 🎯 快捷方法：从 CSV 批量填充
     */
    suspend fun fillFromCsv(
        csvPath: String,
        mappings: List<FieldMapping>,
        submitAfterFill: Boolean = false,
        onProgress: (String) -> Unit = {}
    ): ScenarioResult {
        val lines = File(csvPath).readLines()
        val rowCount = lines.size - 1 // 减去标题行
        
        val config = FormFillerConfig(
            dataSource = DataSource.CsvFile(csvPath, rowCount),
            fieldMappings = mappings,
            submitAfterFill = submitAfterFill
        )
        
        return start(config)
    }
    
    private data class FillResult(val success: Boolean, val message: String)
}
