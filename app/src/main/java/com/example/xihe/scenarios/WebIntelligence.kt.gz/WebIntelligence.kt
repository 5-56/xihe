package com.example.xihe.scenarios

import android.graphics.Rect
import com.example.xihe.utils.LogManager
import android.view.accessibility.AccessibilityNodeInfo
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.core.ScrollDirection
import com.example.xihe.screen.ScreenAnalyzer
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * 🌐 网页智能处理模块
 * 
 * 功能：
 * - 📄 网页内容提取
 * - 🏗️ 网页结构分析
 * - 🎯 网页元素识别
 * - 🔗 网页链接提取
 * - 📜 智能滚动
 * - 🖱️ 智能点击
 * - 📝 表单自动填充
 * - 🔍 搜索优化
 */
object WebIntelligence {
    
    private const val TAG = "WebIntelligence"
    
    // 表单数据缓存
    private val formDataCache = mutableMapOf<String, FormData>()
    
    // 浏览历史
    private val browsingHistory = mutableListOf<BrowsingRecord>()
    
    // 当前页面状态
    private val _currentPageState = MutableStateFlow<WebPageState?>(null)
    val currentPageState = _currentPageState.asStateFlow()
    
    // ==================== 📄 网页内容提取 ====================
    
    /**
     * 📄 提取网页主要内容
     */
    fun extractPageContent(rootNode: AccessibilityNodeInfo?): WebPageContent {
        if (rootNode == null) {
            return WebPageContent.empty()
        }
        
        LogManager.d(TAG, "📄 开始提取网页内容")
        
        val title = extractPageTitle(rootNode)
        val mainText = extractMainText(rootNode)
        val links = extractLinks(rootNode)
        val images = extractImages(rootNode)
        val buttons = extractButtons(rootNode)
        val inputs = extractInputFields(rootNode)
        
        val content = WebPageContent(
            title = title,
            mainText = mainText,
            links = links,
            images = images,
            buttons = buttons,
            inputFields = inputs,
            wordCount = mainText.sumOf { it.length },
            extractedAt = System.currentTimeMillis()
        )
        
        LogManager.d(TAG, "📄 提取完成: title=$title, links=${links.size}, buttons=${buttons.size}")
        
        return content
    }
    
    private fun extractPageTitle(rootNode: AccessibilityNodeInfo): String {
        // 尝试从不同位置提取标题
        val titleCandidates = mutableListOf<String>()
        
        // 查找标题元素
        traverseNodes(rootNode) { node ->
            val className = node.className?.toString() ?: ""
            val text = node.text?.toString() ?: ""
            val desc = node.contentDescription?.toString() ?: ""
            
            // 标题特征
            when {
                className.contains("Title", ignoreCase = true) -> titleCandidates.add(text)
                className.contains("Heading", ignoreCase = true) -> titleCandidates.add(text)
                node.viewIdResourceName?.contains("title", ignoreCase = true) == true -> titleCandidates.add(text)
                text.isNotEmpty() && text.length in 5..50 && !text.contains("\n") -> {
                    // 可能是标题的文本
                    if (isLikelyTitle(text)) {
                        titleCandidates.add(text)
                    }
                }
            }
        }
        
        return titleCandidates.firstOrNull { it.isNotBlank() } ?: "未知页面"
    }
    
    private fun isLikelyTitle(text: String): Boolean {
        // 判断是否像标题
        return text.length >= 4 && 
               text.length <= 50 && 
               !text.contains("http") &&
               !text.matches(Regex("""^\d+$""")) &&
               !text.contains(Regex("""[<>{}[\]]"""))
    }
    
    private fun extractMainText(rootNode: AccessibilityNodeInfo): List<String> {
        val textBlocks = mutableListOf<String>()
        
        traverseNodes(rootNode) { node ->
            val text = node.text?.toString()?.trim() ?: ""
            
            // 过滤条件：有效的文本内容
            if (text.length >= 10 && 
                !text.startsWith("http") &&
                !isNavigationText(text)) {
                textBlocks.add(text)
            }
        }
        
        return textBlocks.distinct()
    }
    
    private fun isNavigationText(text: String): Boolean {
        val navKeywords = listOf("首页", "返回", "更多", "登录", "注册", "下载", "分享", "收藏")
        return navKeywords.any { text == it || text.length < 4 }
    }
    
    // 指纹缓存，防止 1s 内重复解析相同界面
    private var lastAnalysisFingerprint = ""
    private var lastAnalysisTime = 0L
    private var cachedStructure: WebPageStructure? = null

    /**
     * 🏗️ 分析网页结构 (优化版)
     */
    fun analyzePageStructure(rootNode: AccessibilityNodeInfo?): WebPageStructure {
        if (rootNode == null) return WebPageStructure.empty()
        
        val now = System.currentTimeMillis()
        val currentFingerprint = "${rootNode.childCount}_${rootNode.className}"
        
        if (now - lastAnalysisTime < 1000 && currentFingerprint == lastAnalysisFingerprint) {
            cachedStructure?.let { return it }
        }

        LogManager.d(TAG, "🏗️ 执行深度网页结构分析...")
        
        val regions = mutableListOf<PageRegion>()
        // 迭代式遍历优化，避免递归
        val hierarchy = analyzeHierarchyIterative(rootNode)
        regions.addAll(identifyRegions(rootNode))
        
        val structure = WebPageStructure(
            pageType = identifyWebPageType(rootNode),
            layoutMode = detectLayoutMode(rootNode),
            regions = regions,
            hierarchy = hierarchy,
            hasHeader = regions.any { it.type == RegionType.HEADER },
            hasFooter = regions.any { it.type == RegionType.FOOTER },
            hasNavigation = regions.any { it.type == RegionType.NAVIGATION },
            hasSidebar = regions.any { it.type == RegionType.SIDEBAR }
        )

        lastAnalysisFingerprint = currentFingerprint
        lastAnalysisTime = now
        cachedStructure = structure
        return structure
    }

    /**
     * 🚀 迭代式遍历节点（非递归 BFS）
     */
    private fun traverseNodes(root: AccessibilityNodeInfo, action: (AccessibilityNodeInfo) -> Unit) {
        val queue: java.util.Queue<AccessibilityNodeInfo> = java.util.LinkedList()
        queue.add(root)
        var processedCount = 0
        
        while (queue.isNotEmpty() && processedCount < 1000) { // 限制最大处理节点数，防止网页过大
            val node = queue.poll() ?: continue
            processedCount++
            
            // 性能核心：仅处理可见节点
            if (node.isVisibleToUser) {
                action(node)
                for (i in 0 until node.childCount) {
                    node.getChild(i)?.let { queue.add(it) }
                }
            }
        }
    }

    private fun analyzeHierarchyIterative(root: AccessibilityNodeInfo): HierarchyNode {
        // 简单层级提取，不再深度递归
        return HierarchyNode(
            className = root.className?.toString() ?: "Root",
            text = root.text?.toString()?.take(20),
            depth = 0,
            childCount = root.childCount,
            children = emptyList() // 在性能优先模式下，不构建完整子树
        )
    }
    
    private fun identifyWebPageType(rootNode: AccessibilityNodeInfo): WebPageType {
        val content = StringBuilder()
        traverseNodes(rootNode) { node ->
            content.append(node.text?.toString() ?: "")
            content.append(node.contentDescription?.toString() ?: "")
        }
        
        val text = content.toString().lowercase()
        
        return when {
            text.contains("搜索结果") || text.contains("search results") -> WebPageType.SEARCH_RESULTS
            text.contains("登录") || text.contains("login") || text.contains("sign in") -> WebPageType.LOGIN
            text.contains("注册") || text.contains("register") || text.contains("sign up") -> WebPageType.REGISTER
            text.contains("购物车") || text.contains("cart") -> WebPageType.SHOPPING_CART
            text.contains("支付") || text.contains("checkout") || text.contains("payment") -> WebPageType.CHECKOUT
            text.contains("商品详情") || text.contains("product") -> WebPageType.PRODUCT_DETAIL
            text.contains("文章") || text.contains("article") -> WebPageType.ARTICLE
            text.contains("视频") || text.contains("video") -> WebPageType.VIDEO
            text.contains("图片") || text.contains("gallery") -> WebPageType.GALLERY
            text.contains("设置") || text.contains("settings") -> WebPageType.SETTINGS
            else -> WebPageType.GENERAL
        }
    }
    
    private fun detectLayoutMode(rootNode: AccessibilityNodeInfo): LayoutMode {
        var horizontalCount = 0
        var verticalCount = 0
        
        traverseNodes(rootNode) { node ->
            val className = node.className?.toString() ?: ""
            when {
                className.contains("RecyclerView") || className.contains("ListView") -> verticalCount++
                className.contains("HorizontalScrollView") -> horizontalCount++
                className.contains("GridView") || className.contains("Grid") -> horizontalCount++
            }
        }
        
        return when {
            horizontalCount > verticalCount -> LayoutMode.GRID
            verticalCount > 0 -> LayoutMode.LIST
            else -> LayoutMode.MIXED
        }
    }
    
    /**
     * 🔍 识别页面区域
     */
    private fun identifyRegions(rootNode: AccessibilityNodeInfo): List<PageRegion> {
        val regions = mutableListOf<PageRegion>()
        val screenRect = android.graphics.Rect()
        rootNode.getBoundsInScreen(screenRect)
        val screenHeight = screenRect.height()
        
        traverseNodes(rootNode) { node ->
            val rect = android.graphics.Rect()
            node.getBoundsInScreen(rect)
            val className = node.className?.toString()?.lowercase() ?: ""
            val text = (node.text?.toString() ?: "") + (node.contentDescription?.toString() ?: "")
            
            val regionType = when {
                // 顶部区域通常是 Header
                rect.top < screenHeight * 0.1 && (className.contains("toolbar") || className.contains("actionbar")) -> RegionType.HEADER
                // 底部区域通常是 Footer
                rect.top > screenHeight * 0.9 && node.isClickable -> RegionType.FOOTER
                // 导航区域
                className.contains("navigation") || className.contains("tab") -> RegionType.NAVIGATION
                // 侧边栏
                (rect.left < 100 || rect.right > screenHeight - 100) && rect.height() > screenHeight * 0.5 -> RegionType.SIDEBAR
                // 主要内容区域
                className.contains("recycler") || className.contains("scroll") -> RegionType.CONTENT
                else -> null
            }
            
            regionType?.let {
                regions.add(PageRegion(
                    type = it,
                    bounds = rect,
                    nodeCount = node.childCount
                ))
            }
        }
        
        return regions.distinctBy { it.type } // 每种类型只保留一个
    }
    
    // ==================== 🎯 网页元素识别 ====================
    
    /**
     * 🎯 识别网页元素
     */
    fun identifyElements(rootNode: AccessibilityNodeInfo?): WebElementsResult {
        if (rootNode == null) {
            return WebElementsResult.empty()
        }
        
        LogManager.d(TAG, "🎯 识别网页元素")
        
        val clickables = mutableListOf<WebElement>()
        val scrollables = mutableListOf<WebElement>()
        val inputs = mutableListOf<WebElement>()
        val images = mutableListOf<WebElement>()
        val texts = mutableListOf<WebElement>()
        
        traverseNodes(rootNode) { node ->
            val rect = Rect()
            node.getBoundsInScreen(rect)
            
            val element = WebElement(
                id = node.viewIdResourceName,
                className = node.className?.toString() ?: "",
                text = node.text?.toString(),
                contentDescription = node.contentDescription?.toString(),
                bounds = rect,
                isClickable = node.isClickable,
                isScrollable = node.isScrollable,
                isEditable = node.isEditable,
                isCheckable = node.isCheckable,
                isChecked = node.isChecked
            )
            
            when {
                node.isClickable -> clickables.add(element)
                node.isScrollable -> scrollables.add(element)
                node.isEditable -> inputs.add(element)
                node.className?.toString()?.contains("Image", ignoreCase = true) == true -> images.add(element)
                node.text?.isNotEmpty() == true -> texts.add(element)
            }
        }
        
        return WebElementsResult(
            clickableElements = clickables,
            scrollableElements = scrollables,
            inputElements = inputs,
            imageElements = images,
            textElements = texts,
            totalElements = clickables.size + scrollables.size + inputs.size + images.size + texts.size
        )
    }
    
    // ==================== 🔗 网页链接提取 ====================
    
    /**
     * 🔗 提取网页链接
     */
    fun extractLinks(rootNode: AccessibilityNodeInfo?): List<WebLink> {
        if (rootNode == null) return emptyList()
        
        val links = mutableListOf<WebLink>()
        
        traverseNodes(rootNode) { node ->
            val text = node.text?.toString() ?: ""
            val desc = node.contentDescription?.toString() ?: ""
            val className = node.className?.toString() ?: ""
            
            // 检测链接特征
            val isLink = node.isClickable && (
                className.contains("Link", ignoreCase = true) ||
                className.contains("Button", ignoreCase = true) ||
                text.contains("http") ||
                desc.contains("链接") ||
                node.viewIdResourceName?.contains("link", ignoreCase = true) == true
            )
            
            if (isLink && (text.isNotEmpty() || desc.isNotEmpty())) {
                val rect = Rect()
                node.getBoundsInScreen(rect)
                
                links.add(WebLink(
                    text = text.ifEmpty { desc },
                    url = extractUrlFromNode(node),
                    bounds = rect,
                    linkType = detectLinkType(text, desc, className)
                ))
            }
        }
        
        return links.distinctBy { it.text }
    }
    
    private fun extractUrlFromNode(node: AccessibilityNodeInfo): String? {
        // 尝试从文本中提取URL
        val text = node.text?.toString() ?: node.contentDescription?.toString() ?: ""
        val urlPattern = Regex("""https?://[^\s<>"{}|\\^`\[\]]+""")
        return urlPattern.find(text)?.value
    }
    
    private fun detectLinkType(text: String, desc: String, className: String): LinkType {
        val combined = "$text $desc $className".lowercase()
        return when {
            combined.contains("nav") || combined.contains("menu") -> LinkType.NAVIGATION
            combined.contains("ad") || combined.contains("广告") || combined.contains("推广") -> LinkType.ADVERTISEMENT
            combined.contains("article") || combined.contains("文章") -> LinkType.ARTICLE
            combined.contains("product") || combined.contains("商品") -> LinkType.PRODUCT
            combined.contains("image") || combined.contains("图片") -> LinkType.IMAGE
            combined.contains("video") || combined.contains("视频") -> LinkType.VIDEO
            combined.contains("download") || combined.contains("下载") -> LinkType.DOWNLOAD
            else -> LinkType.GENERAL
        }
    }
    
    private fun extractImages(rootNode: AccessibilityNodeInfo): List<WebImage> {
        val images = mutableListOf<WebImage>()
        
        traverseNodes(rootNode) { node ->
            val className = node.className?.toString() ?: ""
            
            if (className.contains("Image", ignoreCase = true)) {
                val rect = Rect()
                node.getBoundsInScreen(rect)
                
                images.add(WebImage(
                    description = node.contentDescription?.toString(),
                    bounds = rect,
                    isClickable = node.isClickable
                ))
            }
        }
        
        return images
    }
    
    private fun extractButtons(rootNode: AccessibilityNodeInfo): List<WebButton> {
        val buttons = mutableListOf<WebButton>()
        
        traverseNodes(rootNode) { node ->
            val className = node.className?.toString() ?: ""
            val text = node.text?.toString() ?: ""
            
            if (node.isClickable && 
                (className.contains("Button", ignoreCase = true) || 
                 text.length in 1..10)) {
                
                val rect = Rect()
                node.getBoundsInScreen(rect)
                
                buttons.add(WebButton(
                    text = text,
                    bounds = rect,
                    buttonType = detectButtonType(text)
                ))
            }
        }
        
        return buttons
    }
    
    private fun detectButtonType(text: String): ButtonType {
        val lowerText = text.lowercase()
        return when {
            lowerText.contains("搜索") || lowerText.contains("search") -> ButtonType.SEARCH
            lowerText.contains("提交") || lowerText.contains("submit") -> ButtonType.SUBMIT
            lowerText.contains("确认") || lowerText.contains("confirm") || lowerText.contains("ok") -> ButtonType.CONFIRM
            lowerText.contains("取消") || lowerText.contains("cancel") -> ButtonType.CANCEL
            lowerText.contains("登录") || lowerText.contains("login") -> ButtonType.LOGIN
            lowerText.contains("注册") || lowerText.contains("register") -> ButtonType.REGISTER
            lowerText.contains("购买") || lowerText.contains("buy") -> ButtonType.BUY
            lowerText.contains("加入") || lowerText.contains("add") -> ButtonType.ADD
            lowerText.contains("下载") || lowerText.contains("download") -> ButtonType.DOWNLOAD
            lowerText.contains("分享") || lowerText.contains("share") -> ButtonType.SHARE
            else -> ButtonType.GENERAL
        }
    }
    
    private fun extractInputFields(rootNode: AccessibilityNodeInfo): List<WebInputField> {
        val inputs = mutableListOf<WebInputField>()
        
        traverseNodes(rootNode) { node ->
            if (node.isEditable) {
                val rect = Rect()
                node.getBoundsInScreen(rect)
                
                val hint = node.hintText?.toString() ?: ""
                val text = node.text?.toString() ?: ""
                
                inputs.add(WebInputField(
                    hint = hint,
                    currentValue = text,
                    bounds = rect,
                    inputType = detectInputType(hint, node.viewIdResourceName)
                ))
            }
        }
        
        return inputs
    }
    
    private fun detectInputType(hint: String, resourceId: String?): InputType {
        val combined = "$hint ${resourceId ?: ""}".lowercase()
        return when {
            combined.contains("user") || combined.contains("用户") || combined.contains("账号") -> InputType.USERNAME
            combined.contains("password") || combined.contains("密码") -> InputType.PASSWORD
            combined.contains("email") || combined.contains("邮箱") -> InputType.EMAIL
            combined.contains("phone") || combined.contains("手机") || combined.contains("电话") -> InputType.PHONE
            combined.contains("search") || combined.contains("搜索") -> InputType.SEARCH
            combined.contains("address") || combined.contains("地址") -> InputType.ADDRESS
            combined.contains("name") || combined.contains("姓名") -> InputType.NAME
            combined.contains("code") || combined.contains("验证码") -> InputType.VERIFICATION_CODE
            else -> InputType.TEXT
        }
    }
    
    // ==================== 📜 智能滚动 ====================
    
    /**
     * 📜 智能滚动到目标内容
     */
    suspend fun smartScrollToContent(
        service: CoreAccessibilityService,
        targetText: String,
        maxScrolls: Int = 10,
        direction: ScrollDirection = ScrollDirection.DOWN
    ): ScrollResult {
        LogManager.d(TAG, "📜 智能滚动查找: $targetText")
        
        var scrollCount = 0
        var found = false
        var targetBounds: Rect? = null
        
        while (scrollCount < maxScrolls && !found) {
            // 检查当前屏幕
            val rootNode = service.rootInActiveWindow
            if (rootNode != null) {
                val matchResult = findTextInScreen(rootNode, targetText)
                if (matchResult != null) {
                    found = true
                    targetBounds = matchResult.bounds
                    LogManager.d(TAG, "✅ 找到目标: $targetText")
                    break
                }
            }
            
            // 执行滚动
            performSmartScroll(service, direction)
            scrollCount++
            delay(500) // 等待内容加载
        }
        
        return ScrollResult(
            found = found,
            scrollCount = scrollCount,
            targetBounds = targetBounds,
            direction = direction
        )
    }
    
    /**
     * 📜 智能滚动（根据内容长度）
     */
    suspend fun performSmartScroll(
        service: CoreAccessibilityService,
        direction: ScrollDirection,
        intensity: ScrollIntensity = ScrollIntensity.NORMAL
    ) {
        val displayMetrics = service.resources.displayMetrics
        val screenHeight = displayMetrics.heightPixels
        val screenWidth = displayMetrics.widthPixels
        
        val distance = when (intensity) {
            ScrollIntensity.LIGHT -> screenHeight * 0.2f
            ScrollIntensity.NORMAL -> screenHeight * 0.4f
            ScrollIntensity.STRONG -> screenHeight * 0.6f
        }
        
        val centerX = screenWidth / 2f
        val centerY = screenHeight / 2f
        
        when (direction) {
            ScrollDirection.DOWN -> {
                service.performScroll(centerX, centerY + distance / 2, centerX, centerY - distance / 2)
            }
            ScrollDirection.UP -> {
                service.performScroll(centerX, centerY - distance / 2, centerX, centerY + distance / 2)
            }
            ScrollDirection.LEFT -> {
                service.performScroll(centerX + distance / 2, centerY, centerX - distance / 2, centerY)
            }
            ScrollDirection.RIGHT -> {
                service.performScroll(centerX - distance / 2, centerY, centerX + distance / 2, centerY)
            }
        }
    }
    
    private fun findTextInScreen(rootNode: AccessibilityNodeInfo, targetText: String): TextMatchResult? {
        var result: TextMatchResult? = null
        
        traverseNodes(rootNode) { node ->
            val text = node.text?.toString() ?: ""
            val desc = node.contentDescription?.toString() ?: ""
            
            if (text.contains(targetText, ignoreCase = true) || 
                desc.contains(targetText, ignoreCase = true)) {
                val rect = Rect()
                node.getBoundsInScreen(rect)
                result = TextMatchResult(
                    text = text.ifEmpty { desc },
                    bounds = rect,
                    similarity = calculateSimilarity(text, targetText)
                )
                return@traverseNodes
            }
        }
        
        return result
    }
    
    private fun calculateSimilarity(text: String, target: String): Float {
        if (text == target) return 1.0f
        if (text.contains(target)) return 0.9f
        return 0.5f
    }
    
    // ==================== 🖱️ 智能点击 ====================
    
    /**
     * 🖱️ 智能点击目标元素
     */
    suspend fun smartClick(
        service: CoreAccessibilityService,
        target: ClickTarget
    ): ClickResult {
        LogManager.d(TAG, "🖱️ 智能点击: ${target.description}")
        
        val rootNode = service.rootInActiveWindow ?: return ClickResult(
            success = false,
            error = "无法获取屏幕内容"
        )
        
        // 查找目标元素
        val targetNode = when (target) {
            is ClickTarget.ByText -> findNodeByText(rootNode, target.text)
            is ClickTarget.ByType -> findNodeByType(rootNode, target.buttonType)
            is ClickTarget.ByPosition -> findNodeAtPosition(rootNode, target.x, target.y)
            is ClickTarget.ByIndex -> findNodeByIndex(rootNode, target.index, target.elementType)
        }
        
        if (targetNode == null) {
            return ClickResult(success = false, error = "未找到目标元素")
        }
        
        // 获取点击位置
        val rect = Rect()
        targetNode.getBoundsInScreen(rect)
        
        // 执行点击
        val clicked = if (targetNode.isClickable) {
            targetNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        } else {
            service.performClick(rect.exactCenterX(), rect.exactCenterY())
            true
        }
        
        return ClickResult(
            success = clicked,
            clickedBounds = rect,
            elementText = targetNode.text?.toString()
        )
    }
    
    private fun findNodeByText(rootNode: AccessibilityNodeInfo, text: String): AccessibilityNodeInfo? {
        var result: AccessibilityNodeInfo? = null
        
        traverseNodes(rootNode) { node ->
            val nodeText = node.text?.toString() ?: ""
            val desc = node.contentDescription?.toString() ?: ""
            
            if (nodeText.contains(text, ignoreCase = true) || 
                desc.contains(text, ignoreCase = true)) {
                if (node.isClickable || node.isEnabled) {
                    result = node
                    return@traverseNodes
                }
            }
        }
        
        return result
    }
    
    private fun findNodeByType(rootNode: AccessibilityNodeInfo, buttonType: ButtonType): AccessibilityNodeInfo? {
        val keywords = when (buttonType) {
            ButtonType.SEARCH -> listOf("搜索", "search", "🔍")
            ButtonType.SUBMIT -> listOf("提交", "submit", "确定")
            ButtonType.CONFIRM -> listOf("确认", "confirm", "ok", "是")
            ButtonType.CANCEL -> listOf("取消", "cancel", "否")
            ButtonType.LOGIN -> listOf("登录", "login", "sign in")
            ButtonType.REGISTER -> listOf("注册", "register", "sign up")
            ButtonType.BUY -> listOf("购买", "buy", "立即购买")
            ButtonType.ADD -> listOf("加入", "add", "添加")
            ButtonType.DOWNLOAD -> listOf("下载", "download")
            ButtonType.SHARE -> listOf("分享", "share")
            ButtonType.GENERAL -> listOf()
        }
        
        var result: AccessibilityNodeInfo? = null
        
        traverseNodes(rootNode) { node ->
            val text = (node.text?.toString() ?: "") + (node.contentDescription?.toString() ?: "")
            
            if (keywords.any { text.contains(it, ignoreCase = true) } && node.isClickable) {
                result = node
                return@traverseNodes
            }
        }
        
        return result
    }
    
    private fun findNodeAtPosition(rootNode: AccessibilityNodeInfo, x: Float, y: Float): AccessibilityNodeInfo? {
        var result: AccessibilityNodeInfo? = null
        var minDistance = Float.MAX_VALUE
        
        traverseNodes(rootNode) { node ->
            if (node.isClickable) {
                val rect = Rect()
                node.getBoundsInScreen(rect)
                
                if (rect.contains(x.toInt(), y.toInt())) {
                    val dx = rect.centerX() - x
                    val dy = rect.centerY() - y
                    val distance = kotlin.math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                    
                    if (distance < minDistance) {
                        minDistance = distance
                        result = node
                    }
                }
            }
        }
        
        return result
    }
    
    private fun findNodeByIndex(rootNode: AccessibilityNodeInfo, index: Int, elementType: String): AccessibilityNodeInfo? {
        val elements = mutableListOf<AccessibilityNodeInfo>()
        
        traverseNodes(rootNode) { node ->
            val className = node.className?.toString() ?: ""
            
            val matches = when (elementType.lowercase()) {
                "link", "链接" -> node.isClickable && className.contains("TextView")
                "button", "按钮" -> node.isClickable && className.contains("Button")
                "input", "输入框" -> node.isEditable
                "image", "图片" -> className.contains("Image")
                else -> node.isClickable
            }
            
            if (matches) {
                elements.add(node)
            }
        }
        
        return elements.getOrNull(index)
    }
    
    // ==================== 📝 表单自动填充 ====================
    
    /**
     * 📝 自动填充表单
     */
    suspend fun autoFillForm(
        service: CoreAccessibilityService,
        formData: FormData
    ): FormFillResult {
        LogManager.d(TAG, "📝 自动填充表单")
        
        val rootNode = service.rootInActiveWindow ?: return FormFillResult(
            success = false,
            filledFields = 0,
            error = "无法获取屏幕内容"
        )
        
        var filledCount = 0
        val errors = mutableListOf<String>()
        
        // 查找并填充每个字段
        formData.fields.forEach { (fieldType, value) ->
            val inputNode = findInputByType(rootNode, fieldType)
            
            if (inputNode != null) {
                val filled = fillInputField(inputNode, value)
                if (filled) {
                    filledCount++
                    LogManager.d(TAG, "✅ 已填充: $fieldType")
                } else {
                    errors.add("填充失败: $fieldType")
                }
                delay(200) // 字段间延迟
            } else {
                errors.add("未找到字段: $fieldType")
            }
        }
        
        return FormFillResult(
            success = errors.isEmpty(),
            filledFields = filledCount,
            totalFields = formData.fields.size,
            errors = errors
        )
    }
    
    private fun findInputByType(rootNode: AccessibilityNodeInfo, fieldType: InputType): AccessibilityNodeInfo? {
        var result: AccessibilityNodeInfo? = null
        
        traverseNodes(rootNode) { node ->
            if (node.isEditable) {
                val hint = node.hintText?.toString()?.lowercase() ?: ""
                val resourceId = node.viewIdResourceName?.lowercase() ?: ""
                
                val detectedType = detectInputType(hint, resourceId)
                if (detectedType == fieldType) {
                    result = node
                    return@traverseNodes
                }
            }
        }
        
        return result
    }
    
    private fun fillInputField(node: AccessibilityNodeInfo, value: String): Boolean {
        // 先聚焦
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        
        // 清空现有内容
        val clearArgs = android.os.Bundle().apply {
            putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0)
            putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, node.text?.length ?: 0)
        }
        node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, clearArgs)
        
        // 输入新内容
        val inputArgs = android.os.Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value)
        }
        
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, inputArgs)
    }
    
    /**
     * 💾 保存表单数据
     */
    fun saveFormData(formId: String, formData: FormData) {
        formDataCache[formId] = formData
        LogManager.d(TAG, "💾 保存表单数据: $formId")
    }
    
    /**
     * 📂 加载表单数据
     */
    fun loadFormData(formId: String): FormData? {
        return formDataCache[formId]
    }
    
    // ==================== 🔍 搜索优化 ====================
    
    /**
     * 🔍 优化搜索操作
     */
    suspend fun optimizedSearch(
        service: CoreAccessibilityService,
        searchQuery: String,
        searchEngine: SearchEngine = SearchEngine.AUTO
    ): SearchResult {
        LogManager.d(TAG, "🔍 执行优化搜索: $searchQuery")
        
        val rootNode = service.rootInActiveWindow ?: return SearchResult(
            success = false,
            error = "无法获取屏幕内容"
        )
        
        // 1. 查找搜索框
        val searchInput = findSearchInput(rootNode)
        if (searchInput == null) {
            return SearchResult(success = false, error = "未找到搜索框")
        }
        
        // 2. 填入搜索内容
        val filled = fillInputField(searchInput, searchQuery)
        if (!filled) {
            return SearchResult(success = false, error = "输入搜索内容失败")
        }
        
        delay(300)
        
        // 3. 点击搜索按钮
        val updatedRootNode = service.rootInActiveWindow ?: return SearchResult(success = false, error = "无法获取屏幕信息")
        val searchButton = findNodeByType(updatedRootNode, ButtonType.SEARCH)
        if (searchButton != null) {
            searchButton.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        } else {
            // 尝试模拟回车
            // 这里可以通过发送键盘事件实现
        }
        
        return SearchResult(
            success = true,
            searchQuery = searchQuery,
            searchEngine = searchEngine
        )
    }
    
    private fun findSearchInput(rootNode: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var result: AccessibilityNodeInfo? = null
        
        traverseNodes(rootNode) { node ->
            if (node.isEditable) {
                val hint = node.hintText?.toString()?.lowercase() ?: ""
                val resourceId = node.viewIdResourceName?.lowercase() ?: ""
                
                if (hint.contains("搜索") || hint.contains("search") ||
                    resourceId.contains("search") || resourceId.contains("query")) {
                    result = node
                    return@traverseNodes
                }
            }
        }
        
        return result
    }
    
    // ==================== 🔧 辅助方法 ====================
    
    private fun countChildNodes(node: AccessibilityNodeInfo): Int {
        return node.childCount // 简化：不再深度统计，仅返回直接子节点数以节省性能
    }
    
    private fun getScreenHeight(rootNode: AccessibilityNodeInfo): Int {
        val rect = Rect()
        rootNode.getBoundsInScreen(rect)
        return rect.height()
    }
    
    private fun getScreenWidth(rootNode: AccessibilityNodeInfo): Int {
        val rect = Rect()
        rootNode.getBoundsInScreen(rect)
        return rect.width()
    }
}

// ==================== 📦 数据类定义 ====================

// 网页内容
data class WebPageContent(
    val title: String,
    val mainText: List<String>,
    val links: List<WebLink>,
    val images: List<WebImage>,
    val buttons: List<WebButton>,
    val inputFields: List<WebInputField>,
    val wordCount: Int,
    val extractedAt: Long
) {
    companion object {
        fun empty() = WebPageContent("", emptyList(), emptyList(), emptyList(), emptyList(), emptyList(), 0, 0)
    }
}

// 网页结构
data class WebPageStructure(
    val pageType: WebPageType,
    val layoutMode: LayoutMode,
    val regions: List<PageRegion>,
    val hierarchy: HierarchyNode,
    val hasHeader: Boolean,
    val hasFooter: Boolean,
    val hasNavigation: Boolean,
    val hasSidebar: Boolean
) {
    companion object {
        fun empty() = WebPageStructure(
            WebPageType.GENERAL, LayoutMode.MIXED, emptyList(),
            HierarchyNode("", null, 0, 0, emptyList()),
            false, false, false, false
        )
    }
}

// 网页类型
enum class WebPageType {
    SEARCH_RESULTS, LOGIN, REGISTER, SHOPPING_CART, CHECKOUT,
    PRODUCT_DETAIL, ARTICLE, VIDEO, GALLERY, SETTINGS, GENERAL
}

// 布局模式
enum class LayoutMode { LIST, GRID, MIXED }

// 页面区域
data class PageRegion(
    val type: RegionType,
    val bounds: Rect,
    val nodeCount: Int
)

enum class RegionType { HEADER, FOOTER, NAVIGATION, SIDEBAR, CONTENT }

// 层级节点
data class HierarchyNode(
    val className: String,
    val text: String?,
    val depth: Int,
    val childCount: Int,
    val children: List<HierarchyNode>
)

// 网页元素
data class WebElement(
    val id: String?,
    val className: String,
    val text: String?,
    val contentDescription: String?,
    val bounds: Rect,
    val isClickable: Boolean,
    val isScrollable: Boolean,
    val isEditable: Boolean,
    val isCheckable: Boolean,
    val isChecked: Boolean
)

// 元素识别结果
data class WebElementsResult(
    val clickableElements: List<WebElement>,
    val scrollableElements: List<WebElement>,
    val inputElements: List<WebElement>,
    val imageElements: List<WebElement>,
    val textElements: List<WebElement>,
    val totalElements: Int
) {
    companion object {
        fun empty() = WebElementsResult(emptyList(), emptyList(), emptyList(), emptyList(), emptyList(), 0)
    }
}

// 网页链接
data class WebLink(
    val text: String,
    val url: String?,
    val bounds: Rect,
    val linkType: LinkType
)

enum class LinkType { NAVIGATION, ADVERTISEMENT, ARTICLE, PRODUCT, IMAGE, VIDEO, DOWNLOAD, GENERAL }

// 网页图片
data class WebImage(
    val description: String?,
    val bounds: Rect,
    val isClickable: Boolean
)

// 网页按钮
data class WebButton(
    val text: String,
    val bounds: Rect,
    val buttonType: ButtonType
)

enum class ButtonType { SEARCH, SUBMIT, CONFIRM, CANCEL, LOGIN, REGISTER, BUY, ADD, DOWNLOAD, SHARE, GENERAL }

// 输入字段
data class WebInputField(
    val hint: String,
    val currentValue: String,
    val bounds: Rect,
    val inputType: InputType
)

enum class InputType { USERNAME, PASSWORD, EMAIL, PHONE, SEARCH, ADDRESS, NAME, VERIFICATION_CODE, TEXT }

// 滚动强度
enum class ScrollIntensity { LIGHT, NORMAL, STRONG }

// 滚动结果
data class ScrollResult(
    val found: Boolean,
    val scrollCount: Int,
    val targetBounds: Rect?,
    val direction: ScrollDirection
)

// 文本匹配结果
data class TextMatchResult(
    val text: String,
    val bounds: Rect,
    val similarity: Float
)

// 点击目标
sealed class ClickTarget(val description: String) {
    data class ByText(val text: String) : ClickTarget("按文本: $text")
    data class ByType(val buttonType: ButtonType) : ClickTarget("按类型: $buttonType")
    data class ByPosition(val x: Float, val y: Float) : ClickTarget("按位置: ($x, $y)")
    data class ByIndex(val index: Int, val elementType: String) : ClickTarget("第${index}个$elementType")
}

// 点击结果
data class ClickResult(
    val success: Boolean,
    val clickedBounds: Rect? = null,
    val elementText: String? = null,
    val error: String? = null
)

// 表单数据
data class FormData(
    val fields: Map<InputType, String>,
    val formId: String? = null
)

// 表单填充结果
data class FormFillResult(
    val success: Boolean,
    val filledFields: Int,
    val totalFields: Int = 0,
    val errors: List<String> = emptyList(),
    val error: String? = null
)

// 搜索引擎
enum class SearchEngine { BAIDU, GOOGLE, BING, AUTO }

// 搜索结果
data class SearchResult(
    val success: Boolean,
    val searchQuery: String? = null,
    val searchEngine: SearchEngine? = null,
    val error: String? = null
)

// 网页状态
data class WebPageState(
    val url: String?,
    val title: String,
    val pageType: WebPageType,
    val loadTime: Long
)

// 浏览记录
data class BrowsingRecord(
    val url: String?,
    val title: String,
    val visitTime: Long
)
