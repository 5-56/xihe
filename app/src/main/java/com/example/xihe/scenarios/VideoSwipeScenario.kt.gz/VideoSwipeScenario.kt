package com.example.xihe.scenarios

import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.CoreAccessibilityService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

/**
 * 📹 刷视频自动化场景
 * 
 * 支持：抖音、快手、B站、小红书、YouTube 等短视频平台
 * 功能：自动滑动浏览、可配置停留时间、随机化行为模拟人类
 * 
 * ⚠️ 仅用于个人解放双手浏览，不做任何互动操作（点赞/关注/评论）
 */
class VideoSwipeScenario(context: Context) : ScenarioBase(context, "刷视频") {
    
    // 协程作用域
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    
    companion object {
        private const val TAG = "VideoSwipeScenario"
        
        // 支持的视频 App 包名
        val SUPPORTED_APPS = mapOf(
            "抖音" to "com.ss.android.ugc.aweme",
            "快手" to "com.smile.gifmaker",
            "B站" to "tv.danmaku.bili",
            "小红书" to "com.xingin.xhs",
            "YouTube" to "com.google.android.youtube",
            "微信视频号" to "com.tencent.mm",
            "西瓜视频" to "com.ss.android.article.video"
        )
    }
    
    /**
     * ⚙️ 刷视频配置
     */
    data class VideoSwipeConfig(
        val appName: String = "抖音",               // 目标 App
        val swipeCount: Int = 50,                   // 滑动次数
        val minStaySeconds: Int = 3,                // 最小停留秒数
        val maxStaySeconds: Int = 15,               // 最大停留秒数
        val enableRandomPause: Boolean = true,      // 启用随机暂停（模拟看完视频）
        val pauseProbability: Float = 0.2f,         // 暂停概率 (0-1)
        val pauseDurationSeconds: Int = 30,         // 暂停时长
        val swipeDirection: SwipeDirection = SwipeDirection.UP  // 滑动方向
    ) : ScenarioConfig(maxIterations = swipeCount)
    
    enum class SwipeDirection {
        UP,     // 向上滑（下一个视频）
        DOWN,   // 向下滑（上一个视频）
        LEFT,   // 向左滑（某些 App 的下一个）
        RIGHT   // 向右滑
    }
    
    /**
     * 🔍 检测用户意图
     */
    fun detectIntent(userInput: String): VideoSwipeConfig? {
        val input = userInput.lowercase()
        
        // 检测是否是刷视频意图
        val isVideoIntent = input.contains(Regex("刷(视频|抖音|快手|b站|小红书)|看视频|自动(刷|滑|播放)|视频(自动|循环)"))
        if (!isVideoIntent) return null
        
        // 检测目标 App
        val appName = when {
            input.contains("抖音") -> "抖音"
            input.contains("快手") -> "快手"
            input.contains(Regex("b站|哔哩哔哩|bilibili")) -> "B站"
            input.contains("小红书") -> "小红书"
            input.contains(Regex("youtube|油管")) -> "YouTube"
            input.contains("视频号") -> "微信视频号"
            input.contains("西瓜") -> "西瓜视频"
            else -> "抖音" // 默认抖音
        }
        
        // 提取滑动次数
        val countMatch = Regex("""(\d+)\s*(个|条|次|分钟)?""").find(input)
        var swipeCount = countMatch?.groupValues?.get(1)?.toIntOrNull() ?: 50
        
        // 如果是分钟，转换为大约的滑动次数（假设平均每个视频 8 秒）
        if (countMatch?.groupValues?.get(2) == "分钟") {
            swipeCount = swipeCount * 60 / 8
        }
        
        // 提取停留时间
        val stayMatch = Regex("""(停留|看|每个?)\s*(\d+)\s*秒""").find(input)
        val minStay = stayMatch?.groupValues?.get(2)?.toIntOrNull() ?: 3
        val maxStay = minStay + 10
        
        LogManager.d(TAG, "✅ 检测到刷视频意图: App=$appName, 次数=$swipeCount, 停留=${minStay}-${maxStay}秒")
        
        return VideoSwipeConfig(
            appName = appName,
            swipeCount = swipeCount,
            minStaySeconds = minStay,
            maxStaySeconds = maxStay
        )
    }
    
    /**
     * 🎯 执行刷视频 (性能优化版)
     */
    override suspend fun execute(config: ScenarioConfig): ScenarioResult {
        val videoConfig = config as? VideoSwipeConfig 
            ?: return ScenarioResult.Failure("配置类型错误")
        
        val service = CoreAccessibilityService.instance
            ?: return ScenarioResult.Failure("无障碍服务未启动")
        
        val packageName = SUPPORTED_APPS[videoConfig.appName]
            ?: return ScenarioResult.Failure("不支持的 App: ${videoConfig.appName}")
        
        updateProgress(message = "正在启动 ${videoConfig.appName}... 🚀")
        if (!service.launchApp(packageName)) {
            return ScenarioResult.Failure("无法启动 ${videoConfig.appName}")
        }
        
        // 初始等待加载
        waitForSettled(service)
        
        var successCount = 0
        var consecutiveFailures = 0
        var lastFingerprint = ""
        
        for (i in 1..videoConfig.swipeCount) {
            if (shouldStop()) return ScenarioResult.Stopped("用户请求停止", successCount, videoConfig.swipeCount)
            
            updateProgress(currentStep = i, message = "浏览视频 #$i... 📹", successCount = successCount)
            
            // 🆕 智能停留：结合配置与随机性，模拟真实观看行为
            val baseStay = Random.nextInt(videoConfig.minStaySeconds, videoConfig.maxStaySeconds + 1) * 1000L
            delay(baseStay)
            
            // 随机深度观看
            if (videoConfig.enableRandomPause && Random.nextFloat() < videoConfig.pauseProbability) {
                delay(Random.nextInt(5, 15) * 1000L)
            }
            
            // 🆕 执行滑动前的视图检查
            val currentFingerprint = getScreenFingerprint(service)
            if (currentFingerprint == lastFingerprint) {
                log("⚠️ 界面未变化，可能卡住或广告，尝试返回...")
                service.performGlobalBack()
                delay(1000)
            }
            lastFingerprint = currentFingerprint
            
            // 执行滑动
            val swipeSuccess = performSwipe(service, videoConfig.swipeDirection)
            
            if (swipeSuccess) {
                successCount++
                consecutiveFailures = 0
                // 滑动后动态等待界面静止
                waitForSettled(service)
            } else {
                consecutiveFailures++
                if (consecutiveFailures > 3) {
                    log("🚨 连续滑动失败，尝试重启应用")
                    service.launchApp(packageName)
                    delay(3000)
                    consecutiveFailures = 0
                }
            }
            
            humanDelay(500, 300)
        }
        
        return ScenarioResult.Success("✅ 刷视频完成，浏览 $successCount 个视频")
    }

    /**
     * 👁️ 等待界面静止
     */
    private suspend fun waitForSettled(service: CoreAccessibilityService, maxWait: Long = 2000L) {
        var lastNodes = 0
        val startTime = System.currentTimeMillis()
        while (System.currentTimeMillis() - startTime < maxWait) {
            val currentNodes = service.rootInActiveWindow?.nodeCount ?: 0
            if (currentNodes > 0 && currentNodes == lastNodes) break
            lastNodes = currentNodes
            delay(300)
        }
    }

    /**
     * 🧬 获取简单的屏幕指纹（用于判断是否卡住）
     */
    private fun getScreenFingerprint(service: CoreAccessibilityService): String {
        val root = service.rootInActiveWindow ?: return ""
        // 简单的哈希：节点数 + 顶部节点文本
        return "${root.nodeCount}_${root.getChild(0)?.text ?: ""}"
    }

    private val android.view.accessibility.AccessibilityNodeInfo.nodeCount: Int
        get() {
            var count = 1
            for (i in 0 until childCount) {
                count += getChild(i)?.nodeCount ?: 0
            }
            return count
        }
    
    /**
     * 📲 执行滑动手势
     */
    private suspend fun performSwipe(
        service: CoreAccessibilityService,
        direction: SwipeDirection
    ): Boolean {
        val (screenWidth, screenHeight) = service.getScreenSize()
        val centerX = screenWidth / 2f
        val centerY = screenHeight / 2f
        
        // 计算滑动起止点（带随机偏移模拟人类）
        val offsetX = Random.nextInt(-50, 51)
        val offsetY = Random.nextInt(-30, 31)
        
        val (startX, startY, endX, endY) = when (direction) {
            SwipeDirection.UP -> listOf(
                centerX + offsetX,
                screenHeight * 0.75f + offsetY,
                centerX + offsetX + Random.nextInt(-20, 21),
                screenHeight * 0.25f + offsetY
            )
            SwipeDirection.DOWN -> listOf(
                centerX + offsetX,
                screenHeight * 0.25f + offsetY,
                centerX + offsetX + Random.nextInt(-20, 21),
                screenHeight * 0.75f + offsetY
            )
            SwipeDirection.LEFT -> listOf(
                screenWidth * 0.8f + offsetX,
                centerY + offsetY,
                screenWidth * 0.2f + offsetX,
                centerY + offsetY + Random.nextInt(-20, 21)
            )
            SwipeDirection.RIGHT -> listOf(
                screenWidth * 0.2f + offsetX,
                centerY + offsetY,
                screenWidth * 0.8f + offsetX,
                centerY + offsetY + Random.nextInt(-20, 21)
            )
        }
        
        // 随机滑动时长（模拟人类速度差异）
        val duration = Random.nextInt(200, 400).toLong()
        
        return service.swipeAsync(startX, startY, endX, endY, duration)
    }
    
    /**
     * 🎯 快捷启动方法
     */
    suspend fun startSwipe(
        appName: String = "抖音",
        count: Int = 50,
        minStaySeconds: Int = 3,
        maxStaySeconds: Int = 15,
        onProgress: (String) -> Unit = {}
    ): ScenarioResult {
        val config = VideoSwipeConfig(
            appName = appName,
            swipeCount = count,
            minStaySeconds = minStaySeconds,
            maxStaySeconds = maxStaySeconds
        )
        
        // 监听进度
        scope.launch {
            progress.collect { p ->
                onProgress(p.message)
            }
        }
        
        return start(config)
    }
}

