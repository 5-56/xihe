package com.example.xihe.scenarios.games

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import com.example.xihe.utils.LogManager
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.ocr.OCRManager
import com.example.xihe.scenarios.ScenarioBase
import com.example.xihe.scenarios.ScenarioConfig
import com.example.xihe.scenarios.ScenarioResult
import kotlinx.coroutines.delay

/**
 * 斗地主自动出牌场景
 * 
 * 功能：
 * - OCR 识别手牌和场上牌
 * - AI 计算最优出牌组合
 * - 自动选牌并出牌
 * - 支持抢地主决策
 * 
 * 支持的斗地主 App：
 * - 欢乐斗地主
 * - QQ斗地主
 * - 途游斗地主
 * - 其他标准界面的斗地主
 */
class DouDiZhuScenario(context: Context) : ScenarioBase(context, "斗地主") {
    
    companion object {
        private const val TAG = "DouDiZhuScenario"
        
        // 牌面定义（从小到大）
        val CARD_ORDER = listOf("3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A", "2", "小王", "大王")
        val CARD_VALUES = CARD_ORDER.mapIndexed { index, card -> card to index }.toMap()
        
        // 牌型
        enum class CardType {
            SINGLE,         // 单牌
            PAIR,           // 对子
            TRIPLE,         // 三张
            TRIPLE_ONE,     // 三带一
            TRIPLE_TWO,     // 三带二
            STRAIGHT,       // 顺子
            STRAIGHT_PAIR,  // 连对
            PLANE,          // 飞机
            PLANE_WINGS,    // 飞机带翅膀
            FOUR_TWO,       // 四带二
            BOMB,           // 炸弹
            ROCKET,         // 王炸
            PASS            // 不出
        }
        
        // 常见斗地主 App
        val SUPPORTED_APPS = mapOf(
            "欢乐斗地主" to "com.qqgame.happylord",
            "QQ斗地主" to "com.tencent.qqgame.landlord",
            "途游斗地主" to "com.boyaa.ddz",
            "微信欢乐斗地主" to "com.tencent.tmgp.happylord"
        )
    }
    
    /**
     * 斗地主配置
     */
    data class DouDiZhuConfig(
        val appName: String = "欢乐斗地主",
        val autoGrab: Boolean = true,           // 自动抢地主
        val grabThreshold: Int = 15,            // 抢地主阈值（手牌评分）
        val playStyle: PlayStyle = PlayStyle.BALANCED,
        val maxRounds: Int = 100                // 最大局数
    ) : ScenarioConfig(maxIterations = maxRounds)
    
    enum class PlayStyle {
        AGGRESSIVE,     // 激进（优先出大牌）
        BALANCED,       // 平衡
        CONSERVATIVE    // 保守（留大牌压制）
    }
    
    // 游戏状态
    private var myCards = mutableListOf<String>()
    private var lastPlayedCards = listOf<String>()
    private var isLandlord = false
    private var roundCount = 0
    
    private val ocrManager by lazy { OCRManager.getInstance(context) }
    
    /**
     * 检测用户意图
     */
    fun detectIntent(userInput: String): DouDiZhuConfig? {
        val input = userInput.lowercase()
        
        val isDouDiZhuIntent = input.contains(Regex("(斗地主|打牌|ddz).*(自动|帮我|ai)")) ||
                input.contains(Regex("(自动|帮我|ai).*(斗地主|打牌)"))
        
        if (!isDouDiZhuIntent) return null
        
        // 检测 App
        val appName = when {
            input.contains("欢乐") -> "欢乐斗地主"
            input.contains("qq") || input.contains("腾讯") -> "QQ斗地主"
            input.contains("途游") -> "途游斗地主"
            else -> "欢乐斗地主"
        }
        
        // 检测风格
        val style = when {
            input.contains("激进") || input.contains("进攻") -> PlayStyle.AGGRESSIVE
            input.contains("保守") || input.contains("稳") -> PlayStyle.CONSERVATIVE
            else -> PlayStyle.BALANCED
        }
        
        LogManager.d(TAG, "检测到斗地主意图: App=$appName, 风格=$style")
        
        return DouDiZhuConfig(appName = appName, playStyle = style)
    }
    
    /**
     * 执行斗地主对局
     * 🎯 执行斗地主对局
     */
    override suspend fun execute(config: ScenarioConfig): ScenarioResult {
        val ddzConfig = config as? DouDiZhuConfig
            ?: return ScenarioResult.Failure("配置类型错误")
        
        val service = CoreAccessibilityService.instance
            ?: return ScenarioResult.Failure("无障碍服务未启动")
        
        // 启动 App
        val packageName = SUPPORTED_APPS[ddzConfig.appName]
        if (packageName != null) {
            updateProgress(message = "正在启动 ${ddzConfig.appName}... 🃏")
            service.launchApp(packageName)
            delay(5000)
        }
        
        roundCount = 0
        
        // 主循环
        while (roundCount < ddzConfig.maxRounds) {
            if (shouldStop()) {
                return ScenarioResult.Stopped(
                    message = "已停止，共玩 $roundCount 局",
                    completedSteps = roundCount,
                    totalSteps = ddzConfig.maxRounds
                )
            }
            
            // 1. 截图分析当前状态
            val screenshot = service.takeScreenshotAsync()
            if (screenshot == null) {
                delay(1000)
                continue
            }
            
            // 2. 识别游戏状态
            val gameState = recognizeGameState(screenshot)
            
            when (gameState) {
                GameState.WAITING -> {
                    updateProgress(message = "等待游戏开始... 🎮")
                    // 尝试点击开始按钮
                    tryClickButton(service, listOf("开始", "准备", "开局", "匹配"))
                    delay(2000)
                }
                
                GameState.GRABBING -> {
                    updateProgress(message = "抢地主阶段... 👑")
                    if (ddzConfig.autoGrab) {
                        handleGrabLandlord(service, screenshot, ddzConfig.grabThreshold)
                    }
                    delay(1000)
                }
                
                GameState.MY_TURN -> {
                    updateProgress(message = "轮到我出牌... 🤔")
                    handleMyTurn(service, screenshot, ddzConfig.playStyle)
                    delay(500)
                }
                
                GameState.WAITING_OTHERS -> {
                    updateProgress(message = "等待其他玩家出牌... 👀")
                    delay(500)
                }
                
                GameState.ROUND_END -> {
                    roundCount++
                    updateProgress(
                        currentStep = roundCount,
                        message = "本局结束，共玩 $roundCount 局 🎉",
                        successCount = roundCount
                    )
                    // 点击继续
                    tryClickButton(service, listOf("继续", "再来一局", "下一局"))
                    delay(3000)
                }
                
                GameState.UNKNOWN -> {
                    delay(1000)
                }
            }
        }
        
        return ScenarioResult.Success(
            message = "斗地主完成，共玩 $roundCount 局",
            completedSteps = roundCount,
            totalSteps = ddzConfig.maxRounds
        )
    }
    
    /**
     * 🔍 识别游戏状态
     */
    private suspend fun recognizeGameState(screenshot: Bitmap): GameState {
        val ocrResult = ocrManager.recognizeText(screenshot)
        val fullText = ocrResult.textBlocks.joinToString(" ") { it.text }.lowercase()
        
        return when {
            fullText.contains("开始") || fullText.contains("准备") || fullText.contains("匹配") -> GameState.WAITING
            fullText.contains("抢地主") || fullText.contains("叫地主") || fullText.contains("不叫") -> GameState.GRABBING
            fullText.contains("出牌") || fullText.contains("不出") || fullText.contains("要不起") -> GameState.MY_TURN
            fullText.contains("胜利") || fullText.contains("失败") || fullText.contains("结算") -> GameState.ROUND_END
            else -> {
                // 通过检测手牌区域判断
                if (detectMyCards(screenshot).isNotEmpty()) {
                    GameState.WAITING_OTHERS
                } else {
                    GameState.UNKNOWN
                }
            }
        }
    }
    
    enum class GameState {
        WAITING,        // 等待开始
        GRABBING,       // 抢地主阶段
        MY_TURN,        // 轮到我出牌
        WAITING_OTHERS, // 等待其他人
        ROUND_END,      // 本局结束
        UNKNOWN         // 未知状态
    }
    
    /**
     * 👑 处理抢地主
     */
    private suspend fun handleGrabLandlord(
        service: CoreAccessibilityService,
        screenshot: Bitmap,
        threshold: Int
    ) {
        // 识别手牌并评估
        myCards = detectMyCards(screenshot).toMutableList()
        val handScore = evaluateHand(myCards)
        
        log("手牌评分: $handScore, 阈值: $threshold")
        
        if (handScore >= threshold) {
            // 抢地主
            isLandlord = tryClickButton(service, listOf("抢地主", "叫地主", "抢"))
            if (isLandlord) {
                log("✅ 决定抢地主")
            }
        } else {
            // 不抢
            tryClickButton(service, listOf("不叫", "不抢", "过"))
            log("❌ 决定不抢")
        }
    }
    
    /**
     * 🎴 处理出牌
     */
    private suspend fun handleMyTurn(
        service: CoreAccessibilityService,
        screenshot: Bitmap,
        style: PlayStyle
    ) {
        // 识别手牌
        myCards = detectMyCards(screenshot).toMutableList()
        
        // 识别上家出的牌
        lastPlayedCards = detectLastPlayedCards(screenshot)
        
        log("我的手牌: $myCards")
        log("上家出牌: $lastPlayedCards")
        
        // 计算出牌策略
        val cardsToPlay = calculateBestPlay(myCards, lastPlayedCards, style)
        
        if (cardsToPlay.isEmpty()) {
            // 不出/要不起
            tryClickButton(service, listOf("不出", "要不起", "过"))
            log("选择不出")
        } else {
            // 选择并出牌
            log("决定出牌: $cardsToPlay")
            
            // 点击选择每张牌
            for (card in cardsToPlay) {
                val cardPosition = findCardPosition(screenshot, card)
                if (cardPosition != null) {
                    service.tapAsync(cardPosition.first, cardPosition.second)
                    delay(100)
                }
            }
            
            // 点击出牌按钮
            delay(200)
            tryClickButton(service, listOf("出牌", "出"))
            
            // 从手牌中移除
            cardsToPlay.forEach { myCards.remove(it) }
        }
    }
    
    /**
     * 🔍 识别手牌（改进版 - 多策略识别）
     */
    private suspend fun detectMyCards(screenshot: Bitmap): List<String> {
        val height = screenshot.height
        val width = screenshot.width
        
        // 手牌区域：屏幕底部 25%
        val cardAreaTop = (height * 0.75).toInt()
        val cardAreaHeight = height - cardAreaTop
        
        // 确保裁剪区域有效
        if (cardAreaHeight <= 0) {
            log("⚠️ 手牌区域无效")
            return emptyList()
        }
        
        // 裁剪手牌区域
        val cardArea = Bitmap.createBitmap(
            screenshot, 0, cardAreaTop,
            width, cardAreaHeight
        )
        
        // 多轮OCR识别（提高准确率）
        val allCards = mutableListOf<String>()
        
        // 第一轮：全区域识别
        val ocrResult = ocrManager.recognizeText(cardArea)
        allCards.addAll(parseCardsFromOCR(ocrResult))
        
        // 第二轮：如果识别结果太少，尝试分区域识别
        if (allCards.size < 5) {
            val leftArea = Bitmap.createBitmap(cardArea, 0, 0, width / 2, cardAreaHeight)
            val rightArea = Bitmap.createBitmap(cardArea, width / 2, 0, width / 2, cardAreaHeight)
            
            val leftResult = ocrManager.recognizeText(leftArea)
            val rightResult = ocrManager.recognizeText(rightArea)
            
            allCards.addAll(parseCardsFromOCR(leftResult))
            allCards.addAll(parseCardsFromOCR(rightResult))
        }
        
        // 去重并排序
        val uniqueCards = allCards.distinct()
        log("识别到手牌: $uniqueCards")
        
        return uniqueCards.sortedBy { CARD_VALUES[it] ?: 0 }
    }
    
    /**
     * 🃏 从OCR结果解析牌面（改进版）
     */
    private fun parseCardsFromOCR(ocrResult: OCRManager.OCRResult): List<String> {
        val cards = mutableListOf<String>()
        
        // 牌面匹配规则（按优先级排序）
        val cardPatterns = listOf(
            // 大小王
            listOf("大王", "BIG JOKER", "大") to "大王",
            listOf("小王", "SMALL JOKER", "小") to "小王",
            // 数字牌
            listOf("10", "十", "1O", "IO") to "10",
            listOf("2", "二") to "2",
            // 字母牌
            listOf("A", "1") to "A",
            listOf("K", "13") to "K",
            listOf("Q", "12") to "Q",  
            listOf("J", "11") to "J",
            // 其他数字
            listOf("9", "九") to "9",
            listOf("8", "八") to "8",
            listOf("7", "七") to "7",
            listOf("6", "六") to "6",
            listOf("5", "五") to "5",
            listOf("4", "四") to "4",
            listOf("3", "三") to "3"
        )
        
        for (block in ocrResult.textBlocks) {
            val text = block.text.uppercase().trim()
            if (text.isEmpty()) continue
            
            // 按模式匹配
            for ((patterns, cardValue) in cardPatterns) {
                var matched = false
                for (pattern in patterns) {
                    if (text.contains(pattern, ignoreCase = true)) {
                        // 避免重复添加（检查位置相近的牌）
                        if (!cards.contains(cardValue) || cardValue in listOf("大王", "小王")) {
                            cards.add(cardValue)
                        }
                        matched = true
                        break
                    }
                }
                if (matched) break
            }
            
            // 如果没匹配到，尝试直接匹配单字符
            if (text.length == 1) {
                when (text) {
                    "A", "K", "Q", "J" -> cards.add(text)
                    in "2".."9" -> cards.add(text)
                }
            }
        }
        
        return cards
    }
    
    /**
     * 🔍 识别上家出的牌
     */
    private suspend fun detectLastPlayedCards(screenshot: Bitmap): List<String> {
        // 上家出牌区域通常在屏幕中上部
        val height = screenshot.height
        val playAreaTop = (height * 0.3).toInt()
        val playAreaBottom = (height * 0.5).toInt()
        
        val playArea = Bitmap.createBitmap(
            screenshot, 0, playAreaTop,
            screenshot.width, playAreaBottom - playAreaTop
        )
        
        val ocrResult = ocrManager.recognizeText(playArea)
        
        // 解析（类似手牌识别）
        val cards = mutableListOf<String>()
        for (block in ocrResult.textBlocks) {
            val text = block.text.uppercase()
            when {
                text.contains("大王") -> cards.add("大王")
                text.contains("小王") -> cards.add("小王")
                text.contains("10") -> cards.add("10")
                text.matches(Regex(".*[AKQJ2-9].*")) -> {
                    val card = text.filter { it in "AKQJ23456789" || it == '1' }
                    if (card.isNotEmpty()) cards.add(card)
                }
            }
        }
        
        return cards.sortedBy { CARD_VALUES[it] ?: 0 }
    }
    
    /**
     * 🧠 计算最佳出牌
     */
    private fun calculateBestPlay(
        hand: List<String>,
        lastPlayed: List<String>,
        style: PlayStyle
    ): List<String> {
        if (lastPlayed.isEmpty()) {
            // 我先出，选择最小的单牌或组合
            return findSmallestPlay(hand, style)
        }
        
        // 分析上家出牌类型
        val lastType = analyzeCardType(lastPlayed)
        
        // 找能压过的牌
        return findWinningPlay(hand, lastPlayed, lastType, style)
    }
    
    /**
     * 🔍 分析牌型
     */
    private fun analyzeCardType(cards: List<String>): CardType {
        val size = cards.size
        val cardCounts = cards.groupingBy { it }.eachCount()
        val counts = cardCounts.values.sorted()
        
        return when {
            size == 2 && cards[0] == "小王" && cards[1] == "大王" -> CardType.ROCKET
            size == 4 && counts == listOf(4) -> CardType.BOMB
            size == 1 -> CardType.SINGLE
            size == 2 && counts == listOf(2) -> CardType.PAIR
            size == 3 && counts == listOf(3) -> CardType.TRIPLE
            size == 4 && counts == listOf(1, 3) -> CardType.TRIPLE_ONE
            size == 5 && counts == listOf(2, 3) -> CardType.TRIPLE_TWO
            size >= 5 && isConsecutive(cards) && counts.all { it == 1 } -> CardType.STRAIGHT
            size >= 6 && size % 2 == 0 && isConsecutivePairs(cards) -> CardType.STRAIGHT_PAIR
            else -> CardType.SINGLE // 默认
        }
    }
    
    /**
     * 🔍 检查是否连续
     */
    private fun isConsecutive(cards: List<String>): Boolean {
        val values = cards.mapNotNull { CARD_VALUES[it] }.sorted()
        val twoValue = CARD_VALUES["2"] ?: 15
        if (values.any { it >= twoValue }) return false // 2和王不能在顺子中
        
        for (i in 1 until values.size) {
            if (values[i] - values[i - 1] != 1) return false
        }
        return true
    }
    
    /**
     * 🔍 检查是否连对
     */
    private fun isConsecutivePairs(cards: List<String>): Boolean {
        val cardCounts = cards.groupingBy { it }.eachCount()
        if (cardCounts.values.any { it != 2 }) return false
        
        val values = cardCounts.keys.mapNotNull { CARD_VALUES[it] }.sorted()
        return isConsecutive(cardCounts.keys.toList())
    }
    
    /**
     * 🎴 找最小出牌
     */
    private fun findSmallestPlay(hand: List<String>, style: PlayStyle): List<String> {
        val cardCounts = hand.groupingBy { it }.eachCount()
        
        // 优先出单牌
        val singles = cardCounts.filter { it.value == 1 }.keys.toList()
        if (singles.isNotEmpty()) {
            val smallest = singles.minByOrNull { CARD_VALUES[it] ?: 0 }
            if (smallest != null) return listOf(smallest)
        }
        
        // 出对子
        val pairs = cardCounts.filter { it.value >= 2 }.keys.toList()
        if (pairs.isNotEmpty()) {
            val smallest = pairs.minByOrNull { CARD_VALUES[it] ?: 0 }
            if (smallest != null) return listOf(smallest, smallest)
        }
        
        // 出最小的牌
        return listOf(hand.first())
    }
    
    /**
     * 🎴 找能压过的牌
     */
    private fun findWinningPlay(
        hand: List<String>,
        lastPlayed: List<String>,
        lastType: CardType,
        style: PlayStyle
    ): List<String> {
        val lastValue = lastPlayed.maxOfOrNull { CARD_VALUES[it] ?: 0 } ?: 0
        val cardCounts = hand.groupingBy { it }.eachCount()
        
        when (lastType) {
            CardType.SINGLE -> {
                // 找更大的单牌
                val bigger = hand.filter { (CARD_VALUES[it] ?: 0) > lastValue }
                if (bigger.isNotEmpty()) {
                    // 根据风格选择
                    return when (style) {
                        PlayStyle.AGGRESSIVE -> listOf(bigger.last()) // 出最大
                        PlayStyle.CONSERVATIVE -> listOf(bigger.first()) // 出最小能压的
                        else -> listOf(bigger[bigger.size / 2]) // 中间
                    }
                }
            }
            
            CardType.PAIR -> {
                val pairs = cardCounts.filter { it.value >= 2 && (CARD_VALUES[it.key] ?: 0) > lastValue }
                if (pairs.isNotEmpty()) {
                    val card = pairs.keys.minByOrNull { CARD_VALUES[it] ?: 0 }
                    if (card != null) return listOf(card, card)
                }
            }
            
            CardType.TRIPLE, CardType.TRIPLE_ONE, CardType.TRIPLE_TWO -> {
                val triples = cardCounts.filter { it.value >= 3 && (CARD_VALUES[it.key] ?: 0) > lastValue }
                if (triples.isNotEmpty()) {
                    val card = triples.keys.minByOrNull { CARD_VALUES[it] ?: 0 }
                    if (card != null) {
                        val result = mutableListOf(card, card, card)
                        
                        // 带牌
                        if (lastType == CardType.TRIPLE_ONE || lastType == CardType.TRIPLE_TWO) {
                            val extras = hand.filter { it != card }.take(if (lastType == CardType.TRIPLE_ONE) 1 else 2)
                            result.addAll(extras)
                        }
                        return result
                    }
                }
            }
            
            else -> {
                // 复杂牌型，尝试用炸弹
            }
        }
        
        // 尝试用炸弹
        if (style != PlayStyle.CONSERVATIVE) {
            val bombs = cardCounts.filter { it.value == 4 }
            if (bombs.isNotEmpty()) {
                val card = bombs.keys.minByOrNull { CARD_VALUES[it] ?: 0 }
                if (card != null) return listOf(card, card, card, card)
            }
            
            // 王炸
            if (hand.contains("小王") && hand.contains("大王")) {
                return listOf("小王", "大王")
            }
        }
        
        // 要不起
        return emptyList()
    }
    
    /**
     * 📊 评估手牌强度
     */
    private fun evaluateHand(cards: List<String>): Int {
        var score = 0
        val cardCounts = cards.groupingBy { it }.eachCount()
        
        // 王炸
        if (cards.contains("小王") && cards.contains("大王")) {
            score += 10
        }
        
        // 炸弹
        score += cardCounts.count { it.value == 4 } * 8
        
        // 大牌
        cards.forEach { card ->
            when (card) {
                "大王" -> score += 6
                "小王" -> score += 5
                "2" -> score += 3
                "A" -> score += 2
                "K" -> score += 1
            }
        }
        
        // 三张
        score += cardCounts.count { it.value == 3 } * 3
        
        return score
    }
    
    /**
     * 📍 找牌的位置
     */
    private suspend fun findCardPosition(screenshot: Bitmap, card: String): Pair<Float, Float>? {
        val ocrResult = ocrManager.recognizeText(screenshot)
        
        for (block in ocrResult.textBlocks) {
            if (block.text.contains(card, ignoreCase = true)) {
                val bounds = block.boundingBox ?: continue
                return (bounds.centerX().toFloat()) to (bounds.centerY().toFloat())
            }
        }
        
        return null
    }
    
    /**
     * 🖱️ 尝试点击按钮
     */
    private suspend fun tryClickButton(service: CoreAccessibilityService, texts: List<String>): Boolean {
        for (text in texts) {
            if (service.findAndClick(text)) {
                return true
            }
        }
        return false
    }
}
