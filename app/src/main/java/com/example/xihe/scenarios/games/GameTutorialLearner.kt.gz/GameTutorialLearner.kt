package com.example.xihe.scenarios.games

import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.core.AutomationEngine
import com.example.xihe.core.LLMClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import com.example.xihe.data.TrainingDataManager
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * 游戏教程学习器
 * 
 * 功能：
 * - 当AI不会操作某个游戏/软件时，自动搜索网上教程
 * - 整理学习信息，提取关键操作步骤
 * - 缓存学习结果，避免重复搜索
 * - 根据学习结果指导游戏操作
 * - 清洗并保存数据用于模型训练
 */
class GameTutorialLearner(private val context: Context) {
    
    companion object {
        private const val TAG = "GameTutorialLearner"
        private const val CACHE_FILE = "game_tutorials_cache.json"
        private const val MAX_CACHE_SIZE = 100
        private const val CACHE_EXPIRE_DAYS = 7
        
        @Volatile
        private var instance: GameTutorialLearner? = null
        
        fun getInstance(context: Context): GameTutorialLearner {
            return instance ?: synchronized(this) {
                instance ?: GameTutorialLearner(context.applicationContext).also { instance = it }
            }
        }
    }
    
    // 教程缓存
    private val tutorialCache = mutableMapOf<String, TutorialInfo>()
    private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }
    
    // 训练数据管理器
    private val trainingDataManager by lazy { TrainingDataManager.getInstance(context) }
    
    // 是否保存训练数据
    var saveForTraining: Boolean = true
    
    init {
        loadCache()
    }
    
    // ==================== 数据类 ====================
    
    @Serializable
    data class TutorialInfo(
        val gameName: String,
        val objective: String,
        val steps: List<GameStep>,
        val tips: List<String>,
        val buttonKeywords: List<String>,
        val timestamp: Long = System.currentTimeMillis()
    )
    
    @Serializable
    data class GameStep(
        val order: Int,
        val action: String,           // 操作描述
        val targetText: String?,      // 目标按钮/文字
        val targetPosition: String?,  // 位置描述（如"屏幕右上角"）
        val waitAfter: Int = 500      // 操作后等待时间(ms)
    )
    
    @Serializable
    data class SearchResult(
        val title: String,
        val snippet: String,
        val url: String
    )
    
    // ==================== 搜索教程 ====================
    
    /**
     * 搜索并学习游戏教程
     * 
     * @param gameName 游戏名称
     * @param objective 目标（如"自动打怪"、"完成日常"）
     * @return 学习后的教程信息
     */
    suspend fun learnGameTutorial(
        gameName: String,
        objective: String
    ): TutorialInfo? = withContext(Dispatchers.IO) {
        val cacheKey = "${gameName}_${objective}".lowercase()
        
        // 1. 检查缓存
        tutorialCache[cacheKey]?.let { cached ->
            if (!isCacheExpired(cached)) {
                LogManager.d(TAG, "✅ 从缓存加载教程: $gameName - $objective")
                return@withContext cached
            }
        }
        
        LogManager.d(TAG, "🔍 开始搜索教程: $gameName - $objective")
        
        try {
            // 2. 构建搜索查询
            val queries = listOf(
                "$gameName $objective 教程 攻略",
                "$gameName $objective 怎么操作",
                "$gameName 新手教程 $objective"
            )
            
            // 3. 搜索网页
            val searchResults = mutableListOf<SearchResult>()
            for (query in queries) {
                val results = searchWeb(query)
                searchResults.addAll(results)
                if (searchResults.size >= 5) break
            }
            
            if (searchResults.isEmpty()) {
                LogManager.w(TAG, "⚠️ 未找到相关教程")
                return@withContext null
            }
            
            LogManager.d(TAG, "📄 找到 ${searchResults.size} 条搜索结果")
            
            // 4. 获取网页内容
            val pageContents = mutableListOf<String>()
            val rawContents = mutableListOf<Pair<SearchResult, String>>()  // 保存原始内容用于训练
            
            for (result in searchResults.take(3)) {
                val content = fetchPageContent(result.url)
                if (content.isNotEmpty()) {
                    pageContents.add("来源: ${result.title}\n$content")
                    rawContents.add(result to content)
                }
            }
            
            if (pageContents.isEmpty()) {
                // 如果无法获取网页内容，使用搜索摘要
                pageContents.addAll(searchResults.map { "${it.title}: ${it.snippet}" })
            }
            
            // 保存原始内容用于训练
            if (saveForTraining && rawContents.isNotEmpty()) {
                saveRawDataForTraining(gameName, objective, rawContents)
            }
            
            // 5. 使用LLM整理教程
            val tutorial = analyzeTutorial(gameName, objective, pageContents.joinToString("\n\n---\n\n"))
            
            // 6. 保存到缓存
            if (tutorial != null) {
                tutorialCache[cacheKey] = tutorial
                saveCache()
                LogManager.d(TAG, "✅ 教程学习完成并缓存: ${tutorial.steps.size} 个步骤")
            }
            
            tutorial
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 学习教程失败: ${e.message}", e)
            null
        }
    }
    
    /**
     * 搜索网页
     */
    private suspend fun searchWeb(query: String): List<SearchResult> = withContext(Dispatchers.IO) {
        val results = mutableListOf<SearchResult>()
        
        try {
            // 使用多个搜索源
            val encodedQuery = URLEncoder.encode(query, "UTF-8")
            
            // 方案1: 使用Bing搜索
            val bingResults = searchBing(encodedQuery)
            results.addAll(bingResults)
            
            // 方案2: 使用百度搜索（备用）
            if (results.isEmpty()) {
                val baiduResults = searchBaidu(encodedQuery)
                results.addAll(baiduResults)
            }
            
        } catch (e: Exception) {
            LogManager.e(TAG, "搜索失败: ${e.message}")
        }
        
        results
    }
    
    /**
     * Bing搜索
     */
    private fun searchBing(query: String): List<SearchResult> {
        val results = mutableListOf<SearchResult>()
        
        try {
            val url = URL("https://www.bing.com/search?q=$query&setlang=zh-CN")
            val connection = url.openConnection() as HttpURLConnection
            connection.apply {
                requestMethod = "GET"
                setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9")
                connectTimeout = 10000
                readTimeout = 10000
            }
            
            val html = connection.inputStream.bufferedReader().readText()
            
            // 简单解析搜索结果
            val pattern = """<li class="b_algo"[^>]*>.*?<h2><a href="([^"]+)"[^>]*>([^<]+)</a></h2>.*?<p[^>]*>([^<]+)</p>""".toRegex(RegexOption.DOT_MATCHES_ALL)
            
            pattern.findAll(html).take(5).forEach { match ->
                val (resultUrl, title, snippet) = match.destructured
                results.add(SearchResult(
                    title = title.trim(),
                    snippet = snippet.trim(),
                    url = resultUrl
                ))
            }
            
        } catch (e: Exception) {
            LogManager.e(TAG, "Bing搜索失败: ${e.message}")
        }
        
        return results
    }
    
    /**
     * 百度搜索
     */
    private fun searchBaidu(query: String): List<SearchResult> {
        val results = mutableListOf<SearchResult>()
        
        try {
            val url = URL("https://www.baidu.com/s?wd=$query")
            val connection = url.openConnection() as HttpURLConnection
            connection.apply {
                requestMethod = "GET"
                setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                connectTimeout = 10000
                readTimeout = 10000
            }
            
            val html = connection.inputStream.bufferedReader().readText()
            
            // 简单解析百度搜索结果
            val titlePattern = """<h3 class="[^"]*t[^"]*"[^>]*>.*?<a[^>]*href="([^"]+)"[^>]*>(.+?)</a>""".toRegex(RegexOption.DOT_MATCHES_ALL)
            val snippetPattern = """<div class="c-abstract[^"]*"[^>]*>(.+?)</div>""".toRegex(RegexOption.DOT_MATCHES_ALL)
            
            val titles = titlePattern.findAll(html).toList()
            val snippets = snippetPattern.findAll(html).toList()
            
            for (i in 0 until minOf(titles.size, snippets.size, 5)) {
                val (resultUrl, title) = titles[i].destructured
                val snippet = snippets[i].groupValues[1]
                    .replace(Regex("<[^>]+>"), "")
                    .trim()
                
                results.add(SearchResult(
                    title = title.replace(Regex("<[^>]+>"), "").trim(),
                    snippet = snippet,
                    url = resultUrl
                ))
            }
            
        } catch (e: Exception) {
            LogManager.e(TAG, "百度搜索失败: ${e.message}")
        }
        
        return results
    }
    
    /**
     * 获取网页内容
     */
    private fun fetchPageContent(pageUrl: String): String {
        return try {
            val url = URL(pageUrl)
            val connection = url.openConnection() as HttpURLConnection
            connection.apply {
                requestMethod = "GET"
                setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                connectTimeout = 10000
                readTimeout = 10000
                instanceFollowRedirects = true
            }
            
            val html = connection.inputStream.bufferedReader().readText()
            
            // 提取正文内容（移除HTML标签）
            val text = html
                .replace(Regex("<script[^>]*>.*?</script>", RegexOption.DOT_MATCHES_ALL), "")
                .replace(Regex("<style[^>]*>.*?</style>", RegexOption.DOT_MATCHES_ALL), "")
                .replace(Regex("<[^>]+>"), " ")
                .replace(Regex("\\s+"), " ")
                .trim()
            
            // 限制长度
            if (text.length > 3000) text.take(3000) else text
            
        } catch (e: Exception) {
            LogManager.e(TAG, "获取网页内容失败: ${e.message}")
            ""
        }
    }
    
    /**
     * 使用LLM分析教程
     */
    private suspend fun analyzeTutorial(
        gameName: String,
        objective: String,
        rawContent: String
    ): TutorialInfo? {
        val prompt = """
            你是一个游戏教程分析助手。请从以下网页内容中提取关于"$gameName"游戏"$objective"的操作教程。

            网页内容：
            $rawContent

            请以JSON格式输出教程信息，格式如下：
            {
                "steps": [
                    {"order": 1, "action": "操作描述", "targetText": "按钮文字", "targetPosition": "位置描述", "waitAfter": 500},
                    ...
                ],
                "tips": ["提示1", "提示2"],
                "buttonKeywords": ["按钮1", "按钮2", ...]
            }

            要求：
            1. steps: 提取具体的操作步骤，按顺序排列
            2. targetText: 需要点击的按钮或文字（如"开始"、"确定"等）
            3. targetPosition: 按钮位置描述（如"屏幕右上角"、"底部中间"等）
            4. tips: 有用的操作提示
            5. buttonKeywords: 游戏中常见的需要点击的按钮关键词
            6. 只输出JSON，不要其他内容
        """.trimIndent()
        
        return try {
            val llmClient = LLMClient(AutomationEngine.baseUrl, AutomationEngine.apiKey, AutomationEngine.modelName)
            val response = llmClient.chatCompletion(prompt, usePersonality = false)
            
            // 解析JSON响应
            val jsonStr = response
                .replace(Regex("```json\\s*"), "")
                .replace(Regex("```\\s*"), "")
                .trim()
            
            val parsed = json.decodeFromString<TutorialParseResult>(jsonStr)
            
            TutorialInfo(
                gameName = gameName,
                objective = objective,
                steps = parsed.steps,
                tips = parsed.tips,
                buttonKeywords = parsed.buttonKeywords
            )
            
        } catch (e: Exception) {
            LogManager.e(TAG, "解析教程失败: ${e.message}")
            null
        }
    }
    
    @Serializable
    private data class TutorialParseResult(
        val steps: List<GameStep> = emptyList(),
        val tips: List<String> = emptyList(),
        val buttonKeywords: List<String> = emptyList()
    )
    
    // ==================== 应用教程 ====================
    
    /**
     * 根据教程获取下一步操作建议
     */
    fun getNextAction(
        tutorial: TutorialInfo,
        currentStep: Int,
        screenText: String
    ): GameStep? {
        if (currentStep >= tutorial.steps.size) {
            return null
        }
        
        val step = tutorial.steps[currentStep]
        
        // 检查目标按钮是否在屏幕上
        val targetVisible = step.targetText?.let { target ->
            screenText.contains(target, ignoreCase = true)
        } ?: true
        
        return if (targetVisible) step else null
    }
    
    /**
     * 从教程中查找匹配的按钮
     */
    fun findMatchingButton(
        tutorial: TutorialInfo,
        screenText: String
    ): String? {
        for (keyword in tutorial.buttonKeywords) {
            if (screenText.contains(keyword, ignoreCase = true)) {
                return keyword
            }
        }
        return null
    }
    
    // ==================== 缓存管理 ====================
    
    private fun loadCache() {
        try {
            val file = File(context.filesDir, CACHE_FILE)
            if (file.exists()) {
                val content = file.readText()
                val cached = json.decodeFromString<Map<String, TutorialInfo>>(content)
                tutorialCache.putAll(cached)
                LogManager.d(TAG, "📂 加载缓存: ${tutorialCache.size} 条教程")
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "加载缓存失败: ${e.message}")
        }
    }
    
    private fun saveCache() {
        try {
            // 清理过期缓存
            val now = System.currentTimeMillis()
            val expireTime = CACHE_EXPIRE_DAYS * 24 * 60 * 60 * 1000L
            tutorialCache.entries.removeIf { now - it.value.timestamp > expireTime }
            
            // 限制缓存大小
            if (tutorialCache.size > MAX_CACHE_SIZE) {
                val sortedEntries = tutorialCache.entries.sortedBy { it.value.timestamp }
                val toRemove = sortedEntries.take(tutorialCache.size - MAX_CACHE_SIZE)
                toRemove.forEach { tutorialCache.remove(it.key) }
            }
            
            val file = File(context.filesDir, CACHE_FILE)
            file.writeText(json.encodeToString(tutorialCache))
            LogManager.d(TAG, "💾 保存缓存: ${tutorialCache.size} 条教程")
            
        } catch (e: Exception) {
            LogManager.e(TAG, "保存缓存失败: ${e.message}")
        }
    }
    
    private fun isCacheExpired(tutorial: TutorialInfo): Boolean {
        val expireTime = CACHE_EXPIRE_DAYS * 24 * 60 * 60 * 1000L
        return System.currentTimeMillis() - tutorial.timestamp > expireTime
    }
    
    /**
     * 清除缓存
     */
    fun clearCache() {
        tutorialCache.clear()
        try {
            File(context.filesDir, CACHE_FILE).delete()
        } catch (e: Exception) {
            LogManager.e(TAG, "清除缓存失败: ${e.message}")
        }
    }
    
    // ==================== 训练数据保存 ====================
    
    /**
     * 保存原始数据用于模型训练
     */
    private suspend fun saveRawDataForTraining(
        gameName: String,
        objective: String,
        rawContents: List<Pair<SearchResult, String>>
    ) {
        try {
            for ((result, content) in rawContents) {
                // 清洗内容
                val cleanedContent = trainingDataManager.cleanTextContent(
                    rawText = content,
                    source = result.url,
                    title = "$gameName - $objective: ${result.title}",
                    category = "游戏教程"
                )
                
                // 保存为多种格式
                trainingDataManager.saveCleanedData(
                    content = cleanedContent,
                    format = TrainingDataManager.DataFormat.JSONL
                )
                
                // 同时保存为对话格式（用于Chat模型微调）
                trainingDataManager.saveCleanedData(
                    content = cleanedContent,
                    format = TrainingDataManager.DataFormat.CONVERSATION
                )
                
                LogManager.d(TAG, "💾 训练数据已保存: ${result.title}")
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "保存训练数据失败: ${e.message}", e)
        }
    }
    
    /**
     * 导出所有训练数据
     */
    suspend fun exportTrainingData(
        format: TrainingDataManager.DataFormat = TrainingDataManager.DataFormat.JSONL,
        outputPath: String? = null
    ): java.io.File? {
        return trainingDataManager.exportTrainingData(format, outputPath)
    }
    
    /**
     * 📊 获取训练数据统计
     */
    fun getTrainingDataStats(): TrainingDataManager.DataStats {
        return trainingDataManager.getStats()
    }
}
