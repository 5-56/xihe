package com.example.xihe.scenarios

import android.graphics.Rect
import com.example.xihe.utils.LogManager
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.regex.Pattern

/**
 * 🛒 购物智能处理模块
 * 
 * 功能：
 * - 📦 商品信息提取
 * - 💰 商品价格识别
 * - ⭐ 商品评价分析
 * - 🔄 商品对比
 * - 🛒 购物车管理
 * - 📋 订单处理
 * - 💳 支付流程
 * - 🚚 物流跟踪
 */
object ShoppingIntelligence {
    
    private const val TAG = "ShoppingIntelligence"
    
    // 购物车缓存
    private val cartItems = mutableListOf<CartItem>()
    
    // 商品对比列表
    private val compareList = mutableListOf<ProductInfo>()
    
    // 订单跟踪
    private val _orderStatus = MutableStateFlow<OrderStatus?>(null)
    val orderStatus = _orderStatus.asStateFlow()
    
    // 物流信息
    private val _logisticsInfo = MutableStateFlow<LogisticsInfo?>(null)
    val logisticsInfo = _logisticsInfo.asStateFlow()
    
    // ==================== 📦 商品信息提取 ====================
    
    /**
     * 📦 提取商品信息
     */
    fun extractProductInfo(rootNode: AccessibilityNodeInfo?): ProductInfo? {
        if (rootNode == null) return null
        
        LogManager.d(TAG, "📦 开始提取商品信息")
        
        val allText = mutableListOf<String>()
        val prices = mutableListOf<PriceInfo>()
        var title: String? = null
        var shopName: String? = null
        var rating: Float? = null
        var salesCount: Int? = null
        val specifications = mutableMapOf<String, String>()
        val images = mutableListOf<String>()
        
        traverseNodes(rootNode) { node ->
            val text = node.text?.toString() ?: ""
            val desc = node.contentDescription?.toString() ?: ""
            val className = node.className?.toString() ?: ""
            
            if (text.isNotEmpty()) {
                allText.add(text)
                
                // 提取价格
                extractPrice(text)?.let { prices.add(it) }
                
                // 提取标题（通常是较长的文本，在页面上方）
                if (title == null && text.length in 10..200 && isLikelyTitle(text)) {
                    title = text
                }
                
                // 提取店铺名
                if (text.contains("旗舰店") || text.contains("专卖店") || text.contains("官方")) {
                    shopName = text
                }
                
                // 提取评分
                extractRating(text)?.let { rating = it }
                
                // 提取销量
                extractSalesCount(text)?.let { salesCount = it }
                
                // 提取规格参数
                extractSpecification(text)?.let { (key, value) ->
                    specifications[key] = value
                }
            }
            
            // 提取图片描述
            if (className.contains("Image") && desc.isNotEmpty()) {
                images.add(desc)
            }
        }
        
        // 确定主价格（通常是最大的或第一个价格）
        val mainPrice = prices.maxByOrNull { it.value }
        val originalPrice = if (prices.size > 1) {
            prices.filter { it != mainPrice }.maxByOrNull { it.value }
        } else null
        
        if (title == null && mainPrice == null) {
            LogManager.w(TAG, "⚠️ 未能提取到有效商品信息")
            return null
        }
        
        return ProductInfo(
            title = title ?: "未知商品",
            currentPrice = mainPrice,
            originalPrice = originalPrice,
            shopName = shopName,
            rating = rating,
            salesCount = salesCount,
            specifications = specifications,
            imageDescriptions = images,
            extractedAt = System.currentTimeMillis()
        ).also {
            LogManager.d(TAG, "📦 提取完成: ${it.title}, 价格: ${it.currentPrice?.formatted}")
        }
    }
    
    /**
     * 💰 提取价格
     */
    private fun extractPrice(text: String): PriceInfo? {
        // 匹配各种价格格式
        val patterns = listOf(
            // ¥99.00 或 ￥99.00
            Pattern.compile("""[¥￥]\s*(\d+(?:\.\d{1,2})?)"""),
            // 99.00元
            Pattern.compile("""(\d+(?:\.\d{1,2})?)\s*元"""),
            // 价格：99.00
            Pattern.compile("""(?:价格|售价|现价|到手价)[：:]\s*(\d+(?:\.\d{1,2})?)"""),
            // $99.00
            Pattern.compile("""\$\s*(\d+(?:\.\d{1,2})?)""")
        )
        
        for (pattern in patterns) {
            val matcher = pattern.matcher(text)
            if (matcher.find()) {
                val priceStr = matcher.group(1) ?: continue
                val value = priceStr.toDoubleOrNull() ?: continue
                
                if (value > 0 && value < 1000000) { // 合理价格范围
                    val priceType = when {
                        text.contains("原价") || text.contains("划线") -> PriceType.ORIGINAL
                        text.contains("到手") || text.contains("券后") -> PriceType.FINAL
                        text.contains("会员") || text.contains("VIP") -> PriceType.MEMBER
                        else -> PriceType.CURRENT
                    }
                    
                    return PriceInfo(
                        value = value,
                        currency = "CNY",
                        formatted = "¥$priceStr",
                        priceType = priceType
                    )
                }
            }
        }
        
        return null
    }
    
    /**
     * ⭐ 提取评分
     */
    private fun extractRating(text: String): Float? {
        // 匹配评分格式：4.9分、4.9星、评分4.9
        val patterns = listOf(
            Pattern.compile("""(\d+(?:\.\d)?)\s*[分星]"""),
            Pattern.compile("""评分[：:]?\s*(\d+(?:\.\d)?)"""),
            Pattern.compile("""(\d+(?:\.\d)?)\s*(?:好评|评价)""")
        )
        
        for (pattern in patterns) {
            val matcher = pattern.matcher(text)
            if (matcher.find()) {
                val rating = matcher.group(1)?.toFloatOrNull()
                if (rating != null && rating in 0f..5f) {
                    return rating
                }
            }
        }
        
        return null
    }
    
    /**
     * 📊 提取销量
     */
    private fun extractSalesCount(text: String): Int? {
        // 匹配销量格式：月销1000+、已售1万+、销量10000
        val patterns = listOf(
            Pattern.compile("""(?:月销|已售|销量|付款)[：:]?\s*(\d+(?:\.\d)?)\s*[万+]?"""),
            Pattern.compile("""(\d+(?:\.\d)?)\s*[万]?\s*人(?:付款|购买|已买)""")
        )
        
        for (pattern in patterns) {
            val matcher = pattern.matcher(text)
            if (matcher.find()) {
                val numStr = matcher.group(1) ?: continue
                var count = numStr.toDoubleOrNull() ?: continue
                
                // 处理"万"单位
                if (text.contains("万")) {
                    count *= 10000
                }
                
                return count.toInt()
            }
        }
        
        return null
    }
    
    /**
     * 📋 提取规格参数
     */
    private fun extractSpecification(text: String): Pair<String, String>? {
        // 匹配规格格式：颜色：红色、尺寸：XL
        val pattern = Pattern.compile("""(颜色|尺寸|型号|规格|容量|材质|品牌)[：:]\s*(.+)""")
        val matcher = pattern.matcher(text)
        
        if (matcher.find()) {
            val key = matcher.group(1)
            val value = matcher.group(2)?.take(20) // 限制长度
            if (key != null && value != null) {
                return key to value
            }
        }
        
        return null
    }
    
    private fun isLikelyTitle(text: String): Boolean {
        return text.length >= 10 &&
               !text.startsWith("¥") &&
               !text.startsWith("￥") &&
               !text.matches(Regex("""^\d+.*""")) &&
               !text.contains("购物车") &&
               !text.contains("立即购买")
    }
    
    // ==================== ⭐ 商品评价分析 ====================
    
    /**
     * ⭐ 分析商品评价
     */
    fun analyzeProductReviews(rootNode: AccessibilityNodeInfo?): ReviewAnalysis {
        if (rootNode == null) return ReviewAnalysis.empty()
        
        LogManager.d(TAG, "⭐ 分析商品评价")
        
        val reviews = mutableListOf<ReviewItem>()
        var totalRating = 0f
        var positiveCount = 0
        var negativeCount = 0
        var neutralCount = 0
        val keywords = mutableMapOf<String, Int>()
        
        traverseNodes(rootNode) { node ->
            val text = node.text?.toString() ?: ""
            
            // 识别评价内容
            if (isLikelyReview(text)) {
                val sentiment = analyzeReviewSentiment(text)
                val rating = extractReviewRating(text)
                
                reviews.add(ReviewItem(
                    content = text.take(200),
                    sentiment = sentiment,
                    rating = rating
                ))
                
                when (sentiment) {
                    ReviewSentiment.POSITIVE -> positiveCount++
                    ReviewSentiment.NEGATIVE -> negativeCount++
                    ReviewSentiment.NEUTRAL -> neutralCount++
                }
                
                if (rating != null) {
                    totalRating += rating
                }
                
                // 提取关键词
                extractReviewKeywords(text).forEach { keyword ->
                    keywords[keyword] = (keywords[keyword] ?: 0) + 1
                }
            }
        }
        
        val avgRating = if (reviews.isNotEmpty()) totalRating / reviews.size else 0f
        
        return ReviewAnalysis(
            totalReviews = reviews.size,
            averageRating = avgRating,
            positiveCount = positiveCount,
            negativeCount = negativeCount,
            neutralCount = neutralCount,
            positiveRate = if (reviews.isNotEmpty()) positiveCount.toFloat() / reviews.size else 0f,
            topKeywords = keywords.entries.sortedByDescending { it.value }.take(10).map { it.key },
            recentReviews = reviews.take(10)
        )
    }
    
    private fun isLikelyReview(text: String): Boolean {
        return text.length in 10..500 &&
               (text.contains("买") || text.contains("收到") || text.contains("质量") ||
                text.contains("不错") || text.contains("好评") || text.contains("差评") ||
                text.contains("推荐") || text.contains("满意") || text.contains("物流"))
    }
    
    private fun analyzeReviewSentiment(text: String): ReviewSentiment {
        val positiveWords = listOf("好", "棒", "赞", "满意", "喜欢", "推荐", "不错", "超值", "划算", "快", "正品")
        val negativeWords = listOf("差", "烂", "坑", "假", "慢", "破", "退", "骗", "失望", "后悔", "垃圾")
        
        var positiveScore = 0
        var negativeScore = 0
        
        positiveWords.forEach { if (text.contains(it)) positiveScore++ }
        negativeWords.forEach { if (text.contains(it)) negativeScore++ }
        
        return when {
            positiveScore > negativeScore + 1 -> ReviewSentiment.POSITIVE
            negativeScore > positiveScore + 1 -> ReviewSentiment.NEGATIVE
            else -> ReviewSentiment.NEUTRAL
        }
    }
    
    private fun extractReviewRating(text: String): Float? {
        val pattern = Pattern.compile("""(\d)\s*[星分]""")
        val matcher = pattern.matcher(text)
        if (matcher.find()) {
            return matcher.group(1)?.toFloatOrNull()
        }
        return null
    }
    
    private fun extractReviewKeywords(text: String): List<String> {
        val keywords = mutableListOf<String>()
        val keywordPatterns = listOf(
            "质量", "包装", "物流", "客服", "价格", "颜色", "尺寸",
            "正品", "划算", "推荐", "满意", "好评"
        )
        
        keywordPatterns.forEach { keyword ->
            if (text.contains(keyword)) {
                keywords.add(keyword)
            }
        }
        
        return keywords
    }
    
    // ==================== 🔄 商品对比 ====================
    
    /**
     * 🔄 添加商品到对比列表
     */
    fun addToCompare(product: ProductInfo): Boolean {
        if (compareList.size >= 4) {
            LogManager.w(TAG, "⚠️ 对比列表已满（最多4个）")
            return false
        }
        
        if (compareList.any { it.title == product.title }) {
            LogManager.w(TAG, "⚠️ 商品已在对比列表中")
            return false
        }
        
        compareList.add(product)
        LogManager.d(TAG, "✅ 添加到对比: ${product.title}")
        return true
    }
    
    /**
     * 🔄 获取商品对比结果
     */
    fun compareProducts(): ProductComparison? {
        if (compareList.size < 2) {
            LogManager.w(TAG, "⚠️ 至少需要2个商品进行对比")
            return null
        }
        
        LogManager.d(TAG, "🔄 对比 ${compareList.size} 个商品")
        
        val priceComparison = compareList.mapNotNull { it.currentPrice?.value }
        val lowestPrice = priceComparison.minOrNull()
        val highestPrice = priceComparison.maxOrNull()
        
        val bestValue = compareList.maxByOrNull { product ->
            val priceScore = product.currentPrice?.value?.let { 100 - it / 10 } ?: 0.0
            val ratingScore = (product.rating ?: 0f) * 20
            priceScore + ratingScore
        }
        
        val comparisonItems = compareList.map { product ->
            ComparisonItem(
                product = product,
                priceRank = compareList.sortedBy { it.currentPrice?.value }.indexOf(product) + 1,
                ratingRank = compareList.sortedByDescending { it.rating ?: 0f }.indexOf(product) + 1,
                isLowestPrice = product.currentPrice?.value == lowestPrice,
                isHighestRated = product.rating == compareList.maxOfOrNull { it.rating ?: 0f }
            )
        }
        
        return ProductComparison(
            items = comparisonItems,
            lowestPriceProduct = compareList.minByOrNull { it.currentPrice?.value ?: Double.MAX_VALUE },
            highestRatedProduct = compareList.maxByOrNull { it.rating ?: 0f },
            bestValueProduct = bestValue,
            priceDifference = if (lowestPrice != null && highestPrice != null) highestPrice - lowestPrice else null
        )
    }
    
    /**
     * 🗑️ 清空对比列表
     */
    fun clearCompareList() {
        compareList.clear()
        LogManager.d(TAG, "🗑️ 对比列表已清空")
    }
    
    // ==================== 🛒 购物车管理 ====================
    
    /**
     * 🛒 添加商品到购物车
     */
    fun addToCart(product: ProductInfo, quantity: Int = 1, specification: String? = null): CartItem {
        val existingItem = cartItems.find { 
            it.product.title == product.title && it.specification == specification 
        }
        
        if (existingItem != null) {
            val index = cartItems.indexOf(existingItem)
            cartItems[index] = existingItem.copy(quantity = existingItem.quantity + quantity)
            LogManager.d(TAG, "🛒 更新购物车: ${product.title}, 数量: ${existingItem.quantity + quantity}")
            return cartItems[index]
        }
        
        val newItem = CartItem(
            id = "cart_${System.currentTimeMillis()}",
            product = product,
            quantity = quantity,
            specification = specification,
            isSelected = true,
            addedAt = System.currentTimeMillis()
        )
        
        cartItems.add(newItem)
        LogManager.d(TAG, "🛒 添加到购物车: ${product.title}")
        return newItem
    }
    
    /**
     * 🛒 获取购物车信息
     */
    fun getCartInfo(): CartInfo {
        val selectedItems = cartItems.filter { it.isSelected }
        val totalPrice = selectedItems.sumOf { 
            (it.product.currentPrice?.value ?: 0.0) * it.quantity 
        }
        val totalQuantity = selectedItems.sumOf { it.quantity }
        
        return CartInfo(
            items = cartItems.toList(),
            selectedItems = selectedItems,
            totalPrice = totalPrice,
            totalQuantity = totalQuantity,
            itemCount = cartItems.size
        )
    }
    
    /**
     * 🛒 更新购物车商品
     */
    fun updateCartItem(itemId: String, quantity: Int? = null, isSelected: Boolean? = null) {
        val index = cartItems.indexOfFirst { it.id == itemId }
        if (index >= 0) {
            val item = cartItems[index]
            cartItems[index] = item.copy(
                quantity = quantity ?: item.quantity,
                isSelected = isSelected ?: item.isSelected
            )
        }
    }
    
    /**
     * 🗑️ 从购物车移除
     */
    fun removeFromCart(itemId: String) {
        cartItems.removeAll { it.id == itemId }
        LogManager.d(TAG, "🗑️ 从购物车移除: $itemId")
    }
    
    // ==================== 📋 订单处理 ====================
    
    /**
     * 📋 创建订单
     */
    fun createOrder(items: List<CartItem>, shippingAddress: ShippingAddress): Order {
        val totalPrice = items.sumOf { (it.product.currentPrice?.value ?: 0.0) * it.quantity }
        
        val order = Order(
            orderId = "ORD${System.currentTimeMillis()}",
            items = items,
            totalPrice = totalPrice,
            shippingAddress = shippingAddress,
            status = OrderState.PENDING_PAYMENT,
            createdAt = System.currentTimeMillis()
        )
        
        LogManager.d(TAG, "📋 创建订单: ${order.orderId}, 总价: ¥$totalPrice")
        return order
    }
    
    /**
     * 📋 更新订单状态
     */
    fun updateOrderStatus(orderId: String, newStatus: OrderState) {
        _orderStatus.value = OrderStatus(
            orderId = orderId,
            status = newStatus,
            updateTime = System.currentTimeMillis()
        )
        LogManager.d(TAG, "📋 订单状态更新: $orderId -> $newStatus")
    }
    
    // ==================== 💳 支付流程 ====================
    
    /**
     * 💳 获取支付流程步骤
     */
    fun getPaymentSteps(): List<PaymentStep> {
        return listOf(
            PaymentStep(1, "确认订单", "核对商品信息和收货地址", PaymentStepStatus.PENDING),
            PaymentStep(2, "选择支付方式", "选择支付宝/微信/银行卡", PaymentStepStatus.PENDING),
            PaymentStep(3, "输入支付密码", "验证支付密码或指纹", PaymentStepStatus.PENDING),
            PaymentStep(4, "支付完成", "等待支付结果确认", PaymentStepStatus.PENDING)
        )
    }
    
    /**
     * 💳 检测当前支付步骤
     */
    fun detectPaymentStep(rootNode: AccessibilityNodeInfo?): PaymentStep? {
        if (rootNode == null) return null
        
        val pageText = StringBuilder()
        traverseNodes(rootNode) { node ->
            pageText.append(node.text?.toString() ?: "")
            pageText.append(" ")
        }
        
        val text = pageText.toString()
        
        return when {
            text.contains("确认订单") || text.contains("提交订单") -> 
                PaymentStep(1, "确认订单", "核对商品信息", PaymentStepStatus.CURRENT)
            text.contains("支付方式") || text.contains("选择支付") -> 
                PaymentStep(2, "选择支付方式", "选择支付方式", PaymentStepStatus.CURRENT)
            text.contains("支付密码") || text.contains("验证") -> 
                PaymentStep(3, "输入支付密码", "验证支付", PaymentStepStatus.CURRENT)
            text.contains("支付成功") || text.contains("支付完成") -> 
                PaymentStep(4, "支付完成", "支付成功", PaymentStepStatus.COMPLETED)
            else -> null
        }
    }
    
    // ==================== 🚚 物流跟踪 ====================
    
    /**
     * 🚚 提取物流信息
     */
    fun extractLogisticsInfo(rootNode: AccessibilityNodeInfo?): LogisticsInfo? {
        if (rootNode == null) return null
        
        LogManager.d(TAG, "🚚 提取物流信息")
        
        var trackingNumber: String? = null
        var carrier: String? = null
        var currentStatus: String? = null
        val trackingHistory = mutableListOf<TrackingEvent>()
        
        traverseNodes(rootNode) { node ->
            val text = node.text?.toString() ?: ""
            
            // 提取快递单号
            if (trackingNumber == null) {
                extractTrackingNumber(text)?.let { trackingNumber = it }
            }
            
            // 提取快递公司
            if (carrier == null) {
                extractCarrier(text)?.let { carrier = it }
            }
            
            // 提取物流状态
            if (isTrackingEvent(text)) {
                trackingHistory.add(TrackingEvent(
                    time = extractEventTime(text),
                    description = text.take(100),
                    location = extractLocation(text)
                ))
            }
            
            // 当前状态
            if (text.contains("已签收") || text.contains("派送中") || 
                text.contains("运输中") || text.contains("已发货")) {
                currentStatus = text.take(50)
            }
        }
        
        if (trackingNumber == null && trackingHistory.isEmpty()) {
            return null
        }
        
        val status = when {
            currentStatus?.contains("已签收") == true -> LogisticsStatus.DELIVERED
            currentStatus?.contains("派送中") == true -> LogisticsStatus.DELIVERING
            currentStatus?.contains("运输中") == true -> LogisticsStatus.IN_TRANSIT
            currentStatus?.contains("已发货") == true -> LogisticsStatus.SHIPPED
            else -> LogisticsStatus.UNKNOWN
        }
        
        return LogisticsInfo(
            trackingNumber = trackingNumber,
            carrier = carrier,
            status = status,
            currentStatus = currentStatus,
            trackingHistory = trackingHistory.sortedByDescending { it.time },
            estimatedDelivery = null
        ).also {
            _logisticsInfo.value = it
        }
    }
    
    private fun extractTrackingNumber(text: String): String? {
        // 匹配快递单号格式
        val patterns = listOf(
            Pattern.compile("""(?:单号|运单)[：:]?\s*([A-Za-z0-9]{10,20})"""),
            Pattern.compile("""([A-Z]{2}\d{9}[A-Z]{2})"""), // 国际单号
            Pattern.compile("""(\d{12,15})""") // 国内单号
        )
        
        for (pattern in patterns) {
            val matcher = pattern.matcher(text)
            if (matcher.find()) {
                return matcher.group(1)
            }
        }
        
        return null
    }
    
    private fun extractCarrier(text: String): String? {
        val carriers = listOf(
            "顺丰", "圆通", "中通", "韵达", "申通", "百世", "极兔", "邮政", "EMS", "京东"
        )
        return carriers.find { text.contains(it) }
    }
    
    private fun isTrackingEvent(text: String): Boolean {
        return text.matches(Regex(""".*\d{1,2}[月/-]\d{1,2}.*""")) &&
               (text.contains("已") || text.contains("正在") || text.contains("到达"))
    }
    
    private fun extractEventTime(text: String): String? {
        val pattern = Pattern.compile("""(\d{1,2}[月/-]\d{1,2}\s*\d{1,2}:\d{2})""")
        val matcher = pattern.matcher(text)
        return if (matcher.find()) matcher.group(1) else null
    }
    
    private fun extractLocation(text: String): String? {
        val pattern = Pattern.compile("""(?:在|到达|离开)\s*[【\[]?([^】\]]+)[】\]]?""")
        val matcher = pattern.matcher(text)
        return if (matcher.find()) matcher.group(1)?.take(20) else null
    }
    
    // ==================== 🔧 辅助方法 ====================
    
    private fun traverseNodes(node: AccessibilityNodeInfo, action: (AccessibilityNodeInfo) -> Unit) {
        action(node)
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { traverseNodes(it, action) }
        }
    }
}

// ==================== 📦 数据类定义 ====================

// 商品信息
data class ProductInfo(
    val title: String,
    val currentPrice: PriceInfo?,
    val originalPrice: PriceInfo? = null,
    val shopName: String? = null,
    val rating: Float? = null,
    val salesCount: Int? = null,
    val specifications: Map<String, String> = emptyMap(),
    val imageDescriptions: List<String> = emptyList(),
    val extractedAt: Long = 0
)

// 价格信息
data class PriceInfo(
    val value: Double,
    val currency: String = "CNY",
    val formatted: String,
    val priceType: PriceType = PriceType.CURRENT
)

enum class PriceType { CURRENT, ORIGINAL, FINAL, MEMBER }

// 评价分析
data class ReviewAnalysis(
    val totalReviews: Int,
    val averageRating: Float,
    val positiveCount: Int,
    val negativeCount: Int,
    val neutralCount: Int,
    val positiveRate: Float,
    val topKeywords: List<String>,
    val recentReviews: List<ReviewItem>
) {
    companion object {
        fun empty() = ReviewAnalysis(0, 0f, 0, 0, 0, 0f, emptyList(), emptyList())
    }
}

data class ReviewItem(
    val content: String,
    val sentiment: ReviewSentiment,
    val rating: Float? = null
)

enum class ReviewSentiment { POSITIVE, NEGATIVE, NEUTRAL }

// 商品对比
data class ProductComparison(
    val items: List<ComparisonItem>,
    val lowestPriceProduct: ProductInfo?,
    val highestRatedProduct: ProductInfo?,
    val bestValueProduct: ProductInfo?,
    val priceDifference: Double?
)

data class ComparisonItem(
    val product: ProductInfo,
    val priceRank: Int,
    val ratingRank: Int,
    val isLowestPrice: Boolean,
    val isHighestRated: Boolean
)

// 购物车
data class CartItem(
    val id: String,
    val product: ProductInfo,
    val quantity: Int,
    val specification: String? = null,
    val isSelected: Boolean = true,
    val addedAt: Long = 0
)

data class CartInfo(
    val items: List<CartItem>,
    val selectedItems: List<CartItem>,
    val totalPrice: Double,
    val totalQuantity: Int,
    val itemCount: Int
)

// 订单
data class Order(
    val orderId: String,
    val items: List<CartItem>,
    val totalPrice: Double,
    val shippingAddress: ShippingAddress,
    val status: OrderState,
    val createdAt: Long
)

data class ShippingAddress(
    val name: String,
    val phone: String,
    val address: String,
    val isDefault: Boolean = false
)

enum class OrderState {
    PENDING_PAYMENT, PAID, SHIPPED, DELIVERED, COMPLETED, CANCELLED, REFUNDING
}

data class OrderStatus(
    val orderId: String,
    val status: OrderState,
    val updateTime: Long
)

// 支付
data class PaymentStep(
    val step: Int,
    val name: String,
    val description: String,
    val status: PaymentStepStatus
)

enum class PaymentStepStatus { PENDING, CURRENT, COMPLETED, FAILED }

// 物流
data class LogisticsInfo(
    val trackingNumber: String?,
    val carrier: String?,
    val status: LogisticsStatus,
    val currentStatus: String?,
    val trackingHistory: List<TrackingEvent>,
    val estimatedDelivery: String?
)

enum class LogisticsStatus { SHIPPED, IN_TRANSIT, DELIVERING, DELIVERED, EXCEPTION, UNKNOWN }

data class TrackingEvent(
    val time: String?,
    val description: String,
    val location: String?
)
