package com.example.xihe.scenarios

import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.scenarios.BrowserScenario
import com.example.xihe.scenarios.VideoScenario
import com.example.xihe.scenarios.games.GomokuScenario
import com.example.xihe.scenarios.games.DouDiZhuScenario
import com.example.xihe.scenarios.games.GameAIScenario
import com.example.xihe.tools.ToolRegistry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.util.Date

/**
 * 🎯 场景管理器
 * 统一管理和执行各种自动化场景
 */
class ScenarioManager private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "ScenarioManager"
        
        @Volatile
        private var instance: ScenarioManager? = null
        
        fun getInstance(context: Context): ScenarioManager {
            return instance ?: synchronized(this) {
                instance ?: ScenarioManager(context.applicationContext).also { instance = it }
            }
        }
    }
    
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    
    private val _executionState = MutableStateFlow<ExecutionState>(ExecutionState.Idle)
    val executionState: StateFlow<ExecutionState> = _executionState
    
    private val executionHistory = mutableListOf<ExecutionRecord>()
    
    /**
     * 🎯 执行场景
     */
    suspend fun executeScenario(
        detection: ScenarioDetectionResult,
        onProgress: (String) -> Unit = {}
    ): ScenarioResult {
        val startTime = System.currentTimeMillis()
        _executionState.value = ExecutionState.Running(
            detection.scenarioType, 0f, "开始执行..."
        )
        
        LogManager.d(TAG, "🎬 开始执行场景: ${detection.scenarioType}")
        
        val result = try {
            when (detection.scenarioType) {
                ScenarioType.MESSAGE -> {
                    val request = detection.parsedRequest as? EnhancedMessageScenario.MessageRequest
                    if (request != null) {
                        EnhancedMessageScenario.sendMessage(request, context) { status ->
                            onProgress(status.message)
                        }
                    } else {
                        ScenarioResult.Failure("消息请求参数错误")
                    }
                }
                ScenarioType.BROWSER -> {
                    when (val request = detection.parsedRequest) {
                        is BrowserScenario.BrowserSearchRequest -> {
                            BrowserScenario.executeBrowserSearch(request, context, onProgress)
                        }
                        is BrowserRequest -> {
                            executeBrowserScenario(request, onProgress)
                        }
                        else -> ScenarioResult.Failure("浏览器请求参数错误")
                    }
                }
                ScenarioType.VIDEO -> {
                    when (val request = detection.parsedRequest) {
                        is VideoScenario.WatchVideoRequest -> {
                            VideoScenario.executeWatchVideo(request, context, onProgress)
                        }
                        is VideoRequest -> {
                            executeVideoScenario(request, onProgress)
                        }
                        else -> ScenarioResult.Failure("视频请求参数错误")
                    }
                }
                ScenarioType.SHOPPING -> {
                    when (val request = detection.parsedRequest) {
                        is ShoppingSearchRequest -> {
                            ShoppingScenario.executeShoppingSearch(request, context, onProgress)
                        }
                        is ShoppingRequest -> {
                            executeShoppingScenario(request, onProgress)
                        }
                        else -> ScenarioResult.Failure("购物请求参数错误")
                    }
                }
                ScenarioType.OFFICE -> {
                    when (val request = detection.parsedRequest) {
                        is OfficeTaskRequest -> {
                            OfficeScenario.executeOfficeTask(request, context, onProgress)
                        }
                        is OfficeRequest -> {
                            executeOfficeScenario(request, onProgress)
                        }
                        else -> ScenarioResult.Failure("办公请求参数错误")
                    }
                }
                ScenarioType.VIDEO_SWIPE -> {
                    val config = detection.parsedRequest as? VideoSwipeScenario.VideoSwipeConfig
                    if (config != null) {
                        executeVideoSwipeScenario(config, onProgress)
                    } else {
                        ScenarioResult.Failure("刷视频配置错误")
                    }
                }
                ScenarioType.FORM_FILLER -> {
                    val config = detection.parsedRequest as? FormFillerScenario.FormFillerConfig
                    if (config != null) {
                        executeFormFillerScenario(config, onProgress)
                    } else {
                        ScenarioResult.Failure("填表配置错误")
                    }
                }
                ScenarioType.GAME_AUTO -> {
                    val config = detection.parsedRequest as? GameAutomationScenario.GameConfig
                    if (config != null) {
                        executeGameScenario(config, onProgress)
                    } else {
                        ScenarioResult.Failure("游戏配置错误")
                    }
                }
                ScenarioType.GOMOKU -> {
                    val config = detection.parsedRequest as? GomokuScenario.GomokuConfig
                    if (config != null) {
                        executeGomokuScenario(config, onProgress)
                    } else {
                        ScenarioResult.Failure("五子棋配置错误")
                    }
                }
                ScenarioType.DOUDIZHU -> {
                    val config = detection.parsedRequest as? DouDiZhuScenario.DouDiZhuConfig
                    if (config != null) {
                        executeDouDiZhuScenario(config, onProgress)
                    } else {
                        ScenarioResult.Failure("斗地主配置错误")
                    }
                }
                ScenarioType.GAME_AI -> {
                    val config = detection.parsedRequest as? GameAIScenario.GameAIConfig
                    if (config != null) {
                        executeGameAIScenario(config, onProgress)
                    } else {
                        ScenarioResult.Failure("游戏AI配置错误")
                    }
                }
                ScenarioType.CUSTOM -> {
                    ScenarioResult.Failure("自定义场景暂不支持")
                }
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "场景执行异常", e)
            ScenarioResult.Failure("执行异常: ${e.message}")
        }
        
        val duration = System.currentTimeMillis() - startTime
        
        _executionState.value = when (result) {
            is ScenarioResult.Success -> ExecutionState.Completed(result)
            is ScenarioResult.PartialSuccess -> ExecutionState.Completed(result)
            is ScenarioResult.Failure -> ExecutionState.Failed(result.error)
            is ScenarioResult.Stopped -> ExecutionState.Completed(result)
        }
        
        executionHistory.add(
            ExecutionRecord(
                scenarioType = detection.scenarioType,
                timestamp = Date(),
                duration = duration,
                result = result
            )
        )
        
        LogManager.d(TAG, "🎬 场景执行完成: $result, 耗时: ${duration}ms")
        return result
    }
    
    /**
     * 🔍 智能检测场景 (并行优化)
     */
    suspend fun detectScenario(userInput: String): ScenarioDetectionResult = withContext(Dispatchers.Default) {
        LogManager.d(TAG, "🔍 并行检测场景: $userInput")

        val messageJob = async { EnhancedMessageScenario.detectMessageIntent(userInput) }
        val shoppingJob = async { ShoppingScenario.detectShopping(userInput) }
        val videoJob = async { VideoScenario.detectWatchVideo(userInput) }
        val browserJob = async { BrowserScenario.detectBrowserSearch(userInput) }
        val officeJob = async { OfficeScenario.detectOffice(userInput) }

        // 按置信度/优先级返回
        messageJob.await()?.let { return@withContext ScenarioDetectionResult(ScenarioType.MESSAGE, 0.95f, it) }
        shoppingJob.await()?.let { return@withContext ScenarioDetectionResult(ScenarioType.SHOPPING, 0.85f, it) }
        videoJob.await()?.let { return@withContext ScenarioDetectionResult(ScenarioType.VIDEO, 0.85f, it) }
        browserJob.await()?.let { return@withContext ScenarioDetectionResult(ScenarioType.BROWSER, 0.85f, it) }
        officeJob.await()?.let { return@withContext ScenarioDetectionResult(ScenarioType.OFFICE, 0.85f, it) }

        ScenarioDetectionResult(ScenarioType.CUSTOM, 0f, null)
    }
    
    private suspend fun executeBrowserScenario(
        request: BrowserRequest,
        onProgress: (String) -> Unit
    ): ScenarioResult {
        return try {
            when (request.action) {
                BrowserAction.SEARCH -> {
                    val searchReq = BrowserScenario.BrowserSearchRequest(
                        searchEngine = "百度",
                        keyword = request.query,
                        count = 5,
                        clickAds = false,
                        useAppMode = false
                    )
                    BrowserScenario.executeBrowserSearch(searchReq, context, onProgress)
                }
                BrowserAction.OPEN_URL, BrowserAction.NAVIGATE -> {
                    val url = request.url
                    if (url.isNullOrBlank()) {
                        return ScenarioResult.Failure("URL为空")
                    }

                    onProgress("正在打开链接...")
                    val openResult = ToolRegistry.executeTool(
                        com.example.xihe.tools.ToolCall(
                            "open_url",
                            buildJsonObject { put("url", kotlinx.serialization.json.JsonPrimitive(url)) }
                        )
                    )

                    if (openResult.success) {
                        ScenarioResult.Success("已打开链接")
                    } else {
                        ScenarioResult.Failure("无法打开链接")
                    }
                }
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "浏览器场景执行失败", e)
            ScenarioResult.Failure("浏览器操作失败: ${e.message}")
        }
    }
    
    private suspend fun executeVideoScenario(
        request: VideoRequest,
        onProgress: (String) -> Unit
    ): ScenarioResult {
        return try {
            // 转换为 WatchVideoRequest
            val videoRequest = VideoScenario.WatchVideoRequest(
                app = request.app.displayName,
                searchKeyword = if (request.action == VideoAction.SEARCH_AND_PLAY) request.query else null,
                count = 10 // 默认10个视频
            )
            
            VideoScenario.executeWatchVideo(videoRequest, context, onProgress)
        } catch (e: Exception) {
            LogManager.e(TAG, "视频场景执行失败", e)
            ScenarioResult.Failure("视频操作失败: ${e.message}")
        }
    }
    
    private suspend fun executeShoppingScenario(
        request: ShoppingRequest,
        onProgress: (String) -> Unit
    ): ScenarioResult {
        return try {
            // 转换为 ShoppingSearchRequest
            val shoppingRequest = ShoppingSearchRequest(
                app = request.app.displayName,
                keyword = request.query,
                shouldBuy = request.action == ShoppingAction.BUY || request.action == ShoppingAction.ADD_TO_CART,
                sortBy = null
            )
            
            ShoppingScenario.executeShoppingSearch(shoppingRequest, context, onProgress)
        } catch (e: Exception) {
            LogManager.e(TAG, "购物场景执行失败", e)
            ScenarioResult.Failure("购物操作失败: ${e.message}")
        }
    }
    
    private suspend fun executeOfficeScenario(
        request: OfficeRequest,
        onProgress: (String) -> Unit
    ): ScenarioResult {
        return try {
            val officeRequest = OfficeTaskRequest(
                app = when (request.app) {
                    OfficeApp.WPS -> OfficeTargetApp.WPS
                    OfficeApp.OFFICE -> OfficeTargetApp.OFFICE
                },
                action = when (request.action) {
                    OfficeAction.CREATE_DOCUMENT -> OfficeTaskAction.CREATE_DOCUMENT
                    OfficeAction.OPEN_DOCUMENT -> OfficeTaskAction.OPEN_DOCUMENT
                    OfficeAction.EDIT -> OfficeTaskAction.EDIT
                },
                documentName = request.documentName
            )

            OfficeScenario.executeOfficeTask(officeRequest, context, onProgress)
        } catch (e: Exception) {
            LogManager.e(TAG, "办公场景执行失败", e)
            ScenarioResult.Failure("办公操作失败: ${e.message}")
        }
    }
    
    private fun findButtonByKeywords(
        node: android.view.accessibility.AccessibilityNodeInfo,
        keywords: List<String>
    ): android.view.accessibility.AccessibilityNodeInfo? {
        val text = node.text?.toString()?.lowercase() ?: ""
        val desc = node.contentDescription?.toString()?.lowercase() ?: ""
        
        if (node.isClickable && keywords.any { text.contains(it.lowercase()) || desc.contains(it.lowercase()) }) {
            return node
        }
        
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                findButtonByKeywords(child, keywords)?.let { return it }
            }
        }
        return null
    }
    
    private fun findNodeByText(
        node: android.view.accessibility.AccessibilityNodeInfo,
        targetText: String
    ): android.view.accessibility.AccessibilityNodeInfo? {
        val text = node.text?.toString() ?: ""
        val desc = node.contentDescription?.toString() ?: ""
        
        if (text.contains(targetText, ignoreCase = true) || desc.contains(targetText, ignoreCase = true)) {
            return node
        }
        
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                findNodeByText(child, targetText)?.let { return it }
            }
        }
        return null
    }
    
    /**
     * 📹 执行刷视频场景
     */
    private suspend fun executeVideoSwipeScenario(
        config: VideoSwipeScenario.VideoSwipeConfig,
        onProgress: (String) -> Unit
    ): ScenarioResult {
        val scenario = VideoSwipeScenario(context)
        
        scope.launch {
            scenario.progress.collect { p ->
                _executionState.value = ExecutionState.Running(
                    ScenarioType.VIDEO_SWIPE,
                    p.progressPercent,
                    p.message
                )
                onProgress(p.message)
            }
        }
        
        return scenario.start(config)
    }
    
    /**
     * 📝 执行填数据场景
     */
    private suspend fun executeFormFillerScenario(
        config: FormFillerScenario.FormFillerConfig,
        onProgress: (String) -> Unit
    ): ScenarioResult {
        val scenario = FormFillerScenario(context)
        
        scope.launch {
            scenario.progress.collect { p ->
                _executionState.value = ExecutionState.Running(
                    ScenarioType.FORM_FILLER,
                    p.progressPercent,
                    p.message
                )
                onProgress(p.message)
            }
        }
        
        return scenario.start(config)
    }
    
    /**
     * 🎮 执行游戏自动化场景
     */
    private suspend fun executeGameScenario(
        config: GameAutomationScenario.GameConfig,
        onProgress: (String) -> Unit
    ): ScenarioResult {
        val scenario = GameAutomationScenario(context)
        
        scope.launch {
            scenario.progress.collect { p ->
                _executionState.value = ExecutionState.Running(
                    ScenarioType.GAME_AUTO,
                    p.progressPercent,
                    p.message
                )
                onProgress(p.message)
            }
        }
        
        return scenario.start(config)
    }
    
    /**
     * ⚫⚪ 执行五子棋场景
     */
    private suspend fun executeGomokuScenario(
        config: GomokuScenario.GomokuConfig,
        onProgress: (String) -> Unit
    ): ScenarioResult {
        val scenario = GomokuScenario(context)
        
        scope.launch {
            scenario.progress.collect { p ->
                _executionState.value = ExecutionState.Running(
                    ScenarioType.GOMOKU,
                    p.progressPercent,
                    p.message
                )
                onProgress(p.message)
            }
        }
        
        return scenario.start(config)
    }
    
    /**
     * 🃏 执行斗地主场景
     */
    private suspend fun executeDouDiZhuScenario(
        config: DouDiZhuScenario.DouDiZhuConfig,
        onProgress: (String) -> Unit
    ): ScenarioResult {
        val scenario = DouDiZhuScenario(context)
        
        scope.launch {
            scenario.progress.collect { p ->
                _executionState.value = ExecutionState.Running(
                    ScenarioType.DOUDIZHU,
                    p.progressPercent,
                    p.message
                )
                onProgress(p.message)
            }
        }
        
        return scenario.start(config)
    }
    
    /**
     * 🤖 执行通用游戏AI场景
     */
    private suspend fun executeGameAIScenario(
        config: GameAIScenario.GameAIConfig,
        onProgress: (String) -> Unit
    ): ScenarioResult {
        val scenario = GameAIScenario(context)
        
        scope.launch {
            scenario.progress.collect { p ->
                _executionState.value = ExecutionState.Running(
                    ScenarioType.GAME_AI,
                    p.progressPercent,
                    p.message
                )
                onProgress(p.message)
            }
        }
        
        return scenario.start(config)
    }
    
    // ==================== 📊 历史记录 ====================
    
    /**
     * 📊 获取执行历史
     */
    fun getExecutionHistory(): List<ExecutionRecord> = executionHistory.toList()
    
    /**
     * 🧹 清空历史
     */
    fun clearHistory() {
        executionHistory.clear()
    }
    
    /**
     * 📊 获取统计信息
     */
    fun getStatistics(): ExecutionStatistics {
        val total = executionHistory.size
        val successful = executionHistory.count { it.result is ScenarioResult.Success }
        val failed = executionHistory.count { it.result is ScenarioResult.Failure }
        val avgDuration = if (total > 0) executionHistory.map { it.duration }.average() else 0.0
        
        return ExecutionStatistics(
            totalExecutions = total,
            successfulExecutions = successful,
            failedExecutions = failed,
            averageDuration = avgDuration.toLong()
        )
    }
    
    // ==================== 🆕 新场景执行实现 ====================
    
    /**
     * 快捷：刷视频
     */
    suspend fun startVideoSwipe(
        appName: String = "抖音",
        count: Int = 50,
        minStaySeconds: Int = 3,
        maxStaySeconds: Int = 15,
        onProgress: (String) -> Unit = {}
    ): ScenarioResult {
        val config = VideoSwipeScenario.VideoSwipeConfig(
            appName = appName,
            swipeCount = count,
            minStaySeconds = minStaySeconds,
            maxStaySeconds = maxStaySeconds
        )
        return executeVideoSwipeScenario(config, onProgress)
    }
    
    /**
     * 🎮 快捷：游戏循环点击
     */
    suspend fun startGameLoopTap(
        x: Float, y: Float,
        isRelative: Boolean = true,
        intervalMs: Long = 1000L,
        count: Int = 100,
        onProgress: (String) -> Unit = {}
    ): ScenarioResult {
        val config = GameAutomationScenario.MacroTemplates.simpleLoopTap(
            x, y, isRelative, intervalMs, count
        )
        return executeGameScenario(config, onProgress)
    }
    
    /**
     * 📝 快捷：填充单条数据
     */
    suspend fun fillFormData(
        fields: Map<String, String>,
        mappings: List<FormFillerScenario.FieldMapping>,
        submitAfterFill: Boolean = false,
        onProgress: (String) -> Unit = {}
    ): ScenarioResult {
        val config = FormFillerScenario.FormFillerConfig(
            dataSource = FormFillerScenario.DataSource.Manual(fields),
            fieldMappings = mappings,
            submitAfterFill = submitAfterFill
        )
        return executeFormFillerScenario(config, onProgress)
    }
    
    // ==================== 🎮 游戏快捷方法 ====================
    
    /**
     * ⚫⚪ 快捷：五子棋对弈
     */
    suspend fun startGomoku(
        playAs: Int = GomokuScenario.BLACK,
        searchDepth: Int = 4,
        onProgress: (String) -> Unit = {}
    ): ScenarioResult {
        val config = GomokuScenario.GomokuConfig(
            playAs = playAs,
            searchDepth = searchDepth
        )
        return executeGomokuScenario(config, onProgress)
    }
    
    /**
     * 🃏 快捷：斗地主对局
     */
    suspend fun startDouDiZhu(
        appName: String = "欢乐斗地主",
        autoGrab: Boolean = true,
        onProgress: (String) -> Unit = {}
    ): ScenarioResult {
        val config = DouDiZhuScenario.DouDiZhuConfig(
            appName = appName,
            autoGrab = autoGrab
        )
        return executeDouDiZhuScenario(config, onProgress)
    }
    
    /**
     * 🤖 快捷：通用游戏AI
     */
    suspend fun startGameAI(
        gamePackage: String? = null,
        objective: String = "按照游戏提示自动操作",
        gameType: GameAIScenario.Companion.GameType = GameAIScenario.Companion.GameType.CUSTOM,
        onProgress: (String) -> Unit = {}
    ): ScenarioResult {
        val config = GameAIScenario.GameAIConfig(
            gamePackage = gamePackage,
            objective = objective,
            gameType = gameType
        )
        return executeGameAIScenario(config, onProgress)
    }
}

// ==================== 📊 数据类定义 ====================

/**
 * 🎯 场景类型
 */
enum class ScenarioType {
    MESSAGE,        // 消息发送
    BROWSER,        // 浏览器
    VIDEO,          // 视频播放
    SHOPPING,       // 购物
    OFFICE,         // 办公
    VIDEO_SWIPE,    // 刷视频
    FORM_FILLER,    // 填表
    GAME_AUTO,      // 游戏自动化
    GOMOKU,         // 五子棋
    DOUDIZHU,       // 斗地主
    GAME_AI,        // 游戏AI
    CUSTOM          // 自定义
}

/**
 * 🎯 场景检测结果
 */
data class ScenarioDetectionResult(
    val scenarioType: ScenarioType,
    val confidence: Float,
    val parsedRequest: Any?
)

/**
 * 🎯 执行状态
 */
sealed class ExecutionState {
    object Idle : ExecutionState()
    data class Running(
        val scenarioType: ScenarioType,
        val progress: Float,
        val message: String
    ) : ExecutionState()
    data class Completed(val result: ScenarioResult) : ExecutionState()
    data class Failed(val error: String) : ExecutionState()
}

/**
 * 📊 执行记录
 */
data class ExecutionRecord(
    val scenarioType: ScenarioType,
    val timestamp: Date,
    val duration: Long,
    val result: ScenarioResult
)

// ==================== 📊 数据类定义 ====================

data class BrowserRequest(
    val action: BrowserAction,
    val query: String,
    val url: String? = null
)

enum class BrowserAction { SEARCH, OPEN_URL, NAVIGATE }

data class VideoRequest(
    val app: VideoApp,
    val action: VideoAction,
    val query: String
)

enum class VideoApp(val packageName: String, val displayName: String) {
    DOUYIN("com.ss.android.ugc.aweme", "抖音"),
    KUAISHOU("com.smile.gifmaker", "快手"),
    BILIBILI("tv.danmaku.bili", "哔哩哔哩"),
    YOUTUBE("com.google.android.youtube", "YouTube")
}

enum class VideoAction { SEARCH_AND_PLAY, PLAY, PAUSE, NEXT, PREVIOUS }

data class ShoppingRequest(
    val app: ShoppingApp,
    val action: ShoppingAction,
    val query: String
)

enum class ShoppingApp(val packageName: String, val displayName: String) {
    TAOBAO("com.taobao.taobao", "淘宝"),
    JD("com.jingdong.app.mall", "京东"),
    PDD("com.xunmeng.pinduoduo", "拼多多")
}

enum class ShoppingAction { SEARCH, ADD_TO_CART, BUY }

data class OfficeRequest(
    val app: OfficeApp,
    val action: OfficeAction,
    val documentName: String
)

enum class OfficeApp(val packageName: String, val displayName: String) {
    WPS("cn.wps.moffice_eng", "WPS"),
    OFFICE("com.microsoft.office.officehubrow", "Office")
}

enum class OfficeAction { CREATE_DOCUMENT, OPEN_DOCUMENT, EDIT }

data class ExecutionStatistics(
    val totalExecutions: Int,
    val successfulExecutions: Int,
    val failedExecutions: Int,
    val averageDuration: Long
)
