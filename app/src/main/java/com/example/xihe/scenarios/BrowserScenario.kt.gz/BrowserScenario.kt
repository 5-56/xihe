package com.example.xihe.scenarios

import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.core.*
import com.example.xihe.tools.ToolRegistry
import kotlinx.coroutines.delay
import kotlinx.serialization.json.buildJsonObject
import kotlin.random.Random

/**
 * 浏览器搜索场景
 * 支持百度、谷歌等搜索引擎
 */
object BrowserScenario {
    private const val TAG = "BrowserScenario"
    
    /**
     * 检测是否是浏览器搜索指令
     */
    fun detectBrowserSearch(userInput: String): BrowserSearchRequest? {
        val input = userInput.trim()
        
        // 场景检测
        // 模式1："打开百度，搜索xxx" -> 打开百度APP
        // 模式2："在浏览器搜索xxx" -> 使用浏览器访问搜索引擎
        
        val useAppMode = input.contains(Regex("打开\\s*(百度|谷歌)")) && !input.contains("浏览器")
        val useBrowserMode = input.contains(Regex("浏览器.*搜索|在浏览器|用浏览器"))
        
        val hasSearchKeyword = input.contains("搜索")
        val hasActionKeyword = input.contains(Regex("查看|浏览|点击|点开|进入|访问|推荐内容|链接|网页|广告"))
        
        // 必须是搜索相关的操作
        if (!useAppMode && !useBrowserMode && !(hasSearchKeyword && hasActionKeyword)) {
            return null
        }
        
        // 提取搜索引擎/APP
        val searchEngine = when {
            input.contains(Regex("谷歌|google")) -> "谷歌"
            input.contains(Regex("百度|baidu")) -> "百度"
            else -> "百度" // 默认百度
        }
        
        // 提取数量
        val countMatch = Regex("""(\d+)\s*(个|条|篇)?\s*(广告|链接|网页|推荐|内容|结果)""").find(input)
        val count = countMatch?.groupValues?.get(1)?.toIntOrNull() ?: 5 // 默认5个
        
        // 判断是否专门点击广告
        val clickAds = input.contains(Regex("广告|推广|赞助"))
        
        // 提取关键词 - 改进版本
        // 先找到"搜索"后面的内容
        val searchPattern = Regex("""搜索[：:]\s*(.+?)(?:[，,]|$)""")
        val searchPattern2 = Regex("""搜索\s+([^，,、。！？\s]+)""")
        
        var keyword = ""
        
        // 尝试匹配 "搜索：xxx" 或 "搜索 xxx"
        searchPattern.find(input)?.let {
            keyword = it.groupValues[1].trim()
        }
        
        if (keyword.isEmpty()) {
            searchPattern2.find(input)?.let {
                keyword = it.groupValues[1].trim()
            }
        }
        
        // 如果还是没找到，尝试从整句中提取（去除所有操作词）
        if (keyword.isEmpty()) {
            keyword = input
                .replace(Regex("^(打开|在|用)?浏览器[，,、]?"), "")
                .replace(Regex("^(帮我|请|麻烦)[，,、]?"), "")
                .replace(Regex("^搜索?[：:]?"), "")  // "搜" or "搜索"
                .replace(Regex("^搜[一些啊吧呢]?"), "")  // "搜一些" "搜啊" "搜吧"
                .replace(Regex("(在|用)?(百度|谷歌|google|baidu)(里|中|上)?[，,、]?"), "") // 去掉搜索引擎名称
                .replace(Regex("[，,、](并且|然后|接着|同时).+"), "") // 去掉后面的操作指令
                .trim()
        }
        
        // 清理关键词中的语气词和停用词
        keyword = keyword
            .replace(Regex("^(一些|一点|有关|关于)[啊呢吧哦呀]?"), "") // "一些啊" "一点啊"
            .replace(Regex("[啊呢吧哦呀嘛](?=[\\s\u4e00-\u9fa5])"), "") // 移除中间的语气词
            .replace(Regex("[，,、。！？]$"), "") // 移除末尾标点
            .replace(Regex("\\s+"), " ") // 合并多个空格
            .trim()
        
        // 如果关键词为空或太短，返回null
        if (keyword.isEmpty() || keyword.length < 2) {
            return null
        }
        
        LogManager.d(TAG, "检测到搜索场景 - 模式: ${if (useAppMode) "APP" else "浏览器"}, 关键词: $keyword")
        
        return BrowserSearchRequest(searchEngine, keyword, count, clickAds, useAppMode)
    }
    
    /**
     * 执行浏览器搜索任务
     */
    suspend fun executeBrowserSearch(
        request: BrowserSearchRequest,
        context: Context,
        onProgress: (String) -> Unit
    ): ScenarioResult {
        return try {
            LogManager.d(TAG, "===== 开始执行搜索场景 =====")
            LogManager.d(TAG, "模式: ${if (request.useAppMode) "APP" else "浏览器"}")
            LogManager.d(TAG, "搜索引擎/APP: ${request.searchEngine}")
            LogManager.d(TAG, "关键词: ${request.keyword}")
            LogManager.d(TAG, "数量: ${request.count}")
            LogManager.d(TAG, "点击广告: ${request.clickAds}")
            
            // Step 1: 根据模式打开APP或浏览器
            if (request.useAppMode) {
                // APP 模式：打开指定的APP
                val appPackage = when (request.searchEngine) {
                    "百度" -> "com.baidu.searchbox"
                    "谷歌" -> "com.google.android.googlequicksearchbox"
                    "今日头条" -> "com.ss.android.article.news"
                    "微信" -> "com.tencent.mm"
                    "QQ" -> "com.tencent.mobileqq"
                    "微博" -> "com.sina.weibo"
                    "知乎" -> "com.zhihu.android"
                    "小红书" -> "com.xingin.xhs"
                    "淘宝" -> "com.taobao.taobao"
                    "京东" -> "com.jingdong.app.mall"
                    "押音" -> "com.ss.android.ugc.aweme"
                    "快手" -> "com.smile.gifmaker"
                    "哔哩哔哩" -> "tv.danmaku.bili"
                    else -> "com.baidu.searchbox"
                }
                
                onProgress("正在打开${request.searchEngine}... 📱")
                LogManager.d(TAG, "打开APP: $appPackage")
                
                val openResult = ToolRegistry.executeTool(
                    com.example.xihe.tools.ToolCall(
                        "launch_app",
                        buildJsonObject { put("appNameOrPackage", kotlinx.serialization.json.JsonPrimitive(appPackage)) }
                    )
                )
                
                if (!openResult.success) {
                    LogManager.e(TAG, "打开${request.searchEngine}APP失败")
                    return ScenarioResult.Failure("无法打开${request.searchEngine}APP")
                }
                
                onProgress("正在在${request.searchEngine}里搜索：${request.keyword}... 🔍")
                LogManager.d(TAG, "${request.searchEngine}APP已打开，等待启动")
                delay(3000) // 等待APP启动
            } else {
                // 浏览器模式：打开URL
                onProgress("正在打开浏览器... 🌐")
                
                val url = when (request.searchEngine) {
                    "百度" -> "https://www.baidu.com/s?wd=${java.net.URLEncoder.encode(request.keyword, "UTF-8")}"
                    "谷歌" -> "https://www.google.com/search?q=${java.net.URLEncoder.encode(request.keyword, "UTF-8")}"
                    else -> "https://www.baidu.com/s?wd=${java.net.URLEncoder.encode(request.keyword, "UTF-8")}"
                }
                
                LogManager.d(TAG, "打开URL: $url")
                
                val openResult = ToolRegistry.executeTool(
                    com.example.xihe.tools.ToolCall(
                        "open_url",
                        buildJsonObject { put("url", kotlinx.serialization.json.JsonPrimitive(url)) }
                    )
                )
                
                if (!openResult.success) {
                    LogManager.e(TAG, "打开浏览器失败")
                    return ScenarioResult.Failure("无法打开浏览器")
                }
                
                onProgress("正在搜索：${request.keyword}... 🔍")
                LogManager.d(TAG, "浏览器已打开，等待页面加载")
                delay(3000) // 等待页面加载
            }
            
            val service = CoreAccessibilityService.instance
            if (service == null) {
                LogManager.e(TAG, "无障碍服务未启动")
                return ScenarioResult.Failure("无障碍服务未启动")
            }
            
            val executor = ActionExecutor(service, context)
            val llmClient = LLMClient(
                AutomationEngine.baseUrl,
                AutomationEngine.apiKey,
                AutomationEngine.modelName,
                AutomationEngine.providerId  // 传入 providerId 以正确识别 Google API
            )
            
            // Step 2: 循环点击链接并浏览
            var clickedCount = 0
            var attempts = 0
            val maxAttempts = request.count * 3 // 最多尝试3倍次数
            
            LogManager.d(TAG, "开始循环点击链接，目标: ${request.count} 个")
            
            while (clickedCount < request.count && attempts < maxAttempts) {
                attempts++
                
                onProgress("正在查找第 ${clickedCount + 1}/${request.count} 个链接... 🔗 (尝试 $attempts)")
                LogManager.d(TAG, "尝试查找第 ${clickedCount + 1} 个链接，当前尝试次数: $attempts")
                
                // 获取当前页面
                val root = service.rootInActiveWindow
                if (root == null) {
                    LogManager.w(TAG, "无法获取屏幕根节点，等待1秒后重试")
                    delay(1000)
                    continue
                }
                
                val packageName = root.packageName?.toString() ?: "unknown"
                LogManager.d(TAG, "当前包名: $packageName")
                
                val screenState = ScreenAnalyzer.analyze(root, packageName)
                
                if (screenState == null) {
                    LogManager.w(TAG, "屏幕分析失败")
                    delay(1000)
                    continue
                }
                
                LogManager.d(TAG, "屏幕分析完成，包名: ${screenState.packageName}")
                
                // 让 AI 找到可点击的链接或广告
                val clickPrompt = if (request.clickAds) {
                    "找到搜索结果中的广告（通常标有'广告'、'推广'等字样），点击进入"
                } else {
                    "找到搜索结果中的链接，点击进入浏览"
                }
                
                val command = try {
                    llmClient.think(screenState, clickPrompt, emptyList())
                } catch (e: Exception) {
                    LogManager.e(TAG, "AI 分析失败", e)
                    
                    // 检测是否是审核失败
                    if (e.message?.contains("无法回答") == true || e.message?.contains("审核") == true) {
                        LogManager.w(TAG, "⚠️ 内容被审核，停止搜索")
                        onProgress("搜索内容被审核，已停止... (｡•́︿•̀｡)")
                        return ScenarioResult.Failure("内容被审核，无法继续")
                    }
                    
                    delay(1000)
                    continue
                }
                
                LogManager.d(TAG, "AI 返回命令: action=${command.action}, thought=${command.thought}")
                
                if (command.action == "CLICK" && command.targetId != null) {
                    // 执行点击
                    val success = executor.execute(command, root)
                    
                    if (success) {
                        clickedCount++
                        onProgress("✅ 已点击第 $clickedCount/${request.count} 个链接")
                        LogManager.d(TAG, "✅ 已点击第 $clickedCount 个链接")
                        
                        // 模拟人类浏览
                        delay(2000)
                        HumanBehaviorSimulator.simulateBrowsing(
                            scrollAction = { direction ->
                                val scrollCmd = AICommand(
                                    thought = "模拟人类浏览",
                                    action = "SCROLL",
                                    direction = direction
                                )
                                executor.execute(scrollCmd, service.rootInActiveWindow ?: root)
                            },
                            durationSeconds = Random.nextInt(5, 15)
                        )
                        
                        // 返回上一页
                        LogManager.d(TAG, "浏览完成，返回上一页")
                        service.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
                        delay(2000)
                    } else {
                        LogManager.w(TAG, "点击失败")
                    }
                } else {
                    // 没找到可点击的元素，尝试滚动
                    LogManager.d(TAG, "未找到可点击元素，尝试滚动")
                    val scrollCmd = AICommand(
                        thought = "滚动查找更多结果",
                        action = "SCROLL",
                        direction = "DOWN"
                    )
                    executor.execute(scrollCmd, root)
                    delay(1500)
                }
            }
            
            LogManager.d(TAG, "===== 浏览器搜索场景结束 =====")
            LogManager.d(TAG, "完成数量: $clickedCount/${request.count}")
            
            if (clickedCount >= request.count) {
                onProgress("浏览完成！已查看 $clickedCount 个页面 ✅")
                ScenarioResult.Success("已在${request.searchEngine}成功浏览 $clickedCount 个页面")
            } else {
                ScenarioResult.Failure("仅完成 $clickedCount/${request.count} 个页面")
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "搜索失败", e)
            ScenarioResult.Failure("搜索失败: ${e.message}")
        }
    }
    
    data class BrowserSearchRequest(
        val searchEngine: String, // "百度" 或 "谷歌"
        val keyword: String,       // 搜索关键词
        val count: Int,            // 要浏览的页面数量
        val clickAds: Boolean,     // 是否专门点击广告
        val useAppMode: Boolean = false  // true=打开APP, false=使用浏览器
    )
}
