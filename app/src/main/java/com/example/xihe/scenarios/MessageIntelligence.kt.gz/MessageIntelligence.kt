package com.example.xihe.scenarios

import android.content.Context
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable
import java.util.concurrent.ConcurrentHashMap

/**
 * 💬 消息智能处理模块
 * 
 * 功能：
 * - 🎯 消息意图识别
 * - 😊 消息情感分析
 * - 🔑 消息关键词提取
 * - 📋 消息模板识别
 * - 🤖 智能自动回复
 * - 👥 联系人智能管理
 * - 📨 消息发送流程优化
 */
object MessageIntelligence {
    
    private const val TAG = "MessageIntelligence"
    
    // 联系人使用频率统计
    private val contactUsageStats = ConcurrentHashMap<String, ContactUsage>()
    
    // 消息模板库
    private val messageTemplates = mutableListOf<MessageTemplate>()
    
    // 自动回复规则
    private val autoReplyRules = mutableListOf<AutoReplyRule>()
    
    // 待发送消息预览
    private val _pendingMessage = MutableStateFlow<PendingMessage?>(null)
    val pendingMessage = _pendingMessage.asStateFlow()
    
    // 发送状态跟踪
    private val _sendingStatus = MutableStateFlow<MessageSendingStatus?>(null)
    val sendingStatus = _sendingStatus.asStateFlow()
    
    init {
        // 初始化默认模板
        initDefaultTemplates()
        // 初始化默认回复规则
        initDefaultAutoReplyRules()
    }
    
    // ==================== 🎯 消息意图识别 ====================
    
    /**
     * 🎯 识别消息意图
     */
    fun analyzeMessageIntent(message: String): MessageIntentResult {
        val normalizedMsg = message.trim().lowercase()
        
        // 识别意图类型
        val intentType = detectIntentType(normalizedMsg)
        
        // 提取实体
        val entities = extractEntities(message)
        
        // 计算置信度
        val confidence = calculateIntentConfidence(normalizedMsg, intentType)
        
        // 生成建议回复
        val suggestedReplies = generateSuggestedReplies(intentType, entities)
        
        LogManager.d(TAG, "🎯 消息意图: type=$intentType, confidence=$confidence")
        
        return MessageIntentResult(
            intentType = intentType,
            confidence = confidence,
            entities = entities,
            suggestedReplies = suggestedReplies,
            requiresResponse = intentType in listOf(
                MessageIntentType.QUESTION,
                MessageIntentType.REQUEST,
                MessageIntentType.CONFIRMATION
            )
        )
    }
    
    private fun detectIntentType(message: String): MessageIntentType {
        return when {
            // 问题
            message.contains("吗") || message.contains("?") || message.contains("？") ||
            message.contains("什么") || message.contains("怎么") || message.contains("哪") ||
            message.contains("谁") || message.contains("为什么") -> MessageIntentType.QUESTION
            
            // 请求
            message.contains("请") || message.contains("帮") || message.contains("能不能") ||
            message.contains("可以") || message.contains("麻烦") -> MessageIntentType.REQUEST
            
            // 确认
            message.contains("好的") || message.contains("可以") || message.contains("行") ||
            message.contains("没问题") || message.contains("ok") -> MessageIntentType.CONFIRMATION
            
            // 拒绝
            message.contains("不") || message.contains("没") || message.contains("别") ||
            message.contains("算了") -> MessageIntentType.REJECTION
            
            // 问候
            message.contains("你好") || message.contains("早") || message.contains("晚安") ||
            message.contains("hi") || message.contains("hello") -> MessageIntentType.GREETING
            
            // 感谢
            message.contains("谢") || message.contains("感谢") || message.contains("thanks") -> 
                MessageIntentType.GRATITUDE
            
            // 道歉
            message.contains("抱歉") || message.contains("对不起") || message.contains("sorry") -> 
                MessageIntentType.APOLOGY
            
            // 告别
            message.contains("再见") || message.contains("拜拜") || message.contains("bye") -> 
                MessageIntentType.FAREWELL
            
            // 紧急
            message.contains("紧急") || message.contains("急") || message.contains("马上") ||
            message.contains("立刻") || message.contains("赶紧") -> MessageIntentType.URGENT
            
            // 通知
            message.contains("通知") || message.contains("告诉你") || message.contains("提醒") -> 
                MessageIntentType.NOTIFICATION
            
            else -> MessageIntentType.STATEMENT
        }
    }
    
    private fun extractEntities(message: String): Map<String, String> {
        val entities = mutableMapOf<String, String>()
        
        // 提取时间
        val timePatterns = listOf(
            Regex("""(\d{1,2}[点时:：]\d{0,2}分?)"""),
            Regex("""(今天|明天|后天|昨天|上午|下午|晚上|中午)"""),
            Regex("""(周[一二三四五六日天])"""),
            Regex("""(\d{1,2}月\d{1,2}[日号])""")
        )
        timePatterns.forEach { pattern ->
            pattern.find(message)?.let {
                entities["time"] = it.value
            }
        }
        
        // 提取地点
        val locationPatterns = listOf(
            Regex("""在(.{2,10}?)[见面会]"""),
            Regex("""去(.{2,10}?)(?:吃|玩|看|开会)"""),
            Regex("""(.{2,10}?(?:餐厅|公司|学校|医院|机场|车站))""")
        )
        locationPatterns.forEach { pattern ->
            pattern.find(message)?.let {
                entities["location"] = it.groupValues.getOrNull(1) ?: it.value
            }
        }
        
        // 提取数量/金额
        val amountPattern = Regex("""(\d+(?:\.\d+)?)\s*(?:元|块|个|份|次)""")
        amountPattern.find(message)?.let {
            entities["amount"] = it.value
        }
        
        // 提取人名（简单匹配）
        val namePattern = Regex("""(?:找|叫|告诉|通知)\s*([^\s,，。！!?？]{2,4})""")
        namePattern.find(message)?.let {
            entities["person"] = it.groupValues[1]
        }
        
        return entities
    }
    
    private fun calculateIntentConfidence(message: String, intent: MessageIntentType): Float {
        // 基于关键词匹配计算置信度
        val keywordCount = when (intent) {
            MessageIntentType.QUESTION -> {
                listOf("吗", "?", "？", "什么", "怎么", "哪", "谁", "为什么").count { message.contains(it) }
            }
            MessageIntentType.REQUEST -> {
                listOf("请", "帮", "能不能", "可以", "麻烦").count { message.contains(it) }
            }
            else -> 1
        }
        
        return (0.6f + keywordCount * 0.1f).coerceAtMost(0.95f)
    }
    
    private fun generateSuggestedReplies(
        intent: MessageIntentType,
        entities: Map<String, String>
    ): List<String> {
        return when (intent) {
            MessageIntentType.QUESTION -> listOf(
                "好的，我来查一下",
                "稍等，我确认下",
                "这个问题我需要了解一下"
            )
            MessageIntentType.REQUEST -> listOf(
                "好的，没问题",
                "可以的",
                "我这就去办"
            )
            MessageIntentType.GREETING -> listOf(
                "你好呀~",
                "嗨~",
                "你好！"
            )
            MessageIntentType.GRATITUDE -> listOf(
                "不客气~",
                "应该的",
                "😊"
            )
            MessageIntentType.CONFIRMATION -> listOf(
                "好的，收到",
                "明白了",
                "👌"
            )
            MessageIntentType.URGENT -> listOf(
                "收到，马上处理",
                "好的，我立刻看",
                "OK，紧急处理中"
            )
            else -> listOf(
                "收到",
                "好的",
                "明白"
            )
        }
    }
    
    // ==================== 😊 情感分析 ====================
    
    /**
     * 😊 分析消息情感
     */
    fun analyzeSentiment(message: String): SentimentResult {
        val normalizedMsg = message.lowercase()
        
        var positiveScore = 0f
        var negativeScore = 0f
        
        // 正面词汇
        val positiveWords = listOf(
            "好" to 0.3f, "棒" to 0.4f, "赞" to 0.4f, "喜欢" to 0.5f, "开心" to 0.5f,
            "高兴" to 0.5f, "感谢" to 0.4f, "谢谢" to 0.3f, "爱" to 0.6f, "太好了" to 0.5f,
            "优秀" to 0.4f, "完美" to 0.5f, "厉害" to 0.4f, "牛" to 0.3f, "😊" to 0.3f,
            "😄" to 0.4f, "❤" to 0.4f, "👍" to 0.3f, "🎉" to 0.4f
        )
        
        // 负面词汇
        val negativeWords = listOf(
            "不" to 0.2f, "差" to 0.4f, "烦" to 0.4f, "讨厌" to 0.5f, "生气" to 0.5f,
            "难过" to 0.5f, "失望" to 0.4f, "抱歉" to 0.2f, "糟糕" to 0.4f, "垃圾" to 0.6f,
            "无语" to 0.3f, "崩溃" to 0.5f, "累" to 0.3f, "困" to 0.2f, "😢" to 0.4f,
            "😭" to 0.5f, "😠" to 0.5f, "💔" to 0.4f
        )
        
        positiveWords.forEach { (word, score) ->
            if (normalizedMsg.contains(word)) positiveScore += score
        }
        
        negativeWords.forEach { (word, score) ->
            if (normalizedMsg.contains(word)) negativeScore += score
        }
        
        // 计算最终情感
        val totalScore = positiveScore - negativeScore
        val sentiment = when {
            totalScore > 0.5f -> Sentiment.VERY_POSITIVE
            totalScore > 0.2f -> Sentiment.POSITIVE
            totalScore < -0.5f -> Sentiment.VERY_NEGATIVE
            totalScore < -0.2f -> Sentiment.NEGATIVE
            else -> Sentiment.NEUTRAL
        }
        
        // 检测情感强度
        val intensity = (kotlin.math.abs(totalScore) * 2).coerceAtMost(1f)
        
        // 检测主要情绪
        val emotions = detectEmotions(normalizedMsg)
        
        return SentimentResult(
            sentiment = sentiment,
            score = totalScore,
            intensity = intensity,
            emotions = emotions,
            confidence = (0.5f + intensity * 0.3f).coerceAtMost(0.9f)
        )
    }
    
    private fun detectEmotions(message: String): List<Emotion> {
        val emotions = mutableListOf<Emotion>()
        
        if (message.contains("开心") || message.contains("高兴") || message.contains("😊") || message.contains("😄")) {
            emotions.add(Emotion.HAPPY)
        }
        if (message.contains("难过") || message.contains("伤心") || message.contains("😢") || message.contains("😭")) {
            emotions.add(Emotion.SAD)
        }
        if (message.contains("生气") || message.contains("愤怒") || message.contains("😠") || message.contains("💢")) {
            emotions.add(Emotion.ANGRY)
        }
        if (message.contains("害怕") || message.contains("担心") || message.contains("😨")) {
            emotions.add(Emotion.FEARFUL)
        }
        if (message.contains("惊讶") || message.contains("😮") || message.contains("😱")) {
            emotions.add(Emotion.SURPRISED)
        }
        if (message.contains("爱") || message.contains("喜欢") || message.contains("❤") || message.contains("😍")) {
            emotions.add(Emotion.LOVING)
        }
        
        return emotions.ifEmpty { listOf(Emotion.NEUTRAL) }
    }
    
    // ==================== 🔑 关键词提取 ====================
    
    /**
     * 🔑 提取消息关键词
     */
    fun extractKeywords(message: String, maxKeywords: Int = 5): KeywordResult {
        val words = segmentWords(message)
        val wordFreq = mutableMapOf<String, Int>()
        
        // 统计词频
        words.forEach { word ->
            if (word.length >= 2 && !isStopWord(word)) {
                wordFreq[word] = (wordFreq[word] ?: 0) + 1
            }
        }
        
        // 计算TF-IDF权重（简化版）
        val keywords = wordFreq.map { (word, freq) ->
            val weight = freq * getWordImportance(word)
            Keyword(word = word, weight = weight, frequency = freq)
        }.sortedByDescending { it.weight }
         .take(maxKeywords)
        
        // 提取主题
        val topics = detectTopics(keywords.map { it.word })
        
        return KeywordResult(
            keywords = keywords,
            topics = topics,
            summary = generateSummary(message, keywords)
        )
    }
    
    private fun segmentWords(text: String): List<String> {
        // 简单分词：按标点和空格分割，再按字符组合
        val words = mutableListOf<String>()
        val cleanText = text.replace(Regex("""[,，。！!?？；;：:、\s]+"""), " ")
        
        cleanText.split(" ").forEach { segment ->
            if (segment.length <= 4) {
                words.add(segment)
            } else {
                // 双字组合
                for (i in 0 until segment.length - 1) {
                    words.add(segment.substring(i, i + 2))
                }
            }
        }
        
        return words.filter { it.isNotBlank() }
    }
    
    private fun isStopWord(word: String): Boolean {
        val stopWords = setOf(
            "的", "了", "是", "在", "我", "你", "他", "她", "它", "们",
            "这", "那", "有", "和", "与", "或", "但", "而", "就", "也",
            "都", "把", "被", "给", "到", "从", "为", "以", "及", "等"
        )
        return word in stopWords
    }
    
    private fun getWordImportance(word: String): Float {
        // 根据词性和语义给予权重
        return when {
            word.matches(Regex(""".*[时间日期月年号点].*""")) -> 1.5f  // 时间相关
            word.matches(Regex(""".*[元块钱].*""")) -> 1.5f  // 金额相关
            word.matches(Regex(""".*[地址路街].*""")) -> 1.3f  // 地点相关
            word.length >= 3 -> 1.2f  // 长词
            else -> 1.0f
        }
    }
    
    private fun detectTopics(keywords: List<String>): List<String> {
        val topics = mutableListOf<String>()
        val keywordText = keywords.joinToString(" ")
        
        if (keywordText.contains(Regex("""工作|项目|会议|报告|任务"""))) topics.add("工作")
        if (keywordText.contains(Regex("""吃|喝|餐|饭|美食"""))) topics.add("餐饮")
        if (keywordText.contains(Regex("""玩|游戏|电影|音乐|娱乐"""))) topics.add("娱乐")
        if (keywordText.contains(Regex("""买|购|钱|付|支付"""))) topics.add("购物")
        if (keywordText.contains(Regex("""去|来|走|回|出发"""))) topics.add("出行")
        if (keywordText.contains(Regex("""学|课|考|书|作业"""))) topics.add("学习")
        
        return topics.ifEmpty { listOf("日常") }
    }
    
    private fun generateSummary(message: String, keywords: List<Keyword>): String {
        val keywordStr = keywords.take(3).joinToString("、") { it.word }
        return "关于${keywordStr}的消息"
    }
    
    // ==================== 📋 消息模板 ====================
    
    /**
     * 📋 识别消息模板
     */
    fun recognizeTemplate(message: String): TemplateMatch? {
        var bestMatch: TemplateMatch? = null
        var maxSimilarity = 0f
        
        messageTemplates.forEach { template ->
            val similarity = calculateTemplateSimilarity(message, template)
            if (similarity > maxSimilarity && similarity > 0.6f) {
                maxSimilarity = similarity
                bestMatch = TemplateMatch(
                    template = template,
                    similarity = similarity,
                    filledValues = extractTemplateValues(message, template)
                )
            }
        }
        
        return bestMatch
    }
    
    private fun calculateTemplateSimilarity(message: String, template: MessageTemplate): Float {
        val templateWords = template.pattern.split(Regex("""\{.*?\}"""))
        var matchCount = 0
        
        templateWords.forEach { word ->
            if (word.isNotBlank() && message.contains(word.trim())) {
                matchCount++
            }
        }
        
        return if (templateWords.isNotEmpty()) {
            matchCount.toFloat() / templateWords.size
        } else 0f
    }
    
    private fun extractTemplateValues(message: String, template: MessageTemplate): Map<String, String> {
        val values = mutableMapOf<String, String>()
        
        template.variables.forEach { variable ->
            val pattern = template.pattern.replace("{$variable}", "(.+?)")
            Regex(pattern).find(message)?.let {
                if (it.groupValues.size > 1) {
                    values[variable] = it.groupValues[1]
                }
            }
        }
        
        return values
    }
    
    /**
     * 📋 应用消息模板
     */
    fun applyTemplate(templateId: String, values: Map<String, String>): String? {
        val template = messageTemplates.find { it.id == templateId } ?: return null
        
        var result = template.pattern
        values.forEach { (key, value) ->
            result = result.replace("{$key}", value)
        }
        
        return result
    }
    
    /**
     * ➕ 添加自定义模板
     */
    fun addTemplate(template: MessageTemplate) {
        messageTemplates.add(template)
        LogManager.d(TAG, "➕ 添加模板: ${template.name}")
    }
    
    private fun initDefaultTemplates() {
        messageTemplates.addAll(listOf(
            MessageTemplate(
                id = "meeting_notice",
                name = "会议通知",
                category = "工作",
                pattern = "通知：{time}在{location}开会，主题：{topic}，请准时参加。",
                variables = listOf("time", "location", "topic")
            ),
            MessageTemplate(
                id = "schedule_confirm",
                name = "日程确认",
                category = "日常",
                pattern = "{time}{event}，{location}见，不见不散~",
                variables = listOf("time", "event", "location")
            ),
            MessageTemplate(
                id = "payment_remind",
                name = "付款提醒",
                category = "财务",
                pattern = "提醒：{item}共{amount}元，麻烦{time}前付款，谢谢~",
                variables = listOf("item", "amount", "time")
            ),
            MessageTemplate(
                id = "birthday_wish",
                name = "生日祝福",
                category = "祝福",
                pattern = "{name}，生日快乐🎂！祝你{wish}，心想事成！",
                variables = listOf("name", "wish")
            )
        ))
    }
    
    // ==================== 🤖 智能自动回复 ====================
    
    /**
     * 🤖 生成自动回复
     */
    fun generateAutoReply(
        receivedMessage: String,
        context: ReplyContext? = null
    ): AutoReplyResult {
        // 分析消息意图
        val intentResult = analyzeMessageIntent(receivedMessage)
        
        // 分析情感
        val sentimentResult = analyzeSentiment(receivedMessage)
        
        // 匹配回复规则
        val matchedRule = autoReplyRules.find { rule ->
            rule.triggers.any { trigger ->
                receivedMessage.lowercase().contains(trigger.lowercase())
            }
        }
        
        // 生成回复
        val reply = if (matchedRule != null) {
            // 使用匹配的规则
            selectReplyFromRule(matchedRule, sentimentResult)
        } else {
            // 根据意图生成
            intentResult.suggestedReplies.firstOrNull() ?: "收到~"
        }
        
        // 根据情感调整回复语气
        val adjustedReply = adjustReplyTone(reply, sentimentResult)
        
        return AutoReplyResult(
            reply = adjustedReply,
            confidence = intentResult.confidence,
            matchedRule = matchedRule?.name,
            reasoning = "基于${intentResult.intentType}意图和${sentimentResult.sentiment}情感生成"
        )
    }
    
    private fun selectReplyFromRule(rule: AutoReplyRule, sentiment: SentimentResult): String {
        return when (sentiment.sentiment) {
            Sentiment.VERY_POSITIVE, Sentiment.POSITIVE -> 
                rule.positiveReplies.randomOrNull() ?: rule.replies.random()
            Sentiment.VERY_NEGATIVE, Sentiment.NEGATIVE -> 
                rule.negativeReplies.randomOrNull() ?: rule.replies.random()
            else -> rule.replies.random()
        }
    }
    
    private fun adjustReplyTone(reply: String, sentiment: SentimentResult): String {
        return when (sentiment.sentiment) {
            Sentiment.VERY_POSITIVE -> "$reply 😊"
            Sentiment.POSITIVE -> "$reply~"
            Sentiment.NEGATIVE -> "抱歉，$reply"
            Sentiment.VERY_NEGATIVE -> "非常抱歉，$reply 😢"
            else -> reply
        }
    }
    
    /**
     * ➕ 添加自动回复规则
     */
    fun addAutoReplyRule(rule: AutoReplyRule) {
        autoReplyRules.add(rule)
        LogManager.d(TAG, "➕ 添加回复规则: ${rule.name}")
    }
    
    private fun initDefaultAutoReplyRules() {
        autoReplyRules.addAll(listOf(
            AutoReplyRule(
                name = "在吗询问",
                triggers = listOf("在吗", "在不在", "你在吗"),
                replies = listOf("在的", "在呢", "我在~"),
                positiveReplies = listOf("在的在的😊", "嗯嗯，在呢~"),
                negativeReplies = listOf("在的，怎么了？")
            ),
            AutoReplyRule(
                name = "忙碌询问",
                triggers = listOf("忙吗", "方便吗", "有空吗"),
                replies = listOf("还好，什么事？", "说吧~", "你说"),
                positiveReplies = listOf("不忙不忙，你说~"),
                negativeReplies = listOf("有点忙，稍后回你")
            ),
            AutoReplyRule(
                name = "收到确认",
                triggers = listOf("收到了吗", "看到了吗", "发给你了"),
                replies = listOf("收到了", "看到了", "好的，收到"),
                positiveReplies = listOf("收到啦，谢谢！"),
                negativeReplies = listOf("收到了，我看看")
            )
        ))
    }
    
    // ==================== 👥 联系人管理 ====================
    
    /**
     * 🔍 智能搜索联系人
     */
    fun smartSearchContact(query: String, contacts: List<ContactInfo>): List<ContactSearchResult> {
        val normalizedQuery = query.trim().lowercase()
        
        return contacts.map { contact ->
            val similarity = calculateContactSimilarity(normalizedQuery, contact)
            val usageScore = contactUsageStats[contact.id]?.let { 
                it.useCount.toFloat() / 100f 
            } ?: 0f
            
            ContactSearchResult(
                contact = contact,
                matchScore = similarity,
                usageScore = usageScore,
                totalScore = similarity * 0.7f + usageScore * 0.3f,
                matchReason = getMatchReason(normalizedQuery, contact)
            )
        }.filter { it.matchScore > 0.3f }
         .sortedByDescending { it.totalScore }
    }
    
    private fun calculateContactSimilarity(query: String, contact: ContactInfo): Float {
        var maxSimilarity = 0f
        
        // 名字匹配
        val nameSimilarity = calculateStringSimilarity(query, contact.name.lowercase())
        maxSimilarity = maxOf(maxSimilarity, nameSimilarity)
        
        // 昵称匹配
        contact.nickname?.let {
            val nickSimilarity = calculateStringSimilarity(query, it.lowercase())
            maxSimilarity = maxOf(maxSimilarity, nickSimilarity)
        }
        
        // 备注匹配
        contact.remark?.let {
            val remarkSimilarity = calculateStringSimilarity(query, it.lowercase())
            maxSimilarity = maxOf(maxSimilarity, remarkSimilarity)
        }
        
        // 拼音匹配（简化）
        val pinyinSimilarity = calculatePinyinSimilarity(query, contact.name)
        maxSimilarity = maxOf(maxSimilarity, pinyinSimilarity)
        
        return maxSimilarity
    }
    
    private fun calculateStringSimilarity(s1: String, s2: String): Float {
        if (s1 == s2) return 1.0f
        if (s1.isEmpty() || s2.isEmpty()) return 0f
        
        // 包含匹配
        if (s2.contains(s1)) return 0.9f
        if (s1.contains(s2)) return 0.8f
        
        // 前缀匹配
        if (s2.startsWith(s1)) return 0.85f
        
        // 字符重叠
        val commonChars = s1.filter { s2.contains(it) }
        return commonChars.length.toFloat() / maxOf(s1.length, s2.length)
    }
    
    private fun calculatePinyinSimilarity(query: String, name: String): Float {
        // 简化拼音匹配：首字母匹配
        val initials = name.map { char ->
            when (char) {
                in 'A'..'Z', in 'a'..'z' -> char.lowercaseChar()
                else -> getPinyinInitial(char)
            }
        }.joinToString("")
        
        return if (initials.startsWith(query.lowercase())) 0.75f else 0f
    }
    
    private fun getPinyinInitial(char: Char): Char {
        // 简化的首字母映射（实际应用需要完整拼音库）
        return when (char.code) {
            in 0x4E00..0x9FA5 -> 'a' // 中文字符返回占位符
            else -> char.lowercaseChar()
        }
    }
    
    private fun getMatchReason(query: String, contact: ContactInfo): String {
        return when {
            contact.name.lowercase().contains(query) -> "名字匹配"
            contact.nickname?.lowercase()?.contains(query) == true -> "昵称匹配"
            contact.remark?.lowercase()?.contains(query) == true -> "备注匹配"
            else -> "模糊匹配"
        }
    }
    
    /**
     * 📊 获取常用联系人推荐
     */
    fun getFrequentContacts(limit: Int = 5): List<String> {
        return contactUsageStats.entries
            .sortedByDescending { it.value.useCount }
            .take(limit)
            .map { it.key }
    }
    
    /**
     * 📈 记录联系人使用
     */
    fun recordContactUsage(contactId: String) {
        val usage = contactUsageStats.getOrPut(contactId) {
            ContactUsage(contactId = contactId)
        }
        contactUsageStats[contactId] = usage.copy(
            useCount = usage.useCount + 1,
            lastUsed = System.currentTimeMillis()
        )
    }
    
    // ==================== 📨 发送流程 ====================
    
    /**
     * 📨 创建待发送消息（预览）
     */
    fun createPendingMessage(
        contact: String,
        message: String,
        app: String = "微信"
    ): PendingMessage {
        val pending = PendingMessage(
            id = "msg_${System.currentTimeMillis()}",
            contact = contact,
            message = message,
            app = app,
            createdAt = System.currentTimeMillis(),
            status = PendingStatus.PREVIEW
        )
        
        _pendingMessage.value = pending
        return pending
    }
    
    /**
     * ✅ 确认发送消息
     */
    fun confirmSend(): Boolean {
        val pending = _pendingMessage.value ?: return false
        _pendingMessage.value = pending.copy(status = PendingStatus.CONFIRMED)
        return true
    }
    
    /**
     * ❌ 取消发送
     */
    fun cancelSend() {
        _pendingMessage.value = null
    }
    
    /**
     * 📊 更新发送状态
     */
    fun updateSendingStatus(status: MessageSendingStatus) {
        _sendingStatus.value = status
    }
    
    /**
     * 📊 获取发送状态描述
     */
    fun getSendingStatusDescription(step: SendingStep): String {
        return when (step) {
            SendingStep.PREPARING -> "准备发送..."
            SendingStep.LAUNCHING_APP -> "正在打开应用..."
            SendingStep.SEARCHING_CONTACT -> "正在搜索联系人..."
            SendingStep.OPENING_CHAT -> "正在打开聊天..."
            SendingStep.INPUTTING_MESSAGE -> "正在输入消息..."
            SendingStep.CLICKING_SEND -> "正在点击发送..."
            SendingStep.VERIFYING -> "验证发送结果..."
            SendingStep.COMPLETED -> "发送完成！"
            SendingStep.FAILED -> "发送失败"
        }
    }
}

// ==================== 📦 数据类定义 ====================

/**
 * 🎯 消息意图类型
 */
enum class MessageIntentType {
    GREETING,       // 问候
    FAREWELL,       // 告别
    QUESTION,       // 问题
    REQUEST,        // 请求
    CONFIRMATION,   // 确认
    REJECTION,      // 拒绝
    GRATITUDE,      // 感谢
    APOLOGY,        // 道歉
    NOTIFICATION,   // 通知
    URGENT,         // 紧急
    STATEMENT       // 陈述
}

/**
 * 🎯 消息意图结果
 */
data class MessageIntentResult(
    val intentType: MessageIntentType,
    val confidence: Float,
    val entities: Map<String, String>,
    val suggestedReplies: List<String>,
    val requiresResponse: Boolean
)

/**
 * 😊 情感类型
 */
enum class Sentiment {
    VERY_POSITIVE, POSITIVE, NEUTRAL, NEGATIVE, VERY_NEGATIVE
}

/**
 * 😊 情绪类型
 */
enum class Emotion {
    HAPPY, SAD, ANGRY, FEARFUL, SURPRISED, LOVING, NEUTRAL
}

/**
 * 😊 情感分析结果
 */
data class SentimentResult(
    val sentiment: Sentiment,
    val score: Float,
    val intensity: Float,
    val emotions: List<Emotion>,
    val confidence: Float
)

/**
 * 🔑 关键词
 */
data class Keyword(
    val word: String,
    val weight: Float,
    val frequency: Int
)

/**
 * 🔑 关键词结果
 */
data class KeywordResult(
    val keywords: List<Keyword>,
    val topics: List<String>,
    val summary: String
)

/**
 * 📋 消息模板
 */
data class MessageTemplate(
    val id: String,
    val name: String,
    val category: String,
    val pattern: String,
    val variables: List<String>
)

/**
 * 📋 模板匹配结果
 */
data class TemplateMatch(
    val template: MessageTemplate,
    val similarity: Float,
    val filledValues: Map<String, String>
)

/**
 * 🤖 自动回复规则
 */
data class AutoReplyRule(
    val name: String,
    val triggers: List<String>,
    val replies: List<String>,
    val positiveReplies: List<String> = emptyList(),
    val negativeReplies: List<String> = emptyList()
)

/**
 * 🤖 自动回复结果
 */
data class AutoReplyResult(
    val reply: String,
    val confidence: Float,
    val matchedRule: String?,
    val reasoning: String
)

/**
 * 💬 回复上下文
 */
data class ReplyContext(
    val previousMessages: List<String> = emptyList(),
    val contactName: String? = null,
    val timeOfDay: String? = null
)

/**
 * 👥 联系人信息
 */
data class ContactInfo(
    val id: String,
    val name: String,
    val nickname: String? = null,
    val remark: String? = null,
    val group: String? = null,
    val avatar: String? = null
)

/**
 * 👥 联系人搜索结果
 */
data class ContactSearchResult(
    val contact: ContactInfo,
    val matchScore: Float,
    val usageScore: Float,
    val totalScore: Float,
    val matchReason: String
)

/**
 * 📊 联系人使用统计
 */
data class ContactUsage(
    val contactId: String,
    val useCount: Int = 0,
    val lastUsed: Long = 0
)

/**
 * 📨 待发送消息
 */
data class PendingMessage(
    val id: String,
    val contact: String,
    val message: String,
    val app: String,
    val createdAt: Long,
    val status: PendingStatus
)

/**
 * 📨 待发送状态
 */
enum class PendingStatus {
    PREVIEW, CONFIRMED, SENDING, SENT, FAILED
}

/**
 * 📊 发送状态
 */
data class MessageSendingStatus(
    val messageId: String,
    val step: SendingStep,
    val progress: Float,
    val error: String? = null
)

/**
 * 📊 发送步骤
 */
enum class SendingStep {
    PREPARING, LAUNCHING_APP, SEARCHING_CONTACT, OPENING_CHAT,
    INPUTTING_MESSAGE, CLICKING_SEND, VERIFYING, COMPLETED, FAILED
}
