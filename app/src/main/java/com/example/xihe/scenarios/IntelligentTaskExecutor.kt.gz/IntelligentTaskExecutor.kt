package com.example.xihe.scenarios

import android.content.Context
import android.content.Intent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.xihe.utils.LogManager
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.core.EnhancedActionExecutor
import com.example.xihe.core.AutomationEngine
import com.example.xihe.core.model.ChatMessageDisplay
import kotlinx.coroutines.delay
import kotlin.random.Random

/**
 * 🧠 智能任务执行器
 * 
 * 根据 TaskStepDefinitions 中定义的步骤执行任务
 * 能够智能识别界面变化并调整执行策略
 */
class IntelligentTaskExecutor(
    private val context: Context
) {
    companion object {
        private const val TAG = "IntelligentTaskExecutor"
        private const val MAX_RETRY = 3
        private const val STEP_TIMEOUT = 10000L
    }
    
    private var currentTask: TaskDefinition? = null
    private var currentStepIndex = 0
    private var taskParameters = mutableMapOf<String, String>()
    private var isRunning = false
    
    /**
     * 🚀 执行任务
     */
    suspend fun executeTask(
        taskType: TaskType,
        appName: String?,
        parameters: Map<String, String>,
        onProgress: (String) -> Unit,
        onComplete: (Boolean, String) -> Unit
    ) {
        val taskDef = TaskStepDefinitions.getTaskDefinition(taskType, appName)
        if (taskDef == null) {
            onComplete(false, "未找到任务定义: $taskType - $appName")
            return
        }
        
        currentTask = taskDef
        taskParameters = parameters.toMutableMap()
        isRunning = true
        currentStepIndex = 0
        
        LogManager.d(TAG, "🚀 开始执行任务: ${taskDef.taskName}")
        LogManager.d(TAG, "📋 共 ${taskDef.steps.size} 个步骤")
        LogManager.d(TAG, "📝 参数: $parameters")
        
        onProgress("开始执行: ${taskDef.taskName}")
        
        try {
            for ((index, step) in taskDef.steps.withIndex()) {
                if (!isRunning) {
                    onComplete(false, "任务被取消")
                    return
                }
                
                currentStepIndex = index
                LogManager.d(TAG, "📌 步骤 ${index + 1}/${taskDef.steps.size}: ${step.description}")
                onProgress("步骤 ${index + 1}: ${step.description}")
                
                val success = executeStep(step, onProgress)
                if (!success) {
                    LogManager.e(TAG, "❌ 步骤失败: ${step.description}")
                    onComplete(false, "步骤失败: ${step.description}")
                    return
                }
                
                delay(300) // 步骤间隔
            }
            
            LogManager.d(TAG, "✅ 任务完成: ${taskDef.taskName}")
            onProgress("任务完成!")
            onComplete(true, "任务执行成功")
            
        } catch (e: Exception) {
            LogManager.e(TAG, "任务执行异常", e)
            onComplete(false, "执行异常: ${e.message}")
        } finally {
            isRunning = false
            currentTask = null
        }
    }
    
    /**
     * 🎯 执行单个步骤
     */
    private suspend fun executeStep(step: TaskStep, onProgress: (String) -> Unit): Boolean {
        val service = CoreAccessibilityService.instance ?: return false
        
        var retryCount = 0
        while (retryCount < MAX_RETRY) {
            try {
                val success = when (step.action) {
                    StepAction.LAUNCH_APP -> executeLaunchApp(step)
                    StepAction.CLICK -> executeClick(step, service)
                    StepAction.CLICK_BY_DESC -> executeClickByDesc(step, service)
                    StepAction.CLICK_EDITABLE -> executeClickEditable(service)
                    StepAction.CLICK_FUZZY -> executeClickFuzzy(step, service)
                    StepAction.CLICK_FIRST_VIDEO -> executeClickFirstVideo(service)
                    StepAction.CLICK_PRODUCT -> executeClickProduct(step, service)
                    StepAction.CLICK_NTH_RESULT -> executeClickNthResult(step, service)
                    StepAction.INPUT_TEXT -> executeInputText(step, service)
                    StepAction.WAIT -> executeWait(step)
                    StepAction.SWIPE_UP -> executeSwipe(service, true)
                    StepAction.SWIPE_DOWN -> executeSwipe(service, false)
                    StepAction.SCROLL_UP -> executeScroll(service, true)
                    StepAction.SCROLL_DOWN -> executeScroll(service, false)
                    StepAction.PRESS_BACK -> executePressBack(service)
                    StepAction.PRESS_ENTER -> executePressEnter(service)
                    StepAction.PRESS_HOME -> executePressHome(service)
                    StepAction.ENSURE_HOME -> executeEnsureHome(step, service)
                    StepAction.CLOSE_POPUP -> executeClosePopup(step, service)
                    StepAction.OPEN_URL -> executeOpenUrl(step)
                    StepAction.VERIFY -> executeVerify(step, service)
                    StepAction.LOOP -> executeLoop(step, onProgress)
                    StepAction.CONDITIONAL -> executeConditional(step, onProgress)
                    StepAction.RANDOM_ACTION -> executeRandomAction(step, onProgress)
                    StepAction.SELECT_SPECIFICATION -> executeSelectSpecification(service)
                    StepAction.REPORT_PROGRESS -> executeReportProgress(step, onProgress)
                    StepAction.ASK_USER_CHOICE -> executeAskUserChoice(step)
                }
                
                if (success) {
                    // 验证预期元素
                    if (step.expectedElements.isNotEmpty()) {
                        delay(500)
                        if (!verifyExpectedElements(step.expectedElements, service)) {
                            LogManager.w(TAG, "⚠️ 预期元素未找到，但步骤可能已成功")
                        }
                    }
                    return true
                }
                
            } catch (e: Exception) {
                LogManager.e(TAG, "步骤执行异常: ${step.description}", e)
            }
            
            // 尝试备用动作
            if (step.fallbackActions.isNotEmpty() && retryCount < step.fallbackActions.size) {
                val fallback = step.fallbackActions[retryCount]
                LogManager.d(TAG, "🔄 尝试备用动作: ${fallback.description}")
                onProgress("尝试: ${fallback.description}")
                
                executeFallbackAction(fallback, service)
                delay(500)
            }
            
            retryCount++
            delay(500)
        }
        
        return false
    }
    
    /**
     * 🚀 启动应用
     */
    private suspend fun executeLaunchApp(step: TaskStep): Boolean {
        val taskDef = currentTask ?: return false
        val packageName = taskDef.appPackage
        
        LogManager.d(TAG, "🚀 启动应用: $packageName")
        
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            delay(3000) // 等待应用启动
            return true
        }
        
        // 尝试备用包名
        for (altPackage in taskDef.alternativePackages) {
            val altIntent = context.packageManager.getLaunchIntentForPackage(altPackage)
            if (altIntent != null) {
                altIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(altIntent)
                delay(3000)
                return true
            }
        }
        
        return false
    }
    
    /**
     * 👆 点击元素
     */
    private suspend fun executeClick(step: TaskStep, service: CoreAccessibilityService): Boolean {
        val rootNode = service.rootInActiveWindow ?: return false
        val targets = resolveParameters(step.targetElements)
        
        for (target in targets) {
            val node = findNodeByText(rootNode, target)
            if (node != null) {
                LogManager.d(TAG, "👆 点击: $target")
                return clickNode(node)
            }
        }
        
        LogManager.w(TAG, "⚠️ 未找到点击目标: $targets")
        return false
    }
    
    /**
     * 👆 通过描述点击
     */
    private suspend fun executeClickByDesc(step: TaskStep, service: CoreAccessibilityService): Boolean {
        val rootNode = service.rootInActiveWindow ?: return false
        val target = step.fallbackActions.firstOrNull()?.parameter as? String ?: return false
        
        val node = findNodeByDescription(rootNode, target)
        if (node != null) {
            return clickNode(node)
        }
        return false
    }
    
    /**
     * 👆 点击可编辑区域
     */
    private suspend fun executeClickEditable(service: CoreAccessibilityService): Boolean {
        val rootNode = service.rootInActiveWindow ?: return false
        val editNode = findEditableNode(rootNode)
        if (editNode != null) {
            return clickNode(editNode)
        }
        return false
    }
    
    /**
     * 👆 模糊点击
     */
    private suspend fun executeClickFuzzy(step: TaskStep, service: CoreAccessibilityService): Boolean {
        val rootNode = service.rootInActiveWindow ?: return false
        val target = resolveParameter(step.targetElements.firstOrNull() ?: "")
        
        val node = findNodeFuzzy(rootNode, target)
        if (node != null) {
            return clickNode(node)
        }
        return false
    }
    
    /**
     * 📹 点击第一个视频
     */
    private suspend fun executeClickFirstVideo(service: CoreAccessibilityService): Boolean {
        val rootNode = service.rootInActiveWindow ?: return false
        
        // 查找视频缩略图或播放按钮
        val videoKeywords = listOf("播放", "视频", "封面", "时长")
        for (keyword in videoKeywords) {
            val node = findClickableNodeWithText(rootNode, keyword)
            if (node != null) {
                return clickNode(node)
            }
        }
        
        // 点击屏幕中间区域的第一个可点击元素
        val clickables = findAllClickableNodes(rootNode)
        if (clickables.isNotEmpty()) {
            return clickNode(clickables.first())
        }
        
        return false
    }
    
    /**
     * 🛒 点击商品
     */
    private suspend fun executeClickProduct(step: TaskStep, service: CoreAccessibilityService): Boolean {
        val rootNode = service.rootInActiveWindow ?: return false
        val index = step.parameters["index"]?.let { resolveParameter(it).toIntOrNull() } ?: 0
        
        // 查找商品列表项
        val products = findProductNodes(rootNode)
        if (products.size > index) {
            return clickNode(products[index])
        }
        
        return products.isNotEmpty() && clickNode(products.first())
    }
    
    /**
     * 🔢 点击第N个搜索结果
     */
    private suspend fun executeClickNthResult(step: TaskStep, service: CoreAccessibilityService): Boolean {
        val rootNode = service.rootInActiveWindow ?: return false
        val index = step.parameters["index"]?.let { resolveParameter(it).toIntOrNull() } ?: 0
        
        val results = findSearchResults(rootNode)
        if (results.size > index) {
            return clickNode(results[index])
        }
        
        return false
    }
    
    /**
     * ⌨️ 输入文本
     */
    private suspend fun executeInputText(step: TaskStep, service: CoreAccessibilityService): Boolean {
        val text = resolveParameter(step.parameters["text"] ?: "")
        val clearFirst = step.parameters["clearFirst"] == "true"
        
        if (text.isEmpty()) return true
        
        val rootNode = service.rootInActiveWindow ?: return false
        val editNode = findEditableNode(rootNode)
        
        if (editNode != null) {
            if (clearFirst) {
                // 清除现有文本
                editNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, android.os.Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
                })
                delay(100)
            }
            
            // 输入新文本
            editNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, android.os.Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            })
            
            LogManager.d(TAG, "⌨️ 已输入: $text")
            return true
        }
        
        return false
    }
    
    /**
     * ⏳ 等待
     */
    private suspend fun executeWait(step: TaskStep): Boolean {
        val duration = step.parameters["duration"]?.toLongOrNull() ?: 1000L
        val random = step.parameters["random"] == "true"
        
        val actualDuration = if (random) {
            duration + Random.nextLong(-duration / 4, duration / 4)
        } else {
            duration
        }
        
        LogManager.d(TAG, "⏳ 等待 ${actualDuration}ms")
        delay(actualDuration)
        return true
    }
    
    /**
     * 👆 滑动
     */
    private suspend fun executeSwipe(service: CoreAccessibilityService, up: Boolean): Boolean {
        val gesture = if (up) {
            android.accessibilityservice.GestureDescription.Builder()
                .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(
                    android.graphics.Path().apply {
                        moveTo(540f, 1500f)
                        lineTo(540f, 500f)
                    },
                    0, 300
                ))
                .build()
        } else {
            android.accessibilityservice.GestureDescription.Builder()
                .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(
                    android.graphics.Path().apply {
                        moveTo(540f, 500f)
                        lineTo(540f, 1500f)
                    },
                    0, 300
                ))
                .build()
        }
        
        service.dispatchGesture(gesture, null, null)
        delay(500)
        return true
    }
    
    /**
     * 📜 滚动
     */
    private suspend fun executeScroll(service: CoreAccessibilityService, up: Boolean): Boolean {
        val rootNode = service.rootInActiveWindow ?: return false
        
        val scrollable = findScrollableNode(rootNode)
        if (scrollable != null) {
            val action = if (up) {
                AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            } else {
                AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            }
            scrollable.performAction(action)
            delay(500)
            return true
        }
        
        // 降级为滑动
        return executeSwipe(service, up)
    }
    
    /**
     * ⬅️ 按返回键
     */
    private suspend fun executePressBack(service: CoreAccessibilityService): Boolean {
        service.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
        delay(500)
        return true
    }
    
    /**
     * ⏎ 按回车键
     */
    private suspend fun executePressEnter(service: CoreAccessibilityService): Boolean {
        val rootNode = service.rootInActiveWindow ?: return false
        val editNode = findEditableNode(rootNode)
        
        if (editNode != null) {
            editNode.performAction(AccessibilityNodeInfo.ACTION_NEXT_AT_MOVEMENT_GRANULARITY)
        }
        
        // 模拟回车键
        val instrumentation = android.app.Instrumentation()
        try {
            instrumentation.sendKeyDownUpSync(android.view.KeyEvent.KEYCODE_ENTER)
        } catch (e: Exception) {
            LogManager.w(TAG, "无法发送回车键", e)
        }
        
        return true
    }
    
    /**
     * 🏠 按Home键
     */
    private suspend fun executePressHome(service: CoreAccessibilityService): Boolean {
        service.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME)
        delay(500)
        return true
    }
    
    /**
     * 🏠 确保在主界面
     */
    private suspend fun executeEnsureHome(step: TaskStep, service: CoreAccessibilityService): Boolean {
        for (i in 1..3) {
            val rootNode = service.rootInActiveWindow ?: continue
            
            // 检查是否需要返回
            var needBack = false
            for (condition in step.checkConditions) {
                if (condition.triggerFallback) {
                    val found = findNodeByText(rootNode, condition.value) != null
                    if (found) {
                        needBack = true
                        break
                    }
                }
            }
            
            if (needBack) {
                LogManager.d(TAG, "📱 检测到需要返回，按返回键")
                executePressBack(service)
                delay(500)
            } else {
                return true
            }
        }
        return true
    }
    
    /**
     * ❌ 关闭弹窗
     */
    private suspend fun executeClosePopup(step: TaskStep, service: CoreAccessibilityService): Boolean {
        val rootNode = service.rootInActiveWindow ?: return true
        val closeKeywords = step.targetElements.ifEmpty { listOf("关闭", "×", "跳过", "我知道了", "取消") }
        
        for (keyword in closeKeywords) {
            val node = findNodeByText(rootNode, keyword)
            if (node != null && node.isClickable) {
                clickNode(node)
                delay(300)
                return true
            }
        }
        
        return true // 没有弹窗也算成功
    }
    
    /**
     * 🌐 打开URL
     */
    private suspend fun executeOpenUrl(step: TaskStep): Boolean {
        val url = step.fallbackActions.firstOrNull()?.parameter as? String ?: return false
        
        val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        delay(3000)
        return true
    }
    
    /**
     * ✅ 验证
     */
    private suspend fun executeVerify(step: TaskStep, service: CoreAccessibilityService): Boolean {
        val rootNode = service.rootInActiveWindow ?: return false
        
        for (condition in step.checkConditions) {
            val value = resolveParameter(condition.value)
            val found = findNodeByText(rootNode, value) != null
            
            if (!found && condition.type == ConditionType.CONTAINS_TEXT) {
                LogManager.w(TAG, "⚠️ 验证失败: 未找到 '$value'")
                return false
            }
        }
        
        return true
    }
    
    /**
     * 🔄 循环执行
     */
    private suspend fun executeLoop(step: TaskStep, onProgress: (String) -> Unit): Boolean {
        val count = step.parameters["count"]?.let { resolveParameter(it).toIntOrNull() } ?: 1
        val variable = step.parameters["variable"] ?: "i"
        
        LogManager.d(TAG, "🔄 开始循环，共 $count 次")
        
        for (i in 1..count) {
            taskParameters[variable] = i.toString()
            
            for (subStep in step.subSteps) {
                val success = executeStep(subStep, onProgress)
                if (!success) {
                    LogManager.w(TAG, "⚠️ 循环步骤失败，继续下一轮")
                    break
                }
            }
            
            if (!isRunning) break
        }
        
        return true
    }
    
    /**
     * ❓ 条件执行
     */
    private suspend fun executeConditional(step: TaskStep, onProgress: (String) -> Unit): Boolean {
        var shouldExecute = true
        
        for (condition in step.checkConditions) {
            val value = resolveParameter(condition.value)
            
            shouldExecute = when (condition.type) {
                ConditionType.NOT_EMPTY -> value.isNotEmpty()
                ConditionType.EQUALS -> value == condition.name
                else -> true
            }
            
            if (!shouldExecute) break
        }
        
        if (shouldExecute) {
            for (subStep in step.subSteps) {
                executeStep(subStep, onProgress)
            }
        }
        
        return true
    }
    
    /**
     * 🎲 随机动作
     */
    private suspend fun executeRandomAction(step: TaskStep, onProgress: (String) -> Unit): Boolean {
        val probability = step.parameters["probability"]?.toFloatOrNull() ?: 0.5f
        
        if (Random.nextFloat() < probability && step.subSteps.isNotEmpty()) {
            val randomStep = step.subSteps.random()
            executeStep(randomStep, onProgress)
        }
        
        return true
    }
    
    /**
     * 📦 选择规格
     */
    private suspend fun executeSelectSpecification(service: CoreAccessibilityService): Boolean {
        val rootNode = service.rootInActiveWindow ?: return true
        
        // 查找规格选项
        val specKeywords = listOf("颜色", "尺码", "规格", "型号")
        for (keyword in specKeywords) {
            val node = findClickableNodeWithText(rootNode, keyword)
            if (node != null) {
                clickNode(node)
                delay(300)
                
                // 点击第一个可选项
                val options = findAllClickableNodes(service.rootInActiveWindow ?: return true)
                if (options.isNotEmpty()) {
                    clickNode(options.first())
                    delay(300)
                }
            }
        }
        
        return true
    }
    
    /**
     * 📊 报告进度
     */
    private suspend fun executeReportProgress(step: TaskStep, onProgress: (String) -> Unit): Boolean {
        val message = resolveParameter(step.parameters["message"] ?: "")
        onProgress(message)
        LogManager.d(TAG, "📊 进度: $message")
        return true
    }
    
    /**
     * ❓ 询问用户选择
     */
    private suspend fun executeAskUserChoice(step: TaskStep): Boolean {
        AutomationEngine.addMessage(ChatMessageDisplay(
            content = "需要您的帮助：请选择正确的选项",
            isUser = false
        ))
        delay(5000) // 等待用户操作
        return true
    }
    
    /**
     * 执行备用动作
     */
    private suspend fun executeFallbackAction(fallback: FallbackAction, service: CoreAccessibilityService) {
        when (fallback.action) {
            StepAction.WAIT -> delay((fallback.parameter as? Int)?.toLong() ?: 1000L)
            StepAction.PRESS_BACK -> executePressBack(service)
            StepAction.CLICK -> {
                val target = fallback.parameter as? String ?: return
                val rootNode = service.rootInActiveWindow ?: return
                val node = findNodeByText(rootNode, target)
                if (node != null) clickNode(node)
            }
            StepAction.SCROLL_UP -> executeScroll(service, true)
            StepAction.LAUNCH_APP -> currentTask?.let { executeLaunchApp(TaskStep("", "", StepAction.LAUNCH_APP)) }
            else -> {}
        }
    }
    
    // ==================== 🔍 辅助方法 ====================
    
    private fun resolveParameter(param: String): String {
        var result = param
        for ((key, value) in taskParameters) {
            result = result.replace("{$key}", value)
        }
        return result
    }
    
    private fun resolveParameters(params: List<String>): List<String> {
        return params.map { resolveParameter(it) }
    }
    
    private fun findNodeByText(node: AccessibilityNodeInfo, text: String): AccessibilityNodeInfo? {
        val nodeText = node.text?.toString() ?: ""
        val nodeDesc = node.contentDescription?.toString() ?: ""
        
        if (nodeText.contains(text, ignoreCase = true) || nodeDesc.contains(text, ignoreCase = true)) {
            return node
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findNodeByText(child, text)?.let { return it }
        }
        
        return null
    }
    
    private fun findNodeByDescription(node: AccessibilityNodeInfo, desc: String): AccessibilityNodeInfo? {
        val nodeDesc = node.contentDescription?.toString() ?: ""
        if (nodeDesc.contains(desc, ignoreCase = true)) {
            return node
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findNodeByDescription(child, desc)?.let { return it }
        }
        
        return null
    }
    
    private fun findNodeFuzzy(node: AccessibilityNodeInfo, target: String): AccessibilityNodeInfo? {
        val nodeText = node.text?.toString() ?: ""
        
        // 计算相似度
        if (nodeText.isNotEmpty() && calculateSimilarity(nodeText, target) > 0.5) {
            return node
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findNodeFuzzy(child, target)?.let { return it }
        }
        
        return null
    }
    
    private fun findEditableNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable) return node
        
        val className = node.className?.toString() ?: ""
        if (className.contains("EditText") || className.contains("TextField")) {
            return node
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findEditableNode(child)?.let { return it }
        }
        
        return null
    }
    
    private fun findScrollableNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable) return node
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findScrollableNode(child)?.let { return it }
        }
        
        return null
    }
    
    private fun findClickableNodeWithText(node: AccessibilityNodeInfo, text: String): AccessibilityNodeInfo? {
        val nodeText = node.text?.toString() ?: ""
        val nodeDesc = node.contentDescription?.toString() ?: ""
        
        if (node.isClickable && (nodeText.contains(text) || nodeDesc.contains(text))) {
            return node
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findClickableNodeWithText(child, text)?.let { return it }
        }
        
        return null
    }
    
    private fun findAllClickableNodes(node: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val result = mutableListOf<AccessibilityNodeInfo>()
        
        if (node.isClickable) {
            result.add(node)
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            result.addAll(findAllClickableNodes(child))
        }
        
        return result
    }
    
    private fun findProductNodes(node: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val products = mutableListOf<AccessibilityNodeInfo>()
        
        // 查找包含价格信息的可点击节点
        if (node.isClickable) {
            val text = node.text?.toString() ?: ""
            if (text.contains("¥") || text.contains("￥") || text.contains("元")) {
                products.add(node)
            }
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            products.addAll(findProductNodes(child))
        }
        
        return products
    }
    
    private fun findSearchResults(node: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val results = mutableListOf<AccessibilityNodeInfo>()
        
        if (node.isClickable && node.text?.toString()?.isNotEmpty() == true) {
            results.add(node)
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            results.addAll(findSearchResults(child))
        }
        
        return results
    }
    
    private fun clickNode(node: AccessibilityNodeInfo): Boolean {
        if (node.isClickable) {
            return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        
        // 尝试点击父节点
        var parent = node.parent
        while (parent != null) {
            if (parent.isClickable) {
                return parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            parent = parent.parent
        }
        
        return false
    }
    
    private fun verifyExpectedElements(elements: List<String>, service: CoreAccessibilityService): Boolean {
        val rootNode = service.rootInActiveWindow ?: return false
        val resolved = resolveParameters(elements)
        
        for (element in resolved) {
            if (findNodeByText(rootNode, element) != null) {
                return true
            }
        }
        
        return false
    }
    
    private fun calculateSimilarity(s1: String, s2: String): Float {
        val longer = if (s1.length > s2.length) s1 else s2
        val shorter = if (s1.length > s2.length) s2 else s1
        
        if (longer.isEmpty()) return 1.0f
        
        val editDistance = levenshteinDistance(longer, shorter)
        return (longer.length - editDistance).toFloat() / longer.length
    }
    
    private fun levenshteinDistance(s1: String, s2: String): Int {
        val dp = Array(s1.length + 1) { IntArray(s2.length + 1) }
        
        for (i in 0..s1.length) dp[i][0] = i
        for (j in 0..s2.length) dp[0][j] = j
        
        for (i in 1..s1.length) {
            for (j in 1..s2.length) {
                val cost = if (s1[i - 1] == s2[j - 1]) 0 else 1
                dp[i][j] = minOf(
                    dp[i - 1][j] + 1,
                    dp[i][j - 1] + 1,
                    dp[i - 1][j - 1] + cost
                )
            }
        }
        
        return dp[s1.length][s2.length]
    }
    
    /**
     * 停止任务
     */
    fun stopTask() {
        isRunning = false
        LogManager.d(TAG, "⏹️ 任务已停止")
    }
}
