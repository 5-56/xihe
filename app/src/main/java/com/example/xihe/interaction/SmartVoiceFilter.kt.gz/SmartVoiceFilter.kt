package com.example.xihe.interaction

import android.content.Context
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * 🎤 智能语音过滤器
 * 
 * 功能：
 * 1. 区分用户语音和系统播报声音
 * 2. 过滤媒体播放声音（视频、音乐等）
 * 3. 智能回声检测和过滤
 * 4. 基于上下文的语音识别过滤
 * 
 * 核心策略：
 * - 时间窗口过滤：TTS播报期间和之后的短时间内忽略识别结果
 * - 内容匹配过滤：检测识别结果是否与最近播报内容相似
 * - 音频状态过滤：检测系统是否有媒体播放
 * - 语义分析过滤：分析识别结果是否像用户指令
 */
class SmartVoiceFilter(private val context: Context) {
    
    companion object {
        private const val TAG = "SmartVoiceFilter"
        
        // 单例实例
        @Volatile
        private var instance: SmartVoiceFilter? = null
        
        fun getInstance(context: Context): SmartVoiceFilter {
            return instance ?: synchronized(this) {
                instance ?: SmartVoiceFilter(context.applicationContext).also { instance = it }
            }
        }
    }
    
    // 过滤状态
    private val _filterState = MutableStateFlow(FilterState())
    val filterState = _filterState.asStateFlow()
    
    // 播报历史（用于回声检测）
    private val spokenHistory = mutableListOf<SpokenRecord>()
    private val MAX_HISTORY_SIZE = 10
    private val HISTORY_EXPIRE_MS = 30000L  // 30秒后过期
    
    // 音频播放监控
    private val audioMonitor by lazy { AudioPlaybackMonitor.getInstance(context) }
    
    // 用户指令关键词（这些词通常表示用户在说话）
    private val userCommandKeywords = setOf(
        // 唤醒词
        "羲和", "小羲", "嘿羲和", "你好羲和",
        // 动作指令
        "打开", "关闭", "播放", "暂停", "停止", "开始",
        "查询", "搜索", "找", "显示", "隐藏",
        "设置", "调整", "修改", "取消", "确认",
        "返回", "退出", "下一个", "上一个",
        // 疑问词
        "什么", "怎么", "为什么", "哪里", "哪个", "谁",
        "多少", "几点", "什么时候",
        // 请求词
        "帮我", "请", "能不能", "可以", "麻烦"
    )
    
    // 系统播报特征词（这些词通常出现在AI回复中）
    private val systemResponsePatterns = setOf(
        "主人", "好的", "正在", "已经", "完成",
        "为您", "帮您", "给您", "让我",
        "请稍等", "马上", "立即"
    )
    
    // 🆕 实时对话模式标志（在此模式下放宽过滤条件）
    private var isRealTimeMode = false
    private var interruptBypassUntil = 0L
    
    /**
     * 🔄 设置实时对话模式
     * 在实时对话模式下，放宽过滤条件，优先响应用户
     */
    fun setRealTimeMode(enabled: Boolean) {
        isRealTimeMode = enabled
        LogManager.d(TAG, "🔄 实时对话模式: ${if (enabled) "开启" else "关闭"}")
    }
    
    /**
     * 🎤 过滤语音识别结果
     * 
     * @param text 识别到的文本
     * @param timestamp 识别时间戳
     * @return FilterResult 过滤结果
     */
    fun filterVoiceInput(text: String, timestamp: Long = System.currentTimeMillis()): FilterResult {
        // 清理过期的历史记录
        cleanExpiredHistory(timestamp)
        
        val state = _filterState.value
        
        // 1. 检查是否在TTS播报期间
        if (state.isTTSSpeaking) {
            LogManager.d(TAG, "🔇 过滤：TTS正在播报中")
            return FilterResult(
                shouldFilter = true,
                reason = FilterReason.TTS_SPEAKING,
                originalText = text
            )
        }
        
        // 2. 检查TTS冷却期 - 🆕 实时模式下延长冷却时间
        val effectiveCooldown = if (isRealTimeMode) {
            maxOf(state.ttsCooldownMs, 2000L)  // 🆕 实时模式延长到2秒，确保不会识别到播报声音
        } else {
            state.ttsCooldownMs
        }
        val timeSinceTTS = timestamp - state.lastTTSEndTime
        if (state.lastTTSEndTime > 0 && timeSinceTTS < effectiveCooldown) {
            LogManager.d(TAG, "🔇 过滤：TTS冷却期 (${timeSinceTTS}ms < ${effectiveCooldown}ms)")
            return FilterResult(
                shouldFilter = true,
                reason = FilterReason.TTS_COOLDOWN,
                originalText = text
            )
        }

        // 3. 🆕 实时对话模式下，严格检查音频播放状态（包括视频、音乐等）
        val audioStatus = audioMonitor.getAudioStatusSummary()
        if (isRealTimeMode) {
            // 🆕 实时模式：只要检测到任何音频播放，就过滤掉
            if (!audioStatus.isSafeForVoiceRecognition()) {
                val reason = audioStatus.getFilterReason()
                LogManager.d(TAG, "🔇 [实时对话] 过滤：$reason")
                return FilterResult(
                    shouldFilter = true,
                    reason = FilterReason.MEDIA_PLAYING,
                    originalText = text
                )
            }
        } else {
            // 普通模式：保持原有逻辑
            if (!audioStatus.isSafeForVoiceRecognition()) {
                val reason = audioStatus.getFilterReason()
                LogManager.d(TAG, "🔇 过滤：$reason")
                return FilterResult(
                    shouldFilter = true,
                    reason = FilterReason.MEDIA_PLAYING,
                    originalText = text
                )
            }
        }

        // 4. 🆕 实时模式下，提高回声检测阈值
        val echoThreshold = if (isRealTimeMode) 0.6 else 0.5  // 实时模式更严格
        val echoMatch = findEchoMatch(text, timestamp, echoThreshold)
        
        // 5. 用户指令关键词检查
        val isLikelyUserCommand = isLikelyUserCommand(text)
        
        // 🆕 实时模式下：即使是用户指令，如果命中回声也要过滤
        if (isRealTimeMode && echoMatch != null) {
            LogManager.d(TAG, "🔇 [实时对话] 过滤：检测到回声 (相似度: ${String.format("%.1f", echoMatch.similarity * 100)}%)")
            return FilterResult(
                shouldFilter = true,
                reason = FilterReason.ECHO_DETECTED,
                originalText = text,
                matchedSpoken = echoMatch.spokenText
            )
        }
        
        // 普通模式：用户指令关键词优先通过
        if (isLikelyUserCommand && echoMatch == null) {
            LogManager.d(TAG, "✅ 检测到用户指令关键词，优先通过：$text")
            return FilterResult(
                shouldFilter = false,
                reason = FilterReason.PASSED,
                originalText = text
            )
        }
        
        // 6. 检查回声（普通模式）
        if (echoMatch != null) {
            LogManager.d(TAG, "🔇 过滤：检测到回声 (相似度: ${String.format("%.1f", echoMatch.similarity * 100)}%)")
            return FilterResult(
                shouldFilter = true,
                reason = FilterReason.ECHO_DETECTED,
                originalText = text,
                matchedSpoken = echoMatch.spokenText
            )
        }
        
        // 7. 检查文本长度
        val minLength = if (isRealTimeMode) 2 else 3  // 🆕 实时模式最少2个字
        if (text.length < minLength) {
            LogManager.d(TAG, "🔇 过滤：文本过短 (${text.length} < $minLength)")
            return FilterResult(
                shouldFilter = true,
                reason = FilterReason.TOO_SHORT,
                originalText = text
            )
        }
        
        // 8. 🆕 实时模式下，也检查是否像系统播报
        if (isLikelySystemResponse(text)) {
            LogManager.d(TAG, "🔇 ${if (isRealTimeMode) "[实时对话] " else ""}过滤：疑似系统播报内容")
            return FilterResult(
                shouldFilter = true,
                reason = FilterReason.SYSTEM_RESPONSE_PATTERN,
                originalText = text
            )
        }
        
        // 通过所有过滤，允许处理
        LogManager.d(TAG, "✅ ${if (isRealTimeMode) "[实时对话] " else ""}通过过滤：$text")
        return FilterResult(
            shouldFilter = false,
            reason = FilterReason.PASSED,
            originalText = text
        )
    }
    
    /**
     * 📝 记录TTS播报内容
     */
    fun recordSpokenText(text: String, timestamp: Long = System.currentTimeMillis()) {
        spokenHistory.add(0, SpokenRecord(text, timestamp))
        
        // 保持历史记录在限制范围内
        while (spokenHistory.size > MAX_HISTORY_SIZE) {
            spokenHistory.removeAt(spokenHistory.size - 1)
        }
        
        LogManager.d(TAG, "📝 记录播报: ${text.take(30)}...")
    }
    
    /**
     * 🔊 更新TTS状态
     */
    fun updateTTSState(isSpeaking: Boolean, timestamp: Long = System.currentTimeMillis()) {
        _filterState.value = _filterState.value.copy(
            isTTSSpeaking = isSpeaking,
            lastTTSEndTime = if (!isSpeaking) timestamp else _filterState.value.lastTTSEndTime
        )
    }
    
    /**
     * ⏱️ 设置TTS冷却时间
     */
    fun setTTSCooldown(cooldownMs: Long) {
        _filterState.value = _filterState.value.copy(ttsCooldownMs = cooldownMs)
    }
    
    /**
     * 🧹 清除历史记录
     */
    fun clearHistory() {
        spokenHistory.clear()
        LogManager.d(TAG, "🧹 已清除播报历史")
    }
    
    // ==================== 私有方法 ====================
    
    /**
     * 清理过期的历史记录
     */
    private fun cleanExpiredHistory(currentTime: Long) {
        spokenHistory.removeAll { record ->
            currentTime - record.timestamp > HISTORY_EXPIRE_MS
        }
    }
    
    /**
     * 查找回声匹配
     * @param threshold 相似度阈值，默认0.5（50%）
     */
    private fun findEchoMatch(text: String, timestamp: Long, threshold: Double = 0.5): EchoMatch? {
        val normalizedInput = text.replace(" ", "").lowercase()
        if (normalizedInput.isBlank()) return null
        
        for (record in spokenHistory) {
            if (timestamp - record.timestamp > 8000L) continue
            val normalizedSpoken = record.text.replace(" ", "").lowercase()
            if (normalizedSpoken.isBlank()) continue
            
            // 完全匹配
            if (normalizedInput == normalizedSpoken) {
                return EchoMatch(record.text, 1.0)
            }
            
            // 部分匹配
            if (normalizedInput.length >= 3) {
                val containsMatch = normalizedSpoken.contains(normalizedInput) || normalizedInput.contains(normalizedSpoken)
                if (containsMatch) {
                    val containRatio = minOf(normalizedInput.length, normalizedSpoken.length).toDouble() /
                        maxOf(normalizedInput.length, normalizedSpoken.length).toDouble()
                    if (containRatio >= threshold) {
                        return EchoMatch(record.text, containRatio)
                    }
                }
            }

            if (normalizedInput.length >= 4) {
                val similarity = calculateSimilarity(normalizedInput, normalizedSpoken)
                if (similarity >= threshold) {
                    return EchoMatch(record.text, similarity)
                }
            }
        }
        
        return null
    }
    
    /**
     * 计算字符串相似度
     */
    private fun calculateSimilarity(s1: String, s2: String): Double {
        if (s1.isEmpty() || s2.isEmpty()) return 0.0
        
        // 使用字符集合的Jaccard相似度
        val set1 = s1.toSet()
        val set2 = s2.toSet()
        
        val intersection = set1.intersect(set2).size
        val union = set1.union(set2).size
        
        return if (union > 0) intersection.toDouble() / union else 0.0
    }
    
    /**
     * 判断是否像用户指令
     */
    private fun isLikelyUserCommand(text: String): Boolean {
        val normalizedText = text.replace(" ", "").lowercase()
        return userCommandKeywords.any { keyword ->
            normalizedText.contains(keyword.lowercase())
        }
    }
    
    /**
     * 判断是否像系统播报
     */
    private fun isLikelySystemResponse(text: String): Boolean {
        val normalizedText = text.replace(" ", "").lowercase()
        
        // 检查是否包含多个系统播报特征词
        val matchCount = systemResponsePatterns.count { pattern ->
            normalizedText.contains(pattern.lowercase())
        }
        
        return matchCount >= 2  // 包含2个以上特征词才认为是系统播报
    }
    
    // ==================== 数据类 ====================
    
    /**
     * 过滤状态
     */
    data class FilterState(
        val isTTSSpeaking: Boolean = false,
        val lastTTSEndTime: Long = 0,
        val ttsCooldownMs: Long = 2500L  // 🆕 默认2.5秒冷却（延长以减少回声）
    )
    
    /**
     * 播报记录
     */
    data class SpokenRecord(
        val text: String,
        val timestamp: Long
    )
    
    /**
     * 回声匹配结果
     */
    data class EchoMatch(
        val spokenText: String,
        val similarity: Double
    )
    
    /**
     * 过滤原因
     */
    enum class FilterReason {
        PASSED,                    // 通过过滤
        TTS_SPEAKING,              // TTS正在播报
        TTS_COOLDOWN,              // TTS冷却期
        ECHO_DETECTED,             // 检测到回声
        MEDIA_PLAYING,             // 媒体播放中
        TOO_SHORT,                 // 文本过短
        SYSTEM_RESPONSE_PATTERN    // 系统播报模式
    }
    
    /**
     * 过滤结果
     */
    data class FilterResult(
        val shouldFilter: Boolean,
        val reason: FilterReason,
        val originalText: String,
        val matchedSpoken: String? = null
    ) {
        fun getReasonDescription(): String {
            return when (reason) {
                FilterReason.PASSED -> "通过"
                FilterReason.TTS_SPEAKING -> "TTS正在播报"
                FilterReason.TTS_COOLDOWN -> "TTS冷却期"
                FilterReason.ECHO_DETECTED -> "检测到回声"
                FilterReason.MEDIA_PLAYING -> "媒体播放中"
                FilterReason.TOO_SHORT -> "文本过短"
                FilterReason.SYSTEM_RESPONSE_PATTERN -> "疑似系统播报"
            }
        }
    }
}
