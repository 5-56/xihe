package com.example.xihe.interaction

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.File
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * 🔐 声纹识别管理器
 * 
 * 实现用户声纹注册和验证，只响应授权用户的唤醒词
 */
object VoiceprintManager {
    
    private const val TAG = "VoiceprintManager"
    
    // 音频参数
    private const val SAMPLE_RATE = 16000
    private const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
    private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
    private const val RECORD_DURATION_MS = 3000L // 录制3秒
    private const val MIN_SAMPLES_FOR_ENROLLMENT = 3 // 至少录制3个样本
    
    // 声纹特征维度
    private const val FEATURE_DIMENSION = 64
    
    // 验证阈值
    private const val VERIFICATION_THRESHOLD = 0.65f
    private const val HIGH_CONFIDENCE_THRESHOLD = 0.80f
    
    // 状态
    private val _state = MutableStateFlow(VoiceprintState.IDLE)
    val state: StateFlow<VoiceprintState> = _state.asStateFlow()
    
    private val _enrollmentProgress = MutableStateFlow(0f)
    val enrollmentProgress: StateFlow<Float> = _enrollmentProgress.asStateFlow()
    
    // 已注册的声纹
    private val enrolledVoiceprints = mutableListOf<VoiceprintProfile>()
    
    // 当前用户
    private var currentUserId: String? = null
    
    // 配置
    private var config = VoiceprintConfig()
    private var context: Context? = null
    
    // 协程作用域
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    
    // 临时录音数据
    private val enrollmentSamples = mutableListOf<FloatArray>()
    
    /**
     * 🎯 初始化
     */
    fun initialize(context: Context, config: VoiceprintConfig = VoiceprintConfig()) {
        this.context = context
        this.config = config
        
        // 加载已保存的声纹
        loadVoiceprints()
        
        LogManager.i(TAG, "🔐 声纹管理器初始化完成，已注册用户数: ${enrolledVoiceprints.size}")
    }
    
    /**
     * 🎤 开始录制声纹样本（注册流程）
     */
    fun startEnrollment(userId: String, userName: String, onProgress: (Int, Int) -> Unit, onComplete: (Boolean, String) -> Unit) {
        if (_state.value != VoiceprintState.IDLE) {
            onComplete(false, "声纹管理器正忙")
            return
        }
        
        currentUserId = userId
        enrollmentSamples.clear()
        _enrollmentProgress.value = 0f
        _state.value = VoiceprintState.ENROLLING
        
        scope.launch {
            try {
                repeat(MIN_SAMPLES_FOR_ENROLLMENT) { index ->
                    LogManager.d(TAG, "🎤 录制样本 ${index + 1}/$MIN_SAMPLES_FOR_ENROLLMENT...")
                    withContext(Dispatchers.Main) {
                        onProgress(index + 1, MIN_SAMPLES_FOR_ENROLLMENT)
                    }
                    
                    // 录制音频
                    val audioData = recordAudioSample()
                    if (audioData != null) {
                        // 提取特征
                        val features = extractFeatures(audioData)
                        enrollmentSamples.add(features)
                        _enrollmentProgress.value = (index + 1).toFloat() / MIN_SAMPLES_FOR_ENROLLMENT
                    }
                    
                    // 间隔1秒
                    delay(1000)
                }
                
                // 生成声纹模板
                if (enrollmentSamples.size >= MIN_SAMPLES_FOR_ENROLLMENT) {
                    val template = createVoiceprintTemplate(enrollmentSamples)
                    val profile = VoiceprintProfile(
                        userId = userId,
                        userName = userName,
                        template = template,
                        createdAt = System.currentTimeMillis(),
                        sampleCount = enrollmentSamples.size
                    )
                    
                    // 保存声纹
                    enrolledVoiceprints.removeAll { it.userId == userId } // 移除旧的
                    enrolledVoiceprints.add(profile)
                    saveVoiceprints()
                    
                    _state.value = VoiceprintState.IDLE
                    withContext(Dispatchers.Main) {
                        onComplete(true, "声纹注册成功！")
                    }
                } else {
                    _state.value = VoiceprintState.IDLE
                    withContext(Dispatchers.Main) {
                        onComplete(false, "录制样本不足，请重试")
                    }
                }
            } catch (e: Exception) {
                LogManager.e(TAG, "声纹注册失败", e)
                _state.value = VoiceprintState.IDLE
                withContext(Dispatchers.Main) {
                    onComplete(false, "注册失败: ${e.message}")
                }
            }
        }
    }
    
    /**
     * 🔍 验证声纹（快速验证唤醒词说话人）
     */
    suspend fun verifyVoiceprint(audioData: ShortArray): VoiceprintResult {
        if (enrolledVoiceprints.isEmpty()) {
            LogManager.d(TAG, "📝 无已注册声纹，跳过验证")
            return VoiceprintResult(true, null, 1.0f, "无注册用户，默认通过")
        }
        
        if (!config.enabled) {
            return VoiceprintResult(true, null, 1.0f, "声纹验证已禁用")
        }
        
        _state.value = VoiceprintState.VERIFYING
        
        try {
            // 提取特征
            val features = extractFeatures(audioData)
            
            // 与所有已注册声纹比对
            var bestMatch: VoiceprintProfile? = null
            var bestScore = 0f
            
            for (profile in enrolledVoiceprints) {
                val score = compareVoiceprints(features, profile.template)
                LogManager.d(TAG, "🔍 与 ${profile.userName} 比对分数: $score")
                
                if (score > bestScore) {
                    bestScore = score
                    bestMatch = profile
                }
            }
            
            _state.value = VoiceprintState.IDLE
            
            val isVerified = bestScore >= VERIFICATION_THRESHOLD
            val confidence = when {
                bestScore >= HIGH_CONFIDENCE_THRESHOLD -> "高置信度"
                bestScore >= VERIFICATION_THRESHOLD -> "中置信度"
                else -> "低置信度"
            }
            
            return if (isVerified && bestMatch != null) {
                LogManager.i(TAG, "✅ 声纹验证通过: ${bestMatch.userName}, 分数: $bestScore")
                VoiceprintResult(true, bestMatch.userId, bestScore, "验证通过 ($confidence)")
            } else {
                LogManager.w(TAG, "❌ 声纹验证失败, 最高分数: $bestScore")
                VoiceprintResult(false, null, bestScore, "未识别的用户")
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "声纹验证失败", e)
            _state.value = VoiceprintState.IDLE
            return VoiceprintResult(false, null, 0f, "验证出错: ${e.message}")
        }
    }
    
    /**
     * 🔍 快速验证（从音频缓冲区）
     */
    fun verifyFromBuffer(audioBuffer: ShortArray, onResult: (VoiceprintResult) -> Unit) {
        scope.launch {
            val result = verifyVoiceprint(audioBuffer)
            withContext(Dispatchers.Main) {
                onResult(result)
            }
        }
    }
    
    /**
     * 🗑️ 删除声纹
     */
    fun deleteVoiceprint(userId: String): Boolean {
        val removed = enrolledVoiceprints.removeAll { it.userId == userId }
        if (removed) {
            saveVoiceprints()
            LogManager.i(TAG, "🗑️ 已删除用户声纹: $userId")
        }
        return removed
    }
    
    /**
     * 📋 获取已注册用户列表
     */
    fun getEnrolledUsers(): List<VoiceprintUserInfo> {
        return enrolledVoiceprints.map {
            VoiceprintUserInfo(
                userId = it.userId,
                userName = it.userName,
                createdAt = it.createdAt,
                sampleCount = it.sampleCount
            )
        }
    }
    
    /**
     * ⚙️ 更新配置
     */
    fun updateConfig(newConfig: VoiceprintConfig) {
        config = newConfig
        LogManager.d(TAG, "⚙️ 声纹配置已更新: enabled=${config.enabled}")
    }
    
    /**
     * 🎤 录制音频样本
     * 🔇 优化：使用 VOICE_COMMUNICATION 音频源，自动启用硬件回声消除
     */
    private suspend fun recordAudioSample(): ShortArray? = withContext(Dispatchers.IO) {
        try {
            val bufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT)
            
            // 🔇 优先使用 VOICE_COMMUNICATION 音频源
            // VOICE_COMMUNICATION 自动启用回声消除(AEC)、噪音抑制(NS)、自动增益控制(AGC)
            val audioRecord = try {
                AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                    SAMPLE_RATE,
                    CHANNEL_CONFIG,
                    AUDIO_FORMAT,
                    bufferSize * 2
                )
            } catch (e: Exception) {
                LogManager.w(TAG, "⚠️ VOICE_COMMUNICATION 不可用，回退到 MIC", e)
                AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    SAMPLE_RATE,
                    CHANNEL_CONFIG,
                    AUDIO_FORMAT,
                    bufferSize * 2
                )
            }
            
            val samples = mutableListOf<Short>()
            val buffer = ShortArray(bufferSize)
            val recordDurationSamples = (SAMPLE_RATE * RECORD_DURATION_MS / 1000).toInt()
            
            audioRecord.startRecording()
            
            while (samples.size < recordDurationSamples) {
                val read = audioRecord.read(buffer, 0, buffer.size)
                if (read > 0) {
                    samples.addAll(buffer.take(read).toList())
                }
            }
            
            audioRecord.stop()
            audioRecord.release()
            
            LogManager.d(TAG, "🎤 录制完成, 样本数: ${samples.size}")
            samples.toShortArray()
        } catch (e: Exception) {
            LogManager.e(TAG, "录音失败", e)
            null
        }
    }
    
    /**
     * 🔬 提取声纹特征
     * 使用简化的MFCC + 统计特征
     */
    private fun extractFeatures(audioData: ShortArray): FloatArray {
        val features = FloatArray(FEATURE_DIMENSION)
        
        // 转换为浮点数并归一化
        val floatData = audioData.map { it.toFloat() / 32768f }.toFloatArray()
        
        // 分帧处理
        val frameSize = 512
        val hopSize = 256
        val numFrames = (floatData.size - frameSize) / hopSize
        
        if (numFrames <= 0) {
            return features
        }
        
        // 计算每帧的特征
        val frameEnergies = mutableListOf<Float>()
        val frameZCRs = mutableListOf<Float>()
        val framePitches = mutableListOf<Float>()
        
        for (i in 0 until numFrames) {
            val start = i * hopSize
            val frame = floatData.slice(start until start + frameSize).toFloatArray()
            
            // 能量
            val energy = frame.map { it * it }.sum()
            frameEnergies.add(energy)
            
            // 过零率
            var zcr = 0f
            for (j in 1 until frame.size) {
                if ((frame[j] >= 0 && frame[j - 1] < 0) || (frame[j] < 0 && frame[j - 1] >= 0)) {
                    zcr += 1
                }
            }
            frameZCRs.add(zcr / frame.size)
            
            // 简单的基频估计
            val pitch = estimatePitch(frame, SAMPLE_RATE)
            framePitches.add(pitch)
        }
        
        // 统计特征
        var idx = 0
        
        // 能量统计 (8个特征)
        features[idx++] = frameEnergies.average().toFloat()
        features[idx++] = frameEnergies.maxOrNull() ?: 0f
        features[idx++] = frameEnergies.minOrNull() ?: 0f
        features[idx++] = calculateStd(frameEnergies)
        features[idx++] = calculateSkewness(frameEnergies)
        features[idx++] = calculateKurtosis(frameEnergies)
        features[idx++] = frameEnergies.sorted().let { it[it.size / 4] } // Q1
        features[idx++] = frameEnergies.sorted().let { it[it.size * 3 / 4] } // Q3
        
        // 过零率统计 (8个特征)
        features[idx++] = frameZCRs.average().toFloat()
        features[idx++] = frameZCRs.maxOrNull() ?: 0f
        features[idx++] = frameZCRs.minOrNull() ?: 0f
        features[idx++] = calculateStd(frameZCRs)
        features[idx++] = calculateSkewness(frameZCRs)
        features[idx++] = calculateKurtosis(frameZCRs)
        features[idx++] = frameZCRs.sorted().let { it[it.size / 4] }
        features[idx++] = frameZCRs.sorted().let { it[it.size * 3 / 4] }
        
        // 基频统计 (8个特征)
        val validPitches = framePitches.filter { it > 50 && it < 500 }
        if (validPitches.isNotEmpty()) {
            features[idx++] = validPitches.average().toFloat()
            features[idx++] = validPitches.maxOrNull() ?: 0f
            features[idx++] = validPitches.minOrNull() ?: 0f
            features[idx++] = calculateStd(validPitches)
            features[idx++] = calculateSkewness(validPitches)
            features[idx++] = calculateKurtosis(validPitches)
            features[idx++] = validPitches.sorted().let { it[it.size / 4] }
            features[idx++] = validPitches.sorted().let { it[it.size * 3 / 4] }
        } else {
            repeat(8) { features[idx++] = 0f }
        }
        
        // 时域特征 (8个特征)
        features[idx++] = floatData.map { abs(it) }.average().toFloat() // 平均幅度
        features[idx++] = floatData.maxOrNull() ?: 0f
        features[idx++] = floatData.minOrNull() ?: 0f
        features[idx++] = calculateStd(floatData.toList())
        
        // 频谱特征（简化版）
        val spectralCentroid = calculateSpectralCentroid(floatData, frameSize)
        features[idx++] = spectralCentroid
        
        // 填充剩余特征
        while (idx < FEATURE_DIMENSION) {
            features[idx++] = 0f
        }
        
        // 归一化特征
        val norm = sqrt(features.map { it * it }.sum())
        if (norm > 0) {
            for (i in features.indices) {
                features[i] = features[i] / norm
            }
        }
        
        return features
    }
    
    /**
     * 📊 估计基频
     */
    private fun estimatePitch(frame: FloatArray, sampleRate: Int): Float {
        // 自相关法估计基频
        val minLag = sampleRate / 500 // 最高500Hz
        val maxLag = sampleRate / 50  // 最低50Hz
        
        if (maxLag >= frame.size) return 0f
        
        var maxCorr = 0f
        var bestLag = 0
        
        for (lag in minLag until minOf(maxLag, frame.size - 1)) {
            var corr = 0f
            for (i in 0 until frame.size - lag) {
                corr += frame[i] * frame[i + lag]
            }
            if (corr > maxCorr) {
                maxCorr = corr
                bestLag = lag
            }
        }
        
        return if (bestLag > 0) sampleRate.toFloat() / bestLag else 0f
    }
    
    /**
     * 📊 计算标准差
     */
    private fun calculateStd(data: List<Float>): Float {
        if (data.isEmpty()) return 0f
        val mean = data.average()
        val variance = data.map { (it - mean) * (it - mean) }.average()
        return sqrt(variance).toFloat()
    }
    
    /**
     * 📊 计算偏度
     */
    private fun calculateSkewness(data: List<Float>): Float {
        if (data.size < 3) return 0f
        val mean = data.average()
        val std = calculateStd(data)
        if (std == 0f) return 0f
        val m3 = data.map { ((it - mean) / std).let { x -> x * x * x } }.average()
        return m3.toFloat()
    }
    
    /**
     * 📊 计算峰度
     */
    private fun calculateKurtosis(data: List<Float>): Float {
        if (data.size < 4) return 0f
        val mean = data.average()
        val std = calculateStd(data)
        if (std == 0f) return 0f
        val m4 = data.map { ((it - mean) / std).let { x -> x * x * x * x } }.average()
        return (m4 - 3).toFloat() // 超额峰度
    }
    
    /**
     * 📊 计算频谱质心
     */
    private fun calculateSpectralCentroid(data: FloatArray, frameSize: Int): Float {
        // 简化版：使用过零率近似
        var zcr = 0f
        for (i in 1 until data.size) {
            if ((data[i] >= 0 && data[i - 1] < 0) || (data[i] < 0 && data[i - 1] >= 0)) {
                zcr += 1
            }
        }
        return zcr / data.size * SAMPLE_RATE / 2
    }
    
    /**
     * 🔗 创建声纹模板（多个样本的平均）
     */
    private fun createVoiceprintTemplate(samples: List<FloatArray>): FloatArray {
        val template = FloatArray(FEATURE_DIMENSION)
        
        for (i in 0 until FEATURE_DIMENSION) {
            template[i] = samples.map { it[i] }.average().toFloat()
        }
        
        // 归一化
        val norm = sqrt(template.map { it * it }.sum())
        if (norm > 0) {
            for (i in template.indices) {
                template[i] = template[i] / norm
            }
        }
        
        return template
    }
    
    /**
     * 🔍 比较声纹相似度
     */
    private fun compareVoiceprints(features: FloatArray, template: FloatArray): Float {
        // 余弦相似度
        var dotProduct = 0f
        var normA = 0f
        var normB = 0f
        
        for (i in 0 until minOf(features.size, template.size)) {
            dotProduct += features[i] * template[i]
            normA += features[i] * features[i]
            normB += template[i] * template[i]
        }
        
        val denominator = sqrt(normA) * sqrt(normB)
        return if (denominator > 0) (dotProduct / denominator + 1) / 2 else 0f // 归一化到 0-1
    }
    
    /**
     * 💾 保存声纹数据
     */
    private fun saveVoiceprints() {
        context?.let { ctx ->
            try {
                val file = File(ctx.filesDir, "voiceprints.json")
                val data = VoiceprintStorage(
                    version = 1,
                    profiles = enrolledVoiceprints.map { profile ->
                        SerializableVoiceprintProfile(
                            userId = profile.userId,
                            userName = profile.userName,
                            template = profile.template.toList(),
                            createdAt = profile.createdAt,
                            sampleCount = profile.sampleCount
                        )
                    }
                )
                file.writeText(Json.encodeToString(VoiceprintStorage.serializer(), data))
                LogManager.d(TAG, "💾 声纹数据已保存")
            } catch (e: Exception) {
                LogManager.e(TAG, "保存声纹数据失败", e)
            }
        }
    }
    
    /**
     * 📂 加载声纹数据
     */
    private fun loadVoiceprints() {
        context?.let { ctx ->
            try {
                val file = File(ctx.filesDir, "voiceprints.json")
                if (file.exists()) {
                    val data = Json.decodeFromString(VoiceprintStorage.serializer(), file.readText())
                    enrolledVoiceprints.clear()
                    enrolledVoiceprints.addAll(data.profiles.map { sp ->
                        VoiceprintProfile(
                            userId = sp.userId,
                            userName = sp.userName,
                            template = sp.template.toFloatArray(),
                            createdAt = sp.createdAt,
                            sampleCount = sp.sampleCount
                        )
                    })
                    LogManager.d(TAG, "📂 已加载 ${enrolledVoiceprints.size} 个声纹")
                }
            } catch (e: Exception) {
                LogManager.e(TAG, "加载声纹数据失败", e)
            }
        }
    }
    
    /**
     * 🔄 重置管理器
     */
    fun reset() {
        enrollmentSamples.clear()
        _state.value = VoiceprintState.IDLE
        _enrollmentProgress.value = 0f
    }
}

// ==================== 📦 数据类 ====================

enum class VoiceprintState {
    IDLE,
    ENROLLING,
    VERIFYING
}

data class VoiceprintConfig(
    val enabled: Boolean = false, // 默认关闭
    val verificationThreshold: Float = 0.65f,
    val requireVerificationForWakeWord: Boolean = true
)

data class VoiceprintProfile(
    val userId: String,
    val userName: String,
    val template: FloatArray,
    val createdAt: Long,
    val sampleCount: Int
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as VoiceprintProfile
        return userId == other.userId
    }
    
    override fun hashCode(): Int = userId.hashCode()
}

data class VoiceprintResult(
    val isVerified: Boolean,
    val userId: String?,
    val confidence: Float,
    val message: String
)

data class VoiceprintUserInfo(
    val userId: String,
    val userName: String,
    val createdAt: Long,
    val sampleCount: Int
)

@Serializable
data class VoiceprintStorage(
    val version: Int,
    val profiles: List<SerializableVoiceprintProfile>
)

@Serializable
data class SerializableVoiceprintProfile(
    val userId: String,
    val userName: String,
    val template: List<Float>,
    val createdAt: Long,
    val sampleCount: Int
)
