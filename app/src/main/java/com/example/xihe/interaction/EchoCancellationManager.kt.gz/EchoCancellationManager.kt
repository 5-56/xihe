package com.example.xihe.interaction

import android.content.Context
import android.media.AudioManager
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import com.example.xihe.utils.LogManager

/**
 * 🔇 回声消除管理器
 * 
 * 功能：
 * 1. 管理系统级回声消除(AEC)
 * 2. 管理噪音抑制(NS)
 * 3. 管理自动增益控制(AGC)
 * 4. 智能检测和过滤系统播报声音
 * 
 * 核心原理：
 * - 使用 VOICE_COMMUNICATION 音频源自动启用硬件级回声消除
 * - 配合软件层面的智能过滤，双重保障只识别用户语音
 */
class EchoCancellationManager(private val context: Context) {
    
    companion object {
        private const val TAG = "EchoCancellation"
        
        // 单例实例
        @Volatile
        private var instance: EchoCancellationManager? = null
        
        fun getInstance(context: Context): EchoCancellationManager {
            return instance ?: synchronized(this) {
                instance ?: EchoCancellationManager(context.applicationContext).also { instance = it }
            }
        }
        
        /**
         * 检查设备是否支持回声消除
         */
        fun isAECSupported(): Boolean = AcousticEchoCanceler.isAvailable()
        
        /**
         * 检查设备是否支持噪音抑制
         */
        fun isNSSupported(): Boolean = NoiseSuppressor.isAvailable()
        
        /**
         * 检查设备是否支持自动增益控制
         */
        fun isAGCSupported(): Boolean = AutomaticGainControl.isAvailable()
    }
    
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    
    // 音频效果实例
    private var echoCanceler: AcousticEchoCanceler? = null
    private var noiseSuppressor: NoiseSuppressor? = null
    private var gainControl: AutomaticGainControl? = null
    
    // 状态
    private var isInitialized = false
    private var audioSessionId: Int = 0
    
    /**
     * 🚀 初始化回声消除（需要在 AudioRecord 创建后调用）
     * 
     * @param audioSessionId AudioRecord 的会话ID
     */
    fun initialize(audioSessionId: Int): Boolean {
        this.audioSessionId = audioSessionId
        
        LogManager.i(TAG, "🔇 初始化回声消除系统...")
        LogManager.d(TAG, "📊 设备支持情况: AEC=${isAECSupported()}, NS=${isNSSupported()}, AGC=${isAGCSupported()}")
        
        var success = true
        
        // 1. 初始化回声消除器
        if (isAECSupported()) {
            try {
                echoCanceler = AcousticEchoCanceler.create(audioSessionId)
                echoCanceler?.enabled = true
                LogManager.i(TAG, "✅ 回声消除(AEC)已启用")
            } catch (e: Exception) {
                LogManager.e(TAG, "❌ 回声消除初始化失败", e)
                success = false
            }
        } else {
            LogManager.w(TAG, "⚠️ 设备不支持硬件回声消除")
        }
        
        // 2. 初始化噪音抑制器
        if (isNSSupported()) {
            try {
                noiseSuppressor = NoiseSuppressor.create(audioSessionId)
                noiseSuppressor?.enabled = true
                LogManager.i(TAG, "✅ 噪音抑制(NS)已启用")
            } catch (e: Exception) {
                LogManager.e(TAG, "❌ 噪音抑制初始化失败", e)
            }
        } else {
            LogManager.w(TAG, "⚠️ 设备不支持硬件噪音抑制")
        }
        
        // 3. 初始化自动增益控制
        if (isAGCSupported()) {
            try {
                gainControl = AutomaticGainControl.create(audioSessionId)
                gainControl?.enabled = true
                LogManager.i(TAG, "✅ 自动增益控制(AGC)已启用")
            } catch (e: Exception) {
                LogManager.e(TAG, "❌ 自动增益控制初始化失败", e)
            }
        }
        
        isInitialized = success
        return success
    }
    
    /**
     * 🔇 启用/禁用回声消除
     */
    fun setEchoCancelerEnabled(enabled: Boolean) {
        echoCanceler?.enabled = enabled
        LogManager.d(TAG, "🔇 回声消除: ${if (enabled) "启用" else "禁用"}")
    }
    
    /**
     * 🔇 启用/禁用噪音抑制
     */
    fun setNoiseSuppressorEnabled(enabled: Boolean) {
        noiseSuppressor?.enabled = enabled
        LogManager.d(TAG, "🔇 噪音抑制: ${if (enabled) "启用" else "禁用"}")
    }
    
    /**
     * 🔊 启用/禁用自动增益控制
     */
    fun setGainControlEnabled(enabled: Boolean) {
        gainControl?.enabled = enabled
        LogManager.d(TAG, "🔊 自动增益: ${if (enabled) "启用" else "禁用"}")
    }
    
    /**
     * 📊 获取当前状态
     */
    fun getStatus(): EchoCancellationStatus {
        return EchoCancellationStatus(
            isInitialized = isInitialized,
            aecSupported = isAECSupported(),
            aecEnabled = echoCanceler?.enabled ?: false,
            nsSupported = isNSSupported(),
            nsEnabled = noiseSuppressor?.enabled ?: false,
            agcSupported = isAGCSupported(),
            agcEnabled = gainControl?.enabled ?: false
        )
    }
    
    /**
     * 🧹 释放资源
     */
    fun release() {
        LogManager.d(TAG, "🧹 释放回声消除资源...")
        
        try {
            echoCanceler?.release()
            echoCanceler = null
        } catch (e: Exception) {
            LogManager.e(TAG, "释放AEC失败", e)
        }
        
        try {
            noiseSuppressor?.release()
            noiseSuppressor = null
        } catch (e: Exception) {
            LogManager.e(TAG, "释放NS失败", e)
        }
        
        try {
            gainControl?.release()
            gainControl = null
        } catch (e: Exception) {
            LogManager.e(TAG, "释放AGC失败", e)
        }
        
        isInitialized = false
        LogManager.d(TAG, "✅ 回声消除资源已释放")
    }
    
    /**
     * 回声消除状态数据类
     */
    data class EchoCancellationStatus(
        val isInitialized: Boolean,
        val aecSupported: Boolean,
        val aecEnabled: Boolean,
        val nsSupported: Boolean,
        val nsEnabled: Boolean,
        val agcSupported: Boolean,
        val agcEnabled: Boolean
    ) {
        override fun toString(): String {
            return buildString {
                append("回声消除状态:\n")
                append("  初始化: $isInitialized\n")
                append("  AEC: ${if (aecSupported) (if (aecEnabled) "✅启用" else "⚪禁用") else "❌不支持"}\n")
                append("  NS: ${if (nsSupported) (if (nsEnabled) "✅启用" else "⚪禁用") else "❌不支持"}\n")
                append("  AGC: ${if (agcSupported) (if (agcEnabled) "✅启用" else "⚪禁用") else "❌不支持"}")
            }
        }
    }
}
