package com.example.xihe.interaction

import android.content.Context
import android.media.AudioManager
import android.media.AudioPlaybackConfiguration
import android.os.Build
import android.view.KeyEvent
import com.example.xihe.utils.LogManager

/**
 * 🔊 音频播放状态监控器
 * 
 * 功能：
 * 1. 检测系统是否有音频正在播放（视频、音乐、通话等）
 * 2. 监听音频焦点变化
 * 3. 提供音频播放状态查询接口
 * 
 * 用途：
 * 在实时对话时，如果检测到系统有音频播放，则暂停语音识别或过滤掉这些声音
 * 避免将视频、音乐等声音误识别为用户指令
 */
class AudioPlaybackMonitor(private val context: Context) {
    
    companion object {
        private const val TAG = "AudioPlaybackMonitor"
        
        // 单例实例
        @Volatile
        private var instance: AudioPlaybackMonitor? = null
        
        fun getInstance(context: Context): AudioPlaybackMonitor {
            return instance ?: synchronized(this) {
                instance ?: AudioPlaybackMonitor(context.applicationContext).also { instance = it }
            }
        }
    }
    
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val myUid: Int = context.applicationInfo.uid

    private fun getClientUidCompat(config: AudioPlaybackConfiguration): Int {
        return try {
            val method = config.javaClass.getMethod("getClientUid")
            (method.invoke(config) as? Int) ?: -1
        } catch (_: Exception) {
            -1
        }
    }
    
    // 音频播放状态
    private var isMediaPlaying = false
    private var lastPlaybackCheckTime = 0L
    private val PLAYBACK_CHECK_INTERVAL = 500L // 检查间隔 500ms
    
    // 音频焦点状态
    private var hasAudioFocus = false
    
    // 音频播放回调 (API 26+)
    private var playbackCallback: AudioManager.AudioPlaybackCallback? = null
    
    // 状态变化监听器
    private var onPlaybackStateChanged: ((Boolean) -> Unit)? = null
    
    /**
     * 🚀 初始化监控器
     */
    fun initialize(onPlaybackStateChanged: ((Boolean) -> Unit)? = null) {
        this.onPlaybackStateChanged = onPlaybackStateChanged
        
        // 注册音频播放回调 (API 26+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            registerPlaybackCallback()
        }
        
        LogManager.i(TAG, "✅ 音频播放监控器初始化完成")
    }
    
    /**
     * 📡 注册音频播放回调 (API 26+)
     */
    private fun registerPlaybackCallback() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            playbackCallback = object : AudioManager.AudioPlaybackCallback() {
                override fun onPlaybackConfigChanged(configs: MutableList<AudioPlaybackConfiguration>?) {
                    super.onPlaybackConfigChanged(configs)
                    
                    val wasPlaying = isMediaPlaying
                    
                    // 检查是否有非本应用的音频播放
                    isMediaPlaying = configs?.any { config ->
                        val uid = getClientUidCompat(config)
                        if (uid == myUid) {
                            false
                        } else {
                            val usage = config.audioAttributes.usage
                            usage == android.media.AudioAttributes.USAGE_MEDIA ||
                                usage == android.media.AudioAttributes.USAGE_GAME ||
                                usage == android.media.AudioAttributes.USAGE_UNKNOWN ||
                                (uid != -1 && usage == android.media.AudioAttributes.USAGE_ASSISTANT)
                        }
                    } ?: false
                    
                    if (wasPlaying != isMediaPlaying) {
                        LogManager.d(TAG, "🔊 音频播放状态变化: ${if (isMediaPlaying) "有音频播放中" else "无音频播放"}")
                        LogManager.d(TAG, "📋 当前播放源数量: ${configs?.size ?: 0}")
                        onPlaybackStateChanged?.invoke(isMediaPlaying)
                    }
                }
            }
            
            playbackCallback?.let { callback ->
                audioManager.registerAudioPlaybackCallback(callback, null)
            }
            LogManager.d(TAG, "📡 已注册音频播放回调")
        }
    }
    
    /**
     * 🔍 检查是否有音频正在播放
     * 
     * @return true 如果有音频正在播放（视频、音乐等）
     */
    fun isAudioPlaying(): Boolean {
        val now = System.currentTimeMillis()
        
        // 缓存检查结果，避免频繁调用
        if (now - lastPlaybackCheckTime < PLAYBACK_CHECK_INTERVAL) {
            return isMediaPlaying
        }
        lastPlaybackCheckTime = now
        
        // API 26+ 使用回调方式已经在 isMediaPlaying 中更新
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // 额外检查：主动获取当前播放配置
            try {
                val configs = audioManager.activePlaybackConfigurations
                isMediaPlaying = configs.any { config ->
                    val uid = getClientUidCompat(config)
                    if (uid == myUid) {
                        false
                    } else {
                        // 检查是否是媒体类型/可能干扰语音识别的音频
                        val usage = config.audioAttributes.usage
                        usage == android.media.AudioAttributes.USAGE_MEDIA ||
                            usage == android.media.AudioAttributes.USAGE_GAME ||
                            usage == android.media.AudioAttributes.USAGE_UNKNOWN ||
                            (uid != -1 && usage == android.media.AudioAttributes.USAGE_ASSISTANT)
                    }
                }
            } catch (e: Exception) {
                LogManager.w(TAG, "⚠️ 获取播放配置失败: ${e.message}")
            }
        } else {
            // 旧版本 API 使用 isMusicActive()
            isMediaPlaying = audioManager.isMusicActive
        }
        
        return isMediaPlaying
    }
    
    /**
     * 🔍 检查是否有音乐正在播放
     */
    fun pauseExternalPlayback(): Boolean {
        if (!isAudioPlaying()) return true
        val paused = dispatchMediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE)
        if (paused) {
            lastPlaybackCheckTime = 0L
            LogManager.i(TAG, "⏸️ 已发送媒体暂停指令")
        }
        return paused
    }

    fun resumeExternalPlayback(): Boolean {
        val resumed = dispatchMediaKey(KeyEvent.KEYCODE_MEDIA_PLAY)
        if (resumed) {
            lastPlaybackCheckTime = 0L
            LogManager.i(TAG, "▶️ 已发送媒体恢复指令")
        }
        return resumed
    }

    private fun dispatchMediaKey(keyCode: Int): Boolean {
        return try {
            audioManager.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
            audioManager.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
            true
        } catch (e: Exception) {
            LogManager.w(TAG, "⚠️ 发送媒体按键失败: ${e.message}")
            false
        }
    }

    fun isMusicActive(): Boolean {
        return audioManager.isMusicActive
    }
    
    /**
     * 🔍 获取当前音频模式
     * 
     * @return 音频模式（正常、通话中、响铃中等）
     */
    fun getAudioMode(): AudioMode {
        return when (audioManager.mode) {
            AudioManager.MODE_NORMAL -> AudioMode.NORMAL
            AudioManager.MODE_RINGTONE -> AudioMode.RINGTONE
            AudioManager.MODE_IN_CALL -> AudioMode.IN_CALL
            AudioManager.MODE_IN_COMMUNICATION -> AudioMode.IN_COMMUNICATION
            else -> AudioMode.NORMAL
        }
    }
    
    /**
     * 🔍 检查是否正在通话
     */
    fun isInCall(): Boolean {
        val mode = audioManager.mode
        return mode == AudioManager.MODE_IN_CALL || 
               mode == AudioManager.MODE_IN_COMMUNICATION
    }
    
    /**
     * 🔍 获取当前媒体音量级别
     * 
     * @return 0-100 的音量百分比
     */
    fun getMediaVolumeLevel(): Int {
        val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        return if (maxVolume > 0) {
            (currentVolume * 100) / maxVolume
        } else {
            0
        }
    }
    
    /**
     * 🔊 获取扬声器是否打开
     */
    fun isSpeakerOn(): Boolean {
        return audioManager.isSpeakerphoneOn
    }
    
    /**
     * 🎧 检查是否连接了耳机
     * 
     * 如果连接了耳机，扬声器播放的声音不会被麦克风捕获
     * 这种情况下可以更宽松地处理语音识别
     */
    fun isHeadsetConnected(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val devices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            devices.any { device ->
                device.type == android.media.AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                device.type == android.media.AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                device.type == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                device.type == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                device.type == android.media.AudioDeviceInfo.TYPE_USB_HEADSET
            }
        } else {
            @Suppress("DEPRECATION")
            audioManager.isWiredHeadsetOn || audioManager.isBluetoothA2dpOn
        }
    }
    
    /**
     * 📊 获取完整的音频状态摘要
     */
    fun getAudioStatusSummary(): AudioStatus {
        return AudioStatus(
            isMediaPlaying = isAudioPlaying(),
            isMusicActive = isMusicActive(),
            isInCall = isInCall(),
            isHeadsetConnected = isHeadsetConnected(),
            isSpeakerOn = isSpeakerOn(),
            audioMode = getAudioMode(),
            mediaVolumeLevel = getMediaVolumeLevel()
        )
    }
    
    /**
     * 🛑 释放资源
     */
    fun release() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            playbackCallback?.let {
                audioManager.unregisterAudioPlaybackCallback(it)
            }
            playbackCallback = null
        }
        LogManager.d(TAG, "✅ 音频播放监控器已释放")
    }
    
    /**
     * 音频模式枚举
     */
    enum class AudioMode {
        NORMAL,           // 正常模式
        RINGTONE,         // 响铃模式
        IN_CALL,          // 通话中
        IN_COMMUNICATION  // 通信模式（如VoIP）
    }
    
    /**
     * 音频状态数据类
     */
    data class AudioStatus(
        val isMediaPlaying: Boolean,      // 是否有媒体播放
        val isMusicActive: Boolean,       // 是否有音乐播放
        val isInCall: Boolean,            // 是否通话中
        val isHeadsetConnected: Boolean,  // 是否连接耳机
        val isSpeakerOn: Boolean,         // 扬声器是否打开
        val audioMode: AudioMode,         // 音频模式
        val mediaVolumeLevel: Int         // 媒体音量级别 (0-100)
    ) {
        /**
         * 判断当前环境是否适合进行语音识别
         * 
         * 适合的情况：
         * 1. 连接了耳机（声音不会被麦克风捕获）
         * 2. 没有媒体播放
         * 3. 没有通话
         */
        fun isSafeForVoiceRecognition(): Boolean {
            // 如果连接了耳机，即使有媒体播放也是安全的
            if (isHeadsetConnected) return true
            
            // 如果没有媒体播放且不在通话中，是安全的
            return !isMediaPlaying && !isInCall
        }
        
        /**
         * 获取需要过滤系统声音的原因
         */
        fun getFilterReason(): String? {
            return when {
                isInCall -> "正在通话中"
                isMediaPlaying && !isHeadsetConnected -> "有媒体正在播放"
                isMusicActive && !isHeadsetConnected -> "有音乐正在播放"
                else -> null
            }
        }
    }
}
