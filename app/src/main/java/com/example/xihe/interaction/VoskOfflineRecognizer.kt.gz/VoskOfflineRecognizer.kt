package com.example.xihe.interaction

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import org.vosk.android.StorageService

/**
 * 🎤 Vosk 离线语音识别器
 * 完全离线运行，不需要网络和 Google 服务
 */
class VoskOfflineRecognizer(private val context: Context) {
    
    companion object {
        private const val TAG = "VoskRecognizer"
        
        // 中文小模型 - 打包在 assets 中
        private const val MODEL_ASSETS_PATH = "model-small-cn"  // assets 中的模型目录名
    }
    
    // 状态
    enum class State {
        UNINITIALIZED,  // 未初始化
        UNPACKING,      // 解压模型中 (首次从 assets 解压)
        INITIALIZING,   // 初始化中
        READY,          // 就绪
        LISTENING,      // 识别中
        ERROR           // 错误
    }
    
    private val _state = MutableStateFlow(State.UNINITIALIZED)
    val state = _state.asStateFlow()
    
    private val _lastResult = MutableStateFlow("")
    val lastResult = _lastResult.asStateFlow()
    
    private val _partialResult = MutableStateFlow("")
    val partialResult = _partialResult.asStateFlow()
    
    private var model: Model? = null
    private var speechService: SpeechService? = null
    
    // 🔄 持续监听模式（实时对话用）
    var continuousListening: Boolean = false
    
    private var startSuppressed: Boolean = false
    
    // ⏱️ 看门狗机制：防止卡住（优化：更智能的重启策略）
    private var watchdogJob: Job? = null
    private var lastActivityTime: Long = 0
    private val WATCHDOG_TIMEOUT = 30000L  // 30秒无活动则重启（优化：延长到30秒，减少误重启）
    
    // 回调
    private var onResult: ((String) -> Unit)? = null
    private var onPartialResult: ((String) -> Unit)? = null
    private var onError: ((String) -> Unit)? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    
    /**
     * 设置识别结果回调
     */
    fun setCallbacks(
        onResult: ((String) -> Unit)? = null,
        onPartialResult: ((String) -> Unit)? = null,
        onError: ((String) -> Unit)? = null
    ) {
        this.onResult = onResult
        this.onPartialResult = onPartialResult
        this.onError = onError
        LogManager.d(TAG, "✅ 回调已设置")
    }
    
    /**
     * 🚀 初始化识别器
     * 首次运行从 assets 解压模型，之后直接加载
     */
    suspend fun initialize(
        onResult: ((String) -> Unit)? = null,
        onPartialResult: ((String) -> Unit)? = null,
        onError: ((String) -> Unit)? = null
    ): Boolean {
        this@VoskOfflineRecognizer.onResult = onResult
        this@VoskOfflineRecognizer.onPartialResult = onPartialResult
        this@VoskOfflineRecognizer.onError = onError
        
        return try {
            _state.value = State.UNPACKING
            LogManager.i(TAG, "📦 开始初始化 Vosk 模型...")
            
            // 🔍 先检查 assets 中是否有模型文件
            val assetsCheck = checkAssetsModel()
            LogManager.d(TAG, "📁 Assets 模型检查: $assetsCheck")
            
            // 🔍 检查目标目录
            val targetDir = java.io.File(context.filesDir, "model")
            LogManager.d(TAG, "📂 目标目录: ${targetDir.absolutePath}, 存在: ${targetDir.exists()}")
            
            // 如果模型已经解压过，尝试直接加载
            if (targetDir.exists() && targetDir.isDirectory && (targetDir.listFiles()?.isNotEmpty() == true)) {
                LogManager.d(TAG, "📁 发现已解压的模型，尝试直接加载...")
                try {
                    model = Model(targetDir.absolutePath)
                    _state.value = State.READY
                    LogManager.i(TAG, "✅ Vosk 模型直接加载成功!")
                    return true
                } catch (e: Exception) {
                    LogManager.w(TAG, "⚠️ 直接加载失败，尝试重新解压: ${e.message}")
                    // 删除旧的模型目录
                    targetDir.deleteRecursively()
                }
            }
            
            LogManager.d(TAG, "📦 从 assets 解压语音识别模型...")
            
            // 使用 Vosk 的 StorageService 从 assets 解压模型
            withContext(Dispatchers.Main) {
                val deferred = CompletableDeferred<Boolean>()
                
                try {
                    StorageService.unpack(
                        context,
                        MODEL_ASSETS_PATH,
                        "model",
                        { loadedModel ->
                            // 模型加载成功
                            model = loadedModel
                            _state.value = State.READY
                            LogManager.i(TAG, "✅ Vosk 语音识别模型加载成功!")
                            deferred.complete(true)
                        },
                        { exception ->
                            // 加载失败
                            LogManager.e(TAG, "❌ StorageService.unpack 失败!")
                            LogManager.e(TAG, "❌ 错误类型: ${exception.javaClass.simpleName}")
                            LogManager.e(TAG, "❌ 错误信息: ${exception.message}")
                            exception.printStackTrace()
                            _state.value = State.ERROR
                            onError?.invoke("模型加载失败: ${exception.message}")
                            deferred.complete(false)
                        }
                    )
                } catch (e: Exception) {
                    LogManager.e(TAG, "❌ StorageService.unpack 调用异常: ${e.message}", e)
                    _state.value = State.ERROR
                    deferred.complete(false)
                }
                
                // 设置超时
                withTimeoutOrNull(60000) { // 60秒超时
                    deferred.await()
                } ?: run {
                    LogManager.e(TAG, "❌ 模型加载超时!")
                    _state.value = State.ERROR
                    false
                }
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 初始化失败: ${e.javaClass.simpleName}", e)
            LogManager.e(TAG, "❌ 错误详情: ${e.message}")
            _state.value = State.ERROR
            onError?.invoke("初始化失败: ${e.message}")
            false
        }
    }
    
    /**
     * 🔍 检查 assets 中的模型文件
     */
    private fun checkAssetsModel(): String {
        return try {
            val files = context.assets.list(MODEL_ASSETS_PATH) ?: emptyArray()
            if (files.isEmpty()) {
                "❌ 模型目录为空或不存在"
            } else {
                "✅ 找到 ${files.size} 个文件/目录: ${files.take(5).joinToString()}"
            }
        } catch (e: Exception) {
            "❌ 检查失败: ${e.message}"
        }
    }
    
    // 模型现在由 StorageService.unpack 从 assets 加载，不需要手动下载
    
    /**
     * 🎤 开始语音识别
     */
    fun startListening() {
        if (startSuppressed) {
            LogManager.d(TAG, "⏸️ 启动被抑制（可能正在播报中），跳过 startListening")
            return
        }
        
        if (_state.value != State.READY && _state.value != State.LISTENING) {
            LogManager.w(TAG, "⚠️ 识别器未就绪，当前状态: ${_state.value}")
            // 如果是持续监听模式，尝试强制重置
            if (continuousListening) {
                LogManager.d(TAG, "🔄 持续监听模式，尝试强制重置...")
                forceReset()
                return
            }
            onError?.invoke("识别器未就绪，请稍后再试")
            return
        }
        
        // 如果已经在监听中，先停止
        if (_state.value == State.LISTENING) {
            LogManager.d(TAG, "🔄 已在监听中，先停止...")
            stopListening()
        }
        
        val currentModel = model ?: run {
            LogManager.e(TAG, "❌ 模型为空")
            return
        }
        
        try {
            val recognizer = Recognizer(currentModel, 16000.0f)
            
            // ⏱️ 启动看门狗
            startWatchdog()
            lastActivityTime = System.currentTimeMillis()
            
            speechService = SpeechService(recognizer, 16000.0f)
            speechService?.startListening(object : RecognitionListener {
                override fun onPartialResult(hypothesis: String?) {
                    lastActivityTime = System.currentTimeMillis()  // 更新活动时间
                    hypothesis?.let {
                        // 解析 JSON 获取文本
                        val text = parseVoskResult(it)
                        if (text.isNotEmpty()) {
                            _partialResult.value = text
                            onPartialResult?.invoke(text)
                            LogManager.d(TAG, "📝 部分结果: $text")
                        }
                    }
                }
                
                override fun onResult(hypothesis: String?) {
                    lastActivityTime = System.currentTimeMillis()  // 更新活动时间
                    hypothesis?.let {
                        val text = parseVoskResult(it)
                        if (text.isNotEmpty()) {
                            // ✏️ 应用纠错
                            val correctedText = correctCommonErrors(text)
                            _lastResult.value = correctedText
                            onResult?.invoke(correctedText)
                            LogManager.d(TAG, "✅ 最终结果: $correctedText")
                        }
                    }
                }
                
                override fun onFinalResult(hypothesis: String?) {
                    hypothesis?.let {
                        val text = parseVoskResult(it)
                        if (text.isNotEmpty()) {
                            // ✏️ 应用纠错
                            val correctedText = correctCommonErrors(text)
                            _lastResult.value = correctedText
                            onResult?.invoke(correctedText)
                            LogManager.d(TAG, "✅ 最终结果: $correctedText")
                        }
                    }
                    // 🔄 持续监听模式：自动重启（📞 优化：极短延迟，像电话一样流畅）
                    if (continuousListening && !startSuppressed) {
                        LogManager.d(TAG, "🔄 持续监听模式，准备重启...")
                        // 🆕 先将状态设为 READY，然后立即重启
                        _state.value = State.READY
                        mainHandler.postDelayed({
                            // 再次检查是否仍在持续监听模式
                            if (continuousListening && !startSuppressed) {
                                LogManager.d(TAG, "🔄 执行重启监听...")
                                startListening()  // 直接调用 startListening 而不是 restartListening
                            } else {
                                LogManager.d(TAG, "⏸️ 持续监听已关闭，跳过重启")
                            }
                        }, 100)  // 📞 优化：缩短到100ms，实现无缝对话
                    } else {
                        _state.value = State.READY
                    }
                }
                
                override fun onError(exception: Exception?) {
                    LogManager.e(TAG, "❌ 识别错误", exception)
                    // 🔄 持续监听模式：出错也重启
                    if (continuousListening && !startSuppressed) {
                        LogManager.d(TAG, "🔄 持续监听模式，错误后准备重启...")
                        _state.value = State.READY
                        mainHandler.postDelayed({
                            // 再次检查是否仍在持续监听模式
                            if (continuousListening && !startSuppressed) {
                                LogManager.d(TAG, "🔄 错误后执行重启监听...")
                                startListening()
                            }
                        }, 500)  // 错误后稍微延长一点
                    } else {
                        _state.value = State.READY
                        onError?.invoke("识别错误: ${exception?.message}")
                    }
                }
                
                override fun onTimeout() {
                    LogManager.d(TAG, "⏱️ 识别超时")
                    // 🔄 持续监听模式：超时也重启（📞 优化：极短延迟）
                    if (continuousListening && !startSuppressed) {
                        LogManager.d(TAG, "🔄 持续监听模式，超时后准备重启...")
                        _state.value = State.READY
                        mainHandler.postDelayed({
                            // 再次检查是否仍在持续监听模式
                            if (continuousListening && !startSuppressed) {
                                LogManager.d(TAG, "🔄 超时后执行重启监听...")
                                startListening()
                            }
                        }, 50)  // 📞 优化：缩短到50ms
                    } else {
                        _state.value = State.READY
                    }
                }
            })
            
            _state.value = State.LISTENING
            LogManager.d(TAG, "🎤 开始监听...")
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 启动识别失败", e)
            _state.value = State.ERROR
            onError?.invoke("启动失败: ${e.message}")
        }
    }
    
    /**
     * 🛑 停止语音识别
     */
    fun stopListening() {
        try {
            speechService?.stop()
            speechService?.shutdown()
            speechService = null
            _state.value = State.READY
            LogManager.d(TAG, "🛑 停止监听")
        } catch (e: Exception) {
            LogManager.e(TAG, "停止监听失败", e)
            // 确保状态恢复
            _state.value = State.READY
        }
    }
    
    /**
     * 🔄 重启语音识别（解决连续识别问题）
     */
    fun restartListening() {
        LogManager.d(TAG, "🔄 重启语音识别...")
        stopListening()
        // 短暂延迟后重新开始
        mainHandler.postDelayed({
            if (_state.value == State.READY && !startSuppressed) {
                startListening()
            }
        }, 200)
    }

    fun setStartSuppressed(suppressed: Boolean) {
        startSuppressed = suppressed
        if (!suppressed) return

        stopWatchdog()

        try {
            speechService?.stop()
            speechService?.shutdown()
        } catch (e: Exception) {
            LogManager.w(TAG, "停止服务失败", e)
        } finally {
            speechService = null
            _state.value = State.READY
        }
    }
    
    /**
     * 🧹 释放资源
     */
    fun release() {
        continuousListening = false
        startSuppressed = false
        stopWatchdog()
        mainHandler.removeCallbacksAndMessages(null)

        try {
            speechService?.stop()
        } catch (e: Exception) {
            LogManager.w(TAG, "停止识别服务失败", e)
        }

        try {
            speechService?.shutdown()
        } catch (e: Exception) {
            LogManager.w(TAG, "关闭识别服务失败", e)
        }
        speechService = null

        try {
            model?.close()
        } catch (e: Exception) {
            LogManager.w(TAG, "关闭模型失败", e)
        }
        model = null

        setCallbacks()
        _lastResult.value = ""
        _partialResult.value = ""
        lastActivityTime = 0
        _state.value = State.UNINITIALIZED
        LogManager.d(TAG, "✅ 资源已释放")
    }

    /**
     * ⏱️ 启动看门狗（防止卡住）
     * 优化：只在真正需要时才重启，避免误触发
     */
    private fun startWatchdog() {
        stopWatchdog()
        if (!continuousListening) return
        
        watchdogJob = CoroutineScope(Dispatchers.Main).launch {
            while (isActive && continuousListening) {
                delay(10000)  // 每 10 秒检查一次（优化：降低检查频率）
                val now = System.currentTimeMillis()
                val idleTime = now - lastActivityTime
                
                // 优化：更严格的重启条件
                if (continuousListening &&
                    !startSuppressed &&
                    idleTime > WATCHDOG_TIMEOUT && 
                    _state.value == State.READY) {  // 只在READY状态才重启
                    LogManager.w(TAG, "⏱️ 看门狗：检测到长时间空闲 (${idleTime}ms)，尝试恢复监听...")
                    forceReset()
                }
            }
        }
        LogManager.d(TAG, "⏱️ 看门狗已启动（检查间隔：10秒，超时阈值：30秒）")
    }
    
    /**
     * ⏱️ 停止看门狗
     */
    private fun stopWatchdog() {
        watchdogJob?.cancel()
        watchdogJob = null
    }
    
    /**
     * 🔄 强制重置（用于恢复卡住状态）
     */
    fun forceReset() {
        LogManager.d(TAG, "🔄 强制重置语音识别...")
        try {
            speechService?.stop()
            speechService = null
        } catch (e: Exception) {
            LogManager.e(TAG, "停止服务失败", e)
        }
        
        _state.value = State.READY
        lastActivityTime = System.currentTimeMillis()
        
        // 延迟后重新开始
        mainHandler.postDelayed({
            if (continuousListening && _state.value == State.READY && !startSuppressed) {
                LogManager.d(TAG, "🔄 强制重置后重新开始监听...")
                startListening()
            }
        }, 500)
    }
    
    /**
     * 📊 解析 Vosk JSON 结果
     */
    private fun parseVoskResult(json: String): String {
        return try {
            // Vosk 返回格式: {"text": "识别的文字"} 或 {"partial": "部分结果"}
            val textMatch = Regex(""""text"\s*:\s*"([^"]*)"""").find(json)
            val partialMatch = Regex(""""partial"\s*:\s*"([^"]*)"""").find(json)
            
            textMatch?.groupValues?.getOrNull(1) 
                ?: partialMatch?.groupValues?.getOrNull(1) 
                ?: ""
        } catch (e: Exception) {
            LogManager.e(TAG, "解析结果失败: $json", e)
            ""
        }
    }
    
    /**
     * 🔍 检查是否已就绪
     */
    fun isReady(): Boolean = _state.value == State.READY
    
    /**
     * ℹ️ 获取模型信息
     */
    fun getModelInfo(): String {
        return """
            模型: Vosk 中文小模型 (内置)
            特点: 完全离线运行，无需网络
            支持: 普通话识别
        """.trimIndent()
    }
    
    /**
     * ✏️ 纠正常见识别错误
     * Vosk 模型有时会误识别某些词，这里进行后处理纠正
     */
    private fun correctCommonErrors(text: String): String {
        var corrected = text
        
        // 常见识别错误映射表
        val corrections = mapOf(
            // 唤醒词纠错
            "你好 契合" to "你好 羲和",
            "你好羲合" to "你好羲和",
            "你好希和" to "你好羲和",
            "你好西和" to "你好羲和",
            "小希" to "小羲",
            "小西" to "小羲",
            "小契" to "小羲",
            "稀和" to "羲和",
            "希和" to "羲和",
            "西和" to "羲和",
            "契和" to "羲和",
            
            // 其他常见错误
            "为神马" to "为什么",
            "神马" to "什么",
            "肿么" to "怎么",
            "酱紫" to "这样",
            "介个" to "这个"
        )
        
        // 应用纠错映射
        for ((error, correction) in corrections) {
            corrected = corrected.replace(error, correction, ignoreCase = true)
        }
        
        // 如果纠错后发生了变化，记录日志
        if (corrected != text) {
            LogManager.d(TAG, "✏️ 识别纠错: \"$text\" → \"$corrected\"")
        }
        
        return corrected
    }
}
