package com.example.xihe.interaction

import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.core.EngineStateManager
import com.example.xihe.core.model.ChatMessageDisplay
import com.example.xihe.core.model.MessageStatus
import com.example.xihe.core.LLMClient
import com.example.xihe.core.AutomationEngine
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * 📞 实时对话管理器
 * 
 * 模拟真实电话对话体验：
 * - 全双工：边听边说，无需等待
 * - 即时打断：用户开口立即停止AI播报
 * - 低延迟：最小化响应时间
 * - 自然轮次：智能判断说话结束
 */
class RealTimeConversationManager(private val context: Context) {
    
    companion object {
        private const val TAG = "RealTimeConversation"
        
        // 🎯 核心参数（优化后的超低延迟配置）
        private const val SILENCE_THRESHOLD_MS = 800L      // 静默800ms判定说话结束（比之前快）
        private const val MIN_SPEECH_LENGTH = 2            // 最少2个字才处理
        private const val INTERRUPT_THRESHOLD_MS = 150L    // 150ms内检测到语音立即打断
        private const val TTS_COOLDOWN_REALTIME_MS = 1200L  // 实时模式TTS冷却时间
        private const val MAX_PENDING_WORDS = 5            // 累积5个字就开始流式播报
        
        @Volatile
        private var instance: RealTimeConversationManager? = null
        
        fun getInstance(context: Context): RealTimeConversationManager {
            return instance ?: synchronized(this) {
                instance ?: RealTimeConversationManager(context.applicationContext).also { instance = it }
            }
        }
    }
    
    // ==================== 状态 ====================
    
    enum class ConversationState {
        IDLE,               // 空闲
        LISTENING,          // 正在听用户说话
        PROCESSING,         // 处理用户输入
        SPEAKING,           // AI正在说话
        INTERRUPTED         // 被用户打断
    }
    
    private val _state = MutableStateFlow(ConversationState.IDLE)
    val state = _state.asStateFlow()
    
    private val _isActive = MutableStateFlow(false)
    val isActive = _isActive.asStateFlow()
    
    // 当前累积的用户语音
    private val _currentUserSpeech = MutableStateFlow("")
    val currentUserSpeech = _currentUserSpeech.asStateFlow()
    
    // 是否可以被打断
    private val _interruptible = MutableStateFlow(true)
    val interruptible = _interruptible.asStateFlow()
    
    // ==================== 内部状态 ====================
    
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var voiceManager: VoiceInteractionManager? = null
    
    // 语音累积
    private var speechBuffer = StringBuilder()
    private var lastSpeechTime = 0L
    private var silenceCheckJob: Job? = null
    
    // TTS状态
    private var isSpeaking = false
    private var currentTTSJob: Job? = null
    private var pendingResponse = StringBuilder()
    
    // 打断检测
    private var interruptCheckJob: Job? = null
    private var lastUserVoiceDetectedTime = 0L
    
    // ==================== 公开方法 ====================
    
    /**
     * 🚀 启动实时对话模式
     */
    fun start(voiceInteractionManager: VoiceInteractionManager) {
        if (_isActive.value) {
            LogManager.w(TAG, "实时对话已在运行")
            return
        }
        
        LogManager.i(TAG, "📞 启动实时对话模式...")
        
        voiceManager = voiceInteractionManager
        _isActive.value = true
        _state.value = ConversationState.LISTENING
        
        // 配置语音管理器为实时模式
        configureForRealTime()
        
        // 启动打断检测
        startInterruptDetection()
        
        LogManager.i(TAG, "✅ 实时对话模式已启动")
    }
    
    /**
     * 🛑 停止实时对话模式
     */
    fun stop() {
        LogManager.i(TAG, "📞 停止实时对话模式...")
        
        _isActive.value = false
        _state.value = ConversationState.IDLE
        
        // 停止所有任务
        silenceCheckJob?.cancel()
        interruptCheckJob?.cancel()
        currentTTSJob?.cancel()
        
        // 清理状态
        speechBuffer.clear()
        pendingResponse.clear()
        _currentUserSpeech.value = ""
        
        // 停止TTS
        voiceManager?.stopSpeaking()
        
        LogManager.i(TAG, "✅ 实时对话模式已停止")
    }
    
    /**
     * 🎤 处理实时语音输入（部分识别结果）
     */
    fun onPartialSpeech(text: String) {
        if (!_isActive.value) return
        
        val now = System.currentTimeMillis()
        lastSpeechTime = now
        lastUserVoiceDetectedTime = now
        
        // 更新显示
        _currentUserSpeech.value = text
        
        // 🔊 如果AI正在说话，检测是否需要打断
        if (_state.value == ConversationState.SPEAKING && text.length >= 2) {
            handleUserInterrupt()
        }
        
        // 更新状态
        if (_state.value != ConversationState.SPEAKING) {
            _state.value = ConversationState.LISTENING
        }
    }
    
    /**
     * 🎤 处理完整语音输入（最终识别结果）
     */
    fun onFinalSpeech(text: String) {
        if (!_isActive.value) return
        if (text.length < MIN_SPEECH_LENGTH) return
        
        LogManager.d(TAG, "🎤 收到完整语音: $text")
        
        val now = System.currentTimeMillis()
        lastSpeechTime = now
        
        // 累积到缓冲区
        if (speechBuffer.isNotEmpty()) {
            speechBuffer.append(" ")
        }
        speechBuffer.append(text)
        
        _currentUserSpeech.value = speechBuffer.toString()
        
        // 如果AI正在说话，打断它
        if (_state.value == ConversationState.SPEAKING) {
            handleUserInterrupt()
        }
        
        // 启动静默检测
        startSilenceDetection()
    }
    
    /**
     * 🔇 用户停止说话（静默检测触发）
     */
    private fun onUserFinishedSpeaking() {
        val finalText = speechBuffer.toString().trim()
        if (finalText.length < MIN_SPEECH_LENGTH) {
            speechBuffer.clear()
            _currentUserSpeech.value = ""
            return
        }
        
        LogManager.i(TAG, "💬 用户说完: $finalText")
        
        // 清理缓冲
        speechBuffer.clear()
        _currentUserSpeech.value = ""
        
        // 处理用户输入
        processUserInput(finalText)
    }
    
    /**
     * ⚡ 处理用户打断
     */
    private fun handleUserInterrupt() {
        if (!_interruptible.value) return
        
        LogManager.i(TAG, "🛑 用户打断AI说话！")
        
        _state.value = ConversationState.INTERRUPTED
        
        // 立即停止TTS
        voiceManager?.stopSpeaking()
        currentTTSJob?.cancel()
        pendingResponse.clear()
        isSpeaking = false
        
        // 切换回监听状态
        scope.launch {
            delay(100) // 极短延迟
            _state.value = ConversationState.LISTENING
        }
    }
    
    // ==================== 内部方法 ====================
    
    /**
     * 配置语音管理器为实时模式
     */
    private fun configureForRealTime() {
        // 设置更短的冷却时间
        // 这里通过回调机制与VoiceInteractionManager协作
        LogManager.d(TAG, "🔧 配置实时模式参数")
    }
    
    /**
     * 启动静默检测
     */
    private fun startSilenceDetection() {
        silenceCheckJob?.cancel()
        silenceCheckJob = scope.launch {
            delay(SILENCE_THRESHOLD_MS)
            
            val timeSinceLastSpeech = System.currentTimeMillis() - lastSpeechTime
            if (timeSinceLastSpeech >= SILENCE_THRESHOLD_MS && speechBuffer.isNotEmpty()) {
                onUserFinishedSpeaking()
            }
        }
    }
    
    /**
     * 启动打断检测
     */
    private fun startInterruptDetection() {
        interruptCheckJob?.cancel()
        interruptCheckJob = scope.launch {
            while (isActive) {
                delay(50) // 50ms检测间隔
                
                if (_state.value == ConversationState.SPEAKING) {
                    val timeSinceVoice = System.currentTimeMillis() - lastUserVoiceDetectedTime
                    if (timeSinceVoice < INTERRUPT_THRESHOLD_MS) {
                        handleUserInterrupt()
                    }
                }
            }
        }
    }
    
    /**
     * 处理用户输入并生成回复
     */
    private fun processUserInput(text: String) {
        _state.value = ConversationState.PROCESSING
        
        // 添加用户消息到UI
        EngineStateManager.addMessage(
            ChatMessageDisplay(
                content = text,
                isUser = true,
                status = MessageStatus.SUCCESS
            )
        )
        
        // 生成AI回复
        scope.launch {
            try {
                val response = generateAIResponse(text)
                
                if (response.isNotBlank()) {
                    // 添加AI消息
                    EngineStateManager.addMessage(
                        ChatMessageDisplay(
                            content = response,
                            isUser = false,
                            status = MessageStatus.SUCCESS
                        )
                    )
                    
                    // 开始播报
                    speakResponse(response)
                }
            } catch (e: Exception) {
                LogManager.e(TAG, "生成回复失败", e)
                _state.value = ConversationState.LISTENING
            }
        }
    }
    
    /**
     * 生成AI回复
     */
    private suspend fun generateAIResponse(input: String): String {
        return withContext(Dispatchers.IO) {
            try {
                val llmClient = LLMClient(
                    AutomationEngine.baseUrl,
                    AutomationEngine.apiKey,
                    AutomationEngine.modelName,
                    AutomationEngine.providerId
                )
                
                // 添加实时对话的系统提示
                val prompt = buildRealtimePrompt(input)
                llmClient.chatCompletion(prompt)
            } catch (e: Exception) {
                LogManager.e(TAG, "LLM调用失败", e)
                "抱歉，我没听清，能再说一遍吗？"
            }
        }
    }
    
    /**
     * 构建实时对话提示
     */
    private fun buildRealtimePrompt(input: String): String {
        return """你正在与用户进行实时语音对话，就像电话通话一样。
请用简短、自然、口语化的方式回复。
- 回复要简洁，通常1-2句话
- 语气要自然亲切，像朋友聊天
- 可以使用语气词如"嗯"、"好的"、"哦"
- 如果需要确认，直接问
- 不要使用书面语或过于正式的表达

用户说：$input"""
    }
    
    /**
     * 播报AI回复（支持打断）
     */
    private fun speakResponse(text: String) {
        _state.value = ConversationState.SPEAKING
        _interruptible.value = true
        isSpeaking = true
        
        currentTTSJob = scope.launch {
            voiceManager?.speak(text) {
                // 播报完成
                isSpeaking = false
                if (_state.value == ConversationState.SPEAKING) {
                    _state.value = ConversationState.LISTENING
                    
                    // 极短延迟后恢复监听
                    launch {
                        delay(TTS_COOLDOWN_REALTIME_MS)
                        if (_isActive.value && _state.value == ConversationState.LISTENING) {
                            voiceManager?.startListening()
                        }
                    }
                }
            }
        }
    }
    
    /**
     * 🎙️ 外部通知检测到用户语音活动
     */
    fun notifyVoiceActivity() {
        lastUserVoiceDetectedTime = System.currentTimeMillis()
    }
    
    /**
     * 释放资源
     */
    fun release() {
        stop()
        scope.cancel()
        instance = null
    }
}
