package com.example.xihe.interaction

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.xihe.utils.LogManager
import androidx.core.content.ContextCompat
import com.example.xihe.tts.SupertonicTTS
import com.example.xihe.tts.OnlineTTS
import com.example.xihe.tts.TTSQueueManager
import com.example.xihe.intelligence.EmotionRecognizer
import com.example.xihe.intelligence.MemorySystem
import com.example.xihe.intelligence.Emotion as EmotionType
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.FileOutputStream
import java.util.*
import kotlin.math.abs

/**
 * 🎤 语音交互管理器
 * 提供语音识别、语音合成、语音唤醒等功能
 */
class VoiceInteractionManager(private val context: Context) {
    
    companion object {
        private const val TAG = "VoiceInteraction"
        private const val SAMPLE_RATE = 16000
        
        // 🎤 唤醒词列表
        private val WAKE_WORDS = listOf(
            "羲和", "小羲", "嘿羲和", "你好羲和", "羲和你好",
            "hi羲和", "hey羲和", "喂羲和", "xihe"
        )
        
        // 🎉 唤醒词回应列表
        private val WAKE_RESPONSES = listOf(
            "主人，我在呢！有什么可以帮你的吗？",
            "在的在的！主人请吩咐~",
            "嗯哼？叫我啦！主人有什么事呀？",
            "来啦来啦！主人想让我做什么呢？",
            "羲和在此！随时为主人效劳！",
            "诶嘿嘿，主人找我有事吗？"
        )
        
        // 🗣️ 常用短语列表 - 这些短语即使在唤醒词模式下也会被处理
        private val COMMON_PHRASES = listOf(
            "你好", "您好", "在吗", "什么", "怎么", "为何", "哪里",
            "帮我", "给我", "打开", "关闭", "停止", "开始", "播放",
            "暂停", "继续", "查询", "搜索", "找到", "显示", "告诉"
        )
    }
    
    /**
     * 语音状态
     */
    enum class VoiceState {
        IDLE,           // 空闲
        LISTENING,      // 监听中
        PROCESSING,     // 处理中
        SPEAKING,       // 说话中
        ERROR           // 错误
    }
    
    /**
     * 语音命令
     */
    data class VoiceCommand(
        val text: String,
        val confidence: Float,
        val timestamp: Long = System.currentTimeMillis(),
        val isWakeWord: Boolean = false,
        val emotion: Emotion? = null
    )
    
    /**
     * 情绪识别
     */
    enum class Emotion {
        HAPPY,      // 开心
        SAD,        // 难过
        ANGRY,      // 生气
        NEUTRAL,    // 中性
        EXCITED,    // 兴奋
        TIRED       // 疲惫
    }
    
    /**
     * 语音配置
     */
    data class VoiceConfig(
        val enableWakeWord: Boolean = true,
        val continuousListening: Boolean = false,
        val voiceSpeed: Float = 1.0f,  // 0.5-2.0
        val voicePitch: Float = 1.0f,  // 0.5-2.0
        val language: Locale = Locale.CHINA,
        val enableEmotionDetection: Boolean = true,
        val enableNoiseSuppression: Boolean = true
    )
    
    // 状态流
    private val _state = MutableStateFlow(VoiceState.IDLE)
    val state = _state.asStateFlow()
    
    private val _lastCommand = MutableStateFlow<VoiceCommand?>(null)
    val lastCommand = _lastCommand.asStateFlow()

    // 🆕 实时部分识别结果 (流式ASR)
    private val _partialRecognitionResult = MutableStateFlow("")
    val partialRecognitionResult = _partialRecognitionResult.asStateFlow()
    
    // 语音识别器 (系统，需要网络)
    private var speechRecognizer: SpeechRecognizer? = null
    private var recognitionIntent: Intent? = null
    
    // Vosk 离线语音识别器 (完全离线)
    private val voskRecognizer = VoskOfflineRecognizer(context).apply {
        // 设置识别结果回调
        setCallbacks(
            onResult = { text ->
                LogManager.d(TAG, "🎤 Vosk识别结果: $text")
                _partialRecognitionResult.value = "" // 清除部分结果
                // 将结果传递到命令处理流程
                handleVoiceInput(text)
            },
            onPartialResult = { text ->
                // LogManager.v(TAG, "🎤 Vosk部分结果: $text") // 减少日志刷屏
                _partialRecognitionResult.value = text
                handleSpeechActivityForMediaPause(text)
            },
            onError = { error ->
                LogManager.e(TAG, "❌ Vosk识别错误: $error")
                if (!config.continuousListening) {
                    resumeExternalPlaybackIfNeeded()
                }
            }
        )
    }
    private var useOfflineRecognizer = true  // 优先使用离线识别
    
    // 📊 统计数据
    private var recognitionCount = 0
    private var successCount = 0
    
    // 🆕 情绪识别系统
    private val emotionRecognizer by lazy { EmotionRecognizer.getInstance(context) }
    
    // 🆕 记忆系统
    private val memorySystem by lazy { MemorySystem.getInstance(context) }
    
    // 初始化状态
    private var isInitialized = false
    private var isVoskInitializing = false  // Vosk正在初始化中
    private var isTtsInitialized = false
    
    // 语音合成器
    private var textToSpeech: TextToSpeech? = null
    
    // Supertonic TTS (本地超快速TTS)
    private val supertonicTTS = SupertonicTTS(context)
    private var useSupertonicTTS = false // 是否使用Supertonic
    private var userPrefersLocalTTS = true // 用户是否偏好使用本地TTS
    
    // 在线 TTS (API调用)
    private val onlineTTS = OnlineTTS(context)
    private var useOnlineTTS = false // 是否使用在线TTS
    
    // TTS 引擎类型枚举
    enum class TTSEngine { LOCAL, ONLINE, SYSTEM }
    
    // 🎵 TTS播放队列管理器
    private val ttsQueueManager by lazy { 
        TTSQueueManager.getInstance(context).apply {
            setTTSCallback { text, emotion, speed, onComplete ->
                speakInternal(text, mapQueueEmotion(emotion), speed, onComplete)
            }
        }
    }
    
    // 音频录制（用于唤醒词检测）
    private var audioRecord: AudioRecord? = null
    private var isRecording = false
    private var wakeWordDetectionActive = false
    private val mainScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val recordingScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    
    // 配置
    private var config = VoiceConfig()
    
    // 🔇 TTS播放状态管理（用于防止回声）
    private var isTTSSpeaking = false
    private var ttsEndTime: Long = 0
    private var ttsStartTime: Long = 0
    private val TTS_COOLDOWN_MS = 2500L  // TTS结束后的冷却时间，防止捕获回声
    private val TTS_COOLDOWN_SHORT_MS = 2000L  // 实时对话模式下的冷却时间
    private val TTS_COOLDOWN_ULTRA_SHORT_MS = 100L  // 打断后的极短冷却时间
    
    // 🎤 智能回声消除：记录最近播报的内容用于过滤
    private var lastSpokenTexts = mutableListOf<String>()
    private val MAX_SPOKEN_HISTORY = 5  // 保留最近5条播报记录
    
    // 🔊 语音播报总开关
    private var enableTTSResponse = true
    
    // 🔇 其他应用播放状态监听（避免识别视频、音乐等）
    private var lastAudioPlaybackTime: Long = 0
    private val AUDIO_PLAYBACK_COOLDOWN_MS = 3000L  // 检测到音频播放后的冷却时间（优化：延长到3秒）
    
    // 🎵 音频播放监控器（用于检测系统声音）
    private val audioPlaybackMonitor by lazy { AudioPlaybackMonitor.getInstance(context) }
    
    // 🎤 智能语音过滤器（用于区分用户语音和系统声音）
    private val smartVoiceFilter by lazy { SmartVoiceFilter.getInstance(context) }

     private val audioManager by lazy {
         context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
     }

     private var audioFocusRequest: AudioFocusRequest? = null
     private var hasRealtimeAudioFocus: Boolean = false
     private var pausedByAudioFocusLoss: Boolean = false
     private var pausedByExternalPlayback: Boolean = false
     private var lastRealtimeSuppressedToastTime: Long = 0
     private var pausedExternalPlaybackForListening: Boolean = false
     private var pendingPlaybackResumeJob: Job? = null
     private var lastExternalPauseAttemptTime: Long = 0
     private val EXTERNAL_PAUSE_ATTEMPT_COOLDOWN_MS = 1500L
     private var waitingForSpeechTriggeredPause: Boolean = false
     private val SPEECH_TRIGGER_MIN_LENGTH = 2

     private val audioFocusChangeListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
         if (!config.continuousListening) return@OnAudioFocusChangeListener

         when (focusChange) {
             AudioManager.AUDIOFOCUS_GAIN -> {
                 hasRealtimeAudioFocus = true
                 if (pausedByAudioFocusLoss) {
                     pausedByAudioFocusLoss = false
                     val audioStatus = audioPlaybackMonitor.getAudioStatusSummary()
                     if (audioStatus.isSafeForVoiceRecognition()) {
                         LogManager.d(TAG, "🎧 [实时对话] 音频焦点恢复，尝试恢复语音识别")
                         voskRecognizer.setStartSuppressed(false)
                         startListening()
                     } else {
                         LogManager.w(TAG, "🔇 [实时对话] 音频焦点恢复但环境不安全，保持暂停: ${audioStatus.getFilterReason()}")
                         maybeShowRealtimeSuppressedToast(audioStatus.getFilterReason())
                     }
                 }
             }

             AudioManager.AUDIOFOCUS_LOSS,
             AudioManager.AUDIOFOCUS_LOSS_TRANSIENT,
             AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                 if (focusChange == AudioManager.AUDIOFOCUS_LOSS) {
                     hasRealtimeAudioFocus = false
                 }

                 if (_state.value == VoiceState.LISTENING) {
                     pausedByAudioFocusLoss = true
                     LogManager.w(TAG, "🔇 [实时对话] 失去音频焦点，暂停语音识别 (focus=$focusChange)")
                     voskRecognizer.setStartSuppressed(true)
                     stopListening(disableContinuous = false)
                 }
             }
         }
     }

     private fun maybeShowRealtimeSuppressedToast(reason: String?) {
         val now = System.currentTimeMillis()
         if (now - lastRealtimeSuppressedToastTime < 2500) return
         lastRealtimeSuppressedToastTime = now

         val msg = if (reason.isNullOrBlank()) {
             "检测到外放媒体/通话，已暂停实时语音识别"
         } else {
             "$reason，已暂停实时语音识别"
         }

         Toast.makeText(context.applicationContext, msg, Toast.LENGTH_SHORT).show()
     }
    
    // 🔇 回声消除管理器
    private val echoCancellationManager by lazy { EchoCancellationManager.getInstance(context) }
    
    // 🎤 唤醒词冷却时间（防止重复触发）
    private var lastWakeWordTime: Long = 0
    private val WAKE_WORD_COOLDOWN_MS = 5000L  // 唤醒词触发后的冷却时间（优化：延长到5秒）
    
    // 📞 实时对话打断检测
    private var lastUserVoiceTime: Long = 0
    private val INTERRUPT_DETECTION_THRESHOLD_MS = 200L  // 200ms内检测到语音就打断
    private var isInterruptEnabled = true  // 是否允许打断
    
    // 回调
    private var onCommandReceived: ((VoiceCommand) -> Unit)? = null
    private var onWakeWordDetected: (() -> Unit)? = null
    private var onUserInterrupt: (() -> Unit)? = null  // 📞 用户打断回调
    
    /**
     * 设置语音命令接收回调
     */
    fun setOnCommandReceived(callback: (VoiceCommand) -> Unit) {
        onCommandReceived = callback
        LogManager.d(TAG, "✅ 命令回调已设置")
    }
    
    /**
     * 📞 设置用户打断回调
     */
    fun setOnUserInterrupt(callback: () -> Unit) {
        onUserInterrupt = callback
        LogManager.d(TAG, "✅ 打断回调已设置")
    }
    
    /**
     * 📞 检测并处理用户打断（在部分识别时调用）
     * 如果正在播报且检测到用户说话，立即停止播报
     */
    fun checkAndHandleInterrupt(partialText: String) {
        if (!config.continuousListening || !isInterruptEnabled) return
        if (!isTTSSpeaking) return
        
        // 检测到有效语音输入（至少2个字符）
        if (partialText.length >= 2) {
            val now = System.currentTimeMillis()
            lastUserVoiceTime = now
            
            LogManager.i(TAG, "📞 检测到用户打断！立即停止播报")
            
            // 立即停止TTS
            stopSpeaking()
            
            // 触发打断回调
            onUserInterrupt?.invoke()
            
            // 极短延迟后恢复监听
            mainScope.launch {
                delay(TTS_COOLDOWN_ULTRA_SHORT_MS)
                voskRecognizer.setStartSuppressed(false)
            }
        }
    }
    
    /**
     * 📞 设置是否允许打断
     */
    fun setInterruptEnabled(enabled: Boolean) {
        isInterruptEnabled = enabled
        LogManager.d(TAG, "📞 打断功能: ${if (enabled) "启用" else "禁用"}")
    }
    
    // 🎯 智能语音识别优化器
    private val asrOptimizer = com.example.xihe.asr.SmartASROptimizer().apply {
        setConfig(
            com.example.xihe.asr.SmartASROptimizer.OptimizationConfig(
                enableContextCorrection = true,
                enableCommonPhraseCorrection = true,
                enableNumberCorrection = true,
                enablePunctuationFix = true,
                enableLLMCorrection = false,  // 默认关闭LLM纠错以提升速度
                confidenceThreshold = 0.6f
            )
        )
    }
    
    /**
     * 处理语音输入 (优化版：包含智能纠错)
     */
    private fun handleVoiceInput(text: String) {
        if (text.isBlank()) return
        
        LogManager.d(TAG, "🎙️ 原始语音输入: $text")

        smartVoiceFilter.setRealTimeMode(config.continuousListening)
        val rawFilterResult = smartVoiceFilter.filterVoiceInput(text)
        if (rawFilterResult.shouldFilter) {
            LogManager.d(TAG, "🔇 原始语音被过滤: ${rawFilterResult.getReasonDescription()}")
            if (config.continuousListening) {
                _state.value = VoiceState.LISTENING
            }
            resumeExternalPlaybackIfNeeded(text)
            return
        }
        
        // 🎯 使用智能优化器优化识别结果
        mainScope.launch {
            try {
                val result = asrOptimizer.optimizeResult(
                    rawText = text,
                    confidence = 0.8f,
                    llmClient = null  // 不使用LLM纠错
                )
                
                val optimizedText = result.optimizedText
                
                if (result.improved) {
                    LogManager.i(TAG, "✅ 识别结果已优化: $text → $optimizedText")
                    if (result.corrections.isNotEmpty()) {
                        LogManager.d(TAG, "  纠正项: ${result.corrections.joinToString(", ")}")
                    }
                } else {
                    LogManager.d(TAG, "✓ 识别结果无需优化: $optimizedText")
                }
                
                // 统一走处理流程
                val optimizedFilterResult = smartVoiceFilter.filterVoiceInput(optimizedText)
                if (optimizedFilterResult.shouldFilter) {
                    LogManager.d(TAG, "🔇 优化后语音被过滤: ${optimizedFilterResult.getReasonDescription()}")
                    if (config.continuousListening) {
                        _state.value = VoiceState.LISTENING
                    }
                    resumeExternalPlaybackIfNeeded(optimizedText)
                    return@launch
                }

                processVoiceCommand(optimizedText)
                
            } catch (e: Exception) {
                LogManager.e(TAG, "语音优化失败，使用原始文本", e)
                processVoiceCommand(text)
            }
        }
    }
    
    /**
     * 🎯 初始化
     */
    fun initialize(
        config: VoiceConfig = VoiceConfig(),
        onCommandReceived: ((VoiceCommand) -> Unit)? = null,
        onWakeWordDetected: (() -> Unit)? = null
    ) {
        this.config = config
        this.onCommandReceived = onCommandReceived
        this.onWakeWordDetected = onWakeWordDetected
        
        LogManager.i(TAG, "🎯 VoiceInteractionManager 开始初始化...")
        
        // 🎵 初始化音频播放监控器
        audioPlaybackMonitor.initialize { isPlaying ->
            if (isPlaying) {
                LogManager.d(TAG, "🔊 检测到系统音频播放，记录时间戳")
                lastAudioPlaybackTime = System.currentTimeMillis()
            }

             if (config.continuousListening) {
                 handleExternalPlaybackStateChanged(isPlaying)
             }
        }
        
        // 🎯 初始化智能语速调节
        ttsQueueManager.setUserBaseSpeed(config.voiceSpeed)
        ttsQueueManager.setSmartSpeedEnabled(true)
        LogManager.d(TAG, "🎯 智能语速调节已启用，基础语速: ${config.voiceSpeed}")
        
        // 🎯 应用ASR优化推荐规则
        com.example.xihe.asr.ASROptimizationHelper.applyRecommendedRules(asrOptimizer)
        
        // 加载用户自定义ASR规则
        val customRules = com.example.xihe.asr.ASROptimizationHelper.loadCustomRules(context)
        if (customRules.isNotEmpty()) {
            asrOptimizer.addCustomRules(customRules)
            LogManager.d(TAG, "📂 已加载 ${customRules.size} 条用户自定义ASR规则")
        }
        
        // 🎤 初始化智能语音过滤器的冷却时间
        smartVoiceFilter.setTTSCooldown(TTS_COOLDOWN_MS)
        LogManager.d(TAG, "🎤 SmartVoiceFilter 冷却时间设置为 ${TTS_COOLDOWN_MS}ms")
        
        // 先初始化 TTS（不需要录音权限）
        initializeTextToSpeech()
        
        // 读取用户的TTS偏好设置
        val prefs = context.getSharedPreferences("voice_settings", android.content.Context.MODE_PRIVATE)
        val ttsEngineType = prefs.getString("tts_engine_type", "local") ?: "local"
        userPrefersLocalTTS = ttsEngineType == "local"
        useOnlineTTS = ttsEngineType == "online"
        
        // 初始化在线 TTS
        if (useOnlineTTS) {
            onlineTTS.initialize()
            LogManager.i(TAG, "🌐 在线TTS已初始化")
        }
        
        // 初始化 Supertonic TTS（不需要录音权限）
        mainScope.launch {
            val success = supertonicTTS.initialize()
            if (success && userPrefersLocalTTS) {
                useSupertonicTTS = true
                LogManager.i(TAG, "✅ Supertonic TTS初始化成功，将使用本地TTS")
            } else if (success) {
                LogManager.i(TAG, "✅ Supertonic TTS已就绪，但用户选择其他TTS引擎")
            } else {
                LogManager.w(TAG, "⚠️ Supertonic TTS初始化失败")
            }
        }
        
        // 检查录音权限
        val hasAudioPermission = checkAudioPermission()
        LogManager.d(TAG, "🔐 录音权限状态: $hasAudioPermission")
        
        if (!hasAudioPermission) {
            LogManager.e(TAG, "❌ 缺少录音权限，语音识别功能受限")
            // 不再直接返回，而是标记状态，TTS 仍然可用
        }
        
        // 🆕 初始化 Vosk 离线语音识别（需要录音权限）
        if (hasAudioPermission) {
            LogManager.i(TAG, "🔄 开始初始化 Vosk 离线语音识别...")
            isVoskInitializing = true
            mainScope.launch {
                try {
                    val voskSuccess = voskRecognizer.initialize(
                        onResult = { text ->
                            _partialRecognitionResult.value = ""
                            handleVoiceInput(text)
                        },
                        onPartialResult = { text ->
                            LogManager.d(TAG, "📝 部分识别: $text")
                            _partialRecognitionResult.value = text
                            handleSpeechActivityForMediaPause(text)
                        },
                        onError = { error ->
                            LogManager.e(TAG, "❌ Vosk 错误: $error")
                            if (!config.continuousListening) {
                                resumeExternalPlaybackIfNeeded()
                            }
                        }
                    )
                    
                    if (voskSuccess) {
                        useOfflineRecognizer = true
                        LogManager.i(TAG, "✅ Vosk 离线语音识别初始化成功!")
                    } else {
                        useOfflineRecognizer = false
                        LogManager.w(TAG, "⚠️ Vosk 初始化失败，回退到系统语音识别")
                        initializeSpeechRecognizer()
                    }
                } catch (e: Exception) {
                    LogManager.e(TAG, "❌ Vosk 初始化异常: ${e.message}", e)
                    useOfflineRecognizer = false
                    initializeSpeechRecognizer()
                } finally {
                    isVoskInitializing = false
                }
            }
        } else {
            LogManager.w(TAG, "⚠️ 无录音权限，跳过 Vosk 初始化")
        }
        
        // ❌ 不再自动启动唤醒词检测
        // 唤醒词检测需要用户手动在设置中开启
        // if (config.enableWakeWord && hasAudioPermission) {
        //     startWakeWordDetection()
        // }
        LogManager.d(TAG, "💡 唤醒词检测默认关闭，需要在设置中手动开启")
        
        isInitialized = true
        LogManager.i(TAG, "✅ 语音交互管理器初始化完成")
    }
    
    /**
     * 🎤 开始语音识别
     */
    fun startListening() {
        if (!checkAudioPermission()) return

        if (isTTSSpeaking) {
            LogManager.d(TAG, "🔇 正在播报中，跳过启动语音识别")
            return
        }
        val now = System.currentTimeMillis()
        val cooldown = if (config.continuousListening) TTS_COOLDOWN_SHORT_MS else TTS_COOLDOWN_MS
        if (ttsEndTime > 0 && now - ttsEndTime < cooldown) {
            LogManager.d(TAG, "🔇 TTS冷却期(${cooldown}ms)内，跳过启动语音识别")
            return
        }

        val audioStatus = audioPlaybackMonitor.getAudioStatusSummary()
        if (!audioStatus.isSafeForVoiceRecognition()) {
            waitingForSpeechTriggeredPause = true
            LogManager.d(TAG, "🔉 检测到外放媒体，进入开口暂停门控")
            if (config.continuousListening) {
                requestRealtimeAudioFocus()
            }
        } else {
            waitingForSpeechTriggeredPause = false
        }

        pausedByExternalPlayback = false
        voskRecognizer.setStartSuppressed(false)

        LogManager.d(TAG, "🎤 准备开始语音识别...")
        LogManager.d(TAG, "🎤 使用引擎: ${if (useOfflineRecognizer) "Vosk离线" else "系统"}")

        if (_state.value == VoiceState.LISTENING) {
            LogManager.w(TAG, "⚠️ 已在监听中，先停止再重新开始")
            stopListening(disableContinuous = false)
            mainScope.launch {
                delay(200)
                startListeningInternal()
            }
            return
        }

        startListeningInternal()
    }

    /**
     * 🎤 内部启动识别方法
     */
    private fun startListeningInternal() {
        _state.value = VoiceState.LISTENING
        
        try {
            val voskState = voskRecognizer.state.value
            LogManager.d(TAG, "🔍 Vosk状态: $voskState, useOfflineRecognizer: $useOfflineRecognizer")
            
            // 如果 Vosk 未初始化，尝试初始化
            if (voskState == VoskOfflineRecognizer.State.UNINITIALIZED && !isVoskInitializing) {
                LogManager.w(TAG, "⚠️ Vosk 未初始化，尝试初始化...")
                initializeVoskAsync()
            }
            
            if (useOfflineRecognizer && voskState == VoskOfflineRecognizer.State.READY) {
                // 🆕 使用 Vosk 离线识别
                LogManager.d(TAG, "🎤 使用 Vosk 离线语音识别")
                voskRecognizer.startListening()
            } else {
                // 回退到系统语音识别
                LogManager.d(TAG, "🎤 使用系统语音识别 (Vosk状态: $voskState)")
                if (speechRecognizer == null) {
                    LogManager.w(TAG, "⚠️ 系统语音识别器未初始化，尝试初始化...")
                    initializeSpeechRecognizer()
                }
                if (speechRecognizer != null) {
                    speechRecognizer?.startListening(recognitionIntent)
                } else {
                    LogManager.e(TAG, "❌ 语音识别不可用！请稍后重试，Vosk 模型正在加载中...")
                    _state.value = VoiceState.ERROR
                }
            }
            LogManager.d(TAG, "开始语音识别")
        } catch (e: Exception) {
            LogManager.e(TAG, "开始语音识别失败", e)
            _state.value = VoiceState.ERROR
        }
    }
    
    /**
     * 🔄 异步初始化 Vosk
     */
    private fun initializeVoskAsync() {
        if (isVoskInitializing) return
        isVoskInitializing = true
        
        LogManager.i(TAG, "🔄 后台初始化 Vosk 离线语音识别...")
        mainScope.launch {
            try {
                val voskSuccess = voskRecognizer.initialize(
                    onResult = { text ->
                        _partialRecognitionResult.value = ""
                        handleVoiceInput(text)
                    },
                    onPartialResult = { text ->
                        _partialRecognitionResult.value = text
                        handleSpeechActivityForMediaPause(text)
                    },
                    onError = { error ->
                        LogManager.e(TAG, "❌ Vosk 错误: $error")
                        if (!config.continuousListening) {
                            resumeExternalPlaybackIfNeeded()
                        }
                    }
                )
                
                if (voskSuccess) {
                    useOfflineRecognizer = true
                    LogManager.i(TAG, "✅ Vosk 离线语音识别初始化成功! 下次点击将使用离线识别")
                } else {
                    useOfflineRecognizer = false
                    LogManager.w(TAG, "⚠️ Vosk 初始化失败")
                }
            } catch (e: Exception) {
                LogManager.e(TAG, "❌ Vosk 初始化异常: ${e.message}", e)
                useOfflineRecognizer = false
            } finally {
                isVoskInitializing = false
            }
        }
    }
    
    /**
     * 🛑 停止语音识别
     * @param disableContinuous 是否同时禁用持续监听模式（默认 true）
     */
    fun stopListening(disableContinuous: Boolean = true) {
        LogManager.d(TAG, "🛑 停止语音识别 (禁用持续模式: $disableContinuous)")
        
        try {
            _partialRecognitionResult.value = "" // 清除显示
            
            // 🔇 禁用持续监听模式，防止自动重启
            if (disableContinuous) {
                config = config.copy(continuousListening = false)
                if (useOfflineRecognizer) {
                    voskRecognizer.continuousListening = false
                }
                voskRecognizer.setStartSuppressed(false)
            }
            
            if (useOfflineRecognizer) {
                voskRecognizer.stopListening()
            } else {
                speechRecognizer?.stopListening()
            }
            _state.value = VoiceState.IDLE
            waitingForSpeechTriggeredPause = false
            LogManager.d(TAG, "✅ 语音识别已停止")
            if (disableContinuous) {
                resumeExternalPlaybackIfNeeded()
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "停止语音识别失败", e)
            _state.value = VoiceState.IDLE
            waitingForSpeechTriggeredPause = false
            if (disableContinuous) {
                resumeExternalPlaybackIfNeeded()
            }
        }
    }
    
    /**
     * 🔄 设置持续监听模式
     */
    fun setContinuousMode(enabled: Boolean) {
        LogManager.d(TAG, "🔄 设置持续监听模式: $enabled")
        if (useOfflineRecognizer) {
            voskRecognizer.continuousListening = enabled
        }
        config = config.copy(continuousListening = enabled)
        
        // 🆕 同步更新 SmartVoiceFilter 的实时模式
        smartVoiceFilter.setRealTimeMode(enabled)
        
        // 🆕 实时对话模式下，缩短 TTS 冷却时间
        if (enabled) {
            smartVoiceFilter.setTTSCooldown(TTS_COOLDOWN_SHORT_MS)
            LogManager.d(TAG, "🎤 实时对话模式：TTS冷却时间设为 ${TTS_COOLDOWN_SHORT_MS}ms")

             requestRealtimeAudioFocus()

             val audioStatus = audioPlaybackMonitor.getAudioStatusSummary()
             if (!audioStatus.isSafeForVoiceRecognition()) {
                 waitingForSpeechTriggeredPause = true
                 LogManager.d(TAG, "🔉 [实时对话] 外放媒体存在，等待用户开口后自动暂停")
             } else {
                 waitingForSpeechTriggeredPause = false
             }
        } else {
            smartVoiceFilter.setTTSCooldown(TTS_COOLDOWN_MS)
            waitingForSpeechTriggeredPause = false
            resumeExternalPlaybackIfNeeded()
             abandonRealtimeAudioFocus()
             pausedByAudioFocusLoss = false
             pausedByExternalPlayback = false
             voskRecognizer.setStartSuppressed(false)
        }
    }

     private fun requestRealtimeAudioFocus() {
         if (hasRealtimeAudioFocus) return

         val result = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
             val attrs = AudioAttributes.Builder()
                 .setUsage(AudioAttributes.USAGE_ASSISTANT)
                 .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                 .build()

             val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                 .setAudioAttributes(attrs)
                 .setOnAudioFocusChangeListener(audioFocusChangeListener)
                 .setWillPauseWhenDucked(true)
                 .build()

             audioFocusRequest = req
             audioManager.requestAudioFocus(req)
         } else {
             @Suppress("DEPRECATION")
             audioManager.requestAudioFocus(
                 audioFocusChangeListener,
                 AudioManager.STREAM_MUSIC,
                 AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE
             )
         }

         hasRealtimeAudioFocus = result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
         LogManager.d(
             TAG,
             "🎧 [实时对话] 请求独占音频焦点: ${if (hasRealtimeAudioFocus) "成功" else "失败"} (result=$result)"
         )
     }

     private fun abandonRealtimeAudioFocus() {
         if (!hasRealtimeAudioFocus && audioFocusRequest == null) return

         try {
             if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                 audioFocusRequest?.let { req ->
                     audioManager.abandonAudioFocusRequest(req)
                 }
             } else {
                 @Suppress("DEPRECATION")
                 audioManager.abandonAudioFocus(audioFocusChangeListener)
             }
         } catch (e: Exception) {
             LogManager.w(TAG, "⚠️ 释放音频焦点失败: ${e.message}")
         } finally {
             audioFocusRequest = null
             hasRealtimeAudioFocus = false
         }
     }

     private fun handleExternalPlaybackStateChanged(isPlaying: Boolean) {
         if (!config.continuousListening) return

         val audioStatus = audioPlaybackMonitor.getAudioStatusSummary()
         if (audioStatus.isHeadsetConnected) {
             waitingForSpeechTriggeredPause = false
             return
         }

         if (isPlaying) {
             waitingForSpeechTriggeredPause = true
             requestRealtimeAudioFocus()
             LogManager.d(TAG, "🔉 [实时对话] 检测到外放媒体，等待用户开口后自动暂停")
             if (_state.value != VoiceState.LISTENING && !isTTSSpeaking) {
                 startListening()
             }
         } else {
             waitingForSpeechTriggeredPause = false
             if (pausedByExternalPlayback) {
                 pausedByExternalPlayback = false
                 if (_state.value != VoiceState.LISTENING && !isTTSSpeaking) {
                     startListening()
                 }
             }
         }
     }

     private fun handleSpeechActivityForMediaPause(partialText: String) {
         val normalized = partialText.trim()
         if (normalized.length < SPEECH_TRIGGER_MIN_LENGTH) return

         val audioStatus = audioPlaybackMonitor.getAudioStatusSummary()
         if (audioStatus.isSafeForVoiceRecognition()) {
             waitingForSpeechTriggeredPause = false
             return
         }

         waitingForSpeechTriggeredPause = true
         val paused = attemptPauseExternalPlaybackForListening(audioStatus)
         if (paused) {
             waitingForSpeechTriggeredPause = false
             pausedByExternalPlayback = false
         }
     }

     private fun attemptPauseExternalPlaybackForListening(audioStatus: AudioPlaybackMonitor.AudioStatus): Boolean {
         if (audioStatus.isHeadsetConnected) return false
         if (!audioStatus.isMediaPlaying && !audioStatus.isMusicActive) return false

         val now = System.currentTimeMillis()
         if (now - lastExternalPauseAttemptTime < EXTERNAL_PAUSE_ATTEMPT_COOLDOWN_MS) return false
         lastExternalPauseAttemptTime = now

         requestRealtimeAudioFocus()
         val paused = audioPlaybackMonitor.pauseExternalPlayback()
         if (paused) {
             pausedExternalPlaybackForListening = true
             waitingForSpeechTriggeredPause = false
             lastAudioPlaybackTime = System.currentTimeMillis()
             LogManager.i(TAG, "⏸️ 已暂停外放媒体，准备监听用户语音")
         } else {
             LogManager.w(TAG, "⚠️ 暂停外放媒体失败")
         }
         return paused
     }

     private fun releaseAudioFocusIfNeededAfterSingleShot() {
         if (!config.continuousListening) {
             abandonRealtimeAudioFocus()
         }
     }

     private fun isMediaControlCommand(text: String): Boolean {
         val normalized = text.replace(" ", "")
         if (normalized.isBlank()) return false
         val mediaControlKeywords = listOf("暂停", "停止", "播放", "继续", "下一首", "上一首", "音量", "静音", "快进", "后退", "小说", "视频", "音乐")
         return mediaControlKeywords.any { normalized.contains(it) }
     }

     private fun resumeExternalPlaybackIfNeeded(commandText: String? = null) {
         if (!pausedExternalPlaybackForListening) {
             waitingForSpeechTriggeredPause = false
             abandonRealtimeAudioFocus()
             return
         }

         pausedExternalPlaybackForListening = false
         waitingForSpeechTriggeredPause = false
         if (isMediaControlCommand(commandText ?: "")) {
             abandonRealtimeAudioFocus()
             return
         }

         pendingPlaybackResumeJob?.cancel()
         pendingPlaybackResumeJob = mainScope.launch {
             delay(250)
             audioPlaybackMonitor.resumeExternalPlayback()
             abandonRealtimeAudioFocus()
             pendingPlaybackResumeJob = null
         }
     }
    
    /**
     * 🎤 设置语音识别引擎类型
     * @param useOffline true = 使用 Vosk 离线识别，false = 使用系统识别
     */
    fun setUseOfflineRecognizer(useOffline: Boolean) {
        LogManager.i(TAG, "🎤 切换语音识别引擎: ${if (useOffline) "Vosk 离线" else "系统"}")
        
        // 如果正在监听，先停止
        if (_state.value == VoiceState.LISTENING) {
            stopListening(disableContinuous = false)
        }
        
        useOfflineRecognizer = useOffline
        
        // 如果切换到离线识别，确保 Vosk 已初始化
        if (useOffline && voskRecognizer.state.value == VoskOfflineRecognizer.State.UNINITIALIZED) {
            LogManager.d(TAG, "⚠️ Vosk 未初始化，尝试初始化...")
            initializeVoskAsync()
        }
    }
    
    /**
     * 🔊 语音合成（文字转语音）- 使用队列管理
     * 支持排队播放，防止重复，优先级控制
     */
    fun speak(
        text: String,
        emotion: Emotion = Emotion.NEUTRAL,
        onComplete: (() -> Unit)? = null
    ) {
        // 🔇 检查是否启用语音播报
        if (!enableTTSResponse) {
            LogManager.d(TAG, "🔇 语音播报已关闭，跳过播报")
            onComplete?.invoke()
            return
        }
        
        // 🎵 使用队列管理器
        val queueEmotion = mapToQueueEmotion(emotion)
        ttsQueueManager.enqueue(
            text = text,
            priority = TTSQueueManager.Priority.NORMAL,
            emotion = queueEmotion,
            onComplete = onComplete
        )
    }
    
    /**
     * 🔊 紧急语音播放（中断当前播放）
     */
    fun speakUrgent(
        text: String,
        emotion: Emotion = Emotion.NEUTRAL,
        onComplete: (() -> Unit)? = null
    ) {
        if (!enableTTSResponse) {
            onComplete?.invoke()
            return
        }
        
        val queueEmotion = mapToQueueEmotion(emotion)
        ttsQueueManager.enqueue(
            text = text,
            priority = TTSQueueManager.Priority.URGENT,
            emotion = queueEmotion,
            onComplete = onComplete
        )
    }
    
    /**
     * 🔊 高优先级语音播放（不中断，但优先播放）
     */
    fun speakHighPriority(
        text: String,
        emotion: Emotion = Emotion.NEUTRAL,
        onComplete: (() -> Unit)? = null
    ) {
        if (!enableTTSResponse) {
            onComplete?.invoke()
            return
        }
        
        val queueEmotion = mapToQueueEmotion(emotion)
        ttsQueueManager.enqueue(
            text = text,
            priority = TTSQueueManager.Priority.HIGH,
            emotion = queueEmotion,
            onComplete = onComplete
        )
    }
    
    /**
     * 🔊 旧版speak方法（兼容性保留，内部使用）
     */
    @Deprecated("Use speak() with queue management instead")
    private fun speakLegacy(
        text: String,
        emotion: Emotion = Emotion.NEUTRAL,
        onComplete: (() -> Unit)? = null
    ) {
        val speed = config.voiceSpeed
        val wasWakeWordDetectionActive = wakeWordDetectionActive || isRecording
        voskRecognizer.setStartSuppressed(true)

        val wasListening = _state.value == VoiceState.LISTENING
        if (wasListening) {
            LogManager.d(TAG, "🔇 播报前完全停止语音识别，防止识别自己的声音...")
            stopListening(disableContinuous = false)
        }
        if (wasWakeWordDetectionActive) {
            LogManager.d(TAG, "🔇 播报前停止唤醒词检测，防止误触发...")
            stopWakeWordDetection()
        }
        
        _state.value = VoiceState.SPEAKING
        isTTSSpeaking = true
        ttsStartTime = System.currentTimeMillis()
        
        recordSpokenText(text)
        smartVoiceFilter.recordSpokenText(text)
        smartVoiceFilter.updateTTSState(isSpeaking = true)
        
        val wrappedOnComplete: (() -> Unit) = {
            _state.value = VoiceState.IDLE
            onComplete?.invoke()
            
            isTTSSpeaking = false
            ttsEndTime = System.currentTimeMillis()
            smartVoiceFilter.updateTTSState(isSpeaking = false)
            
            if (config.continuousListening) {
                LogManager.d(TAG, "🎤 [实时对话模式] 播报完成，等待冷却后恢复语音识别...")
                mainScope.launch {
                    val cooldownTime = TTS_COOLDOWN_SHORT_MS
                    delay(cooldownTime)
                    voskRecognizer.setStartSuppressed(false)
                    resumeListeningAfterSpeaking()
                }
            } else {
                if (wasWakeWordDetectionActive && config.enableWakeWord && !config.continuousListening) {
                    LogManager.d(TAG, "🎤 [唤醒词检测模式] 播报完成，等待冷却后恢复唤醒词检测...")
                    mainScope.launch {
                        delay(TTS_COOLDOWN_MS)
                        if (!isTTSSpeaking && config.enableWakeWord && !config.continuousListening) {
                            voskRecognizer.setStartSuppressed(false)
                            startWakeWordDetection()
                        }
                    }
                } else {
                    LogManager.d(TAG, "📝 [单次识别模式] 播报完成，不自动恢复监听")

                    mainScope.launch {
                        delay(TTS_COOLDOWN_MS)
                        if (!isTTSSpeaking) {
                            voskRecognizer.setStartSuppressed(false)
                        }
                    }
                }
            }
        }
        
        // 根据用户选择的引擎播放
        when {
            // 1. 在线 TTS
            useOnlineTTS && onlineTTS.isReady() -> {
                LogManager.d(TAG, "🌐 使用在线TTS播放: $text")
                mainScope.launch {
                    val success = onlineTTS.speak(
                        text = text,
                        speed = config.voiceSpeed,
                        pitch = config.voicePitch,
                        onStart = null,
                        onDone = { wrappedOnComplete() },
                        onError = { error ->
                            LogManager.w(TAG, "⚠️ 在线TTS失败: $error，回退到系统TTS")
                            speakWithSystemTTSInternal(text, emotion, speed, wrappedOnComplete)
                        }
                    )
                    if (!success) {
                        LogManager.w(TAG, "⚠️ 在线TTS启动失败，回退到系统TTS")
                        speakWithSystemTTSInternal(text, emotion, speed, wrappedOnComplete)
                    }
                }
            }
            // 2. 本地 Supertonic TTS
            useSupertonicTTS && supertonicTTS.isReady() -> {
                LogManager.d(TAG, "🎵 使用Supertonic TTS播放: $text")
                
                // 根据情绪选择语音风格
                val voiceStyle = when (emotion) {
                    Emotion.HAPPY, Emotion.EXCITED -> "F1" // 活泼女声
                    Emotion.SAD, Emotion.TIRED -> "F2" // 温柔女声
                    Emotion.ANGRY -> "M1" // 有力男声
                    else -> "F1" // 默认女声
                }
                
                mainScope.launch {
                    val success = supertonicTTS.speak(text, voiceStyle)
                    if (success) {
                        wrappedOnComplete()
                    } else {
                        LogManager.w(TAG, "⚠️ Supertonic TTS播放失败，回退到系统TTS")
                        speakWithSystemTTSInternal(text, emotion, speed, wrappedOnComplete)
                    }
                }
            }
            // 3. 系统 TTS
            else -> {
                speakWithSystemTTSInternal(text, emotion, speed, wrappedOnComplete)
            }
        }
    }
    
    /**
     * 🔇 暂停语音识别（用于播报时）
     */
    private fun pauseListeningForSpeaking() {
        try {
            if (useOfflineRecognizer) {
                voskRecognizer.stopListening()
            } else {
                speechRecognizer?.stopListening()
            }
            LogManager.d(TAG, "🔇 语音识别已暂停")
        } catch (e: Exception) {
            LogManager.e(TAG, "暂停语音识别失败", e)
        }
    }
    
    /**
     * 🎤 恢复语音识别（播报完成后）
     */
    private fun resumeListeningAfterSpeaking() {
        if (_state.value == VoiceState.SPEAKING) return // 还在播报中
        
        LogManager.d(TAG, "🎤 尝试恢复语音识别，持续模式: ${config.continuousListening}")

        if (config.continuousListening) {
            val audioStatus = audioPlaybackMonitor.getAudioStatusSummary()
            if (!audioStatus.isSafeForVoiceRecognition()) {
                pausedByExternalPlayback = true
                LogManager.w(TAG, "🔇 [实时对话] 播报结束后环境不安全，保持暂停: ${audioStatus.getFilterReason()}")
                maybeShowRealtimeSuppressedToast(audioStatus.getFilterReason())
                requestRealtimeAudioFocus()
                voskRecognizer.setStartSuppressed(true)
                return
            }
        }
        
        try {
            if (config.continuousListening) {
                if (useOfflineRecognizer) {
                    voskRecognizer.continuousListening = true
                }
                smartVoiceFilter.setRealTimeMode(true)
            }

            startListening()
        } catch (e: Exception) {
            LogManager.e(TAG, "恢复语音识别失败", e)
            // 尝试强制重启
            if (useOfflineRecognizer) {
                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                    if (config.continuousListening) {
                        startListening()
                    }
                }, 300)
            }
        }
    }
    
    /**
     * 使用系统TTS播放（内部方法，支持回调）
     */
    private fun speakWithSystemTTSInternal(
        text: String,
        emotion: Emotion,
        speed: Float,
        onComplete: (() -> Unit)?
    ) {
        if (!isTtsInitialized) {
            LogManager.e(TAG, "❌ 系统TTS未初始化，无法播报！请检查手机是否安装了中文语音包")
            onComplete?.invoke()
            return
        }
        
        LogManager.d(TAG, "🔊 使用系统TTS播放: ${text.take(50)}... (语速: $speed)")
        
        // 🎯 设置智能语速
        textToSpeech?.setSpeechRate(speed)
        
        // 根据情绪调整语音参数（音调）
        adjustVoiceForEmotion(emotion)
        
        // 生成唯一ID
        val utteranceId = "utterance_${System.currentTimeMillis()}"
        
        // 设置完成回调
        textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                LogManager.d(TAG, "开始播放: $text")
            }
            
            override fun onDone(utteranceId: String?) {
                onComplete?.invoke()
                LogManager.d(TAG, "播放完成")
            }
            
            override fun onError(utteranceId: String?) {
                _state.value = VoiceState.ERROR
                onComplete?.invoke()
                LogManager.e(TAG, "播放失败")
            }
        })
        
        // 开始播放
        val params = Bundle()
        params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
        
        textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
    }
    
    /**
     * 🎯 处理语音命令
     */
    fun processVoiceCommand(text: String) {
        LogManager.d(TAG, "🎤 处理语音命令: $text")
        try {
        
        // 🗣️ 更新用户发言时间（用于主动对话系统）
        try {
            com.example.xihe.core.ModuleCoordinator.updateUserSpeechTime()
        } catch (e: Exception) {
            // 忽略错误，不影响主流程
        }
        
        // 🆕 实时对话模式下，设置 SmartVoiceFilter 为实时模式
        smartVoiceFilter.setRealTimeMode(config.continuousListening)
        
        // 🎤 使用智能语音过滤器进行过滤
        val filterResult = smartVoiceFilter.filterVoiceInput(text)
        if (filterResult.shouldFilter) {
            LogManager.d(TAG, "🔇 语音被过滤: ${filterResult.getReasonDescription()}")
            // 🆕 即使被过滤，在实时对话模式下也要继续监听
            if (config.continuousListening) {
                _state.value = VoiceState.LISTENING
            }
            return
        }
        
        // 🔇 额外的回声过滤（基于播报历史）- 实时模式下放宽阈值
        if (isLikelyEcho(text)) {
            LogManager.d(TAG, "🔇 忽略识别结果：检测到回声 - $text")
            if (config.continuousListening) {
                _state.value = VoiceState.LISTENING
            }
            return
        }
        
        // 🔇 过滤可能是视频/音乐/其他应用的声音
        if (isLikelyMediaPlayback(text)) {
            LogManager.d(TAG, "🔇 忽略识别结果：疑似媒体播放声音 - $text")
            lastAudioPlaybackTime = System.currentTimeMillis()
            if (config.continuousListening) {
                _state.value = VoiceState.LISTENING
            }
            return
        }
        
        _state.value = VoiceState.PROCESSING
        
        // 🆕 检测情绪（使用新的情绪识别系统）
        val emotionState = emotionRecognizer.recognizeEmotion(
            voiceText = text
        )
        val emotion = emotionState.emotion
        
        // 🎤 检查是否是唤醒词
        val containsWakeWord = isWakeWord(text)
        val isOnlyWake = isOnlyWakeWord(text)
        
        // 🆕 检查是否是常用短语
        val isCommonPhrase = isCommonPhrase(text)
        
        // 🆕 如果处于唤醒词检测模式（等待唤醒），只处理唤醒词和常用短语，忽略其他语音
        if (config.enableWakeWord && !config.continuousListening && !containsWakeWord && !isCommonPhrase) {
            LogManager.d(TAG, "🔇 唤醒词检测模式：忽略非唤醒词语音 - $text")
            _state.value = VoiceState.LISTENING  // 继续监听
            return
        }
        
        if (containsWakeWord) {
            // 🔇 唤醒词冷却检测：防止重复触发
            val timeSinceLastWake = System.currentTimeMillis() - lastWakeWordTime
            if (lastWakeWordTime > 0 && timeSinceLastWake < WAKE_WORD_COOLDOWN_MS) {
                LogManager.d(TAG, "🔇 忽略唤醒词：冷却中 (${timeSinceLastWake}ms < ${WAKE_WORD_COOLDOWN_MS}ms)")
                return
            }
            
            lastWakeWordTime = System.currentTimeMillis()
            LogManager.i(TAG, "🎉 检测到唤醒词!")
            
            // 🔐 声纹验证（如果启用）
            val voiceprintResult = VoiceprintManager.getEnrolledUsers().isNotEmpty()
            if (voiceprintResult) {
                // 有注册用户，需要验证声纹
                // 注意：这里使用简化逻辑，实际应传入音频数据
                LogManager.d(TAG, "🔐 声纹验证中...")
                // 暂时跳过验证，后续可以添加完整验证逻辑
            }
            
            onWakeWordDetected?.invoke()
            // 触发全局唤醒词回调（用于后台服务）
            com.example.xihe.core.ModuleCoordinator.triggerWakeWordDetected()
            
            if (isOnlyWake) {
                // 仅仅是唤醒词，回应用户并继续监听
                LogManager.d(TAG, "📢 仅唤醒词，播放回应...")
                val response = getRandomWakeResponse()
                speak(response, Emotion.HAPPY) {
                    // 回应完毕后继续监听用户指令
                    LogManager.d(TAG, "🎤 回应完毕，继续监听...")
                    if (config.continuousListening || config.enableWakeWord) {
                        startListening()
                    }
                }
                _state.value = VoiceState.SPEAKING
                return
            } else {
                // 唤醒词 + 指令，提取指令并处理
                val commandText = extractCommandAfterWakeWord(text)
                if (commandText != null) {
                    LogManager.d(TAG, "📝 提取到指令: $commandText")
                    // 先回应用户，回应完毕后继续监听
                    speak("好的，主人！", Emotion.HAPPY) {
                        // 🔄 回应完毕后继续监听
                        if (config.continuousListening) {
                            LogManager.d(TAG, "🎤 处理指令完成，继续监听...")
                            startListening()
                        }
                    }
                    // 然后处理指令
                    val command = VoiceCommand(
                        text = commandText,
                        confidence = 0.9f,
                        emotion = null,  // 暂时使用null
                        isWakeWord = true
                    )
                    _lastCommand.value = command
                    onCommandReceived?.invoke(command)
                    return
                }
            }
        }
        
        // 普通语音命令（无唤醒词）
        val command = VoiceCommand(
            text = text,
            confidence = 0.9f,
            emotion = null,  // 暂时使用null  
            isWakeWord = false
        )
        
        _lastCommand.value = command
        
        // 🆕 生成情绪化响应建议
        val emotionalResponse = emotionRecognizer.generateEmotionalResponse(emotion)
        LogManager.d(TAG, "🎭 情绪响应: ${emotionalResponse.tone} - ${emotionalResponse.emoji}")
        
        // 回调处理
        onCommandReceived?.invoke(command)
        
        _state.value = VoiceState.IDLE
        
        // 如果开启连续监听，继续监听
        if (config.continuousListening) {
            mainScope.launch {
                delay(500) // 短暂延迟
                startListening()
            }
        }
        } finally {
            resumeExternalPlaybackIfNeeded(text)
        }
    }
    
    /**
     * 🌟 语音快捷命令
     */
    fun executeQuickCommand(command: String): Boolean {
        val quickCommands = mapOf(
            "打开微信" to "launch_wechat",
            "返回" to "go_back",
            "主页" to "go_home",
            "截图" to "take_screenshot",
            "音量增大" to "volume_up",
            "音量减小" to "volume_down",
            "打开设置" to "open_settings",
            "关闭应用" to "close_app"
        )
        
        val action = quickCommands[command]
        if (action != null) {
            LogManager.d(TAG, "执行快捷命令: $command -> $action")
            // 这里调用实际的执行逻辑
            return true
        }
        
        return false
    }
    
    // ==================== 私有方法 ====================
    
    /**
     * 检查录音权限
     */
    private fun checkAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }
    
    /**
     * 👂 处理音频原始数据（用于噪声过滤）
     */
    fun processAudioBuffer(buffer: ShortArray): Boolean {
        // 计算 RMS 振幅
        var sum = 0.0
        for (sample in buffer) {
            sum += sample * sample
        }
        val rms = Math.sqrt(sum / buffer.size)
        
        // 门限值：低于 30.0 视为背景噪音或静音 (根据实际测试调整)
        val noiseFloor = 30.0
        val isActive = rms > noiseFloor
        
        if (!isActive) {
            // LogManager.v(TAG, "🤫 环境静默 (RMS: $rms)，跳过处理")
        }
        return isActive
    }

    /**
     * 🧹 语音指令预处理（清理口语助词）
     */
    private fun cleanCommandText(text: String): String {
        val fillers = listOf("那个", "额", "呃", "然后", "的话", "就", "这样", "那个啥")
        var cleaned = text
        fillers.forEach { filler ->
            cleaned = cleaned.replace(filler, "")
        }
        return cleaned.trim()
    }
    
    /**
     * 📱 初始化系统语音识别器
     */
    private fun initializeSpeechRecognizer() {
        LogManager.d(TAG, "📱 初始化系统语音识别器...")
        
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            LogManager.e(TAG, "❌ 系统语音识别不可用！此设备可能不支持或缺少 Google 服务")
            return
        }
        
        LogManager.d(TAG, "✅ 系统语音识别可用")
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)
        
        // 设置识别参数
        recognitionIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, config.language.toString())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            // 🔇 尝试使用安静模式，减少系统声音干扰
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
        }
        
        // 设置识别监听器
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                LogManager.d(TAG, "准备接收语音")
            }
            
            override fun onBeginningOfSpeech() {
                LogManager.d(TAG, "开始说话")
            }
            
            override fun onRmsChanged(rmsdB: Float) {
                // 音量变化
            }
            
            override fun onBufferReceived(buffer: ByteArray?) {
                // 接收到音频数据
            }
            
            override fun onEndOfSpeech() {
                LogManager.d(TAG, "说话结束")
                _state.value = VoiceState.PROCESSING
            }
            
            override fun onError(error: Int) {
                val errorMsg = when (error) {
                    SpeechRecognizer.ERROR_AUDIO -> "音频录制错误"
                    SpeechRecognizer.ERROR_CLIENT -> "客户端错误"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "权限不足"
                    SpeechRecognizer.ERROR_NETWORK -> "网络错误"
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "网络超时"
                    SpeechRecognizer.ERROR_NO_MATCH -> "未识别到语音"
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "识别器忙"
                    SpeechRecognizer.ERROR_SERVER -> "服务器错误"
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "语音超时"
                    else -> "未知错误: $error"
                }
                LogManager.e(TAG, "语音识别错误: $errorMsg")
                _state.value = VoiceState.ERROR
                
                // 如果是无匹配或超时，且开启了连续监听，则重新开始
                if (config.continuousListening &&
                    (error == SpeechRecognizer.ERROR_NO_MATCH ||
                     error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)) {
                    restartListening()
                }

                // 如果是“唤醒词检测模式”，也需要持续重启以保持监听
                if (!config.continuousListening && wakeWordDetectionActive && config.enableWakeWord &&
                    (error == SpeechRecognizer.ERROR_NO_MATCH ||
                     error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)) {
                    restartListening()
                }

                if (!config.continuousListening) {
                    resumeExternalPlaybackIfNeeded()
                }
            }
            
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val scores = results?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)
                
                if (!matches.isNullOrEmpty()) {
                    val bestMatch = matches[0]
                    val confidence = scores?.getOrNull(0) ?: 0.5f
                    
                    LogManager.d(TAG, "识别结果: $bestMatch (置信度: $confidence)")
                    _partialRecognitionResult.value = "" // 清除
                    handleVoiceInput(bestMatch)
                    
                    // 如果开启连续监听，继续监听
                    if (config.continuousListening) {
                        restartListening()
                    }

                    // 如果处于“唤醒词检测模式”，也要持续监听
                    if (!config.continuousListening && wakeWordDetectionActive && config.enableWakeWord) {
                        restartListening()
                    }
                }
            }
            
            override fun onPartialResults(partialResults: Bundle?) {
                val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!partial.isNullOrEmpty()) {
                    // LogManager.d(TAG, "部分结果: ${partial[0]}")
                    _partialRecognitionResult.value = partial[0]
                    handleSpeechActivityForMediaPause(partial[0])
                }
            }
            
            override fun onEvent(eventType: Int, params: Bundle?) {
                // 其他事件
            }
        })
    }
    
    /**
     * 初始化语音合成
     */
    private fun initializeTextToSpeech() {
        LogManager.d(TAG, "📢 开始初始化系统TTS...")
        textToSpeech = TextToSpeech(context) { status ->
            LogManager.d(TAG, "📢 系统TTS初始化回调: status=$status")
            if (status == TextToSpeech.SUCCESS) {
                val result = textToSpeech?.setLanguage(config.language)
                LogManager.d(TAG, "📢 设置语言结果: $result (语言: ${config.language})")
                
                if (result == TextToSpeech.LANG_MISSING_DATA || 
                    result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    LogManager.e(TAG, "❌ 系统TTS语言不支持: ${config.language}")
                    LogManager.w(TAG, "💡 请在手机设置中下载中文语音包：设置 → 语言和输入 → 文字转语音 → 下载语音数据")
                    
                    // 尝试使用默认语言
                    val defaultResult = textToSpeech?.setLanguage(java.util.Locale.getDefault())
                    if (defaultResult != TextToSpeech.LANG_MISSING_DATA && 
                        defaultResult != TextToSpeech.LANG_NOT_SUPPORTED) {
                        isTtsInitialized = true
                        LogManager.w(TAG, "⚠️ 使用默认语言作为回退")
                    }
                } else {
                    isTtsInitialized = true
                    // 设置默认语速和音调
                    textToSpeech?.setSpeechRate(config.voiceSpeed)
                    textToSpeech?.setPitch(config.voicePitch)
                    LogManager.i(TAG, "✅ 系统TTS初始化成功")
                }
            } else {
                LogManager.e(TAG, "❌ 系统TTS初始化失败: status=$status")
                LogManager.w(TAG, "💡 请检查手机是否安装了TTS引擎（如Google TTS或讯飞TTS）")
            }
        }
    }
    
    /**
     * 🎤 开始唤醒词检测（持续监听模式）
     * 使用 Vosk 语音识别来检测唤醒词，比能量检测更准确
     */
    fun startWakeWordDetection() {
        if (!checkAudioPermission()) return

        // 🔇 TTS 播报期间/冷却期禁止启动唤醒词检测
        if (isTTSSpeaking) {
            LogManager.d(TAG, "🔇 正在播报中，跳过启动唤醒词检测")
            return
        }
        val now = System.currentTimeMillis()
        val cooldown = if (config.continuousListening) TTS_COOLDOWN_SHORT_MS else TTS_COOLDOWN_MS
        if (ttsEndTime > 0 && now - ttsEndTime < cooldown) {
            LogManager.d(TAG, "🔇 TTS冷却期(${cooldown}ms)内，跳过启动唤醒词检测")
            return
        }
        
        LogManager.i(TAG, "🎤 启动唤醒词持续监听模式...")

        wakeWordDetectionActive = true
        
        // 使用 Vosk 持续监听来检测唤醒词
        if (useOfflineRecognizer && voskRecognizer.state.value == VoskOfflineRecognizer.State.READY) {
            LogManager.d(TAG, "🎤 使用 Vosk 进行唤醒词检测")
            voskRecognizer.startListening()
            _state.value = VoiceState.LISTENING
        } else {
            // 如果 Vosk 不可用，优先使用系统识别器来做“唤醒词检测模式”
            LogManager.w(TAG, "⚠️ Vosk 不可用，尝试使用系统语音识别器进行唤醒词检测")
            if (speechRecognizer == null) {
                initializeSpeechRecognizer()
            }
            if (speechRecognizer != null) {
                _state.value = VoiceState.LISTENING
                speechRecognizer?.startListening(recognitionIntent)
            } else {
                // 最后兜底：能量检测（仅用于触发后续识别逻辑）
                LogManager.w(TAG, "⚠️ 系统语音识别器不可用，使用能量检测作为最后兜底")
                startAudioEnergyDetection()
            }
        }
        
        LogManager.d(TAG, "✅ 唤醒词检测已启动")
    }
    
    /**
     * 🎤 开始音频能量检测（备用方案）
     */
    private fun startAudioEnergyDetection() {
        if (!checkAudioPermission()) return

        wakeWordDetectionActive = true
        _state.value = VoiceState.LISTENING
        
        val bufferSize = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        
        // 🔇 使用 VOICE_COMMUNICATION 音频源（优化版）
        // VOICE_COMMUNICATION 比 VOICE_RECOGNITION 更好：
        // 1. 自动启用回声消除(AEC) - 避免捕获扬声器播放的声音
        // 2. 自动启用噪音抑制(NS) - 过滤环境噪音
        // 3. 自动启用自动增益控制(AGC) - 调整音量
        // 4. 专门为实时通话设计，更适合语音助手场景
        audioRecord = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,  // 优先使用 VOICE_COMMUNICATION
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )
        } catch (e: Exception) {
            LogManager.w(TAG, "⚠️ VOICE_COMMUNICATION 不可用，回退到 VOICE_RECOGNITION", e)
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,  // 备用方案
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )
        }

        // 🔇 初始化 AEC/NS/AGC（如果设备支持）
        try {
            audioRecord?.audioSessionId?.let { sessionId ->
                echoCancellationManager.initialize(sessionId)
                echoCancellationManager.setEchoCancelerEnabled(config.enableNoiseSuppression)
                echoCancellationManager.setNoiseSuppressorEnabled(config.enableNoiseSuppression)
                echoCancellationManager.setGainControlEnabled(config.enableNoiseSuppression)
            }
        } catch (e: Exception) {
            LogManager.w(TAG, "⚠️ 初始化回声消除失败: ${e.message}")
        }
        
        isRecording = true
        audioRecord?.startRecording()
        
        // 在协程中处理音频数据
        recordingScope.launch {
            val buffer = ShortArray(bufferSize)
            
            while (isRecording) {
                // 🔇 播报期间/刚结束时，暂停能量检测，避免把系统播报误判为唤醒
                if (isTTSSpeaking) {
                    delay(200)
                    continue
                }
                val now = System.currentTimeMillis()
                if (ttsEndTime > 0 && now - ttsEndTime < TTS_COOLDOWN_MS) {
                    delay(200)
                    continue
                }

                val readSize = audioRecord?.read(buffer, 0, bufferSize) ?: 0
                if (readSize > 0) {
                    if (detectWakeWordInAudio(buffer, readSize)) {
                        withContext(Dispatchers.Main) {
                            // 检测到语音活动，启动 Vosk 进行实际识别
                            if (useOfflineRecognizer) {
                                voskRecognizer.startListening()
                            }
                            onWakeWordDetected?.invoke()
                        }
                    }
                }
                delay(100)
            }
        }
    }
    
    /**
     * 🎤 启动持续监听模式（唤醒词检测）
     * 注意：这是"等待唤醒词"的模式，只监听唤醒词，不处理其他语音
     */
    fun startContinuousListening() {
        if (isTTSSpeaking) {
            LogManager.d(TAG, "🔇 正在播报中，跳过启动唤醒词检测模式")
            return
        }
        val now = System.currentTimeMillis()
        val cooldown = if (config.continuousListening) TTS_COOLDOWN_SHORT_MS else TTS_COOLDOWN_MS
        if (ttsEndTime > 0 && now - ttsEndTime < cooldown) {
            LogManager.d(TAG, "🔇 TTS冷却期(${cooldown}ms)内，跳过启动唤醒词检测模式")
            return
        }
        LogManager.i(TAG, "🎤 启动唤醒词检测模式（只监听唤醒词）")
        // 🆕 重要：continuousListening=false 表示只等待唤醒词，不处理其他语音
        config = config.copy(continuousListening = false, enableWakeWord = true)
        
        // 🔧 先确保完全停止之前的识别
        stopWakeWordDetection()
        if (useOfflineRecognizer) {
            voskRecognizer.stopListening()
        } else {
            speechRecognizer?.stopListening()
        }
        
        // 🔄 延迟后启动，避免状态冲突
        mainScope.launch {
            delay(300)
            startWakeWordDetection()
        }
    }
    
    /**
     * 🛑 停止持续监听模式
     */
    fun stopContinuousListening() {
        LogManager.i(TAG, "🛑 停止持续监听模式")
        config = config.copy(continuousListening = false)
        stopWakeWordDetection()
    }
    
    /**
     * 🛑 停止唤醒词检测
     */
    fun stopWakeWordDetection() {
        wakeWordDetectionActive = false
        isRecording = false

        try {
            audioRecord?.stop()
        } catch (_: Exception) {
        }
        try {
            audioRecord?.release()
        } catch (_: Exception) {
        }
        audioRecord = null

        try {
            speechRecognizer?.stopListening()
        } catch (_: Exception) {
        }
        
        if (useOfflineRecognizer) {
            voskRecognizer.stopListening()
        }
        
        _state.value = VoiceState.IDLE
        LogManager.d(TAG, "🛑 唤醒词检测已停止")
    }
    
    /**
     * 🔊 设置 TTS 引擎类型
     */
    fun setTTSEngine(engine: TTSEngine) {
        val prefs = context.getSharedPreferences("voice_settings", android.content.Context.MODE_PRIVATE)
        
        when (engine) {
            TTSEngine.LOCAL -> {
                userPrefersLocalTTS = true
                useOnlineTTS = false
                useSupertonicTTS = supertonicTTS.isReady()
                prefs.edit().putString("tts_engine_type", "local").apply()
                LogManager.i(TAG, "🔊 切换到本地TTS引擎")
            }
            TTSEngine.ONLINE -> {
                userPrefersLocalTTS = false
                useOnlineTTS = true
                useSupertonicTTS = false
                onlineTTS.initialize()
                prefs.edit().putString("tts_engine_type", "online").apply()
                LogManager.i(TAG, "🌐 切换到在线TTS引擎")
            }
            TTSEngine.SYSTEM -> {
                userPrefersLocalTTS = false
                useOnlineTTS = false
                useSupertonicTTS = false
                prefs.edit().putString("tts_engine_type", "system").apply()
                LogManager.i(TAG, "📱 切换到系统TTS引擎")
            }
        }
    }
    
    /**
     * 🔊 获取当前 TTS 引擎类型
     */
    fun getCurrentTTSEngine(): TTSEngine {
        return when {
            useOnlineTTS && onlineTTS.isReady() -> TTSEngine.ONLINE
            useSupertonicTTS && supertonicTTS.isReady() -> TTSEngine.LOCAL
            else -> TTSEngine.SYSTEM
        }
    }
    
    /**
     * 🔊 设置是否使用本地TTS (兼容旧接口)
     */
    fun setUseLocalTTS(enabled: Boolean) {
        if (enabled) {
            setTTSEngine(TTSEngine.LOCAL)
        } else {
            setTTSEngine(TTSEngine.SYSTEM)
        }
    }
    
    /**
     * 🔊 获取是否使用本地TTS
     */
    fun isUsingLocalTTS(): Boolean = useSupertonicTTS
    
    // 🎵 语音活动检测状态
    private var consecutiveVoiceFrames = 0
    private val VOICE_FRAMES_THRESHOLD = 3  // 连续3帧语音活动才触发
    private var lastVoiceActivityTime = 0L
    private val VOICE_ACTIVITY_COOLDOWN = 2000L  // 语音活动检测冷却时间
    
    /**
     * 检测音频中的语音活动（用于触发Vosk识别）
     * 注：这是能量检测的备用方案，主要通过Vosk文本匹配检测唤醒词
     */
    private fun detectWakeWordInAudio(buffer: ShortArray, size: Int): Boolean {
        // 🔇 冷却期检测
        val now = System.currentTimeMillis()
        if (now - lastVoiceActivityTime < VOICE_ACTIVITY_COOLDOWN) {
            return false
        }
        
        // 1. 计算音频能量 (RMS)
        var sumSquares = 0.0
        for (i in 0 until size) {
            sumSquares += buffer[i].toDouble() * buffer[i].toDouble()
        }
        val rms = kotlin.math.sqrt(sumSquares / size)
        
        // 2. 能量阈值检测（动态调整）
        val energyThreshold = 800.0  // 降低阈值，提高灵敏度
        if (rms < energyThreshold) {
            consecutiveVoiceFrames = 0
            return false
        }
        
        // 3. 计算过零率 (ZCR)
        var zeroCrossings = 0
        for (i in 1 until size) {
            if ((buffer[i] >= 0 && buffer[i-1] < 0) || 
                (buffer[i] < 0 && buffer[i-1] >= 0)) {
                zeroCrossings++
            }
        }
        val zcr = zeroCrossings.toDouble() / size
        
        // 4. 语音活动检测（ZCR在语音范围内）
        // 语音ZCR通常在0.02-0.25之间
        val isVoiceLike = zcr > 0.02 && zcr < 0.25
        
        if (rms > energyThreshold && isVoiceLike) {
            consecutiveVoiceFrames++
            
            // 连续多帧检测到语音活动，触发Vosk识别
            if (consecutiveVoiceFrames >= VOICE_FRAMES_THRESHOLD) {
                LogManager.d(TAG, "🎵 检测到语音活动 - RMS: ${rms.toInt()}, ZCR: ${String.format("%.3f", zcr)}, 连续帧: $consecutiveVoiceFrames")
                consecutiveVoiceFrames = 0
                lastVoiceActivityTime = now
                return true
            }
        } else {
            consecutiveVoiceFrames = 0
        }
        
        return false
    }
    
    /**
     * 🎤 检测是否包含唤醒词
     */
    private fun isWakeWord(text: String): Boolean {
        val normalizedText = text.replace(" ", "").lowercase()
        return WAKE_WORDS.any { wakeWord ->
            normalizedText.contains(wakeWord.lowercase())
        }
    }
    
    /**
     * 🎤 检测是否仅是唤醒词（不包含其他指令）
     */
    private fun isOnlyWakeWord(text: String): Boolean {
        val normalizedText = text.replace(" ", "").lowercase()
        return WAKE_WORDS.any { wakeWord ->
            normalizedText == wakeWord.lowercase() ||
            normalizedText == "你好${wakeWord.lowercase()}" ||
            normalizedText == "${wakeWord.lowercase()}你好"
        }
    }
    
    /**
     * 🗣️ 检测是否包含常用短语
     */
    private fun isCommonPhrase(text: String): Boolean {
        val trimmedText = text.trim()
        return COMMON_PHRASES.any { phrase ->
            trimmedText.contains(phrase)
        }
    }
    
    /**
     * 🎤 提取唤醒词后的指令
     */
    private fun extractCommandAfterWakeWord(text: String): String? {
        val normalizedText = text.replace(" ", "")
        for (wakeWord in WAKE_WORDS) {
            val patterns = listOf(
                wakeWord,
                "你好$wakeWord",
                "${wakeWord}你好",
                "嘿$wakeWord",
                "喂$wakeWord"
            )
            for (pattern in patterns) {
                if (normalizedText.contains(pattern, ignoreCase = true)) {
                    val remaining = normalizedText.replace(pattern, "", ignoreCase = true).trim()
                    if (remaining.isNotEmpty()) {
                        return remaining
                    }
                }
            }
        }
        return null
    }
    
    /**
     * 🎉 获取随机唤醒词回应
     */
    private fun getRandomWakeResponse(): String {
        return WAKE_RESPONSES.random()
    }
    
    /**
     * 🔇 检测是否可能是视频/音乐/其他应用的声音
     * 通过检测常见的媒体内容特征和系统音频状态来过滤
     */
    private fun isLikelyMediaPlayback(text: String): Boolean {
        // 🎵 先检查系统音频播放状态
        val audioStatus = audioPlaybackMonitor.getAudioStatusSummary()
        
        // 如果连接了耳机，不需要过滤系统声音（声音不会被麦克风捕获）
        if (audioStatus.isHeadsetConnected) {
            LogManager.d(TAG, "🎧 耳机已连接，不过滤系统声音")
        } else {
            // 没有耳机，检测是否有媒体播放
            if (audioStatus.isMediaPlaying || audioStatus.isMusicActive) {
                LogManager.d(TAG, "🔊 检测到系统音频播放，标记为媒体内容")
                return true
            }
        }
        
        // 🆕 如果是常用短语，直接通过
        if (isCommonPhrase(text)) {
            LogManager.d(TAG, "✅ 检测到常用短语，允许通过: $text")
            return false
        }
        
        // 检测是否包含用户指令关键词（优先级高）
        val userCommandKeywords = listOf(
            "羲和", "小羲", "打开", "关闭", "播放", "暂停", "查询", "搜索",
            "帮我", "请问", "什么", "怎么", "为什么", "在哪", "哪里",
            "设置", "调整", "显示", "取消", "确认", "返回", "退出"
        )
        val normalizedTextForCmd = text.replace(" ", "").lowercase()
        if (userCommandKeywords.any { normalizedTextForCmd.contains(it.lowercase()) }) {
            LogManager.d(TAG, "✅ 检测到用户指令关键词，允许通过: $text")
            return false
        }
        
        // 🆕 文本太短（小于2个字），可能是噪音
        if (text.length < 2) {
            LogManager.d(TAG, "🔇 文本过短，视为噪音: $text")
            return true
        }
        
        // 🔇 只有单个字或两个字的重复，很可能是背景音
        if (text.length <= 4) {
            val trimmed = text.trim()
            if (trimmed.isNotEmpty() && (trimmed.all { it == trimmed[0] } || trimmed.matches(Regex("^(.)\\1+$")))) {
                LogManager.d(TAG, "🔇 检测到单字重复，视为噪音: $text")
                return true
            }
        }
        
        // 常见的视频/直播/音乐关键词（扩展版）
        val mediaKeywords = listOf(
            // 直播相关
            "点赞", "关注", "双击", "666", "牛逼", "厉害", "棒", "哇塞",
            "老铁", "家人们", "宝宝", "宝贝", "亲", "兄弟", "姐妹",
            "走一波", "刷起来", "礼物", "火箭", "点点",
            // 音乐相关
            "喔", "啊啊", "哦哦", "嘿嘿", "哈哈", "呜呜", "耶耶",
            "lalala", "nanana", "哎呀呀", "呀呀呀", "噢噢",
            // 广告相关
            "买买", "便宜", "特价", "促销", "限时", "包邮", "秒杀",
            "加微信", "扫码", "下单", "链接", "优惠券",
            // 其他常见噪音
            "啦啦", "呐呐", "咿呀", "嘻嘻", "嗯嗯", "唔唔",
            // 教育/讲解类视频
            "同学们", "小朋友们", "观众朋友",
            // 新闻/播报类
            "据报道", "记者了解", "本台记者"
        )
        
        val normalizedText = text.replace(" ", "").lowercase()
        
        // 检测是否包含媒体关键词
        for (keyword in mediaKeywords) {
            if (normalizedText.contains(keyword.lowercase())) {
                LogManager.d(TAG, "🔇 检测到媒体关键词: $keyword")
                return true
            }
        }
        
        // 检测是否全是重复字符（如"啊啊啊啊"、"哈哈哈"）
        if (text.length >= 3) {
            val uniqueChars = text.toSet().size
            if (uniqueChars <= 2) {
                LogManager.d(TAG, "🔇 检测到重复字符模式")
                return true
            }
        }
        
        return false
    }
    
    /**
     * 🔇 检测是否可能是系统播报的回声
     * 通过检测常见的AI回复模式和最近播报内容来过滤
     */
    private fun isLikelyEcho(text: String): Boolean {
        // 🎤 智能回声检测：检查是否与最近播报的内容相似
        val normalizedInput = text.replace(" ", "").lowercase()
        
        for (spokenText in lastSpokenTexts) {
            val normalizedSpoken = spokenText.replace(" ", "").lowercase()
            
            // 完全匹配
            if (normalizedInput == normalizedSpoken) {
                LogManager.d(TAG, "🔇 检测到完全匹配的回声: $text")
                return true
            }
            
            // 部分匹配（输入是播报内容的子串，或播报内容是输入的子串）
            if (normalizedInput.length >= 4) {
                if (normalizedSpoken.contains(normalizedInput) || normalizedInput.contains(normalizedSpoken)) {
                    // 计算相似度
                    val similarity = calculateSimilarity(normalizedInput, normalizedSpoken)
                    if (similarity > 0.6) {  // 相似度超过60%认为是回声
                        LogManager.d(TAG, "🔇 检测到相似回声 (相似度: ${String.format("%.1f", similarity * 100)}%): $text")
                        return true
                    }
                }
            }
        }
        
        return false
    }
    
    /**
     * 📊 计算两个字符串的相似度 (Jaccard相似度)
     */
    private fun calculateSimilarity(s1: String, s2: String): Double {
        if (s1.isEmpty() || s2.isEmpty()) return 0.0
        
        val set1 = s1.toSet()
        val set2 = s2.toSet()
        
        val intersection = set1.intersect(set2).size
        val union = set1.union(set2).size
        
        return if (union > 0) intersection.toDouble() / union else 0.0
    }
    
    /**
     * 🎤 记录播报内容（用于回声过滤）
     */
    private fun recordSpokenText(text: String) {
        // 添加到历史记录
        lastSpokenTexts.add(0, text)
        
        // 保持历史记录在限制范围内
        while (lastSpokenTexts.size > MAX_SPOKEN_HISTORY) {
            lastSpokenTexts.removeAt(lastSpokenTexts.size - 1)
        }
        
        LogManager.d(TAG, "📝 记录播报内容用于回声过滤: ${text.take(30)}...")
    }
    
    /**
     * 🧹 清除播报历史（在长时间静默后调用）
     */
    fun clearSpokenHistory() {
        lastSpokenTexts.clear()
        LogManager.d(TAG, "🧹 已清除播报历史")
    }
    
    /**
     * 🎵 映射队列情绪类型到本地情绪类型
     */
    private fun mapQueueEmotion(queueEmotion: TTSQueueManager.Emotion): Emotion {
        return when (queueEmotion) {
            TTSQueueManager.Emotion.HAPPY -> Emotion.HAPPY
            TTSQueueManager.Emotion.SAD -> Emotion.SAD
            TTSQueueManager.Emotion.EXCITED -> Emotion.EXCITED
            TTSQueueManager.Emotion.CALM -> Emotion.NEUTRAL
            TTSQueueManager.Emotion.TIRED -> Emotion.TIRED
            TTSQueueManager.Emotion.NEUTRAL -> Emotion.NEUTRAL
        }
    }
    
    /**
     * 🎵 映射本地情绪类型到队列情绪类型
     */
    private fun mapToQueueEmotion(emotion: Emotion): TTSQueueManager.Emotion {
        return when (emotion) {
            Emotion.HAPPY -> TTSQueueManager.Emotion.HAPPY
            Emotion.SAD -> TTSQueueManager.Emotion.SAD
            Emotion.EXCITED -> TTSQueueManager.Emotion.EXCITED
            Emotion.TIRED -> TTSQueueManager.Emotion.TIRED
            Emotion.ANGRY -> TTSQueueManager.Emotion.NEUTRAL
            Emotion.NEUTRAL -> TTSQueueManager.Emotion.NEUTRAL
        }
    }
    
    /**
     * 🔊 内部语音播放方法（由队列管理器调用）
     */
    private fun speakInternal(
        text: String,
        emotion: Emotion,
        speed: Float,
        onComplete: (() -> Unit)?
    ) {
        val wasWakeWordDetectionActive = wakeWordDetectionActive || isRecording
        voskRecognizer.setStartSuppressed(true)

        val wasListening = _state.value == VoiceState.LISTENING
        if (wasListening) {
            stopListening(disableContinuous = false)
        }
        if (wasWakeWordDetectionActive) {
            stopWakeWordDetection()
        }
        
        _state.value = VoiceState.SPEAKING
        isTTSSpeaking = true
        ttsStartTime = System.currentTimeMillis()
        
        recordSpokenText(text)
        smartVoiceFilter.recordSpokenText(text)
        smartVoiceFilter.updateTTSState(isSpeaking = true)
        
        val wrappedOnComplete: (() -> Unit) = {
            _state.value = VoiceState.IDLE
            onComplete?.invoke()
            
            isTTSSpeaking = false
            ttsEndTime = System.currentTimeMillis()
            smartVoiceFilter.updateTTSState(isSpeaking = false)
            
            // 播放完成后恢复监听
            if (config.continuousListening) {
                mainScope.launch {
                    delay(TTS_COOLDOWN_SHORT_MS)
                    voskRecognizer.setStartSuppressed(false)
                    resumeListeningAfterSpeaking()
                }
            } else if (wasWakeWordDetectionActive && config.enableWakeWord) {
                mainScope.launch {
                    delay(TTS_COOLDOWN_MS)
                    if (!isTTSSpeaking && config.enableWakeWord && !config.continuousListening) {
                        voskRecognizer.setStartSuppressed(false)
                        startWakeWordDetection()
                    }
                }
            } else {
                mainScope.launch {
                    delay(TTS_COOLDOWN_MS)
                    if (!isTTSSpeaking) {
                        voskRecognizer.setStartSuppressed(false)
                    }
                }
            }
        }
        
        // 优先尝试使用Supertonic TTS
        if (useSupertonicTTS && supertonicTTS.isReady()) {
            val voiceStyle = when (emotion) {
                Emotion.HAPPY, Emotion.EXCITED -> "F1"
                Emotion.SAD, Emotion.TIRED -> "F2"
                Emotion.ANGRY -> "M1"
                else -> "F1"
            }
            
            mainScope.launch {
                val success = supertonicTTS.speak(text, voiceStyle)
                if (success) {
                    wrappedOnComplete()
                } else {
                    speakWithSystemTTSInternal(text, emotion, speed, wrappedOnComplete)
                }
            }
        } else {
            speakWithSystemTTSInternal(text, emotion, speed, wrappedOnComplete)
        }
    }
    
    /**
     * 检测情绪
     */
    private fun detectEmotion(text: String): Emotion {
        // 简单的基于关键词的情绪检测
        val textLower = text.lowercase()
        
        return when {
            textLower.contains("开心") || textLower.contains("高兴") || 
            textLower.contains("太好了") -> Emotion.HAPPY
            
            textLower.contains("难过") || textLower.contains("伤心") || 
            textLower.contains("失望") -> Emotion.SAD
            
            textLower.contains("生气") || textLower.contains("愤怒") || 
            textLower.contains("讨厌") -> Emotion.ANGRY
            
            textLower.contains("激动") || textLower.contains("兴奋") || 
            textLower.contains("太棒了") -> Emotion.EXCITED
            
            textLower.contains("累") || textLower.contains("困") || 
            textLower.contains("疲惫") -> Emotion.TIRED
            
            else -> Emotion.NEUTRAL
        }
    }
    
    /**
     * 根据情绪调整语音参数
     */
    private fun adjustVoiceForEmotion(emotion: Emotion) {
        // 注意：语速已经在 speakWithSystemTTSInternal 中通过智能调节设置
        // 这里只调整音调
        when (emotion) {
            Emotion.HAPPY, Emotion.EXCITED -> {
                textToSpeech?.setPitch(1.1f)
            }
            Emotion.SAD -> {
                textToSpeech?.setPitch(0.9f)
            }
            Emotion.ANGRY -> {
                textToSpeech?.setPitch(0.8f)
            }
            Emotion.TIRED -> {
                textToSpeech?.setPitch(0.95f)
            }
            Emotion.NEUTRAL -> {
                textToSpeech?.setPitch(config.voicePitch)
            }
        }
    }
    
    /**
     * 重新开始监听
     */
    private fun restartListening() {
        recordingScope.launch {
            delay(500) // 短暂延迟
            withContext(Dispatchers.Main) {
                if (isTTSSpeaking) return@withContext
                val now = System.currentTimeMillis()
                val cooldown = if (config.continuousListening) TTS_COOLDOWN_SHORT_MS else TTS_COOLDOWN_MS
                if (ttsEndTime > 0 && now - ttsEndTime < cooldown) return@withContext
                startListening()
            }
        }
    }
    
    /**
     * 🛑 停止语音播报
     */
    fun stopSpeaking() {
        LogManager.d(TAG, "🛑 停止语音播报")
        
        // 🎵 停止队列管理器
        ttsQueueManager.stopAll()
        
        // 停止Supertonic TTS
        if (useSupertonicTTS) {
            supertonicTTS.stop()
        }
        
        // 停止系统TTS
        textToSpeech?.stop()
        
        isTTSSpeaking = false
        ttsEndTime = System.currentTimeMillis()
        smartVoiceFilter.updateTTSState(isSpeaking = false)
        _state.value = VoiceState.IDLE
        
        mainScope.launch {
            delay(TTS_COOLDOWN_MS)
            if (!isTTSSpeaking) {
                voskRecognizer.setStartSuppressed(false)
            }
        }

        LogManager.d(TAG, "✅ 语音播报已停止")
    }
    
    /**
     * 🎵 获取播放队列大小
     */
    fun getTTSQueueSize(): Int = ttsQueueManager.queueSize.value
    
    /**
     * 🎵 跳过当前播放
     */
    fun skipCurrentTTS() {
        ttsQueueManager.skipCurrent()
    }
    
    /**
     * 🎵 清空播放队列
     */
    fun clearTTSQueue() {
        ttsQueueManager.clearQueue()
    }
    
    /**
     * 🔊 设置是否启用语音播报
     */
    fun setEnableTTSResponse(enabled: Boolean) {
        enableTTSResponse = enabled
        LogManager.d(TAG, "🔊 语音播报${if (enabled) "已启用" else "已关闭"}")
        
        // 如果正在播报，立即停止
        if (!enabled && isTTSSpeaking) {
            stopSpeaking()
        }
    }
    
    /**
     * 🔊 获取是否启用语音播报
     */
    fun isEnableTTSResponse(): Boolean = enableTTSResponse
    
    /**
     * 🔊 检查是否正在播报
     */
    fun isSpeaking(): Boolean = isTTSSpeaking
    
    /**
     * 🎯 设置智能语速开关
     */
    fun setSmartSpeedEnabled(enabled: Boolean) {
        ttsQueueManager.setSmartSpeedEnabled(enabled)
        LogManager.d(TAG, "🎯 智能语速调节: ${if (enabled) "开启" else "关闭"}")
    }
    
    /**
     * 🎚️ 设置用户基础语速
     */
    fun setUserBaseSpeed(speed: Float) {
        val clampedSpeed = speed.coerceIn(0.5f, 2.0f)
        ttsQueueManager.setUserBaseSpeed(clampedSpeed)
        config = config.copy(voiceSpeed = clampedSpeed)
        LogManager.d(TAG, "🎚️ 用户基础语速设置为: $clampedSpeed")
    }
    
    /**
     * 🎚️ 获取当前用户基础语速
     */
    fun getUserBaseSpeed(): Float = config.voiceSpeed
    
    /**
     * 🎯 设置ASR优化器配置
     */
    fun setASROptimizerConfig(config: com.example.xihe.asr.SmartASROptimizer.OptimizationConfig) {
        asrOptimizer.setConfig(config)
        LogManager.d(TAG, "🎯 ASR优化器配置已更新")
    }
    
    /**
     * 📝 添加自定义纠错规则
     */
    fun addCustomASRRule(error: String, correction: String) {
        asrOptimizer.addCustomRule(error, correction)
        LogManager.d(TAG, "✅ 添加自定义ASR规则: $error → $correction")
    }
    
    /**
     * 📝 批量添加自定义纠错规则
     */
    fun addCustomASRRules(rules: Map<String, String>) {
        asrOptimizer.addCustomRules(rules)
        LogManager.d(TAG, "✅ 批量添加 ${rules.size} 条ASR规则")
    }
    
    /**
     * 🗑️ 清空ASR对话历史
     */
    fun clearASRHistory() {
        asrOptimizer.clearHistory()
        LogManager.d(TAG, "🗑️ ASR对话历史已清空")
    }
    
    /**
     * 🧹 清理资源
     */
    fun release() {
        pendingPlaybackResumeJob?.cancel()
        pendingPlaybackResumeJob = null

        config = config.copy(continuousListening = false)
        waitingForSpeechTriggeredPause = false
        wakeWordDetectionActive = false
        isRecording = false
        pausedByAudioFocusLoss = false
        pausedByExternalPlayback = false
        pausedExternalPlaybackForListening = false
        isTTSSpeaking = false
        isInitialized = false
        isVoskInitializing = false
        isTtsInitialized = false
        ttsStartTime = 0
        ttsEndTime = 0
        _partialRecognitionResult.value = ""
        _lastCommand.value = null
        _state.value = VoiceState.IDLE

        onCommandReceived = null
        onWakeWordDetected = null
        onUserInterrupt = null

        resumeExternalPlaybackIfNeeded()
        abandonRealtimeAudioFocus()

        try {
            audioRecord?.stop()
        } catch (_: Exception) {
        }
        try {
            audioRecord?.release()
        } catch (_: Exception) {
        }
        audioRecord = null

        try {
            speechRecognizer?.setRecognitionListener(null)
        } catch (_: Exception) {
        }
        try {
            speechRecognizer?.cancel()
        } catch (_: Exception) {
        }
        try {
            speechRecognizer?.destroy()
        } catch (_: Exception) {
        }
        speechRecognizer = null
        recognitionIntent = null

        voskRecognizer.continuousListening = false
        voskRecognizer.setStartSuppressed(false)
        voskRecognizer.setCallbacks()
        voskRecognizer.release()

        ttsQueueManager.setTTSCallback(null)
        ttsQueueManager.release()

        try {
            textToSpeech?.setOnUtteranceProgressListener(null)
        } catch (_: Exception) {
        }
        try {
            textToSpeech?.stop()
        } catch (_: Exception) {
        }
        try {
            textToSpeech?.shutdown()
        } catch (_: Exception) {
        }
        textToSpeech = null

        onlineTTS.release()
        supertonicTTS.release()
        audioPlaybackMonitor.release()

        mainScope.cancel()
        recordingScope.cancel()

        LogManager.d(TAG, "语音交互管理器已释放")
    }

    /**
     * 📊 获取音量级别（0-100）
     */
    fun getVolumeLevel(): Int {
        return try {
            val currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
            val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            if (maxVolume > 0) {
                (currentVolume * 100 / maxVolume)
            } else {
                50
            }
        } catch (e: Exception) {
            LogManager.w(TAG, "获取音量失败: ${e.message}")
            50
        }
    }
    
    // 🎵 音效播放器
    private val soundPool by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            android.media.SoundPool.Builder()
                .setMaxStreams(3)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .build()
        } else {
            @Suppress("DEPRECATION")
            android.media.SoundPool(3, AudioManager.STREAM_NOTIFICATION, 0)
        }
    }
    
    // 音效ID缓存
    private val soundIds = mutableMapOf<SoundType, Int>()
    private var soundsLoaded = false
    
    /**
     * 🎵 初始化提示音（可选，首次播放时自动初始化）
     */
    private fun initSounds() {
        if (soundsLoaded) return
        
        try {
            // 使用系统默认提示音
            val notificationUri = android.media.RingtoneManager.getDefaultUri(
                android.media.RingtoneManager.TYPE_NOTIFICATION
            )
            
            soundPool.setOnLoadCompleteListener { _, _, status ->
                if (status == 0) {
                    soundsLoaded = true
                    LogManager.d(TAG, "✅ 提示音加载完成")
                }
            }
            
            LogManager.d(TAG, "🎵 提示音初始化完成")
        } catch (e: Exception) {
            LogManager.w(TAG, "⚠️ 提示音初始化失败: ${e.message}")
        }
    }
    
    /**
     * 🎵 播放提示音
     */
    fun playSound(soundType: SoundType) {
        try {
            // 使用系统铃声播放提示音
            val ringtoneUri = when (soundType) {
                SoundType.WAKE_UP, SoundType.START_LISTENING -> {
                    android.media.RingtoneManager.getDefaultUri(
                        android.media.RingtoneManager.TYPE_NOTIFICATION
                    )
                }
                SoundType.SUCCESS -> {
                    android.media.RingtoneManager.getDefaultUri(
                        android.media.RingtoneManager.TYPE_NOTIFICATION
                    )
                }
                SoundType.ERROR -> {
                    android.media.RingtoneManager.getDefaultUri(
                        android.media.RingtoneManager.TYPE_ALARM
                    )
                }
                SoundType.STOP_LISTENING -> {
                    // 停止监听不播放声音
                    null
                }
            }
            
            ringtoneUri?.let { uri ->
                val ringtone = android.media.RingtoneManager.getRingtone(context, uri)
                ringtone?.play()
                LogManager.d(TAG, "🎵 播放提示音: $soundType")
            } ?: run {
                LogManager.d(TAG, "🎵 跳过提示音: $soundType")
            }
        } catch (e: Exception) {
            LogManager.w(TAG, "⚠️ 播放提示音失败: ${e.message}")
        }
    }
    
    enum class SoundType {
        WAKE_UP,
        START_LISTENING,
        STOP_LISTENING,
        ERROR,
        SUCCESS
    }
    
    /**
     * 语音交互回调
     */
    interface VoiceInteractionCallback {
        fun onWakeWordDetected()
        fun onCommandReceived(command: VoiceCommand)
        fun onError(error: String)
    }
}
