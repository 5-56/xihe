package com.example.xihe.collector

import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import com.example.xihe.utils.LogManager
import com.example.xihe.data.UserLifeData
import com.example.xihe.data.UserLifeDatabase
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import java.util.*

/**
 * 📊 生活数据收集器 - 全面记录用户生活
 * 
 * 收集内容：
 * 1. 📱 应用使用记录
 * 2. 💬 消息发送记录（内容、对象、时间）
 * 3. 📍 位置轨迹
 * 4. 🛒 购物记录
 * 5. 🍔 饮食记录
 * 6. 📺 娱乐偏好
 * 7. ⏰ 作息规律
 * 8. 🎯 行为习惯
 * 9. 👥 社交关系
 * 10. 💡 兴趣爱好
 * 
 * 隐私保护：
 * - 数据仅本地存储
 * - 可随时删除
 * - 用户完全控制
 */
class LifeDataCollector private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "LifeDataCollector"
        
        @Volatile
        private var instance: LifeDataCollector? = null
        
        fun getInstance(context: Context): LifeDataCollector {
            return instance ?: synchronized(this) {
                instance ?: LifeDataCollector(context.applicationContext).also {
                    instance = it
                }
            }
        }
    }
    
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private val database = UserLifeDatabase.getInstance(context)

    private val userLifeDataDao = database.userLifeDataDao()
    
    // 各个专项收集器
    private val appUsageCollector = AppUsageCollector(context)
    private val messageCollector = MessageCollector(context)
    private val locationCollector = LocationCollector(context)
    private val shoppingCollector = ShoppingCollector(context)
    private val foodCollector = FoodCollector(context)
    private val entertainmentCollector = EntertainmentCollector(context)
    private val routineCollector = RoutineCollector(context)
    private val behaviorCollector = BehaviorCollector(context)
    private val socialCollector = SocialCollector(context)
    private val interestCollector = InterestCollector(context)
    
    // 收集状态
    private val _collectionState = MutableStateFlow(CollectionState.STOPPED)
    val collectionState: StateFlow<CollectionState> = _collectionState

    val collectionStatsFlow: StateFlow<CollectionStats> = combine(
        userLifeDataDao.getTotalCountFlow(),
        userLifeDataDao.getTodayCountFlow(),
        appUsageCollector.usageStats
    ) { totalRecords, todayRecords, _ ->
        CollectionStats(
            totalRecords = totalRecords,
            todayRecords = todayRecords,
            collectionRate = calculateCollectionRate()
        )
    }.stateIn(
        scope = scope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = CollectionStats(0, 0, 0f)
    )
    
    private var collectionJob: Job? = null
    
    /**
     * 🚀 开始收集
     */
    fun startCollecting() {
        if (_collectionState.value == CollectionState.RUNNING) {
            LogManager.w(TAG, "⚠️ 收集器已在运行中")
            return
        }
        
        LogManager.d(TAG, "🚀 开始收集生活数据...")
        _collectionState.value = CollectionState.RUNNING
        
        // 启动所有收集器
        collectionJob = scope.launch {
            try {
                // 并行启动所有收集器
                launch { appUsageCollector.startCollecting() }
                launch { messageCollector.startCollecting() }
                launch { locationCollector.startCollecting() }
                launch { shoppingCollector.startCollecting() }
                launch { foodCollector.startCollecting() }
                launch { entertainmentCollector.startCollecting() }
                launch { routineCollector.startCollecting() }
                launch { behaviorCollector.startCollecting() }
                launch { socialCollector.startCollecting() }
                launch { interestCollector.startCollecting() }
                
                LogManager.d(TAG, "✅ 所有收集器已启动")
                
            } catch (e: Exception) {
                LogManager.e(TAG, "❌ 收集器启动失败: ${e.message}", e)
                _collectionState.value = CollectionState.ERROR
            }
        }
    }
    
    /**
     * 🛑 停止收集
     */
    fun stopCollecting() {
        LogManager.d(TAG, "🛑 停止收集...")
        
        collectionJob?.cancel()
        _collectionState.value = CollectionState.STOPPED
        
        // 停止所有收集器
        appUsageCollector.stopCollecting()
        messageCollector.stopCollecting()
        locationCollector.stopCollecting()
        shoppingCollector.stopCollecting()
        foodCollector.stopCollecting()
        entertainmentCollector.stopCollecting()
        routineCollector.stopCollecting()
        behaviorCollector.stopCollecting()
        socialCollector.stopCollecting()
        interestCollector.stopCollecting()
        
        LogManager.d(TAG, "✅ 所有收集器已停止")
    }
    
    /**
     * 📊 获取收集统计
     */
    fun getCollectionStats(): CollectionStats {
        return CollectionStats(
            totalRecords = userLifeDataDao.getTotalCount(),
            todayRecords = userLifeDataDao.getTodayCount(),
            collectionRate = calculateCollectionRate()
        )
    }
    
    /**
     * 📈 计算收集率
     */
    private fun calculateCollectionRate(): Float {
        // 根据各个收集器的活跃度计算
        var activeCollectors = 0
        val totalCollectors = 10
        
        if (appUsageCollector.usageStats.value.isNotEmpty()) activeCollectors++
        if (routineCollector.getRoutineData() != null) activeCollectors++
        if (entertainmentCollector.getEntertainmentStats().isNotEmpty()) activeCollectors++
        // 其他收集器需要权限，暂时算作潜在可用
        activeCollectors += 4 // 预估其他收集器
        
        return activeCollectors.toFloat() / totalCollectors
    }
    
    /**
     * 🗑️ 清除所有数据
     */
    suspend fun clearAllData() {
        withContext(Dispatchers.IO) {
            database.clearAllTables()
            LogManager.d(TAG, "🗑️ 所有数据已清除")
        }
    }
    
    /**
     * 📤 导出数据
     */
    suspend fun exportData(): String {
        return withContext(Dispatchers.IO) {
            val json = StringBuilder()
            json.append("{\n")
            
            // 导出应用使用数据
            json.append("  \"appUsage\": [\n")
            appUsageCollector.usageStats.value.forEachIndexed { index, app ->
                json.append("    {\"name\": \"${app.appName}\", \"minutes\": ${app.usageTimeMinutes}}")
                if (index < appUsageCollector.usageStats.value.size - 1) json.append(",")
                json.append("\n")
            }
            json.append("  ],\n")
            
            // 导出作息数据
            val routine = routineCollector.getRoutineData()
            json.append("  \"routine\": {\n")
            json.append("    \"avgSleepHour\": ${routine?.avgSleepHour ?: 23},\n")
            json.append("    \"avgWakeHour\": ${routine?.avgWakeHour ?: 7}\n")
            json.append("  },\n")
            
            // 导出屏幕时间
            json.append("  \"totalScreenTimeMinutes\": ${appUsageCollector.getTotalScreenTimeMinutes()}\n")
            json.append("}")
            
            json.toString()
        }
    }
}

/**
 * 📊 收集状态
 */
enum class CollectionState {
    STOPPED,    // 已停止
    RUNNING,    // 运行中
    PAUSED,     // 已暂停
    ERROR       // 错误
}

/**
 * 📊 收集统计
 */
data class CollectionStats(
    val totalRecords: Int,
    val todayRecords: Int,
    val collectionRate: Float
)

// ==================== 各专项收集器 ====================

/**
 * 📱 应用使用收集器
 * 记录：打开了什么应用、使用时长、操作内容
 */
class AppUsageCollector(private val context: Context) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var job: Job? = null
    private val pm = context.packageManager
    
    // 使用统计缓存
    private val _usageStats = MutableStateFlow<List<AppUsageInfo>>(emptyList())
    val usageStats: StateFlow<List<AppUsageInfo>> = _usageStats
    
    fun startCollecting() {
        LogManager.d("AppUsageCollector", "📱 开始收集应用使用数据")
        
        job = scope.launch {
            while (isActive) {
                try {
                    collectUsageStats()
                } catch (e: Exception) {
                    LogManager.e("AppUsageCollector", "收集应用使用数据失败", e)
                }
                delay(60_000L) // 每分钟收集一次
            }
        }
    }
    
    /**
     * 📊 收集应用使用统计
     */
    private fun collectUsageStats() {
        try {
            val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            
            // 获取今天的使用数据
            val calendar = Calendar.getInstance()
            val endTime = calendar.timeInMillis
            calendar.set(Calendar.HOUR_OF_DAY, 0)
            calendar.set(Calendar.MINUTE, 0)
            calendar.set(Calendar.SECOND, 0)
            val startTime = calendar.timeInMillis
            
            val usageStatsList = usageStatsManager.queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY,
                startTime,
                endTime
            )
            
            if (usageStatsList.isNullOrEmpty()) {
                LogManager.w("AppUsageCollector", "⚠️ 无法获取使用统计（可能需要权限）")
                return
            }
            
            // 过滤和排序
            val appUsageList = usageStatsList
                .filter { it.totalTimeInForeground > 0 }
                .sortedByDescending { it.totalTimeInForeground }
                .take(20)  // 只保留前20个
                .map { stats ->
                    AppUsageInfo(
                        packageName = stats.packageName,
                        appName = getAppName(stats.packageName),
                        usageTimeMinutes = (stats.totalTimeInForeground / 60000).toInt(),
                        lastUsedTime = stats.lastTimeUsed,
                        launchCount = getLaunchCount(stats)
                    )
                }
            
            _usageStats.value = appUsageList
            LogManager.d("AppUsageCollector", "✅ 收集到 ${appUsageList.size} 个应用使用数据")
            
        } catch (e: SecurityException) {
            LogManager.w("AppUsageCollector", "⚠️ 缺少使用情况访问权限")
        } catch (e: Exception) {
            LogManager.e("AppUsageCollector", "收集使用统计失败", e)
        }
    }
    
    /**
     * 📱 获取应用名称
     */
    private fun getAppName(packageName: String): String {
        return try {
            val appInfo = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(appInfo).toString()
        } catch (e: PackageManager.NameNotFoundException) {
            packageName
        }
    }
    
    /**
     * 📊 获取启动次数（API 29+）
     */
    @Suppress("DEPRECATION")
    private fun getLaunchCount(stats: UsageStats): Int {
        return try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                // API 29+ 使用反射获取 appLaunchCount（因为某些设备可能没有）
                val method = UsageStats::class.java.getMethod("getAppLaunchCount")
                method.invoke(stats) as? Int ?: 0
            } else {
                0
            }
        } catch (e: Exception) {
            0
        }
    }
    
    /**
     * 📊 获取今日使用最多的应用
     */
    fun getTopApps(limit: Int = 5): List<AppUsageInfo> {
        return _usageStats.value.take(limit)
    }
    
    /**
     * ⏱️ 获取今日总屏幕时间（分钟）
     */
    fun getTotalScreenTimeMinutes(): Int {
        return _usageStats.value.sumOf { it.usageTimeMinutes }
    }
    
    fun stopCollecting() {
        job?.cancel()
        job = null
    }
}

/**
 * 📱 应用使用信息
 */
data class AppUsageInfo(
    val packageName: String,
    val appName: String,
    val usageTimeMinutes: Int,
    val lastUsedTime: Long,
    val launchCount: Int
)

/**
 * 💬 消息收集器
 * 记录：发送了什么消息、给谁发的、什么时候发的
 * 注意：需要通过无障碍服务配合使用
 */
class MessageCollector(private val context: Context) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var job: Job? = null
    
    // 消息记录缓存
    private val _messageRecords = MutableStateFlow<List<MessageRecord>>(emptyList())
    val messageRecords: StateFlow<List<MessageRecord>> = _messageRecords
    
    // 支持的消息应用包名
    private val messageApps = mapOf(
        "com.tencent.mm" to "微信",
        "com.tencent.mobileqq" to "QQ",
        "com.android.mms" to "短信",
        "com.google.android.apps.messaging" to "Google消息"
    )
    
    fun startCollecting() {
        LogManager.d("MessageCollector", "💬 开始收集消息数据")
        // 消息收集需要配合无障碍服务，这里提供接口供外部调用
        LogManager.d("MessageCollector", "💡 消息收集需配合无障碍服务使用 CoreAccessibilityService")
    }
    
    /**
     * 📨 记录消息发送（由无障碍服务调用）
     */
    fun recordMessage(appPackage: String, contactName: String?, messagePreview: String?) {
        val appName = messageApps[appPackage] ?: "未知应用"
        val record = MessageRecord(
            timestamp = System.currentTimeMillis(),
            appName = appName,
            contactName = contactName ?: "未知联系人",
            messagePreview = messagePreview?.take(50) ?: "",
            isSent = true
        )
        _messageRecords.value = (_messageRecords.value + record).takeLast(100)
        LogManager.d("MessageCollector", "📨 记录消息: $appName -> ${contactName ?: "未知"}")
    }
    
    fun stopCollecting() {
        job?.cancel()
    }
}

/**
 * 📨 消息记录
 */
data class MessageRecord(
    val timestamp: Long,
    val appName: String,
    val contactName: String,
    val messagePreview: String,
    val isSent: Boolean
)

/**
 * 📍 位置收集器
 * 记录：去了哪里、待了多久、频率
 * 注意：需要位置权限
 */
class LocationCollector(private val context: Context) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var job: Job? = null
    
    // 位置记录缓存
    private val _locationHistory = MutableStateFlow<List<LocationRecord>>(emptyList())
    val locationHistory: StateFlow<List<LocationRecord>> = _locationHistory
    
    // 常去地点统计
    private val frequentPlaces = mutableMapOf<String, Int>()
    
    fun startCollecting() {
        LogManager.d("LocationCollector", "📍 开始收集位置数据")
        LogManager.d("LocationCollector", "💡 位置收集需要 ACCESS_FINE_LOCATION 权限")
        // 位置收集需要运行时权限，由外部服务调用 recordLocation
    }
    
    /**
     * 📍 记录位置（由外部服务调用）
     */
    fun recordLocation(latitude: Double, longitude: Double, placeName: String? = null) {
        val record = LocationRecord(
            timestamp = System.currentTimeMillis(),
            latitude = latitude,
            longitude = longitude,
            placeName = placeName ?: "未知地点",
            stayDurationMinutes = 0
        )
        _locationHistory.value = (_locationHistory.value + record).takeLast(200)
        
        // 更新常去地点统计
        val placeKey = placeName ?: "${latitude.toInt()},${longitude.toInt()}"
        frequentPlaces[placeKey] = (frequentPlaces[placeKey] ?: 0) + 1
        
        LogManager.d("LocationCollector", "📍 记录位置: $placeKey")
    }
    
    /**
     * 🏠 获取常去地点
     */
    fun getFrequentPlaces(limit: Int = 5): List<Pair<String, Int>> {
        return frequentPlaces.entries
            .sortedByDescending { it.value }
            .take(limit)
            .map { it.key to it.value }
    }
    
    fun stopCollecting() {
        job?.cancel()
    }
}

/**
 * 📍 位置记录
 */
data class LocationRecord(
    val timestamp: Long,
    val latitude: Double,
    val longitude: Double,
    val placeName: String,
    val stayDurationMinutes: Int
)

/**
 * 🛒 购物收集器
 * 记录：买了什么、花了多少钱、在哪买的
 */
class ShoppingCollector(private val context: Context) {
    private var job: Job? = null
    
    // 购物记录
    private val _shoppingRecords = MutableStateFlow<List<ShoppingRecord>>(emptyList())
    val shoppingRecords: StateFlow<List<ShoppingRecord>> = _shoppingRecords
    
    // 支持的购物应用
    private val shoppingApps = setOf(
        "com.taobao.taobao", "com.jingdong.app.mall", "com.xunmeng.pinduoduo",
        "com.tmall.wireless", "com.suning.mobile.ebuy"
    )
    
    fun startCollecting() {
        LogManager.d("ShoppingCollector", "🛒 开始收集购物数据")
        LogManager.d("ShoppingCollector", "💡 购物数据通过无障碍服务或通知监听收集")
    }
    
    /**
     * 🛒 记录购物行为
     */
    fun recordShopping(appName: String, itemName: String?, price: Double?) {
        val record = ShoppingRecord(
            timestamp = System.currentTimeMillis(),
            platform = appName,
            itemName = itemName ?: "未知商品",
            price = price ?: 0.0
        )
        _shoppingRecords.value = (_shoppingRecords.value + record).takeLast(100)
        LogManager.d("ShoppingCollector", "🛒 记录购物: $appName - ${itemName ?: "未知"}")
    }
    
    fun stopCollecting() { job?.cancel() }
}

data class ShoppingRecord(
    val timestamp: Long, val platform: String, val itemName: String, val price: Double
)

/**
 * 🍔 饮食收集器
 * 记录：吃了什么、喜欢吃什么、饮食习惯
 */
class FoodCollector(private val context: Context) {
    private var job: Job? = null
    
    private val _foodRecords = MutableStateFlow<List<FoodRecord>>(emptyList())
    val foodRecords: StateFlow<List<FoodRecord>> = _foodRecords
    
    // 外卖应用
    private val foodApps = setOf("com.sankuai.meituan", "me.ele", "com.dianping.v1")
    
    fun startCollecting() {
        LogManager.d("FoodCollector", "🍔 开始收集饮食数据")
    }
    
    fun recordFood(restaurant: String?, foodName: String?, mealType: String = "其他") {
        val record = FoodRecord(
            timestamp = System.currentTimeMillis(),
            restaurant = restaurant ?: "未知餐厅",
            foodName = foodName ?: "未知食物",
            mealType = mealType
        )
        _foodRecords.value = (_foodRecords.value + record).takeLast(100)
    }
    
    fun stopCollecting() { job?.cancel() }
}

data class FoodRecord(
    val timestamp: Long, val restaurant: String, val foodName: String, val mealType: String
)

/**
 * 📺 娱乐收集器
 * 记录：看了什么、听了什么、玩了什么
 */
class EntertainmentCollector(private val context: Context) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var job: Job? = null
    
    private val _entertainmentStats = MutableStateFlow<Map<String, Int>>(emptyMap())
    
    // 娱乐应用分类
    private val entertainmentApps = mapOf(
        "com.ss.android.ugc.aweme" to "视频",
        "com.tencent.qqlive" to "视频",
        "com.youku.phone" to "视频",
        "tv.danmaku.bili" to "视频",
        "com.netease.cloudmusic" to "音乐",
        "com.kugou.android" to "音乐",
        "com.tencent.qqmusic" to "音乐",
        "com.tencent.tmgp.sgame" to "游戏"
    )
    
    fun startCollecting() {
        LogManager.d("EntertainmentCollector", "📺 开始收集娱乐数据")
    }
    
    fun recordEntertainment(packageName: String, durationMinutes: Int) {
        val category = entertainmentApps[packageName] ?: "其他"
        val current = _entertainmentStats.value.toMutableMap()
        current[category] = (current[category] ?: 0) + durationMinutes
        _entertainmentStats.value = current
    }
    
    fun getEntertainmentStats(): Map<String, Int> = _entertainmentStats.value
    
    fun stopCollecting() { job?.cancel() }
}

/**
 * ⏰ 作息收集器
 * 记录：睡觉时间、起床时间、作息规律
 */
class RoutineCollector(private val context: Context) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var job: Job? = null
    
    private val _routineData = MutableStateFlow<RoutineData?>(null)
    
    // 屏幕开关记录
    private val screenEvents = mutableListOf<ScreenEvent>()
    
    fun startCollecting() {
        LogManager.d("RoutineCollector", "⏰ 开始收集作息数据")
        // 分析历史屏幕事件推断作息
        analyzeRoutine()
    }
    
    fun recordScreenEvent(isOn: Boolean) {
        screenEvents.add(ScreenEvent(System.currentTimeMillis(), isOn))
        if (screenEvents.size > 200) screenEvents.removeAt(0)
        analyzeRoutine()
    }
    
    private fun analyzeRoutine() {
        if (screenEvents.size < 10) return
        
        // 简单分析：找到最早和最晚的屏幕开启时间
        val calendar = Calendar.getInstance()
        val todayEvents = screenEvents.filter {
            calendar.timeInMillis = it.timestamp
            calendar.get(Calendar.DAY_OF_YEAR) == Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        }
        
        if (todayEvents.isNotEmpty()) {
            val firstOn = todayEvents.firstOrNull { it.isOn }
            val lastOff = todayEvents.lastOrNull { !it.isOn }
            
            calendar.timeInMillis = firstOn?.timestamp ?: System.currentTimeMillis()
            val wakeHour = calendar.get(Calendar.HOUR_OF_DAY)
            
            calendar.timeInMillis = lastOff?.timestamp ?: System.currentTimeMillis()
            val sleepHour = calendar.get(Calendar.HOUR_OF_DAY)
            
            _routineData.value = RoutineData(avgWakeHour = wakeHour, avgSleepHour = sleepHour)
        }
    }
    
    fun getRoutineData(): RoutineData? = _routineData.value
    
    fun stopCollecting() { job?.cancel() }
}

data class ScreenEvent(val timestamp: Long, val isOn: Boolean)
data class RoutineData(val avgWakeHour: Int, val avgSleepHour: Int)

/**
 * 🎯 行为收集器
 * 记录：做了什么、怎么做的、习惯是什么
 */
class BehaviorCollector(private val context: Context) {
    private var job: Job? = null
    
    private val _behaviorPatterns = MutableStateFlow<List<BehaviorPattern>>(emptyList())
    val behaviorPatterns: StateFlow<List<BehaviorPattern>> = _behaviorPatterns
    
    fun startCollecting() {
        LogManager.d("BehaviorCollector", "🎯 开始收集行为数据")
    }
    
    fun recordBehavior(action: String, target: String?, context: String?) {
        val pattern = BehaviorPattern(
            timestamp = System.currentTimeMillis(),
            action = action,
            target = target ?: "",
            context = context ?: ""
        )
        _behaviorPatterns.value = (_behaviorPatterns.value + pattern).takeLast(500)
    }
    
    fun stopCollecting() { job?.cancel() }
}

data class BehaviorPattern(
    val timestamp: Long, val action: String, val target: String, val context: String
)

/**
 * 👥 社交收集器
 * 记录：联系人、社交关系、交流频率
 */
class SocialCollector(private val context: Context) {
    private var job: Job? = null
    
    private val _contactFrequency = MutableStateFlow<Map<String, Int>>(emptyMap())
    val contactFrequency: StateFlow<Map<String, Int>> = _contactFrequency
    
    fun startCollecting() {
        LogManager.d("SocialCollector", "👥 开始收集社交数据")
    }
    
    fun recordInteraction(contactName: String) {
        val current = _contactFrequency.value.toMutableMap()
        current[contactName] = (current[contactName] ?: 0) + 1
        _contactFrequency.value = current
    }
    
    fun getTopContacts(limit: Int = 10): List<Pair<String, Int>> {
        return _contactFrequency.value.entries
            .sortedByDescending { it.value }
            .take(limit)
            .map { it.key to it.value }
    }
    
    fun stopCollecting() { job?.cancel() }
}

/**
 * 💡 兴趣收集器
 * 记录：浏览内容、搜索记录、兴趣爱好
 */
class InterestCollector(private val context: Context) {
    private var job: Job? = null
    
    private val _interestTags = MutableStateFlow<Map<String, Int>>(emptyMap())
    val interestTags: StateFlow<Map<String, Int>> = _interestTags
    
    fun startCollecting() {
        LogManager.d("InterestCollector", "💡 开始收集兴趣数据")
    }
    
    fun recordInterest(tag: String, weight: Int = 1) {
        val current = _interestTags.value.toMutableMap()
        current[tag] = (current[tag] ?: 0) + weight
        _interestTags.value = current
    }
    
    fun getTopInterests(limit: Int = 10): List<Pair<String, Int>> {
        return _interestTags.value.entries
            .sortedByDescending { it.value }
            .take(limit)
            .map { it.key to it.value }
    }
    
    fun stopCollecting() { job?.cancel() }
}

