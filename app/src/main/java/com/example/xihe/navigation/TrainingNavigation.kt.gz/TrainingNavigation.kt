package com.example.xihe.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.xihe.ui.*

/**
 * 🧭 训练系统导航配置
 * 
 * 提供所有训练相关界面的导航路由
 */
object TrainingRoutes {
    const val HUB = "training_hub"
    const val CONTROL = "training_control"
    const val DATA_MANAGER = "training_data_manager"
    const val CUSTOM_DATA = "custom_data"
    const val MONITOR = "training_monitor"
    const val DATA_MANAGEMENT = "data_management"
    const val SETTINGS = "training_settings"
    const val DATA_CLEANER = "data_cleaner"  // 🆕 数据清洗工具
    const val API_MONITOR = "api_monitor"    // 🆕 API训练监控
}

/**
 * 训练系统导航图
 */
@Composable
fun TrainingNavHost(
    navController: NavHostController,
    startDestination: String = TrainingRoutes.HUB
) {
    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        // 训练中心主界面
        composable(TrainingRoutes.HUB) {
            TrainingHub(
                navController = navController,
                onBack = { navController.popBackStack() }
            )
        }
        
        // 训练控制界面
        composable(TrainingRoutes.CONTROL) {
            TrainingControlScreen(
                onBack = { navController.popBackStack() },
                onManageData = { navController.navigate(TrainingRoutes.DATA_MANAGER) }
            )
        }
        
        composable(TrainingRoutes.DATA_MANAGER) {
            TrainingDataManagerScreen(
                onBack = { navController.popBackStack() }
            )
        }
        
        // 自定义数据界面
        composable(TrainingRoutes.CUSTOM_DATA) {
            CustomDataScreen(
                onBack = { navController.popBackStack() }
            )
        }
        
        // 训练监控界面
        composable(TrainingRoutes.MONITOR) {
            TrainingMonitorScreen(
                onBack = { navController.popBackStack() }
            )
        }
        
        // 数据管理界面
        composable(TrainingRoutes.DATA_MANAGEMENT) {
            DataManagementScreen(
                onBack = { navController.popBackStack() }
            )
        }
        
        // 训练设置界面
        composable(TrainingRoutes.SETTINGS) {
            TrainingSettingsScreen(
                onBack = { navController.popBackStack() }
            )
        }
        
        // 🆕 数据清洗工具界面
        composable(TrainingRoutes.DATA_CLEANER) {
            DataCleanerScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
        
        // 🆕 API训练监控界面
        composable(TrainingRoutes.API_MONITOR) {
            APIMonitorSettingsScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}

/**
 * 导航扩展函数
 */
fun NavHostController.navigateToTrainingHub() {
    navigate(TrainingRoutes.HUB)
}

fun NavHostController.navigateToTrainingControl() {
    navigate(TrainingRoutes.CONTROL)
}

fun NavHostController.navigateToCustomData() {
    navigate(TrainingRoutes.CUSTOM_DATA)
}

fun NavHostController.navigateToTrainingMonitor() {
    navigate(TrainingRoutes.MONITOR)
}

fun NavHostController.navigateToDataManagement() {
    navigate(TrainingRoutes.DATA_MANAGEMENT)
}

fun NavHostController.navigateToTrainingSettings() {
    navigate(TrainingRoutes.SETTINGS)
}

// 🆕 数据清洗工具导航
fun NavHostController.navigateToDataCleaner() {
    navigate(TrainingRoutes.DATA_CLEANER)
}

// 🆕 API监控导航
fun NavHostController.navigateToAPIMonitor() {
    navigate(TrainingRoutes.API_MONITOR)
}
