package com.example.xihe.intelligence

import android.content.Context
import com.example.xihe.utils.LogManager
import java.time.LocalTime
import java.time.DayOfWeek
import java.time.LocalDate

/**
 * 🎯 个性化推荐系统
 * 基于用户画像和当前情绪生成个性化推荐
 */
class PersonalizedRecommender(private val context: Context) {
    
    companion object {
        private const val TAG = "PersonalizedRecommender"
        
        @Volatile
        private var instance: PersonalizedRecommender? = null
        
        fun getInstance(context: Context): PersonalizedRecommender {
            return instance ?: synchronized(this) {
                instance ?: PersonalizedRecommender(context.applicationContext).also {
                    instance = it
                }
            }
        }
    }
    
    private val memorySystem = MemorySystem.getInstance(context)
    private val emotionRecognizer = EmotionRecognizer.getInstance(context)
    
    /**
     * 🎯 生成推荐列表
     */
    fun generateRecommendations(): List<Recommendation> {
        val recommendations = mutableListOf<Recommendation>()
        
        try {
            val profile = memorySystem.userProfile.value
            val emotion = emotionRecognizer.currentEmotion.value
            
            // 1. 基于情绪的推荐
            recommendations.addAll(generateEmotionBasedRecommendations(emotion))
            
            // 2. 基于时间的推荐
            recommendations.addAll(generateTimeBasedRecommendations(profile))
            
            // 3. 基于喜好的推荐
            recommendations.addAll(generatePreferenceBasedRecommendations(profile, emotion))
            
            // 4. 基于习惯的推荐
            recommendations.addAll(generateHabitBasedRecommendations(profile))
            
            // 5. 基于位置的推荐
            recommendations.addAll(generateLocationBasedRecommendations(profile))
            
            // 根据优先级和相关性排序
            recommendations.sortByDescending { it.priority * it.relevance }
            
            LogManager.d(TAG, "🎯 生成了 ${recommendations.size} 条推荐")
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 生成推荐失败", e)
        }
        
        return recommendations.take(10) // 返回前10条
    }
    
    /**
     * 🎭 基于情绪的推荐
     */
    private fun generateEmotionBasedRecommendations(emotionState: EmotionState): List<Recommendation> {
        val recommendations = mutableListOf<Recommendation>()
        
        when (emotionState.emotion) {
            Emotion.HAPPY -> {
                recommendations.add(
                    Recommendation(
                        type = RecommendationType.MUSIC,
                        title = "播放欢快音乐",
                        content = "要不要听点欢快的歌庆祝一下？🎉",
                        reason = "您现在心情不错呢~",
                        action = "play_happy_music",
                        priority = 0.8f,
                        relevance = emotionState.intensity
                    )
                )
            }
            
            Emotion.SAD -> {
                recommendations.add(
                    Recommendation(
                        type = RecommendationType.CHAT,
                        title = "聊聊天",
                        content = "需要陪你聊聊天吗？🫂",
                        reason = "您看起来有点不开心",
                        action = "start_chat",
                        priority = 0.9f,
                        relevance = emotionState.intensity
                    )
                )
                recommendations.add(
                    Recommendation(
                        type = RecommendationType.MUSIC,
                        title = "播放治愈音乐",
                        content = "听点舒缓的音乐放松一下？🎵",
                        reason = "音乐可以让心情变好哦",
                        action = "play_healing_music",
                        priority = 0.7f,
                        relevance = emotionState.intensity
                    )
                )
            }
            
            Emotion.ANXIOUS, Emotion.STRESSED -> {
                recommendations.add(
                    Recommendation(
                        type = RecommendationType.RELAXATION,
                        title = "冥想放松",
                        content = "播放冥想音乐，深呼吸放松？🧘‍♀️",
                        reason = "您看起来有点紧张",
                        action = "start_meditation",
                        priority = 0.9f,
                        relevance = emotionState.intensity
                    )
                )
                recommendations.add(
                    Recommendation(
                        type = RecommendationType.REMINDER,
                        title = "休息提醒",
                        content = "要不要出去走走，换换心情？🚶",
                        reason = "适当放松很重要",
                        action = "suggest_break",
                        priority = 0.8f,
                        relevance = emotionState.intensity
                    )
                )
            }
            
            Emotion.TIRED -> {
                recommendations.add(
                    Recommendation(
                        type = RecommendationType.REMINDER,
                        title = "休息建议",
                        content = "要不要休息一下？😴",
                        reason = "您看起来有点累了",
                        action = "suggest_rest",
                        priority = 0.9f,
                        relevance = emotionState.intensity
                    )
                )
            }
            
            Emotion.EXCITED -> {
                recommendations.add(
                    Recommendation(
                        type = RecommendationType.MUSIC,
                        title = "播放动感音乐",
                        content = "来点动感的音乐？🎊",
                        reason = "您现在精神很好呢",
                        action = "play_energetic_music",
                        priority = 0.7f,
                        relevance = emotionState.intensity
                    )
                )
            }
            
            else -> {
                // 中性情绪，不推荐
            }
        }
        
        return recommendations
    }
    
    /**
     * ⏰ 基于时间的推荐
     */
    private fun generateTimeBasedRecommendations(profile: UserProfile): List<Recommendation> {
        val recommendations = mutableListOf<Recommendation>()
        val now = LocalTime.now()
        val hour = now.hour
        
        when {
            // 早晨 6-9点
            hour in 6..9 -> {
                recommendations.add(
                    Recommendation(
                        type = RecommendationType.NEWS,
                        title = "播放晨间新闻",
                        content = "早上好！要听今天的新闻吗？☀️",
                        reason = "早晨新闻时间",
                        action = "play_morning_news",
                        priority = 0.8f,
                        relevance = 0.9f
                    )
                )
                recommendations.add(
                    Recommendation(
                        type = RecommendationType.WEATHER,
                        title = "天气预报",
                        content = "播报今天的天气？🌤️",
                        reason = "出门前了解天气",
                        action = "announce_weather",
                        priority = 0.7f,
                        relevance = 0.8f
                    )
                )
            }
            
            // 午餐 11-14点
            hour in 11..14 -> {
                recommendations.add(
                    Recommendation(
                        type = RecommendationType.FOOD,
                        title = "美食推荐",
                        content = "要不要推荐附近的餐厅？🍽️",
                        reason = "午餐时间到啦",
                        action = "recommend_restaurant",
                        priority = 0.8f,
                        relevance = 0.9f
                    )
                )
            }
            
            // 下午茶 15-17点
            hour in 15..17 -> {
                recommendations.add(
                    Recommendation(
                        type = RecommendationType.REMINDER,
                        title = "下午茶提醒",
                        content = "下午茶时间，喝点什么吗？☕",
                        reason = "下午需要补充能量",
                        action = "suggest_afternoon_tea",
                        priority = 0.6f,
                        relevance = 0.7f
                    )
                )
            }
            
            // 晚餐 18-20点
            hour in 18..20 -> {
                recommendations.add(
                    Recommendation(
                        type = RecommendationType.FOOD,
                        title = "晚餐建议",
                        content = "晚餐想吃什么呢？🍜",
                        reason = "晚餐时间",
                        action = "suggest_dinner",
                        priority = 0.8f,
                        relevance = 0.9f
                    )
                )
            }
            
            // 晚上 21-23点
            hour in 21..23 -> {
                recommendations.add(
                    Recommendation(
                        type = RecommendationType.ENTERTAINMENT,
                        title = "娱乐推荐",
                        content = "要看部电影或听听音乐吗？🎬",
                        reason = "放松时间",
                        action = "suggest_entertainment",
                        priority = 0.7f,
                        relevance = 0.8f
                    )
                )
            }
            
            // 深夜 23-6点
            hour >= 23 || hour < 6 -> {
                recommendations.add(
                    Recommendation(
                        type = RecommendationType.REMINDER,
                        title = "睡眠提醒",
                        content = "已经很晚了，该休息啦！😴",
                        reason = "保证充足睡眠",
                        action = "suggest_sleep",
                        priority = 0.9f,
                        relevance = 0.9f
                    )
                )
            }
        }
        
        return recommendations
    }
    
    /**
     * ⭐ 基于喜好的推荐
     */
    private fun generatePreferenceBasedRecommendations(
        profile: UserProfile,
        emotionState: EmotionState
    ): List<Recommendation> {
        val recommendations = mutableListOf<Recommendation>()
        
        // 音乐喜好
        if (profile.preferences.musicLikes.isNotEmpty() && 
            emotionState.emotion in listOf(Emotion.HAPPY, Emotion.NEUTRAL, Emotion.CALM)) {
            val favoriteArtist = profile.preferences.musicLikes.randomOrNull()
            if (favoriteArtist != null) {
                recommendations.add(
                    Recommendation(
                        type = RecommendationType.MUSIC,
                        title = "播放${favoriteArtist}的歌",
                        content = "要不要听听${favoriteArtist}的歌？🎵",
                        reason = "您喜欢${favoriteArtist}的歌",
                        action = "play_favorite_artist:$favoriteArtist",
                        priority = 0.8f,
                        relevance = 0.9f
                    )
                )
            }
        }
        
        // 食物喜好
        if (profile.preferences.foodLikes.isNotEmpty() && isLunchOrDinnerTime()) {
            val favoriteFood = profile.preferences.foodLikes.randomOrNull()
            if (favoriteFood != null) {
                recommendations.add(
                    Recommendation(
                        type = RecommendationType.FOOD,
                        title = "推荐${favoriteFood}餐厅",
                        content = "附近有${favoriteFood}餐厅，要看看吗？🍽️",
                        reason = "您喜欢吃${favoriteFood}",
                        action = "find_restaurant:$favoriteFood",
                        priority = 0.8f,
                        relevance = 0.9f
                    )
                )
            }
        }
        
        return recommendations
    }
    
    /**
     * 🔄 基于习惯的推荐
     */
    private fun generateHabitBasedRecommendations(profile: UserProfile): List<Recommendation> {
        val recommendations = mutableListOf<Recommendation>()
        val now = LocalTime.now()
        val today = LocalDate.now().dayOfWeek
        
        profile.habits.forEach { habit ->
            when (habit.frequency) {
                HabitFrequency.DAILY -> {
                    // 检查时间
                    habit.time?.let { habitTime ->
                        val parts = habitTime.split(":")
                        if (parts.size == 2) {
                            val habitHour = parts[0].toIntOrNull()
                            if (habitHour != null && now.hour == habitHour) {
                                recommendations.add(
                                    Recommendation(
                                        type = RecommendationType.REMINDER,
                                        title = "习惯提醒",
                                        content = "按照您的习惯，该${habit.description}了",
                                        reason = "您的日常习惯",
                                        action = "habit_reminder:${habit.description}",
                                        priority = 0.9f,
                                        relevance = 1.0f
                                    )
                                )
                            }
                        }
                    }
                }
                
                HabitFrequency.WEEKLY -> {
                    // 检查星期几
                    habit.dayOfWeek?.let { dayOfWeek ->
                        if (today.name.equals(dayOfWeek, ignoreCase = true)) {
                            recommendations.add(
                                Recommendation(
                                    type = RecommendationType.REMINDER,
                                    title = "周期提醒",
                                    content = "今天${habit.description}的日子哦",
                                    reason = "您的每周习惯",
                                    action = "weekly_reminder:${habit.description}",
                                    priority = 0.8f,
                                    relevance = 0.9f
                                )
                            )
                        }
                    }
                }
                
                else -> {}
            }
        }
        
        return recommendations
    }
    
    /**
     * 📍 基于位置的推荐
     */
    private fun generateLocationBasedRecommendations(profile: UserProfile): List<Recommendation> {
        val recommendations = mutableListOf<Recommendation>()
        
        // 这里可以集成位置服务
        // 暂时返回空列表
        
        return recommendations
    }
    
    /**
     * 🍽️ 是否是午餐或晚餐时间
     */
    private fun isLunchOrDinnerTime(): Boolean {
        val hour = LocalTime.now().hour
        return hour in 11..14 || hour in 18..20
    }
}

/**
 * 🎯 推荐项
 */
data class Recommendation(
    val type: RecommendationType,
    val title: String,
    val content: String,
    val reason: String,
    val action: String,
    val priority: Float,          // 优先级 0-1
    val relevance: Float,         // 相关性 0-1
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * 📋 推荐类型
 */
enum class RecommendationType {
    MUSIC,              // 音乐
    FOOD,               // 美食
    NEWS,               // 新闻
    WEATHER,            // 天气
    REMINDER,           // 提醒
    ENTERTAINMENT,      // 娱乐
    CHAT,               // 聊天
    RELAXATION         // 放松
}
