package com.example.xihe.intelligence

import android.content.Context
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * 🎭 情绪识别系统
 * 多维度识别用户情绪状态，提供情绪化响应
 */
class EmotionRecognizer(private val context: Context) {
    
    companion object {
        private const val TAG = "EmotionRecognizer"
        
        @Volatile
        private var instance: EmotionRecognizer? = null
        
        fun getInstance(context: Context): EmotionRecognizer {
            return instance ?: synchronized(this) {
                instance ?: EmotionRecognizer(context.applicationContext).also {
                    instance = it
                }
            }
        }
    }
    
    // 当前情绪状态
    private val _currentEmotion = MutableStateFlow(EmotionState.DEFAULT)
    val currentEmotion = _currentEmotion.asStateFlow()
    
    // 情绪历史记录
    private val emotionHistory = mutableListOf<EmotionRecord>()
    
    // 是否启用
    private var isEnabled = false
    
    /**
     * 🚀 启动情绪识别
     */
    fun start() {
        LogManager.i(TAG, "🚀 启动情绪识别系统")
        isEnabled = true
    }
    
    /**
     * 🛑 停止情绪识别
     */
    fun stop() {
        LogManager.i(TAG, "🛑 停止情绪识别系统")
        isEnabled = false
    }
    
    /**
     * 🎯 识别情绪（多维度分析）
     */
    fun recognizeEmotion(
        voiceText: String? = null,
        voiceTone: VoiceTone? = null,
        speechPattern: SpeechPattern? = null,
        userBehavior: UserBehavior? = null
    ): EmotionState {
        if (!isEnabled) return _currentEmotion.value
        
        try {
            // 1. 文本情感分析
            val textSentiment = analyzeTextSentiment(voiceText)
            
            // 2. 语音语调分析
            val toneSentiment = analyzeVoiceTone(voiceTone)
            
            // 3. 说话模式分析
            val patternSentiment = analyzeSpeechPattern(speechPattern)
            
            // 4. 行为模式分析
            val behaviorSentiment = analyzeBehavior(userBehavior)
            
            // 5. 融合多维度情绪
            val fusedEmotion = fuseEmotions(
                textSentiment,
                toneSentiment,
                patternSentiment,
                behaviorSentiment
            )
            
            // 更新当前情绪
            _currentEmotion.value = fusedEmotion
            
            // 记录历史
            recordEmotion(fusedEmotion)
            
            LogManager.d(TAG, "🎭 情绪识别结果: ${fusedEmotion.emotion} (强度: ${fusedEmotion.intensity})")
            
            return fusedEmotion
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 情绪识别失败", e)
            return _currentEmotion.value
        }
    }
    
    /**
     * 📝 文本情感分析
     */
    private fun analyzeTextSentiment(text: String?): Emotion {
        text ?: return Emotion.NEUTRAL
        
        val normalizedText = text.lowercase()
        
        // 积极情绪关键词
        val positiveKeywords = listOf(
            "开心", "高兴", "快乐", "兴奋", "棒", "好", "喜欢", "爱",
            "哈哈", "嘿嘿", "yeah", "nice", "太好了", "厉害", "赞"
        )
        
        // 消极情绪关键词
        val negativeKeywords = listOf(
            "难过", "伤心", "痛苦", "难受", "不开心", "郁闷", "烦",
            "讨厌", "恨", "气", "生气", "愤怒", "唉", "哎"
        )
        
        // 焦虑/压力关键词
        val anxiousKeywords = listOf(
            "紧张", "焦虑", "担心", "害怕", "压力", "累", "疲惫",
            "困", "忙", "烦躁", "慌", "怕"
        )
        
        // 疲惫关键词
        val tiredKeywords = listOf(
            "累", "困", "疲惫", "乏", "没劲", "想睡", "瞌睡"
        )
        
        return when {
            positiveKeywords.any { normalizedText.contains(it) } -> Emotion.HAPPY
            negativeKeywords.any { normalizedText.contains(it) } -> Emotion.SAD
            anxiousKeywords.any { normalizedText.contains(it) } -> Emotion.ANXIOUS
            tiredKeywords.any { normalizedText.contains(it) } -> Emotion.TIRED
            else -> Emotion.NEUTRAL
        }
    }
    
    /**
     * 🎤 语音语调分析
     */
    private fun analyzeVoiceTone(tone: VoiceTone?): Emotion {
        tone ?: return Emotion.NEUTRAL
        
        return when {
            tone.pitch > 1.2 && tone.speed > 1.1 -> Emotion.EXCITED
            tone.pitch < 0.8 && tone.speed < 0.9 -> Emotion.SAD
            tone.pitch > 1.1 && tone.volume > 0.8 -> Emotion.ANGRY
            tone.speed < 0.8 -> Emotion.TIRED
            else -> Emotion.NEUTRAL
        }
    }
    
    /**
     * 💬 说话模式分析
     */
    private fun analyzeSpeechPattern(pattern: SpeechPattern?): Emotion {
        pattern ?: return Emotion.NEUTRAL
        
        return when {
            // 说话很快，可能兴奋或焦虑
            pattern.wordsPerMinute > 150 -> Emotion.ANXIOUS
            
            // 说话很慢，可能疲惫或沮丧
            pattern.wordsPerMinute < 80 -> Emotion.TIRED
            
            // 语句简短，可能不耐烦
            pattern.avgSentenceLength < 5 -> Emotion.ANNOYED
            
            // 长句，可能在解释或倾诉
            pattern.avgSentenceLength > 20 -> Emotion.STRESSED
            
            else -> Emotion.NEUTRAL
        }
    }
    
    /**
     * 🚶 行为模式分析
     */
    private fun analyzeBehavior(behavior: UserBehavior?): Emotion {
        behavior ?: return Emotion.NEUTRAL
        
        return when {
            // 频繁操作，可能焦虑
            behavior.actionFrequency > 10 -> Emotion.ANXIOUS
            
            // 很少操作，可能疲惫
            behavior.actionFrequency < 2 -> Emotion.TIRED
            
            // 重复操作，可能烦躁
            behavior.repeatActions > 5 -> Emotion.ANNOYED
            
            else -> Emotion.NEUTRAL
        }
    }
    
    /**
     * 🔀 融合多维度情绪
     */
    private fun fuseEmotions(
        text: Emotion,
        tone: Emotion,
        pattern: Emotion,
        behavior: Emotion
    ): EmotionState {
        // 简单投票机制
        val emotions = listOf(text, tone, pattern, behavior)
            .filter { it != Emotion.NEUTRAL }
        
        if (emotions.isEmpty()) {
            return EmotionState(
                emotion = Emotion.NEUTRAL,
                intensity = 0.5f,
                confidence = 0.7f
            )
        }
        
        // 找出最常见的情绪
        val dominantEmotion = emotions.groupingBy { it }
            .eachCount()
            .maxByOrNull { it.value }?.key ?: Emotion.NEUTRAL
        
        // 计算强度（出现次数越多，强度越高）
        val intensity = emotions.count { it == dominantEmotion } / 4f
        
        // 计算置信度
        val confidence = 0.6f + (intensity * 0.4f)
        
        return EmotionState(
            emotion = dominantEmotion,
            intensity = intensity,
            confidence = confidence,
            timestamp = System.currentTimeMillis()
        )
    }
    
    /**
     * 📝 记录情绪历史
     */
    private fun recordEmotion(emotionState: EmotionState) {
        val record = EmotionRecord(
            emotion = emotionState.emotion,
            intensity = emotionState.intensity,
            timestamp = emotionState.timestamp
        )
        
        emotionHistory.add(record)
        
        // 只保留最近100条记录
        if (emotionHistory.size > 100) {
            emotionHistory.removeAt(0)
        }
    }
    
    /**
     * 📊 获取情绪历史
     */
    fun getEmotionHistory(duration: Long = 24 * 60 * 60 * 1000): List<EmotionRecord> {
        val cutoffTime = System.currentTimeMillis() - duration
        return emotionHistory.filter { it.timestamp >= cutoffTime }
    }
    
    /**
     * 📈 分析情绪趋势
     */
    fun analyzeEmotionTrend(): EmotionTrend {
        val recentEmotions = getEmotionHistory(3 * 60 * 60 * 1000) // 最近3小时
        
        if (recentEmotions.isEmpty()) {
            return EmotionTrend.STABLE
        }
        
        // 计算平均强度
        val avgIntensity = recentEmotions.map { it.intensity }.average()
        
        // 统计消极情绪比例
        val negativeCount = recentEmotions.count { 
            it.emotion in listOf(Emotion.SAD, Emotion.ANXIOUS, Emotion.STRESSED, Emotion.ANGRY)
        }
        val negativeRatio = negativeCount.toFloat() / recentEmotions.size
        
        return when {
            negativeRatio > 0.6 -> EmotionTrend.DECLINING
            negativeRatio < 0.2 -> EmotionTrend.IMPROVING
            else -> EmotionTrend.STABLE
        }
    }
    
    /**
     * ⚠️ 检测压力预警
     */
    fun detectStressAlert(): Boolean {
        val recentEmotions = getEmotionHistory(24 * 60 * 60 * 1000) // 最近24小时
        
        if (recentEmotions.isEmpty()) return false
        
        // 计算高压力情绪比例
        val stressedCount = recentEmotions.count {
            it.emotion in listOf(Emotion.STRESSED, Emotion.ANXIOUS, Emotion.ANGRY) &&
            it.intensity > 0.6f
        }
        
        val stressRatio = stressedCount.toFloat() / recentEmotions.size
        
        // 如果超过50%的时间处于高压力状态，触发预警
        return stressRatio > 0.5f
    }
    
    /**
     * 💡 生成情绪化响应建议
     */
    fun generateEmotionalResponse(emotion: Emotion): EmotionalResponse {
        return when (emotion) {
            Emotion.HAPPY -> EmotionalResponse(
                tone = "轻快活泼",
                emoji = "😊🎉✨",
                suggestion = "太好了！要不要听首欢快的歌庆祝一下？"
            )
            
            Emotion.SAD -> EmotionalResponse(
                tone = "温柔安慰",
                emoji = "🫂💕",
                suggestion = "主人，不开心了吗？需要陪你聊聊天吗？"
            )
            
            Emotion.ANXIOUS, Emotion.STRESSED -> EmotionalResponse(
                tone = "舒缓放松",
                emoji = "🧘‍♀️🌸",
                suggestion = "主人，感觉有点紧张？要不要放松一下，我给你播放冥想音乐？"
            )
            
            Emotion.ANGRY -> EmotionalResponse(
                tone = "平和冷静",
                emoji = "😌",
                suggestion = "深呼吸，我们慢慢来，有什么我能帮到你的吗？"
            )
            
            Emotion.TIRED -> EmotionalResponse(
                tone = "温柔体贴",
                emoji = "😴💤",
                suggestion = "主人，看起来有点累了呢，要不要休息一下？"
            )
            
            Emotion.EXCITED -> EmotionalResponse(
                tone = "热情高涨",
                emoji = "🎊🚀",
                suggestion = "哇！主人看起来很兴奋呢！发生什么好事了吗？"
            )
            
            else -> EmotionalResponse(
                tone = "自然亲切",
                emoji = "😊",
                suggestion = null
            )
        }
    }
    
    /**
     * 📊 获取统计信息
     */
    fun getStatistics(): EmotionStatistics {
        val recentEmotions = getEmotionHistory()
        
        val emotionCounts = recentEmotions
            .groupingBy { it.emotion }
            .eachCount()
        
        val dominantEmotion = emotionCounts.maxByOrNull { it.value }?.key
        
        return EmotionStatistics(
            totalRecords = recentEmotions.size,
            dominantEmotion = dominantEmotion,
            emotionDistribution = emotionCounts,
            trend = analyzeEmotionTrend(),
            hasStressAlert = detectStressAlert()
        )
    }
}

/**
 * 🎭 情绪类型
 */
enum class Emotion {
    HAPPY,          // 开心
    SAD,            // 悲伤
    ANGRY,          // 生气
    ANXIOUS,        // 焦虑
    STRESSED,       // 压力大
    TIRED,          // 疲惫
    EXCITED,        // 兴奋
    ANNOYED,        // 烦躁
    CALM,           // 平静
    NEUTRAL         // 中性
}

/**
 * 📊 情绪状态
 */
data class EmotionState(
    val emotion: Emotion,
    val intensity: Float,          // 强度 0-1
    val confidence: Float,         // 置信度 0-1
    val timestamp: Long = System.currentTimeMillis()
) {
    companion object {
        val DEFAULT = EmotionState(
            emotion = Emotion.NEUTRAL,
            intensity = 0.5f,
            confidence = 0.5f
        )
    }
}

/**
 * 📝 情绪记录
 */
data class EmotionRecord(
    val emotion: Emotion,
    val intensity: Float,
    val timestamp: Long
)

/**
 * 📈 情绪趋势
 */
enum class EmotionTrend {
    IMPROVING,      // 好转
    STABLE,         // 稳定
    DECLINING       // 恶化
}

/**
 * 🎤 语音语调
 */
data class VoiceTone(
    val pitch: Float,       // 音高 (1.0为正常)
    val speed: Float,       // 语速 (1.0为正常)
    val volume: Float       // 音量 (0-1)
)

/**
 * 💬 说话模式
 */
data class SpeechPattern(
    val wordsPerMinute: Int,        // 每分钟词数
    val avgSentenceLength: Int,     // 平均句子长度
    val pauseFrequency: Float       // 停顿频率
)

/**
 * 🚶 用户行为
 */
data class UserBehavior(
    val actionFrequency: Int,       // 操作频率
    val repeatActions: Int,         // 重复操作次数
    val errorRate: Float            // 错误率
)

/**
 * 💡 情绪化响应
 */
data class EmotionalResponse(
    val tone: String,               // 语气风格
    val emoji: String,              // 表情符号
    val suggestion: String?         // 建议
)

/**
 * 📊 情绪统计
 */
data class EmotionStatistics(
    val totalRecords: Int,
    val dominantEmotion: Emotion?,
    val emotionDistribution: Map<Emotion, Int>,
    val trend: EmotionTrend,
    val hasStressAlert: Boolean
)
