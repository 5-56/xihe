package com.example.xihe.intelligence

import android.content.Context
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/**
 * 🧠 记忆系统
 * 长期记忆、工作记忆、知识图谱
 */
class MemorySystem(private val context: Context) {
    
    companion object {
        private const val TAG = "MemorySystem"
        private const val MEMORY_FILE = "user_memory.json"
        private const val KNOWLEDGE_GRAPH_FILE = "knowledge_graph.json"
        
        @Volatile
        private var instance: MemorySystem? = null
        
        fun getInstance(context: Context): MemorySystem {
            return instance ?: synchronized(this) {
                instance ?: MemorySystem(context.applicationContext).also {
                    instance = it
                }
            }
        }
    }
    
    // 用户画像
    private val _userProfile = MutableStateFlow(UserProfile())
    val userProfile = _userProfile.asStateFlow()
    
    // 短期记忆（当天对话）
    private val shortTermMemory = mutableListOf<Conversation>()
    
    // 工作记忆（当前任务上下文）
    private var workingMemory: TaskContext? = null
    
    // 知识图谱
    private val knowledgeGraph = mutableMapOf<String, KnowledgeNode>()
    
    // 重要记忆
    private val importantMemories = mutableListOf<Memory>()
    
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    
    init {
        loadMemory()
    }
    
    /**
     * 💾 加载记忆
     */
    private fun loadMemory() {
        scope.launch {
            try {
                val memoryFile = File(context.filesDir, MEMORY_FILE)
                if (memoryFile.exists()) {
                    val json = JSONObject(memoryFile.readText())
                    _userProfile.value = parseUserProfile(json)
                    LogManager.i(TAG, "✅ 记忆加载成功")
                }
            } catch (e: Exception) {
                LogManager.e(TAG, "❌ 记忆加载失败", e)
            }
        }
    }
    
    /**
     * 💾 保存记忆
     */
    fun saveMemory() {
        scope.launch {
            try {
                val json = serializeUserProfile(_userProfile.value)
                val memoryFile = File(context.filesDir, MEMORY_FILE)
                memoryFile.writeText(json.toString(2))
                LogManager.i(TAG, "✅ 记忆保存成功")
            } catch (e: Exception) {
                LogManager.e(TAG, "❌ 记忆保存失败", e)
            }
        }
    }
    
    /**
     * 📝 从对话中学习
     */
    fun learnFromConversation(userInput: String, aiResponse: String) {
        try {
            // 添加到短期记忆
            shortTermMemory.add(
                Conversation(
                    userInput = userInput,
                    aiResponse = aiResponse,
                    timestamp = System.currentTimeMillis()
                )
            )
            
            // 提取知识
            extractKnowledge(userInput)
            
            // 保存记忆
            saveMemory()
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 从对话学习失败", e)
        }
    }
    
    /**
     * 🔍 提取知识
     */
    private fun extractKnowledge(text: String) {
        val normalized = text.lowercase()
        
        // 提取喜好
        extractPreferences(normalized)
        
        // 提取人物关系
        extractRelationships(normalized)
        
        // 提取重要日期
        extractImportantDates(normalized)
        
        // 提取习惯
        extractHabits(normalized)
    }
    
    /**
     * 💚 提取喜好
     */
    private fun extractPreferences(text: String) {
        val profile = _userProfile.value.copy()
        
        // 音乐喜好
        val musicKeywords = mapOf(
            "喜欢" to listOf("周杰伦", "林俊杰", "邓紫棋", "流行", "民谣", "摇滚"),
            "不喜欢" to listOf("重金属", "说唱")
        )
        
        musicKeywords.forEach { (preference, keywords) ->
            keywords.forEach { keyword ->
                if (text.contains(keyword) && text.contains("歌") || text.contains("音乐")) {
                    when (preference) {
                        "喜欢" -> {
                            if (!profile.preferences.musicLikes.contains(keyword)) {
                                profile.preferences.musicLikes.add(keyword)
                                LogManager.d(TAG, "📝 学习到音乐喜好: $keyword")
                            }
                        }
                        "不喜欢" -> {
                            if (!profile.preferences.musicDislikes.contains(keyword)) {
                                profile.preferences.musicDislikes.add(keyword)
                                LogManager.d(TAG, "📝 学习到音乐厌恶: $keyword")
                            }
                        }
                    }
                }
            }
        }
        
        // 食物喜好
        if (text.contains("喜欢吃") || text.contains("爱吃")) {
            // 简单模式识别
            val foods = listOf("火锅", "烧烤", "寿司", "川菜", "湘菜", "粤菜")
            foods.forEach { food ->
                if (text.contains(food) && !profile.preferences.foodLikes.contains(food)) {
                    profile.preferences.foodLikes.add(food)
                    LogManager.d(TAG, "📝 学习到食物喜好: $food")
                }
            }
        }
        
        if (text.contains("不喜欢") || text.contains("讨厌") || text.contains("过敏")) {
            val foods = listOf("香菜", "芹菜", "海鲜", "牛奶", "鸡蛋")
            foods.forEach { food ->
                if (text.contains(food) && !profile.preferences.foodDislikes.contains(food)) {
                    profile.preferences.foodDislikes.add(food)
                    LogManager.d(TAG, "📝 学习到食物厌恶: $food")
                }
            }
        }
        
        _userProfile.value = profile
    }
    
    /**
     * 👥 提取人物关系
     */
    private fun extractRelationships(text: String) {
        val profile = _userProfile.value.copy()
        
        // 关系关键词
        val relationshipKeywords = mapOf(
            "爸爸" to RelationType.FATHER,
            "妈妈" to RelationType.MOTHER,
            "哥哥" to RelationType.BROTHER,
            "姐姐" to RelationType.SISTER,
            "弟弟" to RelationType.BROTHER,
            "妹妹" to RelationType.SISTER,
            "老婆" to RelationType.SPOUSE,
            "妻子" to RelationType.SPOUSE,
            "老公" to RelationType.SPOUSE,
            "丈夫" to RelationType.SPOUSE,
            "男朋友" to RelationType.BOYFRIEND,
            "女朋友" to RelationType.GIRLFRIEND,
            "儿子" to RelationType.SON,
            "女儿" to RelationType.DAUGHTER,
            "同事" to RelationType.COLLEAGUE,
            "朋友" to RelationType.FRIEND
        )
        
        relationshipKeywords.forEach { (keyword, relationType) ->
            if (text.contains(keyword)) {
                // 尝试提取名字
                val namePattern = Regex("$keyword[叫是]([\\u4e00-\\u9fa5]{2,4})")
                val matchResult = namePattern.find(text)
                
                if (matchResult != null) {
                    val name = matchResult.groupValues[1]
                    val existing = profile.relationships.find { 
                        it.name == name && it.type == relationType 
                    }
                    
                    if (existing == null) {
                        profile.relationships.add(
                            Relationship(
                                name = name,
                                type = relationType,
                                notes = null
                            )
                        )
                        LogManager.d(TAG, "📝 学习到人物关系: $name ($relationType)")
                    }
                }
            }
        }
        
        _userProfile.value = profile
    }
    
    /**
     * 📅 提取重要日期
     */
    private fun extractImportantDates(text: String) {
        val profile = _userProfile.value.copy()
        
        // 生日关键词
        if (text.contains("生日")) {
            // 提取日期 (简单模式)
            val datePattern = Regex("(\\d{1,2})月(\\d{1,2})日")
            val matchResult = datePattern.find(text)
            
            if (matchResult != null) {
                val month = matchResult.groupValues[1]
                val day = matchResult.groupValues[2]
                val dateStr = "${month}月${day}日"
                
                // 判断是谁的生日
                val person = when {
                    text.contains("我的") || text.contains("是") -> "我"
                    text.contains("爸爸") -> "爸爸"
                    text.contains("妈妈") -> "妈妈"
                    text.contains("女朋友") || text.contains("男朋友") -> "恋人"
                    else -> null
                }
                
                if (person != null) {
                    val existing = profile.importantDates.find {
                        it.name == "${person}的生日"
                    }
                    
                    if (existing == null) {
                        profile.importantDates.add(
                            ImportantDate(
                                name = "${person}的生日",
                                date = dateStr,
                                type = DateType.BIRTHDAY
                            )
                        )
                        LogManager.d(TAG, "📝 学习到重要日期: ${person}的生日 $dateStr")
                    }
                }
            }
        }
        
        _userProfile.value = profile
    }
    
    /**
     * 🔄 提取习惯
     */
    private fun extractHabits(text: String) {
        val profile = _userProfile.value.copy()
        
        // 时间习惯
        if (text.contains("每天") || text.contains("习惯")) {
            val timePattern = Regex("(\\d{1,2})点")
            val matchResult = timePattern.find(text)
            
            if (matchResult != null) {
                val hour = matchResult.groupValues[1]
                
                val activity = when {
                    text.contains("起床") -> "起床"
                    text.contains("睡觉") -> "睡觉"
                    text.contains("运动") -> "运动"
                    text.contains("吃饭") -> "吃饭"
                    else -> null
                }
                
                if (activity != null) {
                    val existing = profile.habits.find { it.description.contains(activity) }
                    
                    if (existing == null) {
                        profile.habits.add(
                            Habit(
                                description = "每天${hour}点${activity}",
                                frequency = HabitFrequency.DAILY,
                                time = "${hour}:00"
                            )
                        )
                        LogManager.d(TAG, "📝 学习到习惯: 每天${hour}点${activity}")
                    }
                }
            }
        }
        
        // 周期习惯
        val weekdayMap = mapOf(
            "周一" to "Monday", "周二" to "Tuesday", "周三" to "Wednesday",
            "周四" to "Thursday", "周五" to "Friday", "周六" to "Saturday", "周日" to "Sunday"
        )
        
        weekdayMap.forEach { (chinese, english) ->
            if (text.contains(chinese)) {
                val activity = when {
                    text.contains("健身") -> "去健身房"
                    text.contains("聚会") -> "朋友聚会"
                    text.contains("看电影") -> "看电影"
                    else -> null
                }
                
                if (activity != null) {
                    val existing = profile.habits.find {
                        it.description.contains(chinese) && it.description.contains(activity)
                    }
                    
                    if (existing == null) {
                        profile.habits.add(
                            Habit(
                                description = "${chinese}${activity}",
                                frequency = HabitFrequency.WEEKLY,
                                dayOfWeek = english
                            )
                        )
                        LogManager.d(TAG, "📝 学习到习惯: ${chinese}${activity}")
                    }
                }
            }
        }
        
        _userProfile.value = profile
    }
    
    /**
     * 🔍 查询记忆
     */
    fun queryMemory(keyword: String): List<Memory> {
        return importantMemories.filter {
            it.content.contains(keyword, ignoreCase = true)
        }
    }
    
    /**
     * 💭 获取今日对话
     */
    fun getTodayConversations(): List<Conversation> {
        val todayStart = LocalDate.now().atStartOfDay()
            .atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
        
        return shortTermMemory.filter { it.timestamp >= todayStart }
    }
    
    /**
     * 📊 获取统计信息
     */
    fun getStatistics(): MemoryStatistics {
        return MemoryStatistics(
            totalConversations = shortTermMemory.size,
            totalMemories = importantMemories.size,
            relationshipsCount = _userProfile.value.relationships.size,
            habitsCount = _userProfile.value.habits.size,
            importantDatesCount = _userProfile.value.importantDates.size
        )
    }
    
    /**
     * 🗑️ 清空所有记忆
     */
    fun clearAllMemories() {
        scope.launch {
            try {
                shortTermMemory.clear()
                importantMemories.clear()
                knowledgeGraph.clear()
                workingMemory = null
                _userProfile.value = UserProfile()
                
                // 删除本地文件
                val memoryFile = File(context.filesDir, MEMORY_FILE)
                if (memoryFile.exists()) {
                    memoryFile.delete()
                }
                
                val knowledgeFile = File(context.filesDir, KNOWLEDGE_GRAPH_FILE)
                if (knowledgeFile.exists()) {
                    knowledgeFile.delete()
                }
                
                LogManager.i(TAG, "🗑️ 所有记忆已清空")
            } catch (e: Exception) {
                LogManager.e(TAG, "❌ 清空记忆失败", e)
            }
        }
    }
    
    /**
     * 🔄 解析用户画像
     */
    private fun parseUserProfile(json: JSONObject): UserProfile {
        // 简化版解析
        return UserProfile(
            personalInfo = PersonalInfo(),
            preferences = Preferences(),
            habits = mutableListOf(),
            relationships = mutableListOf(),
            importantDates = mutableListOf()
        )
    }
    
    /**
     * 🔄 序列化用户画像
     */
    private fun serializeUserProfile(profile: UserProfile): JSONObject {
        val json = JSONObject()
        
        // 序列化喜好
        val prefsJson = JSONObject()
        prefsJson.put("musicLikes", JSONArray(profile.preferences.musicLikes))
        prefsJson.put("musicDislikes", JSONArray(profile.preferences.musicDislikes))
        prefsJson.put("foodLikes", JSONArray(profile.preferences.foodLikes))
        prefsJson.put("foodDislikes", JSONArray(profile.preferences.foodDislikes))
        json.put("preferences", prefsJson)
        
        // 序列化关系
        val relationshipsJson = JSONArray()
        profile.relationships.forEach { rel ->
            val relJson = JSONObject()
            relJson.put("name", rel.name)
            relJson.put("type", rel.type.name)
            relJson.put("notes", rel.notes)
            relationshipsJson.put(relJson)
        }
        json.put("relationships", relationshipsJson)
        
        // 序列化日期
        val datesJson = JSONArray()
        profile.importantDates.forEach { date ->
            val dateJson = JSONObject()
            dateJson.put("name", date.name)
            dateJson.put("date", date.date)
            dateJson.put("type", date.type.name)
            datesJson.put(dateJson)
        }
        json.put("importantDates", datesJson)
        
        // 序列化习惯
        val habitsJson = JSONArray()
        profile.habits.forEach { habit ->
            val habitJson = JSONObject()
            habitJson.put("description", habit.description)
            habitJson.put("frequency", habit.frequency.name)
            habitJson.put("time", habit.time)
            habitJson.put("dayOfWeek", habit.dayOfWeek)
            habitsJson.put(habitJson)
        }
        json.put("habits", habitsJson)
        
        return json
    }
}

/**
 * 👤 用户画像
 */
data class UserProfile(
    val personalInfo: PersonalInfo = PersonalInfo(),
    val preferences: Preferences = Preferences(),
    val habits: MutableList<Habit> = mutableListOf(),
    val relationships: MutableList<Relationship> = mutableListOf(),
    val importantDates: MutableList<ImportantDate> = mutableListOf()
)

/**
 * ℹ️ 个人信息
 */
data class PersonalInfo(
    val name: String? = null,
    val birthday: String? = null,
    val age: Int? = null,
    val gender: String? = null,
    val occupation: String? = null
)

/**
 * ⭐ 偏好设置
 */
data class Preferences(
    val musicLikes: MutableList<String> = mutableListOf(),
    val musicDislikes: MutableList<String> = mutableListOf(),
    val foodLikes: MutableList<String> = mutableListOf(),
    val foodDislikes: MutableList<String> = mutableListOf(),
    val hobbies: MutableList<String> = mutableListOf()
)

/**
 * 🔄 习惯
 */
data class Habit(
    val description: String,
    val frequency: HabitFrequency,
    val time: String? = null,
    val dayOfWeek: String? = null
)

enum class HabitFrequency {
    DAILY, WEEKLY, MONTHLY
}

/**
 * 👥 人物关系
 */
data class Relationship(
    val name: String,
    val type: RelationType,
    val phone: String? = null,
    val notes: String? = null
)

enum class RelationType {
    FATHER, MOTHER, BROTHER, SISTER,
    SPOUSE, BOYFRIEND, GIRLFRIEND,
    SON, DAUGHTER,
    COLLEAGUE, FRIEND, OTHER
}

/**
 * 📅 重要日期
 */
data class ImportantDate(
    val name: String,
    val date: String,
    val type: DateType,
    val reminder: Boolean = true
)

enum class DateType {
    BIRTHDAY, ANNIVERSARY, APPOINTMENT, OTHER
}

/**
 * 💬 对话记录
 */
data class Conversation(
    val userInput: String,
    val aiResponse: String,
    val timestamp: Long
)

/**
 * 💭 记忆
 */
data class Memory(
    val content: String,
    val importance: Float,
    val timestamp: Long
)

/**
 * 📋 任务上下文
 */
data class TaskContext(
    val currentTask: String,
    val context: Map<String, Any>,
    val startTime: Long
)

/**
 * 🌐 知识节点
 */
data class KnowledgeNode(
    val id: String,
    val type: String,
    val properties: Map<String, Any>,
    val relations: MutableList<KnowledgeRelation> = mutableListOf()
)

data class KnowledgeRelation(
    val targetId: String,
    val relationType: String
)

/**
 * 📊 记忆统计
 */
data class MemoryStatistics(
    val totalConversations: Int,
    val totalMemories: Int,
    val relationshipsCount: Int,
    val habitsCount: Int,
    val importantDatesCount: Int
)
