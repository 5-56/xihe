package com.example.xihe.scheduler

import android.content.Context
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.*

/**
 * ⏰ 任务调度器
 * 定时执行任务
 */
class TaskScheduler(private val context: Context) {
    
    companion object {
        private const val TAG = "TaskScheduler"
        private const val SCHEDULES_DIR = "schedules"
        private const val SCHEDULE_FILE_EXTENSION = ".schedule"
        private const val MIN_CHECK_INTERVAL = 1000L
        private const val CHECK_INTERVAL = 10000L

        @Volatile
        private var instance: TaskScheduler? = null

        fun getInstance(context: Context): TaskScheduler {
            return instance ?: synchronized(this) {
                instance ?: TaskScheduler(context.applicationContext).also { instance = it }
            }
        }
    }
    
    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
    }
    
    private val schedulesMap = mutableMapOf<String, ScheduledTask>()
    private val _schedules = MutableStateFlow<List<ScheduledTask>>(emptyList())
    val schedules = _schedules.asStateFlow()
    
    private val schedulerScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var schedulerJob: Job? = null
    private var loadJob: Job? = null
    private val _isRunning = MutableStateFlow(false)
    val isRunning = _isRunning.asStateFlow()
    
    private val schedulesDir: File by lazy {
        File(context.filesDir, SCHEDULES_DIR).apply {
            if (!exists()) {
                mkdirs()
            }
        }
    }
    
    init {
        loadSchedules()
    }
    
    /**
     * ▶️ 启动调度器
     */
    fun start() {
        if (_isRunning.value) {
            LogManager.d(TAG, "⚠️ 调度器已在运行")
            return
        }
        
        _isRunning.value = true
        
        val job = schedulerScope.launch {
            while (isActive && _isRunning.value) {
                try {
                    val now = System.currentTimeMillis()
                    checkAndExecuteTasks(now)
                    delay(calculateCheckInterval(now))
                } catch (e: Exception) {
                    LogManager.d(TAG, "❌ 检查任务失败", e)
                    delay(CHECK_INTERVAL)
                }
            }
        }
        schedulerJob = job
        job.invokeOnCompletion {
            if (schedulerJob === job) {
                schedulerJob = null
            }
        }
        
        LogManager.d(TAG, "▶️ 任务调度器已启动")
    }
    
    /**
     * ⏹️ 停止调度器
     */
    fun stop() {
        _isRunning.value = false
        schedulerJob?.cancel()
        schedulerJob = null
        
        LogManager.d(TAG, "⏹️ 任务调度器已停止")
    }
    
    /**
     * 🔍 检查并执行任务
     */
    private suspend fun checkAndExecuteTasks(now: Long) {
        for (schedule in schedulesMap.values.toList()) {
            if (!schedule.enabled) continue
            
            if (shouldExecute(schedule, now)) {
                executeScheduledTask(schedule)
            }
        }
    }

    private fun calculateCheckInterval(now: Long): Long {
        val nextExecutionTime = schedulesMap.values
            .toList()
            .asSequence()
            .filter { it.enabled }
            .map { it.nextExecutionTime }
            .filter { it > now }
            .minOrNull()
            ?: return CHECK_INTERVAL

        return (nextExecutionTime - now).coerceIn(MIN_CHECK_INTERVAL, CHECK_INTERVAL)
    }
    
    /**
     * 🎯 判断是否应该执行
     */
    private fun shouldExecute(schedule: ScheduledTask, now: Long): Boolean {
        // 检查是否到了下次执行时间
        if (now < schedule.nextExecutionTime) {
            return false
        }
        
        // 检查是否在时间范围内
        if (schedule.startTime != null && now < schedule.startTime) {
            return false
        }
        if (schedule.endTime != null && now > schedule.endTime) {
            return false
        }
        
        // 检查星期
        if (schedule.daysOfWeek.isNotEmpty()) {
            val calendar = Calendar.getInstance()
            calendar.timeInMillis = now
            val dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK)
            if (!schedule.daysOfWeek.contains(dayOfWeek)) {
                return false
            }
        }
        
        // 检查执行次数
        if (schedule.maxExecutions > 0 && schedule.executionCount >= schedule.maxExecutions) {
            return false
        }
        
        return true
    }
    
    /**
     * ▶️ 执行计划任务
     */
    private suspend fun executeScheduledTask(schedule: ScheduledTask) {
        try {
            LogManager.d(TAG, "▶️ 执行计划任务: ${schedule.name}")
            
            // 更新执行信息
            val updatedSchedule = schedule.copy(
                lastExecutionTime = System.currentTimeMillis(),
                nextExecutionTime = calculateNextExecutionTime(schedule),
                executionCount = schedule.executionCount + 1
            )
            
            schedulesMap[schedule.id] = updatedSchedule
            saveSchedule(updatedSchedule)
            updateSchedulesList()
            
            // 这里应该调用实际的任务执行逻辑
            // 例如：taskExecutor.execute(schedule.taskId)
            
            LogManager.d(TAG, "✅ 任务执行完成: ${schedule.name}")
            
        } catch (e: Exception) {
            LogManager.d(TAG, "❌ 执行任务失败: ${schedule.name}", e)
        }
    }
    
    /**
     * ⏱️ 计算下次执行时间
     */
    private fun calculateNextExecutionTime(schedule: ScheduledTask): Long {
        val now = System.currentTimeMillis()
        
        return when (schedule.type) {
            ScheduleType.ONCE -> {
                // 一次性任务，不再执行
                Long.MAX_VALUE
            }
            ScheduleType.INTERVAL -> {
                // 间隔执行
                now + schedule.intervalMillis
            }
            ScheduleType.DAILY -> {
                // 每天指定时间
                calculateDailyNextTime(now, schedule.timeOfDay)
            }
            ScheduleType.WEEKLY -> {
                // 每周指定时间
                calculateWeeklyNextTime(now, schedule.daysOfWeek, schedule.timeOfDay)
            }
            ScheduleType.CRON -> {
                // Cron表达式（简化版）
                now + schedule.intervalMillis
            }
        }
    }
    
    /**
     * 📅 计算每日下次执行时间
     */
    private fun calculateDailyNextTime(now: Long, timeOfDay: String?): Long {
        if (timeOfDay == null) return now + 24 * 60 * 60 * 1000L
        
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = now
        
        // 解析时间 "HH:mm"
        val parts = timeOfDay.split(":")
        if (parts.size == 2) {
            val hour = parts[0].toIntOrNull() ?: 0
            val minute = parts[1].toIntOrNull() ?: 0
            
            calendar.set(Calendar.HOUR_OF_DAY, hour)
            calendar.set(Calendar.MINUTE, minute)
            calendar.set(Calendar.SECOND, 0)
            calendar.set(Calendar.MILLISECOND, 0)
            
            // 如果今天的时间已过，改为明天
            if (calendar.timeInMillis <= now) {
                calendar.add(Calendar.DAY_OF_MONTH, 1)
            }
            
            return calendar.timeInMillis
        }
        
        return now + 24 * 60 * 60 * 1000L
    }
    
    /**
     * 📅 计算每周下次执行时间
     */
    private fun calculateWeeklyNextTime(now: Long, daysOfWeek: List<Int>, timeOfDay: String?): Long {
        if (daysOfWeek.isEmpty()) return now + 7 * 24 * 60 * 60 * 1000L
        
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = now
        
        val currentDayOfWeek = calendar.get(Calendar.DAY_OF_WEEK)
        
        // 找到下一个匹配的星期
        for (i in 0..7) {
            calendar.timeInMillis = now + i * 24 * 60 * 60 * 1000L
            val dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK)
            
            if (daysOfWeek.contains(dayOfWeek)) {
                // 设置时间
                if (timeOfDay != null) {
                    val parts = timeOfDay.split(":")
                    if (parts.size == 2) {
                        val hour = parts[0].toIntOrNull() ?: 0
                        val minute = parts[1].toIntOrNull() ?: 0
                        
                        calendar.set(Calendar.HOUR_OF_DAY, hour)
                        calendar.set(Calendar.MINUTE, minute)
                        calendar.set(Calendar.SECOND, 0)
                        calendar.set(Calendar.MILLISECOND, 0)
                    }
                }
                
                if (calendar.timeInMillis > now) {
                    return calendar.timeInMillis
                }
            }
        }
        
        return now + 7 * 24 * 60 * 60 * 1000L
    }
    
    /**
     * ➕ 添加计划任务
     */
    suspend fun addSchedule(schedule: ScheduledTask): Boolean {
        return try {
            schedulesMap[schedule.id] = schedule
            saveSchedule(schedule)
            updateSchedulesList()
            
            LogManager.d(TAG, "➕ 添加计划任务: ${schedule.name}")
            true
        } catch (e: Exception) {
            LogManager.d(TAG, "❌ 添加计划任务失败", e)
            false
        }
    }
    
    /**
     * 🗑️ 删除计划任务
     */
    suspend fun deleteSchedule(scheduleId: String): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val file = File(schedulesDir, "$scheduleId$SCHEDULE_FILE_EXTENSION")
                val deleted = file.delete()
                
                if (deleted) {
                    schedulesMap.remove(scheduleId)
                    updateSchedulesList()
                    LogManager.d(TAG, "🗑️ 删除计划任务: $scheduleId")
                }
                
                deleted
            } catch (e: Exception) {
                LogManager.d(TAG, "❌ 删除计划任务失败", e)
                false
            }
        }
    }
    
    /**
     * 🔄 启用/禁用计划任务
     */
    suspend fun toggleSchedule(scheduleId: String, enabled: Boolean): Boolean {
        return try {
            val schedule = schedulesMap[scheduleId]
            if (schedule != null) {
                val updated = schedule.copy(enabled = enabled)
                schedulesMap[scheduleId] = updated
                saveSchedule(updated)
                updateSchedulesList()
                
                LogManager.d(TAG, "🔄 ${if (enabled) "启用" else "禁用"}计划任务: ${schedule.name}")
                true
            } else {
                false
            }
        } catch (e: Exception) {
            LogManager.d(TAG, "❌ 切换计划任务状态失败", e)
            false
        }
    }
    
    /**
     * 💾 保存计划任务
     */
    private suspend fun saveSchedule(schedule: ScheduledTask): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val file = File(schedulesDir, "${schedule.id}$SCHEDULE_FILE_EXTENSION")
                val jsonString = json.encodeToString(schedule)
                file.writeText(jsonString)
                true
            } catch (e: Exception) {
                LogManager.d(TAG, "❌ 保存计划任务失败", e)
                false
            }
        }
    }
    
    /**
     * 📖 加载所有计划任务
     */
    private fun loadSchedules() {
        loadJob?.cancel()
        val job = schedulerScope.launch(Dispatchers.IO) {
            try {
                val files = schedulesDir.listFiles { file ->
                    file.extension == SCHEDULE_FILE_EXTENSION.removePrefix(".")
                }
                
                files?.forEach { file ->
                    try {
                        val jsonString = file.readText()
                        val schedule = json.decodeFromString<ScheduledTask>(jsonString)
                        schedulesMap[schedule.id] = schedule
                    } catch (e: Exception) {
                        LogManager.d(TAG, "❌ 加载计划任务文件失败: ${file.name}", e)
                    }
                }
                
                updateSchedulesList()
                LogManager.d(TAG, "📖 已加载 ${schedulesMap.size} 个计划任务")
            } catch (e: Exception) {
                LogManager.d(TAG, "❌ 加载计划任务失败", e)
            }
        }
        loadJob = job
    }
    
    /**
     * 🔄 更新计划任务列表
     */
    private fun updateSchedulesList() {
        _schedules.value = schedulesMap.values
            .sortedBy { it.nextExecutionTime }
    }
    
    /**
     * 📊 获取调度统计
     */
    fun getScheduleStatistics(): ScheduleStatistics {
        val schedules = schedulesMap.values
        
        return ScheduleStatistics(
            totalSchedules = schedules.size,
            enabledSchedules = schedules.count { it.enabled },
            disabledSchedules = schedules.count { !it.enabled },
            totalExecutions = schedules.sumOf { it.executionCount }
        )
    }
    
    // ============ 数据类型 ============
    
    /**
     * ⏰ 计划任务
     */
    @Serializable
    data class ScheduledTask(
        val id: String,
        val name: String,
        val description: String = "",
        val taskId: String,                 // 要执行的任务ID
        val type: ScheduleType,
        val enabled: Boolean = true,
        val intervalMillis: Long = 0L,      // 间隔时间（毫秒）
        val timeOfDay: String? = null,      // 每天的时间 "HH:mm"
        val daysOfWeek: List<Int> = emptyList(), // 星期几 (1=Sunday, 2=Monday, ...)
        val startTime: Long? = null,        // 开始时间
        val endTime: Long? = null,          // 结束时间
        val maxExecutions: Int = 0,         // 最大执行次数（0=无限制）
        val lastExecutionTime: Long = 0L,   // 上次执行时间
        val nextExecutionTime: Long = 0L,   // 下次执行时间
        val executionCount: Int = 0,        // 已执行次数
        val createdAt: Long = System.currentTimeMillis()
    )
    
    /**
     * 🏷️ 调度类型
     */
    @Serializable
    enum class ScheduleType {
        ONCE,           // 一次性
        INTERVAL,       // 间隔执行
        DAILY,          // 每天
        WEEKLY,         // 每周
        CRON            // Cron表达式
    }
    
    /**
     * 📊 调度统计
     */
    data class ScheduleStatistics(
        val totalSchedules: Int,
        val enabledSchedules: Int,
        val disabledSchedules: Int,
        val totalExecutions: Int
    )
}
