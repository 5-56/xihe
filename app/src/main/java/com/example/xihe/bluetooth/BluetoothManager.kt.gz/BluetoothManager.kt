package com.example.xihe.bluetooth

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager as SystemBluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

/**
 * 📡 蓝牙管理器
 * 提供蓝牙开关、设备扫描、连接等功能
 */
class BluetoothManager private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "BluetoothManager"
        
        @Volatile
        private var instance: BluetoothManager? = null
        
        fun getInstance(context: Context): BluetoothManager {
            return instance ?: synchronized(this) {
                instance ?: BluetoothManager(context.applicationContext).also { instance = it }
            }
        }
    }
    
    private val systemBluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? SystemBluetoothManager
    private val bluetoothAdapter: BluetoothAdapter? = systemBluetoothManager?.adapter
    
    private val _discoveredDevices = MutableStateFlow<List<BluetoothDeviceInfo>>(emptyList())
    val discoveredDevices = _discoveredDevices.asStateFlow()
    
    private val _isScanning = MutableStateFlow(false)
    val isScanning = _isScanning.asStateFlow()
    
    private var discoveryReceiver: BroadcastReceiver? = null
    
    /**
     * 蓝牙设备信息
     */
    data class BluetoothDeviceInfo(
        val name: String?,
        val address: String,
        val bondState: Int,
        val type: Int,
        val rssi: Int? = null
    ) {
        fun isBonded(): Boolean = bondState == BluetoothDevice.BOND_BONDED
        
        fun getTypeString(): String {
            return when (type) {
                BluetoothDevice.DEVICE_TYPE_CLASSIC -> "经典蓝牙"
                BluetoothDevice.DEVICE_TYPE_LE -> "低功耗蓝牙"
                BluetoothDevice.DEVICE_TYPE_DUAL -> "双模蓝牙"
                else -> "未知"
            }
        }
    }
    
    /**
     * 📡 检查蓝牙是否可用
     */
    fun isBluetoothAvailable(): Boolean {
        return bluetoothAdapter != null
    }
    
    /**
     * 📡 检查蓝牙是否开启
     */
    fun isBluetoothEnabled(): Boolean {
        return bluetoothAdapter?.isEnabled == true
    }
    
    /**
     * 📡 开启蓝牙
     */
    fun enableBluetooth(): Boolean {
        return try {
            if (!checkBluetoothPermissions()) {
                LogManager.w(TAG, "⚠️ 没有蓝牙权限")
                return false
            }
            
            if (bluetoothAdapter == null) {
                LogManager.w(TAG, "⚠️ 设备不支持蓝牙")
                return false
            }
            
            if (bluetoothAdapter.isEnabled) {
                LogManager.d(TAG, "蓝牙已经开启")
                return true
            }
            
            // Android 13+ 无法通过代码直接开启蓝牙
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                LogManager.w(TAG, "⚠️ Android 13+ 需要用户手动开启蓝牙")
                // 打开蓝牙设置页面
                val intent = Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                return false
            }
            
            @Suppress("DEPRECATION")
            val enabled = bluetoothAdapter.enable()
            LogManager.d(TAG, "✅ 请求开启蓝牙: $enabled")
            enabled
        } catch (e: Exception) {
            LogManager.e(TAG, "开启蓝牙失败", e)
            false
        }
    }
    
    /**
     * 📡 关闭蓝牙
     */
    fun disableBluetooth(): Boolean {
        return try {
            if (!checkBluetoothPermissions()) {
                LogManager.w(TAG, "⚠️ 没有蓝牙权限")
                return false
            }
            
            if (bluetoothAdapter == null) {
                return false
            }
            
            if (!bluetoothAdapter.isEnabled) {
                LogManager.d(TAG, "蓝牙已经关闭")
                return true
            }
            
            // Android 13+ 无法通过代码直接关闭蓝牙
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                LogManager.w(TAG, "⚠️ Android 13+ 需要用户手动关闭蓝牙")
                val intent = Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                return false
            }
            
            @Suppress("DEPRECATION")
            val disabled = bluetoothAdapter.disable()
            LogManager.d(TAG, "✅ 请求关闭蓝牙: $disabled")
            disabled
        } catch (e: Exception) {
            LogManager.e(TAG, "关闭蓝牙失败", e)
            false
        }
    }
    
    /**
     * 🔍 开始扫描蓝牙设备
     */
    suspend fun startDiscovery(): Boolean = withContext(Dispatchers.IO) {
        try {
            if (!checkBluetoothPermissions()) {
                LogManager.w(TAG, "⚠️ 没有蓝牙权限")
                return@withContext false
            }
            
            if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled) {
                LogManager.w(TAG, "⚠️ 蓝牙未开启")
                return@withContext false
            }
            
            // 如果正在扫描，先停止
            if (bluetoothAdapter.isDiscovering) {
                bluetoothAdapter.cancelDiscovery()
            }
            
            // 清空之前的设备列表
            _discoveredDevices.value = emptyList()
            
            // 注册广播接收器
            registerDiscoveryReceiver()
            
            // 开始扫描
            val started = bluetoothAdapter.startDiscovery()
            _isScanning.value = started
            
            LogManager.i(TAG, "🔍 开始扫描蓝牙设备: $started")
            started
        } catch (e: Exception) {
            LogManager.e(TAG, "开始扫描失败", e)
            false
        }
    }
    
    /**
     * ⏹️ 停止扫描
     */
    fun stopDiscovery(): Boolean {
        return try {
            if (!checkBluetoothPermissions()) {
                return false
            }
            
            val stopped = bluetoothAdapter?.cancelDiscovery() ?: false
            _isScanning.value = false
            
            // 注销广播接收器
            unregisterDiscoveryReceiver()
            
            LogManager.d(TAG, "⏹️ 停止扫描: $stopped")
            stopped
        } catch (e: Exception) {
            LogManager.e(TAG, "停止扫描失败", e)
            false
        }
    }
    
    /**
     * 📱 获取已配对的设备
     */
    fun getBondedDevices(): List<BluetoothDeviceInfo> {
        return try {
            if (!checkBluetoothPermissions()) {
                LogManager.w(TAG, "⚠️ 没有蓝牙权限")
                return emptyList()
            }
            
            val devices = bluetoothAdapter?.bondedDevices?.map { device ->
                BluetoothDeviceInfo(
                    name = device.name,
                    address = device.address,
                    bondState = device.bondState,
                    type = device.type
                )
            } ?: emptyList()
            
            LogManager.d(TAG, "📱 已配对设备: ${devices.size}个")
            devices
        } catch (e: Exception) {
            LogManager.e(TAG, "获取已配对设备失败", e)
            emptyList()
        }
    }
    
    /**
     * 🔗 配对设备
     */
    fun pairDevice(address: String): Boolean {
        return try {
            if (!checkBluetoothPermissions()) {
                LogManager.w(TAG, "⚠️ 没有蓝牙权限")
                return false
            }
            
            val device = bluetoothAdapter?.getRemoteDevice(address)
            val paired = device?.createBond() ?: false
            
            LogManager.i(TAG, "🔗 请求配对设备: $address, 结果: $paired")
            paired
        } catch (e: Exception) {
            LogManager.e(TAG, "配对设备失败", e)
            false
        }
    }
    
    /**
     * 🔓 取消配对
     */
    fun unpairDevice(address: String): Boolean {
        return try {
            if (!checkBluetoothPermissions()) {
                LogManager.w(TAG, "⚠️ 没有蓝牙权限")
                return false
            }
            
            val device = bluetoothAdapter?.getRemoteDevice(address)
            
            // 使用反射调用removeBond方法
            val method = device?.javaClass?.getMethod("removeBond")
            val result = method?.invoke(device) as? Boolean ?: false
            
            LogManager.i(TAG, "🔓 取消配对: $address, 结果: $result")
            result
        } catch (e: Exception) {
            LogManager.e(TAG, "取消配对失败", e)
            false
        }
    }
    
    /**
     * 📻 注册扫描广播接收器
     */
    private fun registerDiscoveryReceiver() {
        if (discoveryReceiver != null) {
            return
        }
        
        discoveryReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    BluetoothDevice.ACTION_FOUND -> {
                        if (!checkBluetoothPermissions()) {
                            return
                        }
                        
                        val device = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                        } else {
                            @Suppress("DEPRECATION")
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                        }
                        
                        val rssi = intent.getShortExtra(BluetoothDevice.EXTRA_RSSI, Short.MIN_VALUE).toInt()
                        
                        device?.let {
                            val deviceInfo = BluetoothDeviceInfo(
                                name = it.name,
                                address = it.address,
                                bondState = it.bondState,
                                type = it.type,
                                rssi = rssi
                            )
                            
                            val currentDevices = _discoveredDevices.value.toMutableList()
                            if (currentDevices.none { d -> d.address == deviceInfo.address }) {
                                currentDevices.add(deviceInfo)
                                _discoveredDevices.value = currentDevices
                                LogManager.d(TAG, "发现设备: ${deviceInfo.name ?: "未知"} (${deviceInfo.address})")
                            }
                        }
                    }
                    
                    BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                        _isScanning.value = false
                        LogManager.i(TAG, "🔍 扫描完成，共发现 ${_discoveredDevices.value.size} 个设备")
                    }
                }
            }
        }
        
        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
        }
        
        context.registerReceiver(discoveryReceiver, filter)
    }
    
    /**
     * 📻 注销扫描广播接收器
     */
    private fun unregisterDiscoveryReceiver() {
        try {
            discoveryReceiver?.let {
                context.unregisterReceiver(it)
                discoveryReceiver = null
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "注销广播接收器失败", e)
        }
    }
    
    /**
     * 📱 获取蓝牙适配器名称
     */
    fun getAdapterName(): String? {
        return try {
            if (!checkBluetoothPermissions()) {
                return null
            }
            bluetoothAdapter?.name
        } catch (e: Exception) {
            null
        }
    }
    
    /**
     * 📱 设置蓝牙适配器名称
     */
    fun setAdapterName(name: String): Boolean {
        return try {
            if (!checkBluetoothPermissions()) {
                LogManager.w(TAG, "⚠️ 没有蓝牙权限")
                return false
            }
            
            bluetoothAdapter?.name = name
            LogManager.d(TAG, "✅ 设置蓝牙名称: $name")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "设置蓝牙名称失败", e)
            false
        }
    }
    
    /**
     * 📱 获取蓝牙地址
     */
    fun getAdapterAddress(): String? {
        return try {
            if (!checkBluetoothPermissions()) {
                return null
            }
            bluetoothAdapter?.address
        } catch (e: Exception) {
            null
        }
    }
    
    /**
     * 🔍 搜索设备（按名称）
     */
    fun searchDeviceByName(name: String): List<BluetoothDeviceInfo> {
        val allDevices = getBondedDevices() + _discoveredDevices.value
        return allDevices.filter { 
            it.name?.contains(name, ignoreCase = true) == true 
        }.distinctBy { it.address }
    }
    
    /**
     * ⚙️ 打开蓝牙设置
     */
    fun openBluetoothSettings(): Boolean {
        return try {
            val intent = Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "打开蓝牙设置失败", e)
            false
        }
    }
    
    /**
     * ✅ 检查蓝牙权限
     */
    private fun checkBluetoothPermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            checkPermission(Manifest.permission.BLUETOOTH_CONNECT) &&
            checkPermission(Manifest.permission.BLUETOOTH_SCAN)
        } else {
            checkPermission(Manifest.permission.BLUETOOTH) &&
            checkPermission(Manifest.permission.BLUETOOTH_ADMIN)
        }
    }
    
    private fun checkPermission(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
    }
    
    /**
     * 🧹 清理资源
     */
    fun cleanup() {
        stopDiscovery()
        unregisterDiscoveryReceiver()
    }
}
