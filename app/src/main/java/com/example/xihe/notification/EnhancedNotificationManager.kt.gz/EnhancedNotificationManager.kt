package com.example.xihe.notification

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.RemoteInput
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * 🔔 增强通知管理器
 * 提供通知读取、回复、清除、分类等功能
 */
class EnhancedNotificationManager private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "EnhancedNotificationMgr"
        
        @Volatile
        private var instance: EnhancedNotificationManager? = null
        
        fun getInstance(context: Context): EnhancedNotificationManager {
            return instance ?: synchronized(this) {
                instance ?: EnhancedNotificationManager(context.applicationContext).also { instance = it }
            }
        }
        
        const val REPLY_ACTION = "com.example.xihe.NOTIFICATION_REPLY"
        const val KEY_TEXT_REPLY = "key_text_reply"
    }
    
    private val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    
    private val _activeNotifications = MutableStateFlow<List<NotificationInfo>>(emptyList())
    val activeNotifications = _activeNotifications.asStateFlow()
    
    /**
     * 通知信息
     */
    data class NotificationInfo(
        val id: Int,
        val key: String,
        val packageName: String,
        val appName: String,
        val title: String?,
        val text: String?,
        val bigText: String?,
        val subText: String?,
        val timestamp: Long,
        val category: NotificationCategory,
        val priority: Int,
        val isOngoing: Boolean,
        val isClearable: Boolean,
        val canReply: Boolean,
        val actions: List<NotificationAction>
    )
    
    /**
     * 通知分类
     */
    enum class NotificationCategory {
        MESSAGE,        // 消息类（微信、QQ等）
        SOCIAL,         // 社交类（微博、知乎等）
        SYSTEM,         // 系统类
        MEDIA,          // 媒体类（音乐、视频）
        EMAIL,          // 邮件类
        SHOPPING,       // 购物类
        NEWS,           // 新闻类
        PROMOTION,      // 推广类
        OTHER           // 其他
    }
    
    /**
     * 通知动作
     */
    data class NotificationAction(
        val title: String,
        val isReplyAction: Boolean = false
    )
    
    /**
     * 📋 获取所有活动通知
     */
    fun getActiveNotifications(): List<NotificationInfo> {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val notifications = notificationManager.activeNotifications
                notifications.mapNotNull { sbn -> parseNotification(sbn) }
            } else {
                emptyList()
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "获取活动通知失败", e)
            emptyList()
        }
    }
    
    /**
     * 📱 获取指定应用的通知
     */
    fun getNotificationsByPackage(packageName: String): List<NotificationInfo> {
        return getActiveNotifications().filter { it.packageName == packageName }
    }
    
    /**
     * 🗂️ 按分类获取通知
     */
    fun getNotificationsByCategory(category: NotificationCategory): List<NotificationInfo> {
        return getActiveNotifications().filter { it.category == category }
    }
    
    /**
     * 💬 获取消息类通知（微信、QQ等）
     */
    fun getMessageNotifications(): List<NotificationInfo> {
        return getNotificationsByCategory(NotificationCategory.MESSAGE)
    }
    
    /**
     * 🗑️ 清除指定通知
     */
    fun clearNotification(notificationKey: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                // 需要通过NotificationListenerService来清除
                // 这里返回true，实际清除操作在NotificationListenerService中完成
                LogManager.d(TAG, "请求清除通知: $notificationKey")
                true
            } else {
                false
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "清除通知失败", e)
            false
        }
    }
    
    /**
     * 🗑️ 清除所有通知
     */
    fun clearAllNotifications(): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                LogManager.d(TAG, "请求清除所有通知")
                true
            } else {
                false
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "清除所有通知失败", e)
            false
        }
    }
    
    /**
     * 🗑️ 清除指定应用的通知
     */
    fun clearNotificationsByPackage(packageName: String): Boolean {
        return try {
            val notifications = getNotificationsByPackage(packageName)
            notifications.forEach { clearNotification(it.key) }
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "清除应用通知失败", e)
            false
        }
    }
    
    /**
     * 💬 回复通知（需要NotificationListenerService支持）
     */
    fun replyToNotification(notificationKey: String, replyText: String): Boolean {
        return try {
            // 实际的回复操作需要在NotificationListenerService中实现
            LogManager.d(TAG, "请求回复通知: $notificationKey, 内容: $replyText")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "回复通知失败", e)
            false
        }
    }
    
    /**
     * 🎯 智能分类通知
     */
    private fun categorizeNotification(packageName: String, notification: Notification): NotificationCategory {
        return when {
            // 消息类应用
            packageName in listOf(
                "com.tencent.mm",           // 微信
                "com.tencent.mobileqq",     // QQ
                "com.tencent.tim",          // TIM
                "com.alibaba.android.rimet", // 钉钉
                "com.ss.android.lark",      // 飞书
                "org.telegram.messenger",   // Telegram
                "com.whatsapp",             // WhatsApp
                "jp.naver.line.android"     // LINE
            ) -> NotificationCategory.MESSAGE
            
            // 社交类应用
            packageName in listOf(
                "com.sina.weibo",           // 微博
                "com.zhihu.android",        // 知乎
                "com.xingin.xhs",           // 小红书
                "tv.danmaku.bili"           // B站
            ) -> NotificationCategory.SOCIAL
            
            // 购物类应用
            packageName in listOf(
                "com.taobao.taobao",        // 淘宝
                "com.jingdong.app.mall",    // 京东
                "com.xunmeng.pinduoduo",    // 拼多多
                "com.eg.android.AlipayGphone" // 支付宝
            ) -> NotificationCategory.SHOPPING
            
            // 媒体类
            notification.category == Notification.CATEGORY_TRANSPORT ||
            packageName.contains("music") ||
            packageName.contains("video") -> NotificationCategory.MEDIA
            
            // 邮件类
            notification.category == Notification.CATEGORY_EMAIL ||
            packageName.contains("email") ||
            packageName.contains("mail") -> NotificationCategory.EMAIL
            
            // 系统类
            packageName.startsWith("com.android") ||
            packageName.startsWith("android") -> NotificationCategory.SYSTEM
            
            else -> NotificationCategory.OTHER
        }
    }
    
    /**
     * 📦 解析通知
     */
    private fun parseNotification(sbn: StatusBarNotification): NotificationInfo? {
        return try {
            val notification = sbn.notification
            val extras = notification.extras
            
            val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
            val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
            val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
            val subText = extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()
            
            val category = categorizeNotification(sbn.packageName, notification)
            
            val actions = notification.actions?.map { action ->
                val isReply = action.remoteInputs?.any { 
                    it.allowFreeFormInput 
                } == true
                NotificationAction(
                    title = action.title?.toString() ?: "",
                    isReplyAction = isReply
                )
            } ?: emptyList()
            
            val canReply = actions.any { it.isReplyAction }
            
            NotificationInfo(
                id = sbn.id,
                key = sbn.key,
                packageName = sbn.packageName,
                appName = getAppName(sbn.packageName),
                title = title,
                text = text,
                bigText = bigText,
                subText = subText,
                timestamp = sbn.postTime,
                category = category,
                priority = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    notification.priority
                } else {
                    0
                },
                isOngoing = (notification.flags and Notification.FLAG_ONGOING_EVENT) != 0,
                isClearable = sbn.isClearable,
                canReply = canReply,
                actions = actions
            )
        } catch (e: Exception) {
            LogManager.e(TAG, "解析通知失败", e)
            null
        }
    }
    
    /**
     * 📱 获取应用名称
     */
    private fun getAppName(packageName: String): String {
        return try {
            val pm = context.packageManager
            val appInfo = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(appInfo).toString()
        } catch (e: Exception) {
            packageName
        }
    }
    
    /**
     * 📊 获取通知统计
     */
    fun getNotificationStats(): NotificationStats {
        val notifications = getActiveNotifications()
        return NotificationStats(
            total = notifications.size,
            messages = notifications.count { it.category == NotificationCategory.MESSAGE },
            social = notifications.count { it.category == NotificationCategory.SOCIAL },
            shopping = notifications.count { it.category == NotificationCategory.SHOPPING },
            system = notifications.count { it.category == NotificationCategory.SYSTEM },
            other = notifications.count { it.category == NotificationCategory.OTHER }
        )
    }
    
    data class NotificationStats(
        val total: Int,
        val messages: Int,
        val social: Int,
        val shopping: Int,
        val system: Int,
        val other: Int
    )
    
    /**
     * 🔍 搜索通知
     */
    fun searchNotifications(keyword: String): List<NotificationInfo> {
        return getActiveNotifications().filter { notification ->
            notification.title?.contains(keyword, ignoreCase = true) == true ||
            notification.text?.contains(keyword, ignoreCase = true) == true ||
            notification.bigText?.contains(keyword, ignoreCase = true) == true ||
            notification.appName.contains(keyword, ignoreCase = true)
        }
    }
    
    /**
     * ⚡ 获取最新通知
     */
    fun getLatestNotifications(count: Int = 10): List<NotificationInfo> {
        return getActiveNotifications()
            .sortedByDescending { it.timestamp }
            .take(count)
    }
    
    /**
     * 🔔 创建通知（用于AI发送通知）
     */
    fun createNotification(
        title: String,
        content: String,
        channelId: String = "xihe_default",
        channelName: String = "羲和通知",
        priority: Int = NotificationCompat.PRIORITY_DEFAULT
    ): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    channelId,
                    channelName,
                    NotificationManager.IMPORTANCE_DEFAULT
                )
                notificationManager.createNotificationChannel(channel)
            }
            
            val notification = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(content)
                .setPriority(priority)
                .setAutoCancel(true)
                .build()
            
            val notificationId = System.currentTimeMillis().toInt()
            NotificationManagerCompat.from(context).notify(notificationId, notification)
            
            LogManager.d(TAG, "✅ 创建通知成功: $title")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 创建通知失败", e)
            false
        }
    }
}
