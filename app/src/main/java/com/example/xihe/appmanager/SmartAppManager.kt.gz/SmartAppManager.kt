package com.example.xihe.appmanager

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.Closeable

/**
 * 📱 智能应用管理器
 * 管理已安装应用，提供应用信息和操作
 * 
 * 🆕 修复内存泄漏：
 * - 使用 SupervisorJob 管理协程生命周期
 * - 实现 Closeable 接口支持资源释放
 * - 支持外部传入 CoroutineScope
 */
class SmartAppManager(private val context: Context) : Closeable {
    
    companion object {
        private const val TAG = "SmartAppManager"
        
        @Volatile
        private var instance: SmartAppManager? = null
        
        fun getInstance(context: Context): SmartAppManager {
            return instance ?: synchronized(this) {
                instance ?: SmartAppManager(context.applicationContext).also { instance = it }
            }
        }
    }
    
    private val packageManager = context.packageManager
    private val appsMap = mutableMapOf<String, AppDetail>()
    
    private val _apps = MutableStateFlow<List<AppDetail>>(emptyList())
    val apps = _apps.asStateFlow()
    
    private val _appUsageStats = MutableStateFlow<Map<String, AppUsageInfo>>(emptyMap())
    val appUsageStats = _appUsageStats.asStateFlow()
    
    // 🆕 使用 SupervisorJob 管理协程生命周期，防止内存泄漏
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var isLoading = false
    
    init {
        loadInstalledApps()
    }
    
    /**
     * 🗑️ 释放资源（防止内存泄漏）
     */
    override fun close() {
        scope.cancel()
        appsMap.clear()
        LogManager.d(TAG, "✅ SmartAppManager 资源已释放")
    }
    
    /**
     * 📖 加载已安装应用
     * 🆕 修复：使用管理的 scope 而不是新建 CoroutineScope
     */
    fun loadInstalledApps() {
        if (isLoading) return
        isLoading = true
        
        scope.launch {
            try {
                val apps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
                
                appsMap.clear()
                for (appInfo in apps) {
                    try {
                        val appDetail = AppDetail(
                            packageName = appInfo.packageName,
                            appName = packageManager.getApplicationLabel(appInfo).toString(),
                            icon = packageManager.getApplicationIcon(appInfo),
                            versionName = packageManager.getPackageInfo(appInfo.packageName, 0).versionName ?: "Unknown",
                            versionCode = packageManager.getPackageInfo(appInfo.packageName, 0).longVersionCode,
                            isSystemApp = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                            isEnabled = appInfo.enabled,
                            installTime = packageManager.getPackageInfo(appInfo.packageName, 0).firstInstallTime,
                            updateTime = packageManager.getPackageInfo(appInfo.packageName, 0).lastUpdateTime
                        )
                        
                        appsMap[appInfo.packageName] = appDetail
                    } catch (e: Exception) {
                        LogManager.e(TAG, "加载应用失败: ${appInfo.packageName}", e)
                    }
                }
                
                _apps.value = appsMap.values.sortedBy { it.appName }
                LogManager.i(TAG, "✅ 已加载 ${appsMap.size} 个应用")
            } catch (e: Exception) {
                LogManager.e(TAG, "❌ 加载应用列表失败", e)
            } finally {
                isLoading = false
            }
        }
    }
    
    /**
     * 🔍 搜索应用
     */
    fun searchApps(query: String): List<AppDetail> {
        if (query.isBlank()) return appsMap.values.toList()
        
        return appsMap.values.filter { app ->
            app.appName.contains(query, ignoreCase = true) ||
            app.packageName.contains(query, ignoreCase = true)
        }
    }
    
    /**
     * 🔍 根据包名获取应用
     */
    fun getAppByPackage(packageName: String): AppDetail? {
        return appsMap[packageName]
    }
    
    /**
     * 🔍 根据应用名获取应用
     */
    fun getAppByName(appName: String): AppDetail? {
        return appsMap.values.find { 
            it.appName.equals(appName, ignoreCase = true) 
        }
    }
    
    /**
     * 🚀 启动应用
     */
    fun launchApp(packageName: String): Boolean {
        return try {
            val intent = packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                
                // 记录使用
                recordAppUsage(packageName)
                
                LogManager.d(TAG, "🚀 启动应用: $packageName")
                true
            } else {
                LogManager.w(TAG, "⚠️ 应用没有启动入口: $packageName")
                false
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 启动应用失败: $packageName", e)
            false
        }
    }
    
    /**
     * ℹ️ 打开应用详情页
     */
    fun openAppDetails(packageName: String): Boolean {
        return try {
            val intent = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = android.net.Uri.parse("package:$packageName")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            LogManager.d(TAG, "ℹ️ 打开应用详情: $packageName")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 打开应用详情失败", e)
            false
        }
    }
    
    /**
     * 📝 记录应用使用
     */
    private fun recordAppUsage(packageName: String) {
        val currentStats = _appUsageStats.value.toMutableMap()
        val currentUsage = currentStats[packageName] ?: AppUsageInfo(
            packageName = packageName,
            launchCount = 0,
            lastLaunchTime = 0L,
            totalUsageTime = 0L
        )
        
        currentStats[packageName] = currentUsage.copy(
            launchCount = currentUsage.launchCount + 1,
            lastLaunchTime = System.currentTimeMillis()
        )
        
        _appUsageStats.value = currentStats
    }
    
    /**
     * 📊 获取使用最频繁的应用
     */
    fun getMostUsedApps(limit: Int = 10): List<AppDetail> {
        val sortedByUsage = _appUsageStats.value.entries
            .sortedByDescending { it.value.launchCount }
            .take(limit)
            .mapNotNull { appsMap[it.key] }
        
        return sortedByUsage
    }
    
    /**
     * 🕒 获取最近使用的应用
     */
    fun getRecentlyUsedApps(limit: Int = 10): List<AppDetail> {
        val sortedByTime = _appUsageStats.value.entries
            .sortedByDescending { it.value.lastLaunchTime }
            .take(limit)
            .mapNotNull { appsMap[it.key] }
        
        return sortedByTime
    }
    
    /**
     * 🏷️ 获取系统应用
     */
    fun getSystemApps(): List<AppDetail> {
        return appsMap.values.filter { it.isSystemApp }
    }
    
    /**
     * 🏷️ 获取用户应用
     */
    fun getUserApps(): List<AppDetail> {
        return appsMap.values.filter { !it.isSystemApp }
    }
    
    /**
     * ✅ 获取已启用应用
     */
    fun getEnabledApps(): List<AppDetail> {
        return appsMap.values.filter { it.isEnabled }
    }
    
    /**
     * ❌ 获取已禁用应用
     */
    fun getDisabledApps(): List<AppDetail> {
        return appsMap.values.filter { !it.isEnabled }
    }
    
    /**
     * 🆕 获取最近安装的应用
     */
    fun getRecentlyInstalledApps(limit: Int = 10): List<AppDetail> {
        return appsMap.values
            .sortedByDescending { it.installTime }
            .take(limit)
    }
    
    /**
     * 🔄 获取最近更新的应用
     */
    fun getRecentlyUpdatedApps(limit: Int = 10): List<AppDetail> {
        return appsMap.values
            .sortedByDescending { it.updateTime }
            .take(limit)
    }
    
    /**
     * 📊 获取应用统计
     */
    fun getAppStatistics(): AppStatistics {
        val allApps = appsMap.values
        
        return AppStatistics(
            totalApps = allApps.size,
            systemApps = allApps.count { it.isSystemApp },
            userApps = allApps.count { !it.isSystemApp },
            enabledApps = allApps.count { it.isEnabled },
            disabledApps = allApps.count { !it.isEnabled },
            mostUsedApp = getMostUsedApps(1).firstOrNull(),
            recentlyUsedCount = _appUsageStats.value.size
        )
    }
    
    /**
     * 💾 导出应用列表
     */
    fun exportAppList(): String {
        val sb = StringBuilder()
        sb.appendLine("应用列表导出")
        sb.appendLine("=" .repeat(50))
        sb.appendLine("总应用数: ${appsMap.size}")
        sb.appendLine("导出时间: ${System.currentTimeMillis()}")
        sb.appendLine()
        
        for (app in appsMap.values.sortedBy { it.appName }) {
            sb.appendLine("应用名: ${app.appName}")
            sb.appendLine("包名: ${app.packageName}")
            sb.appendLine("版本: ${app.versionName}")
            sb.appendLine("系统应用: ${if (app.isSystemApp) "是" else "否"}")
            sb.appendLine("状态: ${if (app.isEnabled) "已启用" else "已禁用"}")
            sb.appendLine("-".repeat(50))
        }
        
        return sb.toString()
    }
    
    // ============ 数据类型 ============
    
    /**
     * 📱 应用详情
     */
    data class AppDetail(
        val packageName: String,
        val appName: String,
        val icon: Drawable,
        val versionName: String,
        val versionCode: Long,
        val isSystemApp: Boolean,
        val isEnabled: Boolean,
        val installTime: Long,
        val updateTime: Long
    )
    
    /**
     * 📊 应用使用信息
     */
    data class AppUsageInfo(
        val packageName: String,
        val launchCount: Int,
        val lastLaunchTime: Long,
        val totalUsageTime: Long
    )
    
    /**
     * 📊 应用统计
     */
    data class AppStatistics(
        val totalApps: Int,
        val systemApps: Int,
        val userApps: Int,
        val enabledApps: Int,
        val disabledApps: Int,
        val mostUsedApp: AppDetail?,
        val recentlyUsedCount: Int
    )
}
