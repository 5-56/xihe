package com.example.xihe.screenshot

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaScannerConnection
import android.os.Environment
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

/**
 * 截图管理器
 * 管理屏幕截图的保存和管理
 */
class ScreenshotManager(private val context: Context) {
    
    companion object {
        private const val TAG = "ScreenshotManager"
        private const val SCREENSHOTS_DIR = "screenshots"
        private const val THUMBNAIL_SIZE = 200
        
        @Volatile
        private var instance: ScreenshotManager? = null
        
        fun getInstance(context: Context): ScreenshotManager {
            return instance ?: synchronized(this) {
                instance ?: ScreenshotManager(context.applicationContext).also { instance = it }
            }
        }
    }
    
    private val screenshotsDir: File by lazy {
        File(context.getExternalFilesDir(Environment.DIRECTORY_PICTURES), SCREENSHOTS_DIR).apply {
            if (!exists()) {
                mkdirs()
            }
        }
    }
    
    /**
     * 保存截图
     */
    suspend fun saveScreenshot(
        bitmap: Bitmap,
        name: String? = null,
        quality: Int = 90
    ): SaveResult {
        return withContext(Dispatchers.IO) {
            try {
                val timestamp = System.currentTimeMillis()
                val dateFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
                val filename = name ?: "screenshot_${dateFormat.format(Date(timestamp))}.png"
                val file = File(screenshotsDir, filename)
                
                FileOutputStream(file).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, quality, out)
                }
                
                // 通知媒体扫描器
                MediaScannerConnection.scanFile(
                    context,
                    arrayOf(file.absolutePath),
                    arrayOf("image/png"),
                    null
                )
                
                // 生成缩略图
                val thumbnail = createThumbnail(bitmap)
                val thumbnailFile = File(screenshotsDir, "thumb_$filename")
                FileOutputStream(thumbnailFile).use { out ->
                    thumbnail.compress(Bitmap.CompressFormat.JPEG, 80, out)
                }
                
                LogManager.i(TAG, " 截图已保存: $filename")
                
                SaveResult(
                    success = true,
                    file = file,
                    thumbnailFile = thumbnailFile,
                    message = "截图保存成功",
                    size = file.length()
                )
            } catch (e: Exception) {
                LogManager.e(TAG, " 保存截图失败", e)
                SaveResult(
                    success = false,
                    file = null,
                    thumbnailFile = null,
                    message = "保存失败: ${e.message}",
                    size = 0L
                )
            }
        }
    }
    
    /**
     * 创建缩略图
     */
    private fun createThumbnail(bitmap: Bitmap): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        val scale = THUMBNAIL_SIZE.toFloat() / maxOf(width, height)
        
        val scaledWidth = (width * scale).toInt()
        val scaledHeight = (height * scale).toInt()
        
        return Bitmap.createScaledBitmap(bitmap, scaledWidth, scaledHeight, true)
    }
    
    /**
     * 列出所有截图
     */
    fun listScreenshots(): List<ScreenshotInfo> {
        return try {
            screenshotsDir.listFiles { file ->
                file.isFile && file.name.startsWith("screenshot_") && file.extension == "png"
            }
                ?.map { file ->
                    val thumbnailFile = File(screenshotsDir, "thumb_${file.name}")
                    
                    ScreenshotInfo(
                        name = file.nameWithoutExtension,
                        file = file,
                        thumbnailFile = if (thumbnailFile.exists()) thumbnailFile else null,
                        size = file.length(),
                        createdAt = file.lastModified(),
                        width = 0, // 需要加载图片才能获取
                        height = 0
                    )
                }
                ?.sortedByDescending { it.createdAt }
                ?: emptyList()
        } catch (e: Exception) {
            LogManager.e(TAG, " 列出截图失败", e)
            emptyList()
        }
    }
    
    /**
     * 加载截图
     */
    suspend fun loadScreenshot(file: File): Bitmap? {
        return withContext(Dispatchers.IO) {
            try {
                BitmapFactory.decodeFile(file.absolutePath)
            } catch (e: Exception) {
                LogManager.e(TAG, " 加载截图失败", e)
                null
            }
        }
    }
    
    /**
     * 加载缩略图
     */
    suspend fun loadThumbnail(file: File): Bitmap? {
        return withContext(Dispatchers.IO) {
            try {
                BitmapFactory.decodeFile(file.absolutePath)
            } catch (e: Exception) {
                LogManager.e(TAG, " 加载缩略图失败", e)
                null
            }
        }
    }
    
    /**
     * 删除截图
     */
    suspend fun deleteScreenshot(file: File): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                // 删除缩略图
                val thumbnailFile = File(file.parent, "thumb_${file.name}")
                thumbnailFile.delete()
                
                // 删除原图
                val deleted = file.delete()
                if (deleted) {
                    LogManager.i(TAG, " 删除截图: ${file.name}")
                }
                deleted
            } catch (e: Exception) {
                LogManager.e(TAG, " 删除截图失败", e)
                false
            }
        }
    }
    
    /**
     * 删除所有截图
     */
    suspend fun deleteAllScreenshots(): Int {
        return withContext(Dispatchers.IO) {
            try {
                val screenshots = listScreenshots()
                var deletedCount = 0
                
                screenshots.forEach { screenshot ->
                    if (deleteScreenshot(screenshot.file)) {
                        deletedCount++
                    }
                }
                
                LogManager.i(TAG, " 删除了 $deletedCount 个截图")
                deletedCount
            } catch (e: Exception) {
                LogManager.e(TAG, " 删除所有截图失败", e)
                0
            }
        }
    }
    
    /**
     * 清理旧截图
     */
    suspend fun cleanOldScreenshots(keepDays: Int = 7): Int {
        return withContext(Dispatchers.IO) {
            try {
                val cutoffTime = System.currentTimeMillis() - keepDays * 24 * 60 * 60 * 1000L
                val screenshots = listScreenshots()
                var deletedCount = 0
                
                screenshots.forEach { screenshot ->
                    if (screenshot.createdAt < cutoffTime) {
                        if (deleteScreenshot(screenshot.file)) {
                            deletedCount++
                        }
                    }
                }
                
                LogManager.i(TAG, " 清理了 $deletedCount 个旧截图")
                deletedCount
            } catch (e: Exception) {
                LogManager.e(TAG, " 清理截图失败", e)
                0
            }
        }
    }
    
    /**
     * 获取截图统计
     * 📊 获取截图统计
     */
    fun getScreenshotStatistics(): ScreenshotStatistics {
        val screenshots = listScreenshots()
        val totalSize = screenshots.sumOf { it.size }
        
        return ScreenshotStatistics(
            totalScreenshots = screenshots.size,
            totalSize = totalSize,
            oldestScreenshot = screenshots.minByOrNull { it.createdAt },
            newestScreenshot = screenshots.maxByOrNull { it.createdAt }
        )
    }
    
    /**
     * 🔍 搜索截图
     */
    fun searchScreenshots(query: String): List<ScreenshotInfo> {
        return listScreenshots().filter { screenshot ->
            screenshot.name.contains(query, ignoreCase = true)
        }
    }
    
    /**
     * 📁 获取截图目录路径
     */
    fun getScreenshotsPath(): String {
        return screenshotsDir.absolutePath
    }
    
    // ============ 数据类型 ============
    
    /**
     * 💾 保存结果
     */
    data class SaveResult(
        val success: Boolean,
        val file: File?,
        val thumbnailFile: File?,
        val message: String,
        val size: Long
    )
    
    /**
     * 📸 截图信息
     */
    data class ScreenshotInfo(
        val name: String,
        val file: File,
        val thumbnailFile: File?,
        val size: Long,
        val createdAt: Long,
        val width: Int,
        val height: Int
    )
    
    /**
     * 📊 截图统计
     */
    data class ScreenshotStatistics(
        val totalScreenshots: Int,
        val totalSize: Long,
        val oldestScreenshot: ScreenshotInfo?,
        val newestScreenshot: ScreenshotInfo?
    )
}
