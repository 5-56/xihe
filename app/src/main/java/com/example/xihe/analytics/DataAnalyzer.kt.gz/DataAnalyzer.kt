package com.example.xihe.analytics

import android.app.ActivityManager
import android.app.usage.NetworkStatsManager
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

/**
 * 📊 数据统计分析器
 * 提供应用使用统计、存储分析、电池分析等功能
 */
class DataAnalyzer private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "DataAnalyzer"
        
        @Volatile
        private var instance: DataAnalyzer? = null
        
        fun getInstance(context: Context): DataAnalyzer {
            return instance ?: synchronized(this) {
                instance ?: DataAnalyzer(context.applicationContext).also { instance = it }
            }
        }
    }
    
    private val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
    
    /**
     * 应用使用统计
     */
    data class AppUsageStats(
        val packageName: String,
        val appName: String,
        val totalTimeInForeground: Long,
        val lastTimeUsed: Long,
        val launchCount: Int
    ) {
        fun getTotalTimeFormatted(): String {
            val hours = totalTimeInForeground / (1000 * 60 * 60)
            val minutes = (totalTimeInForeground / (1000 * 60)) % 60
            return "${hours}小时${minutes}分钟"
        }
        
        fun getLastUsedFormatted(): String {
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
            return sdf.format(Date(lastTimeUsed))
        }
    }
    
    /**
     * 存储信息
     */
    data class StorageInfo(
        val totalSpace: Long,
        val freeSpace: Long,
        val usedSpace: Long,
        val usagePercentage: Float
    ) {
        fun getTotalSpaceFormatted(): String = formatSize(totalSpace)
        fun getFreeSpaceFormatted(): String = formatSize(freeSpace)
        fun getUsedSpaceFormatted(): String = formatSize(usedSpace)
        
        private fun formatSize(bytes: Long): String {
            val kb = bytes / 1024.0
            val mb = kb / 1024.0
            val gb = mb / 1024.0
            
            return when {
                gb >= 1 -> "%.2f GB".format(gb)
                mb >= 1 -> "%.2f MB".format(mb)
                kb >= 1 -> "%.2f KB".format(kb)
                else -> "$bytes B"
            }
        }
    }
    
    /**
     * 内存信息
     */
    data class MemoryInfo(
        val totalRam: Long,
        val availableRam: Long,
        val usedRam: Long,
        val usagePercentage: Float,
        val threshold: Long,
        val isLowMemory: Boolean
    )
    
    /**
     * 网络流量统计
     */
    data class NetworkStats(
        val totalRxBytes: Long,
        val totalTxBytes: Long,
        val mobileRxBytes: Long,
        val mobileTxBytes: Long,
        val wifiRxBytes: Long,
        val wifiTxBytes: Long
    ) {
        fun getTotalTraffic(): Long = totalRxBytes + totalTxBytes
        fun getTotalTrafficFormatted(): String = formatTraffic(getTotalTraffic())
        
        private fun formatTraffic(bytes: Long): String {
            val kb = bytes / 1024.0
            val mb = kb / 1024.0
            val gb = mb / 1024.0
            
            return when {
                gb >= 1 -> "%.2f GB".format(gb)
                mb >= 1 -> "%.2f MB".format(mb)
                kb >= 1 -> "%.2f KB".format(kb)
                else -> "$bytes B"
            }
        }
    }
    
    // ==================== 应用使用统计 ====================
    
    /**
     * 📱 获取应用使用统计
     */
    suspend fun getAppUsageStats(days: Int = 7): List<AppUsageStats> = withContext(Dispatchers.IO) {
        try {
            val calendar = Calendar.getInstance()
            val endTime = calendar.timeInMillis
            calendar.add(Calendar.DAY_OF_YEAR, -days)
            val startTime = calendar.timeInMillis
            
            val usageStatsList = usageStatsManager?.queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY,
                startTime,
                endTime
            ) ?: return@withContext emptyList()
            
            val statsMap = mutableMapOf<String, UsageStats>()
            
            // 合并同一应用的统计数据
            usageStatsList.forEach { stats ->
                if (stats.totalTimeInForeground > 0) {
                    val existing = statsMap[stats.packageName]
                    if (existing == null) {
                        statsMap[stats.packageName] = stats
                    } else {
                        existing.add(stats)
                    }
                }
            }
            
            // 转换为AppUsageStats并排序
            statsMap.values.mapNotNull { stats ->
                try {
                    val appName = getAppName(stats.packageName)
                    AppUsageStats(
                        packageName = stats.packageName,
                        appName = appName,
                        totalTimeInForeground = stats.totalTimeInForeground,
                        lastTimeUsed = stats.lastTimeUsed,
                        launchCount = 0
                    )
                } catch (e: Exception) {
                    null
                }
            }.sortedByDescending { it.totalTimeInForeground }
        } catch (e: Exception) {
            LogManager.e(TAG, "获取应用使用统计失败", e)
            emptyList()
        }
    }
    
    /**
     * 📱 获取今天的应用使用统计
     */
    suspend fun getTodayAppUsageStats(): List<AppUsageStats> = withContext(Dispatchers.IO) {
        getAppUsageStats(1)
    }
    
    /**
     * 📱 获取使用时间最长的应用
     */
    suspend fun getTopUsedApps(limit: Int = 10): List<AppUsageStats> = withContext(Dispatchers.IO) {
        getAppUsageStats(7).take(limit)
    }
    
    /**
     * 📊 获取屏幕使用时间统计
     */
    suspend fun getScreenTimeStats(days: Int = 7): ScreenTimeStats = withContext(Dispatchers.IO) {
        try {
            val appStats = getAppUsageStats(days)
            val totalScreenTime = appStats.sumOf { it.totalTimeInForeground }
            val avgScreenTime = if (days > 0) totalScreenTime / days else 0
            
            ScreenTimeStats(
                totalScreenTime = totalScreenTime,
                averageScreenTime = avgScreenTime,
                days = days,
                topApps = appStats.take(5)
            )
        } catch (e: Exception) {
            LogManager.e(TAG, "获取屏幕使用时间失败", e)
            ScreenTimeStats(0, 0, days, emptyList())
        }
    }
    
    data class ScreenTimeStats(
        val totalScreenTime: Long,
        val averageScreenTime: Long,
        val days: Int,
        val topApps: List<AppUsageStats>
    ) {
        fun getTotalTimeFormatted(): String {
            val hours = totalScreenTime / (1000 * 60 * 60)
            val minutes = (totalScreenTime / (1000 * 60)) % 60
            return "${hours}小时${minutes}分钟"
        }
        
        fun getAverageTimeFormatted(): String {
            val hours = averageScreenTime / (1000 * 60 * 60)
            val minutes = (averageScreenTime / (1000 * 60)) % 60
            return "${hours}小时${minutes}分钟"
        }
    }
    
    // ==================== 存储分析 ====================
    
    /**
     * 💾 获取内部存储信息
     */
    fun getInternalStorageInfo(): StorageInfo {
        return try {
            val path = Environment.getDataDirectory()
            val stat = StatFs(path.path)
            
            val totalSpace = stat.blockCountLong * stat.blockSizeLong
            val freeSpace = stat.availableBlocksLong * stat.blockSizeLong
            val usedSpace = totalSpace - freeSpace
            val usagePercentage = (usedSpace.toFloat() / totalSpace) * 100
            
            StorageInfo(totalSpace, freeSpace, usedSpace, usagePercentage)
        } catch (e: Exception) {
            LogManager.e(TAG, "获取内部存储信息失败", e)
            StorageInfo(0, 0, 0, 0f)
        }
    }
    
    /**
     * 💾 获取外部存储信息
     */
    fun getExternalStorageInfo(): StorageInfo? {
        return try {
            if (!Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
                return null
            }
            
            val path = Environment.getExternalStorageDirectory()
            val stat = StatFs(path.path)
            
            val totalSpace = stat.blockCountLong * stat.blockSizeLong
            val freeSpace = stat.availableBlocksLong * stat.blockSizeLong
            val usedSpace = totalSpace - freeSpace
            val usagePercentage = (usedSpace.toFloat() / totalSpace) * 100
            
            StorageInfo(totalSpace, freeSpace, usedSpace, usagePercentage)
        } catch (e: Exception) {
            LogManager.e(TAG, "获取外部存储信息失败", e)
            null
        }
    }
    
    /**
     * 💾 获取应用占用空间
     */
    fun getAppStorageInfo(packageName: String): Long {
        return try {
            val pm = context.packageManager
            val appInfo = pm.getApplicationInfo(packageName, 0)
            
            var totalSize = 0L
            
            // 应用安装目录大小
            appInfo.sourceDir?.let { sourceDir ->
                val file = java.io.File(sourceDir)
                totalSize += file.length()
            }
            
            // 数据目录大小
            appInfo.dataDir?.let { dataDir ->
                totalSize += getFolderSize(java.io.File(dataDir))
            }
            
            totalSize
        } catch (e: Exception) {
            LogManager.e(TAG, "获取应用存储信息失败", e)
            0L
        }
    }
    
    private fun getFolderSize(folder: java.io.File): Long {
        var size = 0L
        try {
            folder.listFiles()?.forEach { file ->
                size += if (file.isDirectory) {
                    getFolderSize(file)
                } else {
                    file.length()
                }
            }
        } catch (e: Exception) {
            // Ignore permission errors
        }
        return size
    }
    
    // ==================== 内存分析 ====================
    
    /**
     * 🧠 获取内存信息
     */
    fun getMemoryInfo(): MemoryInfo {
        return try {
            val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memoryInfo = ActivityManager.MemoryInfo()
            activityManager.getMemoryInfo(memoryInfo)
            
            val totalRam = memoryInfo.totalMem
            val availableRam = memoryInfo.availMem
            val usedRam = totalRam - availableRam
            val usagePercentage = (usedRam.toFloat() / totalRam) * 100
            
            MemoryInfo(
                totalRam = totalRam,
                availableRam = availableRam,
                usedRam = usedRam,
                usagePercentage = usagePercentage,
                threshold = memoryInfo.threshold,
                isLowMemory = memoryInfo.lowMemory
            )
        } catch (e: Exception) {
            LogManager.e(TAG, "获取内存信息失败", e)
            MemoryInfo(0, 0, 0, 0f, 0, false)
        }
    }
    
    /**
     * 🧠 获取运行中的进程
     */
    fun getRunningProcesses(): List<ProcessInfo> {
        return try {
            val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val runningProcesses = activityManager.runningAppProcesses ?: return emptyList()
            
            runningProcesses.map { process ->
                ProcessInfo(
                    processName = process.processName,
                    pid = process.pid,
                    importance = process.importance
                )
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "获取运行进程失败", e)
            emptyList()
        }
    }
    
    data class ProcessInfo(
        val processName: String,
        val pid: Int,
        val importance: Int
    )
    
    // ==================== 网络统计 ====================
    
    /**
     * 📊 获取网络流量统计
     */
    fun getNetworkStats(): NetworkStats {
        return try {
            val mobileRx = android.net.TrafficStats.getMobileRxBytes()
            val mobileTx = android.net.TrafficStats.getMobileTxBytes()
            val totalRx = android.net.TrafficStats.getTotalRxBytes()
            val totalTx = android.net.TrafficStats.getTotalTxBytes()
            
            val wifiRx = totalRx - mobileRx
            val wifiTx = totalTx - mobileTx
            
            NetworkStats(
                totalRxBytes = totalRx,
                totalTxBytes = totalTx,
                mobileRxBytes = mobileRx,
                mobileTxBytes = mobileTx,
                wifiRxBytes = wifiRx,
                wifiTxBytes = wifiTx
            )
        } catch (e: Exception) {
            LogManager.e(TAG, "获取网络统计失败", e)
            NetworkStats(0, 0, 0, 0, 0, 0)
        }
    }
    
    // ==================== 综合统计 ====================
    
    /**
     * 📊 获取系统概览
     */
    suspend fun getSystemOverview(): SystemOverview = withContext(Dispatchers.IO) {
        SystemOverview(
            storage = getInternalStorageInfo(),
            memory = getMemoryInfo(),
            network = getNetworkStats(),
            topApps = getTopUsedApps(5)
        )
    }
    
    data class SystemOverview(
        val storage: StorageInfo,
        val memory: MemoryInfo,
        val network: NetworkStats,
        val topApps: List<AppUsageStats>
    )
    
    // ==================== 工具方法 ====================
    
    /**
     * 📱 获取应用名称
     */
    private fun getAppName(packageName: String): String {
        return try {
            val pm = context.packageManager
            val appInfo = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(appInfo).toString()
        } catch (e: Exception) {
            packageName
        }
    }
    
    /**
     * 📊 格式化大小
     */
    fun formatSize(bytes: Long): String {
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        
        return when {
            gb >= 1 -> "%.2f GB".format(gb)
            mb >= 1 -> "%.2f MB".format(mb)
            kb >= 1 -> "%.2f KB".format(kb)
            else -> "$bytes B"
        }
    }
}
