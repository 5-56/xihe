package com.example.xihe.communication

import android.Manifest
import android.app.PendingIntent
import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.provider.ContactsContract
import android.provider.Telephony
import android.telecom.TelecomManager
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * 📞 通讯管理器
 * 提供短信、电话、通讯录等通讯功能
 */
class CommunicationManager private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "CommunicationManager"
        
        @Volatile
        private var instance: CommunicationManager? = null
        
        fun getInstance(context: Context): CommunicationManager {
            return instance ?: synchronized(this) {
                instance ?: CommunicationManager(context.applicationContext).also { instance = it }
            }
        }
    }
    
    private val contentResolver: ContentResolver = context.contentResolver
    
    /**
     * 📱 联系人信息
     */
    data class Contact(
        val id: String,
        val name: String,
        val phoneNumbers: List<String>,
        val emails: List<String> = emptyList(),
        val photoUri: String? = null
    )
    
    /**
     * 💬 短信信息
     */
    data class SmsMessage(
        val id: String,
        val threadId: String,
        val address: String,
        val body: String,
        val date: Long,
        val type: SmsType,
        val read: Boolean
    )
    
    enum class SmsType {
        INBOX,      // 收件箱
        SENT,       // 已发送
        DRAFT,      // 草稿
        OUTBOX,     // 发件箱
        FAILED      // 失败
    }
    
    /**
     * 📞 通话记录
     */
    data class CallLog(
        val id: String,
        val number: String,
        val name: String?,
        val date: Long,
        val duration: Long,
        val type: CallType
    )
    
    enum class CallType {
        INCOMING,   // 来电
        OUTGOING,   // 去电
        MISSED,     // 未接
        REJECTED    // 拒接
    }
    
    // ==================== 联系人管理 ====================
    
    /**
     * 📋 获取所有联系人
     */
    suspend fun getAllContacts(): List<Contact> = withContext(Dispatchers.IO) {
        if (!checkPermission(Manifest.permission.READ_CONTACTS)) {
            LogManager.w(TAG, "⚠️ 没有读取联系人权限")
            return@withContext emptyList()
        }
        
        val contacts = mutableListOf<Contact>()
        val cursor = contentResolver.query(
            ContactsContract.Contacts.CONTENT_URI,
            null, null, null,
            ContactsContract.Contacts.DISPLAY_NAME + " ASC"
        )
        
        cursor?.use {
            while (it.moveToNext()) {
                val id = it.getString(it.getColumnIndexOrThrow(ContactsContract.Contacts._ID))
                val name = it.getString(it.getColumnIndexOrThrow(ContactsContract.Contacts.DISPLAY_NAME)) ?: ""
                val photoUri = it.getString(it.getColumnIndexOrThrow(ContactsContract.Contacts.PHOTO_URI))
                
                val phoneNumbers = getPhoneNumbers(id)
                val emails = getEmails(id)
                
                if (phoneNumbers.isNotEmpty() || emails.isNotEmpty()) {
                    contacts.add(Contact(id, name, phoneNumbers, emails, photoUri))
                }
            }
        }
        
        LogManager.d(TAG, "📋 获取联系人: ${contacts.size}个")
        contacts
    }
    
    /**
     * 🔍 搜索联系人
     */
    suspend fun searchContacts(query: String): List<Contact> = withContext(Dispatchers.IO) {
        if (!checkPermission(Manifest.permission.READ_CONTACTS)) {
            return@withContext emptyList()
        }
        
        val contacts = getAllContacts()
        contacts.filter { contact ->
            contact.name.contains(query, ignoreCase = true) ||
            contact.phoneNumbers.any { it.contains(query) }
        }
    }
    
    /**
     * 📱 根据姓名查找联系人
     */
    suspend fun findContactByName(name: String): Contact? = withContext(Dispatchers.IO) {
        searchContacts(name).firstOrNull()
    }
    
    /**
     * 📱 根据电话号码查找联系人
     */
    suspend fun findContactByPhone(phoneNumber: String): Contact? = withContext(Dispatchers.IO) {
        if (!checkPermission(Manifest.permission.READ_CONTACTS)) {
            return@withContext null
        }
        
        val uri = Uri.withAppendedPath(
            ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
            Uri.encode(phoneNumber)
        )
        
        val cursor = contentResolver.query(uri, null, null, null, null)
        
        cursor?.use {
            if (it.moveToFirst()) {
                val id = it.getString(it.getColumnIndexOrThrow(ContactsContract.PhoneLookup._ID))
                val name = it.getString(it.getColumnIndexOrThrow(ContactsContract.PhoneLookup.DISPLAY_NAME))
                val photoUri = it.getString(it.getColumnIndexOrThrow(ContactsContract.PhoneLookup.PHOTO_URI))
                
                return@withContext Contact(
                    id = id,
                    name = name,
                    phoneNumbers = listOf(phoneNumber),
                    photoUri = photoUri
                )
            }
        }
        
        null
    }
    
    /**
     * 📞 获取电话号码
     */
    private fun getPhoneNumbers(contactId: String): List<String> {
        val phoneNumbers = mutableListOf<String>()
        val cursor = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            null,
            ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
            arrayOf(contactId),
            null
        )
        
        cursor?.use {
            while (it.moveToNext()) {
                val number = it.getString(
                    it.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
                )
                phoneNumbers.add(number)
            }
        }
        
        return phoneNumbers
    }
    
    /**
     * 📧 获取邮箱
     */
    private fun getEmails(contactId: String): List<String> {
        val emails = mutableListOf<String>()
        val cursor = contentResolver.query(
            ContactsContract.CommonDataKinds.Email.CONTENT_URI,
            null,
            ContactsContract.CommonDataKinds.Email.CONTACT_ID + " = ?",
            arrayOf(contactId),
            null
        )
        
        cursor?.use {
            while (it.moveToNext()) {
                val email = it.getString(
                    it.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Email.ADDRESS)
                )
                emails.add(email)
            }
        }
        
        return emails
    }
    
    /**
     * ➕ 添加联系人
     */
    suspend fun addContact(
        name: String,
        phoneNumber: String,
        email: String? = null
    ): Boolean = withContext(Dispatchers.IO) {
        if (!checkPermission(Manifest.permission.WRITE_CONTACTS)) {
            LogManager.w(TAG, "⚠️ 没有写入联系人权限")
            return@withContext false
        }
        
        try {
            val operations = ArrayList<android.content.ContentProviderOperation>()
            
            // 添加联系人基本信息
            operations.add(
                android.content.ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                    .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                    .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                    .build()
            )
            
            // 添加姓名
            operations.add(
                android.content.ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                    .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, name)
                    .build()
            )
            
            // 添加电话号码
            operations.add(
                android.content.ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                    .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, phoneNumber)
                    .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)
                    .build()
            )
            
            // 添加邮箱（如果有）
            if (email != null) {
                operations.add(
                    android.content.ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE)
                        .withValue(ContactsContract.CommonDataKinds.Email.ADDRESS, email)
                        .withValue(ContactsContract.CommonDataKinds.Email.TYPE, ContactsContract.CommonDataKinds.Email.TYPE_HOME)
                        .build()
                )
            }
            
            contentResolver.applyBatch(ContactsContract.AUTHORITY, operations)
            LogManager.i(TAG, "✅ 添加联系人成功: $name")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 添加联系人失败", e)
            false
        }
    }
    
    /**
     * ✏️ 更新联系人
     */
    suspend fun updateContact(
        contactId: String,
        name: String? = null,
        phoneNumber: String? = null,
        email: String? = null
    ): Boolean = withContext(Dispatchers.IO) {
        if (!checkPermission(Manifest.permission.WRITE_CONTACTS)) {
            LogManager.w(TAG, "⚠️ 没有写入联系人权限")
            return@withContext false
        }
        
        try {
            // 更新姓名
            if (name != null) {
                val nameValues = ContentValues().apply {
                    put(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, name)
                }
                
                contentResolver.update(
                    ContactsContract.Data.CONTENT_URI,
                    nameValues,
                    "${ContactsContract.Data.CONTACT_ID} = ? AND ${ContactsContract.Data.MIMETYPE} = ?",
                    arrayOf(contactId, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                )
            }
            
            // 更新电话号码
            if (phoneNumber != null) {
                val phoneValues = ContentValues().apply {
                    put(ContactsContract.CommonDataKinds.Phone.NUMBER, phoneNumber)
                }
                
                contentResolver.update(
                    ContactsContract.Data.CONTENT_URI,
                    phoneValues,
                    "${ContactsContract.Data.CONTACT_ID} = ? AND ${ContactsContract.Data.MIMETYPE} = ?",
                    arrayOf(contactId, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                )
            }
            
            // 更新邮箱
            if (email != null) {
                val emailValues = ContentValues().apply {
                    put(ContactsContract.CommonDataKinds.Email.ADDRESS, email)
                }
                
                contentResolver.update(
                    ContactsContract.Data.CONTENT_URI,
                    emailValues,
                    "${ContactsContract.Data.CONTACT_ID} = ? AND ${ContactsContract.Data.MIMETYPE} = ?",
                    arrayOf(contactId, ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE)
                )
            }
            
            LogManager.i(TAG, "✅ 更新联系人成功: $contactId")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 更新联系人失败", e)
            false
        }
    }
    
    /**
     * 🗑️ 删除联系人
     */
    suspend fun deleteContact(contactId: String): Boolean = withContext(Dispatchers.IO) {
        if (!checkPermission(Manifest.permission.WRITE_CONTACTS)) {
            LogManager.w(TAG, "⚠️ 没有写入联系人权限")
            return@withContext false
        }
        
        try {
            val deleted = contentResolver.delete(
                ContactsContract.RawContacts.CONTENT_URI,
                "${ContactsContract.RawContacts.CONTACT_ID} = ?",
                arrayOf(contactId)
            )
            
            LogManager.i(TAG, "🗑️ 删除联系人: $contactId, 结果: $deleted")
            deleted > 0
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 删除联系人失败", e)
            false
        }
    }
    
    // ==================== 短信管理 ====================
    
    /**
     * 💬 发送短信
     */
    fun sendSms(phoneNumber: String, message: String): Boolean {
        return try {
            if (!checkPermission(Manifest.permission.SEND_SMS)) {
                LogManager.w(TAG, "⚠️ 没有发送短信权限")
                return false
            }
            
            val smsManager = SmsManager.getDefault()
            
            // 如果短信过长，分段发送
            if (message.length > 70) {
                val parts = smsManager.divideMessage(message)
                smsManager.sendMultipartTextMessage(
                    phoneNumber,
                    null,
                    parts,
                    null,
                    null
                )
            } else {
                smsManager.sendTextMessage(
                    phoneNumber,
                    null,
                    message,
                    null,
                    null
                )
            }
            
            LogManager.i(TAG, "✅ 发送短信成功: $phoneNumber")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 发送短信失败", e)
            false
        }
    }
    
    /**
     * 📥 获取收件箱短信
     */
    suspend fun getInboxMessages(limit: Int = 100): List<SmsMessage> = withContext(Dispatchers.IO) {
        getSmsMessages(Telephony.Sms.Inbox.CONTENT_URI, limit)
    }
    
    /**
     * 📤 获取已发送短信
     */
    suspend fun getSentMessages(limit: Int = 100): List<SmsMessage> = withContext(Dispatchers.IO) {
        getSmsMessages(Telephony.Sms.Sent.CONTENT_URI, limit)
    }
    
    /**
     * 💬 获取短信
     */
    private fun getSmsMessages(uri: Uri, limit: Int): List<SmsMessage> {
        if (!checkPermission(Manifest.permission.READ_SMS)) {
            LogManager.w(TAG, "⚠️ 没有读取短信权限")
            return emptyList()
        }
        
        val messages = mutableListOf<SmsMessage>()
        val cursor = contentResolver.query(
            uri,
            null, null, null,
            Telephony.Sms.DATE + " DESC LIMIT $limit"
        )
        
        cursor?.use {
            while (it.moveToNext()) {
                val id = it.getString(it.getColumnIndexOrThrow(Telephony.Sms._ID))
                val threadId = it.getString(it.getColumnIndexOrThrow(Telephony.Sms.THREAD_ID))
                val address = it.getString(it.getColumnIndexOrThrow(Telephony.Sms.ADDRESS)) ?: ""
                val body = it.getString(it.getColumnIndexOrThrow(Telephony.Sms.BODY)) ?: ""
                val date = it.getLong(it.getColumnIndexOrThrow(Telephony.Sms.DATE))
                val type = it.getInt(it.getColumnIndexOrThrow(Telephony.Sms.TYPE))
                val read = it.getInt(it.getColumnIndexOrThrow(Telephony.Sms.READ)) == 1
                
                val smsType = when (type) {
                    Telephony.Sms.MESSAGE_TYPE_INBOX -> SmsType.INBOX
                    Telephony.Sms.MESSAGE_TYPE_SENT -> SmsType.SENT
                    Telephony.Sms.MESSAGE_TYPE_DRAFT -> SmsType.DRAFT
                    Telephony.Sms.MESSAGE_TYPE_OUTBOX -> SmsType.OUTBOX
                    Telephony.Sms.MESSAGE_TYPE_FAILED -> SmsType.FAILED
                    else -> SmsType.INBOX
                }
                
                messages.add(SmsMessage(id, threadId, address, body, date, smsType, read))
            }
        }
        
        LogManager.d(TAG, "📥 获取短信: ${messages.size}条")
        return messages
    }
    
    /**
     * 🔍 搜索短信
     */
    suspend fun searchSms(keyword: String): List<SmsMessage> = withContext(Dispatchers.IO) {
        if (!checkPermission(Manifest.permission.READ_SMS)) {
            return@withContext emptyList()
        }
        
        val messages = mutableListOf<SmsMessage>()
        val cursor = contentResolver.query(
            Telephony.Sms.CONTENT_URI,
            null,
            "${Telephony.Sms.BODY} LIKE ?",
            arrayOf("%$keyword%"),
            Telephony.Sms.DATE + " DESC LIMIT 50"
        )
        
        cursor?.use {
            while (it.moveToNext()) {
                val id = it.getString(it.getColumnIndexOrThrow(Telephony.Sms._ID))
                val threadId = it.getString(it.getColumnIndexOrThrow(Telephony.Sms.THREAD_ID))
                val address = it.getString(it.getColumnIndexOrThrow(Telephony.Sms.ADDRESS)) ?: ""
                val body = it.getString(it.getColumnIndexOrThrow(Telephony.Sms.BODY)) ?: ""
                val date = it.getLong(it.getColumnIndexOrThrow(Telephony.Sms.DATE))
                val type = it.getInt(it.getColumnIndexOrThrow(Telephony.Sms.TYPE))
                val read = it.getInt(it.getColumnIndexOrThrow(Telephony.Sms.READ)) == 1
                
                val smsType = when (type) {
                    Telephony.Sms.MESSAGE_TYPE_INBOX -> SmsType.INBOX
                    Telephony.Sms.MESSAGE_TYPE_SENT -> SmsType.SENT
                    else -> SmsType.INBOX
                }
                
                messages.add(SmsMessage(id, threadId, address, body, date, smsType, read))
            }
        }
        
        messages
    }
    
    /**
     * 🗑️ 删除短信
     */
    fun deleteSms(messageId: String): Boolean {
        return try {
            if (!checkPermission(Manifest.permission.READ_SMS)) {
                LogManager.w(TAG, "⚠️ 没有删除短信权限")
                return false
            }
            
            val deleted = contentResolver.delete(
                Telephony.Sms.CONTENT_URI,
                "${Telephony.Sms._ID} = ?",
                arrayOf(messageId)
            )
            
            LogManager.d(TAG, "🗑️ 删除短信: $messageId, 结果: $deleted")
            deleted > 0
        } catch (e: Exception) {
            LogManager.e(TAG, "删除短信失败", e)
            false
        }
    }
    
    // ==================== 电话管理 ====================
    
    /**
     * 📞 拨打电话
     */
    fun makeCall(phoneNumber: String): Boolean {
        return try {
            if (!checkPermission(Manifest.permission.CALL_PHONE)) {
                LogManager.w(TAG, "⚠️ 没有拨打电话权限")
                // 尝试打开拨号界面
                return openDialer(phoneNumber)
            }
            
            val intent = Intent(Intent.ACTION_CALL)
            intent.data = Uri.parse("tel:$phoneNumber")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            
            LogManager.i(TAG, "✅ 拨打电话: $phoneNumber")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 拨打电话失败", e)
            false
        }
    }
    
    /**
     * 📱 打开拨号界面
     */
    fun openDialer(phoneNumber: String? = null): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_DIAL)
            if (phoneNumber != null) {
                intent.data = Uri.parse("tel:$phoneNumber")
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            
            LogManager.d(TAG, "✅ 打开拨号界面: $phoneNumber")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "打开拨号界面失败", e)
            false
        }
    }
    
    /**
     * 📞 获取通话记录
     */
    suspend fun getCallLogs(limit: Int = 100): List<CallLog> = withContext(Dispatchers.IO) {
        if (!checkPermission(Manifest.permission.READ_CALL_LOG)) {
            LogManager.w(TAG, "⚠️ 没有读取通话记录权限")
            return@withContext emptyList()
        }
        
        val logs = mutableListOf<CallLog>()
        val cursor = contentResolver.query(
            android.provider.CallLog.Calls.CONTENT_URI,
            null, null, null,
            android.provider.CallLog.Calls.DATE + " DESC LIMIT $limit"
        )
        
        cursor?.use {
            while (it.moveToNext()) {
                val id = it.getString(it.getColumnIndexOrThrow(android.provider.CallLog.Calls._ID))
                val number = it.getString(it.getColumnIndexOrThrow(android.provider.CallLog.Calls.NUMBER)) ?: ""
                val name = it.getString(it.getColumnIndexOrThrow(android.provider.CallLog.Calls.CACHED_NAME))
                val date = it.getLong(it.getColumnIndexOrThrow(android.provider.CallLog.Calls.DATE))
                val duration = it.getLong(it.getColumnIndexOrThrow(android.provider.CallLog.Calls.DURATION))
                val type = it.getInt(it.getColumnIndexOrThrow(android.provider.CallLog.Calls.TYPE))
                
                val callType = when (type) {
                    android.provider.CallLog.Calls.INCOMING_TYPE -> CallType.INCOMING
                    android.provider.CallLog.Calls.OUTGOING_TYPE -> CallType.OUTGOING
                    android.provider.CallLog.Calls.MISSED_TYPE -> CallType.MISSED
                    android.provider.CallLog.Calls.REJECTED_TYPE -> CallType.REJECTED
                    else -> CallType.MISSED
                }
                
                logs.add(CallLog(id, number, name, date, duration, callType))
            }
        }
        
        LogManager.d(TAG, "📞 获取通话记录: ${logs.size}条")
        logs
    }
    
    /**
     * 📞 获取最近通话记录
     */
    suspend fun getRecentCalls(count: Int = 10): List<CallLog> = withContext(Dispatchers.IO) {
        getCallLogs(count)
    }
    
    /**
     * 🔍 搜索通话记录
     */
    suspend fun searchCallLogs(query: String): List<CallLog> = withContext(Dispatchers.IO) {
        val logs = getCallLogs()
        logs.filter { log ->
            log.number.contains(query) ||
            log.name?.contains(query, ignoreCase = true) == true
        }
    }
    
    // ==================== 权限检查 ====================
    
    /**
     * ✅ 检查权限
     */
    private fun checkPermission(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
    }
    
    /**
     * 📋 检查所有需要的权限
     */
    fun checkAllPermissions(): Map<String, Boolean> {
        return mapOf(
            "READ_CONTACTS" to checkPermission(Manifest.permission.READ_CONTACTS),
            "WRITE_CONTACTS" to checkPermission(Manifest.permission.WRITE_CONTACTS),
            "READ_SMS" to checkPermission(Manifest.permission.READ_SMS),
            "SEND_SMS" to checkPermission(Manifest.permission.SEND_SMS),
            "READ_CALL_LOG" to checkPermission(Manifest.permission.READ_CALL_LOG),
            "CALL_PHONE" to checkPermission(Manifest.permission.CALL_PHONE)
        )
    }
}
