package com.example.xihe.multimodal

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.example.xihe.utils.LogManager
import com.example.xihe.ocr.OCRManager
import com.example.xihe.ocr.DeepSeekOCRService
import com.example.xihe.ocr.DeepSeekOCRResult
import com.example.xihe.security.PrivacyFilter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * 📸 本地图片分析器
 * 
 * 在本地分析图片内容，不上传到云端
 * 使用OCR识别文字，ML Kit识别物体
 * 
 * 🔒 隐私保护：所有分析都在本地完成
 */
class LocalImageAnalyzer(private val context: Context) {
    
    companion object {
        private const val TAG = "LocalImageAnalyzer"
        
        @Volatile
        private var instance: LocalImageAnalyzer? = null
        
        fun getInstance(context: Context): LocalImageAnalyzer {
            return instance ?: synchronized(this) {
                instance ?: LocalImageAnalyzer(context.applicationContext).also { 
                    instance = it 
                }
            }
        }
    }
    
    // OCR管理器 (本地 ML Kit)
    private val ocrManager = OCRManager.getInstance(context)
    
    // DeepSeek-OCR 云端服务
    private val deepSeekOCR = DeepSeekOCRService.getInstance(context)
    
    // 是否优先使用云端 OCR
    private var preferCloudOCR = false
    
    /**
     * 🔧 配置 DeepSeek API Key
     */
    fun configureDeepSeekApiKey(apiKey: String) {
        deepSeekOCR.saveApiKey(apiKey)
        LogManager.i(TAG, "✅ DeepSeek API Key 已配置")
    }
    
    /**
     * 🔄 设置是否优先使用云端 OCR
     */
    fun setPreferCloudOCR(prefer: Boolean) {
        preferCloudOCR = prefer
        LogManager.i(TAG, "🔄 云端 OCR 优先: $prefer")
    }
    
    /**
     * 📸 分析图片（支持本地和云端 OCR）
     * 
     * @param uri 图片URI
     * @param query 用户问题（可选）
     * @param useCloudOCR 是否使用云端 OCR（null 表示使用默认设置）
     * @return 分析结果
     */
    suspend fun analyzeImage(
        uri: Uri, 
        query: String? = null,
        useCloudOCR: Boolean? = null
    ): ImageAnalysisResult {
        return withContext(Dispatchers.IO) {
            try {
                val shouldUseCloud = useCloudOCR ?: (preferCloudOCR && deepSeekOCR.isConfigured())
                LogManager.i(TAG, "📸 开始图片分析: $uri [云端OCR: $shouldUseCloud]")
                
                // 1. 加载图片
                val bitmap = loadBitmap(uri) ?: return@withContext ImageAnalysisResult(
                    success = false,
                    error = "无法加载图片"
                )
                
                LogManager.d(TAG, "📷 图片尺寸: ${bitmap.width}x${bitmap.height}")
                
                // 2. OCR识别文字 (根据配置选择本地或云端)
                val extractedText: String
                val textBlockCount: Int
                
                if (shouldUseCloud && deepSeekOCR.isConfigured()) {
                    // 使用 DeepSeek-OCR 云端识别
                    val cloudResult = deepSeekOCR.recognizeImage(bitmap, query)
                    if (cloudResult.success) {
                        extractedText = cloudResult.text
                        textBlockCount = extractedText.split("\n").size
                        LogManager.d(TAG, "☁️ DeepSeek-OCR 识别完成，耗时: ${cloudResult.recognitionTime}ms")
                    } else {
                        // 云端失败，回退到本地
                        LogManager.w(TAG, "⚠️ 云端 OCR 失败，回退到本地: ${cloudResult.error}")
                        val localResult = ocrManager.recognizeText(bitmap)
                        extractedText = localResult.textBlocks.joinToString("\n") { it.text }
                        textBlockCount = localResult.textBlocks.size
                    }
                } else {
                    // 使用本地 ML Kit OCR
                    val ocrResult = try {
                        ocrManager.recognizeText(bitmap)
                    } catch (e: Exception) {
                        LogManager.e(TAG, "OCR失败", e)
                        null
                    }
                    extractedText = ocrResult?.textBlocks?.joinToString("\n") { it.text } ?: ""
                    textBlockCount = ocrResult?.textBlocks?.size ?: 0
                }
                
                LogManager.d(TAG, "📝 OCR识别到 $textBlockCount 个文本块")
                
                // 3. 基于用户问题生成回答
                val answer = generateAnswer(extractedText, query, bitmap)
                
                // 4. 🔒 过滤敏感信息（如果要展示给用户）
                val safeText = PrivacyFilter.sanitize(extractedText)
                
                ImageAnalysisResult(
                    success = true,
                    extractedText = safeText,
                    rawText = extractedText,  // 原始文本（仅本地使用）
                    answer = answer,
                    imageWidth = bitmap.width,
                    imageHeight = bitmap.height,
                    textBlockCount = textBlockCount
                )
                
            } catch (e: Exception) {
                LogManager.e(TAG, "图片分析失败", e)
                ImageAnalysisResult(
                    success = false,
                    error = "分析失败: ${e.message}"
                )
            }
        }
    }
    
    /**
     * 📄 分析图片中的文档
     * 优先使用 DeepSeek-OCR 进行高精度文档识别
     */
    suspend fun analyzeDocument(uri: Uri, forceCloud: Boolean = true): DocumentAnalysisResult {
        return withContext(Dispatchers.IO) {
            try {
                val bitmap = loadBitmap(uri) ?: return@withContext DocumentAnalysisResult(
                    success = false,
                    error = "无法加载文档图片"
                )
                
                val fullText: String
                val structure: DocumentStructure?
                
                // 文档识别优先使用 DeepSeek-OCR
                if (forceCloud && deepSeekOCR.isConfigured()) {
                    LogManager.i(TAG, "📄 使用 DeepSeek-OCR 进行文档识别")
                    val cloudResult = deepSeekOCR.recognizeDocument(bitmap)
                    
                    if (cloudResult.success) {
                        fullText = cloudResult.text
                        // 从云端结果解析文档结构
                        structure = parseDocumentStructureFromText(fullText)
                        LogManager.d(TAG, "☁️ 文档识别完成，耗时: ${cloudResult.recognitionTime}ms")
                    } else {
                        // 回退到本地
                        LogManager.w(TAG, "⚠️ 云端文档识别失败，回退到本地")
                        val ocrResult = ocrManager.recognizeText(bitmap)
                        fullText = ocrResult.textBlocks.joinToString("\n") { it.text }
                        structure = analyzeDocumentStructure(ocrResult)
                    }
                } else {
                    val ocrResult = ocrManager.recognizeText(bitmap)
                    fullText = ocrResult.textBlocks.joinToString("\n") { it.text }
                    structure = analyzeDocumentStructure(ocrResult)
                }
                
                DocumentAnalysisResult(
                    success = true,
                    fullText = PrivacyFilter.sanitize(fullText),
                    structure = structure,
                    pageCount = 1,
                    wordCount = fullText.split(Regex("\\s+")).size
                )
                
            } catch (e: Exception) {
                DocumentAnalysisResult(
                    success = false,
                    error = "文档分析失败: ${e.message}"
                )
            }
        }
    }
    
    /**
     * 🔮 使用 DeepSeek-OCR 智能问答
     * 针对图片内容进行问答
     */
    suspend fun askAboutImage(uri: Uri, question: String): ImageAnalysisResult {
        return withContext(Dispatchers.IO) {
            try {
                val bitmap = loadBitmap(uri) ?: return@withContext ImageAnalysisResult(
                    success = false,
                    error = "无法加载图片"
                )
                
                if (!deepSeekOCR.isConfigured()) {
                    return@withContext ImageAnalysisResult(
                        success = false,
                        error = "DeepSeek API 未配置，请先设置 API Key"
                    )
                }
                
                LogManager.i(TAG, "🔮 使用 DeepSeek-OCR 智能问答: $question")
                val result = deepSeekOCR.askAboutImage(bitmap, question)
                
                if (result.success) {
                    ImageAnalysisResult(
                        success = true,
                        extractedText = result.text,
                        rawText = result.text,
                        answer = result.text,
                        imageWidth = bitmap.width,
                        imageHeight = bitmap.height
                    )
                } else {
                    ImageAnalysisResult(
                        success = false,
                        error = result.error
                    )
                }
            } catch (e: Exception) {
                ImageAnalysisResult(
                    success = false,
                    error = "智能问答失败: ${e.message}"
                )
            }
        }
    }
    
    /**
     * 📊 识别表格图片
     */
    suspend fun analyzeTable(uri: Uri): DocumentAnalysisResult {
        return withContext(Dispatchers.IO) {
            try {
                val bitmap = loadBitmap(uri) ?: return@withContext DocumentAnalysisResult(
                    success = false,
                    error = "无法加载图片"
                )
                
                if (!deepSeekOCR.isConfigured()) {
                    return@withContext DocumentAnalysisResult(
                        success = false,
                        error = "DeepSeek API 未配置，表格识别需要云端服务"
                    )
                }
                
                LogManager.i(TAG, "📊 使用 DeepSeek-OCR 进行表格识别")
                val result = deepSeekOCR.recognizeTable(bitmap)
                
                if (result.success) {
                    DocumentAnalysisResult(
                        success = true,
                        fullText = result.text,
                        pageCount = 1,
                        wordCount = result.text.split(Regex("\\s+")).size
                    )
                } else {
                    DocumentAnalysisResult(
                        success = false,
                        error = result.error
                    )
                }
            } catch (e: Exception) {
                DocumentAnalysisResult(
                    success = false,
                    error = "表格识别失败: ${e.message}"
                )
            }
        }
    }
    
    /**
     * ✍️ 识别手写体
     */
    suspend fun analyzeHandwriting(uri: Uri): ImageAnalysisResult {
        return withContext(Dispatchers.IO) {
            try {
                val bitmap = loadBitmap(uri) ?: return@withContext ImageAnalysisResult(
                    success = false,
                    error = "无法加载图片"
                )
                
                if (!deepSeekOCR.isConfigured()) {
                    return@withContext ImageAnalysisResult(
                        success = false,
                        error = "DeepSeek API 未配置，手写体识别需要云端服务"
                    )
                }
                
                LogManager.i(TAG, "✍️ 使用 DeepSeek-OCR 进行手写体识别")
                val result = deepSeekOCR.recognizeHandwriting(bitmap)
                
                if (result.success) {
                    ImageAnalysisResult(
                        success = true,
                        extractedText = result.text,
                        rawText = result.text,
                        answer = "手写内容识别结果:\n${result.text}",
                        imageWidth = bitmap.width,
                        imageHeight = bitmap.height
                    )
                } else {
                    ImageAnalysisResult(
                        success = false,
                        error = result.error
                    )
                }
            } catch (e: Exception) {
                ImageAnalysisResult(
                    success = false,
                    error = "手写体识别失败: ${e.message}"
                )
            }
        }
    }
    
    /**
     * 📊 获取 DeepSeek-OCR 服务状态
     */
    fun getDeepSeekStatus(): String = deepSeekOCR.getStatusInfo()
    
    /**
     * 🔍 检查 DeepSeek-OCR 是否已配置
     */
    fun isDeepSeekConfigured(): Boolean = deepSeekOCR.isConfigured()
    
    /**
     * 🔍 根据问题在图片中查找答案
     */
    suspend fun findAnswerInImage(uri: Uri, question: String): String {
        val result = analyzeImage(uri, question)
        return if (result.success) {
            result.answer ?: "图片中没有找到相关内容"
        } else {
            result.error ?: "分析失败"
        }
    }
    
    // ==================== 私有方法 ====================
    
    /**
     * 加载图片
     */
    private fun loadBitmap(uri: Uri): Bitmap? {
        return try {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                BitmapFactory.decodeStream(inputStream)
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "加载图片失败: $uri", e)
            null
        }
    }
    
    /**
     * 基于OCR文本和用户问题生成回答
     */
    private fun generateAnswer(text: String, query: String?, bitmap: Bitmap): String? {
        if (text.isBlank()) {
            return "图片中没有识别到文字内容"
        }
        
        if (query.isNullOrBlank()) {
            return "图片中包含以下文字内容:\n$text"
        }
        
        // 简单的关键词匹配
        val queryLower = query.lowercase()
        val lines = text.split("\n")
        
        // 查找价格
        if (queryLower.contains("价格") || queryLower.contains("多少钱") || queryLower.contains("price")) {
            val pricePattern = Regex("""[￥¥$]?\s*\d+\.?\d*\s*[元块]?""")
            val prices = pricePattern.findAll(text).map { it.value.trim() }.toList()
            if (prices.isNotEmpty()) {
                return "图片中找到以下价格: ${prices.joinToString(", ")}"
            }
        }
        
        // 查找电话
        if (queryLower.contains("电话") || queryLower.contains("联系") || queryLower.contains("phone")) {
            val phonePattern = Regex("""1[3-9]\d{9}|0\d{2,3}-?\d{7,8}""")
            val phones = phonePattern.findAll(text).map { it.value }.toList()
            if (phones.isNotEmpty()) {
                return "图片中找到以下联系方式: ${phones.joinToString(", ")}"
            }
        }
        
        // 查找日期
        if (queryLower.contains("日期") || queryLower.contains("时间") || queryLower.contains("date")) {
            val datePattern = Regex("""\d{4}[-/年]\d{1,2}[-/月]\d{1,2}日?|\d{1,2}[-/月]\d{1,2}日?""")
            val dates = datePattern.findAll(text).map { it.value }.toList()
            if (dates.isNotEmpty()) {
                return "图片中找到以下日期: ${dates.joinToString(", ")}"
            }
        }
        
        // 通用关键词搜索
        val keywords = query.split(Regex("\\s+"))
        val matchedLines = lines.filter { line ->
            keywords.any { keyword -> line.contains(keyword, ignoreCase = true) }
        }
        
        return if (matchedLines.isNotEmpty()) {
            "找到相关内容:\n${matchedLines.joinToString("\n")}"
        } else {
            "图片内容:\n$text\n\n（未找到与\"$query\"直接相关的内容）"
        }
    }
    
    /**
     * 分析文档结构
     */
    private fun analyzeDocumentStructure(ocrResult: com.example.xihe.ocr.OCRManager.OCRResult): DocumentStructure {
        val blocks = ocrResult.textBlocks
        
        // 简单的结构分析
        val titles = mutableListOf<String>()
        val paragraphs = mutableListOf<String>()
        val lists = mutableListOf<String>()
        
        blocks.forEach { block ->
            val text = block.text.trim()
            when {
                // 标题（短且可能全大写或以数字开头）
                text.length < 50 && (text.matches(Regex("^[\\d一二三四五六七八九十]+[、.．].*")) || 
                                     text.matches(Regex("^第[一二三四五六七八九十\\d]+[章节条].*"))) -> {
                    titles.add(text)
                }
                // 列表项
                text.matches(Regex("^[•·\\-\\*].*")) || text.matches(Regex("^\\d+[、.)].*")) -> {
                    lists.add(text)
                }
                // 段落
                else -> {
                    paragraphs.add(text)
                }
            }
        }
        
        return DocumentStructure(
            titles = titles,
            paragraphs = paragraphs,
            lists = lists
        )
    }
    
    /**
     * 从文本解析文档结构
     */
    private fun parseDocumentStructureFromText(text: String): DocumentStructure {
        val lines = text.split("\n")
        val titles = mutableListOf<String>()
        val paragraphs = mutableListOf<String>()
        val lists = mutableListOf<String>()
        
        lines.forEach { line ->
            val trimmed = line.trim()
            if (trimmed.isEmpty()) return@forEach
            
            when {
                // Markdown 标题
                trimmed.startsWith("#") -> {
                    titles.add(trimmed.trimStart('#').trim())
                }
                // 数字标题
                trimmed.matches(Regex("^[\\d一二三四五六七八九十]+[、.．:：].*")) -> {
                    titles.add(trimmed)
                }
                // 章节标题
                trimmed.matches(Regex("^第[一二三四五六七八九十\\d]+[章节条款项].*")) -> {
                    titles.add(trimmed)
                }
                // 列表项
                trimmed.matches(Regex("^[-•·*]\\s.*")) || 
                trimmed.matches(Regex("^\\d+[.)]\\s.*")) -> {
                    lists.add(trimmed)
                }
                // Markdown 表格行
                trimmed.startsWith("|") && trimmed.endsWith("|") -> {
                    lists.add(trimmed)  // 表格行作为列表处理
                }
                // 普通段落
                else -> {
                    paragraphs.add(trimmed)
                }
            }
        }
        
        return DocumentStructure(
            titles = titles,
            paragraphs = paragraphs,
            lists = lists
        )
    }
}

/**
 * 图片分析结果
 */
data class ImageAnalysisResult(
    val success: Boolean,
    val extractedText: String = "",
    val rawText: String = "",  // 原始文本（未过滤）
    val answer: String? = null,
    val imageWidth: Int = 0,
    val imageHeight: Int = 0,
    val textBlockCount: Int = 0,
    val error: String? = null
)

/**
 * 文档分析结果
 */
data class DocumentAnalysisResult(
    val success: Boolean,
    val fullText: String = "",
    val structure: DocumentStructure? = null,
    val pageCount: Int = 0,
    val wordCount: Int = 0,
    val error: String? = null
)

/**
 * 文档结构
 */
data class DocumentStructure(
    val titles: List<String> = emptyList(),
    val paragraphs: List<String> = emptyList(),
    val lists: List<String> = emptyList()
)
