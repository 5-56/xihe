package com.example.xihe.multimodal

import android.content.Context
import android.graphics.Bitmap
import com.example.xihe.utils.LogManager
import com.example.xihe.ocr.OCRManager
import com.example.xihe.interaction.VoiceInteractionManager
import com.example.xihe.intelligence.EmotionRecognizer
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * 🎭 多模态交互管理器
 * 融合视觉、语音、文本等多种交互方式
 */
class MultimodalInteractionManager(private val context: Context) {
    
    companion object {
        private const val TAG = "MultimodalInteraction"
        
        @Volatile
        private var instance: MultimodalInteractionManager? = null
        
        fun getInstance(context: Context): MultimodalInteractionManager {
            return instance ?: synchronized(this) {
                instance ?: MultimodalInteractionManager(context.applicationContext).also {
                    instance = it
                }
            }
        }
    }
    
    // OCR管理器
    private val ocrManager = OCRManager.getInstance(context)
    
    // 语音交互管理器
    private val voiceManager by lazy { 
        VoiceInteractionManager(context)
    }
    
    // 情绪识别
    private val emotionRecognizer = EmotionRecognizer.getInstance(context)
    
    // 当前交互模式
    private val _currentMode = MutableStateFlow(InteractionMode.VOICE_ONLY)
    val currentMode = _currentMode.asStateFlow()
    
    // 交互上下文
    private var interactionContext: InteractionContext? = null
    
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    
    /**
     * 🎯 初始化
     */
    fun initialize() {
        LogManager.w(TAG, "🚀 初始化多模态交互管理器")
    }
    
    /**
     * 📸 视觉+语音交互
     * 
     * 场景示例:
     * 用户指着菜单说: "这个多少钱？"
     * 系统: OCR识别菜单 + 语音识别 → 找到价格
     */
    suspend fun processVisualVoiceQuery(
        image: Bitmap,
        voiceQuery: String
    ): MultimodalResponse = withContext(Dispatchers.Default) {
        try {
            LogManager.d(TAG, "🎭 处理视觉+语音查询")
            LogManager.d(TAG, "📸 图像: ${image.width}x${image.height}")
            LogManager.d(TAG, "🎤 语音: $voiceQuery")
            
            // 1. OCR识别图像文字
            val ocrResult = ocrManager.recognizeText(image)
            LogManager.d(TAG, "📝 OCR识别到 ${ocrResult.textBlocks.size} 个文本块")
            
            // 2. 分析语音查询意图
            val intent = analyzeIntent(voiceQuery)
            LogManager.d(TAG, "🎯 意图识别: $intent")
            
            // 3. 融合视觉和语音信息
            val result = when (intent) {
                QueryIntent.PRICE_QUERY -> {
                    // 查询价格
                    findPriceInOCR(ocrResult, voiceQuery)
                }
                
                QueryIntent.CONTENT_QUERY -> {
                    // 查询内容
                    findContentInOCR(ocrResult, voiceQuery)
                }
                
                QueryIntent.TRANSLATE_REQUEST -> {
                    // 翻译请求
                    translateOCRText(ocrResult)
                }
                
                QueryIntent.READ_REQUEST -> {
                    // 朗读请求
                    readOCRText(ocrResult)
                }
                
                QueryIntent.EXPLAIN_REQUEST -> {
                    // 解释说明
                    explainOCRContent(ocrResult, voiceQuery)
                }
                
                else -> {
                    "抱歉，我不太明白您的意思"
                }
            }
            
            MultimodalResponse(
                success = true,
                text = result,
                confidence = 0.8f,
                mode = InteractionMode.VISUAL_VOICE
            )
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 多模态处理失败", e)
            MultimodalResponse(
                success = false,
                text = "处理失败: ${e.message}",
                confidence = 0f,
                mode = InteractionMode.VISUAL_VOICE
            )
        }
    }
    
    /**
     * 📸 纯视觉查询
     */
    suspend fun processVisualQuery(image: Bitmap): MultimodalResponse = withContext(Dispatchers.Default) {
        try {
            LogManager.d(TAG, "📸 处理纯视觉查询")
            
            // OCR识别
            val ocrResult = ocrManager.recognizeText(image)
            
            // 提取文本
            val allText = ocrResult.textBlocks.joinToString("\n") { it.text }
            
            MultimodalResponse(
                success = true,
                text = allText,
                confidence = 0.9f,
                mode = InteractionMode.VISUAL_ONLY,
                ocrData = ocrResult
            )
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 视觉处理失败", e)
            MultimodalResponse(
                success = false,
                text = "识别失败: ${e.message}",
                confidence = 0f,
                mode = InteractionMode.VISUAL_ONLY
            )
        }
    }
    
    /**
     * 🎯 分析语音意图
     */
    private fun analyzeIntent(voiceQuery: String): QueryIntent {
        val query = voiceQuery.lowercase()
        
        return when {
            query.contains("多少钱") || query.contains("价格") || query.contains("几块") -> 
                QueryIntent.PRICE_QUERY
            
            query.contains("这是什么") || query.contains("什么意思") -> 
                QueryIntent.CONTENT_QUERY
            
            query.contains("翻译") || query.contains("英文") || query.contains("中文") -> 
                QueryIntent.TRANSLATE_REQUEST
            
            query.contains("读") || query.contains("念") || query.contains("播报") -> 
                QueryIntent.READ_REQUEST
            
            query.contains("解释") || query.contains("说明") || query.contains("讲解") -> 
                QueryIntent.EXPLAIN_REQUEST
            
            else -> QueryIntent.UNKNOWN
        }
    }
    
    /**
     * 💰 在OCR结果中查找价格
     */
    private fun findPriceInOCR(ocrResult: OCRManager.OCRResult, query: String): String {
        // 提取商品名称
        val itemName = extractItemName(query)
        
        // 价格正则表达式
        val pricePattern = Regex("(\\d+\\.?\\d*)元|(￥\\d+\\.?\\d*)|(\\\$\\d+\\.?\\d*)")
        
        // 遍历文本块查找价格
        ocrResult.textBlocks.forEach { block ->
            val text = block.text
            
            // 如果包含商品名称，查找附近的价格
            if (itemName.isEmpty() || text.contains(itemName, ignoreCase = true)) {
                val priceMatch = pricePattern.find(text)
                if (priceMatch != null) {
                    val price = priceMatch.value
                    return if (itemName.isNotEmpty()) {
                        "${itemName}的价格是${price}"
                    } else {
                        "价格是${price}"
                    }
                }
            }
        }
        
        // 如果没找到，列出所有价格
        val allPrices = ocrResult.textBlocks.mapNotNull { block ->
            pricePattern.find(block.text)?.value
        }
        
        return if (allPrices.isNotEmpty()) {
            "我看到了这些价格: ${allPrices.joinToString(", ")}"
        } else {
            "抱歉，没有找到价格信息"
        }
    }
    
    /**
     * 📝 提取商品名称
     */
    private fun extractItemName(query: String): String {
        // 简单提取逻辑，可以更复杂
        val patterns = listOf(
            Regex("(.+)多少钱"),
            Regex("(.+)价格"),
            Regex("这个(.+)"),
            Regex("(.+)的价格")
        )
        
        patterns.forEach { pattern ->
            val match = pattern.find(query)
            if (match != null && match.groupValues.size > 1) {
                return match.groupValues[1].trim()
            }
        }
        
        return ""
    }
    
    /**
     * 🔍 在OCR结果中查找内容
     */
    private fun findContentInOCR(ocrResult: OCRManager.OCRResult, query: String): String {
        // 提取关键词
        val keywords = extractKeywords(query)
        
        // 在文本中搜索
        val matchedBlocks = ocrResult.textBlocks.filter { block ->
            keywords.any { keyword ->
                block.text.contains(keyword, ignoreCase = true)
            }
        }
        
        return if (matchedBlocks.isNotEmpty()) {
            "找到了: ${matchedBlocks.joinToString("\n") { it.text }}"
        } else {
            "没有找到相关内容"
        }
    }
    
    /**
     * 🔤 提取关键词
     */
    private fun extractKeywords(query: String): List<String> {
        // 移除疑问词
        val stopWords = listOf("这是", "什么", "是", "的", "吗", "呢", "啊")
        var cleaned = query
        stopWords.forEach { word ->
            cleaned = cleaned.replace(word, "")
        }
        return cleaned.trim().split(" ").filter { it.isNotEmpty() }
    }
    
    /**
     * 🌐 翻译OCR文本
     */
    private fun translateOCRText(ocrResult: OCRManager.OCRResult): String {
        // 提取所有文本
        val allText = ocrResult.textBlocks.joinToString(" ") { it.text }
        
        // 检测语言并翻译
        val detectedLanguage = detectLanguage(allText)
        val translatedText = when (detectedLanguage) {
            "en" -> translateToChineseSimple(allText)
            "zh" -> translateToEnglishSimple(allText)
            "ja" -> translateJapaneseToChineseSimple(allText)
            else -> "识别到的文本: $allText"
        }
        
        return "🌐 翻译结果:\n原文($detectedLanguage): $allText\n译文: $translatedText"
    }
    
    private fun detectLanguage(text: String): String {
        val chinesePattern = Regex("[\u4e00-\u9fa5]")
        val japanesePattern = Regex("[\u3040-\u309f\u30a0-\u30ff]")
        val englishPattern = Regex("[a-zA-Z]")
        
        val chineseCount = chinesePattern.findAll(text).count()
        val japaneseCount = japanesePattern.findAll(text).count()
        val englishCount = englishPattern.findAll(text).count()
        
        return when {
            japaneseCount > 0 -> "ja"
            chineseCount > englishCount -> "zh"
            englishCount > 0 -> "en"
            else -> "unknown"
        }
    }
    
    private fun translateToChineseSimple(englishText: String): String {
        // 简单的常见词汇翻译
        val commonTranslations = mapOf(
            "hello" to "你好", "world" to "世界", "thank" to "感谢",
            "you" to "你", "welcome" to "欢迎", "good" to "好",
            "morning" to "早上", "night" to "晚上", "day" to "天",
            "search" to "搜索", "click" to "点击", "open" to "打开",
            "close" to "关闭", "save" to "保存", "delete" to "删除",
            "settings" to "设置", "home" to "主页", "back" to "返回"
        )
        
        var result = englishText.lowercase()
        commonTranslations.forEach { (en, zh) ->
            result = result.replace(en, zh)
        }
        return result
    }
    
    private fun translateToEnglishSimple(chineseText: String): String {
        val commonTranslations = mapOf(
            "你好" to "hello", "世界" to "world", "感谢" to "thank you",
            "欢迎" to "welcome", "早上好" to "good morning",
            "搜索" to "search", "点击" to "click", "打开" to "open",
            "关闭" to "close", "保存" to "save", "删除" to "delete",
            "设置" to "settings", "主页" to "home", "返回" to "back"
        )
        
        var result = chineseText
        commonTranslations.forEach { (zh, en) ->
            result = result.replace(zh, en)
        }
        return result
    }
    
    private fun translateJapaneseToChineseSimple(japaneseText: String): String {
        val commonTranslations = mapOf(
            "こんにちは" to "你好", "ありがとう" to "谢谢",
            "おはよう" to "早上好", "こんばんは" to "晚上好",
            "はい" to "是", "いいえ" to "不是"
        )
        
        var result = japaneseText
        commonTranslations.forEach { (ja, zh) ->
            result = result.replace(ja, zh)
        }
        return result
    }
    
    /**
     * 📢 朗读OCR文本
     */
    private fun readOCRText(ocrResult: OCRManager.OCRResult): String {
        // 提取所有文本
        val allText = ocrResult.textBlocks.joinToString("。") { it.text }
        
        // 触发TTS朗读
        scope.launch {
            // voiceManager.speak(allText)
        }
        
        return "正在为您朗读..."
    }
    
    /**
     * 💡 解释OCR内容
     */
    private fun explainOCRContent(ocrResult: OCRManager.OCRResult, query: String): String {
        val allText = ocrResult.textBlocks.joinToString(" ") { it.text }
        
        // 分析文本类型并提供解释
        val textType = analyzeTextType(allText)
        val explanation = when (textType) {
            TextType.PRICE -> explainPriceInfo(allText)
            TextType.PHONE -> explainPhoneNumber(allText)
            TextType.DATE -> explainDateInfo(allText)
            TextType.ADDRESS -> explainAddressInfo(allText)
            TextType.EMAIL -> explainEmailInfo(allText)
            TextType.URL -> explainUrlInfo(allText)
            TextType.CODE -> explainCodeInfo(allText)
            else -> "这是一段普通文本，内容为: $allText"
        }
        
        return "💡 内容解释:\n$explanation"
    }
    
    private enum class TextType { PRICE, PHONE, DATE, ADDRESS, EMAIL, URL, CODE, GENERAL }
    
    private fun analyzeTextType(text: String): TextType {
        return when {
            text.contains(Regex("[¥￥\\$]")) || text.contains("元") -> TextType.PRICE
            text.contains(Regex("1[3-9]\\d{9}")) -> TextType.PHONE
            text.contains(Regex("\\d{4}[-/]年?\\d{1,2}[-/]月?\\d{1,2}日?")) -> TextType.DATE
            text.contains("省") || text.contains("市") || text.contains("区") || text.contains("街") -> TextType.ADDRESS
            text.contains("@") && text.contains(".") -> TextType.EMAIL
            text.contains("http") || text.contains("www.") -> TextType.URL
            text.contains(Regex("[{}();=]")) -> TextType.CODE
            else -> TextType.GENERAL
        }
    }
    
    private fun explainPriceInfo(text: String): String {
        val priceMatch = Regex("[¥￥\\$]?\\s*(\\d+(?:\\.\\d{2})?)").find(text)
        val price = priceMatch?.groupValues?.get(1) ?: "unknown"
        return "这是一个价格信息，金额为: ¥$price"
    }
    
    private fun explainPhoneNumber(text: String): String {
        val phoneMatch = Regex("1[3-9]\\d{9}").find(text)
        val phone = phoneMatch?.value ?: "unknown"
        return "这是一个手机号码: $phone，归属地可通过运营商查询"
    }
    
    private fun explainDateInfo(text: String): String {
        return "这是一个日期信息，表示的时间为: $text"
    }
    
    private fun explainAddressInfo(text: String): String {
        return "这是一个地址信息: $text，可以用于导航或寄快递"
    }
    
    private fun explainEmailInfo(text: String): String {
        val emailMatch = Regex("[\\w.-]+@[\\w.-]+\\.\\w+").find(text)
        val email = emailMatch?.value ?: "unknown"
        return "这是一个电子邮箱地址: $email"
    }
    
    private fun explainUrlInfo(text: String): String {
        return "这是一个网址链接，点击可以访问相关网页"
    }
    
    private fun explainCodeInfo(text: String): String {
        return "这看起来是一段代码或程序文本"
    }
    
    /**
     * 🎤 手势+语音交互
     * 
     * 场景: 用户滑动手势 + 说 "翻到下一页"
     */
    fun processGestureVoice(gesture: GestureType, voiceCommand: String): MultimodalResponse {
        LogManager.d(TAG, "👋 处理手势+语音: $gesture + $voiceCommand")
        
        // 融合手势和语音
        val action = when {
            gesture == GestureType.SWIPE_LEFT && voiceCommand.contains("下一页") -> {
                "翻到下一页"
            }
            gesture == GestureType.SWIPE_RIGHT && voiceCommand.contains("上一页") -> {
                "翻到上一页"
            }
            gesture == GestureType.PINCH && voiceCommand.contains("放大") -> {
                "放大显示"
            }
            else -> {
                "未识别的手势命令组合"
            }
        }
        
        return MultimodalResponse(
            success = true,
            text = action,
            confidence = 0.9f,
            mode = InteractionMode.GESTURE_VOICE
        )
    }
    
    /**
     * 🎭 情绪+语音交互
     * 
     * 场景: 根据用户情绪调整交互方式
     */
    fun processEmotionalInteraction(voiceCommand: String): MultimodalResponse {
        // 获取当前情绪
        val emotion = emotionRecognizer.currentEmotion.value
        
        // 根据情绪调整响应
        val emotionalResponse = emotionRecognizer.generateEmotionalResponse(emotion.emotion)
        
        LogManager.d(TAG, "🎭 情绪化交互: ${emotion.emotion} → ${emotionalResponse.tone}")
        
        return MultimodalResponse(
            success = true,
            text = "以${emotionalResponse.tone}的语气回复",
            confidence = emotion.confidence,
            mode = InteractionMode.EMOTIONAL_VOICE
        )
    }
    
    /**
     * 🔄 切换交互模式
     */
    fun setInteractionMode(mode: InteractionMode) {
        _currentMode.value = mode
        LogManager.d(TAG, "🔄 切换到交互模式: $mode")
    }
}

/**
 * 🎭 交互模式
 */
enum class InteractionMode {
    VOICE_ONLY,         // 纯语音
    VISUAL_ONLY,        // 纯视觉
    VISUAL_VOICE,       // 视觉+语音
    GESTURE_VOICE,      // 手势+语音
    EMOTIONAL_VOICE,    // 情绪+语音
    MULTIMODAL          // 完全多模态
}

/**
 * 🎯 查询意图
 */
enum class QueryIntent {
    PRICE_QUERY,        // 价格查询
    CONTENT_QUERY,      // 内容查询
    TRANSLATE_REQUEST,  // 翻译请求
    READ_REQUEST,       // 朗读请求
    EXPLAIN_REQUEST,    // 解释请求
    UNKNOWN             // 未知
}

/**
 * 👋 手势类型
 */
enum class GestureType {
    SWIPE_LEFT,     // 左滑
    SWIPE_RIGHT,    // 右滑
    SWIPE_UP,       // 上滑
    SWIPE_DOWN,     // 下滑
    PINCH,          // 缩放
    TAP,            // 点击
    LONG_PRESS      // 长按
}

/**
 * 📊 多模态响应
 */
data class MultimodalResponse(
    val success: Boolean,
    val text: String,
    val confidence: Float,
    val mode: InteractionMode,
    val ocrData: OCRManager.OCRResult? = null,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * 📝 交互上下文
 */
data class InteractionContext(
    val lastImage: Bitmap? = null,
    val lastVoiceCommand: String? = null,
    val lastGesture: GestureType? = null,
    val timestamp: Long = System.currentTimeMillis()
)
