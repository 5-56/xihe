package com.example.xihe.multimodal

import android.content.Context
import android.net.Uri
import com.example.xihe.utils.LogManager
import com.example.xihe.security.PrivacyFilter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * 📄 本地文档分析器
 * 
 * 在本地分析文档内容，不上传到云端
 * 支持: TXT, CSV, JSON, XML, MD 等文本文件
 * 
 * 🔒 隐私保护：所有分析都在本地完成
 */
class LocalDocumentAnalyzer(private val context: Context) {
    
    companion object {
        private const val TAG = "LocalDocumentAnalyzer"
        private const val MAX_FILE_SIZE = 5 * 1024 * 1024  // 5MB 最大文件大小
        
        @Volatile
        private var instance: LocalDocumentAnalyzer? = null
        
        fun getInstance(context: Context): LocalDocumentAnalyzer {
            return instance ?: synchronized(this) {
                instance ?: LocalDocumentAnalyzer(context.applicationContext).also { 
                    instance = it 
                }
            }
        }
        
        // 支持的文件类型
        val SUPPORTED_EXTENSIONS = listOf(
            "txt", "text",
            "csv",
            "json",
            "xml",
            "md", "markdown",
            "log",
            "html", "htm",
            "yaml", "yml",
            "ini", "conf", "config"
        )
    }
    
    /**
     * 📄 分析文档（完全本地，不上传云端）
     * 
     * @param uri 文档URI
     * @param query 用户问题（可选）
     * @return 分析结果
     */
    suspend fun analyzeDocument(uri: Uri, query: String? = null): FileAnalysisResult {
        return withContext(Dispatchers.IO) {
            try {
                LogManager.i(TAG, "开始本地文档分析: $uri")
                
                // 1. 获取文件信息
                val fileName = getFileName(uri)
                val extension = fileName?.substringAfterLast('.', "")?.lowercase() ?: ""
                
                LogManager.d(TAG, "📁 文件名: $fileName, 扩展名: $extension")
                
                // 2. 读取文件内容
                val content = readFileContent(uri)
                if (content == null) {
                    return@withContext FileAnalysisResult(
                        success = false,
                        error = "无法读取文件内容"
                    )
                }
                
                LogManager.d(TAG, "📝 文件内容长度: ${content.length} 字符")
                
                // 3. 根据文件类型进行解析
                val parsedContent = when (extension) {
                    "csv" -> parseCSV(content)
                    "json" -> parseJSON(content)
                    "xml", "html", "htm" -> parseXML(content)
                    "md", "markdown" -> parseMarkdown(content)
                    else -> ParsedContent(content, "text")
                }
                
                // 4. 基于用户问题生成回答
                val answer = if (query != null) {
                    findAnswerInContent(parsedContent.text, query)
                } else {
                    generateSummary(parsedContent)
                }
                
                // 5. 🔒 过滤敏感信息
                val safeContent = PrivacyFilter.sanitize(parsedContent.text)
                val safeAnswer = PrivacyFilter.sanitize(answer)
                
                FileAnalysisResult(
                    success = true,
                    fileName = fileName,
                    fileType = extension,
                    contentPreview = safeContent.take(500),
                    fullContent = safeContent,
                    answer = safeAnswer,
                    lineCount = content.lines().size,
                    wordCount = content.split(Regex("\\s+")).size,
                    charCount = content.length
                )
                
            } catch (e: Exception) {
                LogManager.e(TAG, "文档分析失败", e)
                FileAnalysisResult(
                    success = false,
                    error = "分析失败: ${e.message}"
                )
            }
        }
    }
    
    /**
     * 🔍 在文档中查找答案
     */
    suspend fun findAnswer(uri: Uri, question: String): String {
        val result = analyzeDocument(uri, question)
        return if (result.success) {
            result.answer ?: "文档中没有找到相关内容"
        } else {
            result.error ?: "分析失败"
        }
    }
    
    /**
     * 📊 获取文档摘要
     */
    suspend fun getSummary(uri: Uri): String {
        val result = analyzeDocument(uri, null)
        return if (result.success) {
            buildString {
                appendLine("📄 文件: ${result.fileName}")
                appendLine("📝 类型: ${result.fileType}")
                appendLine("📏 行数: ${result.lineCount}")
                appendLine("🔤 字数: ${result.wordCount}")
                appendLine()
                appendLine("📋 内容预览:")
                appendLine(result.contentPreview)
            }
        } else {
            result.error ?: "无法生成摘要"
        }
    }
    
    // ==================== 私有方法 ====================
    
    /**
     * 获取文件名
     */
    private fun getFileName(uri: Uri): String? {
        return try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (nameIndex >= 0) cursor.getString(nameIndex) else null
                } else null
            }
        } catch (e: Exception) {
            uri.lastPathSegment
        }
    }
    
    /**
     * 读取文件内容
     */
    private fun readFileContent(uri: Uri): String? {
        return try {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                // 检查文件大小
                val available = inputStream.available()
                if (available > MAX_FILE_SIZE) {
                    LogManager.w(TAG, "文件过大: $available bytes")
                    return null
                }
                
                BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8)).use { reader ->
                    reader.readText()
                }
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "读取文件失败", e)
            null
        }
    }
    
    /**
     * 解析CSV
     */
    private fun parseCSV(content: String): ParsedContent {
        val lines = content.lines()
        val headers = lines.firstOrNull()?.split(",")?.map { it.trim() } ?: emptyList()
        val dataRows = lines.drop(1).take(100)  // 最多显示100行
        
        val formatted = buildString {
            appendLine("表头: ${headers.joinToString(" | ")}")
            appendLine("---")
            dataRows.forEachIndexed { index, row ->
                appendLine("第${index + 1}行: $row")
            }
            if (lines.size > 101) {
                appendLine("... 还有 ${lines.size - 101} 行")
            }
        }
        
        return ParsedContent(formatted, "csv", headers)
    }
    
    /**
     * 解析JSON
     */
    private fun parseJSON(content: String): ParsedContent {
        // 简单格式化JSON
        val formatted = try {
            val trimmed = content.trim()
            if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
                // 简单的JSON美化
                formatJSON(trimmed)
            } else {
                content
            }
        } catch (e: Exception) {
            content
        }
        
        return ParsedContent(formatted, "json")
    }
    
    /**
     * 简单的JSON格式化
     */
    private fun formatJSON(json: String): String {
        val sb = StringBuilder()
        var indent = 0
        var inString = false
        
        for (char in json) {
            when {
                char == '"' && (sb.isEmpty() || sb.last() != '\\') -> {
                    inString = !inString
                    sb.append(char)
                }
                !inString && (char == '{' || char == '[') -> {
                    sb.append(char)
                    sb.append('\n')
                    indent++
                    sb.append("  ".repeat(indent))
                }
                !inString && (char == '}' || char == ']') -> {
                    sb.append('\n')
                    indent--
                    sb.append("  ".repeat(indent))
                    sb.append(char)
                }
                !inString && char == ',' -> {
                    sb.append(char)
                    sb.append('\n')
                    sb.append("  ".repeat(indent))
                }
                !inString && char == ':' -> {
                    sb.append(": ")
                }
                !inString && char.isWhitespace() -> {
                    // 跳过空白
                }
                else -> {
                    sb.append(char)
                }
            }
        }
        
        return sb.toString()
    }
    
    /**
     * 解析XML/HTML
     */
    private fun parseXML(content: String): ParsedContent {
        // 提取文本内容（移除标签）
        val textOnly = content.replace(Regex("<[^>]+>"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        
        return ParsedContent(textOnly, "xml")
    }
    
    /**
     * 解析Markdown
     */
    private fun parseMarkdown(content: String): ParsedContent {
        // 提取标题
        val headers = Regex("^#+\\s+(.+)$", RegexOption.MULTILINE)
            .findAll(content)
            .map { it.groupValues[1] }
            .toList()
        
        return ParsedContent(content, "markdown", headers)
    }
    
    /**
     * 在内容中查找答案
     */
    private fun findAnswerInContent(content: String, query: String): String {
        val queryLower = query.lowercase()
        val lines = content.lines()
        
        // 关键词匹配
        val keywords = query.split(Regex("\\s+")).filter { it.length > 1 }
        val matchedLines = lines.filter { line ->
            keywords.any { keyword -> line.contains(keyword, ignoreCase = true) }
        }.take(10)
        
        return if (matchedLines.isNotEmpty()) {
            "找到以下相关内容:\n${matchedLines.joinToString("\n")}"
        } else {
            "文档中未找到与\"$query\"直接相关的内容"
        }
    }
    
    /**
     * 生成文档摘要
     */
    private fun generateSummary(parsed: ParsedContent): String {
        val preview = parsed.text.take(1000)
        return when (parsed.type) {
            "csv" -> "这是一个CSV表格文件:\n$preview"
            "json" -> "这是一个JSON数据文件:\n$preview"
            "xml" -> "这是一个XML/HTML文件，提取的文本内容:\n$preview"
            "markdown" -> "这是一个Markdown文档:\n$preview"
            else -> "文档内容:\n$preview"
        }
    }
}

/**
 * 解析后的内容
 */
data class ParsedContent(
    val text: String,
    val type: String,
    val metadata: List<String> = emptyList()
)

/**
 * 文件分析结果
 */
data class FileAnalysisResult(
    val success: Boolean,
    val fileName: String? = null,
    val fileType: String? = null,
    val contentPreview: String = "",
    val fullContent: String = "",
    val answer: String? = null,
    val lineCount: Int = 0,
    val wordCount: Int = 0,
    val charCount: Int = 0,
    val error: String? = null
)
