package com.example.xihe.training

import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.data.ConversationDataManager
import kotlinx.coroutines.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/**
 * 📱 本地模型训练器
 * 在手机上训练个性化的羲和AI模型
 * 
 * ⚠️ 重要说明：
 * TensorFlow Lite 只支持推理，不支持在设备端训练！
 * 
 * 本类现在作为 OnDeviceLearner 的包装器，提供：
 * - TF-IDF 向量化文本匹配
 * - 意图分类学习
 * - 模式记忆与相似度匹配
 * 
 * 如需真正的深度学习训练，请使用服务端方案。
 */
class LocalModelTrainer private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "LocalModelTrainer"
        private const val MODEL_DIR = "xihe_model"
        private const val CHECKPOINT_DIR = "checkpoints"
        private const val CONFIG_FILE = "training_config.json"
        
        @Volatile
        private var instance: LocalModelTrainer? = null
        
        fun getInstance(context: Context): LocalModelTrainer {
            return instance ?: synchronized(this) {
                instance ?: LocalModelTrainer(context.applicationContext).also {
                    instance = it
                }
            }
        }
    }
    
    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
    }
    
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    
    // 模型目录
    private val modelDir: File by lazy {
        File(context.filesDir, MODEL_DIR).apply {
            if (!exists()) mkdirs()
        }
    }
    
    // 检查点目录
    private val checkpointDir: File by lazy {
        File(modelDir, CHECKPOINT_DIR).apply {
            if (!exists()) mkdirs()
        }
    }
    
    // 训练配置
    private var config: LocalTrainingConfig = LocalTrainingConfig()
    
    // 🆕 使用真正可用的设备端学习器
    private val onDeviceLearner: OnDeviceLearner by lazy {
        OnDeviceLearner.getInstance(context)
    }
    
    // 训练状态
    private var isTraining = false
    private var currentEpoch = 0
    private var totalLoss = 0.0
    
    /**
     * 开始训练（使用真正可用的设备端学习方案）
     */
    suspend fun startTraining(
        onProgress: (TrainingProgress) -> Unit
    ): TrainingResult = withContext(Dispatchers.Default) {
        if (isTraining) {
            LogManager.i(TAG, "训练已在进行中")
            return@withContext TrainingResult.AlreadyRunning
        }
        
        try {
            isTraining = true
            currentEpoch = 0
            totalLoss = 0.0
            
            LogManager.d(TAG, "🚀 开始本地模型学习（使用 OnDeviceLearner）")
            
            // 🆕 委托给 OnDeviceLearner 执行真正的学习
            val result = onDeviceLearner.startLearning { progress ->
                currentEpoch = progress.epoch
                onProgress(progress)
            }
            
            // 更新状态
            when (result) {
                is TrainingResult.Success -> {
                    totalLoss = result.averageLoss * result.epochs
                    currentEpoch = result.epochs
                }
                else -> {}
            }
            
            result
            
        } catch (e: Exception) {
            LogManager.e(TAG, "训练失败", e)
            TrainingResult.Failed(e.message ?: "未知错误")
        } finally {
            isTraining = false
        }
    }
    
    /**
     * 🔮 使用学习到的模式进行预测
     */
    suspend fun predict(input: String): PredictionResult {
        return onDeviceLearner.predict(input)
    }
    
    /**
     * 📚 从新对话学习（增量学习）
     */
    fun learnFromConversation(userInput: String, aiResponse: String) {
        onDeviceLearner.learnFromConversation(userInput, aiResponse)
    }
    
    /**
     * 📊 获取学习统计
     */
    fun getLearnerStatistics(): LearnerStatistics {
        return onDeviceLearner.getStatistics()
    }
    
    /**
     * ⏸️ 暂停训练
     */
    fun pauseTraining() {
        isTraining = false
        LogManager.d(TAG, "⏸️ 训练已暂停")
    }
    
    /**
     * 📊 获取训练进度
     */
    fun getTrainingStatus(): TrainingStatus {
        return TrainingStatus(
            isTraining = isTraining,
            currentEpoch = currentEpoch,
            totalEpochs = config.epochs,
            averageLoss = if (currentEpoch > 0) totalLoss / currentEpoch else 0.0
        )
    }
    
    // 🆕 旧方法已移除，所有训练逻辑委托给 OnDeviceLearner
    // OnDeviceLearner 使用真正可用的 TF-IDF + 余弦相似度方案
}

// ==================== 数据模型 ====================

/**
 * 本地训练配置
 */
@Serializable
data class LocalTrainingConfig(
    val vocabSize: Int = 10000,        // 词汇表大小
    val hiddenSize: Int = 256,         // 隐藏层大小（小模型）
    val numLayers: Int = 4,            // 层数（精简）
    val batchSize: Int = 4,            // 批次大小（小批次节省内存）
    val epochs: Int = 10,              // 训练轮数
    val learningRate: Float = 0.0001f, // 学习率
    val checkpointInterval: Int = 2    // 检查点保存间隔
)

/**
 * 训练进度
 */
data class TrainingProgress(
    val stage: String,
    val epoch: Int = 0,
    val totalEpochs: Int = 0,
    val progress: Float = 0f,
    val message: String = ""
)

/**
 * 训练状态
 */
data class TrainingStatus(
    val isTraining: Boolean,
    val currentEpoch: Int,
    val totalEpochs: Int,
    val averageLoss: Double
)

/**
 * 训练结果
 */
sealed class TrainingResult {
    data class Success(
        val epochs: Int,
        val averageLoss: Double,
        val accuracy: Double,
        val modelPath: String
    ) : TrainingResult()
    
    data class Failed(val error: String) : TrainingResult()
    object AlreadyRunning : TrainingResult()
    object InsufficientData : TrainingResult()
    object Interrupted : TrainingResult()
}

/**
 * 训练数据项
 * 🆕 注意：OnDeviceLearner 使用 TrainingPair，此类保留用于向后兼容
 */
data class TrainingDataItem(
    val input: String,
    val output: String
)

// 🆕 MiniLanguageModel 已移除
// 原因：TensorFlow Lite 不支持设备端训练，空实现的 backward() 和 updateParameters() 导致训练无效
// 替代方案：使用 OnDeviceLearner 的 TF-IDF + 余弦相似度方案
