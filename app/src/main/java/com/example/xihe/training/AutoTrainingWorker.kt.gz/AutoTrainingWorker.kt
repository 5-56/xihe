package com.example.xihe.training

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import com.example.xihe.utils.LogManager
import androidx.core.app.NotificationCompat
import androidx.work.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.delay
import java.io.File
import java.util.concurrent.TimeUnit
import com.example.xihe.training.OnDeviceLearner

/**
 * 🤖 自动训练Worker (增强版)
 * 在手机充电、电量充足、空闲时自动进行增量训练
 */
class AutoTrainingWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {
    
    companion object {
        const val TAG = "AutoTrainingWorker"
        const val WORK_NAME = "XiheAutoTraining"
        const val PREFS_NAME = "training_prefs"
        const val KEY_OFFSET = "last_trained_offset"
        const val BATCH_SIZE = 20  // 每次处理20条
        
        // 通知配置
        private const val NOTIFICATION_CHANNEL_ID = "xihe_training_channel"
        private const val NOTIFICATION_ID = 1001
        
        // 训练条件
        private const val MIN_BATTERY_LEVEL = 50
        
        /**
         * 📅 调度自动训练任务
         */
        fun schedule(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiresCharging(true)              // 必须充电
                .setRequiresBatteryNotLow(true)         // 电量不能低
                .setRequiresDeviceIdle(true)            // 设备空闲
                .build()
            
            val trainingRequest = PeriodicWorkRequestBuilder<AutoTrainingWorker>(
                1, TimeUnit.HOURS, // 每小时检查一次
                15, TimeUnit.MINUTES
            )
                .setConstraints(constraints)
                .build()
            
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                trainingRequest
            )
            
            LogManager.i(TAG, "✅ 自动训练任务已调度")
        }
        
        /**
         * 🚫 取消自动训练
         */
        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
            LogManager.i(TAG, "⏹️ 自动训练任务已取消")
        }
    }
    
    override suspend fun doWork(): Result {
        return try {
            LogManager.i(TAG, "🤖 自动训练任务开始")
            
            // 1. 检查设备状态
            if (!checkDeviceConditions()) {
                LogManager.i(TAG, "❌ 设备条件不满足，跳过训练")
                return Result.success()
            }
            
            val learner = OnDeviceLearner.getInstance(applicationContext)
            val prefs = applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            
            // 2. 初始化模型
            if (!learner.initialize()) {
                 LogManager.e(TAG, "❌ 模型初始化失败")
                 return Result.failure()
            }
            
            // 🆕 学习智能脚本库
            LogManager.i(TAG, "📚 正在学习脚本库...")
            com.example.xihe.automation.script.SmartScriptManager.initialize(applicationContext)
            val scripts = com.example.xihe.automation.script.SmartScriptManager.getAllScripts()
            if (scripts.isNotEmpty()) {
                learner.learnScripts(scripts)
                LogManager.i(TAG, "✅ 已学习 ${scripts.size} 个自动化脚本")
            }
            
            // 3. 获取数据文件
            val dataFile = File(applicationContext.filesDir, "xihe_conversations/training_data.jsonl")
            if (!dataFile.exists()) {
                LogManager.i(TAG, "❌ 暂无训练数据")
                return Result.success()
            }
            
            // 4. 读取进度
            var currentOffset = prefs.getInt(KEY_OFFSET, 0)
            // 简单统计总行数（实际应用中建议缓存）
            val totalLines = try { dataFile.useLines { it.count() } } catch (e: Exception) { 1000 }
            
            // 如果已经训练完了，从头开始检查新数据或者直接结束
            if (currentOffset >= totalLines) {
                // 这里可以重置或者检查是否有新文件，暂时重置
                // currentOffset = 0 
                LogManager.i(TAG, "✅ 所有数据已训练完毕")
                return Result.success() 
            }
            
            // 5. 设置前台服务通知
            setForeground(createForegroundInfo(currentOffset, totalLines))
            
            val startTime = System.currentTimeMillis()
            var trainedCount = 0
            
            // 6. 批量训练循环
            while (!isStopped) {
                // 加载一批数据
                val batch = learner.loadTrainingDataBatch(currentOffset, BATCH_SIZE)
                
                if (batch.isEmpty()) {
                    if (currentOffset < totalLines) {
                        currentOffset += BATCH_SIZE // 跳过坏块
                        continue
                    }
                    break
                }

                // 训练这批数据
                learner.batchLearn(batch)
                
                // 更新进度
                currentOffset += BATCH_SIZE
                trainedCount += batch.size
                if (currentOffset > totalLines) currentOffset = totalLines

                // 保存进度到 Prefs
                prefs.edit().putInt(KEY_OFFSET, currentOffset).apply()

                // 更新 Notification 和 WorkManager 进度
                setProgress(workDataOf(
                    "progress" to (currentOffset.toFloat() / totalLines),
                    "current" to currentOffset,
                    "total" to totalLines,
                    "stage" to "正在学习模式..."
                ))
                setForeground(createForegroundInfo(currentOffset, totalLines))

                // 防止过热，每批次暂停一下
                delay(200) 
            }
            
            // 7. 记录会话
            val duration = System.currentTimeMillis() - startTime
            TrainingStateManager.recordSession(TrainingSession(
                epochs = 1,
                accuracy = 1.0, // 增量学习默认成功
                duration = duration,
                dataCount = trainedCount,
                success = true
            ))
            
            LogManager.i(TAG, "🎉 训练完成，处理了 $trainedCount 条数据")
            
            // 发送完成通知
            if (trainedCount > 0) {
                sendTrainingNotification(
                    title = "羲和AI进阶完成！✨",
                    message = "新学习了 $trainedCount 个对话模式"
                )
            }
            
            Result.success()
            
        } catch (e: Exception) {
            LogManager.e(TAG, "自动训练任务失败", e)
            TrainingStateManager.recordSession(TrainingSession(
                epochs = 0, accuracy = 0.0, duration = 0, dataCount = 0, success = false
            ))
            Result.retry()
        }
    }
    
    private fun checkDeviceConditions(): Boolean {
        val batteryManager = applicationContext.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val batteryLevel = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        
        if (batteryLevel < MIN_BATTERY_LEVEL) return false
        if (!batteryManager.isCharging) return false
        
        return true
    }
    
    private fun createForegroundInfo(current: Int, total: Int): ForegroundInfo {
        val channelId = "xihe_training_channel"
        val title = "羲和正在学习"
        val progress = if (total > 0) (current * 100 / total) else 0
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "羲和训练服务",
                NotificationManager.IMPORTANCE_LOW
            )
            val notificationManager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(applicationContext, channelId)
            .setContentTitle(title)
            .setContentText("已学习 $progress% ($current/$total)")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setProgress(total, current, false)
            .setOngoing(true)
            .build()

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ForegroundInfo(
                NOTIFICATION_ID, 
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            ForegroundInfo(NOTIFICATION_ID, notification)
        }
    }
    
    private fun sendTrainingNotification(title: String, message: String) {
        val notificationManager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = NotificationCompat.Builder(applicationContext, NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setAutoCancel(true)
            .build()
        notificationManager.notify(NOTIFICATION_ID + 1, notification)
    }
}

/**
 * 🎯 训练状态管理器
 * (保留原有逻辑供UI使用)
 */
object TrainingStateManager {
    private const val TAG = "TrainingStateManager"
    
    private val _trainingHistory = MutableStateFlow<List<TrainingSession>>(emptyList())
    val trainingHistory: StateFlow<List<TrainingSession>> = _trainingHistory
    
    fun recordSession(session: TrainingSession) {
        val currentHistory = _trainingHistory.value.toMutableList()
        currentHistory.add(session)
        if (currentHistory.size > 10) currentHistory.removeAt(0)
        _trainingHistory.value = currentHistory
    }
    
    fun getStatistics(): TrainingStatistics {
        val history = _trainingHistory.value
        if (history.isEmpty()) return TrainingStatistics()
        
        return TrainingStatistics(
            totalSessions = history.size,
            totalEpochs = history.sumOf { it.epochs },
            averageAccuracy = history.mapNotNull { it.accuracy }.average(),
            lastTrainingTime = history.lastOrNull()?.timestamp ?: 0L,
            successRate = if (history.isNotEmpty()) history.count { it.success }.toDouble() / history.size else 0.0
        )
    }
}

data class TrainingSession(
    val timestamp: Long = System.currentTimeMillis(),
    val epochs: Int,
    val accuracy: Double?,
    val duration: Long,
    val dataCount: Int,
    val success: Boolean
)

data class TrainingStatistics(
    val totalSessions: Int = 0,
    val totalEpochs: Int = 0,
    val averageAccuracy: Double = 0.0,
    val lastTrainingTime: Long = 0L,
    val successRate: Double = 0.0
)