package com.example.xihe.training

import android.content.Context
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import kotlin.math.sqrt

/**
 * 🧠 设备端学习器 - 真正可用的本地学习方案
 * 
 * 技术方案说明：
 * ===============
 * TensorFlow Lite 只支持推理，不支持在设备端训练！
 * 
 * 本方案采用实际可行的替代方案：
 * 1. **TF-IDF 向量化** - 将文本转换为数值向量
 * 2. **余弦相似度匹配** - 找到最相似的历史对话
 * 3. **模式学习** - 记住用户的表达习惯和偏好
 * 4. **意图分类** - 基于关键词和模式的规则分类
 * 
 * 这种方案：
 * - ✅ 真正在设备上运行
 * - ✅ 不需要网络连接
 * - ✅ 随着对话增多不断改进
 * - ✅ 保护用户隐私
 */
class OnDeviceLearner private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "OnDeviceLearner"
        private const val MODEL_DIR = "xihe_learner"
        private const val VOCABULARY_FILE = "vocabulary.json"
        private const val PATTERNS_FILE = "learned_patterns.json"
        private const val INTENTS_FILE = "intent_model.json"
        
        @Volatile
        private var instance: OnDeviceLearner? = null
        
        fun getInstance(context: Context): OnDeviceLearner {
            return instance ?: synchronized(this) {
                instance ?: OnDeviceLearner(context.applicationContext).also {
                    instance = it
                }
            }
        }
    }
    
    private val json = Json { 
        prettyPrint = true 
        ignoreUnknownKeys = true
    }
    
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    
    // 模型目录
    private val modelDir: File by lazy {
        File(context.filesDir, MODEL_DIR).apply { if (!exists()) mkdirs() }
    }
    
    // 词汇表 - 词 -> (索引, 文档频率)
    private val vocabulary = mutableMapOf<String, VocabEntry>()
    
    // 学习到的模式
    private val learnedPatterns = mutableListOf<LearnedPattern>()
    
    // 意图模型
    private val intentModel = IntentModel()
    
    // 🆕 脚本索引库
    private val scriptIndex = mutableListOf<ScriptIndexEntry>()
    
    // 训练数据缓存
    private val trainingCache = mutableListOf<TrainingPair>()
    
    private var isInitialized = false
    private var isLearning = false
    
    // ==================== 初始化 ====================
    
    /**
     * 初始化学习器
     */
    suspend fun initialize(): Boolean = withContext(Dispatchers.IO) {
        if (isInitialized) return@withContext true
        
        try {
            LogManager.i(TAG, "初始化设备端学习器...")
            
            // 加载词汇表
            loadVocabulary()
            
            // 加载学习模式
            loadPatterns()
            
            // 加载意图模型
            loadIntentModel()
            
            isInitialized = true
            LogManager.i(TAG, "学习器初始化完成 (词汇: ${vocabulary.size}, 模式: ${learnedPatterns.size})")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "初始化失败", e)
            false
        }
    }

    // ==================== 📜 脚本学习与检索 ====================

    /**
     * 🧠 学习脚本库
     * 将脚本的描述和关键词转化为向量索引
     */
    fun learnScripts(scripts: List<com.example.xihe.automation.script.SmartScript>) {
        scriptIndex.clear()
        
        for (script in scripts) {
            // 构建脚本的语义文本 = 名称 + 描述 + 关键词
            val semanticText = "${script.metadata.name} ${script.metadata.description} ${script.metadata.keywords.joinToString(" ")}"
            
            // 更新词汇表以包含脚本中的新词
            updateVocabulary(semanticText)
            
            // 计算向量
            val vector = computeTfIdfVector(semanticText)
            
            scriptIndex.add(ScriptIndexEntry(
                scriptId = script.id,
                vector = vector,
                keywords = script.metadata.keywords
            ))
        }
        
        LogManager.i(TAG, "脚本库学习完成: 已索引 ${scriptIndex.size} 个脚本")
    }

    /**
     * 🔍 寻找最佳匹配脚本
     */
    fun findBestScript(query: String, threshold: Float = 0.3f): com.example.xihe.automation.script.SmartScript? {
        if (scriptIndex.isEmpty()) return null
        
        val queryVector = computeTfIdfVector(query)
        val queryTokens = tokenize(query.lowercase())
        
        // 1. 计算相似度
        val matches = scriptIndex.map { entry ->
            val similarity = cosineSimilarity(queryVector, entry.vector)
            // 关键词加权
            val keywordMatchCount = entry.keywords.count { it.lowercase() in queryTokens }
            val finalScore = similarity + (keywordMatchCount * 0.1f)
            
            entry to finalScore
        }
        
        // 2. 找到最高分
        val bestMatch = matches.maxByOrNull { it.second }
        
        if (bestMatch != null && bestMatch.second >= threshold) {
            return com.example.xihe.automation.script.SmartScriptManager.getScript(bestMatch.first.scriptId)
        }
        
        return null
    }
    
    // ==================== 学习训练 ====================
    
    /**
     * 开始学习（基于对话数据）
     */
    suspend fun startLearning(
        onProgress: (TrainingProgress) -> Unit
    ): TrainingResult = withContext(Dispatchers.Default) {
        if (isLearning) {
            return@withContext TrainingResult.AlreadyRunning
        }
        
        try {
            isLearning = true
            
            if (!isInitialized) {
                initialize()
            }
            
            LogManager.i(TAG, "开始学习...")
            
            // 1. 加载训练数据
            onProgress(TrainingProgress(stage = "加载数据", progress = 0.1f))
            val trainingData = loadTrainingData()
            
            if (trainingData.size < 10) {
                LogManager.w(TAG, "数据不足: ${trainingData.size} 条")
                return@withContext TrainingResult.InsufficientData
            }
            
            LogManager.i(TAG, "加载 ${trainingData.size} 条训练数据")
            
            // 2. 构建词汇表
            onProgress(TrainingProgress(stage = "构建词汇表", progress = 0.2f))
            buildVocabulary(trainingData)
            
            // 3. 学习意图模式
            onProgress(TrainingProgress(stage = "学习意图", progress = 0.4f))
            learnIntentPatterns(trainingData)
            
            // 4. 学习回复模式
            onProgress(TrainingProgress(stage = "学习模式", progress = 0.6f))
            learnResponsePatterns(trainingData)
            
            // 5. 计算TF-IDF向量
            onProgress(TrainingProgress(stage = "计算向量", progress = 0.8f))
            computeTfIdfVectors(trainingData)
            
            // 6. 保存模型
            onProgress(TrainingProgress(stage = "保存模型", progress = 0.9f))
            saveModel()
            
            // 7. 评估
            val accuracy = evaluateModel(trainingData)
            
            onProgress(TrainingProgress(stage = "完成", progress = 1.0f))
            
            LogManager.i(TAG, "学习完成！准确率: ${(accuracy * 100).toInt()}%")
            
            TrainingResult.Success(
                epochs = 1,
                averageLoss = 1.0 - accuracy,
                accuracy = accuracy,
                modelPath = modelDir.absolutePath
            )
            
        } catch (e: Exception) {
            LogManager.e(TAG, "学习失败", e)
            TrainingResult.Failed(e.message ?: "未知错误")
        } finally {
            isLearning = false
        }
    }
    
    // ==================== 增量/批量训练 ====================

    /**
     * 批量学习（用于后台训练）
     */
    suspend fun batchLearn(data: List<TrainingPair>) = withContext(Dispatchers.Default) {
        if (data.isEmpty()) return@withContext
        
        // 1. 批量更新词汇表
        for (pair in data) {
            updateVocabulary(pair.input)
            updateVocabulary(pair.output)
        }
        
        // 2. 批量添加模式
        val newPatterns = data.map { pair ->
            LearnedPattern(
                userInput = pair.input,
                aiResponse = pair.output,
                inputVector = computeTfIdfVector(pair.input),
                intent = classifyIntent(pair.input),
                learnedAt = System.currentTimeMillis()
            )
        }
        
        synchronized(learnedPatterns) {
            learnedPatterns.addAll(newPatterns)
            // 保持模式库大小合理 (例如只保留最近的 5000 条)
            if (learnedPatterns.size > 5000) {
                // 删除旧的，保留新的
                val removeCount = learnedPatterns.size - 5000
                if (removeCount > 0) {
                    // 使用 subList 删除效率更高
                    learnedPatterns.subList(0, removeCount).clear()
                }
            }
        }
        
        // 3. 更新意图统计 (简单增量更新)
        for (pair in data) {
            val intent = classifyIntent(pair.input)
            val tokens = tokenize(pair.input.lowercase())
            val currentKeywords = intentModel.intentKeywords.getOrPut(intent) { mutableListOf() }
            
            // 将新关键词加入 (去重)
            for (token in tokens) {
                if (token !in currentKeywords && currentKeywords.size < 50) {
                    currentKeywords.add(token)
                }
            }
        }
        
        // 4. 自动保存
        saveModel()
    }

    /**
     * 分页加载训练数据（支持断点续传）
     */
    suspend fun loadTrainingDataBatch(offset: Int, limit: Int): List<TrainingPair> = withContext(Dispatchers.IO) {
        val dataFile = File(context.filesDir, "xihe_conversations/training_data.jsonl")
        if (!dataFile.exists()) return@withContext emptyList()
        
        val pairs = mutableListOf<TrainingPair>()
        var currentLine = 0
        var addedCount = 0
        
        try {
            dataFile.useLines { lines ->
                for (line in lines) {
                    if (currentLine >= offset) {
                        if (addedCount >= limit) break
                        
                        if (line.isNotBlank()) {
                            try {
                                val userMatch = """"role"\s*:\s*"user".*?"content"\s*:\s*"([^"]+)"""".toRegex()
                                val assistantMatch = """"role"\s*:\s*"assistant".*?"content"\s*:\s*"([^"]+)"""".toRegex()
                                
                                val userContent = userMatch.find(line)?.groupValues?.get(1)
                                val assistantContent = assistantMatch.find(line)?.groupValues?.get(1)
                                
                                if (userContent != null && assistantContent != null) {
                                    pairs.add(TrainingPair(userContent, assistantContent))
                                    addedCount++
                                }
                            } catch (e: Exception) {
                                // 忽略解析错误
                            }
                        }
                    }
                    currentLine++
                }
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "批量加载数据失败", e)
        }
        
        pairs
    }

    // ==================== 推理预测 ====================
    
    /**
     * 预测回复（基于相似度匹配）
     */
    suspend fun predict(input: String): PredictionResult = withContext(Dispatchers.Default) {
        if (!isInitialized) {
            initialize()
        }
        
        // 1. 分析意图
        val intent = classifyIntent(input)
        
        // 2. 查找相似对话
        val similar = findSimilarPatterns(input, topK = 3)
        
        // 3. 生成建议回复
        val suggestedResponse = if (similar.isNotEmpty()) {
            similar.first().response
        } else {
            null
        }
        
        PredictionResult(
            intent = intent,
            confidence = similar.firstOrNull()?.similarity ?: 0.5f,
            suggestedResponse = suggestedResponse,
            similarPatterns = similar
        )
    }
    
    /**
     * 分类意图
     */
    fun classifyIntent(input: String): UserIntent {
        val normalized = input.lowercase()
        val tokens = tokenize(normalized)
        
        // 基于关键词和模式的规则分类
        return when {
            // 发送消息
            tokens.any { it in listOf("发消息", "发信息", "告诉", "通知") } ||
            normalized.contains("发消息") || normalized.contains("发给") -> 
                UserIntent.SEND_MESSAGE
            
            // 打开应用
            tokens.any { it in listOf("打开", "启动", "运行", "开启") } ->
                UserIntent.OPEN_APP
            
            // 搜索
            tokens.any { it in listOf("搜索", "搜一下", "查一下", "查询", "找") } ->
                UserIntent.SEARCH
            
            // 设置提醒
            tokens.any { it in listOf("提醒", "闹钟", "定时", "记得") } ->
                UserIntent.SET_REMINDER
            
            // 播放媒体
            tokens.any { it in listOf("播放", "放", "听", "看") } &&
            tokens.any { it in listOf("歌", "音乐", "视频", "电影") } ->
                UserIntent.PLAY_MEDIA
            
            // 查询信息
            normalized.contains("天气") || normalized.contains("时间") ||
            normalized.contains("日期") || normalized.contains("多少") ->
                UserIntent.QUERY_INFO
            
            // 问候
            tokens.any { it in listOf("你好", "早上好", "晚上好", "嗨", "hello") } ->
                UserIntent.GREETING
            
            // 闲聊
            else -> UserIntent.CHAT
        }
    }
    
    /**
     * 查找相似模式
     */
    fun findSimilarPatterns(input: String, topK: Int = 5): List<SimilarPattern> {
        if (learnedPatterns.isEmpty()) return emptyList()
        
        val inputVector = computeTfIdfVector(input)
        
        return learnedPatterns
            .map { pattern ->
                val similarity = cosineSimilarity(inputVector, pattern.inputVector)
                SimilarPattern(
                    input = pattern.userInput,
                    response = pattern.aiResponse,
                    similarity = similarity
                )
            }
            .filter { it.similarity > 0.1f }
            .sortedByDescending { it.similarity }
            .take(topK)
    }
    
    // ==================== 在线学习 ====================
    
    /**
     * 从新对话学习（增量学习）
     */
    fun learnFromConversation(userInput: String, aiResponse: String) {
        scope.launch {
            try {
                // 1. 更新词汇表
                updateVocabulary(userInput)
                updateVocabulary(aiResponse)
                
                // 2. 添加到模式库
                val inputVector = computeTfIdfVector(userInput)
                val pattern = LearnedPattern(
                    userInput = userInput,
                    aiResponse = aiResponse,
                    inputVector = inputVector,
                    intent = classifyIntent(userInput),
                    learnedAt = System.currentTimeMillis()
                )
                
                learnedPatterns.add(pattern)
                
                // 3. 限制模式数量（保留最近1000条）
                while (learnedPatterns.size > 1000) {
                    learnedPatterns.removeAt(0)
                }
                
                // 4. 定期保存
                if (learnedPatterns.size % 10 == 0) {
                    saveModel()
                }
                
                LogManager.i(TAG, "学习新对话 (模式库: ${learnedPatterns.size})")
            } catch (e: Exception) {
                LogManager.e(TAG, "增量学习失败", e)
            }
        }
    }
    
    // ==================== TF-IDF 计算 ====================
    
    /**
     * 分词
     */
    private fun tokenize(text: String): List<String> {
        // 中文按字符分词，英文按空格分词
        val tokens = mutableListOf<String>()
        val sb = StringBuilder()
        
        for (char in text) {
            when {
                char.isWhitespace() -> {
                    if (sb.isNotEmpty()) {
                        tokens.add(sb.toString())
                        sb.clear()
                    }
                }
                char.code in 0x4E00..0x9FFF -> {
                    // 中文字符
                    if (sb.isNotEmpty()) {
                        tokens.add(sb.toString())
                        sb.clear()
                    }
                    tokens.add(char.toString())
                }
                else -> {
                    sb.append(char)
                }
            }
        }
        
        if (sb.isNotEmpty()) {
            tokens.add(sb.toString())
        }
        
        return tokens.filter { it.isNotBlank() }
    }
    
    /**
     * 计算 TF-IDF 向量
     */
    private fun computeTfIdfVector(text: String): Map<String, Float> {
        val tokens = tokenize(text.lowercase())
        val tf = tokens.groupingBy { it }.eachCount()
        val maxTf = tf.values.maxOrNull() ?: 1
        
        val vector = mutableMapOf<String, Float>()
        val totalDocs = learnedPatterns.size.coerceAtLeast(1)
        
        for ((term, count) in tf) {
            val termFreq = 0.5f + 0.5f * (count.toFloat() / maxTf)
            val docFreq = vocabulary[term]?.docFreq ?: 1
            val idf = kotlin.math.ln((totalDocs + 1).toFloat() / (docFreq + 1)) + 1
            vector[term] = termFreq * idf
        }
        
        return vector
    }
    
    /**
     * 余弦相似度
     */
    private fun cosineSimilarity(v1: Map<String, Float>, v2: Map<String, Float>): Float {
        val commonKeys = v1.keys.intersect(v2.keys)
        if (commonKeys.isEmpty()) return 0f
        
        var dotProduct = 0f
        var norm1 = 0f
        var norm2 = 0f
        
        for (key in commonKeys) {
            dotProduct += (v1[key] ?: 0f) * (v2[key] ?: 0f)
        }
        
        for (value in v1.values) {
            norm1 += value * value
        }
        
        for (value in v2.values) {
            norm2 += value * value
        }
        
        val denominator = sqrt(norm1) * sqrt(norm2)
        return if (denominator > 0) dotProduct / denominator else 0f
    }
    
    // ==================== 模型构建 ====================
    
    /**
     * 构建词汇表
     */
    private fun buildVocabulary(data: List<TrainingPair>) {
        vocabulary.clear()
        var index = 0
        
        for (pair in data) {
            val tokens = tokenize(pair.input.lowercase()) + tokenize(pair.output.lowercase())
            for (token in tokens.distinct()) {
                if (token !in vocabulary) {
                    vocabulary[token] = VocabEntry(index++, 1)
                } else {
                    vocabulary[token]?.let { entry ->
                        vocabulary[token] = entry.copy(docFreq = entry.docFreq + 1)
                    }
                }
            }
        }
        
        LogManager.i(TAG, "词汇表构建完成: ${vocabulary.size} 词")
    }
    
    /**
     * 学习意图模式
     */
    private fun learnIntentPatterns(data: List<TrainingPair>) {
        // 统计每种意图的关键词
        val intentKeywords = mutableMapOf<UserIntent, MutableMap<String, Int>>()
        
        for (pair in data) {
            val intent = classifyIntent(pair.input)
            val tokens = tokenize(pair.input.lowercase())
            
            val keywords = intentKeywords.getOrPut(intent) { mutableMapOf() }
            for (token in tokens) {
                keywords[token] = (keywords[token] ?: 0) + 1
            }
        }
        
        // 更新意图模型
        intentModel.intentKeywords.clear()
        for ((intent, keywords) in intentKeywords) {
            // 取每种意图top 20关键词
            val topKeywords = keywords.entries
                .sortedByDescending { it.value }
                .take(20)
                .map { it.key }
            intentModel.intentKeywords[intent] = topKeywords.toMutableList()
        }
        
        LogManager.i(TAG, "意图模式学习完成: ${intentModel.intentKeywords.size} 种意图")
    }
    
    /**
     * 学习回复模式
     */
    private fun learnResponsePatterns(data: List<TrainingPair>) {
        learnedPatterns.clear()
        
        for (pair in data) {
            val inputVector = computeTfIdfVector(pair.input)
            val pattern = LearnedPattern(
                userInput = pair.input,
                aiResponse = pair.output,
                inputVector = inputVector,
                intent = classifyIntent(pair.input),
                learnedAt = System.currentTimeMillis()
            )
            learnedPatterns.add(pattern)
        }
        
        LogManager.i(TAG, "回复模式学习完成: ${learnedPatterns.size} 条")
    }
    
    /**
     * 计算所有训练数据的TF-IDF向量
     */
    private fun computeTfIdfVectors(data: List<TrainingPair>) {
        // 向量已在 learnResponsePatterns 中计算
        LogManager.i(TAG, "TF-IDF向量计算完成")
    }
    
    /**
     * 评估模型
     */
    private fun evaluateModel(data: List<TrainingPair>): Double {
        if (data.size < 10) return 0.0
        
        val testSize = minOf(50, data.size / 5)
        val testData = data.shuffled().take(testSize)
        
        var correct = 0
        for (pair in testData) {
            val similar = findSimilarPatterns(pair.input, topK = 1)
            if (similar.isNotEmpty() && similar.first().similarity > 0.5f) {
                correct++
            }
        }
        
        return correct.toDouble() / testSize
    }
    
    // ==================== 持久化 ====================
    
    /**
     * 保存模型
     */
    private suspend fun saveModel() = withContext(Dispatchers.IO) {
        try {
            // 保存词汇表
            val vocabFile = File(modelDir, VOCABULARY_FILE)
            val vocabData = vocabulary.map { (word, entry) ->
                VocabSaveEntry(word, entry.index, entry.docFreq)
            }
            vocabFile.writeText(json.encodeToString(vocabData))
            
            // 保存模式（只保存最近500条以节省空间）
            val patternsFile = File(modelDir, PATTERNS_FILE)
            val patternsToSave = learnedPatterns.takeLast(500).map { pattern ->
                PatternSaveEntry(
                    userInput = pattern.userInput,
                    aiResponse = pattern.aiResponse,
                    intent = pattern.intent.name,
                    learnedAt = pattern.learnedAt
                )
            }
            patternsFile.writeText(json.encodeToString(patternsToSave))
            
            // 保存意图模型
            val intentsFile = File(modelDir, INTENTS_FILE)
            val intentsData = intentModel.intentKeywords.map { (intent, keywords) ->
                IntentSaveEntry(intent.name, keywords)
            }
            intentsFile.writeText(json.encodeToString(intentsData))
            
            LogManager.i(TAG, "模型保存完成")
        } catch (e: Exception) {
            LogManager.e(TAG, "保存模型失败", e)
        }
    }
    
    private fun loadVocabulary() {
        try {
            val vocabFile = File(modelDir, VOCABULARY_FILE)
            if (vocabFile.exists()) {
                val entries = json.decodeFromString<List<VocabSaveEntry>>(vocabFile.readText())
                vocabulary.clear()
                for (entry in entries) {
                    vocabulary[entry.word] = VocabEntry(entry.index, entry.docFreq)
                }
            }
        } catch (e: Exception) {
            LogManager.w(TAG, "加载词汇表失败", e)
        }
    }
    
    private fun loadPatterns() {
        try {
            val patternsFile = File(modelDir, PATTERNS_FILE)
            if (patternsFile.exists()) {
                val entries = json.decodeFromString<List<PatternSaveEntry>>(patternsFile.readText())
                learnedPatterns.clear()
                for (entry in entries) {
                    val pattern = LearnedPattern(
                        userInput = entry.userInput,
                        aiResponse = entry.aiResponse,
                        inputVector = computeTfIdfVector(entry.userInput),
                        intent = try { UserIntent.valueOf(entry.intent) } catch (e: Exception) { UserIntent.CHAT },
                        learnedAt = entry.learnedAt
                    )
                    learnedPatterns.add(pattern)
                }
            }
        } catch (e: Exception) {
            LogManager.w(TAG, "加载模式失败", e)
        }
    }
    
    private fun loadIntentModel() {
        try {
            val intentsFile = File(modelDir, INTENTS_FILE)
            if (intentsFile.exists()) {
                val entries = json.decodeFromString<List<IntentSaveEntry>>(intentsFile.readText())
                intentModel.intentKeywords.clear()
                for (entry in entries) {
                    val intent = try { UserIntent.valueOf(entry.intent) } catch (e: Exception) { continue }
                    intentModel.intentKeywords[intent] = entry.keywords.toMutableList()
                }
            }
        } catch (e: Exception) {
            LogManager.w(TAG, "加载意图模型失败", e)
        }
    }
    
    private fun updateVocabulary(text: String) {
        val tokens = tokenize(text.lowercase())
        for (token in tokens.distinct()) {
            if (token !in vocabulary) {
                vocabulary[token] = VocabEntry(vocabulary.size, 1)
            } else {
                vocabulary[token]?.let { entry ->
                    vocabulary[token] = entry.copy(docFreq = entry.docFreq + 1)
                }
            }
        }
    }
    
    private suspend fun loadTrainingData(): List<TrainingPair> = withContext(Dispatchers.IO) {
        try {
            val dataFile = File(context.filesDir, "xihe_conversations/training_data.jsonl")
            if (!dataFile.exists()) return@withContext emptyList()
            
            val pairs = mutableListOf<TrainingPair>()
            dataFile.readLines().forEach { line ->
                if (line.isNotBlank()) {
                    try {
                        // 简单解析 JSONL
                        val userMatch = """"role"\s*:\s*"user".*?"content"\s*:\s*"([^"]+)"""".toRegex()
                        val assistantMatch = """"role"\s*:\s*"assistant".*?"content"\s*:\s*"([^"]+)"""".toRegex()
                        
                        val userContent = userMatch.find(line)?.groupValues?.get(1)
                        val assistantContent = assistantMatch.find(line)?.groupValues?.get(1)
                        
                        if (userContent != null && assistantContent != null) {
                            pairs.add(TrainingPair(userContent, assistantContent))
                        }
                    } catch (e: Exception) {
                        // 忽略解析错误的行
                    }
                }
            }
            pairs
        } catch (e: Exception) {
            LogManager.e(TAG, "加载训练数据失败", e)
            emptyList()
        }
    }
    
    /**
     * 📊 获取学习统计
     */
    fun getStatistics(): LearnerStatistics {
        return LearnerStatistics(
            vocabularySize = vocabulary.size,
            patternCount = learnedPatterns.size,
            intentCount = intentModel.intentKeywords.size,
            isInitialized = isInitialized,
            isLearning = isLearning
        )
    }
}

// ==================== 数据类 ====================

/**
 * 词汇表条目
 */
data class VocabEntry(
    val index: Int,
    val docFreq: Int
)

/**
 * 学习到的模式
 */
data class LearnedPattern(
    val userInput: String,
    val aiResponse: String,
    val inputVector: Map<String, Float>,
    val intent: UserIntent,
    val learnedAt: Long
)

/**
 * 意图模型
 */
class IntentModel {
    val intentKeywords = mutableMapOf<UserIntent, MutableList<String>>()
}

/**
 * 用户意图
 */
enum class UserIntent {
    SEND_MESSAGE,   // 发送消息
    OPEN_APP,       // 打开应用
    SEARCH,         // 搜索
    SET_REMINDER,   // 设置提醒
    PLAY_MEDIA,     // 播放媒体
    QUERY_INFO,     // 查询信息
    GREETING,       // 问候
    CHAT            // 闲聊
}

/**
 * 预测结果
 */
data class PredictionResult(
    val intent: UserIntent,
    val confidence: Float,
    val suggestedResponse: String?,
    val similarPatterns: List<SimilarPattern>
)

/**
 * 相似模式
 */
data class SimilarPattern(
    val input: String,
    val response: String,
    val similarity: Float
)

/**
 * 训练对
 */
data class TrainingPair(
    val input: String,
    val output: String
)

/**
 * 学习器统计
 */
data class LearnerStatistics(
    val vocabularySize: Int,
    val patternCount: Int,
    val intentCount: Int,
    val isInitialized: Boolean,
    val isLearning: Boolean
)

// ==================== 序列化辅助类 ====================

@Serializable
data class VocabSaveEntry(
    val word: String,
    val index: Int,
    val docFreq: Int
)

@Serializable
data class PatternSaveEntry(
    val userInput: String,
    val aiResponse: String,
    val intent: String,
    val learnedAt: Long
)

@Serializable
data class IntentSaveEntry(
    val intent: String,
    val keywords: List<String>
)

/**
 * 脚本索引条目
 */
data class ScriptIndexEntry(
    val scriptId: String,
    val vector: Map<String, Float>,
    val keywords: List<String>
)
