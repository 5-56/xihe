package com.example.xihe.training

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import com.example.xihe.utils.LogManager
import com.example.xihe.data.UserLifeDatabase
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Calendar

/**
 * 🧠 自动训练调度器
 * 
 * 功能：
 * 1. 📊 智能判断训练时机
 * 2. 🔋 电量充足时训练
 * 3. 📅 定时训练（每天凌晨）
 * 4. 📈 数据达到阈值时训练
 * 5. 💤 用户睡觉时训练
 * 6. 🎯 增量训练（只训练新数据）
 * 
 * 训练策略：
 * - 充电 + 电量>50% + 凌晨2-6点 → 深度训练
 * - 充电 + 电量>30% + 任意时间 → 快速训练
 * - 数据增加>1000条 → 增量训练
 * - 用户无操作>30分钟 → 轻量训练
 */
class AutoTrainingScheduler private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "AutoTrainingScheduler"
        
        // 训练条件
        private const val MIN_BATTERY_FOR_DEEP_TRAINING = 50
        private const val MIN_BATTERY_FOR_QUICK_TRAINING = 30
        private const val MIN_NEW_DATA_COUNT = 1000
        private const val IDLE_TIME_MINUTES = 30
        
        // 训练时间段
        private const val DEEP_TRAINING_START_HOUR = 2  // 凌晨2点
        private const val DEEP_TRAINING_END_HOUR = 6    // 早上6点
        
        @Volatile
        private var instance: AutoTrainingScheduler? = null
        
        fun getInstance(context: Context): AutoTrainingScheduler {
            return instance ?: synchronized(this) {
                instance ?: AutoTrainingScheduler(context.applicationContext).also {
                    instance = it
                }
            }
        }
    }
    
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private val database = UserLifeDatabase.getInstance(context)
    
    // 训练器
    private val localTrainer = LocalModelTrainer.getInstance(context)
    private val tfliteTrainer = OptimizedTFLiteTrainer.getInstance(context)
    
    // 🆕 训练保护系统
    private val trainingGuard = MobileTrainingGuard(context)
    
    // 训练状态
    private val _trainingState = MutableStateFlow(TrainingScheduleState.IDLE)
    val trainingState: StateFlow<TrainingScheduleState> = _trainingState
    
    // 调度任务
    private var scheduleJob: Job? = null
    
    // 上次训练时间
    private var lastTrainingTime = 0L
    private var lastDataCount = 0
    
    /**
     * 启动调度器
     */
    fun start() {
        if (_trainingState.value != TrainingScheduleState.IDLE) {
            LogManager.i(TAG, "调度器已在运行中")
            return
        }
        
        LogManager.d(TAG, "启动自动训练调度器...")
        _trainingState.value = TrainingScheduleState.MONITORING
        
        scheduleJob = scope.launch {
            while (isActive) {
                try {
                    // 检查训练条件
                    checkAndScheduleTraining()
                    
                    // 每5分钟检查一次
                    delay(5 * 60 * 1000)
                    
                } catch (e: Exception) {
                    LogManager.e(TAG, "调度错误: ${e.message}", e)
                    delay(60 * 1000) // 出错后1分钟再试
                }
            }
        }
    }
    
    /**
     * 停止调度器
     */
    fun stop() {
        LogManager.d(TAG, "停止调度器...")
        scheduleJob?.cancel()
        _trainingState.value = TrainingScheduleState.IDLE
    }
    
    /**
     * 检查并调度训练
     */
    private suspend fun checkAndScheduleTraining() {
        // 如果正在训练，跳过
        if (_trainingState.value == TrainingScheduleState.TRAINING) {
            LogManager.d(TAG, "正在训练中，跳过本次检查")
            return
        }
        
        val strategy = determineTrainingStrategy()
        
        when (strategy) {
            TrainingStrategy.DEEP_TRAINING -> {
                LogManager.d(TAG, "满足深度训练条件")
                performTraining(TrainingType.DEEP)
            }
            
            TrainingStrategy.QUICK_TRAINING -> {
                LogManager.d(TAG, "满足快速训练条件")
                performTraining(TrainingType.QUICK)
            }
            
            TrainingStrategy.INCREMENTAL_TRAINING -> {
                LogManager.d(TAG, "满足增量训练条件")
                performTraining(TrainingType.INCREMENTAL)
            }
            
            TrainingStrategy.NO_TRAINING -> {
                LogManager.d(TAG, "不满足训练条件")
            }
        }
    }
    
    /**
     * 判断训练策略
     * 新版逻辑：
     * - 夜间(22:00-7:00)或设备空闲时：不要求充电，只检查内存
     * - 内存不足是唯一的硬性阻止条件
     */
    private fun determineTrainingStrategy(): TrainingStrategy {
        val batteryLevel = getBatteryLevel()
        val isCharging = isCharging()
        val currentHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val newDataCount = getNewDataCount()
        val timeSinceLastTraining = System.currentTimeMillis() - lastTrainingTime
        
        // 使用 MobileTrainingGuard 检查训练条件
        val guardResult = trainingGuard.canStartTraining(isManualTrigger = false)
        
        // 如果被阻止（主要是内存不足），不进行训练
        if (guardResult is TrainingGuardResult.Blocked) {
            LogManager.d(TAG, "训练条件不满足: ${guardResult.reason}")
            return TrainingStrategy.NO_TRAINING
        }
        
        // 检查是否为夜间自主训练时段
        val isNightTime = trainingGuard.isNightTrainingTime()
        
        // 1. 深度训练：凌晨时段 + 距离上次训练>24小时
        // 夜间不再要求充电
        if (currentHour in DEEP_TRAINING_START_HOUR until DEEP_TRAINING_END_HOUR &&
            batteryLevel >= 20 &&  // 只要求最低电量
            timeSinceLastTraining > 24 * 60 * 60 * 1000) {
            return TrainingStrategy.DEEP_TRAINING
        }
        
        // 2. 快速训练：夜间或充电时 + 中等电量
        // 夜间时段不要求充电
        if ((isNightTime || isCharging) &&
            batteryLevel >= MIN_BATTERY_FOR_QUICK_TRAINING &&
            timeSinceLastTraining > 12 * 60 * 60 * 1000) {
            return TrainingStrategy.QUICK_TRAINING
        }
        
        // 3. 增量训练：新数据达到阈值 + 夜间或充电
        // 夜间时段不要求充电
        if (newDataCount >= MIN_NEW_DATA_COUNT &&
            (isNightTime || isCharging) &&
            batteryLevel >= 20 &&
            timeSinceLastTraining > 6 * 60 * 60 * 1000) {
            return TrainingStrategy.INCREMENTAL_TRAINING
        }
        
        return TrainingStrategy.NO_TRAINING
    }
    
    /**
     * 执行训练
     */
    private suspend fun performTraining(type: TrainingType) {
        _trainingState.value = TrainingScheduleState.TRAINING
        
        try {
            LogManager.d(TAG, "开始${type.name}训练...")
            
            val startTime = System.currentTimeMillis()
            
            when (type) {
                TrainingType.DEEP -> {
                    // 深度训练：训练所有数据
                    localTrainer.startTraining { progress ->
                        LogManager.d(TAG, "训练进度: ${(progress.progress * 100).toInt()}%")
                    }
                }
                
                TrainingType.QUICK -> {
                    // 快速训练：训练最近数据
                    tfliteTrainer.startTraining(
                        onProgress = { progress ->
                            LogManager.d(TAG, "快速训练进度: ${(progress.progress * 100).toInt()}%")
                        },
                        onMetrics = { metrics ->
                            LogManager.d(TAG, "训练指标: Epoch=${metrics.currentEpoch}/${metrics.totalEpochs}, Loss=${metrics.currentLoss}")
                        }
                    )
                }
                
                TrainingType.INCREMENTAL -> {
                    // 增量训练：只训练新数据
                    tfliteTrainer.startTraining(
                        onProgress = { progress ->
                            LogManager.d(TAG, "增量训练进度: ${(progress.progress * 100).toInt()}%")
                        },
                        onMetrics = { metrics ->
                            LogManager.d(TAG, "训练指标: Epoch=${metrics.currentEpoch}/${metrics.totalEpochs}, Loss=${metrics.currentLoss}")
                        }
                    )
                }
            }
            
            val duration = System.currentTimeMillis() - startTime
            lastTrainingTime = System.currentTimeMillis()
            lastDataCount = database.userLifeDataDao().getTotalCount()
            
            LogManager.d(TAG, "训练完成，耗时: ${duration / 1000}秒")
            
        } catch (e: Exception) {
            LogManager.e(TAG, "训练失败: ${e.message}", e)
        } finally {
            _trainingState.value = TrainingScheduleState.MONITORING
        }
    }
    
    /**
     * 获取电量
     */
    private fun getBatteryLevel(): Int {
        val batteryStatus: Intent? = IntentFilter(Intent.ACTION_BATTERY_CHANGED).let { filter ->
            context.registerReceiver(null, filter)
        }
        
        val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        
        return if (level != -1 && scale != -1) {
            (level * 100 / scale.toFloat()).toInt()
        } else {
            0
        }
    }
    
    /**
     * 是否充电
     */
    private fun isCharging(): Boolean {
        val batteryStatus: Intent? = IntentFilter(Intent.ACTION_BATTERY_CHANGED).let { filter ->
            context.registerReceiver(null, filter)
        }
        
        val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        return status == BatteryManager.BATTERY_STATUS_CHARGING ||
               status == BatteryManager.BATTERY_STATUS_FULL
    }
    
    /**
     * 获取新数据数量
     */
    private fun getNewDataCount(): Int {
        val currentCount = database.userLifeDataDao().getTotalCount()
        return currentCount - lastDataCount
    }
    
    /**
     * 是否应该训练
     */
    fun shouldTrain(): Boolean {
        return determineTrainingStrategy() != TrainingStrategy.NO_TRAINING
    }
    
    /**
     * 手动触发训练
     * 用户手动触发时，只检查内存条件，其他条件放宽
     */
    suspend fun triggerTraining(): Boolean {
        if (_trainingState.value == TrainingScheduleState.TRAINING) {
            LogManager.i(TAG, "已在训练中")
            return false
        }
        
        // 手动触发时使用放宽条件检查
        val guardResult = trainingGuard.canStartTraining(isManualTrigger = true)
        
        if (guardResult is TrainingGuardResult.Blocked) {
            LogManager.i(TAG, "无法开始训练: ${guardResult.reason}")
            return false
        }
        
        LogManager.d(TAG, "手动触发训练（放宽条件模式）")
        performTraining(TrainingType.QUICK)
        return true
    }
    
    /**
     * 🌙 检查是否为夜间自主训练时段
     */
    fun isNightTrainingTime(): Boolean {
        return trainingGuard.isNightTrainingTime()
    }
    
    /**
     * 📊 获取当前训练条件状态
     */
    fun getTrainingConditions(): TrainingConditionsInfo {
        val batteryLevel = getBatteryLevel()
        val isCharging = isCharging()
        val isNightTime = trainingGuard.isNightTrainingTime()
        val guardResult = trainingGuard.canStartTraining(isManualTrigger = false)
        
        return TrainingConditionsInfo(
            batteryLevel = batteryLevel,
            isCharging = isCharging,
            isNightTime = isNightTime,
            canAutoTrain = guardResult !is TrainingGuardResult.Blocked,
            blockReason = if (guardResult is TrainingGuardResult.Blocked) guardResult.reason else null
        )
    }
}

/**
 * 📊 训练条件信息
 */
data class TrainingConditionsInfo(
    val batteryLevel: Int,
    val isCharging: Boolean,
    val isNightTime: Boolean,
    val canAutoTrain: Boolean,
    val blockReason: String?
)

/**
 * 📊 训练调度状态
 */
enum class TrainingScheduleState {
    IDLE,           // 空闲
    MONITORING,     // 监控中
    TRAINING        // 训练中
}

/**
 * 🎯 训练策略
 */
enum class TrainingStrategy {
    DEEP_TRAINING,          // 深度训练
    QUICK_TRAINING,         // 快速训练
    INCREMENTAL_TRAINING,   // 增量训练
    NO_TRAINING             // 不训练
}

/**
 * 🧠 训练类型
 */
enum class TrainingType {
    DEEP,           // 深度训练（全量）
    QUICK,          // 快速训练（最近）
    INCREMENTAL     // 增量训练（新数据）
}

