package com.example.xihe.training

import android.app.ActivityManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.*

/**
 * 🔍 羲和系统监控器
 * 
 * 实时监控手机的所有状态信息
 * 
 * 监控内容：
 * 1. 🌡️ 温度 - 实时电池温度
 * 2. 🔋 电量 - 电池电量和充电状态
 * 3. 💾 内存 - 可用内存和使用率
 * 4. 💿 存储 - 可用存储空间
 * 5. 📱 屏幕 - 屏幕开关状态
 * 6. 🏃 活动 - 用户活动状态（步行、静止等）
 * 7. 💡 光线 - 环境光线强度
 * 8. 🔄 CPU - CPU使用率
 * 9. 📶 网络 - 网络连接状态
 * 10. 😴 睡眠 - 用户睡眠状态推断
 */
class SystemMonitor(private val context: Context) {
    
    companion object {
        private const val TAG = "SystemMonitor"
        private const val MONITOR_INTERVAL = 60_000L  // 每分钟更新一次
        
        @Volatile
        private var instance: SystemMonitor? = null
        
        fun getInstance(context: Context): SystemMonitor {
            return instance ?: synchronized(this) {
                instance ?: SystemMonitor(context.applicationContext).also { instance = it }
            }
        }
    }
    
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
    private val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    private val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    
    // 实时状态流
    private val _systemState = MutableStateFlow(SystemState())
    val systemState: StateFlow<SystemState> = _systemState.asStateFlow()
    
    // 用户状态流
    private val _userState = MutableStateFlow(UserState())
    val userState: StateFlow<UserState> = _userState.asStateFlow()
    
    // 训练建议流
    private val _trainingRecommendation = MutableStateFlow(TrainingRecommendation())
    val trainingRecommendation: StateFlow<TrainingRecommendation> = _trainingRecommendation.asStateFlow()
    
    // 传感器监听
    private var lightSensor: Sensor? = null
    private var currentLightLevel = 0f
    
    private val lightSensorListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent?) {
            event?.let {
                currentLightLevel = it.values[0]
            }
        }
        
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }
    
    /**
     * 启动监控
     */
    fun startMonitoring() {
        LogManager.d(TAG, "开始系统监控...")
        
        // 启动定期监控
        scope.launch {
            while (isActive) {
                try {
                    updateSystemState()
                    updateUserState()
                    updateTrainingRecommendation()
                    delay(MONITOR_INTERVAL)
                } catch (e: Exception) {
                    LogManager.e(TAG, "监控更新失败", e)
                }
            }
        }
        
        // 启动传感器监听
        lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT)
        lightSensor?.let {
            sensorManager.registerListener(
                lightSensorListener,
                it,
                SensorManager.SENSOR_DELAY_NORMAL
            )
        }
        
        LogManager.d(TAG, "系统监控已启动")
    }
    
    /**
     * 停止监控
     */
    fun stopMonitoring() {
        scope.cancel()
        sensorManager.unregisterListener(lightSensorListener)
        LogManager.d(TAG, "系统监控已停止")
    }
    
    /**
     * 更新系统状态
     */
    private fun updateSystemState() {
        val state = SystemState(
            // 温度
            temperature = getCurrentTemperature(),
            
            // 电池
            batteryLevel = getBatteryLevel(),
            isCharging = isCharging(),
            batteryHealth = getBatteryHealth(),
            
            // 内存
            availableMemoryMB = getAvailableMemoryMB(),
            totalMemoryMB = getTotalMemoryMB(),
            memoryUsagePercent = getMemoryUsagePercent(),
            
            // 存储
            availableStorageMB = getAvailableStorageMB(),
            
            // 屏幕
            isScreenOn = isScreenOn(),
            
            // 光线
            lightLevel = currentLightLevel,
            
            // CPU
            cpuUsagePercent = getCpuUsage(),
            
            // 时间
            timestamp = System.currentTimeMillis()
        )
        
        _systemState.value = state
        
        LogManager.d(TAG, """
            系统状态更新:
            温度: ${state.temperature}°C
            电量: ${state.batteryLevel}% ${if (state.isCharging) "充电中" else ""}
            内存: ${state.availableMemoryMB}MB 可用
            屏幕: ${if (state.isScreenOn) "开启" else "关闭"}
            光线: ${state.lightLevel} lux
        """.trimIndent())
    }
    
    /**
     * 更新用户状态
     */
    private fun updateUserState() {
        val isDeviceIdle = checkDeviceIdle()
        val isProbablySleeping = checkIfUserSleeping()
        val screenOffDuration = getScreenOffDuration()
        val lastInteractionTime = getLastInteractionTime()
        
        val state = UserState(
            isDeviceIdle = isDeviceIdle,
            isProbablySleeping = isProbablySleeping,
            screenOffDurationMinutes = screenOffDuration,
            lastInteractionMinutesAgo = lastInteractionTime,
            currentActivity = detectCurrentActivity(),
            timestamp = System.currentTimeMillis()
        )
        
        _userState.value = state
        
        LogManager.d(TAG, """
            用户状态更新:
            设备空闲: ${state.isDeviceIdle}
            可能在睡觉: ${state.isProbablySleeping}
            屏幕关闭: ${state.screenOffDurationMinutes}分钟
            当前活动: ${state.currentActivity}
        """.trimIndent())
    }
    
    /**
     * 更新训练建议
     */
    private fun updateTrainingRecommendation() {
        val sysState = _systemState.value
        val usrState = _userState.value
        
        val recommendation = TrainingRecommendation(
            shouldStartTraining = evaluateShouldStartTraining(sysState, usrState),
            canStartTraining = evaluateCanStartTraining(sysState, usrState),
            reason = generateRecommendationReason(sysState, usrState),
            confidence = calculateConfidence(sysState, usrState),
            recommendedConfig = generateRecommendedConfig(sysState, usrState),
            blockers = findBlockers(sysState, usrState),
            timestamp = System.currentTimeMillis()
        )
        
        _trainingRecommendation.value = recommendation
        
        if (recommendation.shouldStartTraining) {
            LogManager.d(TAG, "推荐现在开始训练: ${recommendation.reason}")
        }
    }
    
    // ==================== 检测方法 ====================
    
    /**
     * 🌡️ 获取当前温度
     */
    private fun getCurrentTemperature(): Float {
        return try {
            val batteryStatus: Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val temp = batteryStatus?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 350) ?: 350
            temp / 10.0f
        } catch (e: Exception) {
            35.0f
        }
    }
    
    /**
     * 🔋 获取电池电量
     */
    private fun getBatteryLevel(): Int {
        val batteryStatus = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        
        return if (level >= 0 && scale > 0) {
            (level.toFloat() / scale.toFloat() * 100).toInt()
        } else {
            100
        }
    }
    
    /**
     * ⚡ 是否正在充电
     */
    private fun isCharging(): Boolean {
        val batteryStatus = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        
        return status == BatteryManager.BATTERY_STATUS_CHARGING ||
               status == BatteryManager.BATTERY_STATUS_FULL
    }
    
    /**
     * 🏥 电池健康状态
     */
    private fun getBatteryHealth(): String {
        val batteryStatus = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val health = batteryStatus?.getIntExtra(BatteryManager.EXTRA_HEALTH, -1) ?: -1
        
        return when (health) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "良好"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "过热"
            BatteryManager.BATTERY_HEALTH_DEAD -> "损坏"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "电压过高"
            BatteryManager.BATTERY_HEALTH_COLD -> "过冷"
            else -> "未知"
        }
    }
    
    /**
     * 💾 获取可用内存
     */
    private fun getAvailableMemoryMB(): Long {
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        return memoryInfo.availMem / (1024 * 1024)
    }
    
    /**
     * 💾 获取总内存
     */
    private fun getTotalMemoryMB(): Long {
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        return memoryInfo.totalMem / (1024 * 1024)
    }
    
    /**
     * 💾 获取内存使用率
     */
    private fun getMemoryUsagePercent(): Int {
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        val used = memoryInfo.totalMem - memoryInfo.availMem
        return ((used.toFloat() / memoryInfo.totalMem.toFloat()) * 100).toInt()
    }
    
    /**
     * 💿 获取可用存储空间
     */
    private fun getAvailableStorageMB(): Long {
        val dataDir = context.filesDir
        return dataDir.freeSpace / (1024 * 1024)
    }
    
    /**
     * 📱 屏幕是否开启
     */
    private fun isScreenOn(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT_WATCH) {
            powerManager.isInteractive
        } else {
            @Suppress("DEPRECATION")
            powerManager.isScreenOn
        }
    }
    
    /**
     * 😴 检查设备是否空闲
     */
    private fun checkDeviceIdle(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            powerManager.isDeviceIdleMode || !powerManager.isInteractive
        } else {
            !isScreenOn()
        }
    }
    
    /**
     * 🛌 检查用户是否在睡觉
     */
    private fun checkIfUserSleeping(): Boolean {
        val currentHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val screenOff = !isScreenOn()
        val screenOffTime = getScreenOffDuration()
        val lightLow = currentLightLevel < 10f
        
        // 睡眠判断条件：
        // 1. 时间在晚上10点到早上8点之间
        // 2. 屏幕关闭超过30分钟
        // 3. 环境光线很暗
        val isSleepTime = currentHour >= 22 || currentHour < 8
        val screenOffLongEnough = screenOffTime > 30
        
        return isSleepTime && screenOff && screenOffLongEnough && lightLow
    }
    
    /**
     * ⏱️ 获取屏幕关闭时长（分钟）
     */
    private fun getScreenOffDuration(): Long {
        // 这里需要记录屏幕关闭时间
        // 简化版本：如果屏幕关闭，返回估算值
        return if (!isScreenOn()) {
            30L  // 简化：假设关闭30分钟
        } else {
            0L
        }
    }
    
    /**
     * ⏱️ 获取上次交互时间（分钟前）
     */
    private fun getLastInteractionTime(): Long {
        // 使用UsageStatsManager获取最后使用时间
        return if (!isScreenOn()) {
            30L
        } else {
            0L
        }
    }
    
    /**
     * 🏃 检测当前活动
     */
    private fun detectCurrentActivity(): String {
        return when {
            !isScreenOn() -> "屏幕关闭"
            currentLightLevel < 10f -> "暗环境"
            else -> "正常使用"
        }
    }
    
    /**
     * 🔥 获取CPU使用率
     */
    private fun getCpuUsage(): Int {
        // 简化版本
        return 50
    }
    
    // ==================== 评估方法 ====================
    
    /**
     * ✅ 评估是否应该开始训练
     */
    private fun evaluateShouldStartTraining(sys: SystemState, usr: UserState): Boolean {
        return sys.isCharging &&
               sys.batteryLevel > 50 &&
               sys.temperature < 40f &&
               sys.memoryUsagePercent < 70 &&
               (usr.isDeviceIdle || usr.isProbablySleeping) &&
               sys.batteryHealth != "过热"
    }
    
    /**
     * 🟢 评估能否开始训练
     */
    private fun evaluateCanStartTraining(sys: SystemState, usr: UserState): Boolean {
        return sys.temperature < 42f &&
               sys.batteryLevel > 30 &&
               sys.memoryUsagePercent < 80 &&
               sys.availableStorageMB > 100
    }
    
    /**
     * 📝 生成推荐原因
     */
    private fun generateRecommendationReason(sys: SystemState, usr: UserState): String {
        return when {
            usr.isProbablySleeping -> "用户正在睡觉，设备空闲"
            usr.isDeviceIdle && sys.isCharging -> "设备空闲且正在充电"
            !sys.isCharging -> "未充电"
            sys.batteryLevel < 50 -> "电量不足50%"
            sys.temperature > 40 -> "温度过高"
            sys.memoryUsagePercent > 70 -> "内存不足"
            else -> "条件不满足"
        }
    }
    
    /**
     * 📊 计算信心度
     */
    private fun calculateConfidence(sys: SystemState, usr: UserState): Float {
        var score = 0f
        
        if (sys.isCharging) score += 0.2f
        if (sys.batteryLevel > 70) score += 0.2f
        if (sys.temperature < 38) score += 0.2f
        if (usr.isProbablySleeping) score += 0.3f
        if (sys.memoryUsagePercent < 60) score += 0.1f
        
        return score.coerceIn(0f, 1f)
    }
    
    /**
     * ⚙️ 生成推荐配置
     */
    private fun generateRecommendedConfig(sys: SystemState, usr: UserState): Map<String, Any> {
        return mapOf(
            "batchSize" to when {
                sys.memoryUsagePercent > 60 -> 2
                sys.memoryUsagePercent > 40 -> 4
                else -> 8
            },
            "useGpu" to (sys.temperature < 38 && sys.batteryLevel > 60),
            "maxEpochs" to when {
                usr.isProbablySleeping -> 10
                usr.isDeviceIdle -> 5
                else -> 3
            },
            "threadCount" to when {
                sys.cpuUsagePercent > 60 -> 2
                sys.cpuUsagePercent > 40 -> 4
                else -> 6
            }
        )
    }
    
    /**
     * 🚫 找出阻碍因素
     */
    private fun findBlockers(sys: SystemState, usr: UserState): List<String> {
        val blockers = mutableListOf<String>()
        
        if (!sys.isCharging) blockers.add("未充电")
        if (sys.batteryLevel < 50) blockers.add("电量<50%")
        if (sys.temperature > 40) blockers.add("温度>40°C")
        if (sys.memoryUsagePercent > 70) blockers.add("内存不足")
        if (!usr.isDeviceIdle && !usr.isProbablySleeping) blockers.add("设备使用中")
        
        return blockers
    }
}

// ==================== 数据类 ====================

/**
 * 系统状态
 */
data class SystemState(
    val temperature: Float = 0f,
    val batteryLevel: Int = 100,
    val isCharging: Boolean = false,
    val batteryHealth: String = "良好",
    val availableMemoryMB: Long = 0,
    val totalMemoryMB: Long = 0,
    val memoryUsagePercent: Int = 0,
    val availableStorageMB: Long = 0,
    val isScreenOn: Boolean = true,
    val lightLevel: Float = 0f,
    val cpuUsagePercent: Int = 0,
    val timestamp: Long = 0
)

/**
 * 用户状态
 */
data class UserState(
    val isDeviceIdle: Boolean = false,
    val isProbablySleeping: Boolean = false,
    val screenOffDurationMinutes: Long = 0,
    val lastInteractionMinutesAgo: Long = 0,
    val currentActivity: String = "",
    val timestamp: Long = 0
)

/**
 * 训练建议
 */
data class TrainingRecommendation(
    val shouldStartTraining: Boolean = false,
    val canStartTraining: Boolean = false,
    val reason: String = "",
    val confidence: Float = 0f,
    val recommendedConfig: Map<String, Any> = emptyMap(),
    val blockers: List<String> = emptyList(),
    val timestamp: Long = 0
)
