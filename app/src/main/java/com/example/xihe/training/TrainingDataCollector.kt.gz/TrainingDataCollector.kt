package com.example.xihe.training

import android.content.Context
import android.view.accessibility.AccessibilityNodeInfo
import com.example.xihe.utils.LogManager
import com.example.xihe.automation.*
import kotlinx.coroutines.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/**
 * 🎓 羲和模型训练数据收集器
 * 
 * 收集执行过程中的所有数据用于模型训练：
 * 1. 用户指令 → 意图识别数据
 * 2. 界面状态 → 动作选择数据
 * 3. 执行结果 → 反馈学习数据
 * 4. 失败恢复 → 自适应策略数据
 */
class TrainingDataCollector(private val context: Context) {
    
    companion object {
        private const val TAG = "TrainingData"
        private const val DATA_DIR = "xihe_training_data"
        private const val MAX_SAMPLES_PER_FILE = 1000
        
        @Volatile
        private var instance: TrainingDataCollector? = null
        
        fun getInstance(context: Context): TrainingDataCollector {
            return instance ?: synchronized(this) {
                instance ?: TrainingDataCollector(context.applicationContext).also { instance = it }
            }
        }
    }
    
    private val json = Json { 
        prettyPrint = true 
        ignoreUnknownKeys = true
        encodeDefaults = true
    }
    
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val timestampFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault())
    
    // 当前会话数据
    private var currentSession: DataCollectionSession? = null
    private val pendingSamples = mutableListOf<TrainingSample>()
    
    // 数据统计
    private var totalSamplesCollected = 0L
    private var totalSessionsCompleted = 0L
    
    /**
     * 📝 开始新的训练数据收集会话
     */
    fun startSession(userCommand: String): String {
        val sessionId = UUID.randomUUID().toString()
        currentSession = DataCollectionSession(
            sessionId = sessionId,
            startTime = System.currentTimeMillis(),
            userCommand = userCommand,
            samples = mutableListOf()
        )
        
        LogManager.d(TAG, "📝 开始训练数据收集会话: $sessionId")
        return sessionId
    }
    
    /**
     * 🎯 记录意图识别数据
     */
    fun recordIntentRecognition(
        userCommand: String,
        recognizedIntent: IntentType,
        intentDescription: String,
        targetApp: String,
        parameters: Map<String, String>,
        confidence: Float = 1.0f,
        isCorrect: Boolean = true
    ) {
        val sample = TrainingSample(
            id = generateSampleId(),
            type = SampleType.INTENT_RECOGNITION,
            timestamp = System.currentTimeMillis(),
            input = IntentInput(
                userCommand = userCommand,
                context = getCurrentContext()
            ),
            output = IntentOutput(
                intentType = recognizedIntent.name,
                description = intentDescription,
                app = targetApp,
                parameters = parameters
            ),
            metadata = SampleMetadata(
                confidence = confidence,
                isCorrect = isCorrect,
                sessionId = currentSession?.sessionId
            )
        )
        
        addSample(sample)
        LogManager.d(TAG, "🎯 记录意图识别: $recognizedIntent (正确: $isCorrect)")
    }
    
    /**
     * 📱 记录界面状态和动作选择
     */
    fun recordActionSelection(
        screenState: ScreenState,
        selectedAction: String,
        actionTarget: String?,
        actionParameters: Map<String, String>,
        alternativeActions: List<String> = emptyList(),
        reasoning: String = ""
    ) {
        val sample = TrainingSample(
            id = generateSampleId(),
            type = SampleType.ACTION_SELECTION,
            timestamp = System.currentTimeMillis(),
            input = ActionInput(
                screenState = screenState,
                taskContext = currentSession?.let {
                    TaskContextData(
                        command = it.userCommand,
                        currentStep = it.currentStepIndex,
                        totalSteps = it.totalSteps
                    )
                }
            ),
            output = ActionOutput(
                selectedAction = selectedAction,
                target = actionTarget,
                parameters = actionParameters,
                alternatives = alternativeActions,
                reasoning = reasoning
            ),
            metadata = SampleMetadata(
                sessionId = currentSession?.sessionId
            )
        )
        
        addSample(sample)
        LogManager.d(TAG, "📱 记录动作选择: $selectedAction -> $actionTarget")
    }
    
    /**
     * ✅ 记录执行结果
     */
    fun recordExecutionResult(
        action: String,
        target: String?,
        success: Boolean,
        resultMessage: String,
        executionTimeMs: Long,
        screenBefore: ScreenState? = null,
        screenAfter: ScreenState? = null
    ) {
        val sample = TrainingSample(
            id = generateSampleId(),
            type = SampleType.EXECUTION_RESULT,
            timestamp = System.currentTimeMillis(),
            input = ExecutionInput(
                action = action,
                target = target,
                screenBefore = screenBefore
            ),
            output = ExecutionOutput(
                success = success,
                message = resultMessage,
                executionTimeMs = executionTimeMs,
                screenAfter = screenAfter
            ),
            metadata = SampleMetadata(
                sessionId = currentSession?.sessionId
            )
        )
        
        addSample(sample)
        
        // 更新会话统计
        currentSession?.let {
            if (success) it.successfulActions++ else it.failedActions++
        }
        
        LogManager.d(TAG, "✅ 记录执行结果: $action - ${if (success) "成功" else "失败"}")
    }
    
    /**
     * 🔄 记录失败恢复策略
     */
    fun recordRecoveryStrategy(
        failedAction: String,
        failureReason: String,
        screenState: ScreenState,
        recoveryStrategy: String,
        recoveryActions: List<String>,
        recoverySuccess: Boolean
    ) {
        val sample = TrainingSample(
            id = generateSampleId(),
            type = SampleType.RECOVERY_STRATEGY,
            timestamp = System.currentTimeMillis(),
            input = RecoveryInput(
                failedAction = failedAction,
                failureReason = failureReason,
                screenState = screenState,
                retryCount = currentSession?.currentRetryCount ?: 0
            ),
            output = RecoveryOutput(
                strategy = recoveryStrategy,
                actions = recoveryActions,
                success = recoverySuccess
            ),
            metadata = SampleMetadata(
                sessionId = currentSession?.sessionId
            )
        )
        
        addSample(sample)
        LogManager.d(TAG, "🔄 记录恢复策略: $recoveryStrategy (成功: $recoverySuccess)")
    }
    
    /**
     * 🧠 记录 LLM 交互
     */
    fun recordLLMInteraction(
        prompt: String,
        response: String,
        purpose: String,
        latencyMs: Long,
        tokensUsed: Int = 0
    ) {
        val sample = TrainingSample(
            id = generateSampleId(),
            type = SampleType.LLM_INTERACTION,
            timestamp = System.currentTimeMillis(),
            input = LLMInput(
                prompt = prompt,
                purpose = purpose
            ),
            output = LLMOutput(
                response = response,
                latencyMs = latencyMs,
                tokensUsed = tokensUsed
            ),
            metadata = SampleMetadata(
                sessionId = currentSession?.sessionId
            )
        )
        
        addSample(sample)
        LogManager.d(TAG, "🧠 记录 LLM 交互: $purpose (${latencyMs}ms)")
    }
    
    /**
     * 📚 记录搜索学习
     */
    fun recordSearchLearning(
        searchQuery: String,
        searchResults: List<String>,
        learnedKnowledge: String,
        appliedSuccessfully: Boolean
    ) {
        val sample = TrainingSample(
            id = generateSampleId(),
            type = SampleType.SEARCH_LEARNING,
            timestamp = System.currentTimeMillis(),
            input = SearchInput(
                query = searchQuery,
                context = currentSession?.userCommand ?: ""
            ),
            output = SearchOutput(
                results = searchResults,
                learnedKnowledge = learnedKnowledge,
                applied = appliedSuccessfully
            ),
            metadata = SampleMetadata(
                sessionId = currentSession?.sessionId
            )
        )
        
        addSample(sample)
        LogManager.d(TAG, "📚 记录搜索学习: $searchQuery")
    }
    
    /**
     * 🏁 结束会话并保存数据
     */
    fun endSession(success: Boolean, summary: String = "") {
        val session = currentSession ?: return
        
        session.endTime = System.currentTimeMillis()
        session.success = success
        session.summary = summary
        
        // 保存会话数据
        scope.launch {
            saveSessionData(session)
        }
        
        totalSessionsCompleted++
        LogManager.d(TAG, "🏁 会话结束: ${session.sessionId} (成功: $success)")
        
        currentSession = null
    }
    
    /**
     * 📊 从 AccessibilityNodeInfo 提取屏幕状态
     */
    fun extractScreenState(rootNode: AccessibilityNodeInfo?): ScreenState {
        if (rootNode == null) {
            return ScreenState(
                packageName = "",
                visibleTexts = emptyList(),
                clickableElements = emptyList(),
                editableElements = emptyList(),
                scrollableElements = emptyList()
            )
        }
        
        val visibleTexts = mutableListOf<String>()
        val clickableElements = mutableListOf<UIElement>()
        val editableElements = mutableListOf<UIElement>()
        val scrollableElements = mutableListOf<UIElement>()
        var packageName = ""
        
        fun traverse(node: AccessibilityNodeInfo, depth: Int = 0) {
            if (depth > 15) return // 防止过深遍历
            
            val text = node.text?.toString() ?: ""
            val desc = node.contentDescription?.toString() ?: ""
            val className = node.className?.toString() ?: ""
            
            if (node.packageName != null) {
                packageName = node.packageName.toString()
            }
            
            // 收集可见文本
            if (text.isNotEmpty() && text.length < 200) {
                visibleTexts.add(text)
            }
            
            // 收集 UI 元素
            val bounds = android.graphics.Rect()
            node.getBoundsInScreen(bounds)
            
            val element = UIElement(
                text = text.take(100),
                description = desc.take(100),
                className = className.substringAfterLast('.'),
                bounds = ElementBounds(bounds.left, bounds.top, bounds.right, bounds.bottom),
                isEnabled = node.isEnabled,
                isFocused = node.isFocused
            )
            
            if (node.isClickable && (text.isNotEmpty() || desc.isNotEmpty())) {
                clickableElements.add(element)
            }
            if (node.isEditable) {
                editableElements.add(element)
            }
            if (node.isScrollable) {
                scrollableElements.add(element)
            }
            
            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { traverse(it, depth + 1) }
            }
        }
        
        traverse(rootNode)
        
        return ScreenState(
            packageName = packageName,
            visibleTexts = visibleTexts.distinct().take(50),
            clickableElements = clickableElements.take(30),
            editableElements = editableElements.take(10),
            scrollableElements = scrollableElements.take(5)
        )
    }
    
    /**
     * 💾 保存会话数据到文件
     */
    private suspend fun saveSessionData(session: DataCollectionSession) = withContext(Dispatchers.IO) {
        try {
            val dataDir = File(context.filesDir, DATA_DIR)
            if (!dataDir.exists()) dataDir.mkdirs()
            
            val dateStr = dateFormat.format(Date(session.startTime))
            val fileName = "session_${dateStr}_${session.sessionId.take(8)}.json"
            val file = File(dataDir, fileName)
            
            // 构建完整的会话数据
            val sessionData = SessionData(
                session = session.toSerialized(),
                samples = pendingSamples.filter { it.metadata.sessionId == session.sessionId }
            )
            
            file.writeText(json.encodeToString(sessionData))
            
            LogManager.d(TAG, "💾 会话数据已保存: $fileName")
            
            // 清理已保存的样本
            pendingSamples.removeAll { it.metadata.sessionId == session.sessionId }
            
        } catch (e: Exception) {
            LogManager.e(TAG, "保存会话数据失败", e)
        }
    }
    
    /**
     * 📤 导出所有训练数据
     */
    fun exportAllData(format: ExportFormat = ExportFormat.JSONL): File? {
        try {
            val dataDir = File(context.filesDir, DATA_DIR)
            if (!dataDir.exists()) return null
            
            val exportDir = File(context.getExternalFilesDir(null), "xihe_export")
            if (!exportDir.exists()) exportDir.mkdirs()
            
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val exportFile = File(exportDir, "xihe_training_data_$timestamp.${format.extension}")
            
            when (format) {
                ExportFormat.JSONL -> exportAsJsonl(dataDir, exportFile)
                ExportFormat.JSON -> exportAsJson(dataDir, exportFile)
                ExportFormat.CSV -> exportAsCsv(dataDir, exportFile)
            }
            
            LogManager.d(TAG, "📤 数据导出完成: ${exportFile.absolutePath}")
            return exportFile
            
        } catch (e: Exception) {
            LogManager.e(TAG, "导出数据失败", e)
            return null
        }
    }
    
    private fun exportAsJsonl(dataDir: File, exportFile: File) {
        exportFile.bufferedWriter().use { writer ->
            dataDir.listFiles()?.filter { it.extension == "json" }?.forEach { file ->
                try {
                    val sessionData = json.decodeFromString<SessionData>(file.readText())
                    sessionData.samples.forEach { sample ->
                        writer.write(json.encodeToString(sample))
                        writer.newLine()
                    }
                } catch (e: Exception) {
                    LogManager.e(TAG, "解析文件失败: ${file.name}", e)
                }
            }
        }
    }
    
    private fun exportAsJson(dataDir: File, exportFile: File) {
        val allSamples = mutableListOf<TrainingSample>()
        
        dataDir.listFiles()?.filter { it.extension == "json" }?.forEach { file ->
            try {
                val sessionData = json.decodeFromString<SessionData>(file.readText())
                allSamples.addAll(sessionData.samples)
            } catch (e: Exception) {
                LogManager.e(TAG, "解析文件失败: ${file.name}", e)
            }
        }
        
        exportFile.writeText(json.encodeToString(allSamples))
    }
    
    private fun exportAsCsv(dataDir: File, exportFile: File) {
        exportFile.bufferedWriter().use { writer ->
            // 写入标题
            writer.write("id,type,timestamp,input,output,success\n")
            
            dataDir.listFiles()?.filter { it.extension == "json" }?.forEach { file ->
                try {
                    val sessionData = json.decodeFromString<SessionData>(file.readText())
                    sessionData.samples.forEach { sample ->
                        val inputStr = json.encodeToString(sample.input).replace("\"", "\"\"")
                        val outputStr = json.encodeToString(sample.output).replace("\"", "\"\"")
                        writer.write("${sample.id},${sample.type},${sample.timestamp},\"$inputStr\",\"$outputStr\",${sample.metadata.isCorrect}\n")
                    }
                } catch (e: Exception) {
                    LogManager.e(TAG, "解析文件失败: ${file.name}", e)
                }
            }
        }
    }
    
    /**
     * 🧹 清理旧数据
     */
    fun cleanOldData(daysToKeep: Int = 30) {
        scope.launch(Dispatchers.IO) {
            try {
                val dataDir = File(context.filesDir, DATA_DIR)
                if (!dataDir.exists()) return@launch
                
                val cutoffTime = System.currentTimeMillis() - (daysToKeep * 24 * 60 * 60 * 1000L)
                var deletedCount = 0
                
                dataDir.listFiles()?.forEach { file ->
                    if (file.lastModified() < cutoffTime) {
                        file.delete()
                        deletedCount++
                    }
                }
                
                LogManager.d(TAG, "🧹 已清理 $deletedCount 个旧数据文件")
            } catch (e: Exception) {
                LogManager.e(TAG, "清理旧数据失败", e)
            }
        }
    }
    
    /**
     * 📊 获取统计信息
     */
    fun getStatistics(): DataStatistics {
        val dataDir = File(context.filesDir, DATA_DIR)
        var totalFiles = 0
        var totalSamples = 0
        var totalSize = 0L
        val sampleTypeCounts = mutableMapOf<SampleType, Int>()
        
        dataDir.listFiles()?.filter { it.extension == "json" }?.forEach { file ->
            totalFiles++
            totalSize += file.length()
            
            try {
                val sessionData = json.decodeFromString<SessionData>(file.readText())
                totalSamples += sessionData.samples.size
                
                sessionData.samples.forEach { sample ->
                    sampleTypeCounts[sample.type] = (sampleTypeCounts[sample.type] ?: 0) + 1
                }
            } catch (e: Exception) {
                // 忽略解析错误
            }
        }
        
        return DataStatistics(
            totalFiles = totalFiles,
            totalSamples = totalSamples,
            totalSizeBytes = totalSize,
            sampleTypeCounts = sampleTypeCounts,
            sessionsCompleted = totalSessionsCompleted
        )
    }
    
    // ==================== 辅助方法 ====================
    
    private fun addSample(sample: TrainingSample) {
        pendingSamples.add(sample)
        currentSession?.samples?.add(sample)
        totalSamplesCollected++
        
        // 定期保存
        if (pendingSamples.size >= MAX_SAMPLES_PER_FILE) {
            scope.launch {
                flushPendingSamples()
            }
        }
    }
    
    private suspend fun flushPendingSamples() = withContext(Dispatchers.IO) {
        if (pendingSamples.isEmpty()) return@withContext
        
        try {
            val dataDir = File(context.filesDir, DATA_DIR)
            if (!dataDir.exists()) dataDir.mkdirs()
            
            val timestamp = System.currentTimeMillis()
            val fileName = "samples_${dateFormat.format(Date(timestamp))}_$timestamp.json"
            val file = File(dataDir, fileName)
            
            file.writeText(json.encodeToString(pendingSamples.toList()))
            pendingSamples.clear()
            
            LogManager.d(TAG, "💾 批量样本已保存: $fileName")
        } catch (e: Exception) {
            LogManager.e(TAG, "保存批量样本失败", e)
        }
    }
    
    private fun generateSampleId(): String {
        return "sample_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}"
    }
    
    private fun getCurrentContext(): String {
        return currentSession?.let {
            "会话: ${it.sessionId.take(8)}, 步骤: ${it.currentStepIndex}/${it.totalSteps}"
        } ?: "无会话上下文"
    }
    
    fun updateSessionProgress(currentStep: Int, totalSteps: Int) {
        currentSession?.let {
            it.currentStepIndex = currentStep
            it.totalSteps = totalSteps
        }
    }
    
    fun updateRetryCount(count: Int) {
        currentSession?.currentRetryCount = count
    }
}

// ==================== 数据模型 ====================

enum class SampleType {
    INTENT_RECOGNITION,    // 意图识别
    ACTION_SELECTION,      // 动作选择
    EXECUTION_RESULT,      // 执行结果
    RECOVERY_STRATEGY,     // 恢复策略
    LLM_INTERACTION,       // LLM交互
    SEARCH_LEARNING        // 搜索学习
}

enum class ExportFormat(val extension: String) {
    JSONL("jsonl"),
    JSON("json"),
    CSV("csv")
}

@Serializable
data class TrainingSample(
    val id: String,
    val type: SampleType,
    val timestamp: Long,
    val input: SampleInput,
    val output: SampleOutput,
    val metadata: SampleMetadata
)

@Serializable
sealed class SampleInput

@Serializable
sealed class SampleOutput

@Serializable
data class SampleMetadata(
    val confidence: Float = 1.0f,
    val isCorrect: Boolean = true,
    val sessionId: String? = null,
    val tags: List<String> = emptyList()
)

// 意图识别
@Serializable
data class IntentInput(
    val userCommand: String,
    val context: String = ""
) : SampleInput()

@Serializable
data class IntentOutput(
    val intentType: String,
    val description: String,
    val app: String,
    val parameters: Map<String, String>
) : SampleOutput()

// 动作选择
@Serializable
data class ActionInput(
    val screenState: ScreenState,
    val taskContext: TaskContextData? = null
) : SampleInput()

@Serializable
data class ActionOutput(
    val selectedAction: String,
    val target: String?,
    val parameters: Map<String, String>,
    val alternatives: List<String> = emptyList(),
    val reasoning: String = ""
) : SampleOutput()

// 执行结果
@Serializable
data class ExecutionInput(
    val action: String,
    val target: String?,
    val screenBefore: ScreenState? = null
) : SampleInput()

@Serializable
data class ExecutionOutput(
    val success: Boolean,
    val message: String,
    val executionTimeMs: Long,
    val screenAfter: ScreenState? = null
) : SampleOutput()

// 恢复策略
@Serializable
data class RecoveryInput(
    val failedAction: String,
    val failureReason: String,
    val screenState: ScreenState,
    val retryCount: Int
) : SampleInput()

@Serializable
data class RecoveryOutput(
    val strategy: String,
    val actions: List<String>,
    val success: Boolean
) : SampleOutput()

// LLM 交互
@Serializable
data class LLMInput(
    val prompt: String,
    val purpose: String
) : SampleInput()

@Serializable
data class LLMOutput(
    val response: String,
    val latencyMs: Long,
    val tokensUsed: Int
) : SampleOutput()

// 搜索学习
@Serializable
data class SearchInput(
    val query: String,
    val context: String
) : SampleInput()

@Serializable
data class SearchOutput(
    val results: List<String>,
    val learnedKnowledge: String,
    val applied: Boolean
) : SampleOutput()

// 屏幕状态
@Serializable
data class ScreenState(
    val packageName: String,
    val visibleTexts: List<String>,
    val clickableElements: List<UIElement>,
    val editableElements: List<UIElement>,
    val scrollableElements: List<UIElement>
)

@Serializable
data class UIElement(
    val text: String,
    val description: String,
    val className: String,
    val bounds: ElementBounds,
    val isEnabled: Boolean = true,
    val isFocused: Boolean = false
)

@Serializable
data class ElementBounds(
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int
)

@Serializable
data class TaskContextData(
    val command: String,
    val currentStep: Int,
    val totalSteps: Int
)

// 会话数据
data class DataCollectionSession(
    val sessionId: String,
    val startTime: Long,
    var endTime: Long = 0,
    val userCommand: String,
    var success: Boolean = false,
    var summary: String = "",
    var currentStepIndex: Int = 0,
    var totalSteps: Int = 0,
    var currentRetryCount: Int = 0,
    var successfulActions: Int = 0,
    var failedActions: Int = 0,
    val samples: MutableList<TrainingSample> = mutableListOf()
)

@Serializable
data class SessionData(
    val session: TrainingSessionSerialized,
    val samples: List<TrainingSample>
)

@Serializable
data class TrainingSessionSerialized(
    val sessionId: String,
    val startTime: Long,
    val endTime: Long,
    val userCommand: String,
    val success: Boolean,
    val summary: String,
    val successfulActions: Int,
    val failedActions: Int
)

// 统计数据
data class DataStatistics(
    val totalFiles: Int,
    val totalSamples: Int,
    val totalSizeBytes: Long,
    val sampleTypeCounts: Map<SampleType, Int>,
    val sessionsCompleted: Long
)

// 扩展函数：将 DataCollectionSession 转换为可序列化版本
fun DataCollectionSession.toSerialized() = TrainingSessionSerialized(
    sessionId = sessionId,
    startTime = startTime,
    endTime = endTime,
    userCommand = userCommand,
    success = success,
    summary = summary,
    successfulActions = successfulActions,
    failedActions = failedActions
)
