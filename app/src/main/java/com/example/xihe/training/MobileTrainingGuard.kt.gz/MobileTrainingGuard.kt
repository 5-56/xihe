package com.example.xihe.training

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import com.example.xihe.utils.LogManager
import com.example.xihe.utils.DeviceStatusHelper
import java.io.File

/**
 * 📱 手机训练保护系统
 * 
 * 专门为手机环境设计的训练保护机制
 * 
 * 核心保护：
 * 1. 🌡️ 温度监控 - 防止过热
 * 2. 🔋 电池保护 - 避免电池损耗
 * 3. 💾 内存保护 - 防止OOM
 * 4. ⚡ 性能监控 - 避免卡顿
 * 5. 📱 用户体验 - 保证流畅使用
 */
class MobileTrainingGuard(private val context: Context) {
    
    companion object {
        private const val TAG = "MobileTrainingGuard"
        
        // 安全阈值
        private const val MAX_SAFE_TEMP_CELSIUS = 40.0f    // 最高安全温度
        private const val MIN_BATTERY_PERCENT = 50         // 最低电量
        private const val MAX_MEMORY_PERCENT = 70          // 最大内存使用率
        private const val MIN_FREE_STORAGE_MB = 500        // 最小可用存储
        private const val MAX_CPU_USAGE_PERCENT = 80       // 最大CPU使用率
        
        // 警告阈值
        private const val WARN_TEMP_CELSIUS = 38.0f
        private const val WARN_MEMORY_PERCENT = 60
        private const val WARN_BATTERY_PERCENT = 60
        
        // 夜间自主训练时段
        private const val NIGHT_TRAINING_START_HOUR = 22   // 晚上10点
        private const val NIGHT_TRAINING_END_HOUR = 7      // 早上7点
    }
    
    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
    private val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    
    /**
     * 🔍 检查是否可以开始训练
     * @param isManualTrigger 是否为用户手动触发（手动触发时放宽条件）
     */
    fun canStartTraining(isManualTrigger: Boolean = false): TrainingGuardResult {
        LogManager.d(TAG, "🔍 开始安全检查... (手动触发: $isManualTrigger)")
        
        val checks = mutableListOf<SafetyCheck>()
        val isNightTime = isNightTrainingTime()
        val isIdle = isDeviceIdle()
        
        // 🌙 判断是否为自主训练时段（晚上或设备空闲）
        val isAutoTrainingTime = isNightTime || isIdle
        
        // 1. 温度检查（始终检查，但手动触发时放宽阈值）
        val tempCheck = checkTemperature()
        checks.add(tempCheck)
        if (!tempCheck.passed && !isManualTrigger) {
            return TrainingGuardResult.Blocked(
                reason = "设备温度过高 (${tempCheck.value}°C)",
                checks = checks
            )
        }
        
        // 2. 电池检查
        // 🆕 用户手动触发或夜间/空闲时段：不检查充电状态
        val batteryCheck = checkBattery(relaxed = isManualTrigger || isAutoTrainingTime)
        checks.add(batteryCheck)
        if (!batteryCheck.passed && !isManualTrigger && !isAutoTrainingTime) {
            return TrainingGuardResult.Blocked(
                reason = "电池电量不足或未充电",
                checks = checks
            )
        }
        
        // 3. 内存检查（⚠️ 唯一的硬性条件，任何时候内存不足都不能训练）
        val memoryCheck = checkMemory()
        checks.add(memoryCheck)
        if (!memoryCheck.passed) {
            return TrainingGuardResult.Blocked(
                reason = "可用内存不足 (${memoryCheck.value}%)，无法进行训练",
                checks = checks
            )
        }
        
        // 4. 存储检查（手动触发或自主训练时段时放宽）
        val storageCheck = checkStorage()
        checks.add(storageCheck)
        if (!storageCheck.passed && !isManualTrigger) {
            return TrainingGuardResult.Blocked(
                reason = "存储空间不足",
                checks = checks
            )
        }
        
        // 5. 设备空闲检查（手动触发或夜间时段时跳过）
        val idleCheck = checkDeviceIdle()
        checks.add(idleCheck)
        if (!idleCheck.passed && !isManualTrigger && !isNightTime) {
            return TrainingGuardResult.Blocked(
                reason = "设备正在使用中",
                checks = checks
            )
        }
        
        // 6. CPU使用率检查（仅警告，不阻止）
        val cpuCheck = checkCpuUsage()
        checks.add(cpuCheck)
        if (!cpuCheck.passed) {
            return TrainingGuardResult.Warning(
                reason = "CPU使用率较高，训练可能较慢",
                checks = checks
            )
        }
        
        LogManager.d(TAG, "✅ 所有安全检查通过")
        return TrainingGuardResult.Allowed(checks = checks)
    }
    
    /**
     * 🌙 检查是否为夜间自主训练时段
     */
    fun isNightTrainingTime(): Boolean {
        val currentHour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return currentHour >= NIGHT_TRAINING_START_HOUR || currentHour < NIGHT_TRAINING_END_HOUR
    }
    
    /**
     * 🔍 训练中实时监控
     */
    fun monitorDuringTraining(): TrainingMonitorResult {
        val temp = getCurrentTemperature()
        val battery = getBatteryLevel()
        val memory = getMemoryUsage()
        
        // 温度过高 - 立即停止
        if (temp > MAX_SAFE_TEMP_CELSIUS) {
            LogManager.w(TAG, "⚠️ 温度过高！立即停止训练")
            return TrainingMonitorResult.MustStop(
                reason = "设备温度过高 ($temp°C)",
                severity = Severity.CRITICAL
            )
        }
        
        // 电池低 - 建议停止
        if (battery < MIN_BATTERY_PERCENT && !isCharging()) {
            LogManager.w(TAG, "⚠️ 电池电量低且未充电")
            return TrainingMonitorResult.ShouldStop(
                reason = "电池电量低 ($battery%)",
                severity = Severity.HIGH
            )
        }
        
        // 内存不足 - 必须停止
        if (memory > MAX_MEMORY_PERCENT) {
            LogManager.w(TAG, "⚠️ 内存使用率过高")
            return TrainingMonitorResult.MustStop(
                reason = "内存使用率过高 ($memory%)",
                severity = Severity.CRITICAL
            )
        }
        
        // 温度警告
        if (temp > WARN_TEMP_CELSIUS) {
            return TrainingMonitorResult.Warning(
                reason = "温度偏高 ($temp°C)，建议降低训练强度",
                severity = Severity.MEDIUM
            )
        }
        
        // 内存警告
        if (memory > WARN_MEMORY_PERCENT) {
            return TrainingMonitorResult.Warning(
                reason = "内存使用率偏高 ($memory%)，建议减小批次大小",
                severity = Severity.MEDIUM
            )
        }
        
        return TrainingMonitorResult.Continue
    }
    
    /**
     * 🌡️ 温度检查
     */
    private fun checkTemperature(): SafetyCheck {
        val temp = getCurrentTemperature()
        
        return SafetyCheck(
            name = "设备温度",
            passed = temp < MAX_SAFE_TEMP_CELSIUS,
            value = "$temp°C",
            threshold = "${MAX_SAFE_TEMP_CELSIUS}°C",
            message = when {
                temp >= MAX_SAFE_TEMP_CELSIUS -> "温度过高，无法训练"
                temp >= WARN_TEMP_CELSIUS -> "温度偏高，建议降低强度"
                else -> "温度正常"
            }
        )
    }
    
    /**
     * 🔋 电池检查
     * @param relaxed 是否放宽条件（手动触发或夜间/空闲时段不要求充电）
     */
    private fun checkBattery(relaxed: Boolean = false): SafetyCheck {
        val level = getBatteryLevel()
        val charging = isCharging()
        
        // 🆕 放宽条件时：只要电量>=20%即可，不要求充电
        // 严格条件时：需要充电且电量>=50%
        val passed = if (relaxed) {
            level >= 20  // 放宽条件：只检查最低电量
        } else {
            charging && level >= MIN_BATTERY_PERCENT
        }
        
        val threshold = if (relaxed) "20% 以上（放宽模式）" else "$MIN_BATTERY_PERCENT% 且充电中"
        
        return SafetyCheck(
            name = "电池状态",
            passed = passed,
            value = "$level% ${if (charging) "充电中" else "未充电"}",
            threshold = threshold,
            message = when {
                relaxed && level < 20 -> "电量过低（<20%）"
                !relaxed && !charging -> "未连接充电器"
                !relaxed && level < MIN_BATTERY_PERCENT -> "电量不足 $MIN_BATTERY_PERCENT%"
                else -> "电池状态良好"
            }
        )
    }
    
    /**
     * 💾 内存检查
     */
    private fun checkMemory(): SafetyCheck {
        val memoryUsage = getMemoryUsage()
        val passed = memoryUsage < MAX_MEMORY_PERCENT
        
        return SafetyCheck(
            name = "可用内存",
            passed = passed,
            value = "${100 - memoryUsage}% 可用",
            threshold = "${100 - MAX_MEMORY_PERCENT}% 以上",
            message = when {
                memoryUsage >= MAX_MEMORY_PERCENT -> "内存不足"
                memoryUsage >= WARN_MEMORY_PERCENT -> "内存偏紧张"
                else -> "内存充足"
            }
        )
    }
    
    /**
     * 💿 存储检查
     */
    private fun checkStorage(): SafetyCheck {
        val freeMB = getFreeStorageMB()
        val passed = freeMB >= MIN_FREE_STORAGE_MB
        
        return SafetyCheck(
            name = "存储空间",
            passed = passed,
            value = "${freeMB}MB 可用",
            threshold = "${MIN_FREE_STORAGE_MB}MB 以上",
            message = when {
                freeMB < MIN_FREE_STORAGE_MB -> "存储空间不足"
                freeMB < MIN_FREE_STORAGE_MB * 2 -> "存储空间偏少"
                else -> "存储空间充足"
            }
        )
    }
    
    /**
     * 😴 设备空闲检查
     */
    private fun checkDeviceIdle(): SafetyCheck {
        val isIdle = isDeviceIdle()
        
        return SafetyCheck(
            name = "设备状态",
            passed = isIdle,
            value = if (isIdle) "空闲" else "使用中",
            threshold = "空闲",
            message = if (isIdle) "设备空闲，可以训练" else "设备正在使用中"
        )
    }
    
    /**
     * 🔥 CPU使用率检查
     */
    private fun checkCpuUsage(): SafetyCheck {
        val cpuUsage = getCpuUsage()
        val passed = cpuUsage < MAX_CPU_USAGE_PERCENT
        
        return SafetyCheck(
            name = "CPU使用率",
            passed = passed,
            value = "$cpuUsage%",
            threshold = "${MAX_CPU_USAGE_PERCENT}% 以下",
            message = when {
                cpuUsage >= MAX_CPU_USAGE_PERCENT -> "CPU负载过高"
                cpuUsage >= 60 -> "CPU负载较高"
                else -> "CPU负载正常"
            }
        )
    }
    
    /**
     * 📊 获取推荐的训练配置
     */
    fun getRecommendedConfig(): RecommendedTrainingConfig {
        val temp = getCurrentTemperature()
        val memory = getMemoryUsage()
        val battery = getBatteryLevel()
        val cpuUsage = getCpuUsage()
        
        // 根据设备状态推荐配置
        val batchSize = when {
            memory > 60 -> 2           // 内存紧张：小批次
            memory > 40 -> 4           // 内存一般：中批次
            else -> 8                  // 内存充足：大批次
        }
        
        val useGpu = when {
            temp > 38 -> false         // 温度高：不用GPU
            battery < 60 -> false      // 电量低：不用GPU
            else -> true               // 条件好：使用GPU
        }
        
        val maxEpochs = when {
            temp > 38 || battery < 60 -> 3   // 条件差：少训练
            temp > 35 || battery < 80 -> 5   // 条件一般：中等
            else -> 10                       // 条件好：多训练
        }
        
        val threadCount = when {
            cpuUsage > 60 -> 2         // CPU忙：少线程
            cpuUsage > 40 -> 4         // CPU一般：中等
            else -> 8                  // CPU闲：多线程
        }
        
        return RecommendedTrainingConfig(
            batchSize = batchSize,
            useGpu = useGpu,
            maxEpochs = maxEpochs,
            threadCount = threadCount,
            reason = buildConfigReason(temp, memory, battery, cpuUsage)
        )
    }
    
    // ==================== 辅助方法 ====================
    
    /**
     * 获取当前温度
     */
    private fun getCurrentTemperature(): Float {
        return try {
            // 从电池温度估算
            val batteryStatus: Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val batteryTemp = batteryStatus?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 350) ?: 350
            batteryTemp / 10.0f  // 电池温度单位是0.1°C
        } catch (e: Exception) {
            LogManager.w(TAG, "无法获取温度", e)
            35.0f  // 默认35°C
        }
    }
    
    /**
     * 获取电池电量
     */
    private fun getBatteryLevel(): Int {
        val batteryStatus = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        
        return if (level >= 0 && scale > 0) {
            (level.toFloat() / scale.toFloat() * 100).toInt()
        } else {
            100  // 无法获取时假设满电
        }
    }
    
    /**
     * 是否正在充电
     */
    private fun isCharging(): Boolean {
        val batteryStatus = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        
        return status == BatteryManager.BATTERY_STATUS_CHARGING ||
               status == BatteryManager.BATTERY_STATUS_FULL
    }
    
    /**
     * 获取内存使用率
     */
    private fun getMemoryUsage(): Int {
        val runtime = Runtime.getRuntime()
        val usedMemory = runtime.totalMemory() - runtime.freeMemory()
        val maxMemory = runtime.maxMemory()
        
        return ((usedMemory.toFloat() / maxMemory.toFloat()) * 100).toInt()
    }
    
    /**
     * 获取可用存储空间（MB）
     */
    private fun getFreeStorageMB(): Long {
        val dataDir = context.filesDir
        val freeBytes = dataDir.freeSpace
        return freeBytes / (1024 * 1024)
    }
    
    /**
     * 检查设备是否空闲
     */
    private fun isDeviceIdle(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            powerManager.isDeviceIdleMode || !powerManager.isInteractive
        } else {
            !powerManager.isInteractive
        }
    }
    
    /**
     * 获取CPU使用率
     * 🆕 使用 DeviceStatusHelper 获取真实值
     * 注意：由于getCpuUsage()是suspend函数，这里返回默认值
     */
    private fun getCpuUsage(): Int {
        // DeviceStatusHelper.getCpuUsage() 是suspend函数，需要在协程中调用
        // 这里返回默认估算值
        return 50  // 返回默认值
    }
    
    /**
     * 构建配置推荐原因
     */
    private fun buildConfigReason(temp: Float, memory: Int, battery: Int, cpu: Int): String {
        val reasons = mutableListOf<String>()
        
        if (temp > 38) reasons.add("温度偏高")
        if (memory > 60) reasons.add("内存紧张")
        if (battery < 70) reasons.add("电量有限")
        if (cpu > 60) reasons.add("CPU繁忙")
        
        return if (reasons.isEmpty()) {
            "设备状态良好，使用推荐配置"
        } else {
            "考虑到${reasons.joinToString("、")}，推荐使用保守配置"
        }
    }
}

// ==================== 数据类 ====================

/**
 * 训练保护结果
 */
sealed class TrainingGuardResult {
    data class Allowed(val checks: List<SafetyCheck>) : TrainingGuardResult()
    data class Warning(val reason: String, val checks: List<SafetyCheck>) : TrainingGuardResult()
    data class Blocked(val reason: String, val checks: List<SafetyCheck>) : TrainingGuardResult()
}

/**
 * 训练监控结果
 */
sealed class TrainingMonitorResult {
    object Continue : TrainingMonitorResult()
    data class Warning(val reason: String, val severity: Severity) : TrainingMonitorResult()
    data class ShouldStop(val reason: String, val severity: Severity) : TrainingMonitorResult()
    data class MustStop(val reason: String, val severity: Severity) : TrainingMonitorResult()
}

/**
 * 严重程度
 */
enum class Severity {
    LOW, MEDIUM, HIGH, CRITICAL
}

/**
 * 安全检查项
 */
data class SafetyCheck(
    val name: String,
    val passed: Boolean,
    val value: String,
    val threshold: String,
    val message: String
)

/**
 * 推荐的训练配置
 */
data class RecommendedTrainingConfig(
    val batchSize: Int,
    val useGpu: Boolean,
    val maxEpochs: Int,
    val threadCount: Int,
    val reason: String
)
