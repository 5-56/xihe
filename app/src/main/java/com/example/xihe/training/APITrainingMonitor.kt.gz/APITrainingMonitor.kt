package com.example.xihe.training

import android.content.Context
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

/**
 * 🌐 API 训练监控管理器
 * 
 * 功能：
 * 1. 📡 实时上报训练状态到远程API
 * 2. 🎮 接收远程控制指令（开始/停止/调整参数）
 * 3. 📊 同步训练指标和日志
 * 4. 🤖 调用AI API进行智能训练决策
 * 5. 📈 训练数据云端备份
 * 
 * 支持的API类型：
 * - OpenAI Compatible API
 * - 自定义监控服务器
 * - WebSocket 实时通信
 */
class APITrainingMonitor private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "APITrainingMonitor"
        
        // 默认配置
        private const val DEFAULT_REPORT_INTERVAL_MS = 5000L  // 5秒上报一次
        private const val DEFAULT_POLL_INTERVAL_MS = 3000L   // 3秒轮询一次指令
        private const val MAX_RETRY_COUNT = 3
        private const val TIMEOUT_MS = 10000
        
        @Volatile
        private var instance: APITrainingMonitor? = null
        
        fun getInstance(context: Context): APITrainingMonitor {
            return instance ?: synchronized(this) {
                instance ?: APITrainingMonitor(context.applicationContext).also {
                    instance = it
                }
            }
        }
    }
    
    // 配置
    private var config = APIMonitorConfig()
    
    // 状态
    private val _monitorState = MutableStateFlow(MonitorState.DISCONNECTED)
    val monitorState: StateFlow<MonitorState> = _monitorState
    
    private val _lastCommand = MutableStateFlow<RemoteCommand?>(null)
    val lastCommand: StateFlow<RemoteCommand?> = _lastCommand
    
    private val _connectionStatus = MutableStateFlow(ConnectionStatus())
    val connectionStatus: StateFlow<ConnectionStatus> = _connectionStatus
    
    // 协程
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var reportJob: Job? = null
    private var pollJob: Job? = null
    
    // 训练器引用
    private var trainer: OptimizedTFLiteTrainer? = null
    private var scheduler: AutoTrainingScheduler? = null
    
    /**
     * 🔧 配置API监控
     */
    fun configure(config: APIMonitorConfig) {
        this.config = config
        LogManager.i(TAG, "✅ API监控配置更新: ${config.apiEndpoint}")
    }
    
    /**
     * 🚀 启动监控
     */
    fun startMonitoring(
        trainer: OptimizedTFLiteTrainer,
        scheduler: AutoTrainingScheduler
    ) {
        this.trainer = trainer
        this.scheduler = scheduler
        
        if (_monitorState.value == MonitorState.CONNECTED) {
            LogManager.w(TAG, "⚠️ 监控已在运行中")
            return
        }
        
        LogManager.i(TAG, "🚀 启动API训练监控...")
        _monitorState.value = MonitorState.CONNECTING
        
        // 启动状态上报
        startStatusReporting()
        
        // 启动指令轮询（如果启用）
        if (config.enableRemoteControl) {
            startCommandPolling()
        }
        
        _monitorState.value = MonitorState.CONNECTED
        LogManager.i(TAG, "✅ API监控已启动")
    }
    
    /**
     * 🛑 停止监控
     */
    fun stopMonitoring() {
        LogManager.i(TAG, "🛑 停止API监控...")
        
        reportJob?.cancel()
        pollJob?.cancel()
        
        _monitorState.value = MonitorState.DISCONNECTED
        LogManager.i(TAG, "✅ API监控已停止")
    }
    
    /**
     * 📡 启动状态上报
     */
    private fun startStatusReporting() {
        reportJob = scope.launch {
            while (isActive) {
                try {
                    reportTrainingStatus()
                    delay(config.reportIntervalMs)
                } catch (e: Exception) {
                    LogManager.e(TAG, "状态上报失败: ${e.message}")
                    _connectionStatus.value = _connectionStatus.value.copy(
                        lastError = e.message,
                        failedAttempts = _connectionStatus.value.failedAttempts + 1
                    )
                    delay(config.reportIntervalMs * 2)  // 失败后延长间隔
                }
            }
        }
    }
    
    /**
     * 🎮 启动指令轮询
     */
    private fun startCommandPolling() {
        pollJob = scope.launch {
            while (isActive) {
                try {
                    val command = pollRemoteCommand()
                    command?.let { handleRemoteCommand(it) }
                    delay(config.pollIntervalMs)
                } catch (e: Exception) {
                    LogManager.e(TAG, "指令轮询失败: ${e.message}")
                    delay(config.pollIntervalMs * 2)
                }
            }
        }
    }
    
    /**
     * 📊 上报训练状态
     */
    private suspend fun reportTrainingStatus() {
        val trainer = this.trainer ?: return
        val scheduler = this.scheduler ?: return
        
        val metrics = trainer.metrics.value
        val state = trainer.trainingState.value
        val conditions = scheduler.getTrainingConditions()
        
        val statusJson = JSONObject().apply {
            put("device_id", getDeviceId())
            put("timestamp", System.currentTimeMillis())
            put("training_state", state.name)
            put("metrics", JSONObject().apply {
                put("epoch", metrics.currentEpoch)
                put("total_epochs", metrics.totalEpochs)
                put("batch", metrics.currentBatch)
                put("total_batches", metrics.totalBatches)
                put("loss", metrics.currentLoss)
                put("throughput", metrics.averageThroughput)
                put("samples_processed", metrics.samplesProcessed)
            })
            put("conditions", JSONObject().apply {
                put("battery_level", conditions.batteryLevel)
                put("is_charging", conditions.isCharging)
                put("is_night_time", conditions.isNightTime)
                put("can_auto_train", conditions.canAutoTrain)
                put("block_reason", conditions.blockReason ?: "")
            })
        }
        
        // 发送到API
        val response = sendToAPI(config.apiEndpoint + "/training/status", statusJson)
        
        _connectionStatus.value = _connectionStatus.value.copy(
            lastReportTime = System.currentTimeMillis(),
            successfulReports = _connectionStatus.value.successfulReports + 1,
            lastError = null
        )
        
        LogManager.i(TAG, "📡 状态上报成功")
    }
    
    /**
     * 🎮 轮询远程指令
     */
    private suspend fun pollRemoteCommand(): RemoteCommand? {
        val response = sendToAPI(
            config.apiEndpoint + "/training/commands?device_id=${getDeviceId()}",
            null,
            "GET"
        )
        
        if (response.isNullOrBlank()) return null
        
        return try {
            val json = JSONObject(response)
            if (json.has("command")) {
                RemoteCommand(
                    type = CommandType.valueOf(json.getString("command")),
                    params = if (json.has("params")) json.getJSONObject("params") else null,
                    timestamp = json.optLong("timestamp", System.currentTimeMillis())
                )
            } else null
        } catch (e: Exception) {
            LogManager.e(TAG, "解析指令失败: ${e.message}")
            null
        }
    }
    
    /**
     * 🎯 处理远程指令
     */
    private suspend fun handleRemoteCommand(command: RemoteCommand) {
        LogManager.i(TAG, "🎮 收到远程指令: ${command.type}")
        _lastCommand.value = command
        
        when (command.type) {
            CommandType.START_TRAINING -> {
                scheduler?.triggerTraining()
            }
            
            CommandType.STOP_TRAINING -> {
                trainer?.stopTraining()
            }
            
            CommandType.ADJUST_PARAMS -> {
                command.params?.let { params ->
                    // 调整训练参数
                    LogManager.i(TAG, "调整参数: $params")
                }
            }
            
            CommandType.GET_STATUS -> {
                reportTrainingStatus()
            }
            
            CommandType.EXPORT_DATA -> {
                exportTrainingData()
            }
            
            CommandType.AI_ANALYZE -> {
                requestAIAnalysis()
            }
        }
    }
    
    /**
     * 🤖 请求AI分析训练状态
     */
    suspend fun requestAIAnalysis(): AIAnalysisResult = withContext(Dispatchers.IO) {
        LogManager.i(TAG, "🤖 请求AI分析...")
        
        if (config.aiApiKey.isBlank()) {
            return@withContext AIAnalysisResult.Error("未配置AI API Key")
        }
        
        val trainer = this@APITrainingMonitor.trainer
            ?: return@withContext AIAnalysisResult.Error("训练器未初始化")
        
        val metrics = trainer.metrics.value
        val scheduler = this@APITrainingMonitor.scheduler
        val conditions = scheduler?.getTrainingConditions()
        
        // 构建分析请求
        val prompt = buildAIAnalysisPrompt(metrics, conditions)
        
        try {
            val response = callAIAPI(prompt)
            val analysis = parseAIResponse(response)
            
            LogManager.i(TAG, "✅ AI分析完成")
            AIAnalysisResult.Success(analysis)
            
        } catch (e: Exception) {
            LogManager.e(TAG, "AI分析失败: ${e.message}")
            AIAnalysisResult.Error(e.message ?: "未知错误")
        }
    }
    
    /**
     * 📝 构建AI分析提示词
     */
    private fun buildAIAnalysisPrompt(
        metrics: TrainingMetrics,
        conditions: TrainingConditionsInfo?
    ): String {
        return """
            你是一个AI训练专家。请分析以下训练状态并提供建议：
            
            ## 训练指标
            - 当前Epoch: ${metrics.currentEpoch}/${metrics.totalEpochs}
            - 当前Batch: ${metrics.currentBatch}/${metrics.totalBatches}
            - 当前Loss: ${metrics.currentLoss}
            - 吞吐量: ${metrics.averageThroughput} 样本/秒
            - 已处理样本: ${metrics.samplesProcessed}
            
            ## 设备条件
            - 电池电量: ${conditions?.batteryLevel ?: "未知"}%
            - 是否充电: ${conditions?.isCharging ?: "未知"}
            - 是否夜间: ${conditions?.isNightTime ?: "未知"}
            - 可以自动训练: ${conditions?.canAutoTrain ?: "未知"}
            ${conditions?.blockReason?.let { "- 阻止原因: $it" } ?: ""}
            
            请提供：
            1. 训练状态评估
            2. 是否建议继续训练
            3. 参数调整建议
            4. 潜在问题警告
            
            请用JSON格式回复。
        """.trimIndent()
    }
    
    /**
     * 🤖 调用AI API
     */
    private suspend fun callAIAPI(prompt: String): String = withContext(Dispatchers.IO) {
        val requestBody = JSONObject().apply {
            put("model", config.aiModel)
            put("messages", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "system")
                    put("content", "你是一个专业的AI训练监控助手。")
                })
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", prompt)
                })
            })
            put("temperature", 0.7)
            put("max_tokens", 1000)
        }
        
        val url = URL(config.aiApiEndpoint)
        val connection = url.openConnection() as HttpURLConnection
        
        try {
            connection.apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Authorization", "Bearer ${config.aiApiKey}")
                connectTimeout = TIMEOUT_MS
                readTimeout = TIMEOUT_MS
                doOutput = true
            }
            
            OutputStreamWriter(connection.outputStream).use { writer ->
                writer.write(requestBody.toString())
            }
            
            if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader(InputStreamReader(connection.inputStream)).use { reader ->
                    reader.readText()
                }
            } else {
                throw Exception("AI API错误: ${connection.responseCode}")
            }
        } finally {
            connection.disconnect()
        }
    }
    
    /**
     * 📊 解析AI响应
     */
    private fun parseAIResponse(response: String): AIAnalysis {
        return try {
            val json = JSONObject(response)
            val content = json.getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")
            
            // 尝试解析JSON格式的分析结果
            val analysisJson = JSONObject(content)
            
            AIAnalysis(
                status = analysisJson.optString("status", "正常"),
                shouldContinue = analysisJson.optBoolean("should_continue", true),
                suggestions = analysisJson.optJSONArray("suggestions")?.let { arr ->
                    (0 until arr.length()).map { arr.getString(it) }
                } ?: emptyList(),
                warnings = analysisJson.optJSONArray("warnings")?.let { arr ->
                    (0 until arr.length()).map { arr.getString(it) }
                } ?: emptyList(),
                parameterAdjustments = analysisJson.optJSONObject("adjustments")?.let { adj ->
                    mapOf(
                        "batch_size" to adj.optInt("batch_size", -1),
                        "learning_rate" to adj.optDouble("learning_rate", -1.0),
                        "epochs" to adj.optInt("epochs", -1)
                    ).filterValues { it != -1 && it != -1.0 }
                } ?: emptyMap(),
                rawAnalysis = content
            )
        } catch (e: Exception) {
            // 如果解析失败，返回原始文本
            AIAnalysis(
                status = "分析完成",
                shouldContinue = true,
                suggestions = emptyList(),
                warnings = emptyList(),
                parameterAdjustments = emptyMap(),
                rawAnalysis = response
            )
        }
    }
    
    /**
     * 📤 导出训练数据
     */
    private suspend fun exportTrainingData() {
        LogManager.i(TAG, "📤 导出训练数据...")
        // 实现数据导出逻辑
    }
    
    /**
     * 📡 发送HTTP请求
     */
    private suspend fun sendToAPI(
        endpoint: String,
        data: JSONObject?,
        method: String = "POST"
    ): String? = withContext(Dispatchers.IO) {
        
        if (config.apiEndpoint.isBlank()) {
            LogManager.i(TAG, "API端点未配置，跳过发送")
            return@withContext null
        }
        
        var retries = 0
        while (retries < MAX_RETRY_COUNT) {
            try {
                val url = URL(endpoint)
                val connection = url.openConnection() as HttpURLConnection
                
                connection.apply {
                    requestMethod = method
                    setRequestProperty("Content-Type", "application/json")
                    config.apiKey?.let { 
                        setRequestProperty("Authorization", "Bearer $it")
                    }
                    connectTimeout = TIMEOUT_MS
                    readTimeout = TIMEOUT_MS
                    doOutput = method == "POST"
                }
                
                if (method == "POST" && data != null) {
                    OutputStreamWriter(connection.outputStream).use { writer ->
                        writer.write(data.toString())
                    }
                }
                
                val responseCode = connection.responseCode
                
                return@withContext if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader(InputStreamReader(connection.inputStream)).use { reader ->
                        reader.readText()
                    }
                } else {
                    LogManager.w(TAG, "API响应: $responseCode")
                    null
                }
                
            } catch (e: Exception) {
                LogManager.e(TAG, "API请求失败 (尝试 ${retries + 1}): ${e.message}")
                retries++
                if (retries < MAX_RETRY_COUNT) {
                    delay(1000L * retries)  // 指数退避
                }
            }
        }
        
        null
    }
    
    /**
     * 🔑 获取设备ID
     */
    private fun getDeviceId(): String {
        val prefs = context.getSharedPreferences("xihe_monitor", Context.MODE_PRIVATE)
        var deviceId = prefs.getString("device_id", null)
        
        if (deviceId == null) {
            deviceId = "xihe_${System.currentTimeMillis()}_${(Math.random() * 10000).toInt()}"
            prefs.edit().putString("device_id", deviceId).apply()
        }
        
        return deviceId
    }
    
    /**
     * 📊 手动上报训练日志
     */
    suspend fun reportTrainingLog(
        level: LogLevel,
        message: String,
        metadata: Map<String, Any>? = null
    ) {
        val logJson = JSONObject().apply {
            put("device_id", getDeviceId())
            put("timestamp", System.currentTimeMillis())
            put("level", level.name)
            put("message", message)
            metadata?.let { put("metadata", JSONObject(it)) }
        }
        
        sendToAPI(config.apiEndpoint + "/training/logs", logJson)
    }
    
    /**
     * 📈 上报训练里程碑
     */
    suspend fun reportMilestone(
        type: MilestoneType,
        details: Map<String, Any>
    ) {
        val milestoneJson = JSONObject().apply {
            put("device_id", getDeviceId())
            put("timestamp", System.currentTimeMillis())
            put("type", type.name)
            put("details", JSONObject(details))
        }
        
        sendToAPI(config.apiEndpoint + "/training/milestones", milestoneJson)
    }
}

// ==================== 数据类 ====================

/**
 * API监控配置
 */
data class APIMonitorConfig(
    val apiEndpoint: String = "",
    val apiKey: String? = null,
    val reportIntervalMs: Long = 5000L,
    val pollIntervalMs: Long = 3000L,
    val enableRemoteControl: Boolean = true,
    val aiApiEndpoint: String = "https://api.openai.com/v1/chat/completions",
    val aiApiKey: String = "",
    val aiModel: String = "gpt-3.5-turbo"
)

/**
 * 监控状态
 */
enum class MonitorState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    ERROR
}

/**
 * 连接状态
 */
data class ConnectionStatus(
    val lastReportTime: Long = 0,
    val successfulReports: Int = 0,
    val failedAttempts: Int = 0,
    val lastError: String? = null
)

/**
 * 远程指令
 */
data class RemoteCommand(
    val type: CommandType,
    val params: JSONObject? = null,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * 指令类型
 */
enum class CommandType {
    START_TRAINING,
    STOP_TRAINING,
    ADJUST_PARAMS,
    GET_STATUS,
    EXPORT_DATA,
    AI_ANALYZE
}

/**
 * AI分析结果
 */
sealed class AIAnalysisResult {
    data class Success(val analysis: AIAnalysis) : AIAnalysisResult()
    data class Error(val message: String) : AIAnalysisResult()
}

/**
 * AI分析内容
 */
data class AIAnalysis(
    val status: String,
    val shouldContinue: Boolean,
    val suggestions: List<String>,
    val warnings: List<String>,
    val parameterAdjustments: Map<String, Any>,
    val rawAnalysis: String
)

/**
 * 日志级别
 */
enum class LogLevel {
    DEBUG, INFO, WARN, ERROR
}

/**
 * 里程碑类型
 */
enum class MilestoneType {
    TRAINING_STARTED,
    EPOCH_COMPLETED,
    TRAINING_COMPLETED,
    MODEL_SAVED,
    ERROR_OCCURRED
}
