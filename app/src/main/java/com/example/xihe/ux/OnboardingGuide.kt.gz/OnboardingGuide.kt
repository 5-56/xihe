package com.example.xihe.ux

import android.content.Context
import android.content.SharedPreferences
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * 🎓 新手引导系统
 * 提供功能使用引导、任务创建引导、操作演示等
 */
class OnboardingGuide(private val context: Context) {
    
    companion object {
        private const val TAG = "OnboardingGuide"
        private const val PREFS_NAME = "onboarding_prefs"
        
        @Volatile
        private var instance: OnboardingGuide? = null
        
        fun getInstance(context: Context): OnboardingGuide {
            return instance ?: synchronized(this) {
                instance ?: OnboardingGuide(context.applicationContext).also { instance = it }
            }
        }
    }
    
    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    
    // 当前引导状态
    private val _currentGuide = MutableStateFlow<GuideStep?>(null)
    val currentGuide: StateFlow<GuideStep?> = _currentGuide
    
    // 是否首次使用
    val isFirstTime: Boolean
        get() = prefs.getBoolean("is_first_time", true)
    
    // ==================== 📊 数据类 ====================
    
    /**
     * 📍 引导步骤
     */
    data class GuideStep(
        val id: String,
        val title: String,
        val description: String,
        val illustration: GuideIllustration? = null,
        val highlightTarget: HighlightTarget? = null,
        val action: GuideAction? = null,
        val stepNumber: Int,
        val totalSteps: Int,
        val canSkip: Boolean = true
    )
    
    /**
     * 🖼️ 引导插图
     */
    data class GuideIllustration(
        val type: IllustrationType,
        val resourceId: Int? = null,
        val emoji: String? = null
    )
    
    enum class IllustrationType {
        IMAGE,      // 图片
        ANIMATION,  // 动画
        EMOJI       // 表情
    }
    
    /**
     * 🎯 高亮目标
     */
    data class HighlightTarget(
        val viewId: String,
        val shape: HighlightShape = HighlightShape.CIRCLE,
        val padding: Int = 8
    )
    
    enum class HighlightShape {
        CIRCLE,     // 圆形
        RECTANGLE,  // 矩形
        ROUNDED     // 圆角矩形
    }
    
    /**
     * ▶️ 引导动作
     */
    data class GuideAction(
        val label: String,
        val action: GuideActionType
    )
    
    enum class GuideActionType {
        NEXT,           // 下一步
        TRY_IT,         // 试一试
        SKIP,           // 跳过
        FINISH,         // 完成
        OPEN_SETTINGS   // 打开设置
    }
    
    /**
     * 📚 引导流程
     */
    data class GuideFlow(
        val id: String,
        val name: String,
        val steps: List<GuideStepTemplate>,
        val completed: Boolean = false
    )
    
    /**
     * 📝 引导步骤模板
     */
    data class GuideStepTemplate(
        val id: String,
        val title: String,
        val description: String,
        val emoji: String? = null,
        val highlightViewId: String? = null,
        val actionType: GuideActionType = GuideActionType.NEXT
    )
    
    // ==================== 📚 预定义引导流程 ====================
    
    /**
     * 🎬 欢迎引导
     */
    private val welcomeFlow = GuideFlow(
        id = "welcome",
        name = "欢迎使用羲和",
        steps = listOf(
            GuideStepTemplate(
                id = "welcome_1",
                title = "👋 欢迎使用羲和！",
                description = "我是你的智能助手，可以帮你自动操作手机、发消息、搜索信息等。让我来介绍一下吧！",
                emoji = "🎉"
            ),
            GuideStepTemplate(
                id = "welcome_2",
                title = "🎤 语音交互",
                description = "你可以通过语音和我对话，说出你想做的事情，比如「给张三发微信说晚上见」",
                emoji = "🎤"
            ),
            GuideStepTemplate(
                id = "welcome_3",
                title = "⌨️ 文字输入",
                description = "也可以在输入框中直接打字告诉我你的需求",
                emoji = "⌨️"
            ),
            GuideStepTemplate(
                id = "welcome_4",
                title = "🔧 无障碍权限",
                description = "为了帮你自动操作手机，我需要开启无障碍服务权限。点击下方按钮去设置吧！",
                emoji = "🔧",
                actionType = GuideActionType.OPEN_SETTINGS
            ),
            GuideStepTemplate(
                id = "welcome_5",
                title = "✅ 准备就绪！",
                description = "太棒了！现在你可以开始使用羲和了。试着说「你好」和我打个招呼吧！",
                emoji = "🚀",
                actionType = GuideActionType.FINISH
            )
        )
    )
    
    /**
     * 📱 消息发送引导
     */
    private val messageGuideFlow = GuideFlow(
        id = "message_guide",
        name = "发送消息教程",
        steps = listOf(
            GuideStepTemplate(
                id = "msg_1",
                title = "📱 发送消息",
                description = "我可以帮你自动发送微信、QQ等消息",
                emoji = "📱"
            ),
            GuideStepTemplate(
                id = "msg_2",
                title = "📝 告诉我联系人",
                description = "你可以说：\n• 给张三发微信说晚上见\n• 微信发给妈妈：我到家了\n• 发消息给李四说明天开会",
                emoji = "📝"
            ),
            GuideStepTemplate(
                id = "msg_3",
                title = "🔄 自动执行",
                description = "我会自动打开应用、搜索联系人、输入消息并发送",
                emoji = "🔄"
            ),
            GuideStepTemplate(
                id = "msg_4",
                title = "✅ 试一试",
                description = "现在试着说「给xxx发微信说你好」吧！",
                emoji = "✅",
                actionType = GuideActionType.TRY_IT
            )
        )
    )
    
    /**
     * 🌐 搜索引导
     */
    private val searchGuideFlow = GuideFlow(
        id = "search_guide",
        name = "搜索功能教程",
        steps = listOf(
            GuideStepTemplate(
                id = "search_1",
                title = "🔍 智能搜索",
                description = "我可以帮你搜索任何信息",
                emoji = "🔍"
            ),
            GuideStepTemplate(
                id = "search_2",
                title = "📝 搜索指令",
                description = "你可以说：\n• 搜索今天天气\n• 百度一下附近的餐厅\n• 抖音搜索搞笑视频",
                emoji = "📝"
            ),
            GuideStepTemplate(
                id = "search_3",
                title = "✅ 试一试",
                description = "说「搜索今天新闻」试试看！",
                emoji = "✅",
                actionType = GuideActionType.TRY_IT
            )
        )
    )
    
    /**
     * 📋 所有引导流程
     */
    private val allFlows = listOf(welcomeFlow, messageGuideFlow, searchGuideFlow)
    
    // ==================== 🎬 引导控制 ====================
    
    /**
     * 🎬 开始欢迎引导
     */
    fun startWelcomeGuide() {
        if (!isFirstTime) return
        startFlow(welcomeFlow)
    }
    
    /**
     * 🎬 开始指定引导
     */
    fun startGuide(flowId: String) {
        val flow = allFlows.find { it.id == flowId }
        if (flow != null) {
            startFlow(flow)
        }
    }
    
    /**
     * ▶️ 开始流程
     */
    private var currentFlow: GuideFlow? = null
    private var currentStepIndex = 0
    
    private fun startFlow(flow: GuideFlow) {
        LogManager.d(TAG, "🎬 开始引导: ${flow.name}")
        currentFlow = flow
        currentStepIndex = 0
        showStep(0)
    }
    
    /**
     * 📍 显示步骤
     */
    private fun showStep(index: Int) {
        val flow = currentFlow ?: return
        if (index >= flow.steps.size) {
            completeFlow()
            return
        }
        
        val template = flow.steps[index]
        val step = GuideStep(
            id = template.id,
            title = template.title,
            description = template.description,
            illustration = template.emoji?.let { 
                GuideIllustration(IllustrationType.EMOJI, emoji = it) 
            },
            highlightTarget = template.highlightViewId?.let { 
                HighlightTarget(it) 
            },
            action = GuideAction(
                label = when (template.actionType) {
                    GuideActionType.NEXT -> "下一步"
                    GuideActionType.TRY_IT -> "试一试"
                    GuideActionType.SKIP -> "跳过"
                    GuideActionType.FINISH -> "完成"
                    GuideActionType.OPEN_SETTINGS -> "去设置"
                },
                action = template.actionType
            ),
            stepNumber = index + 1,
            totalSteps = flow.steps.size
        )
        
        _currentGuide.value = step
        currentStepIndex = index
    }
    
    /**
     * ➡️ 下一步
     */
    fun nextStep() {
        showStep(currentStepIndex + 1)
    }
    
    /**
     * ⬅️ 上一步
     */
    fun previousStep() {
        if (currentStepIndex > 0) {
            showStep(currentStepIndex - 1)
        }
    }
    
    /**
     * ⏭️ 跳过引导
     */
    fun skipGuide() {
        completeFlow()
    }
    
    /**
     * ✅ 完成流程
     */
    private fun completeFlow() {
        val flow = currentFlow ?: return
        
        LogManager.d(TAG, "✅ 引导完成: ${flow.name}")
        
        // 标记完成
        prefs.edit().apply {
            putBoolean("flow_${flow.id}_completed", true)
            if (flow.id == "welcome") {
                putBoolean("is_first_time", false)
            }
            apply()
        }
        
        currentFlow = null
        currentStepIndex = 0
        _currentGuide.value = null
    }
    
    /**
     * 🚪 关闭引导
     */
    fun dismissGuide() {
        _currentGuide.value = null
    }
    
    // ==================== ❓ 上下文帮助 ====================
    
    /**
     * ❓ 获取上下文帮助
     */
    fun getContextHelp(context: HelpContext): List<HelpItem> {
        return when (context) {
            HelpContext.MAIN_SCREEN -> listOf(
                HelpItem("🎤 语音输入", "点击麦克风按钮开始语音输入"),
                HelpItem("⌨️ 文字输入", "在输入框中输入你的指令"),
                HelpItem("📜 历史记录", "向上滑动查看对话历史")
            )
            HelpContext.VOICE_INPUT -> listOf(
                HelpItem("🗣️ 清晰说话", "在安静环境下清晰说出指令"),
                HelpItem("⏸️ 停顿", "说完后稍等片刻，我会自动识别")
            )
            HelpContext.TASK_EXECUTION -> listOf(
                HelpItem("⏸️ 暂停", "点击暂停按钮可以暂停任务"),
                HelpItem("❌ 取消", "点击取消按钮可以终止任务"),
                HelpItem("📊 进度", "查看当前执行进度和状态")
            )
            HelpContext.SETTINGS -> listOf(
                HelpItem("🔧 无障碍", "开启无障碍服务才能自动操作"),
                HelpItem("🔊 语音", "调整语音识别和语音播报设置"),
                HelpItem("🔔 通知", "管理任务完成通知")
            )
            HelpContext.ERROR -> listOf(
                HelpItem("🔄 重试", "点击重试按钮再次尝试"),
                HelpItem("🔧 检查设置", "确保无障碍服务已开启"),
                HelpItem("📱 检查应用", "确保目标应用已安装")
            )
        }
    }
    
    /**
     * 📚 获取常见问题
     */
    fun getFAQ(): List<FAQItem> {
        return listOf(
            FAQItem(
                question = "为什么需要开启无障碍服务？",
                answer = "无障碍服务让我能够读取屏幕内容和模拟操作，这是自动化功能的基础。你的隐私数据我不会收集。"
            ),
            FAQItem(
                question = "支持哪些应用？",
                answer = "支持微信、QQ、抖音、淘宝、浏览器等常用应用。其他应用也可以尝试，但可能兼容性有限。"
            ),
            FAQItem(
                question = "发消息失败怎么办？",
                answer = "1. 确保无障碍服务已开启\n2. 确保目标应用已安装且登录\n3. 确保联系人名字正确\n4. 尝试重新执行"
            ),
            FAQItem(
                question = "如何停止正在执行的任务？",
                answer = "可以说「停止」或「取消」，或者点击屏幕上的取消按钮。"
            ),
            FAQItem(
                question = "会不会误操作？",
                answer = "涉及支付、删除等敏感操作时，我会先征求你的确认。你可以在设置中调整安全级别。"
            )
        )
    }
    
    // ==================== 📊 状态查询 ====================
    
    /**
     * ✅ 检查引导是否完成
     */
    fun isFlowCompleted(flowId: String): Boolean {
        return prefs.getBoolean("flow_${flowId}_completed", false)
    }
    
    /**
     * 🔄 重置所有引导
     */
    fun resetAllGuides() {
        prefs.edit().clear().apply()
        LogManager.d(TAG, "🔄 所有引导已重置")
    }
}

/**
 * 📍 帮助上下文
 */
enum class HelpContext {
    MAIN_SCREEN,        // 主屏幕
    VOICE_INPUT,        // 语音输入
    TASK_EXECUTION,     // 任务执行
    SETTINGS,           // 设置
    ERROR               // 错误
}

/**
 * ❓ 帮助项
 */
data class HelpItem(
    val title: String,
    val description: String
)

/**
 * 📚 FAQ项
 */
data class FAQItem(
    val question: String,
    val answer: String
)
