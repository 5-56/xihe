package com.example.xihe.ux

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import com.example.xihe.utils.LogManager
import com.example.xihe.core.ModuleCoordinator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

/**
 * 🎯 用户反馈管理器
 * 提供实时状态反馈、操作结果提示、友好错误提示等功能
 */
class UserFeedbackManager(private val context: Context) {
    
    companion object {
        private const val TAG = "UserFeedbackManager"
        
        @Volatile
        private var instance: UserFeedbackManager? = null
        
        fun getInstance(context: Context): UserFeedbackManager {
            return instance ?: synchronized(this) {
                instance ?: UserFeedbackManager(context.applicationContext).also { instance = it }
            }
        }
    }
    
    // TTS 引擎
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    
    // 振动器
    private val vibrator: Vibrator? by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }
    
    // 当前反馈状态
    private val _currentFeedback = MutableStateFlow<FeedbackMessage?>(null)
    val currentFeedback: StateFlow<FeedbackMessage?> = _currentFeedback
    
    // 反馈历史
    private val feedbackHistory = mutableListOf<FeedbackMessage>()
    
    // 配置
    var enableVoice = true
    var enableVibration = true
    var enableVisual = true
    
    init {
        initTTS()
    }
    
    // ==================== 📊 数据类 ====================
    
    /**
     * 💬 反馈消息
     */
    data class FeedbackMessage(
        val id: String = java.util.UUID.randomUUID().toString(),
        val type: FeedbackType,
        val title: String,
        val message: String,
        val timestamp: Long = System.currentTimeMillis(),
        val duration: Long = 3000,
        val actionable: Boolean = false,
        val action: FeedbackAction? = null
    )
    
    /**
     * 🏷️ 反馈类型
     */
    enum class FeedbackType {
        SUCCESS,        // 成功
        ERROR,          // 错误
        WARNING,        // 警告
        INFO,           // 信息
        PROGRESS,       // 进度
        CONFIRMATION,   // 确认
        CELEBRATION     // 庆祝
    }
    
    /**
     * ▶️ 反馈动作
     */
    data class FeedbackAction(
        val label: String,
        val action: () -> Unit
    )
    
    /**
     * 📳 振动模式
     */
    enum class VibrationPattern {
        LIGHT,          // 轻触
        MEDIUM,         // 中等
        STRONG,         // 强烈
        SUCCESS,        // 成功
        ERROR,          // 错误
        WARNING,        // 警告
        DOUBLE_TAP      // 双击
    }
    
    // ==================== 🔊 TTS 初始化 ====================
    
    /**
     * 🔊 初始化TTS
     */
    private fun initTTS() {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val result = tts?.setLanguage(Locale.CHINESE)
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA && 
                          result != TextToSpeech.LANG_NOT_SUPPORTED
                LogManager.d(TAG, "🔊 TTS 初始化: $ttsReady")
            }
        }
    }
    
    // ==================== ✅ 成功反馈 ====================
    
    /**
     * ✅ 显示成功反馈
     */
    fun showSuccess(
        title: String = "操作成功",
        message: String,
        celebrate: Boolean = false
    ) {
        val feedback = FeedbackMessage(
            type = if (celebrate) FeedbackType.CELEBRATION else FeedbackType.SUCCESS,
            title = title,
            message = message,
            duration = if (celebrate) 4000 else 2500
        )
        
        showFeedback(feedback)
        
        if (enableVibration) {
            vibrate(if (celebrate) VibrationPattern.SUCCESS else VibrationPattern.LIGHT)
        }
        
        if (enableVoice && celebrate) {
            speak("太棒了！$message")
        }
    }
    
    /**
     * 🎉 显示庆祝动画
     */
    fun celebrate(message: String) {
        showSuccess(title = "🎉 太棒了！", message = message, celebrate = true)
    }
    
    // ==================== ❌ 错误反馈 ====================
    
    /**
     * ❌ 显示错误反馈
     */
    fun showError(
        title: String = "操作失败",
        message: String,
        suggestion: String? = null,
        retryAction: (() -> Unit)? = null
    ) {
        val fullMessage = if (suggestion != null) {
            "$message\n💡 建议: $suggestion"
        } else {
            message
        }
        
        val feedback = FeedbackMessage(
            type = FeedbackType.ERROR,
            title = title,
            message = fullMessage,
            duration = 4000,
            actionable = retryAction != null,
            action = retryAction?.let { FeedbackAction("重试", it) }
        )
        
        showFeedback(feedback)
        
        if (enableVibration) {
            vibrate(VibrationPattern.ERROR)
        }
    }
    
    /**
     * 🔄 显示可重试的错误
     */
    fun showRetryableError(
        message: String,
        onRetry: () -> Unit
    ) {
        showError(
            title = "操作失败",
            message = message,
            suggestion = "点击重试按钮再次尝试",
            retryAction = onRetry
        )
    }
    
    // ==================== ⚠️ 警告反馈 ====================
    
    /**
     * ⚠️ 显示警告
     */
    fun showWarning(
        title: String = "注意",
        message: String,
        duration: Long = 3500
    ) {
        val feedback = FeedbackMessage(
            type = FeedbackType.WARNING,
            title = title,
            message = message,
            duration = duration
        )
        
        showFeedback(feedback)
        
        if (enableVibration) {
            vibrate(VibrationPattern.WARNING)
        }
    }
    
    // ==================== ℹ️ 信息反馈 ====================
    
    /**
     * ℹ️ 显示信息
     */
    fun showInfo(
        title: String = "提示",
        message: String,
        duration: Long = 3000
    ) {
        val feedback = FeedbackMessage(
            type = FeedbackType.INFO,
            title = title,
            message = message,
            duration = duration
        )
        
        showFeedback(feedback)
    }
    
    // ==================== 📊 进度反馈 ====================
    
    /**
     * 📊 显示进度
     */
    fun showProgress(
        title: String,
        message: String,
        progress: Float? = null
    ) {
        val progressText = progress?.let { " (${(it * 100).toInt()}%)" } ?: ""
        
        val feedback = FeedbackMessage(
            type = FeedbackType.PROGRESS,
            title = title,
            message = "$message$progressText",
            duration = 0 // 进度消息不自动消失
        )
        
        showFeedback(feedback)
    }
    
    /**
     * ✅ 更新进度为完成
     */
    fun completeProgress(message: String) {
        showSuccess(title = "完成", message = message, celebrate = true)
    }
    
    // ==================== ❓ 确认反馈 ====================
    
    /**
     * ❓ 请求确认
     */
    fun requestConfirmation(
        title: String,
        message: String,
        onConfirm: () -> Unit,
        onCancel: (() -> Unit)? = null
    ) {
        val feedback = FeedbackMessage(
            type = FeedbackType.CONFIRMATION,
            title = title,
            message = message,
            duration = 0, // 不自动消失
            actionable = true,
            action = FeedbackAction("确认", onConfirm)
        )
        
        showFeedback(feedback)
        
        if (enableVibration) {
            vibrate(VibrationPattern.DOUBLE_TAP)
        }
    }
    
    // ==================== 🔧 核心方法 ====================
    
    /**
     * 📣 显示反馈
     */
    private fun showFeedback(feedback: FeedbackMessage) {
        _currentFeedback.value = feedback
        
        feedbackHistory.add(feedback)
        if (feedbackHistory.size > 50) {
            feedbackHistory.removeAt(0)
        }
        
        LogManager.d(TAG, "📣 反馈: [${feedback.type}] ${feedback.title} - ${feedback.message}")
    }
    
    /**
     * 🔇 清除当前反馈
     */
    fun clearFeedback() {
        _currentFeedback.value = null
    }
    
    /**
     * 📳 振动
     */
    fun vibrate(pattern: VibrationPattern) {
        if (!enableVibration) return
        
        vibrator?.let { v ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val effect = when (pattern) {
                    VibrationPattern.LIGHT -> VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE)
                    VibrationPattern.MEDIUM -> VibrationEffect.createOneShot(100, VibrationEffect.DEFAULT_AMPLITUDE)
                    VibrationPattern.STRONG -> VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE)
                    VibrationPattern.SUCCESS -> VibrationEffect.createWaveform(longArrayOf(0, 50, 50, 100), -1)
                    VibrationPattern.ERROR -> VibrationEffect.createWaveform(longArrayOf(0, 100, 100, 100, 100, 100), -1)
                    VibrationPattern.WARNING -> VibrationEffect.createWaveform(longArrayOf(0, 80, 80, 80), -1)
                    VibrationPattern.DOUBLE_TAP -> VibrationEffect.createWaveform(longArrayOf(0, 50, 100, 50), -1)
                }
                v.vibrate(effect)
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(100)
            }
        }
    }
    
    /**
     * 🔊 语音播报
     */
    fun speak(text: String, interrupt: Boolean = true) {
        if (!enableVoice || !ttsReady) return

        if (ModuleCoordinator.isModuleAvailable("Voice")) {
            ModuleCoordinator.speak(text)
            return
        }
        
        val queueMode = if (interrupt) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
        tts?.speak(text, queueMode, null, "feedback_${System.currentTimeMillis()}")
    }
    
    /**
     * 🔇 停止语音
     */
    fun stopSpeaking() {
        tts?.stop()
    }
    
    // ==================== 📋 便捷方法 ====================
    
    /**
     * 📝 任务开始反馈
     */
    fun onTaskStart(taskName: String) {
        showProgress("正在执行", taskName)
        if (enableVoice) {
            speak("开始执行$taskName")
        }
    }
    
    /**
     * ✅ 任务完成反馈
     */
    fun onTaskComplete(taskName: String) {
        celebrate("$taskName 完成")
    }
    
    /**
     * ❌ 任务失败反馈
     */
    fun onTaskFailed(taskName: String, reason: String, onRetry: (() -> Unit)? = null) {
        showError(
            title = "$taskName 失败",
            message = reason,
            retryAction = onRetry
        )
    }
    
    /**
     * 📍 步骤反馈
     */
    fun onStepProgress(stepName: String, current: Int, total: Int) {
        val progress = current.toFloat() / total
        showProgress("步骤 $current/$total", stepName, progress)
    }
    
    // ==================== 📊 历史记录 ====================
    
    /**
     * 📜 获取反馈历史
     */
    fun getFeedbackHistory(): List<FeedbackMessage> = feedbackHistory.toList()
    
    /**
     * 🧹 清空历史
     */
    fun clearHistory() {
        feedbackHistory.clear()
    }
    
    /**
     * 🛑 销毁
     */
    fun destroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
