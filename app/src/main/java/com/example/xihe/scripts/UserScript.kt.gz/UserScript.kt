package com.example.xihe.scripts

import kotlinx.serialization.Serializable
import java.util.UUID

/**
 * 🎬 用户自定义脚本
 * 
 * 保存用户满意的任务执行脚本，支持：
 * - 调节每个动作的执行时间和等待时间
 * - 设置循环次数
 * - 自定义循环起点
 * - 排除试错步骤
 */
@Serializable
data class UserScript(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val description: String = "",
    val appPackage: String,
    val appName: String,
    val category: ScriptCategory,
    val steps: List<ScriptStep>,
    val loopConfig: LoopConfig = LoopConfig(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val executionCount: Int = 0,
    val lastExecutedAt: Long? = null,
    val isFavorite: Boolean = false,
    val tags: List<String> = emptyList()
)

/**
 * 脚本类别
 */
@Serializable
enum class ScriptCategory {
    MESSAGE,        // 发消息
    VIDEO,          // 刷视频
    SEARCH,         // 搜索资料
    SHOPPING,       // 购物
    SOCIAL,         // 社交
    GAME,           // 游戏
    OFFICE,         // 办公
    CUSTOM          // 自定义
}

/**
 * 脚本步骤
 */
@Serializable
data class ScriptStep(
    val id: String = UUID.randomUUID().toString(),
    val order: Int,
    val name: String,
    val description: String,
    val actionType: ScriptActionType,
    val targetSelector: TargetSelector? = null,
    val inputText: String? = null,
    val timing: StepTiming = StepTiming(),
    val isEnabled: Boolean = true,
    val isLoopStart: Boolean = false,
    val conditions: List<StepCondition> = emptyList(),
    val onFailure: FailureAction = FailureAction.RETRY
)

/**
 * 脚本动作类型
 */
@Serializable
enum class ScriptActionType {
    LAUNCH_APP,         // 启动应用
    CLICK,              // 点击
    LONG_CLICK,         // 长按
    INPUT_TEXT,         // 输入文本
    SWIPE_UP,           // 上滑
    SWIPE_DOWN,         // 下滑
    SWIPE_LEFT,         // 左滑
    SWIPE_RIGHT,        // 右滑
    SCROLL,             // 滚动
    PRESS_BACK,         // 返回
    PRESS_HOME,         // Home键
    WAIT,               // 等待
    WAIT_FOR_ELEMENT,   // 等待元素出现
    CLOSE_POPUP,        // 关闭弹窗
    TAKE_SCREENSHOT,    // 截图
    CUSTOM_GESTURE      // 自定义手势
}

/**
 * 目标选择器 - 用于定位界面元素
 */
@Serializable
data class TargetSelector(
    val type: SelectorType,
    val value: String,
    val alternativeValues: List<String> = emptyList(),
    val index: Int = 0,
    val matchMode: MatchMode = MatchMode.CONTAINS
)

/**
 * 选择器类型
 */
@Serializable
enum class SelectorType {
    TEXT,               // 按文本
    CONTENT_DESCRIPTION,// 按描述
    RESOURCE_ID,        // 按资源ID
    CLASS_NAME,         // 按类名
    BOUNDS,             // 按坐标范围
    XPATH               // XPath
}

/**
 * 匹配模式
 */
@Serializable
enum class MatchMode {
    EXACT,              // 精确匹配
    CONTAINS,           // 包含
    STARTS_WITH,        // 开头匹配
    ENDS_WITH,          // 结尾匹配
    REGEX,              // 正则匹配
    FUZZY               // 模糊匹配
}

/**
 * 步骤时间配置
 */
@Serializable
data class StepTiming(
    val executionDuration: Long = 300,      // 执行时长(ms)
    val waitBefore: Long = 0,               // 执行前等待(ms)
    val waitAfter: Long = 500,              // 执行后等待(ms)
    val timeout: Long = 10000,              // 超时时间(ms)
    val randomDelay: Boolean = false,       // 是否随机延迟
    val randomDelayMin: Long = 0,           // 随机延迟最小值
    val randomDelayMax: Long = 1000         // 随机延迟最大值
)

/**
 * 步骤条件
 */
@Serializable
data class StepCondition(
    val type: ConditionType,
    val selector: TargetSelector? = null,
    val expectedValue: String? = null,
    val negate: Boolean = false
)

/**
 * 条件类型
 */
@Serializable
enum class ConditionType {
    ELEMENT_EXISTS,     // 元素存在
    ELEMENT_VISIBLE,    // 元素可见
    ELEMENT_CLICKABLE,  // 元素可点击
    TEXT_EQUALS,        // 文本相等
    TEXT_CONTAINS,      // 文本包含
    APP_FOREGROUND      // 应用在前台
}

/**
 * 失败处理方式
 */
@Serializable
enum class FailureAction {
    RETRY,              // 重试
    SKIP,               // 跳过
    STOP,               // 停止脚本
    GOTO_STEP,          // 跳转到指定步骤
    ASK_USER            // 询问用户
}

/**
 * 循环配置
 */
@Serializable
data class LoopConfig(
    val enabled: Boolean = false,
    val loopCount: Int = 1,                 // 循环次数，-1表示无限循环
    val loopStartStepId: String? = null,    // 循环起点步骤ID，null表示从头开始
    val loopEndStepId: String? = null,      // 循环终点步骤ID，null表示到末尾
    val loopInterval: Long = 0,             // 每轮循环间隔(ms)
    val stopCondition: StopCondition? = null // 停止条件
)

/**
 * 停止条件
 */
@Serializable
data class StopCondition(
    val type: StopConditionType,
    val value: String
)

/**
 * 停止条件类型
 */
@Serializable
enum class StopConditionType {
    TIME_ELAPSED,       // 运行时间
    LOOP_COUNT,         // 循环次数
    ELEMENT_FOUND,      // 找到元素
    ELEMENT_NOT_FOUND,  // 元素消失
    USER_INTERRUPT      // 用户中断
}

/**
 * 脚本执行记录
 */
@Serializable
data class ScriptExecutionRecord(
    val scriptId: String,
    val scriptName: String,
    val startTime: Long,
    val endTime: Long? = null,
    val status: ExecutionStatus = ExecutionStatus.RUNNING,
    val stepsExecuted: Int = 0,
    val loopsCompleted: Int = 0,
    val errorMessage: String? = null,
    val stepRecords: List<StepExecutionRecord> = emptyList()
)

/**
 * 执行状态
 */
@Serializable
enum class ExecutionStatus {
    RUNNING,
    COMPLETED,
    FAILED,
    CANCELLED,
    PAUSED
}

/**
 * 步骤执行记录
 */
@Serializable
data class StepExecutionRecord(
    val stepId: String,
    val stepName: String,
    val startTime: Long,
    val endTime: Long,
    val success: Boolean,
    val retryCount: Int = 0,
    val errorMessage: String? = null
)

/**
 * 脚本录制状态
 */
data class RecordingState(
    val isRecording: Boolean = false,
    val scriptName: String = "",
    val appPackage: String = "",
    val recordedSteps: MutableList<ScriptStep> = mutableListOf(),
    val startTime: Long = 0,
    val currentStepOrder: Int = 0
)

/**
 * 脚本模板 - 预定义的常用脚本
 */
object ScriptTemplates {
    
    fun getWeChatMessageTemplate(contactName: String, message: String): UserScript {
        return UserScript(
            name = "微信发消息给$contactName",
            appPackage = "com.tencent.mm",
            appName = "微信",
            category = ScriptCategory.MESSAGE,
            steps = listOf(
                ScriptStep(
                    order = 1,
                    name = "启动微信",
                    description = "打开微信应用",
                    actionType = ScriptActionType.LAUNCH_APP,
                    timing = StepTiming(waitAfter = 3000)
                ),
                ScriptStep(
                    order = 2,
                    name = "点击搜索",
                    description = "点击搜索按钮",
                    actionType = ScriptActionType.CLICK,
                    targetSelector = TargetSelector(SelectorType.TEXT, "搜索", listOf("Search", "🔍")),
                    timing = StepTiming(waitAfter = 500)
                ),
                ScriptStep(
                    order = 3,
                    name = "输入联系人",
                    description = "输入联系人名称",
                    actionType = ScriptActionType.INPUT_TEXT,
                    inputText = contactName,
                    timing = StepTiming(waitAfter = 1500)
                ),
                ScriptStep(
                    order = 4,
                    name = "点击联系人",
                    description = "从搜索结果点击联系人",
                    actionType = ScriptActionType.CLICK,
                    targetSelector = TargetSelector(SelectorType.TEXT, contactName, matchMode = MatchMode.FUZZY),
                    timing = StepTiming(waitAfter = 1000)
                ),
                ScriptStep(
                    order = 5,
                    name = "点击输入框",
                    description = "点击消息输入框",
                    actionType = ScriptActionType.CLICK,
                    targetSelector = TargetSelector(SelectorType.TEXT, "请输入", listOf("发消息")),
                    timing = StepTiming(waitAfter = 300)
                ),
                ScriptStep(
                    order = 6,
                    name = "输入消息",
                    description = "输入要发送的消息",
                    actionType = ScriptActionType.INPUT_TEXT,
                    inputText = message,
                    timing = StepTiming(waitAfter = 300)
                ),
                ScriptStep(
                    order = 7,
                    name = "发送消息",
                    description = "点击发送按钮",
                    actionType = ScriptActionType.CLICK,
                    targetSelector = TargetSelector(SelectorType.TEXT, "发送", listOf("Send")),
                    timing = StepTiming(waitAfter = 500)
                )
            )
        )
    }
    
    fun getDouyinWatchTemplate(videoCount: Int, watchDuration: Long): UserScript {
        return UserScript(
            name = "抖音刷${videoCount}个视频",
            appPackage = "com.ss.android.ugc.aweme",
            appName = "抖音",
            category = ScriptCategory.VIDEO,
            steps = listOf(
                ScriptStep(
                    order = 1,
                    name = "启动抖音",
                    description = "打开抖音应用",
                    actionType = ScriptActionType.LAUNCH_APP,
                    timing = StepTiming(waitAfter = 3000)
                ),
                ScriptStep(
                    order = 2,
                    name = "观看视频",
                    description = "观看当前视频",
                    actionType = ScriptActionType.WAIT,
                    timing = StepTiming(executionDuration = watchDuration, randomDelay = true, randomDelayMin = -2000, randomDelayMax = 3000),
                    isLoopStart = true
                ),
                ScriptStep(
                    order = 3,
                    name = "滑动下一个",
                    description = "上滑切换到下一个视频",
                    actionType = ScriptActionType.SWIPE_UP,
                    timing = StepTiming(executionDuration = 300, waitAfter = 500)
                )
            ),
            loopConfig = LoopConfig(
                enabled = true,
                loopCount = videoCount,
                loopStartStepId = null // 将在保存时设置为步骤2的ID
            )
        )
    }
    
    fun getTaobaoSearchTemplate(productName: String): UserScript {
        return UserScript(
            name = "淘宝搜索$productName",
            appPackage = "com.taobao.taobao",
            appName = "淘宝",
            category = ScriptCategory.SHOPPING,
            steps = listOf(
                ScriptStep(
                    order = 1,
                    name = "启动淘宝",
                    description = "打开淘宝应用",
                    actionType = ScriptActionType.LAUNCH_APP,
                    timing = StepTiming(waitAfter = 3000)
                ),
                ScriptStep(
                    order = 2,
                    name = "关闭弹窗",
                    description = "关闭可能出现的弹窗",
                    actionType = ScriptActionType.CLOSE_POPUP,
                    timing = StepTiming(waitAfter = 500)
                ),
                ScriptStep(
                    order = 3,
                    name = "点击搜索",
                    description = "点击搜索框",
                    actionType = ScriptActionType.CLICK,
                    targetSelector = TargetSelector(SelectorType.TEXT, "搜索", listOf("搜索宝贝", "🔍")),
                    timing = StepTiming(waitAfter = 500)
                ),
                ScriptStep(
                    order = 4,
                    name = "输入商品",
                    description = "输入要搜索的商品名称",
                    actionType = ScriptActionType.INPUT_TEXT,
                    inputText = productName,
                    timing = StepTiming(waitAfter = 300)
                ),
                ScriptStep(
                    order = 5,
                    name = "搜索",
                    description = "点击搜索按钮",
                    actionType = ScriptActionType.CLICK,
                    targetSelector = TargetSelector(SelectorType.TEXT, "搜索"),
                    timing = StepTiming(waitAfter = 2000)
                )
            )
        )
    }
}
