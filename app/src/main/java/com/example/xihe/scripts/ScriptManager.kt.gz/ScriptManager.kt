package com.example.xihe.scripts

import android.content.Context
import android.view.accessibility.AccessibilityNodeInfo
import com.example.xihe.utils.LogManager
import com.example.xihe.CoreAccessibilityService
import com.example.xihe.core.AutomationEngine
import com.example.xihe.core.model.ChatMessageDisplay
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import kotlin.random.Random

/**
 * 📜 脚本管理器
 * 
 * 管理用户脚本的保存、加载、编辑和执行
 */
class ScriptManager private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "ScriptManager"
        private const val SCRIPTS_DIR = "user_scripts"
        private const val SCRIPTS_INDEX_FILE = "scripts_index.json"
        
        @Volatile
        private var instance: ScriptManager? = null
        
        fun getInstance(context: Context): ScriptManager {
            return instance ?: synchronized(this) {
                instance ?: ScriptManager(context.applicationContext).also { instance = it }
            }
        }
    }
    
    private val json = Json { 
        prettyPrint = true 
        ignoreUnknownKeys = true
        encodeDefaults = true
    }
    
    private val scriptsDir: File by lazy {
        File(context.filesDir, SCRIPTS_DIR).also { 
            if (!it.exists()) it.mkdirs() 
        }
    }
    
    // 脚本列表
    private val _scripts = MutableStateFlow<List<UserScript>>(emptyList())
    val scripts: StateFlow<List<UserScript>> = _scripts.asStateFlow()
    
    // 执行状态
    private val _executionState = MutableStateFlow<ScriptExecutionState>(ScriptExecutionState.Idle)
    val executionState: StateFlow<ScriptExecutionState> = _executionState.asStateFlow()
    
    // 录制状态
    private val _recordingState = MutableStateFlow(RecordingState())
    val recordingState: StateFlow<RecordingState> = _recordingState.asStateFlow()
    
    // 当前执行的脚本
    private val executionScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var currentExecution: Job? = null
    private var isPaused = false
    
    init {
        loadScripts()
    }
    
    // ==================== 📁 脚本存储 ====================
    
    /**
     * 加载所有脚本
     */
    private fun loadScripts() {
        try {
            val scriptFiles = scriptsDir.listFiles { file -> file.extension == "json" } ?: emptyArray()
            val loadedScripts = scriptFiles.mapNotNull { file ->
                try {
                    json.decodeFromString<UserScript>(file.readText())
                } catch (e: Exception) {
                    LogManager.e(TAG, "加载脚本失败: ${file.name}", e)
                    null
                }
            }
            _scripts.value = loadedScripts.sortedByDescending { it.updatedAt }
            LogManager.d(TAG, "📂 已加载 ${loadedScripts.size} 个脚本")
        } catch (e: Exception) {
            LogManager.e(TAG, "加载脚本列表失败", e)
        }
    }
    
    /**
     * 保存脚本
     */
    fun saveScript(script: UserScript): Boolean {
        return try {
            val updatedScript = script.copy(updatedAt = System.currentTimeMillis())
            val file = File(scriptsDir, "${script.id}.json")
            file.writeText(json.encodeToString(updatedScript))
            
            // 更新列表
            val currentList = _scripts.value.toMutableList()
            val index = currentList.indexOfFirst { it.id == script.id }
            if (index >= 0) {
                currentList[index] = updatedScript
            } else {
                currentList.add(0, updatedScript)
            }
            _scripts.value = currentList
            
            LogManager.d(TAG, "💾 脚本已保存: ${script.name}")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "保存脚本失败", e)
            false
        }
    }
    
    /**
     * 删除脚本
     */
    fun deleteScript(scriptId: String): Boolean {
        return try {
            val file = File(scriptsDir, "$scriptId.json")
            if (file.exists()) {
                file.delete()
            }
            _scripts.value = _scripts.value.filter { it.id != scriptId }
            LogManager.d(TAG, "🗑️ 脚本已删除: $scriptId")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "删除脚本失败", e)
            false
        }
    }
    
    /**
     * 获取脚本
     */
    fun getScript(scriptId: String): UserScript? {
        return _scripts.value.find { it.id == scriptId }
    }
    
    /**
     * 根据类别获取脚本
     */
    fun getScriptsByCategory(category: ScriptCategory): List<UserScript> {
        return _scripts.value.filter { it.category == category }
    }
    
    /**
     * 搜索脚本
     */
    fun searchScripts(query: String): List<UserScript> {
        val lowerQuery = query.lowercase()
        return _scripts.value.filter { script ->
            script.name.lowercase().contains(lowerQuery) ||
            script.description.lowercase().contains(lowerQuery) ||
            script.appName.lowercase().contains(lowerQuery) ||
            script.tags.any { it.lowercase().contains(lowerQuery) }
        }
    }
    
    // ==================== 🎬 脚本执行 ====================
    
    /**
     * 执行脚本
     */
    fun executeScript(
        script: UserScript,
        onProgress: (String) -> Unit = {}
    ) {
        if (_executionState.value is ScriptExecutionState.Running) {
            LogManager.w(TAG, "已有脚本正在执行")
            return
        }
        
        launchExecution {
            executeScriptInternal(script, onProgress)
        }
    }

    private fun launchExecution(block: suspend CoroutineScope.() -> Unit) {
        val job = executionScope.launch(block = block)
        currentExecution = job
        job.invokeOnCompletion {
            if (currentExecution === job) {
                currentExecution = null
            }
        }
    }
    
    private suspend fun executeScriptInternal(
        script: UserScript,
        onProgress: (String) -> Unit
    ) {
        val service = CoreAccessibilityService.instance
        if (service == null) {
            _executionState.value = ScriptExecutionState.Error("无障碍服务未启动")
            return
        }
        
        val startTime = System.currentTimeMillis()
        val stepRecords = mutableListOf<StepExecutionRecord>()
        var loopsCompleted = 0
        
        _executionState.value = ScriptExecutionState.Running(
            scriptId = script.id,
            scriptName = script.name,
            currentStep = 0,
            totalSteps = script.steps.size,
            loopCount = 0,
            message = "开始执行: ${script.name}"
        )
        
        LogManager.d(TAG, "🚀 开始执行脚本: ${script.name}")
        onProgress("开始执行: ${script.name}")
        
        try {
            val enabledSteps = script.steps.filter { it.isEnabled }
            val loopConfig = script.loopConfig
            
            // 确定循环起点和终点
            val loopStartIndex = if (loopConfig.enabled && loopConfig.loopStartStepId != null) {
                enabledSteps.indexOfFirst { it.id == loopConfig.loopStartStepId }.takeIf { it >= 0 } ?: 0
            } else 0
            
            val loopEndIndex = if (loopConfig.enabled && loopConfig.loopEndStepId != null) {
                enabledSteps.indexOfFirst { it.id == loopConfig.loopEndStepId }.takeIf { it >= 0 } ?: enabledSteps.lastIndex
            } else enabledSteps.lastIndex
            
            // 执行循环前的步骤
            for (i in 0 until loopStartIndex) {
                if (!executeStep(enabledSteps[i], i, enabledSteps.size, service, stepRecords, onProgress)) {
                    throw Exception("步骤执行失败: ${enabledSteps[i].name}")
                }
            }
            
            // 执行循环
            val loopCount = if (loopConfig.enabled) loopConfig.loopCount else 1
            val actualLoopCount = if (loopCount < 0) Int.MAX_VALUE else loopCount
            
            for (loop in 1..actualLoopCount) {
                if (_executionState.value !is ScriptExecutionState.Running) break
                
                // 检查暂停
                while (isPaused) {
                    delay(100)
                }
                
                loopsCompleted = loop
                LogManager.d(TAG, "🔄 循环 $loop/$loopCount")
                
                for (i in loopStartIndex..loopEndIndex) {
                    if (_executionState.value !is ScriptExecutionState.Running) break
                    
                    val step = enabledSteps[i]
                    _executionState.value = ScriptExecutionState.Running(
                        scriptId = script.id,
                        scriptName = script.name,
                        currentStep = i + 1,
                        totalSteps = enabledSteps.size,
                        loopCount = loop,
                        message = "步骤 ${i + 1}: ${step.name}"
                    )
                    
                    if (!executeStep(step, i, enabledSteps.size, service, stepRecords, onProgress)) {
                        when (step.onFailure) {
                            FailureAction.STOP -> throw Exception("步骤失败: ${step.name}")
                            FailureAction.SKIP -> continue
                            FailureAction.ASK_USER -> {
                                AutomationEngine.addMessage(ChatMessageDisplay(
                                    content = "步骤「${step.name}」执行失败，是否继续？",
                                    isUser = false
                                ))
                                delay(5000)
                            }
                            else -> {}
                        }
                    }
                }
                
                // 循环间隔
                if (loopConfig.loopInterval > 0 && loop < actualLoopCount) {
                    delay(loopConfig.loopInterval)
                }
            }
            
            // 执行循环后的步骤
            for (i in (loopEndIndex + 1) until enabledSteps.size) {
                if (!executeStep(enabledSteps[i], i, enabledSteps.size, service, stepRecords, onProgress)) {
                    LogManager.w(TAG, "后续步骤失败: ${enabledSteps[i].name}")
                }
            }
            
            // 更新执行统计
            saveScript(script.copy(
                executionCount = script.executionCount + 1,
                lastExecutedAt = System.currentTimeMillis()
            ))
            
            _executionState.value = ScriptExecutionState.Completed(
                scriptId = script.id,
                scriptName = script.name,
                duration = System.currentTimeMillis() - startTime,
                stepsExecuted = stepRecords.size,
                loopsCompleted = loopsCompleted
            )
            
            LogManager.d(TAG, "✅ 脚本执行完成: ${script.name}")
            onProgress("执行完成!")
            
        } catch (e: CancellationException) {
            _executionState.value = ScriptExecutionState.Cancelled(script.id, script.name)
            LogManager.d(TAG, "⏹️ 脚本已取消: ${script.name}")
            onProgress("已取消")
        } catch (e: Exception) {
            _executionState.value = ScriptExecutionState.Error(e.message ?: "未知错误")
            LogManager.e(TAG, "❌ 脚本执行失败", e)
            onProgress("执行失败: ${e.message}")
        }
    }
    
    /**
     * 执行单个步骤
     */
    private suspend fun executeStep(
        step: ScriptStep,
        index: Int,
        total: Int,
        service: CoreAccessibilityService,
        records: MutableList<StepExecutionRecord>,
        onProgress: (String) -> Unit
    ): Boolean {
        val startTime = System.currentTimeMillis()
        var retryCount = 0
        val maxRetry = if (step.onFailure == FailureAction.RETRY) 3 else 1
        
        onProgress("步骤 ${index + 1}/$total: ${step.name}")
        
        // 执行前等待
        if (step.timing.waitBefore > 0) {
            delay(step.timing.waitBefore)
        }
        
        // 添加随机延迟
        if (step.timing.randomDelay) {
            val randomDelay = Random.nextLong(step.timing.randomDelayMin, step.timing.randomDelayMax)
            delay(randomDelay)
        }
        
        while (retryCount < maxRetry) {
            try {
                val success = when (step.actionType) {
                    ScriptActionType.LAUNCH_APP -> executeLaunchApp(step)
                    ScriptActionType.CLICK -> executeClick(step, service)
                    ScriptActionType.LONG_CLICK -> executeLongClick(step, service)
                    ScriptActionType.INPUT_TEXT -> executeInputText(step, service)
                    ScriptActionType.SWIPE_UP -> executeSwipe(service, true, step.timing.executionDuration)
                    ScriptActionType.SWIPE_DOWN -> executeSwipe(service, false, step.timing.executionDuration)
                    ScriptActionType.SWIPE_LEFT -> executeSwipeHorizontal(service, true, step.timing.executionDuration)
                    ScriptActionType.SWIPE_RIGHT -> executeSwipeHorizontal(service, false, step.timing.executionDuration)
                    ScriptActionType.SCROLL -> executeScroll(step, service)
                    ScriptActionType.PRESS_BACK -> executePressBack(service)
                    ScriptActionType.PRESS_HOME -> executePressHome(service)
                    ScriptActionType.WAIT -> executeWait(step)
                    ScriptActionType.WAIT_FOR_ELEMENT -> executeWaitForElement(step, service)
                    ScriptActionType.CLOSE_POPUP -> executeClosePopup(service)
                    ScriptActionType.TAKE_SCREENSHOT -> true // TODO: 实现截图
                    ScriptActionType.CUSTOM_GESTURE -> true // TODO: 实现自定义手势
                }
                
                if (success) {
                    // 执行后等待
                    if (step.timing.waitAfter > 0) {
                        delay(step.timing.waitAfter)
                    }
                    
                    records.add(StepExecutionRecord(
                        stepId = step.id,
                        stepName = step.name,
                        startTime = startTime,
                        endTime = System.currentTimeMillis(),
                        success = true,
                        retryCount = retryCount
                    ))
                    
                    return true
                }
            } catch (e: Exception) {
                LogManager.e(TAG, "步骤执行异常: ${step.name}", e)
            }
            
            retryCount++
            if (retryCount < maxRetry) {
                delay(500)
            }
        }
        
        records.add(StepExecutionRecord(
            stepId = step.id,
            stepName = step.name,
            startTime = startTime,
            endTime = System.currentTimeMillis(),
            success = false,
            retryCount = retryCount,
            errorMessage = "步骤执行失败"
        ))
        
        return false
    }
    
    // ==================== 🎯 步骤执行方法 ====================
    
    private suspend fun executeLaunchApp(step: ScriptStep): Boolean {
        val script = _scripts.value.find { it.steps.contains(step) } ?: return false
        val packageName = script.appPackage
        
        val intent = context.packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            delay(step.timing.executionDuration)
            return true
        }
        return false
    }
    
    private suspend fun executeClick(step: ScriptStep, service: CoreAccessibilityService): Boolean {
        val selector = step.targetSelector ?: return false
        val rootNode = service.rootInActiveWindow ?: return false
        
        val node = findNode(rootNode, selector)
        if (node != null) {
            return clickNode(node)
        }
        
        // 尝试备用值
        for (altValue in selector.alternativeValues) {
            val altSelector = selector.copy(value = altValue)
            val altNode = findNode(rootNode, altSelector)
            if (altNode != null) {
                return clickNode(altNode)
            }
        }
        
        return false
    }
    
    private suspend fun executeLongClick(step: ScriptStep, service: CoreAccessibilityService): Boolean {
        val selector = step.targetSelector ?: return false
        val rootNode = service.rootInActiveWindow ?: return false
        
        val node = findNode(rootNode, selector)
        if (node != null) {
            return node.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)
        }
        return false
    }
    
    private suspend fun executeInputText(step: ScriptStep, service: CoreAccessibilityService): Boolean {
        val text = step.inputText ?: return true
        val rootNode = service.rootInActiveWindow ?: return false
        
        val editNode = findEditableNode(rootNode)
        if (editNode != null) {
            editNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, android.os.Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            })
            return true
        }
        return false
    }
    
    private suspend fun executeSwipe(service: CoreAccessibilityService, up: Boolean, duration: Long): Boolean {
        val startY = if (up) 1500f else 500f
        val endY = if (up) 500f else 1500f
        
        val gesture = android.accessibilityservice.GestureDescription.Builder()
            .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(
                android.graphics.Path().apply {
                    moveTo(540f, startY)
                    lineTo(540f, endY)
                },
                0, duration
            ))
            .build()
        
        service.dispatchGesture(gesture, null, null)
        delay(duration + 100)
        return true
    }
    
    private suspend fun executeSwipeHorizontal(service: CoreAccessibilityService, left: Boolean, duration: Long): Boolean {
        val startX = if (left) 900f else 180f
        val endX = if (left) 180f else 900f
        
        val gesture = android.accessibilityservice.GestureDescription.Builder()
            .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(
                android.graphics.Path().apply {
                    moveTo(startX, 1000f)
                    lineTo(endX, 1000f)
                },
                0, duration
            ))
            .build()
        
        service.dispatchGesture(gesture, null, null)
        delay(duration + 100)
        return true
    }
    
    private suspend fun executeScroll(step: ScriptStep, service: CoreAccessibilityService): Boolean {
        val rootNode = service.rootInActiveWindow ?: return false
        val scrollable = findScrollableNode(rootNode)
        
        if (scrollable != null) {
            scrollable.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
            return true
        }
        
        return executeSwipe(service, true, step.timing.executionDuration)
    }
    
    private suspend fun executePressBack(service: CoreAccessibilityService): Boolean {
        service.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
        return true
    }
    
    private suspend fun executePressHome(service: CoreAccessibilityService): Boolean {
        service.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME)
        return true
    }
    
    private suspend fun executeWait(step: ScriptStep): Boolean {
        var duration = step.timing.executionDuration
        
        if (step.timing.randomDelay) {
            duration += Random.nextLong(step.timing.randomDelayMin, step.timing.randomDelayMax)
        }
        
        delay(duration)
        return true
    }
    
    private suspend fun executeWaitForElement(step: ScriptStep, service: CoreAccessibilityService): Boolean {
        val selector = step.targetSelector ?: return true
        val timeout = step.timing.timeout
        val startTime = System.currentTimeMillis()
        
        while (System.currentTimeMillis() - startTime < timeout) {
            val rootNode = service.rootInActiveWindow
            if (rootNode != null) {
                val node = findNode(rootNode, selector)
                if (node != null) {
                    return true
                }
            }
            delay(200)
        }
        
        return false
    }
    
    private suspend fun executeClosePopup(service: CoreAccessibilityService): Boolean {
        val rootNode = service.rootInActiveWindow ?: return true
        val closeKeywords = listOf("关闭", "×", "跳过", "我知道了", "取消", "不再提示", "知道了")
        
        for (keyword in closeKeywords) {
            val node = findNodeByText(rootNode, keyword)
            if (node != null && node.isClickable) {
                clickNode(node)
                delay(300)
                return true
            }
        }
        
        return true
    }
    
    // ==================== 🔍 辅助方法 ====================
    
    private fun findNode(root: AccessibilityNodeInfo, selector: TargetSelector): AccessibilityNodeInfo? {
        return when (selector.type) {
            SelectorType.TEXT -> findNodeByText(root, selector.value, selector.matchMode)
            SelectorType.CONTENT_DESCRIPTION -> findNodeByDescription(root, selector.value)
            SelectorType.RESOURCE_ID -> findNodeByResourceId(root, selector.value)
            SelectorType.CLASS_NAME -> findNodeByClassName(root, selector.value)
            else -> findNodeByText(root, selector.value, selector.matchMode)
        }
    }
    
    private fun findNodeByText(node: AccessibilityNodeInfo, text: String, matchMode: MatchMode = MatchMode.CONTAINS): AccessibilityNodeInfo? {
        val nodeText = node.text?.toString() ?: ""
        
        val matches = when (matchMode) {
            MatchMode.EXACT -> nodeText == text
            MatchMode.CONTAINS -> nodeText.contains(text, ignoreCase = true)
            MatchMode.STARTS_WITH -> nodeText.startsWith(text, ignoreCase = true)
            MatchMode.ENDS_WITH -> nodeText.endsWith(text, ignoreCase = true)
            MatchMode.REGEX -> Regex(text).containsMatchIn(nodeText)
            MatchMode.FUZZY -> calculateSimilarity(nodeText, text) > 0.5f
        }
        
        if (matches) return node
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findNodeByText(child, text, matchMode)?.let { return it }
        }
        
        return null
    }
    
    private fun findNodeByDescription(node: AccessibilityNodeInfo, desc: String): AccessibilityNodeInfo? {
        if (node.contentDescription?.toString()?.contains(desc, ignoreCase = true) == true) {
            return node
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findNodeByDescription(child, desc)?.let { return it }
        }
        
        return null
    }
    
    private fun findNodeByResourceId(node: AccessibilityNodeInfo, resourceId: String): AccessibilityNodeInfo? {
        if (node.viewIdResourceName?.contains(resourceId) == true) {
            return node
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findNodeByResourceId(child, resourceId)?.let { return it }
        }
        
        return null
    }
    
    private fun findNodeByClassName(node: AccessibilityNodeInfo, className: String): AccessibilityNodeInfo? {
        if (node.className?.toString()?.contains(className) == true) {
            return node
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findNodeByClassName(child, className)?.let { return it }
        }
        
        return null
    }
    
    private fun findEditableNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable) return node
        
        val className = node.className?.toString() ?: ""
        if (className.contains("EditText") || className.contains("TextField")) {
            return node
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findEditableNode(child)?.let { return it }
        }
        
        return null
    }
    
    private fun findScrollableNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable) return node
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findScrollableNode(child)?.let { return it }
        }
        
        return null
    }
    
    private fun clickNode(node: AccessibilityNodeInfo): Boolean {
        if (node.isClickable) {
            return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        
        var parent = node.parent
        while (parent != null) {
            if (parent.isClickable) {
                return parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            parent = parent.parent
        }
        
        return false
    }
    
    private fun calculateSimilarity(s1: String, s2: String): Float {
        val longer = if (s1.length > s2.length) s1 else s2
        val shorter = if (s1.length > s2.length) s2 else s1
        
        if (longer.isEmpty()) return 1.0f
        
        var matches = 0
        for (char in shorter) {
            if (longer.contains(char, ignoreCase = true)) matches++
        }
        
        return matches.toFloat() / longer.length
    }
    
    // ==================== 🎮 控制方法 ====================
    
    /**
     * 暂停执行
     */
    fun pauseExecution() {
        isPaused = true
        val current = _executionState.value
        if (current is ScriptExecutionState.Running) {
            _executionState.value = ScriptExecutionState.Paused(
                current.scriptId,
                current.scriptName,
                current.currentStep,
                current.totalSteps
            )
        }
    }
    
    /**
     * 恢复执行
     */
    fun resumeExecution() {
        isPaused = false
        val current = _executionState.value
        if (current is ScriptExecutionState.Paused) {
            _executionState.value = ScriptExecutionState.Running(
                current.scriptId,
                current.scriptName,
                current.currentStep,
                current.totalSteps,
                0,
                "继续执行..."
            )
        }
    }
    
    /**
     * 停止执行
     */
    fun stopExecution() {
        currentExecution?.cancel()
        currentExecution = null
        isPaused = false
        
        val current = _executionState.value
        when (current) {
            is ScriptExecutionState.Running -> {
                _executionState.value = ScriptExecutionState.Cancelled(current.scriptId, current.scriptName)
            }
            is ScriptExecutionState.Paused -> {
                _executionState.value = ScriptExecutionState.Cancelled(current.scriptId, current.scriptName)
            }
            else -> {}
        }
    }
    
    // ==================== 🎬 脚本录制 ====================
    
    /**
     * 开始录制脚本
     */
    fun startRecording(scriptName: String, appPackage: String) {
        _recordingState.value = RecordingState(
            isRecording = true,
            scriptName = scriptName,
            appPackage = appPackage,
            startTime = System.currentTimeMillis()
        )
        LogManager.d(TAG, "🎬 开始录制脚本: $scriptName")
    }
    
    /**
     * 记录步骤
     */
    fun recordStep(
        name: String,
        description: String,
        actionType: ScriptActionType,
        targetSelector: TargetSelector? = null,
        inputText: String? = null
    ) {
        val state = _recordingState.value
        if (!state.isRecording) return
        
        val step = ScriptStep(
            order = state.currentStepOrder + 1,
            name = name,
            description = description,
            actionType = actionType,
            targetSelector = targetSelector,
            inputText = inputText
        )
        
        state.recordedSteps.add(step)
        _recordingState.value = state.copy(currentStepOrder = state.currentStepOrder + 1)
        
        LogManager.d(TAG, "📝 已记录步骤: $name")
    }
    
    /**
     * 停止录制并保存
     */
    fun stopRecordingAndSave(category: ScriptCategory, appName: String): UserScript? {
        val state = _recordingState.value
        if (!state.isRecording || state.recordedSteps.isEmpty()) {
            _recordingState.value = RecordingState()
            return null
        }
        
        val script = UserScript(
            name = state.scriptName,
            appPackage = state.appPackage,
            appName = appName,
            category = category,
            steps = state.recordedSteps.toList()
        )
        
        saveScript(script)
        _recordingState.value = RecordingState()
        
        LogManager.d(TAG, "✅ 脚本录制完成: ${script.name}")
        return script
    }
    
    /**
     * 取消录制
     */
    fun cancelRecording() {
        _recordingState.value = RecordingState()
        LogManager.d(TAG, "❌ 录制已取消")
    }
    
    // ==================== 📋 从任务执行创建脚本 ====================
    
    /**
     * 从成功的任务执行创建脚本
     */
    fun createScriptFromExecution(
        name: String,
        description: String,
        category: ScriptCategory,
        appPackage: String,
        appName: String,
        executedSteps: List<ScriptStep>,
        loopConfig: LoopConfig = LoopConfig()
    ): UserScript {
        val script = UserScript(
            name = name,
            description = description,
            appPackage = appPackage,
            appName = appName,
            category = category,
            steps = executedSteps,
            loopConfig = loopConfig
        )
        
        saveScript(script)
        return script
    }
    
    /**
     * 复制脚本
     */
    fun duplicateScript(scriptId: String, newName: String): UserScript? {
        val original = getScript(scriptId) ?: return null
        
        val copy = original.copy(
            id = java.util.UUID.randomUUID().toString(),
            name = newName,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            executionCount = 0,
            lastExecutedAt = null
        )
        
        saveScript(copy)
        return copy
    }
    
    /**
     * 更新脚本步骤时间配置
     */
    fun updateStepTiming(scriptId: String, stepId: String, timing: StepTiming): Boolean {
        val script = getScript(scriptId) ?: return false
        
        val updatedSteps = script.steps.map { step ->
            if (step.id == stepId) {
                step.copy(timing = timing)
            } else {
                step
            }
        }
        
        return saveScript(script.copy(steps = updatedSteps))
    }
    
    /**
     * 更新循环配置
     */
    fun updateLoopConfig(scriptId: String, loopConfig: LoopConfig): Boolean {
        val script = getScript(scriptId) ?: return false
        return saveScript(script.copy(loopConfig = loopConfig))
    }
    
    /**
     * 设置步骤为循环起点
     */
    fun setLoopStartStep(scriptId: String, stepId: String): Boolean {
        val script = getScript(scriptId) ?: return false
        val loopConfig = script.loopConfig.copy(
            enabled = true,
            loopStartStepId = stepId
        )
        return saveScript(script.copy(loopConfig = loopConfig))
    }
    
    /**
     * 启用/禁用步骤
     */
    fun toggleStepEnabled(scriptId: String, stepId: String): Boolean {
        val script = getScript(scriptId) ?: return false
        
        val updatedSteps = script.steps.map { step ->
            if (step.id == stepId) {
                step.copy(isEnabled = !step.isEnabled)
            } else {
                step
            }
        }
        
        return saveScript(script.copy(steps = updatedSteps))
    }
    
    // ==================== 🔧 工具兼容方法 ====================
    // 以下方法用于与 AdvancedAutomationTools 兼容
    
    /**
     * 简单脚本数据类（用于工具兼容）
     */
    data class SimpleScript(
        val id: String,
        val name: String,
        val description: String = "",
        val actions: List<SimpleAction>,
        val createdTime: Long = System.currentTimeMillis(),
        val modifiedTime: Long = System.currentTimeMillis()
    )
    
    data class SimpleAction(
        val type: String,
        val parameters: Map<String, String> = emptyMap(),
        val delayAfter: Long = 500
    )
    
    data class SimpleExecutionResult(
        val success: Boolean,
        val executedActions: Int = 0,
        val totalActions: Int = 0,
        val errorMessage: String? = null
    )
    
    /**
     * 创建简单脚本（工具兼容）
     */
    fun createScript(name: String, description: String = ""): SimpleScript {
        val id = "script_${System.currentTimeMillis()}"
        return SimpleScript(
            id = id,
            name = name,
            description = description,
            actions = emptyList()
        )
    }
    
    /**
     * 保存简单脚本（工具兼容）
     */
    fun saveScript(script: SimpleScript): Boolean {
        // 转换为 UserScript 并保存
        val userScript = UserScript(
            id = script.id,
            name = script.name,
            description = script.description,
            appPackage = "",
            appName = "通用",
            category = ScriptCategory.CUSTOM,
            steps = script.actions.mapIndexed { index, action ->
                ScriptStep(
                    order = index,
                    name = action.type,
                    description = action.parameters.toString(),
                    actionType = mapActionType(action.type),
                    inputText = action.parameters["text"],
                    timing = StepTiming(waitAfter = action.delayAfter)
                )
            },
            createdAt = script.createdTime,
            updatedAt = script.modifiedTime
        )
        return saveScript(userScript)
    }
    
    /**
     * 加载简单脚本（工具兼容）
     */
    fun loadScript(scriptId: String): SimpleScript? {
        val userScript = getScript(scriptId) ?: return null
        return SimpleScript(
            id = userScript.id,
            name = userScript.name,
            description = userScript.description,
            actions = userScript.steps.map { step ->
                SimpleAction(
                    type = step.actionType.name,
                    parameters = buildMap {
                        step.inputText?.let { put("text", it) }
                    },
                    delayAfter = step.timing.waitAfter
                )
            },
            createdTime = userScript.createdAt,
            modifiedTime = userScript.updatedAt
        )
    }
    
    /**
     * 获取所有简单脚本（工具兼容）
     */
    fun getAllScripts(): List<SimpleScript> {
        return _scripts.value.map { userScript ->
            SimpleScript(
                id = userScript.id,
                name = userScript.name,
                description = userScript.description,
                actions = userScript.steps.map { step ->
                    SimpleAction(
                        type = step.actionType.name,
                        parameters = buildMap {
                            step.inputText?.let { put("text", it) }
                        },
                        delayAfter = step.timing.waitAfter
                    )
                },
                createdTime = userScript.createdAt,
                modifiedTime = userScript.updatedAt
            )
        }
    }
    
    /**
     * 执行简单脚本（工具兼容）
     */
    suspend fun executeScript(script: SimpleScript): SimpleExecutionResult {
        val userScript = getScript(script.id)
        if (userScript == null) {
            return SimpleExecutionResult(false, 0, script.actions.size, "脚本不存在")
        }

        if (_executionState.value is ScriptExecutionState.Running) {
            return SimpleExecutionResult(false, 0, script.actions.size, "宸叉湁鑴氭湰姝ｅ湪鎵ц")
        }

        var executedCount = 0
        executeScript(userScript) { 
            executedCount++
        }
        
        // 等待执行完成
        val executionJob = currentExecution
            ?: return SimpleExecutionResult(false, 0, script.actions.size, "鑴氭湰鏈兘鍚姩")

        executionJob.join()
        
        return when (val state = _executionState.value) {
            is ScriptExecutionState.Completed -> SimpleExecutionResult(
                true, state.stepsExecuted, userScript.steps.size
            )
            is ScriptExecutionState.Error -> SimpleExecutionResult(
                false, executedCount, userScript.steps.size, state.message
            )
            else -> SimpleExecutionResult(false, executedCount, userScript.steps.size)
        }
    }
    
    private fun mapActionType(type: String): ScriptActionType {
        return when (type.uppercase()) {
            "CLICK" -> ScriptActionType.CLICK
            "LONG_CLICK" -> ScriptActionType.LONG_CLICK
            "INPUT", "INPUT_TEXT" -> ScriptActionType.INPUT_TEXT
            "SWIPE" -> ScriptActionType.SWIPE_UP
            "SCROLL" -> ScriptActionType.SCROLL
            "BACK" -> ScriptActionType.PRESS_BACK
            "HOME" -> ScriptActionType.PRESS_HOME
            "WAIT" -> ScriptActionType.WAIT
            "LAUNCH_APP" -> ScriptActionType.LAUNCH_APP
            else -> ScriptActionType.WAIT
        }
    }
}

/**
 * 脚本执行状态
 */
sealed class ScriptExecutionState {
    object Idle : ScriptExecutionState()
    
    data class Running(
        val scriptId: String,
        val scriptName: String,
        val currentStep: Int,
        val totalSteps: Int,
        val loopCount: Int,
        val message: String
    ) : ScriptExecutionState()
    
    data class Paused(
        val scriptId: String,
        val scriptName: String,
        val currentStep: Int,
        val totalSteps: Int
    ) : ScriptExecutionState()
    
    data class Completed(
        val scriptId: String,
        val scriptName: String,
        val duration: Long,
        val stepsExecuted: Int,
        val loopsCompleted: Int
    ) : ScriptExecutionState()
    
    data class Cancelled(
        val scriptId: String,
        val scriptName: String
    ) : ScriptExecutionState()
    
    data class Error(val message: String) : ScriptExecutionState()
}
