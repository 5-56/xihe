package com.example.xihe.understanding

import android.content.Context
import android.content.SharedPreferences
import com.example.xihe.utils.LogManager
import com.example.xihe.core.UserIntent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.UUID

/**
 * 🧠 对话上下文管理器
 * 管理羲和的"记忆"，让她能理解多轮对话
 */
class ConversationContextManager private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "ContextManager"
        private const val PREFS_NAME = "xihe_conversation_context"
        private const val KEY_CURRENT_CONTEXT = "current_context"
        
        @Volatile
        private var instance: ConversationContextManager? = null
        
        fun getInstance(context: Context): ConversationContextManager {
            return instance ?: synchronized(this) {
                instance ?: ConversationContextManager(context.applicationContext).also {
                    instance = it
                }
            }
        }
    }
    
    private val prefs: SharedPreferences = 
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    
    private val json = Json { 
        ignoreUnknownKeys = true
        isLenient = true
    }
    
    // 当前上下文状态
    private val _currentContext = MutableStateFlow(loadContext())
    val currentContext = _currentContext.asStateFlow()
    
    /**
     * 添加用户输入和系统响应
     */
    fun addTurn(
        userInput: String,
        recognizedIntent: UserIntent? = null,
        systemResponse: String = "",
        executionSuccess: Boolean = false
    ) {
        val turn = Turn(
            userInput = userInput,
            timestamp = System.currentTimeMillis(),
            recognizedIntent = recognizedIntent,
            systemResponse = systemResponse,
            executionSuccess = executionSuccess
        )
        
        val newContext = _currentContext.value.addTurn(turn)
        updateContext(newContext)
        
        LogManager.w(TAG, "添加对话轮次: $userInput")
    }
    
    /**
     * 更新实体
     */
    fun updateEntity(type: EntityType, value: String, confidence: Float = 0.9f) {
        val newContext = _currentContext.value.updateEntity(type, value, confidence)
        updateContext(newContext)
        
        LogManager.w(TAG, "更新实体: ${type.name} = $value")
    }
    
    /**
     * 批量更新实体（从意图中提取）
     */
    fun updateEntitiesFromIntent(intent: UserIntent) {
        var newContext = _currentContext.value
        
        // 从 entities 中提取并更新
        intent.entities.forEach { (key, value) ->
            val entityType = when (key) {
                "contact", "contactName" -> EntityType.PERSON
                "app", "appName" -> EntityType.APP
                "message", "content" -> EntityType.CONTENT
                "query", "keyword" -> EntityType.KEYWORD
                "location" -> EntityType.LOCATION
                "time" -> EntityType.TIME
                else -> null
            }
            
            if (entityType != null && value.isNotBlank()) {
                newContext = newContext.updateEntity(entityType, value, intent.confidence.toFloat())
            }
        }
        
        updateContext(newContext)
    }
    
    /**
     * 获取最近提到的实体
     */
    fun getRecentEntity(type: EntityType): Entity? {
        return _currentContext.value.getRecentEntity(type)
    }
    
    /**
     * 获取对话历史摘要（用于LLM Prompt）
     */
    fun getHistorySummary(maxTurns: Int = 5): String {
        val history = _currentContext.value.history.takeLast(maxTurns)
        
        if (history.isEmpty()) {
            return "这是一个新对话。"
        }
        
        val summary = StringBuilder()
        summary.append("对话历史:\n")
        
        history.forEachIndexed { index, turn ->
            summary.append("${index + 1}. 用户: ${turn.userInput}\n")
            if (turn.systemResponse.isNotBlank()) {
                summary.append("   羲和: ${turn.systemResponse}\n")
            }
        }
        
        // 添加活跃实体
        val entities = _currentContext.value.activeEntities
        if (entities.isNotEmpty()) {
            summary.append("\n当前记住的信息:\n")
            entities.forEach { (_, entity) ->
                summary.append("- ${entity.type.name}: ${entity.value}\n")
            }
        }
        
        return summary.toString()
    }
    
    /**
     * 获取活跃实体摘要
     */
    fun getActiveEntitiesSummary(): Map<EntityType, String> {
        return _currentContext.value.activeEntities.mapKeys { it.value.type }.mapValues { it.value.value }
    }
    
    /**
     * 设置待确认意图
     */
    fun setPendingIntent(intent: UserIntent) {
        val newContext = _currentContext.value.copy(pendingIntent = intent)
        updateContext(newContext)
        LogManager.w(TAG, "设置待确认意图: ${intent.type}")
    }
    
    /**
     * 清除待确认意图
     */
    fun clearPendingIntent() {
        val newContext = _currentContext.value.copy(pendingIntent = null)
        updateContext(newContext)
    }
    
    /**
     * 开始新话题
     */
    fun startTopic(topicName: String, relatedEntities: List<String> = emptyList()) {
        val topic = Topic(
            name = topicName,
            startTime = System.currentTimeMillis(),
            relatedEntities = relatedEntities
        )
        
        val newContext = _currentContext.value.copy(currentTopic = topic)
        updateContext(newContext)
        
        LogManager.w(TAG, "开始新话题: $topicName")
    }
    
    /**
     * 清除会话（重新开始）
     */
    fun clearSession() {
        val newContext = ConversationContext(
            sessionId = UUID.randomUUID().toString(),
            userPreferences = _currentContext.value.userPreferences // 保留用户偏好
        )
        updateContext(newContext)
        
        LogManager.w(TAG, "清除会话，开始新会话")
    }
    
    /**
     * 更新并保存上下文
     */
    private fun updateContext(newContext: ConversationContext) {
        // 清理过期实体
        val cleanedContext = newContext.cleanupStaleEntities()
        _currentContext.value = cleanedContext
        
        // 持久化保存
        saveContext(cleanedContext)
    }
    
    /**
     * 保存上下文到持久化存储
     */
    private fun saveContext(context: ConversationContext) {
        try {
            val jsonString = json.encodeToString(context)
            prefs.edit().putString(KEY_CURRENT_CONTEXT, jsonString).apply()
        } catch (e: Exception) {
            LogManager.e(TAG, "保存上下文失败", e)
        }
    }
    
    /**
     * 加载上下文
     */
    private fun loadContext(): ConversationContext {
        return try {
            val jsonString = prefs.getString(KEY_CURRENT_CONTEXT, null)
            if (jsonString != null) {
                json.decodeFromString<ConversationContext>(jsonString)
            } else {
                // 创建新上下文
                ConversationContext(sessionId = UUID.randomUUID().toString())
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "加载上下文失败，创建新上下文", e)
            ConversationContext(sessionId = UUID.randomUUID().toString())
        }
    }
}
