package com.example.xihe.understanding

import com.example.xihe.utils.LogManager
import com.example.xihe.core.UserIntent

/**
 * 💭 隐含意图检测器
 * 理解用户的真实需求，即使他们没有明说
 */
class ImplicitIntentDetector {
    
    companion object {
        private const val TAG = "ImplicitIntentDetector"
    }
    
    /**
     * 检测隐含意图
     * @return 检测到的隐含意图列表（可能有多个）
     */
    fun detect(input: String, context: ConversationContext): List<UserIntent> {
        val implicitIntents = mutableListOf<UserIntent>()
        val normalizedInput = input.trim().lowercase()
        
        // 1. 生理需求 → 订餐
        if (detectHunger(normalizedInput)) {
            implicitIntents.add(createIntent(
                type = "order_food",
                confidence = 0.7,
                reasoning = "用户表达饥饿，可能需要订餐",
                suggestion = "要不要我帮你打开美团外卖看看？"
            ))
        }
        
        // 2. 天气/温度感受 → 查询天气
        if (detectWeatherConcern(normalizedInput)) {
            implicitIntents.add(createIntent(
                type = "check_weather",
                confidence = 0.65,
                reasoning = "用户对天气/温度有感受，可能想了解天气",
                suggestion = "要不要我帮你查查今天的天气？"
            ))
        }
        
        // 3. 交通问题 → 导航/路况
        if (detectTrafficProblem(normalizedInput)) {
            implicitIntents.add(createIntent(
                type = "check_traffic",
                confidence = 0.7,
                reasoning = "用户遇到交通问题，可能需要导航",
                suggestion = "要不要我帮你查看实时路况或重新规划路线？"
            ))
        }
        
        // 4. 疲劳/困倦 → 提醒休息
        if (detectFatigue(normalizedInput)) {
            implicitIntents.add(createIntent(
                type = "suggest_rest",
                confidence = 0.6,
                reasoning = "用户表达疲劳，建议休息",
                suggestion = "你看起来很累，要不要休息一下？我可以帮你设置闹钟"
            ))
        }
        
        // 5. 无聊 → 推荐娱乐
        if (detectBoredom(normalizedInput)) {
            implicitIntents.add(createIntent(
                type = "recommend_entertainment",
                confidence = 0.65,
                reasoning = "用户感到无聊，可以推荐娱乐",
                suggestion = "要不要打开抖音刷刷视频，或者我给你讲个笑话？"
            ))
        }
        
        // 6. 寻找物品 → 搜索/提醒
        if (detectSearchingItem(normalizedInput)) {
            val item = extractItem(normalizedInput)
            implicitIntents.add(createIntent(
                type = "find_item",
                confidence = 0.6,
                reasoning = "用户在找东西，可以帮助搜索",
                suggestion = "要不要我帮你在淘宝/京东搜索「$item」？",
                entities = mapOf("item" to item)
            ))
        }
        
        // 7. 忘记事情 → 记录备忘
        if (detectForgetting(normalizedInput)) {
            implicitIntents.add(createIntent(
                type = "create_memo",
                confidence = 0.65,
                reasoning = "用户担心忘记，可以帮助记录",
                suggestion = "要不要我帮你记下来，到时候提醒你？"
            ))
        }
        
        if (implicitIntents.isNotEmpty()) {
            LogManager.w(TAG, "💭 检测到${implicitIntents.size}个隐含意图")
        }
        
        return implicitIntents
    }
    
    // ==================== 检测方法 ====================
    
    private fun detectHunger(input: String): Boolean {
        return input.matches(Regex(".*(饿|肚子饿|想吃|好饿|快饿死).*"))
    }
    
    private fun detectWeatherConcern(input: String): Boolean {
        return input.matches(Regex(".*(好冷|好热|冷死|热死|好闷|天气).*"))
    }
    
    private fun detectTrafficProblem(input: String): Boolean {
        return input.matches(Regex(".*(堵车|好堵|塞车|路况|交通).*"))
    }
    
    private fun detectFatigue(input: String): Boolean {
        return input.matches(Regex(".*(累|好累|困|好困|疲|想睡).*"))
    }
    
    private fun detectBoredom(input: String): Boolean {
        return input.matches(Regex(".*(无聊|好无聊|没事干|闲).*"))
    }
    
    private fun detectSearchingItem(input: String): Boolean {
        return input.matches(Regex(".*(找不到|在哪|哪里有|我的.+呢).*"))
    }
    
    private fun detectForgetting(input: String): Boolean {
        return input.matches(Regex(".*(别忘|不要忘|记得|提醒我).*"))
    }
    
    // ==================== 辅助方法 ====================
    
    private fun extractItem(input: String): String {
        val pattern = Regex("(找不到|在哪|哪里有|我的)\\s*(.+?)\\s*(呢|啊|了|\\?|？|$)")
        val match = pattern.find(input)
        return match?.groupValues?.get(2)?.trim() ?: "东西"
    }
    
    private fun createIntent(
        type: String,
        confidence: Double,
        reasoning: String,
        suggestion: String,
        entities: Map<String, String> = emptyMap()
    ): UserIntent {
        return UserIntent(
            type = type,
            confidence = confidence,
            reasoning = reasoning,
            entities = entities,
            parameters = kotlinx.serialization.json.buildJsonObject {
                put("suggestion", kotlinx.serialization.json.JsonPrimitive(suggestion))
                put("isImplicit", kotlinx.serialization.json.JsonPrimitive(true))
            }
        )
    }
}
