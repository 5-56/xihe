package com.example.xihe.understanding

import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.appmanager.SmartAppManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable

/**
 * 🧠 深度上下文理解系统
 * 
 * 解决问题:
 * ❌ 当前: 用户说"打开微信"然后说"给张三发消息"，AI不知道在微信里发
 * ✅ 优化: AI能记住当前在微信里，自动理解"给张三发消息"是在微信发送
 * 
 * 核心能力:
 * 1. 多轮对话上下文
 * 2. 实体追踪
 * 3. 意图延续
 * 4. 省略补全
 * 5. 指代消解
 */
class DeepContextUnderstanding private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "DeepContext"
        private const val MAX_HISTORY_SIZE = 50
        
        // 🆕 常见应用别名映射（基础列表，会动态补充）
        private val COMMON_APP_ALIASES = mapOf(
            "微信" to "com.tencent.mm",
            "QQ" to "com.tencent.mobileqq",
            "支付宝" to "com.eg.android.AlipayGphone",
            "抖音" to "com.ss.android.ugc.aweme",
            "淘宝" to "com.taobao.taobao",
            "美团" to "com.sankuai.meituan",
            "饿了么" to "me.ele",
            "哔哩哔哩" to "tv.danmaku.bili",
            "B站" to "tv.danmaku.bili",
            "快手" to "com.smile.gifmaker",
            "小红书" to "com.xingin.xhs",
            "京东" to "com.jingdong.app.mall",
            "拼多多" to "com.xunmeng.pinduoduo",
            "高德地图" to "com.autonavi.minimap",
            "百度地图" to "com.baidu.BaiduMap",
            "滴滴" to "com.sdu.didi.psnger",
            "设置" to "com.android.settings",
            "电话" to "com.android.dialer",
            "相机" to "com.android.camera",
            "图库" to "com.android.gallery3d"
        )
        
        @Volatile
        private var instance: DeepContextUnderstanding? = null
        
        fun getInstance(context: Context): DeepContextUnderstanding {
            return instance ?: synchronized(this) {
                instance ?: DeepContextUnderstanding(context.applicationContext).also {
                    instance = it
                }
            }
        }
    }
    
    // 🆕 动态应用列表（从 SmartAppManager 获取）
    private val dynamicAppNames: Set<String> by lazy {
        try {
            val appManager = SmartAppManager.getInstance(context)
            appManager.apps.value.map { it.appName }.toSet()
        } catch (e: Exception) {
            LogManager.e(TAG, "无法加载动态应用列表", e)
            emptySet()
        }
    }
    
    // 对话上下文
    private val _dialogueContext = MutableStateFlow(DialogueContext())
    val dialogueContext = _dialogueContext.asStateFlow()
    
    // 对话历史
    private val conversationHistory = mutableListOf<ConversationTurn>()
    
    /**
     * 💬 处理用户输入（带上下文理解）
     */
    fun processWithContext(userInput: String): EnhancedUnderstanding {
        LogManager.d(TAG, "💬 处理输入: $userInput")
        
        val currentContext = _dialogueContext.value
        
        // 1. 指代消解
        val resolvedInput = resolveReferences(userInput, currentContext)
        
        // 2. 省略补全
        val completedInput = completeOmissions(resolvedInput, currentContext)
        
        // 3. 意图理解
        val intent = understandIntent(completedInput, currentContext)
        
        // 4. 实体提取
        val entities = extractEntities(completedInput)
        
        // 5. 更新上下文
        updateContext(userInput, intent, entities)
        
        // 6. 记录对话轮次
        recordConversationTurn(userInput, completedInput, intent, entities)
        
        return EnhancedUnderstanding(
            originalInput = userInput,
            resolvedInput = resolvedInput,
            completedInput = completedInput,
            intent = intent,
            entities = entities,
            context = currentContext,
            confidence = calculateConfidence(intent, entities)
        )
    }
    
    /**
     * 🔗 指代消解
     * 
     * 示例:
     * 用户: "打开微信"
     * 用户: "给他发消息" -> 补全为 "给张三发消息"（如果之前提到过张三）
     */
    private fun resolveReferences(input: String, context: DialogueContext): String {
        var resolved = input
        
        // 解决人称代词
        val pronouns = mapOf(
            "他" to context.lastMentionedPerson?.name,
            "她" to context.lastMentionedPerson?.name,
            "它" to context.lastMentionedObject,
            "这个" to context.lastMentionedObject,
            "那个" to context.lastMentionedObject
        )
        
        for ((pronoun, reference) in pronouns) {
            if (reference != null && resolved.contains(pronoun)) {
                resolved = resolved.replace(pronoun, reference)
                LogManager.d(TAG, "🔗 指代消解: $pronoun -> $reference")
            }
        }
        
        return resolved
    }
    
    /**
     * 📝 省略补全
     * 
     * 示例:
     * 用户: "给张三发消息说明天开会"
     * 用户: "给李四也发一条" -> 补全为 "给李四发消息说明天开会"
     */
    private fun completeOmissions(input: String, context: DialogueContext): String {
        var completed = input
        
        // 补全动作
        if (context.lastAction != null && !containsAction(input)) {
            completed = "${context.lastAction} $completed"
            LogManager.d(TAG, "📝 补全动作: ${context.lastAction}")
        }
        
        // 补全内容
        if (input.contains("也") || input.contains("同样")) {
            context.lastContent?.let {
                if (!completed.contains(it)) {
                    completed += " $it"
                    LogManager.d(TAG, "📝 补全内容: $it")
                }
            }
        }
        
        // 补全应用上下文
        if (context.currentApp != null && !containsApp(input)) {
            // 不明确添加应用名，但记录在上下文中
            LogManager.d(TAG, "📝 隐含应用: ${context.currentApp}")
        }
        
        return completed
    }
    
    /**
     * 🎯 理解意图（基于上下文）
     */
    private fun understandIntent(input: String, context: DialogueContext): IntentType {
        return when {
            // 延续之前的任务
            context.unfinishedTask != null && isContinuation(input) -> {
                IntentType.CONTINUE_TASK
            }
            
            // 修改之前的操作
            isModification(input) -> {
                IntentType.MODIFY_PREVIOUS
            }
            
            // 新的任务
            containsAction(input) -> {
                IntentType.NEW_TASK
            }
            
            // 询问
            input.contains("吗") || input.contains("？") -> {
                IntentType.QUESTION
            }
            
            // 闲聊
            else -> {
                IntentType.CHAT
            }
        }
    }
    
    /**
     * 🏷️ 提取实体
     */
    private fun extractEntities(input: String): Map<String, EntityValue> {
        val entities = mutableMapOf<String, EntityValue>()
        
        // 提取人名
        val personPattern = Regex("给(\\S+?)发|找(\\S+)")
        personPattern.find(input)?.let {
            val person = it.groupValues[1]
            entities["person"] = EntityValue(person, DeepEntityType.PERSON, 0.9f)
        }
        
        // 提取应用名
        val appPattern = Regex("(打开|启动|使用)(\\S+)")
        appPattern.find(input)?.let {
            val app = it.groupValues[2]
            entities["app"] = EntityValue(app, DeepEntityType.APP, 0.9f)
        }
        
        // 提取时间
        val timePattern = Regex("(明天|今天|后天|下周|\\d+点)")
        timePattern.find(input)?.let {
            val time = it.groupValues[1]
            entities["time"] = EntityValue(time, DeepEntityType.TIME, 0.8f)
        }
        
        // 提取内容
        val contentPattern = Regex("说(.+)")
        contentPattern.find(input)?.let {
            val content = it.groupValues[1]
            entities["content"] = EntityValue(content, DeepEntityType.CONTENT, 0.95f)
        }
        
        return entities
    }
    
    /**
     * 🔄 更新上下文
     */
    private fun updateContext(
        userInput: String,
        intent: IntentType,
        entities: Map<String, EntityValue>
    ) {
        val current = _dialogueContext.value
        
        val updated = current.copy(
            // 更新应用
            currentApp = entities["app"]?.value ?: current.currentApp,
            
            // 更新最后动作
            lastAction = extractAction(userInput) ?: current.lastAction,
            
            // 更新最后内容
            lastContent = entities["content"]?.value ?: current.lastContent,
            
            // 更新提到的人
            lastMentionedPerson = entities["person"]?.let {
                Person(it.value, DeepEntityType.PERSON)
            } ?: current.lastMentionedPerson,
            
            // 更新提到的对象
            lastMentionedObject = detectObject(userInput) ?: current.lastMentionedObject,
            
            // 更新时间戳
            lastUpdateTime = System.currentTimeMillis(),
            
            // 增加轮次
            turnCount = current.turnCount + 1
        )
        
        _dialogueContext.value = updated
        
        LogManager.d(TAG, "🔄 上下文已更新: app=${updated.currentApp}, action=${updated.lastAction}")
    }
    
    /**
     * 📚 记录对话轮次
     */
    private fun recordConversationTurn(
        userInput: String,
        processedInput: String,
        intent: IntentType,
        entities: Map<String, EntityValue>
    ) {
        val turn = ConversationTurn(
            userInput = userInput,
            processedInput = processedInput,
            intent = intent,
            entities = entities,
            timestamp = System.currentTimeMillis(),
            context = _dialogueContext.value.copy()
        )
        
        conversationHistory.add(turn)
        
        // 保持最近N轮
        if (conversationHistory.size > MAX_HISTORY_SIZE) {
            conversationHistory.removeAt(0)
        }
    }
    
    /**
     * 🎯 计算理解置信度
     */
    private fun calculateConfidence(
        intent: IntentType,
        entities: Map<String, EntityValue>
    ): Float {
        // 基础置信度
        var confidence = 0.7f
        
        // 意图明确 +0.1
        if (intent != IntentType.UNKNOWN) {
            confidence += 0.1f
        }
        
        // 实体丰富 +0.2
        if (entities.isNotEmpty()) {
            confidence += 0.2f * (entities.size.toFloat() / 4f).coerceAtMost(1f)
        }
        
        return confidence.coerceIn(0f, 1f)
    }
    
    // ==================== 辅助方法 ====================
    
    private fun containsAction(input: String): Boolean {
        val actions = listOf("打开", "发送", "搜索", "播放", "查看", "设置", "关闭")
        return actions.any { input.contains(it) }
    }
    
    private fun containsApp(input: String): Boolean {
        // 🆕 使用动态应用列表 + 常见别名
        val allAppNames = COMMON_APP_ALIASES.keys + dynamicAppNames
        return allAppNames.any { input.contains(it) }
    }
    
    /**
     * 🆕 从输入中提取应用名
     */
    fun extractAppName(input: String): String? {
        // 优先匹配常见别名
        for (alias in COMMON_APP_ALIASES.keys) {
            if (input.contains(alias)) {
                return alias
            }
        }
        // 然后匹配动态应用列表
        for (appName in dynamicAppNames) {
            if (input.contains(appName)) {
                return appName
            }
        }
        return null
    }
    
    /**
     * 🆕 获取应用包名
     */
    fun getAppPackageName(appName: String): String? {
        // 先查常见别名
        COMMON_APP_ALIASES[appName]?.let { return it }
        
        // 然后查动态列表
        try {
            val appManager = SmartAppManager.getInstance(context)
            return appManager.getAppByName(appName)?.packageName
        } catch (e: Exception) {
            return null
        }
    }
    
    private fun isContinuation(input: String): Boolean {
        val continuations = listOf("继续", "然后", "接着", "再")
        return continuations.any { input.contains(it) }
    }
    
    private fun isModification(input: String): Boolean {
        val modifications = listOf("改成", "换成", "不对", "改为")
        return modifications.any { input.contains(it) }
    }
    
    private fun extractAction(input: String): String? {
        val actionPattern = Regex("(打开|发送|搜索|播放|查看|设置|关闭)")
        return actionPattern.find(input)?.groupValues?.get(1)
    }
    
    private fun detectObject(input: String): String? {
        // 简单实现，可以扩展
        return null
    }
    
    /**
     * 🗑️ 清除上下文（开始新对话）
     */
    fun clearContext() {
        _dialogueContext.value = DialogueContext()
        conversationHistory.clear()
        LogManager.d(TAG, "🗑️ 上下文已清除")
    }
    
    /**
     * 📖 获取对话历史
     */
    fun getConversationHistory(): List<ConversationTurn> {
        return conversationHistory.toList()
    }
}

// ==================== 数据类 ====================

/**
 * 📋 对话上下文
 */
@Serializable
data class DialogueContext(
    val currentApp: String? = null,              // 当前应用
    val lastAction: String? = null,              // 最后动作
    val lastContent: String? = null,             // 最后内容
    val lastMentionedPerson: Person? = null,     // 最后提到的人
    val lastMentionedObject: String? = null,     // 最后提到的对象
    val unfinishedTask: String? = null,          // 未完成任务
    val lastUpdateTime: Long = 0L,               // 最后更新时间
    val turnCount: Int = 0                       // 对话轮次
)

/**
 * 👤 人物实体
 */
@Serializable
data class Person(
    val name: String,
    val type: DeepEntityType
)

/**
 * 🏷️ 实体值
 */
@Serializable
data class EntityValue(
    val value: String,
    val type: DeepEntityType,
    val confidence: Float
)

/**
 * 🎯 实体类型
 */
enum class DeepEntityType {
    PERSON,     // 人物
    APP,        // 应用
    TIME,       // 时间
    PLACE,      // 地点
    CONTENT,    // 内容
    OBJECT,     // 物体
    ACTION      // 动作
}

/**
 * 🎭 意图类型
 */
enum class IntentType {
    NEW_TASK,           // 新任务
    CONTINUE_TASK,      // 继续任务
    MODIFY_PREVIOUS,    // 修改上一步
    QUESTION,           // 询问
    CHAT,               // 闲聊
    UNKNOWN             // 未知
}

/**
 * 💡 增强理解结果
 */
data class EnhancedUnderstanding(
    val originalInput: String,                      // 原始输入
    val resolvedInput: String,                      // 指代消解后
    val completedInput: String,                     // 省略补全后
    val intent: IntentType,                         // 意图
    val entities: Map<String, EntityValue>,         // 实体
    val context: DialogueContext,                   // 当前上下文
    val confidence: Float                           // 置信度
)

/**
 * 🔄 对话轮次
 */
@Serializable
data class ConversationTurn(
    val userInput: String,
    val processedInput: String,
    val intent: IntentType,
    val entities: Map<String, EntityValue>,
    val timestamp: Long,
    val context: DialogueContext
)

