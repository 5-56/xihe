package com.example.xihe.understanding

import com.example.xihe.utils.LogManager
import com.example.xihe.core.UserIntent

/**
 * 🧩 意图补全器
 * 从上下文中补全缺失的信息
 */
class IntentCompleter {
    
    companion object {
        private const val TAG = "IntentCompleter"
    }
    
    /**
     * 补全意图中缺失的信息
     */
    fun complete(intent: UserIntent, context: ConversationContext): UserIntent {
        var completed = intent
        
        // 根据意图类型补全不同的信息
        when (intent.type) {
            "send_wechat_message", "send_message" -> {
                completed = completeMessageIntent(completed, context)
            }
            "web_search" -> {
                completed = completeSearchIntent(completed, context)
            }
            "open_app" -> {
                completed = completeAppIntent(completed, context)
            }
        }
        
        if (completed != intent) {
            LogManager.w(TAG, "✅ 意图补全完成")
        }
        
        return completed
    }
    
    /**
     * 补全发消息意图
     */
    private fun completeMessageIntent(intent: UserIntent, context: ConversationContext): UserIntent {
        val entities = intent.entities.toMutableMap()
        var modified = false
        
        // 1. 补全联系人
        if (entities["contact"].isNullOrBlank() && entities["contactName"].isNullOrBlank()) {
            context.getRecentEntity(EntityType.PERSON)?.let { person ->
                entities["contact"] = person.value
                entities["contactName"] = person.value
                modified = true
                LogManager.w(TAG, "💡 补全联系人: ${person.value}")
            }
        }
        
        // 2. 补全消息内容
        if (entities["message"].isNullOrBlank()) {
            context.getRecentEntity(EntityType.CONTENT)?.let { content ->
                entities["message"] = content.value
                modified = true
                LogManager.w(TAG, "💡 补全消息内容: ${content.value}")
            }
        }
        
        // 3. 补全应用
        if (entities["app"].isNullOrBlank()) {
            context.getRecentEntity(EntityType.APP)?.let { app ->
                // 只有在明确是消息应用时才补全
                if (app.value in listOf("微信", "QQ", "钉钉", "飞书", "Telegram")) {
                    entities["app"] = app.value
                    modified = true
                    LogManager.w(TAG, "💡 补全应用: ${app.value}")
                }
            }
        }
        
        return if (modified) {
            intent.copy(
                entities = entities,
                reasoning = intent.reasoning + " [已从上下文补全信息]"
            )
        } else {
            intent
        }
    }
    
    /**
     * 补全搜索意图
     */
    private fun completeSearchIntent(intent: UserIntent, context: ConversationContext): UserIntent {
        val entities = intent.entities.toMutableMap()
        var modified = false
        
        // 补全搜索关键词
        if (entities["query"].isNullOrBlank() && entities["keyword"].isNullOrBlank()) {
            context.getRecentEntity(EntityType.KEYWORD)?.let { keyword ->
                entities["query"] = keyword.value
                entities["keyword"] = keyword.value
                modified = true
                LogManager.w(TAG, "💡 补全搜索关键词: ${keyword.value}")
            }
        }
        
        return if (modified) {
            intent.copy(entities = entities)
        } else {
            intent
        }
    }
    
    /**
     * 补全打开应用意图
     */
    private fun completeAppIntent(intent: UserIntent, context: ConversationContext): UserIntent {
        val entities = intent.entities.toMutableMap()
        var modified = false
        
        // 补全应用名称
        if (entities["app_name"].isNullOrBlank() && entities["appName"].isNullOrBlank()) {
            context.getRecentEntity(EntityType.APP)?.let { app ->
                entities["app_name"] = app.value
                entities["appName"] = app.value
                modified = true
                LogManager.w(TAG, "💡 补全应用名称: ${app.value}")
            }
        }
        
        return if (modified) {
            intent.copy(entities = entities)
        } else {
            intent
        }
    }
}
