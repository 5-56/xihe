package com.example.xihe.understanding

import com.example.xihe.core.UserIntent
import kotlinx.serialization.Serializable

/**
 * 🧠 对话上下文 - 羲和的"记忆"系统
 * 记住对话历史、活跃实体、用户偏好等
 */
@Serializable
data class ConversationContext(
    // 对话历史（最近10轮）
    val history: List<Turn> = emptyList(),
    
    // 当前话题
    val currentTopic: Topic? = null,
    
    // 活跃实体（最近提到的人、应用、内容等）
    val activeEntities: Map<String, Entity> = emptyMap(),
    
    // 待确认的意图
    val pendingIntent: UserIntent? = null,
    
    // 用户偏好
    val userPreferences: UserPreferences = UserPreferences(),
    
    // 会话ID
    val sessionId: String = "",
    
    // 最后更新时间
    val lastUpdateTime: Long = System.currentTimeMillis()
) {
    /**
     * 添加新的对话轮次
     */
    fun addTurn(turn: Turn): ConversationContext {
        val newHistory = (history + turn).takeLast(10) // 只保留最近10轮
        return copy(
            history = newHistory,
            lastUpdateTime = System.currentTimeMillis()
        )
    }
    
    /**
     * 更新活跃实体
     */
    fun updateEntity(type: EntityType, value: String, confidence: Float = 0.9f): ConversationContext {
        val key = type.name
        val entity = Entity(
            type = type,
            value = value,
            lastMentioned = System.currentTimeMillis(),
            confidence = confidence
        )
        
        return copy(
            activeEntities = activeEntities + (key to entity),
            lastUpdateTime = System.currentTimeMillis()
        )
    }
    
    /**
     * 获取指定类型的最近实体
     */
    fun getRecentEntity(type: EntityType): Entity? {
        return activeEntities[type.name]
    }
    
    /**
     * 清理过期实体（超过5分钟未提及）
     */
    fun cleanupStaleEntities(): ConversationContext {
        val currentTime = System.currentTimeMillis()
        val fiveMinutes = 5 * 60 * 1000L
        
        val activeEntitiesFiltered = activeEntities.filter { (_, entity) ->
            (currentTime - entity.lastMentioned) < fiveMinutes
        }
        
        return copy(activeEntities = activeEntitiesFiltered)
    }
}

/**
 * 📝 对话轮次
 */
@Serializable
data class Turn(
    val userInput: String,
    val timestamp: Long,
    val recognizedIntent: UserIntent? = null,
    val systemResponse: String = "",
    val executionSuccess: Boolean = false
)

/**
 * 🏷️ 实体（人、应用、内容等）
 */
@Serializable
data class Entity(
    val type: EntityType,
    val value: String,
    val lastMentioned: Long,
    val confidence: Float
)

/**
 * 🎯 实体类型
 */
enum class EntityType {
    PERSON,      // 联系人/人名
    APP,         // 应用
    LOCATION,    // 地点
    TIME,        // 时间
    ACTION,      // 动作
    CONTENT,     // 内容/消息
    KEYWORD      // 关键词（搜索等）
}

/**
 * 📊 当前话题
 */
@Serializable
data class Topic(
    val name: String,           // 话题名称，如"发消息"、"搜索"
    val startTime: Long,        // 话题开始时间
    val relatedEntities: List<String> = emptyList() // 相关实体
)

/**
 * ⚙️ 用户偏好
 */
@Serializable
data class UserPreferences(
    // 常用联系人（用于智能推荐）
    val frequentContacts: List<String> = emptyList(),
    
    // 常用应用
    val frequentApps: List<String> = emptyList(),
    
    // 语音/文本偏好
    val preferVoice: Boolean = true,
    
    // 澄清偏好（是否喜欢主动澄清）
    val preferClarification: Boolean = true
)
