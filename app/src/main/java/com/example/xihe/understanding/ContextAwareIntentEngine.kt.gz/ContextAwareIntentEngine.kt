package com.example.xihe.understanding

import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.core.UserIntent

/**
 * 🧠 上下文感知意图引擎
 * 羲和的"大脑"，整合所有理解能力
 */
class ContextAwareIntentEngine private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "ContextAwareEngine"
        
        @Volatile
        private var instance: ContextAwareIntentEngine? = null
        
        fun getInstance(context: Context): ContextAwareIntentEngine {
            return instance ?: synchronized(this) {
                instance ?: ContextAwareIntentEngine(context.applicationContext).also {
                    instance = it
                }
            }
        }
    }
    
    // 核心组件
    private val contextManager = ConversationContextManager.getInstance(context)
    private val referenceResolver = ReferenceResolver()
    private val intentCompleter = IntentCompleter()
    private val implicitDetector = ImplicitIntentDetector()
    private val clarificationManager = ClarificationManager()
    
    /**
     * 🎯 处理用户输入，返回增强后的意图
     * 这是羲和理解用户的主入口
     */
    fun processInput(
        userInput: String,
        baseIntent: UserIntent? = null
    ): IntentProcessingResult {
        LogManager.d(TAG, " 开始处理输入: $userInput")
        
        // 1. 获取当前上下文
        val conversationContext = contextManager.currentContext.value
        
        // 2. 指代消解 - 理解"他"、"也"等指代
        val resolvedInput = referenceResolver.resolve(userInput, conversationContext)
        
        // 3. 检测隐含意图
        val implicitIntents = implicitDetector.detect(resolvedInput, conversationContext)
        
        // 4. 如果有基础意图，进行补全
        val enhancedIntent = if (baseIntent != null) {
            intentCompleter.complete(baseIntent, conversationContext)
        } else {
            baseIntent
        }
        
        // 5. 检查是否需要澄清
        val needsClarification = enhancedIntent?.let {
            clarificationManager.needsClarification(it, conversationContext)
        } ?: false
        
        val clarificationQuestion = if (needsClarification && enhancedIntent != null) {
            clarificationManager.generateClarificationQuestion(enhancedIntent, conversationContext)
        } else {
            null
        }
        
        // 6. 更新上下文
        if (enhancedIntent != null) {
            contextManager.updateEntitiesFromIntent(enhancedIntent)
        }
        
        // 7. 记录这一轮对话
        contextManager.addTurn(
            userInput = userInput,
            recognizedIntent = enhancedIntent
        )
        
        LogManager.d(TAG, " 处理完成: 解析后输入=$resolvedInput, 隐含意图数=${implicitIntents.size}, 需要澄清=$needsClarification")
        
        return IntentProcessingResult(
            originalInput = userInput,
            resolvedInput = resolvedInput,
            enhancedIntent = enhancedIntent,
            implicitIntents = implicitIntents,
            needsClarification = needsClarification,
            clarificationQuestion = clarificationQuestion,
            conversationContext = conversationContext
        )
    }
    
    /**
     * 🔄 更新执行结果
     */
    fun updateExecutionResult(
        userInput: String,
        intent: UserIntent?,
        systemResponse: String,
        success: Boolean
    ) {
        contextManager.addTurn(
            userInput = userInput,
            recognizedIntent = intent,
            systemResponse = systemResponse,
            executionSuccess = success
        )
    }
    
    /**
     * 📝 手动更新实体
     */
    fun updateEntity(type: EntityType, value: String, confidence: Float = 0.9f) {
        contextManager.updateEntity(type, value, confidence)
    }
    
    /**
     * 📚 获取对话历史摘要（用于LLM）
     */
    fun getHistorySummary(maxTurns: Int = 5): String {
        return contextManager.getHistorySummary(maxTurns)
    }
    
    /**
     * 🗑️ 清除会话
     */
    fun clearSession() {
        contextManager.clearSession()
    }
    
    /**
     * 💡 获取建议
     */
    fun getSuggestions(intent: UserIntent): List<String> {
        val context = contextManager.currentContext.value
        return clarificationManager.generateSuggestions(intent, context)
    }
}

/**
 * 🎯 意图处理结果
 */
data class IntentProcessingResult(
    val originalInput: String,           // 原始输入
    val resolvedInput: String,           // 消解后的输入
    val enhancedIntent: UserIntent?,     // 增强后的意图
    val implicitIntents: List<UserIntent>, // 隐含意图
    val needsClarification: Boolean,     // 是否需要澄清
    val clarificationQuestion: String?,  // 澄清问题
    val conversationContext: ConversationContext // 当前上下文
)
