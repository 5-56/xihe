package com.example.xihe.understanding

import com.example.xihe.utils.LogManager
import com.example.xihe.core.UserIntent

/**
 * ❓ 澄清管理器
 * 当意图不明确时主动询问用户
 */
class ClarificationManager {
    
    companion object {
        private const val TAG = "ClarificationManager"
        
        // 置信度阈值 - 降低以减少不必要的澄清
        private const val CLARIFICATION_THRESHOLD = 0.4
    }
    
    /**
     * 判断是否需要澄清
     */
    fun needsClarification(intent: UserIntent, context: ConversationContext): Boolean {
        // 🆕 对于复杂任务、信息查询、闲聊等，优先交给AI处理，不要求澄清
        if (intent.type in listOf("information_query", "casual_chat", "complex_task")) {
            LogManager.w(TAG, "✅ 复杂任务/信息查询，直接交给AI处理")
            return false
        }
        
        // 1. 置信度过低（阈值降低到0.4）
        if (intent.confidence < CLARIFICATION_THRESHOLD) {
            LogManager.w(TAG, "❓ 需要澄清: 置信度过低 (${intent.confidence})")
            return true
        }
        
        // 2. 缺少必需信息（仅对特定类型检查）
        if (isMissingRequiredInfo(intent)) {
            LogManager.w(TAG, "❓ 需要澄清: 缺少必需信息")
            return true
        }
        
        // 3. 有多个可能的理解
        if (hasAmbiguity(intent, context)) {
            LogManager.w(TAG, "❓ 需要澄清: 存在歧义")
            return true
        }
        
        return false
    }
    
    /**
     * 生成澄清问题
     */
    fun generateClarificationQuestion(intent: UserIntent, context: ConversationContext): String {
        return when {
            // 置信度低
            intent.confidence < 0.4 -> {
                "不好意思，我没太听懂你的意思，能再说详细一点吗？🤔"
            }
            
            // 根据意图类型生成特定问题
            intent.type in listOf("send_wechat_message", "send_message") -> {
                generateMessageClarification(intent)
            }
            
            intent.type == "open_app" -> {
                generateAppClarification(intent)
            }
            
            intent.type == "web_search" -> {
                generateSearchClarification(intent)
            }
            
            // 通用澄清
            else -> {
                "你是想让我${inferAction(intent.type)}吗？"
            }
        }
    }
    
    /**
     * 生成建议列表（多选一）
     */
    fun generateSuggestions(intent: UserIntent, context: ConversationContext): List<String> {
        val suggestions = mutableListOf<String>()
        
        when (intent.type) {
            "send_wechat_message", "send_message" -> {
                // 建议常用联系人
                context.userPreferences.frequentContacts.take(3).forEach { contact ->
                    suggestions.add("给$contact 发消息")
                }
            }
            
            "open_app" -> {
                // 建议常用应用
                context.userPreferences.frequentApps.take(5).forEach { app ->
                    suggestions.add("打开$app")
                }
            }
        }
        
        return suggestions
    }
    
    // ==================== 私有方法 ====================
    
    /**
     * 检查是否缺少必需信息
     */
    private fun isMissingRequiredInfo(intent: UserIntent): Boolean {
        return when (intent.type) {
            "send_wechat_message", "send_message" -> {
                // 只有contact和message都缺失才需要澄清
                (intent.entities["contact"].isNullOrBlank() && 
                 intent.entities["contactName"].isNullOrBlank()) ||
                intent.entities["message"].isNullOrBlank()
            }
            
            "open_app" -> {
                // 只有app_name缺失才需要澄清
                intent.entities["app_name"].isNullOrBlank() &&
                intent.entities["appName"].isNullOrBlank()
            }
            
            "web_search" -> {
                // 只有query缺失才需要澄清
                intent.entities["query"].isNullOrBlank() &&
                intent.entities["keyword"].isNullOrBlank()
            }
            
            // 🆕 对于信息查询和闲聊，不需要澄清，直接交给AI处理
            "information_query", "casual_chat", "complex_task" -> false
            
            else -> false
        }
    }
    
    /**
     * 检查是否存在歧义
     */
    private fun hasAmbiguity(intent: UserIntent, context: ConversationContext): Boolean {
        // 如果待确认意图与当前意图类似，可能有歧义
        val pendingIntent = context.pendingIntent
        if (pendingIntent != null && pendingIntent.type == intent.type) {
            return true
        }
        
        return false
    }
    
    /**
     * 生成消息相关的澄清问题
     */
    private fun generateMessageClarification(intent: UserIntent): String {
        return when {
            intent.entities["contact"].isNullOrBlank() &&
            intent.entities["contactName"].isNullOrBlank() -> {
                "你想给谁发消息呢？📱"
            }
            
            intent.entities["message"].isNullOrBlank() -> {
                "想发什么内容呢？💬"
            }
            
            intent.confidence < CLARIFICATION_THRESHOLD -> {
                val contact = intent.entities["contact"] ?: intent.entities["contactName"]
                val message = intent.entities["message"]
                "你是想给「${contact}」发送「${message}」吗？"
            }
            
            else -> "你要发消息是吗？"
        }
    }
    
    /**
     * 生成应用相关的澄清问题
     */
    private fun generateAppClarification(intent: UserIntent): String {
        return when {
            intent.entities["app_name"].isNullOrBlank() &&
            intent.entities["appName"].isNullOrBlank() -> {
                "你想打开哪个应用呢？📱"
            }
            
            else -> {
                val appName = intent.entities["app_name"] ?: intent.entities["appName"]
                "你是想打开「${appName}」吗？"
            }
        }
    }
    
    /**
     * 生成搜索相关的澄清问题
     */
    private fun generateSearchClarification(intent: UserIntent): String {
        return when {
            intent.entities["query"].isNullOrBlank() &&
            intent.entities["keyword"].isNullOrBlank() -> {
                "你想搜索什么呢？🔍"
            }
            
            else -> {
                val query = intent.entities["query"] ?: intent.entities["keyword"]
                "你是想搜索「${query}」吗？"
            }
        }
    }
    
    /**
     * 推测动作
     */
    private fun inferAction(intentType: String): String {
        return when (intentType) {
            "send_message", "send_wechat_message" -> "发消息"
            "open_app" -> "打开应用"
            "web_search" -> "搜索"
            "check_weather" -> "查天气"
            "order_food" -> "订餐"
            else -> "执行这个操作"
        }
    }
}
