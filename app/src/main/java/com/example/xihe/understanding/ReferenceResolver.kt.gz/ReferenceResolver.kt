package com.example.xihe.understanding

import com.example.xihe.utils.LogManager

/**
 * 🔗 指代消解器
 * 处理"他"、"她"、"那个"、"也"等指代词
 */
class ReferenceResolver {
    
    companion object {
        private const val TAG = "ReferenceResolver"
    }
    
    /**
     * 消解指代，返回完整的输入
     */
    fun resolve(input: String, context: ConversationContext): String {
        var resolved = input
        
        // 1. 消解人称代词
        resolved = resolvePronouns(resolved, context)
        
        // 2. 消解"也"、"同样"等副词
        resolved = resolveAdverbs(resolved, context)
        
        // 3. 消解"那个"、"这个"等指示代词
        resolved = resolveDemonstratives(resolved, context)
        
        if (resolved != input) {
            LogManager.w(TAG, "💡 指代消解: \"$input\" → \"$resolved\"")
        }
        
        return resolved
    }
    
    /**
     * 消解人称代词（他、她、它）
     */
    private fun resolvePronouns(input: String, context: ConversationContext): String {
        var resolved = input
        
        // 找到最近提到的人
        val recentPerson = context.getRecentEntity(EntityType.PERSON)
        
        if (recentPerson != null) {
            val pronouns = listOf("他", "她", "它", "ta")
            pronouns.forEach { pronoun ->
                if (resolved.contains(pronoun)) {
                    resolved = resolved.replace(pronoun, recentPerson.value)
                    LogManager.w(TAG, "代词消解: $pronoun → ${recentPerson.value}")
                }
            }
        }
        
        return resolved
    }
    
    /**
     * 消解"也"、"同样"、"再"等副词
     * 例如："给李四也发一条" → "给李四发消息说XXX"
     */
    private fun resolveAdverbs(input: String, context: ConversationContext): String {
        var resolved = input
        
        // 检测"也"、"同样"、"再"等词
        val alsoPatterns = listOf("也", "同样", "再", "还")
        
        if (alsoPatterns.any { resolved.contains(it) }) {
            // 如果有"也"，尝试从历史中获取相同的动作和内容
            val lastTurn = context.history.lastOrNull()
            if (lastTurn?.recognizedIntent != null) {
                val lastIntent = lastTurn.recognizedIntent
                
                // 如果是发消息类意图，复制消息内容
                if (lastIntent.type == "send_wechat_message" || lastIntent.type == "send_message") {
                    val lastMessage = lastIntent.entities["message"]
                    if (!lastMessage.isNullOrBlank()) {
                        // 如果当前输入中没有消息内容，补充上
                        if (!resolved.contains("说") && !resolved.contains("：")) {
                            resolved = resolved.replace("也", "")
                                .replace("同样", "")
                                .replace("再", "")
                            resolved = "${resolved}说${lastMessage}"
                            LogManager.w(TAG, "副词消解: 复制上次的消息内容 = $lastMessage")
                        }
                    }
                }
            }
        }
        
        return resolved
    }
    
    /**
     * 消解指示代词（那个、这个、那里）
     */
    private fun resolveDemonstratives(input: String, context: ConversationContext): String {
        var resolved = input
        
        // "那个人" → 最近提到的人
        if (resolved.matches(Regex(".*那个人.*"))) {
            val recentPerson = context.getRecentEntity(EntityType.PERSON)
            if (recentPerson != null) {
                resolved = resolved.replace("那个人", recentPerson.value)
                LogManager.w(TAG, "指示代词消解: 那个人 → ${recentPerson.value}")
            }
        }
        
        // "那个应用" → 最近打开的应用
        if (resolved.matches(Regex(".*那个(应用|app|软件).*"))) {
            val recentApp = context.getRecentEntity(EntityType.APP)
            if (recentApp != null) {
                resolved = resolved.replace(Regex("那个(应用|app|软件)"), recentApp.value)
                LogManager.w(TAG, "指示代词消解: 那个应用 → ${recentApp.value}")
            }
        }
        
        return resolved
    }
}
