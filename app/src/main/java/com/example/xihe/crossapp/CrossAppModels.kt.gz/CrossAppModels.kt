package com.example.xihe.crossapp

import kotlinx.serialization.Serializable

/**
 * 📱 跨应用任务模型
 */
@Serializable
data class CrossAppTask(
    val id: String,
    val name: String,
    val description: String,
    val steps: List<CrossAppStep>,
    val createdAt: Long = System.currentTimeMillis()
) {
    /**
     * 获取涉及的应用列表
     */
    fun getInvolvedApps(): List<String> {
        return steps.map { it.targetApp }.distinct()
    }
    
    /**
     * 获取任务预计执行时间
     */
    fun getEstimatedDuration(): Long {
        return steps.sumOf { it.estimatedDuration }
    }
}

/**
 * 📋 跨应用任务步骤
 */
@Serializable
data class CrossAppStep(
    val stepId: String,
    val targetApp: String,
    val targetPackage: String,
    val description: String,
    val action: CrossAppAction,
    val waitForElement: String? = null,
    val waitTimeout: Long = 5000L,
    val estimatedDuration: Long = 1000L,
    val required: Boolean = true
)

/**
 * 🎬 跨应用操作动作
 */
@Serializable
sealed class CrossAppAction {
    /**
     * 复制文本到剪贴板
     */
    @Serializable
    data class CopyText(
        val text: String,
        val label: String = "xihe_copy"
    ) : CrossAppAction()
    
    /**
     * 从剪贴板粘贴文本
     */
    @Serializable
    data class PasteText(
        val targetField: String,
        val clearBefore: Boolean = true
    ) : CrossAppAction()
    
    /**
     * 分享内容
     */
    @Serializable
    data class ShareContent(
        val content: String,
        val type: ShareType,
        val targetApp: String? = null
    ) : CrossAppAction()
    
    /**
     * 打开深度链接
     */
    @Serializable
    data class OpenDeepLink(
        val url: String,
        val fallbackAction: String? = null
    ) : CrossAppAction()
    
    /**
     * 截屏并保存
     */
    @Serializable
    data class CaptureScreen(
        val savePath: String? = null,
        val shareAfterCapture: Boolean = false
    ) : CrossAppAction()
    
    /**
     * 获取文本内容
     */
    @Serializable
    data class ExtractText(
        val selector: String,
        val variableName: String
    ) : CrossAppAction()
    
    /**
     * 点击元素
     */
    @Serializable
    data class ClickElement(
        val selector: String,
        val waitAfter: Long = 500L
    ) : CrossAppAction()
    
    /**
     * 输入文本
     */
    @Serializable
    data class InputText(
        val selector: String,
        val text: String,
        val clearBefore: Boolean = true
    ) : CrossAppAction()
    
    /**
     * 等待
     */
    @Serializable
    data class Wait(
        val duration: Long
    ) : CrossAppAction()
    
    /**
     * 自定义操作
     */
    @Serializable
    data class CustomOperation(
        val operation: String,
        val params: Map<String, String> = emptyMap()
    ) : CrossAppAction()
}

/**
 * 📤 分享类型
 */
enum class ShareType {
    TEXT,       // 纯文本
    IMAGE,      // 图片
    FILE,       // 文件
    LINK        // 链接
}

/**
 * 📋 剪贴板项
 */
data class ClipboardItem(
    val content: String,
    val type: ClipboardType,
    val timestamp: Long,
    val source: String? = null
)

/**
 * 📋 剪贴板类型
 */
enum class ClipboardType {
    TEXT,
    HTML,
    IMAGE,
    FILE,
    UNKNOWN
}

/**
 * ✅ 任务执行结果
 */
data class TaskResult(
    val success: Boolean,
    val message: String,
    val executedSteps: Int,
    val totalSteps: Int,
    val duration: Long,
    val data: Map<String, Any> = emptyMap(),
    val error: Throwable? = null
) {
    companion object {
        fun success(message: String, executedSteps: Int, totalSteps: Int, duration: Long): TaskResult {
            return TaskResult(
                success = true,
                message = message,
                executedSteps = executedSteps,
                totalSteps = totalSteps,
                duration = duration
            )
        }
        
        fun failed(message: String, executedSteps: Int = 0, totalSteps: Int = 0, error: Throwable? = null): TaskResult {
            return TaskResult(
                success = false,
                message = message,
                executedSteps = executedSteps,
                totalSteps = totalSteps,
                duration = 0,
                error = error
            )
        }
    }
}

/**
 * 📱 应用信息
 */
data class AppInfo(
    val packageName: String,
    val appName: String,
    val versionName: String,
    val versionCode: Long,
    val isSystemApp: Boolean,
    val isEnabled: Boolean
)

/**
 * 💾 应用状态
 */
data class AppState(
    val packageName: String,
    val currentPage: String,
    val savedData: Map<String, Any> = emptyMap(),
    val timestamp: Long = System.currentTimeMillis()
)
