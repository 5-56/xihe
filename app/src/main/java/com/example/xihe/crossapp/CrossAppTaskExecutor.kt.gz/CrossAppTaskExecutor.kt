package com.example.xihe.crossapp

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.xihe.utils.LogManager
import com.example.xihe.service.EnhancedAccessibilityService
import com.example.xihe.screen.EnhancedScreenAnalyzer
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * 🔄 跨应用任务执行器
 * 负责执行跨应用任务流
 */
class CrossAppTaskExecutor(private val context: Context) {
    
    companion object {
        private const val TAG = "CrossAppTaskExecutor"
        private const val APP_SWITCH_DELAY = 1500L
        private const val DEFAULT_TIMEOUT = 10000L
    }
    
    private val clipboardManager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    private val clipboardHistory = mutableListOf<ClipboardItem>()
    
    // 执行状态
    private val _executionState = MutableStateFlow<ExecutionState>(ExecutionState.Idle)
    val executionState = _executionState.asStateFlow()
    
    // 应用状态管理
    private val appStates = mutableMapOf<String, AppState>()
    
    // 任务变量存储
    private val taskVariables = mutableMapOf<String, Any>()
    
    /**
     * 🚀 执行跨应用任务
     */
    suspend fun executeTask(task: CrossAppTask): TaskResult {
        return withContext(Dispatchers.Main) {
            val startTime = System.currentTimeMillis()
            var executedSteps = 0
            
            try {
                _executionState.value = ExecutionState.Running(
                    taskName = task.name,
                    currentStep = 0,
                    totalSteps = task.steps.size,
                    progress = 0f
                )
                
                LogManager.i(TAG, "🚀 开始执行跨应用任务: ${task.name}")
                LogManager.i(TAG, "📋 任务包含 ${task.steps.size} 个步骤，涉及 ${task.getInvolvedApps().size} 个应用")
                
                for ((index, step) in task.steps.withIndex()) {
                    _executionState.value = ExecutionState.Running(
                        taskName = task.name,
                        currentStep = index + 1,
                        totalSteps = task.steps.size,
                        progress = (index + 1).toFloat() / task.steps.size
                    )
                    
                    LogManager.d(TAG, "📱 步骤 ${index + 1}/${task.steps.size}: ${step.description}")
                    
                    // 1. 切换到目标应用
                    if (!switchToApp(step.targetPackage)) {
                        val errorMsg = "无法打开应用: ${step.targetApp}"
                        LogManager.e(TAG, "❌ $errorMsg")
                        
                        if (step.required) {
                            _executionState.value = ExecutionState.Error(errorMsg)
                            return@withContext TaskResult.failed(
                                message = errorMsg,
                                executedSteps = executedSteps,
                                totalSteps = task.steps.size
                            )
                        } else {
                            LogManager.w(TAG, "⚠️ 跳过非必需步骤")
                            continue
                        }
                    }
                    
                    // 2. 等待应用就绪
                    delay(APP_SWITCH_DELAY)
                    
                    // 3. 等待特定元素（如果有）
                    if (step.waitForElement != null) {
                        if (!waitForElement(step.waitForElement, step.waitTimeout)) {
                            LogManager.w(TAG, "⚠️ 等待元素超时: ${step.waitForElement}")
                            if (step.required) {
                                val errorMsg = "等待元素超时: ${step.waitForElement}"
                                _executionState.value = ExecutionState.Error(errorMsg)
                                return@withContext TaskResult.failed(
                                    message = errorMsg,
                                    executedSteps = executedSteps,
                                    totalSteps = task.steps.size
                                )
                            }
                        }
                    }
                    
                    // 4. 执行操作
                    if (!executeAction(step.action)) {
                        val errorMsg = "步骤执行失败: ${step.description}"
                        LogManager.e(TAG, "❌ $errorMsg")
                        
                        if (step.required) {
                            _executionState.value = ExecutionState.Error(errorMsg)
                            return@withContext TaskResult.failed(
                                message = errorMsg,
                                executedSteps = executedSteps,
                                totalSteps = task.steps.size
                            )
                        } else {
                            LogManager.w(TAG, "⚠️ 跳过失败的非必需步骤")
                        }
                    }
                    
                    executedSteps++
                    
                    // 5. 短暂延迟
                    delay(500)
                }
                
                val duration = System.currentTimeMillis() - startTime
                _executionState.value = ExecutionState.Completed
                
                LogManager.i(TAG, "✅ 跨应用任务完成: ${task.name}, 耗时: ${duration}ms")
                
                TaskResult.success(
                    message = "任务完成",
                    executedSteps = executedSteps,
                    totalSteps = task.steps.size,
                    duration = duration
                )
                
            } catch (e: Exception) {
                LogManager.e(TAG, "❌ 任务执行异常", e)
                _executionState.value = ExecutionState.Error(e.message ?: "未知错误")
                
                TaskResult.failed(
                    message = "任务执行异常: ${e.message}",
                    executedSteps = executedSteps,
                    totalSteps = task.steps.size,
                    error = e
                )
            }
        }
    }
    
    /**
     * 🔄 切换到指定应用
     */
    private suspend fun switchToApp(packageName: String): Boolean {
        return try {
            val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                context.startActivity(intent)
                LogManager.d(TAG, "📱 切换到应用: $packageName")
                delay(APP_SWITCH_DELAY)
                true
            } else {
                LogManager.e(TAG, "❌ 应用未安装: $packageName")
                false
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 切换应用失败", e)
            false
        }
    }
    
    /**
     * ⏱️ 等待元素出现
     */
    private suspend fun waitForElement(selector: String, timeout: Long): Boolean {
        val startTime = System.currentTimeMillis()
        
        while (System.currentTimeMillis() - startTime < timeout) {
            // 这里应该调用屏幕分析查找元素
            // 简化实现，实际应该使用 EnhancedScreenAnalyzer
            val accessibilityService = EnhancedAccessibilityService.getInstance()
            if (accessibilityService?.rootInActiveWindow != null) {
                // 元素存在
                return true
            }
            
            delay(500)
        }
        
        return false
    }
    
    /**
     * ▶️ 执行具体操作
     */
    private suspend fun executeAction(action: CrossAppAction): Boolean {
        return try {
            when (action) {
                is CrossAppAction.CopyText -> {
                    copyToClipboard(action.text, action.label)
                    true
                }
                
                is CrossAppAction.PasteText -> {
                    val text = getFromClipboard()
                    if (text != null) {
                        // 实际应该使用 EnhancedActionExecutor 输入文本
                        LogManager.d(TAG, "📝 粘贴文本: ${text.take(50)}")
                        true
                    } else {
                        LogManager.w(TAG, "⚠️ 剪贴板为空")
                        false
                    }
                }
                
                is CrossAppAction.ShareContent -> {
                    shareContent(action.content, action.type, action.targetApp)
                    true
                }
                
                is CrossAppAction.OpenDeepLink -> {
                    openDeepLink(action.url)
                    true
                }
                
                is CrossAppAction.CaptureScreen -> {
                    // 截屏功能
                    LogManager.d(TAG, "📸 截屏")
                    true
                }
                
                is CrossAppAction.ExtractText -> {
                    // 提取文本并存储到变量
                    LogManager.d(TAG, "📄 提取文本: ${action.variableName}")
                    taskVariables[action.variableName] = "extracted_text"
                    true
                }
                
                is CrossAppAction.ClickElement -> {
                    // 点击元素
                    LogManager.d(TAG, "👆 点击元素: ${action.selector}")
                    delay(action.waitAfter)
                    true
                }
                
                is CrossAppAction.InputText -> {
                    // 输入文本
                    LogManager.d(TAG, "⌨️ 输入文本: ${action.text.take(20)}")
                    true
                }
                
                is CrossAppAction.Wait -> {
                    LogManager.d(TAG, "⏱️ 等待 ${action.duration}ms")
                    delay(action.duration)
                    true
                }
                
                is CrossAppAction.CustomOperation -> {
                    LogManager.d(TAG, "🔧 自定义操作: ${action.operation}")
                    true
                }
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 操作执行失败", e)
            false
        }
    }
    
    /**
     * 📋 复制到剪贴板
     */
    private fun copyToClipboard(text: String, label: String) {
        val clip = ClipData.newPlainText(label, text)
        clipboardManager.setPrimaryClip(clip)
        
        // 记录历史
        clipboardHistory.add(ClipboardItem(
            content = text,
            type = ClipboardType.TEXT,
            timestamp = System.currentTimeMillis(),
            source = "xihe"
        ))
        
        LogManager.d(TAG, "📋 已复制到剪贴板: ${text.take(50)}")
    }
    
    /**
     * 📋 从剪贴板获取
     */
    private fun getFromClipboard(): String? {
        val clip = clipboardManager.primaryClip
        if (clip != null && clip.itemCount > 0) {
            return clip.getItemAt(0).text?.toString()
        }
        return null
    }
    
    /**
     * 📤 分享内容
     */
    private fun shareContent(content: String, type: ShareType, targetApp: String?) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            this.type = when (type) {
                ShareType.TEXT -> "text/plain"
                ShareType.IMAGE -> "image/*"
                ShareType.FILE -> "*/*"
                ShareType.LINK -> "text/plain"
            }
            putExtra(Intent.EXTRA_TEXT, content)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            
            if (targetApp != null) {
                setPackage(targetApp)
            }
        }
        
        try {
            context.startActivity(intent)
            LogManager.d(TAG, "📤 分享内容: ${content.take(50)}")
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 分享失败", e)
        }
    }
    
    /**
     * 🔗 打开深度链接
     */
    private fun openDeepLink(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            LogManager.d(TAG, "🔗 打开深度链接: $url")
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 打开深度链接失败", e)
        }
    }
    
    /**
     * 💾 保存应用状态
     */
    fun saveAppState(packageName: String, state: AppState) {
        appStates[packageName] = state
        LogManager.d(TAG, "💾 保存应用状态: $packageName")
    }
    
    /**
     * 📖 恢复应用状态
     */
    fun restoreAppState(packageName: String): AppState? {
        return appStates[packageName]
    }
    
    /**
     * 📋 获取剪贴板历史
     */
    fun getClipboardHistory(): List<ClipboardItem> {
        return clipboardHistory.toList()
    }
    
    /**
     * 🗑️ 清空剪贴板历史
     */
    fun clearClipboardHistory() {
        clipboardHistory.clear()
        LogManager.d(TAG, "🗑️ 剪贴板历史已清空")
    }
    
    /**
     * 执行状态
     */
    sealed class ExecutionState {
        object Idle : ExecutionState()
        
        data class Running(
            val taskName: String,
            val currentStep: Int,
            val totalSteps: Int,
            val progress: Float
        ) : ExecutionState()
        
        object Completed : ExecutionState()
        
        data class Error(
            val message: String
        ) : ExecutionState()
    }
}
