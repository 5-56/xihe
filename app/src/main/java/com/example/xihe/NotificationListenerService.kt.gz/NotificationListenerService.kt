package com.example.xihe

import android.app.Notification
import android.content.Intent
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable

/**
 * 通知监听服务 - 让AI能够读取和响应系统通知
 * 
 * 功能：
 * 1. 监听所有应用的通知
 * 2. 提取通知内容（标题、文本、应用）
 * 3. 支持点击通知、清除通知
 * 4. 为AI提供通知上下文
 */
class NotificationListenerService : NotificationListenerService() {
    
    companion object {
        private const val TAG = "NotificationListener"
        
        var instance: NotificationListenerService? = null
            private set
        
        private val _isConnected = MutableStateFlow(false)
        val isConnected = _isConnected.asStateFlow()
        
        private val _recentNotifications = MutableStateFlow<List<NotificationData>>(emptyList())
        val recentNotifications = _recentNotifications.asStateFlow()
        
        const val MAX_NOTIFICATIONS = 50 // 最多保留50条通知
    }
    
    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        _isConnected.value = true
        LogManager.d(TAG, "Notification Listener Connected")
        
        // 读取现有通知
        loadActiveNotifications()
    }
    
    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        instance = null
        _isConnected.value = false
        LogManager.d(TAG, "Notification Listener Disconnected")
    }
    
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        
        if (sbn == null) return
        
        val notificationData = extractNotificationData(sbn)
        addNotification(notificationData)
        
        LogManager.d(TAG, "Notification Posted: ${notificationData.packageName} - ${notificationData.title}")
    }
    
    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        super.onNotificationRemoved(sbn)
        
        if (sbn == null) return
        
        LogManager.d(TAG, "Notification Removed: ${sbn.packageName} - ${sbn.notification.extras.getString(Notification.EXTRA_TITLE)}")
    }
    
    /**
     * 加载当前活动的通知
     */
    private fun loadActiveNotifications() {
        try {
            val activeNotifications = activeNotifications ?: return
            val notifications = activeNotifications.map { extractNotificationData(it) }
            _recentNotifications.value = notifications.takeLast(MAX_NOTIFICATIONS)
            LogManager.d(TAG, "Loaded ${notifications.size} active notifications")
        } catch (e: Exception) {
            LogManager.e(TAG, "Error loading active notifications: ${e.message}", e)
        }
    }
    
    /**
     * 添加通知到列表
     */
    private fun addNotification(notification: NotificationData) {
        val current = _recentNotifications.value.toMutableList()
        current.add(notification)
        
        // 保持最大数量限制
        if (current.size > MAX_NOTIFICATIONS) {
            current.removeAt(0)
        }
        
        _recentNotifications.value = current
    }
    
    /**
     * 提取通知数据
     */
    private fun extractNotificationData(sbn: StatusBarNotification): NotificationData {
        val notification = sbn.notification
        val extras = notification.extras
        
        val title = extras.getString(Notification.EXTRA_TITLE) ?: ""
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
        val subText = extras.getString(Notification.EXTRA_SUB_TEXT)
        
        // 完整文本（优先使用bigText）
        val fullText = bigText ?: text
        
        return NotificationData(
            key = sbn.key,
            packageName = sbn.packageName,
            title = title,
            text = fullText,
            subText = subText,
            time = sbn.postTime,
            category = notification.category,
            isClearable = sbn.isClearable,
            isOngoing = sbn.isOngoing
        )
    }
    
    /**
     * 点击通知（触发PendingIntent）
     */
    fun clickNotification(key: String): Boolean {
        try {
            val notifications = activeNotifications ?: return false
            val sbn = notifications.find { it.key == key } ?: return false
            
            val notification = sbn.notification
            val pendingIntent = notification.contentIntent
            
            if (pendingIntent != null) {
                pendingIntent.send()
                LogManager.d(TAG, "Clicked notification: $key")
                return true
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "Error clicking notification: ${e.message}", e)
        }
        return false
    }
    
    /**
     * 清除通知
     */
    fun dismissNotification(key: String): Boolean {
        try {
            cancelNotification(key)
            LogManager.d(TAG, "Dismissed notification: $key")
            return true
        } catch (e: Exception) {
            LogManager.e(TAG, "Error dismissing notification: ${e.message}", e)
            return false
        }
    }
    
    /**
     * 清除所有通知
     */
    fun dismissAllNotifications(): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                cancelAllNotifications()
                LogManager.d(TAG, "Dismissed all notifications")
                true
            } else {
                false
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "Error dismissing all notifications: ${e.message}", e)
            false
        }
    }
    
    /**
     * 获取指定应用的通知
     */
    fun getNotificationsByPackage(packageName: String): List<NotificationData> {
        return _recentNotifications.value.filter { it.packageName == packageName }
    }
    
    /**
     * 搜索通知内容
     */
    fun searchNotifications(query: String): List<NotificationData> {
        return _recentNotifications.value.filter {
            it.title.contains(query, ignoreCase = true) || 
            it.text.contains(query, ignoreCase = true)
        }
    }
}

/**
 * 通知数据
 */
@Serializable
data class NotificationData(
    val key: String,
    val packageName: String,
    val title: String,
    val text: String,
    val subText: String?,
    val time: Long,
    val category: String?,
    val isClearable: Boolean,
    val isOngoing: Boolean
)
