package com.example.xihe.maintenance

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Environment
import android.os.StatFs
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * 🔧 系统维护管理器
 * 提供垃圾清理、应用管理、性能优化等功能
 */
class SystemMaintenanceManager private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "SystemMaintenance"
        
        @Volatile
        private var instance: SystemMaintenanceManager? = null
        
        fun getInstance(context: Context): SystemMaintenanceManager {
            return instance ?: synchronized(this) {
                instance ?: SystemMaintenanceManager(context.applicationContext).also { instance = it }
            }
        }
    }
    
    private val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val packageManager = context.packageManager
    
    /**
     * 清理结果
     */
    data class CleanupResult(
        val success: Boolean,
        val freedSpace: Long = 0,
        val cacheCleared: Long = 0,
        val filesDeleted: Int = 0,
        val errorMessage: String? = null
    ) {
        fun getFreedSpaceFormatted(): String {
            val kb = freedSpace / 1024.0
            val mb = kb / 1024.0
            return when {
                mb >= 1 -> "%.2f MB".format(mb)
                kb >= 1 -> "%.2f KB".format(kb)
                else -> "$freedSpace B"
            }
        }
    }
    
    /**
     * 应用信息
     */
    data class AppInfo(
        val packageName: String,
        val appName: String,
        val versionName: String,
        val versionCode: Long,
        val size: Long,
        val isSystemApp: Boolean,
        val enabled: Boolean
    )
    
    // ==================== 垃圾清理 ====================
    
    /**
     * 🧹 清理应用缓存
     */
    suspend fun clearAppCache(): CleanupResult = withContext(Dispatchers.IO) {
        try {
            val cacheDir = context.cacheDir
            val externalCacheDir = context.externalCacheDir
            
            var totalFreed = 0L
            var filesDeleted = 0
            
            // 清理内部缓存
            if (cacheDir.exists()) {
                val result = deleteDirectory(cacheDir, false)
                totalFreed += result.first
                filesDeleted += result.second
            }
            
            // 清理外部缓存
            if (externalCacheDir != null && externalCacheDir.exists()) {
                val result = deleteDirectory(externalCacheDir, false)
                totalFreed += result.first
                filesDeleted += result.second
            }
            
            LogManager.i(TAG, "🧹 清理缓存完成: ${formatSize(totalFreed)}, $filesDeleted 个文件")
            CleanupResult(
                success = true,
                freedSpace = totalFreed,
                cacheCleared = totalFreed,
                filesDeleted = filesDeleted
            )
        } catch (e: Exception) {
            LogManager.e(TAG, "清理缓存失败", e)
            CleanupResult(false, errorMessage = e.message)
        }
    }
    
    /**
     * 🗑️ 清理临时文件
     */
    suspend fun clearTempFiles(): CleanupResult = withContext(Dispatchers.IO) {
        try {
            val tempDirs = listOf(
                File(context.filesDir, "temp"),
                File(context.getExternalFilesDir(null), "temp"),
                File(Environment.getExternalStorageDirectory(), ".tmp")
            )
            
            var totalFreed = 0L
            var filesDeleted = 0
            
            tempDirs.forEach { dir ->
                if (dir.exists()) {
                    val result = deleteDirectory(dir, true)
                    totalFreed += result.first
                    filesDeleted += result.second
                }
            }
            
            LogManager.i(TAG, "🗑️ 清理临时文件完成: ${formatSize(totalFreed)}, $filesDeleted 个文件")
            CleanupResult(
                success = true,
                freedSpace = totalFreed,
                filesDeleted = filesDeleted
            )
        } catch (e: Exception) {
            LogManager.e(TAG, "清理临时文件失败", e)
            CleanupResult(false, errorMessage = e.message)
        }
    }
    
    /**
     * 🧹 深度清理
     */
    suspend fun deepCleanup(): CleanupResult = withContext(Dispatchers.IO) {
        try {
            var totalFreed = 0L
            var filesDeleted = 0
            
            // 清理缓存
            val cacheResult = clearAppCache()
            totalFreed += cacheResult.freedSpace
            filesDeleted += cacheResult.filesDeleted
            
            // 清理临时文件
            val tempResult = clearTempFiles()
            totalFreed += tempResult.freedSpace
            filesDeleted += tempResult.filesDeleted
            
            LogManager.i(TAG, "🧹 深度清理完成: ${formatSize(totalFreed)}, $filesDeleted 个文件")
            CleanupResult(
                success = true,
                freedSpace = totalFreed,
                filesDeleted = filesDeleted
            )
        } catch (e: Exception) {
            LogManager.e(TAG, "深度清理失败", e)
            CleanupResult(false, errorMessage = e.message)
        }
    }
    
    /**
     * 📁 删除目录
     */
    private fun deleteDirectory(directory: File, deleteRoot: Boolean): Pair<Long, Int> {
        var totalSize = 0L
        var filesDeleted = 0
        
        try {
            directory.listFiles()?.forEach { file ->
                if (file.isDirectory) {
                    val result = deleteDirectory(file, true)
                    totalSize += result.first
                    filesDeleted += result.second
                } else {
                    totalSize += file.length()
                    if (file.delete()) {
                        filesDeleted++
                    }
                }
            }
            
            if (deleteRoot && directory.delete()) {
                filesDeleted++
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "删除目录失败: ${directory.path}", e)
        }
        
        return Pair(totalSize, filesDeleted)
    }
    
    // ==================== 应用管理 ====================
    
    /**
     * 📱 获取已安装应用列表
     */
    suspend fun getInstalledApps(): List<AppInfo> = withContext(Dispatchers.IO) {
        try {
            val packages = packageManager.getInstalledPackages(PackageManager.GET_META_DATA)
            
            packages.mapNotNull { packageInfo ->
                try {
                    val appInfo = packageInfo.applicationInfo ?: return@mapNotNull null
                    AppInfo(
                        packageName = packageInfo.packageName,
                        appName = packageManager.getApplicationLabel(appInfo).toString(),
                        versionName = packageInfo.versionName ?: "Unknown",
                        versionCode = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
                            packageInfo.longVersionCode
                        } else {
                            @Suppress("DEPRECATION")
                            packageInfo.versionCode.toLong()
                        },
                        size = getAppSize(packageInfo.packageName),
                        isSystemApp = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                        enabled = appInfo.enabled
                    )
                } catch (e: Exception) {
                    null
                }
            }.sortedBy { it.appName }
        } catch (e: Exception) {
            LogManager.e(TAG, "获取应用列表失败", e)
            emptyList()
        }
    }
    
    /**
     * 📱 获取用户应用列表（排除系统应用）
     */
    suspend fun getUserApps(): List<AppInfo> = withContext(Dispatchers.IO) {
        getInstalledApps().filter { !it.isSystemApp }
    }
    
    /**
     * 🗑️ 卸载应用
     */
    fun uninstallApp(packageName: String): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_DELETE)
            intent.data = Uri.parse("package:$packageName")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            LogManager.i(TAG, "🗑️ 请求卸载应用: $packageName")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "卸载应用失败", e)
            false
        }
    }
    
    /**
     * ⏹️ 强制停止应用
     */
    fun forceStopApp(packageName: String): Boolean {
        return try {
            activityManager.killBackgroundProcesses(packageName)
            LogManager.i(TAG, "⏹️ 强制停止应用: $packageName")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "强制停止应用失败", e)
            false
        }
    }
    
    /**
     * 🧹 清理应用数据
     */
    fun clearAppData(packageName: String): Boolean {
        return try {
            val intent = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            intent.data = Uri.parse("package:$packageName")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            LogManager.i(TAG, "🧹 打开应用详情页面: $packageName")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "打开应用详情失败", e)
            false
        }
    }
    
    /**
     * 📊 获取应用大小
     */
    private fun getAppSize(packageName: String): Long {
        return try {
            val appInfo = packageManager.getApplicationInfo(packageName, 0)
            var size = 0L
            
            appInfo.sourceDir?.let { sourceDir ->
                size += File(sourceDir).length()
            }
            
            appInfo.dataDir?.let { dataDir ->
                size += getFolderSize(File(dataDir))
            }
            
            size
        } catch (e: Exception) {
            0L
        }
    }
    
    private fun getFolderSize(folder: File): Long {
        var size = 0L
        try {
            folder.listFiles()?.forEach { file ->
                size += if (file.isDirectory) {
                    getFolderSize(file)
                } else {
                    file.length()
                }
            }
        } catch (e: Exception) {
            // Ignore permission errors
        }
        return size
    }
    
    // ==================== 性能优化 ====================
    
    /**
     * 🚀 释放内存
     */
    fun freeMemory(): Boolean {
        return try {
            System.gc()
            Runtime.getRuntime().gc()
            LogManager.i(TAG, "🚀 请求释放内存")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "释放内存失败", e)
            false
        }
    }
    
    /**
     * 📊 获取可优化项
     */
    suspend fun getOptimizationSuggestions(): List<OptimizationSuggestion> = withContext(Dispatchers.IO) {
        val suggestions = mutableListOf<OptimizationSuggestion>()
        
        // 检查存储空间
        val storageInfo = getStorageInfo()
        if (storageInfo.usagePercentage > 90) {
            suggestions.add(
                OptimizationSuggestion(
                    type = "storage",
                    severity = "high",
                    title = "存储空间不足",
                    description = "已使用${storageInfo.usagePercentage.toInt()}%的存储空间",
                    action = "清理缓存和临时文件"
                )
            )
        }
        
        // 检查内存使用
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        if (memoryInfo.lowMemory) {
            suggestions.add(
                OptimizationSuggestion(
                    type = "memory",
                    severity = "medium",
                    title = "内存不足",
                    description = "可用内存较低",
                    action = "关闭不必要的后台应用"
                )
            )
        }
        
        // 检查运行中的应用
        val runningApps = activityManager.runningAppProcesses?.size ?: 0
        if (runningApps > 20) {
            suggestions.add(
                OptimizationSuggestion(
                    type = "apps",
                    severity = "low",
                    title = "后台应用过多",
                    description = "有${runningApps}个应用在后台运行",
                    action = "强制停止不需要的应用"
                )
            )
        }
        
        suggestions
    }
    
    data class OptimizationSuggestion(
        val type: String,
        val severity: String,
        val title: String,
        val description: String,
        val action: String
    )
    
    /**
     * 💾 获取存储信息
     */
    private fun getStorageInfo(): StorageInfo {
        val path = Environment.getDataDirectory()
        val stat = StatFs(path.path)
        
        val totalSpace = stat.blockCountLong * stat.blockSizeLong
        val freeSpace = stat.availableBlocksLong * stat.blockSizeLong
        val usedSpace = totalSpace - freeSpace
        val usagePercentage = (usedSpace.toFloat() / totalSpace) * 100
        
        return StorageInfo(totalSpace, freeSpace, usedSpace, usagePercentage)
    }
    
    data class StorageInfo(
        val totalSpace: Long,
        val freeSpace: Long,
        val usedSpace: Long,
        val usagePercentage: Float
    )
    
    // ==================== 系统信息 ====================
    
    /**
     * 📊 获取系统详细信息
     */
    fun getSystemInfo(): SystemInfo {
        val runtime = Runtime.getRuntime()
        
        return SystemInfo(
            androidVersion = android.os.Build.VERSION.RELEASE,
            sdkVersion = android.os.Build.VERSION.SDK_INT,
            manufacturer = android.os.Build.MANUFACTURER,
            model = android.os.Build.MODEL,
            device = android.os.Build.DEVICE,
            totalMemory = runtime.maxMemory(),
            availableMemory = runtime.freeMemory(),
            totalProcessors = runtime.availableProcessors()
        )
    }
    
    data class SystemInfo(
        val androidVersion: String,
        val sdkVersion: Int,
        val manufacturer: String,
        val model: String,
        val device: String,
        val totalMemory: Long,
        val availableMemory: Long,
        val totalProcessors: Int
    )
    
    /**
     * 🔧 工具方法：格式化大小
     */
    private fun formatSize(bytes: Long): String {
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        
        return when {
            gb >= 1 -> "%.2f GB".format(gb)
            mb >= 1 -> "%.2f MB".format(mb)
            kb >= 1 -> "%.2f KB".format(kb)
            else -> "$bytes B"
        }
    }
    
    /**
     * ⚙️ 打开应用管理
     */
    fun openAppManagement(): Boolean {
        return try {
            val intent = Intent(android.provider.Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "打开应用管理失败", e)
            false
        }
    }
}
