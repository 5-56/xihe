package com.example.xihe.ocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import com.example.xihe.utils.LogManager
import android.view.WindowManager
import com.example.xihe.screen.ScreenAnalyzer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

/**
 * 屏幕 OCR 服务
 * 整合截图和 OCR 识别，提供完整的屏幕文字识别能力
 */
class ScreenOCRService(private val context: Context) {
    
    companion object {
        private const val TAG = "ScreenOCRService"
        
        @Volatile
        private var instance: ScreenOCRService? = null
        
        fun getInstance(context: Context): ScreenOCRService {
            return instance ?: synchronized(this) {
                instance ?: ScreenOCRService(context.applicationContext).also { instance = it }
            }
        }
    }
    
    private val ocrManager = OCRManager.getInstance(context)
    private val screenAnalyzer = ScreenAnalyzer()
    
    // 屏幕参数
    private val displayMetrics: DisplayMetrics by lazy {
        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        DisplayMetrics().also { 
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                it.setTo(context.resources.displayMetrics)
            } else {
                @Suppress("DEPRECATION")
                windowManager.defaultDisplay.getMetrics(it)
            }
        }
    }
    
    // MediaProjection 相关（用于截图）
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    
    // 缓存
    private var lastScreenBitmap: Bitmap? = null
    private var lastOCRResult: OCRManager.OCRResult? = null
    private var lastAnalysisTime: Long = 0
    
    /**
     * 设置 MediaProjection（需要用户授权）
     */
    fun setMediaProjection(projection: MediaProjection?) {
        this.mediaProjection = projection
        if (projection != null) {
            setupVirtualDisplay()
        }
    }
    
    /**
     * 设置虚拟显示器
     */
    private fun setupVirtualDisplay() {
        try {
            imageReader = ImageReader.newInstance(
                displayMetrics.widthPixels,
                displayMetrics.heightPixels,
                PixelFormat.RGBA_8888,
                2
            )
            
            virtualDisplay = mediaProjection?.createVirtualDisplay(
                "ScreenOCR",
                displayMetrics.widthPixels,
                displayMetrics.heightPixels,
                displayMetrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface,
                null,
                Handler(Looper.getMainLooper())
            )
            
            LogManager.i(TAG, "✅ 虚拟显示器设置成功: ${displayMetrics.widthPixels}x${displayMetrics.heightPixels}")
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 设置虚拟显示器失败", e)
        }
    }
    
    /**
     * 截取屏幕
     */
    suspend fun captureScreen(): Bitmap? = withContext(Dispatchers.IO) {
        if (imageReader == null) {
            LogManager.w(TAG, "⚠️ ImageReader 未初始化，需要先设置 MediaProjection")
            return@withContext null
        }
        
        try {
            val image = imageReader?.acquireLatestImage()
            if (image != null) {
                val bitmap = imageToBitmap(image)
                image.close()
                lastScreenBitmap = bitmap
                LogManager.i(TAG, "📷 截图成功: ${bitmap.width}x${bitmap.height}")
                return@withContext bitmap
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 截图失败", e)
        }
        
        return@withContext null
    }
    
    /**
     * Image 转 Bitmap
     */
    private fun imageToBitmap(image: Image): Bitmap {
        val planes = image.planes
        val buffer = planes[0].buffer
        val pixelStride = planes[0].pixelStride
        val rowStride = planes[0].rowStride
        val rowPadding = rowStride - pixelStride * image.width
        
        val bitmap = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride,
            image.height,
            Bitmap.Config.ARGB_8888
        )
        bitmap.copyPixelsFromBuffer(buffer)
        
        // 如果有 padding，裁剪掉
        return if (rowPadding > 0) {
            Bitmap.createBitmap(bitmap, 0, 0, image.width, image.height)
        } else {
            bitmap
        }
    }
    
    /**
     * 完整的屏幕 OCR 分析
     * @param bitmap 可选的已有截图，如果为空则自动截图
     * @return OCR 增强的屏幕分析结果
     */
    suspend fun analyzeScreenWithOCR(
        bitmap: Bitmap? = null
    ): ScreenOCRAnalysisResult = withContext(Dispatchers.Default) {
        val startTime = System.currentTimeMillis()
        
        // 获取截图
        val screenBitmap = bitmap ?: captureScreen()
        if (screenBitmap == null) {
            LogManager.w(TAG, "⚠️ 无法获取屏幕截图")
            return@withContext ScreenOCRAnalysisResult(
                success = false,
                errorMessage = "无法获取屏幕截图"
            )
        }
        
        try {
            // 执行 OCR 识别
            val ocrResult = ocrManager.recognizeText(screenBitmap, preferChinese = true)
            lastOCRResult = ocrResult
            lastAnalysisTime = System.currentTimeMillis()
            
            // 转换为 ScreenAnalyzer 的格式
            val ocrTexts = ocrResult.textBlocks.flatMap { block ->
                block.lines.map { line ->
                    ScreenAnalyzer.OCRDetectedText(
                        text = line.text,
                        bounds = line.boundingBox?.let { rect ->
                            ScreenAnalyzer.ElementBounds(
                                left = rect.left,
                                top = rect.top,
                                right = rect.right,
                                bottom = rect.bottom
                            )
                        } ?: ScreenAnalyzer.ElementBounds(0, 0, 0, 0),
                        confidence = 1.0f
                    )
                }
            }
            
            val totalTime = System.currentTimeMillis() - startTime
            LogManager.i(TAG, "✅ OCR 分析完成: ${ocrTexts.size} 个文本, 耗时 ${totalTime}ms")
            
            return@withContext ScreenOCRAnalysisResult(
                success = true,
                ocrTexts = ocrTexts,
                fullText = ocrResult.fullText,
                analysisTime = totalTime,
                screenWidth = screenBitmap.width,
                screenHeight = screenBitmap.height
            )
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ OCR 分析失败", e)
            return@withContext ScreenOCRAnalysisResult(
                success = false,
                errorMessage = e.message
            )
        }
    }
    
    /**
     * 在屏幕上查找文本
     */
    suspend fun findTextOnScreen(
        targetText: String,
        bitmap: Bitmap? = null
    ): TextSearchResult = withContext(Dispatchers.Default) {
        val analysisResult = analyzeScreenWithOCR(bitmap)
        
        if (!analysisResult.success) {
            return@withContext TextSearchResult(
                found = false,
                errorMessage = analysisResult.errorMessage
            )
        }
        
        // 查找匹配的文本
        val matches = ocrManager.findTextInResult(
            lastOCRResult ?: return@withContext TextSearchResult(found = false),
            targetText,
            fuzzyMatch = true
        )
        
        if (matches.isEmpty()) {
            return@withContext TextSearchResult(
                found = false,
                errorMessage = "未找到文本: $targetText"
            )
        }
        
        val bestMatch = matches.first()
        return@withContext TextSearchResult(
            found = true,
            matchedText = bestMatch.text,
            clickX = bestMatch.centerX,
            clickY = bestMatch.centerY,
            confidence = bestMatch.similarity,
            allMatches = matches.map { TextMatch(it.text, it.centerX, it.centerY, it.similarity) }
        )
    }
    
    /**
     * 获取点击位置附近的文本
     */
    suspend fun getTextNearPosition(
        x: Int,
        y: Int,
        maxDistance: Int = 100
    ): String? = withContext(Dispatchers.Default) {
        val ocrResult = lastOCRResult ?: return@withContext null
        val nearestText = ocrManager.findTextNearPosition(ocrResult, x, y, maxDistance)
        return@withContext nearestText?.text
    }
    
    /**
     * 获取所有可点击的文本位置
     */
    suspend fun getAllClickableTexts(): List<ClickableText> = withContext(Dispatchers.Default) {
        val ocrResult = lastOCRResult ?: return@withContext emptyList()
        return@withContext ocrManager.getAllClickableTextPositions(ocrResult)
    }
    
    /**
     * 获取缓存的 OCR 结果
     */
    fun getCachedOCRResult(): OCRManager.OCRResult? {
        return if (System.currentTimeMillis() - lastAnalysisTime < 1000) {
            lastOCRResult
        } else {
            null
        }
    }
    
    /**
     * 清理资源
     */
    fun cleanup() {
        try {
            virtualDisplay?.release()
            imageReader?.close()
            mediaProjection?.stop()
            ocrManager.cleanup()
            lastScreenBitmap?.recycle()
            lastScreenBitmap = null
            lastOCRResult = null
            LogManager.i(TAG, "🧹 ScreenOCRService 资源已清理")
        } catch (e: Exception) {
            LogManager.e(TAG, "清理资源失败", e)
        }
    }
}

/**
 * 屏幕 OCR 分析结果
 */
data class ScreenOCRAnalysisResult(
    val success: Boolean,
    val ocrTexts: List<ScreenAnalyzer.OCRDetectedText> = emptyList(),
    val fullText: String = "",
    val analysisTime: Long = 0,
    val screenWidth: Int = 0,
    val screenHeight: Int = 0,
    val errorMessage: String? = null
)

/**
 * 🔍 文本搜索结果
 */
data class TextSearchResult(
    val found: Boolean,
    val matchedText: String? = null,
    val clickX: Int = 0,
    val clickY: Int = 0,
    val confidence: Float = 0f,
    val allMatches: List<TextMatch> = emptyList(),
    val errorMessage: String? = null
)

/**
 * 📝 文本匹配项
 */
data class TextMatch(
    val text: String,
    val centerX: Int,
    val centerY: Int,
    val similarity: Float
)
