package com.example.xihe.ocr

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import com.example.xihe.utils.LogManager
import com.example.xihe.utils.ApiKeyHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * 🔮 DeepSeek-OCR 云端识别服务
 * 
 * 使用 SiliconFlow API 调用 DeepSeek-OCR 模型
 * 用于高精度文档、照片识别
 * 
 * 🌟 特点:
 * - 支持复杂文档识别
 * - 支持手写体识别
 * - 支持多语言混合识别
 * - 表格结构识别
 */
class DeepSeekOCRService(private val context: Context) {
    
    companion object {
        private const val TAG = "DeepSeekOCR"
        
        // SiliconFlow API 配置
        private const val API_BASE_URL = "https://api.siliconflow.cn/v1/chat/completions"
        // DeepSeek-OCR 模型（限时免费）
        private const val MODEL_NAME = "deepseek-ai/DeepSeek-OCR"
        
        // 连接配置
        private const val CONNECT_TIMEOUT = 30000  // 30秒
        private const val READ_TIMEOUT = 60000     // 60秒
        
        // 图片压缩配置
        private const val MAX_IMAGE_SIZE = 2048    // 最大边长
        private const val JPEG_QUALITY = 85        // JPEG质量
        
        @Volatile
        private var instance: DeepSeekOCRService? = null
        
        fun getInstance(context: Context): DeepSeekOCRService {
            return instance ?: synchronized(this) {
                instance ?: DeepSeekOCRService(context.applicationContext).also {
                    instance = it
                }
            }
        }
    }
    
    // API Key (应该从安全存储获取)
    private var apiKey: String = ""
    
    /**
     * 🔑 设置 API Key
     */
    fun setApiKey(key: String) {
        apiKey = key.trim()
        LogManager.i(TAG, "✅ API Key 已设置")
    }
    
    /**
     * 🔑 从加密存储加载 API Key
     */
    fun loadApiKey(): Boolean {
        val secureKey = ApiKeyHelper.getDeepSeekOcrApiKey(context).trim()
        if (secureKey.isNotEmpty()) {
            apiKey = secureKey
            return true
        }

        val legacyPrefs = context.getSharedPreferences("xihe_secure_prefs", Context.MODE_PRIVATE)
        val legacyKey = legacyPrefs.getString("deepseek_api_key", "")?.trim().orEmpty()
        if (legacyKey.isNotEmpty()) {
            ApiKeyHelper.saveDeepSeekOcrApiKey(context, legacyKey)
            legacyPrefs.edit().remove("deepseek_api_key").apply()
            apiKey = legacyKey
            return true
        }

        apiKey = ""
        return false
    }
    
    /**
     * 🔑 保存 API Key 到加密存储
     */
    fun saveApiKey(key: String) {
        val normalizedKey = key.trim()
        if (ApiKeyHelper.saveDeepSeekOcrApiKey(context, normalizedKey)) {
            apiKey = normalizedKey
            LogManager.i(TAG, "✅ API Key 已保存")
        }
    }
    
    /**
     * 📸 识别图片中的文字
     * 
     * @param bitmap 要识别的图片
     * @param prompt 自定义提示词(可选)
     * @return OCR识别结果
     */
    suspend fun recognizeImage(
        bitmap: Bitmap,
        prompt: String? = null
    ): DeepSeekOCRResult = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        
        if (apiKey.isEmpty()) {
            LogManager.e(TAG, "❌ API Key 未设置")
            return@withContext DeepSeekOCRResult(
                success = false,
                error = "API Key 未设置，请先配置 DeepSeek API Key"
            )
        }
        
        try {
            LogManager.i(TAG, "🔮 开始 DeepSeek-OCR 识别: ${bitmap.width}x${bitmap.height}")
            
            // 1. 压缩并编码图片
            val base64Image = encodeImageToBase64(bitmap)
            LogManager.d(TAG, "📦 图片已编码，大小: ${base64Image.length / 1024}KB")
            
            // 2. 构建请求
            val ocrPrompt = prompt ?: buildDefaultOCRPrompt()
            val requestBody = buildRequestBody(base64Image, ocrPrompt)
            
            // 3. 发送请求
            val response = sendRequest(requestBody)
            
            // 4. 解析响应
            val result = parseResponse(response, startTime)
            
            LogManager.i(TAG, "✅ DeepSeek-OCR 识别完成，耗时: ${result.recognitionTime}ms")
            result
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ DeepSeek-OCR 识别失败", e)
            DeepSeekOCRResult(
                success = false,
                error = "识别失败: ${e.message}",
                recognitionTime = System.currentTimeMillis() - startTime
            )
        }
    }
    
    /**
     * 📄 识别文档图片
     * 专门针对文档优化的识别
     */
    suspend fun recognizeDocument(bitmap: Bitmap): DeepSeekOCRResult {
        val documentPrompt = """
            请仔细识别这张文档图片中的所有文字内容。
            要求：
            1. 完整识别所有文字，不要遗漏
            2. 保持原始的段落结构和换行
            3. 如果有表格，请用 Markdown 表格格式输出
            4. 如果有标题，请标注标题层级
            5. 识别所有数字、日期、金额等关键信息
            
            请直接输出识别到的文字内容：
        """.trimIndent()
        
        return recognizeImage(bitmap, documentPrompt)
    }
    
    /**
     * 📷 识别照片中的文字
     * 适用于拍照场景
     */
    suspend fun recognizePhoto(bitmap: Bitmap): DeepSeekOCRResult {
        val photoPrompt = """
            请识别这张照片中的所有可见文字。
            包括：
            - 标牌、招牌上的文字
            - 商品标签、价格
            - 说明文字
            - 任何印刷或手写文字
            
            请直接输出识别到的文字内容：
        """.trimIndent()
        
        return recognizeImage(bitmap, photoPrompt)
    }
    
    /**
     * 📊 识别表格
     */
    suspend fun recognizeTable(bitmap: Bitmap): DeepSeekOCRResult {
        val tablePrompt = """
            请识别这张图片中的表格内容。
            要求：
            1. 识别表头和所有单元格内容
            2. 使用 Markdown 表格格式输出
            3. 保持行列结构
            4. 如果有合并单元格，请适当处理
            
            请输出识别到的表格：
        """.trimIndent()
        
        return recognizeImage(bitmap, tablePrompt)
    }
    
    /**
     * ✍️ 识别手写体
     */
    suspend fun recognizeHandwriting(bitmap: Bitmap): DeepSeekOCRResult {
        val handwritingPrompt = """
            请识别这张图片中的手写文字。
            注意：
            1. 这是手写内容，可能不太清晰
            2. 尽量准确识别每个字
            3. 如果某些字不确定，可以用[?]标注
            4. 保持原有的书写顺序
            
            请输出识别到的手写内容：
        """.trimIndent()
        
        return recognizeImage(bitmap, handwritingPrompt)
    }
    
    /**
     * 🎯 智能问答模式
     * 根据图片内容回答问题
     */
    suspend fun askAboutImage(bitmap: Bitmap, question: String): DeepSeekOCRResult {
        val qaPrompt = """
            请查看这张图片，然后回答以下问题：
            
            问题：$question
            
            请基于图片内容给出准确的回答：
        """.trimIndent()
        
        return recognizeImage(bitmap, qaPrompt)
    }
    
    /**
     * 📊 分析总结图片内容
     * 返回包含原始OCR文本和AI总结的结果
     */
    suspend fun analyzeAndSummarize(bitmap: Bitmap, userQuery: String? = null): AnalysisSummaryResult {
        return withContext(Dispatchers.IO) {
            val startTime = System.currentTimeMillis()
            
            try {
                if (!isConfigured()) {
                    LogManager.e(TAG, "❌ API Key 未配置")
                    return@withContext AnalysisSummaryResult(
                        success = false,
                        error = "API Key 未配置"
                    )
                }
                
                LogManager.i(TAG, "📊 开始分析总结图片... userQuery=$userQuery")
                
                // 构建一次性分析总结提示词（直接识别+总结）
                val analysisPrompt = if (userQuery != null) {
                    """
                        请仔细查看这张图片，完成以下任务：
                        
                        1. 首先，识别并提取图片中的所有文字内容
                        2. 然后，根据识别到的内容回答用户的问题
                        
                        用户问题：$userQuery
                        
                        请按以下格式回答：
                        
                        📝 识别内容：
                        [完整列出图片中识别到的所有文字]
                        
                        💡 回答：
                        [根据识别内容回答用户的问题]
                    """.trimIndent()
                } else {
                    """
                        请仔细查看这张图片，完成以下任务：
                        
                        1. 识别图片中的所有文字内容
                        2. 分析并总结图片的主要信息
                        
                        请按以下格式输出：
                        
                        📝 识别内容：
                        [完整列出图片中识别到的所有文字]
                        
                        📋 内容总结：
                        [用2-3句话概括图片的主要内容和关键信息]
                        
                        🏷️ 类型：
                        [判断这是什么类型的内容，如：文档、截图、照片、表格、票据等]
                    """.trimIndent()
                }
                
                // 一次 API 调用完成识别和总结
                val result = recognizeImage(bitmap, analysisPrompt)
                
                val endTime = System.currentTimeMillis()
                LogManager.d(TAG, "📊 分析完成，耗时: ${endTime - startTime}ms, success=${result.success}")
                
                if (result.success) {
                    LogManager.d(TAG, "📊 结果内容: ${result.text.take(200)}...")
                    AnalysisSummaryResult(
                        success = true,
                        rawOcrText = result.text,  // 整个回复作为原始文本
                        summary = result.text,      // 整个回复作为总结
                        recognitionTimeMs = endTime - startTime
                    )
                } else {
                    LogManager.e(TAG, "❌ 分析失败: ${result.error}")
                    AnalysisSummaryResult(
                        success = false,
                        error = result.error ?: "识别失败"
                    )
                }
                
            } catch (e: Exception) {
                LogManager.e(TAG, "❌ 分析总结异常", e)
                AnalysisSummaryResult(
                    success = false,
                    error = "分析失败: ${e.message}"
                )
            }
        }
    }
    
    // ==================== 私有方法 ====================
    
    /**
     * 🖼️ 将 Bitmap 编码为 Base64
     */
    private fun encodeImageToBase64(bitmap: Bitmap): String {
        // 压缩图片
        val scaledBitmap = scaleDownBitmap(bitmap)
        
        // 转换为 JPEG 并编码
        val outputStream = ByteArrayOutputStream()
        scaledBitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, outputStream)
        val imageBytes = outputStream.toByteArray()
        
        // 如果创建了新的 bitmap，回收它
        if (scaledBitmap != bitmap) {
            scaledBitmap.recycle()
        }
        
        return Base64.encodeToString(imageBytes, Base64.NO_WRAP)
    }
    
    /**
     * 📐 缩放图片
     */
    private fun scaleDownBitmap(bitmap: Bitmap): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        
        if (width <= MAX_IMAGE_SIZE && height <= MAX_IMAGE_SIZE) {
            return bitmap
        }
        
        val ratio = if (width > height) {
            MAX_IMAGE_SIZE.toFloat() / width
        } else {
            MAX_IMAGE_SIZE.toFloat() / height
        }
        
        val newWidth = (width * ratio).toInt()
        val newHeight = (height * ratio).toInt()
        
        LogManager.d(TAG, "📐 图片缩放: ${width}x${height} → ${newWidth}x${newHeight}")
        
        return Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true)
    }
    
    /**
     * 📋 构建默认 OCR 提示词
     * DeepSeek-OCR 需要特殊格式的提示词
     */
    private fun buildDefaultOCRPrompt(): String {
        // DeepSeek-OCR 专用提示词格式
        return "<image>\n<|grounding|>OCR this image."
    }
    
    /**
     * 🔧 构建 API 请求体
     */
    private fun buildRequestBody(base64Image: String, prompt: String): String {
        val messagesArray = JSONArray().apply {
            put(JSONObject().apply {
                put("role", "user")
                put("content", JSONArray().apply {
                    // 图片内容
                    put(JSONObject().apply {
                        put("type", "image_url")
                        put("image_url", JSONObject().apply {
                            put("url", "data:image/jpeg;base64,$base64Image")
                        })
                    })
                    // 文本提示
                    put(JSONObject().apply {
                        put("type", "text")
                        put("text", prompt)
                    })
                })
            })
        }
        
        return JSONObject().apply {
            put("model", MODEL_NAME)
            put("messages", messagesArray)
            put("max_tokens", 4096)
            put("temperature", 0.1)  // 低温度，提高准确性
            put("stream", false)
        }.toString()
    }
    
    /**
     * 🌐 发送 HTTP 请求
     */
    private fun sendRequest(requestBody: String): String {
        val url = URL(API_BASE_URL)
        val connection = url.openConnection() as HttpURLConnection
        
        try {
            connection.apply {
                requestMethod = "POST"
                connectTimeout = CONNECT_TIMEOUT
                readTimeout = READ_TIMEOUT
                doInput = true
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Authorization", "Bearer $apiKey")
            }
            
            // 写入请求体
            connection.outputStream.use { os ->
                os.write(requestBody.toByteArray(Charsets.UTF_8))
                os.flush()
            }
            
            // 检查响应码
            val responseCode = connection.responseCode
            LogManager.d(TAG, "📡 API 响应码: $responseCode")
            
            if (responseCode != HttpURLConnection.HTTP_OK) {
                val errorStream = connection.errorStream?.bufferedReader()?.readText() ?: "Unknown error"
                throw Exception("API 请求失败: $responseCode - $errorStream")
            }
            
            // 读取响应
            return connection.inputStream.bufferedReader().readText()
            
        } finally {
            connection.disconnect()
        }
    }
    
    /**
     * 📊 解析 API 响应
     */
    private fun parseResponse(response: String, startTime: Long): DeepSeekOCRResult {
        LogManager.d(TAG, "📥 原始响应: ${response.take(500)}...")
        
        val json = JSONObject(response)
        
        // 检查是否有错误
        if (json.has("error")) {
            val error = json.getJSONObject("error")
            val message = error.optString("message", "未知错误")
            LogManager.e(TAG, "❌ API 错误: $message")
            return DeepSeekOCRResult(
                success = false,
                error = message,
                recognitionTime = System.currentTimeMillis() - startTime
            )
        }
        
        // 提取识别结果
        val choices = json.optJSONArray("choices")
        if (choices == null || choices.length() == 0) {
            LogManager.e(TAG, "❌ choices 为空或不存在")
            return DeepSeekOCRResult(
                success = false,
                error = "API 返回空结果",
                recognitionTime = System.currentTimeMillis() - startTime
            )
        }
        
        val firstChoice = choices.getJSONObject(0)
        val message = firstChoice.optJSONObject("message")
        if (message == null) {
            LogManager.e(TAG, "❌ message 不存在")
            return DeepSeekOCRResult(
                success = false,
                error = "API 返回格式错误",
                recognitionTime = System.currentTimeMillis() - startTime
            )
        }
        
        // 处理 content - 可能是字符串或数组
        val content: String = try {
            // 先尝试作为字符串获取
            val contentStr = message.optString("content", "")
            if (contentStr.isNotEmpty()) {
                contentStr
            } else {
                // 尝试作为数组获取
                val contentArray = message.optJSONArray("content")
                if (contentArray != null && contentArray.length() > 0) {
                    val sb = StringBuilder()
                    for (i in 0 until contentArray.length()) {
                        val item = contentArray.get(i)
                        when (item) {
                            is String -> sb.append(item)
                            is JSONObject -> {
                                // 可能是 {"type": "text", "text": "..."} 格式
                                val text = item.optString("text", "")
                                if (text.isNotEmpty()) sb.append(text)
                            }
                        }
                    }
                    sb.toString()
                } else {
                    ""
                }
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "解析 content 失败", e)
            ""
        }
        
        LogManager.d(TAG, "📝 原始内容长度: ${content.length}, 内容: ${content.take(300)}...")
        
        // DeepSeek-OCR 返回格式: <|ref|>文字内容<|/ref|>，需要提取
        val extractedText = extractOCRText(content)
        LogManager.d(TAG, "📝 提取后内容长度: ${extractedText.length}")
        
        // 提取 token 使用情况
        val usage = json.optJSONObject("usage")
        val promptTokens = usage?.optInt("prompt_tokens", 0) ?: 0
        val completionTokens = usage?.optInt("completion_tokens", 0) ?: 0
        
        return DeepSeekOCRResult(
            success = true,
            text = extractedText,
            recognitionTime = System.currentTimeMillis() - startTime,
            promptTokens = promptTokens,
            completionTokens = completionTokens,
            model = MODEL_NAME
        )
    }
    
    /**
     * 🔍 提取 OCR 文本
     * DeepSeek-OCR 返回格式: <|ref|>文字内容<|/ref|>
     */
    private fun extractOCRText(content: String): String {
        if (content.isEmpty()) return ""
        
        // 尝试提取 <|ref|>...<|/ref|> 格式的内容
        val refPattern = Regex("<\\|ref\\|>(.*?)<\\|/ref\\|>", RegexOption.DOT_MATCHES_ALL)
        val matches = refPattern.findAll(content)
        val extractedTexts = matches.map { it.groupValues[1].trim() }.toList()
        
        if (extractedTexts.isNotEmpty()) {
            LogManager.d(TAG, "📝 从 <|ref|> 标签提取到 ${extractedTexts.size} 段文本")
            return extractedTexts.joinToString("\n")
        }
        
        // 如果没有 <|ref|> 标签，尝试清理其他标签
        val cleanedContent = content
            .replace(Regex("<\\|[^|]*\\|>"), "") // 移除所有 <|xxx|> 标签
            .replace(Regex("<image>"), "")       // 移除 <image> 标签
            .trim()
        
        // 如果清理后有内容，返回清理后的内容
        if (cleanedContent.isNotEmpty()) {
            return cleanedContent
        }
        
        // 最后返回原始内容
        return content
    }
    
    /**
     * 📊 检查服务状态
     */
    fun isConfigured(): Boolean = apiKey.isNotEmpty()
    
    /**
     * 📊 获取状态信息
     */
    fun getStatusInfo(): String {
        return """
            DeepSeek-OCR 服务状态:
            - API 已配置: ${if (apiKey.isNotEmpty()) "是" else "否"}
            - 模型: $MODEL_NAME
            - API 端点: $API_BASE_URL
        """.trimIndent()
    }
}

/**
 * 📊 DeepSeek-OCR 识别结果
 */
data class DeepSeekOCRResult(
    val success: Boolean,
    val text: String = "",
    val error: String? = null,
    val recognitionTime: Long = 0,
    val promptTokens: Int = 0,
    val completionTokens: Int = 0,
    val model: String = ""
)

/**
 * 📊 分析总结结果
 */
data class AnalysisSummaryResult(
    val success: Boolean,
    val rawOcrText: String = "",  // 原始 OCR 识别文本
    val summary: String = "",      // AI 总结内容
    val error: String? = null,
    val recognitionTimeMs: Long = 0
)
