package com.example.xihe.ocr

import android.graphics.Bitmap
import android.graphics.Rect
import android.util.Base64
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * 🌐 OCR.space 云端 OCR 客户端
 * 
 * 功能：
 * - 支持图片 URL 和 Base64 两种方式
 * - 支持多语言识别（中文、英文、日文等）
 * - 返回文字位置信息（overlay）
 * - 自动重试机制
 */
class OCRSpaceClient {
    
    // 支持的语言代码 - 移到类级别以便外部访问
    object Languages {
        const val CHINESE_SIMPLIFIED = "chs"  // 简体中文
        const val CHINESE_TRADITIONAL = "cht" // 繁体中文
        const val ENGLISH = "eng"             // 英文
        const val JAPANESE = "jpn"            // 日文
        const val KOREAN = "kor"              // 韩文
        const val AUTO = "auto"               // 自动检测
    }
    
    // 🔧 OCR 引擎选择 - 移到类级别以便外部访问
    object Engines {
        const val ENGINE_1 = 1  // 快速，适合清晰文档
        const val ENGINE_2 = 2  // 更准确，适合中文和复杂图片
    }
    
    companion object {
        private const val TAG = "OCRSpaceClient"
        private const val API_URL = "https://api.ocr.space/parse/image"
        
        // 内置 API Key
        private const val DEFAULT_API_KEY = "K87119668388957"
        
        @Volatile
        private var instance: OCRSpaceClient? = null
        
        fun getInstance(): OCRSpaceClient {
            return instance ?: synchronized(this) {
                instance ?: OCRSpaceClient().also { instance = it }
            }
        }
    }
    
    private var apiKey: String = DEFAULT_API_KEY
    
    // 📊 统计信息
    private var requestCount = 0
    private var successCount = 0
    private var failCount = 0
    private var totalResponseTime = 0L
    
    /**
     * 设置自定义 API Key
     */
    fun setApiKey(key: String) {
        if (key.isNotBlank()) {
            apiKey = key
            LogManager.d(TAG, "✅ 已设置自定义 API Key")
        }
    }
    
    /**
     * 📊 获取 API 统计信息
     */
    fun getApiStatistics(): ApiStatistics {
        return ApiStatistics(
            requestCount = requestCount,
            successCount = successCount,
            failCount = failCount,
            avgResponseTime = if (successCount > 0) totalResponseTime / successCount else 0,
            successRate = if (requestCount > 0) successCount.toFloat() / requestCount else 0f
        )
    }
    
    data class ApiStatistics(
        val requestCount: Int,
        val successCount: Int,
        val failCount: Int,
        val avgResponseTime: Long,
        val successRate: Float
    )
    
    /**
     * 📊 OCR.space 识别结果
     */
    data class OCRSpaceResult(
        val success: Boolean,
        val fullText: String,
        val textBlocks: List<TextBlock>,
        val errorMessage: String? = null,
        val processingTime: Long = 0,
        val language: String = ""
    )
    
    data class TextBlock(
        val text: String,
        val boundingBox: Rect?,
        val lines: List<TextLine>
    )
    
    data class TextLine(
        val text: String,
        val boundingBox: Rect?,
        val words: List<TextWord>
    )
    
    data class TextWord(
        val text: String,
        val boundingBox: Rect?,
        val centerX: Int,
        val centerY: Int
    )

    
    /**
     * 🔗 从图片 URL 识别文字
     */
    suspend fun recognizeFromUrl(
        imageUrl: String,
        language: String = Languages.CHINESE_SIMPLIFIED,
        isOverlayRequired: Boolean = true,
        engine: Int = Engines.ENGINE_2
    ): OCRSpaceResult = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        
        LogManager.d(TAG, "🌐 开始云端 OCR (URL): $imageUrl, engine=$engine")
        
        try {
            val result = sendOCRRequestWithUrl(
                imageUrl = imageUrl,
                language = language,
                isOverlayRequired = isOverlayRequired,
                engine = engine
            )
            
            val processingTime = System.currentTimeMillis() - startTime
            result.copy(processingTime = processingTime)
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 云端 OCR (URL) 失败", e)
            OCRSpaceResult(
                success = false,
                fullText = "",
                textBlocks = emptyList(),
                errorMessage = e.message,
                processingTime = System.currentTimeMillis() - startTime
            )
        }
    }
    
    /**
     * 🔄 将 Bitmap 转换为 Base64
     */
    private fun bitmapToBase64(bitmap: Bitmap): String {
        val outputStream = ByteArrayOutputStream()
        
        // 如果图片太大，先压缩
        val scaledBitmap = if (bitmap.width > 2000 || bitmap.height > 2000) {
            val scale = minOf(2000f / bitmap.width, 2000f / bitmap.height)
            Bitmap.createScaledBitmap(
                bitmap,
                (bitmap.width * scale).toInt(),
                (bitmap.height * scale).toInt(),
                true
            )
        } else {
            bitmap
        }
        
        scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
        val byteArray = outputStream.toByteArray()
        
        return Base64.encodeToString(byteArray, Base64.NO_WRAP)
    }
    
    /**
     * 📤 发送 OCR 请求 (Base64)
     */
    private fun sendOCRRequest(
        base64Image: String,
        language: String,
        isOverlayRequired: Boolean,
        engine: Int = Engines.ENGINE_2
    ): OCRSpaceResult {
        val url = URL(API_URL)
        val connection = url.openConnection() as HttpURLConnection
        
        try {
            connection.requestMethod = "POST"
            connection.setRequestProperty("User-Agent", "Mozilla/5.0")
            connection.setRequestProperty("Accept-Language", "en-US,en;q=0.5")
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            connection.doOutput = true
            connection.connectTimeout = 30000
            connection.readTimeout = 60000
            
            // 构建请求参数
            val postData = buildString {
                append("apikey=").append(URLEncoder.encode(apiKey, "UTF-8"))
                append("&isOverlayRequired=").append(isOverlayRequired)
                append("&language=").append(URLEncoder.encode(language, "UTF-8"))
                append("&base64Image=").append(URLEncoder.encode("data:image/jpeg;base64,$base64Image", "UTF-8"))
                append("&OCREngine=").append(engine)
                append("&scale=true")   // 自动缩放
                append("&isTable=false")
            }
            
            // 发送请求
            connection.outputStream.use { os ->
                os.write(postData.toByteArray(Charsets.UTF_8))
                os.flush()
            }
            
            // 读取响应
            val responseCode = connection.responseCode
            val response = if (responseCode == HttpURLConnection.HTTP_OK) {
                connection.inputStream.bufferedReader().use { it.readText() }
            } else {
                connection.errorStream?.bufferedReader()?.use { it.readText() } ?: "HTTP Error: $responseCode"
            }
            
            LogManager.d(TAG, "📥 API 响应码: $responseCode")
            
            return parseResponse(response, language)
            
        } finally {
            connection.disconnect()
        }
    }
    
    /**
     * 📤 发送 OCR 请求 (URL)
     */
    private fun sendOCRRequestWithUrl(
        imageUrl: String,
        language: String,
        isOverlayRequired: Boolean,
        engine: Int = Engines.ENGINE_2
    ): OCRSpaceResult {
        val url = URL(API_URL)
        val connection = url.openConnection() as HttpURLConnection
        
        try {
            connection.requestMethod = "POST"
            connection.setRequestProperty("User-Agent", "Mozilla/5.0")
            connection.setRequestProperty("Accept-Language", "en-US,en;q=0.5")
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            connection.doOutput = true
            connection.connectTimeout = 30000
            connection.readTimeout = 60000
            
            // 构建请求参数
            val postData = buildString {
                append("apikey=").append(URLEncoder.encode(apiKey, "UTF-8"))
                append("&isOverlayRequired=").append(isOverlayRequired)
                append("&language=").append(URLEncoder.encode(language, "UTF-8"))
                append("&url=").append(URLEncoder.encode(imageUrl, "UTF-8"))
                append("&OCREngine=").append(engine)
                append("&scale=true")
                append("&isTable=false")
            }
            
            // 发送请求
            connection.outputStream.use { os ->
                os.write(postData.toByteArray(Charsets.UTF_8))
                os.flush()
            }
            
            // 读取响应
            val responseCode = connection.responseCode
            val response = if (responseCode == HttpURLConnection.HTTP_OK) {
                connection.inputStream.bufferedReader().use { it.readText() }
            } else {
                connection.errorStream?.bufferedReader()?.use { it.readText() } ?: "HTTP Error: $responseCode"
            }
            
            LogManager.d(TAG, "📥 API (URL) 响应码: $responseCode")
            
            return parseResponse(response, language)
            
        } finally {
            connection.disconnect()
        }
    }
    
    /**
     * 📥 解析 OCR.space API 响应
     */
    private fun parseResponse(jsonResponse: String, language: String): OCRSpaceResult {
        try {
            val json = JSONObject(jsonResponse)
            
            // 检查是否有错误
            val isErroredOnProcessing = json.optBoolean("IsErroredOnProcessing", false)
            val ocrExitCode = json.optInt("OCRExitCode", -1)
            
            if (isErroredOnProcessing || ocrExitCode != 1) {
                val errorMessage = json.optString("ErrorMessage", "")
                val errorDetails = json.optJSONArray("ErrorDetails")?.let { arr ->
                    (0 until arr.length()).map { arr.getString(it) }.joinToString("; ")
                } ?: ""
                
                LogManager.w(TAG, "⚠️ OCR.space 错误: $errorMessage $errorDetails")
                
                return OCRSpaceResult(
                    success = false,
                    fullText = "",
                    textBlocks = emptyList(),
                    errorMessage = "$errorMessage $errorDetails".trim(),
                    language = language
                )
            }
            
            // 解析识别结果
            val parsedResults = json.optJSONArray("ParsedResults")
            if (parsedResults == null || parsedResults.length() == 0) {
                return OCRSpaceResult(
                    success = false,
                    fullText = "",
                    textBlocks = emptyList(),
                    errorMessage = "无识别结果",
                    language = language
                )
            }
            
            val textBlocks = mutableListOf<TextBlock>()
            val fullTextBuilder = StringBuilder()
            
            for (i in 0 until parsedResults.length()) {
                val result = parsedResults.getJSONObject(i)
                val parsedText = result.optString("ParsedText", "")
                
                if (parsedText.isNotEmpty()) {
                    fullTextBuilder.append(parsedText)
                    if (i < parsedResults.length() - 1) {
                        fullTextBuilder.append("\n")
                    }
                }
                
                // 解析 TextOverlay（如果有）
                val textOverlay = result.optJSONObject("TextOverlay")
                if (textOverlay != null) {
                    val lines = textOverlay.optJSONArray("Lines")
                    if (lines != null) {
                        for (j in 0 until lines.length()) {
                            val lineObj = lines.getJSONObject(j)
                            val lineText = lineObj.optString("LineText", "")
                            
                            // 解析行的位置信息
                            val maxHeight = lineObj.optInt("MaxHeight", 0)
                            val minTop = lineObj.optInt("MinTop", 0)
                            
                            // 解析单词
                            val words = lineObj.optJSONArray("Words")
                            val textWords = mutableListOf<TextWord>()
                            
                            if (words != null) {
                                for (k in 0 until words.length()) {
                                    val wordObj = words.getJSONObject(k)
                                    val wordText = wordObj.optString("WordText", "")
                                    val left = wordObj.optInt("Left", 0)
                                    val top = wordObj.optInt("Top", 0)
                                    val width = wordObj.optInt("Width", 0)
                                    val height = wordObj.optInt("Height", 0)
                                    
                                    val wordRect = Rect(left, top, left + width, top + height)
                                    textWords.add(TextWord(
                                        text = wordText,
                                        boundingBox = wordRect,
                                        centerX = wordRect.centerX(),
                                        centerY = wordRect.centerY()
                                    ))
                                }
                            }
                            
                            // 计算行的边界框
                            val lineRect = if (textWords.isNotEmpty()) {
                                val minLeft = textWords.minOf { it.boundingBox?.left ?: 0 }
                                val maxRight = textWords.maxOf { it.boundingBox?.right ?: 0 }
                                Rect(minLeft, minTop, maxRight, minTop + maxHeight)
                            } else {
                                null
                            }
                            
                            val textLine = TextLine(
                                text = lineText,
                                boundingBox = lineRect,
                                words = textWords
                            )
                            
                            textBlocks.add(TextBlock(
                                text = lineText,
                                boundingBox = lineRect,
                                lines = listOf(textLine)
                            ))
                        }
                    }
                } else {
                    // 没有 overlay 信息，简单处理
                    parsedText.split("\n").filter { it.isNotBlank() }.forEach { line ->
                        textBlocks.add(TextBlock(
                            text = line.trim(),
                            boundingBox = null,
                            lines = listOf(TextLine(
                                text = line.trim(),
                                boundingBox = null,
                                words = emptyList()
                            ))
                        ))
                    }
                }
            }
            
            return OCRSpaceResult(
                success = true,
                fullText = fullTextBuilder.toString().trim(),
                textBlocks = textBlocks,
                language = language
            )
            
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 解析 OCR 响应失败", e)
            return OCRSpaceResult(
                success = false,
                fullText = "",
                textBlocks = emptyList(),
                errorMessage = "解析响应失败: ${e.message}",
                language = language
            )
        }
    }
    
    /**
     * 🎯 从 Bitmap 识别文字（带引擎选择）
     */
    suspend fun recognizeFromBitmap(
        bitmap: Bitmap,
        language: String = Languages.CHINESE_SIMPLIFIED,
        isOverlayRequired: Boolean = true,
        engine: Int = Engines.ENGINE_2
    ): OCRSpaceResult = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        requestCount++
        
        LogManager.d(TAG, "🌐 开始云端 OCR 识别: ${bitmap.width}x${bitmap.height}, language=$language, engine=$engine")
        
        try {
            val base64Image = bitmapToBase64(bitmap)
            
            val result = sendOCRRequest(
                base64Image = base64Image,
                language = language,
                isOverlayRequired = isOverlayRequired,
                engine = engine
            )
            
            val processingTime = System.currentTimeMillis() - startTime
            LogManager.d(TAG, "✅ 云端 OCR 完成, 耗时 ${processingTime}ms")
            
            if (result.success) {
                successCount++
                totalResponseTime += processingTime
            } else {
                failCount++
            }
            
            result.copy(processingTime = processingTime)
            
        } catch (e: Exception) {
            failCount++
            LogManager.e(TAG, "❌ 云端 OCR 失败", e)
            OCRSpaceResult(
                success = false,
                fullText = "",
                textBlocks = emptyList(),
                errorMessage = e.message ?: "未知错误",
                processingTime = System.currentTimeMillis() - startTime
            )
        }
    }
    
    /**
     * 🔄 检查 API 配额状态
     */
    fun checkApiQuota(): String {
        return """
            OCR.space API 状态:
            - API Key: ${apiKey.take(8)}...
            - 请求次数: $requestCount
            - 成功次数: $successCount
            - 失败次数: $failCount
            - 成功率: ${if (requestCount > 0) String.format("%.1f%%", successCount.toFloat() / requestCount * 100) else "N/A"}
            - 平均响应时间: ${if (successCount > 0) totalResponseTime / successCount else 0}ms
        """.trimIndent()
    }
    
    /**
     * 🔄 重置统计
     */
    fun resetStatistics() {
        requestCount = 0
        successCount = 0
        failCount = 0
        totalResponseTime = 0L
        LogManager.d(TAG, "📊 API 统计已重置")
    }
    
    /**
     * 📊 简化结果类（用于 OCRManager 兼容）
     */
    data class SimpleResult(
        val success: Boolean,
        val parsedText: String,
        val errorMessage: String? = null
    )
    
    /**
     * 🔄 获取简化结果（用于 OCRManager 兼容）
     */
    fun OCRSpaceResult.toSimpleResult(): SimpleResult {
        return SimpleResult(
            success = this.success,
            parsedText = this.fullText,
            errorMessage = this.errorMessage
        )
    }
}
