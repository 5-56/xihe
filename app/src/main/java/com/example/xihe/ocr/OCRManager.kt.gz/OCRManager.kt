package com.example.xihe.ocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.example.xihe.utils.LogManager
import com.example.xihe.utils.GeometryUtils
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.abs

/**
 * 📝 OCR 文字识别管理器 (混合模式)
 * 🌐 优先使用 OCR.space 云端识别（精度更高）
 * 📱 离线时自动回退到 Google ML Kit 本地识别
 * 
 * 策略：
 * 1. 检查网络连接
 * 2. 有网络 → 使用 OCR.space 云端 API
 * 3. 无网络或云端失败 → 回退到 ML Kit 本地识别
 */
class OCRManager(private val context: Context) {
    
    companion object {
        private const val TAG = "OCRManager"
        
        // 🎯 离线模式配置
        private const val USE_OFFLINE_MODE = true  // 启用离线模式
        private const val OFFLINE_MODEL_PATH = "mlkit-google-ocr-models"  // assets中的模型路径
        
        // 🌐 混合模式配置
        private const val PREFER_CLOUD_OCR = true  // 优先使用云端 OCR
        private const val CLOUD_TIMEOUT_MS = 15000L  // 云端超时时间
        
        @Volatile
        private var instance: OCRManager? = null
        
        fun getInstance(context: Context): OCRManager {
            return instance ?: synchronized(this) {
                instance ?: OCRManager(context.applicationContext).also { instance = it }
            }
        }
    }
    
    /**
     * 🏷️ OCR 来源标识
     */
    enum class OCRSource {
        CLOUD_OCR_SPACE,  // OCR.space 云端
        LOCAL_ML_KIT,     // Google ML Kit 本地
        CACHE             // 缓存结果
    }
    
    // 初始化标志
    private var isInitialized = false
    
    // 🌐 OCR.space 云端客户端
    private val ocrSpaceClient: OCRSpaceClient by lazy {
        LogManager.d(TAG, "🔧 初始化 OCR.space 云端客户端")
        OCRSpaceClient()
    }
    
    // 中文识别器（也支持英文）
    private val chineseRecognizer: TextRecognizer by lazy {
        LogManager.d(TAG, "🔧 初始化中文识别器 [离线模式: $USE_OFFLINE_MODE]")
        val options = ChineseTextRecognizerOptions.Builder()
            .apply {
                if (USE_OFFLINE_MODE) {
                    LogManager.d(TAG, "📦 配置使用离线模型: $OFFLINE_MODEL_PATH")
                }
            }
            .build()
        
        TextRecognition.getClient(options).also {
            LogManager.i(TAG, "✅ 中文识别器初始化完成")
        }
    }
    
    // 拉丁文识别器（纯英文场景更快）
    private val latinRecognizer: TextRecognizer by lazy {
        LogManager.d(TAG, "🔧 初始化拉丁文识别器 [离线模式: $USE_OFFLINE_MODE]")
        val options = TextRecognizerOptions.Builder()
            .apply {
                if (USE_OFFLINE_MODE) {
                    LogManager.d(TAG, "📦 配置使用离线模型: $OFFLINE_MODEL_PATH")
                }
            }
            .build()
        
        TextRecognition.getClient(options).also {
            LogManager.i(TAG, "✅ 拉丁文识别器初始化完成")
        }
    }
    
    // 缓存最近的识别结果
    private var cachedResult: OCRResult? = null
    private var cacheTimestamp: Long = 0
    private val cacheValidDuration = 500L // 缓存有效期 500ms
    
    // 📊 统计信息
    private var totalRecognitions = 0
    private var cloudSuccessCount = 0
    private var localSuccessCount = 0
    private var cloudFailCount = 0
    private var totalCloudTime = 0L
    private var totalLocalTime = 0L
    
    // ⚙️ 配置选项
    private var maxRetryCount = 2  // 最大重试次数
    private var enableImagePreprocessing = true  // 启用图片预处理
    private var minConfidenceThreshold = 0.5f  // 最低置信度阈值
    
    /**
     * 📊 OCR 识别结果
     */
    data class OCRResult(
        val fullText: String,                           // 完整文本
        val textBlocks: List<TextBlock>,                // 文本块列表
        val recognitionTime: Long,                      // 识别耗时(ms)
        val imageWidth: Int,                            // 图片宽度
        val imageHeight: Int,                           // 图片高度
        val language: String = "mixed",                 // 识别语言
        val source: OCRSource = OCRSource.LOCAL_ML_KIT, // 🆕 OCR 来源
        val confidence: Float = 1.0f,                   // 🆕 整体置信度
        val retryCount: Int = 0                         // 🆕 重试次数
    )
    
    /**
     * 📦 文本块
     */
    data class TextBlock(
        val text: String,                               // 文本内容
        val boundingBox: Rect?,                         // 边界框
        val lines: List<TextLine>,                      // 行列表
        val confidence: Float? = null                   // 置信度
    )
    
    /**
     * 📝 文本行
     */
    data class TextLine(
        val text: String,                               // 行文本
        val boundingBox: Rect?,                         // 边界框
        val elements: List<TextElement>                 // 元素列表（单词/字符）
    )
    
    /**
     * 🔤 文本元素（单词或字符）
     */
    data class TextElement(
        val text: String,                               // 元素文本
        val boundingBox: Rect?,                         // 边界框
        val centerX: Int,                               // 中心X坐标
        val centerY: Int                                // 中心Y坐标
    )
    
    /**
     * 🎯 从 Bitmap 识别文字 (混合模式)
     * 优先使用云端 OCR.space，离线时回退到本地 ML Kit
     * 
     * @param bitmap 要识别的图片
     * @param preferChinese 是否优先使用中文识别器
     * @param forceLocal 强制使用本地识别（跳过云端）
     * @return OCR 识别结果
     */
    suspend fun recognizeText(
        bitmap: Bitmap,
        preferChinese: Boolean = true,
        forceLocal: Boolean = false
    ): OCRResult = withContext(Dispatchers.Default) {
        val startTime = System.currentTimeMillis()
        totalRecognitions++
        
        // 首次使用时初始化
        if (!isInitialized) {
            LogManager.i(TAG, "🚀 首次初始化 OCR Manager [混合模式: 云端优先=$PREFER_CLOUD_OCR]")
            checkOfflineModelAvailability()
            isInitialized = true
        }
        
        // 🖼️ 图片预处理
        val processedBitmap = if (enableImagePreprocessing) {
            preprocessImage(bitmap)
        } else {
            bitmap
        }
        
        LogManager.d(TAG, "🔍 开始 OCR 识别: ${processedBitmap.width}x${processedBitmap.height}, preferChinese=$preferChinese, forceLocal=$forceLocal")
        
        var retryCount = 0
        
        // 🌐 混合模式：优先尝试云端（带重试）
        if (PREFER_CLOUD_OCR && !forceLocal && isNetworkAvailable()) {
            LogManager.d(TAG, "🌐 网络可用，尝试 OCR.space 云端识别...")
            
            while (retryCount <= maxRetryCount) {
                try {
                    val cloudResult = recognizeWithCloud(processedBitmap, preferChinese, startTime)
                    if (cloudResult != null) {
                        // 评估结果质量
                        val confidence = evaluateResultConfidence(cloudResult)
                        
                        if (confidence >= minConfidenceThreshold) {
                            // 更新统计
                            cloudSuccessCount++
                            totalCloudTime += cloudResult.recognitionTime
                            
                            // 更新缓存
                            val finalResult = cloudResult.copy(confidence = confidence, retryCount = retryCount)
                            cachedResult = finalResult
                            cacheTimestamp = System.currentTimeMillis()
                            
                            LogManager.d(TAG, "✅ 云端 OCR 识别完成: ${finalResult.textBlocks.size} 个文本块, 耗时 ${finalResult.recognitionTime}ms, 置信度 ${String.format("%.2f", confidence)}")
                            return@withContext finalResult
                        } else {
                            LogManager.w(TAG, "⚠️ 云端结果置信度过低 ($confidence < $minConfidenceThreshold)，尝试本地识别")
                            break
                        }
                    }
                } catch (e: Exception) {
                    retryCount++
                    if (retryCount <= maxRetryCount) {
                        LogManager.w(TAG, "⚠️ 云端 OCR 失败 (尝试 $retryCount/$maxRetryCount): ${e.message}")
                        kotlinx.coroutines.delay(500L * retryCount) // 递增延迟
                    } else {
                        LogManager.w(TAG, "⚠️ 云端 OCR 重试次数已用尽，回退到本地: ${e.message}")
                        cloudFailCount++
                    }
                }
            }
        } else if (!forceLocal) {
            LogManager.d(TAG, "📴 网络不可用，使用本地 ML Kit 识别")
        }
        
        // 📱 本地 ML Kit 识别
        val inputImage = InputImage.fromBitmap(processedBitmap, 0)
        val recognizer = if (preferChinese) chineseRecognizer else latinRecognizer
        
        try {
            val text = recognizeWithRecognizer(inputImage, recognizer)
            val result = convertToOCRResult(text, processedBitmap.width, processedBitmap.height, startTime, OCRSource.LOCAL_ML_KIT)
            
            // 评估结果质量
            val confidence = evaluateResultConfidence(result)
            val finalResult = result.copy(confidence = confidence)
            
            // 更新统计
            localSuccessCount++
            totalLocalTime += finalResult.recognitionTime
            
            // 更新缓存
            cachedResult = finalResult
            cacheTimestamp = System.currentTimeMillis()
            
            LogManager.d(TAG, "✅ 本地 OCR 识别完成: ${finalResult.textBlocks.size} 个文本块, 耗时 ${finalResult.recognitionTime}ms, 置信度 ${String.format("%.2f", confidence)}")
            LogManager.d(TAG, "📝 识别文本预览: ${finalResult.fullText.take(100)}...")
            
            finalResult
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ OCR 识别失败", e)
            throw e
        }
    }
    
    /**
     * 🖼️ 图片预处理 - 提高识别准确率
     */
    private fun preprocessImage(bitmap: Bitmap): Bitmap {
        var processed = bitmap
        
        // 1. 尺寸调整 - 太小的图片放大，太大的图片缩小
        val minDimension = 300
        val maxDimension = 2000
        
        if (bitmap.width < minDimension || bitmap.height < minDimension) {
            val scale = maxOf(
                minDimension.toFloat() / bitmap.width,
                minDimension.toFloat() / bitmap.height
            )
            processed = Bitmap.createScaledBitmap(
                bitmap,
                (bitmap.width * scale).toInt(),
                (bitmap.height * scale).toInt(),
                true
            )
            LogManager.d(TAG, "🔍 图片放大: ${bitmap.width}x${bitmap.height} -> ${processed.width}x${processed.height}")
        } else if (bitmap.width > maxDimension || bitmap.height > maxDimension) {
            val scale = minOf(
                maxDimension.toFloat() / bitmap.width,
                maxDimension.toFloat() / bitmap.height
            )
            processed = Bitmap.createScaledBitmap(
                bitmap,
                (bitmap.width * scale).toInt(),
                (bitmap.height * scale).toInt(),
                true
            )
            LogManager.d(TAG, "🔍 图片缩小: ${bitmap.width}x${bitmap.height} -> ${processed.width}x${processed.height}")
        }
        
        return processed
    }
    
    /**
     * 📊 评估识别结果置信度
     */
    private fun evaluateResultConfidence(result: OCRResult): Float {
        if (result.fullText.isEmpty()) return 0f
        if (result.textBlocks.isEmpty()) return 0f
        
        var confidence = 1.0f
        
        // 1. 文本长度因素
        val textLength = result.fullText.length
        if (textLength < 3) {
            confidence *= 0.5f  // 太短的文本可能是误识别
        }
        
        // 2. 文本块数量因素
        val blockCount = result.textBlocks.size
        if (blockCount == 0) {
            confidence *= 0.3f
        }
        
        // 3. 特殊字符比例
        val specialCharRatio = result.fullText.count { !it.isLetterOrDigit() && !it.isWhitespace() }.toFloat() / textLength
        if (specialCharRatio > 0.5f) {
            confidence *= 0.7f  // 特殊字符过多可能是乱码
        }
        
        // 4. 位置信息完整性
        val blocksWithPosition = result.textBlocks.count { it.boundingBox != null }
        val positionRatio = if (result.textBlocks.isNotEmpty()) {
            blocksWithPosition.toFloat() / result.textBlocks.size
        } else 0f
        confidence *= (0.5f + 0.5f * positionRatio)
        
        return confidence.coerceIn(0f, 1f)
    }
    
    /**
     * 📦 批量识别多张图片
     */
    suspend fun recognizeTextBatch(
        bitmaps: List<Bitmap>,
        preferChinese: Boolean = true,
        forceLocal: Boolean = false
    ): List<OCRResult> = withContext(Dispatchers.Default) {
        LogManager.d(TAG, "📦 开始批量识别: ${bitmaps.size} 张图片")
        
        bitmaps.mapIndexed { index, bitmap ->
            LogManager.d(TAG, "📦 处理图片 ${index + 1}/${bitmaps.size}")
            try {
                recognizeText(bitmap, preferChinese, forceLocal)
            } catch (e: Exception) {
                LogManager.e(TAG, "❌ 图片 ${index + 1} 识别失败: ${e.message}")
                // 返回空结果
                OCRResult(
                    fullText = "",
                    textBlocks = emptyList(),
                    recognitionTime = 0,
                    imageWidth = bitmap.width,
                    imageHeight = bitmap.height,
                    source = OCRSource.LOCAL_ML_KIT,
                    confidence = 0f
                )
            }
        }
    }
    
    /**
     * 🔄 智能识别 - 自动选择最佳策略
     * 根据图片特征和历史数据选择最优识别方式
     */
    suspend fun recognizeTextSmart(
        bitmap: Bitmap,
        preferChinese: Boolean = true
    ): OCRResult = withContext(Dispatchers.Default) {
        // 分析图片特征
        val imageComplexity = analyzeImageComplexity(bitmap)
        
        // 根据历史成功率和图片复杂度选择策略
        val cloudSuccessRate = if (cloudSuccessCount + cloudFailCount > 0) {
            cloudSuccessCount.toFloat() / (cloudSuccessCount + cloudFailCount)
        } else 0.5f
        
        val useCloud = when {
            !isNetworkAvailable() -> false
            imageComplexity > 0.7f && cloudSuccessRate > 0.6f -> true  // 复杂图片且云端成功率高
            imageComplexity < 0.3f -> false  // 简单图片用本地即可
            cloudSuccessRate > 0.8f -> true  // 云端成功率很高
            else -> PREFER_CLOUD_OCR
        }
        
        LogManager.d(TAG, "🧠 智能选择: 图片复杂度=$imageComplexity, 云端成功率=$cloudSuccessRate, 使用云端=$useCloud")
        
        recognizeText(bitmap, preferChinese, forceLocal = !useCloud)
    }
    
    /**
     * 📊 分析图片复杂度 (0-1)
     */
    private fun analyzeImageComplexity(bitmap: Bitmap): Float {
        // 简化的复杂度分析
        val pixels = IntArray(bitmap.width * bitmap.height)
        bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
        
        // 计算颜色变化
        var colorVariance = 0L
        var prevPixel = pixels[0]
        for (pixel in pixels) {
            val diff = kotlin.math.abs(pixel - prevPixel)
            colorVariance += diff
            prevPixel = pixel
        }
        
        val avgVariance = colorVariance.toFloat() / pixels.size
        
        // 归一化到 0-1
        return (avgVariance / 1000000f).coerceIn(0f, 1f)
    }
    
    /**
     * 🌐 使用 OCR.space 云端识别
     */
    private suspend fun recognizeWithCloud(
        bitmap: Bitmap,
        preferChinese: Boolean,
        startTime: Long
    ): OCRResult? {
        val language = if (preferChinese) {
            OCRSpaceClient.Languages.CHINESE_SIMPLIFIED
        } else {
            OCRSpaceClient.Languages.ENGLISH
        }
        
        val cloudResult = ocrSpaceClient.recognizeFromBitmap(
            bitmap = bitmap,
            language = language,
            isOverlayRequired = true,
            engine = OCRSpaceClient.Engines.ENGINE_2
        )
        
        if (!cloudResult.success) {
            LogManager.w(TAG, "⚠️ OCR.space 返回失败: ${cloudResult.errorMessage}")
            return null
        }
        
        if (cloudResult.fullText.isEmpty()) {
            LogManager.w(TAG, "⚠️ OCR.space 返回空文本")
            return null
        }
        
        // 将云端结果转换为 OCRResult 格式
        val textBlocks = cloudResult.textBlocks.map { block ->
            TextBlock(
                text = block.text,
                boundingBox = block.boundingBox,
                lines = block.lines.map { line ->
                    TextLine(
                        text = line.text,
                        boundingBox = line.boundingBox,
                        elements = line.words.map { word ->
                            TextElement(
                                text = word.text,
                                boundingBox = word.boundingBox,
                                centerX = word.centerX,
                                centerY = word.centerY
                            )
                        }
                    )
                }
            )
        }
        
        return OCRResult(
            fullText = cloudResult.fullText,
            textBlocks = textBlocks,
            recognitionTime = System.currentTimeMillis() - startTime,
            imageWidth = bitmap.width,
            imageHeight = bitmap.height,
            language = if (preferChinese) "chinese" else "english",
            source = OCRSource.CLOUD_OCR_SPACE
        )
    }
    
    /**
     * 📶 检查网络是否可用
     */
    private fun isNetworkAvailable(): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        
        val network = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
        
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
               capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }
    
    /**
     * 🔄 使用识别器进行识别
     */
    private suspend fun recognizeWithRecognizer(
        inputImage: InputImage,
        recognizer: TextRecognizer
    ): Text = suspendCancellableCoroutine { continuation ->
        recognizer.process(inputImage)
            .addOnSuccessListener { text ->
                continuation.resume(text)
            }
            .addOnFailureListener { e ->
                continuation.resumeWithException(e)
            }
    }
    
    /**
     * 🔄 转换为 OCRResult
     */
    private fun convertToOCRResult(
        text: Text,
        imageWidth: Int,
        imageHeight: Int,
        startTime: Long,
        source: OCRSource = OCRSource.LOCAL_ML_KIT
    ): OCRResult {
        val textBlocks = text.textBlocks.map { block ->
            TextBlock(
                text = block.text,
                boundingBox = block.boundingBox,
                lines = block.lines.map { line ->
                    TextLine(
                        text = line.text,
                        boundingBox = line.boundingBox,
                        elements = line.elements.map { element ->
                            val box = element.boundingBox
                            TextElement(
                                text = element.text,
                                boundingBox = box,
                                centerX = box?.centerX() ?: 0,
                                centerY = box?.centerY() ?: 0
                            )
                        }
                    )
                }
            )
        }
        
        return OCRResult(
            fullText = text.text,
            textBlocks = textBlocks,
            recognitionTime = System.currentTimeMillis() - startTime,
            imageWidth = imageWidth,
            imageHeight = imageHeight,
            source = source
        )
    }
    
    /**
     * 🎯 在指定区域内查找文本
     * @param result OCR结果
     * @param targetText 要查找的文本
     * @param fuzzyMatch 是否模糊匹配
     * @return 匹配的文本元素列表
     */
    fun findTextInResult(
        result: OCRResult,
        targetText: String,
        fuzzyMatch: Boolean = true
    ): List<TextMatchResult> {
        val matches = mutableListOf<TextMatchResult>()
        val normalizedTarget = targetText.lowercase().trim()
        
        for (block in result.textBlocks) {
            for (line in block.lines) {
                // 行级别匹配
                if (matchText(line.text, normalizedTarget, fuzzyMatch)) {
                    matches.add(TextMatchResult(
                        text = line.text,
                        boundingBox = line.boundingBox,
                        matchType = MatchType.LINE,
                        similarity = calculateSimilarity(line.text, targetText)
                    ))
                }
                
                // 元素级别匹配
                for (element in line.elements) {
                    if (matchText(element.text, normalizedTarget, fuzzyMatch)) {
                        matches.add(TextMatchResult(
                            text = element.text,
                            boundingBox = element.boundingBox,
                            matchType = MatchType.ELEMENT,
                            centerX = element.centerX,
                            centerY = element.centerY,
                            similarity = calculateSimilarity(element.text, targetText)
                        ))
                    }
                }
            }
        }
        
        // 按相似度排序
        return matches.sortedByDescending { it.similarity }
    }
    
    /**
     * 🔍 匹配文本
     */
    private fun matchText(source: String, target: String, fuzzyMatch: Boolean): Boolean {
        val normalizedSource = source.lowercase().trim()
        
        return if (fuzzyMatch) {
            normalizedSource.contains(target) || 
            target.contains(normalizedSource) ||
            calculateSimilarity(normalizedSource, target) > 0.7f
        } else {
            normalizedSource == target
        }
    }
    
    /**
     * 📊 计算文本相似度（简化版 Levenshtein）
     */
    private fun calculateSimilarity(s1: String, s2: String): Float {
        if (s1 == s2) return 1.0f
        if (s1.isEmpty() || s2.isEmpty()) return 0.0f
        
        val str1 = s1.lowercase()
        val str2 = s2.lowercase()
        
        // 包含关系检查
        if (str1.contains(str2) || str2.contains(str1)) {
            val minLen = minOf(str1.length, str2.length)
            val maxLen = maxOf(str1.length, str2.length)
            return minLen.toFloat() / maxLen.toFloat()
        }
        
        // 简化的编辑距离
        val maxLen = maxOf(str1.length, str2.length)
        var matches = 0
        val minLen = minOf(str1.length, str2.length)
        
        for (i in 0 until minLen) {
            if (str1[i] == str2[i]) matches++
        }
        
        return matches.toFloat() / maxLen.toFloat()
    }
    
    /**
     * 📍 根据坐标查找最近的文本
     */
    fun findTextNearPosition(
        result: OCRResult,
        x: Int,
        y: Int,
        maxDistance: Int = 100
    ): TextMatchResult? {
        var nearestMatch: TextMatchResult? = null
        var minDistance = Int.MAX_VALUE
        
        for (block in result.textBlocks) {
            for (line in block.lines) {
                for (element in line.elements) {
                    val distance = calculateDistance(x, y, element.centerX, element.centerY)
                    if (distance < minDistance && distance <= maxDistance) {
                        minDistance = distance
                        nearestMatch = TextMatchResult(
                            text = element.text,
                            boundingBox = element.boundingBox,
                            matchType = MatchType.ELEMENT,
                            centerX = element.centerX,
                            centerY = element.centerY,
                            distance = distance
                        )
                    }
                }
            }
        }
        
        return nearestMatch
    }
    
    /**
     * 📏 计算距离 - 使用 GeometryUtils
     */
    private fun calculateDistance(x1: Int, y1: Int, x2: Int, y2: Int): Int {
        return GeometryUtils.calculateDistance(x1, y1, x2, y2).toInt()
    }
    
    /**
     * 🔍 在指定区域内查找文本
     */
    fun findTextInRegion(
        result: OCRResult,
        region: Rect
    ): List<TextMatchResult> {
        val matches = mutableListOf<TextMatchResult>()
        
        for (block in result.textBlocks) {
            for (line in block.lines) {
                val box = line.boundingBox
                if (box != null && Rect.intersects(region, box)) {
                    matches.add(TextMatchResult(
                        text = line.text,
                        boundingBox = box,
                        matchType = MatchType.LINE
                    ))
                }
            }
        }
        
        return matches
    }
    
    /**
     * 📊 获取屏幕所有可点击文本位置
     */
    fun getAllClickableTextPositions(result: OCRResult): List<ClickableText> {
        val clickables = mutableListOf<ClickableText>()
        
        for (block in result.textBlocks) {
            for (line in block.lines) {
                val box = line.boundingBox
                if (box != null) {
                    clickables.add(ClickableText(
                        text = line.text,
                        centerX = box.centerX(),
                        centerY = box.centerY(),
                        boundingBox = box
                    ))
                }
            }
        }
        
        return clickables
    }
    
    /**
     * 🔄 获取缓存结果（如果有效）
     */
    fun getCachedResult(): OCRResult? {
        val now = System.currentTimeMillis()
        return if (cachedResult != null && (now - cacheTimestamp) < cacheValidDuration) {
            cachedResult
        } else {
            null
        }
    }
    
    /**
     * 📦 检查离线模型可用性
     */
    private fun checkOfflineModelAvailability() {
        try {
            val assetManager = context.assets
            val modelFiles = assetManager.list(OFFLINE_MODEL_PATH)
            
            if (modelFiles != null && modelFiles.isNotEmpty()) {
                LogManager.i(TAG, "✅ 检测到离线OCR模型: ${modelFiles.size} 个文件/目录")
                LogManager.d(TAG, "📁 模型目录: $OFFLINE_MODEL_PATH")
                
                // 列出主要模型组件
                val components = listOf("aksara", "gocr", "taser")
                components.forEach { component ->
                    val componentPath = "$OFFLINE_MODEL_PATH/$component"
                    try {
                        val files = assetManager.list(componentPath)
                        if (files != null && files.isNotEmpty()) {
                            LogManager.d(TAG, "  ✓ $component: ${files.size} 个文件")
                        }
                    } catch (e: Exception) {
                        LogManager.w(TAG, "  ✗ $component: 不可用")
                    }
                }
                
                LogManager.i(TAG, "🎯 OCR 将使用离线模型进行识别")
            } else {
                LogManager.w(TAG, "⚠️ 未找到离线OCR模型，将使用在线模式")
                LogManager.d(TAG, "💡 提示: 将模型文件放到 assets/$OFFLINE_MODEL_PATH 以启用离线模式")
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 检查离线模型时出错: ${e.message}", e)
            LogManager.w(TAG, "⚠️ 将回退到在线模式")
        }
    }
    
    /**
     * 📊 获取OCR状态信息
     */
    fun getStatusInfo(): String {
        val networkStatus = if (isNetworkAvailable()) "已连接" else "离线"
        val lastSource = cachedResult?.source?.name ?: "无"
        val avgCloudTime = if (cloudSuccessCount > 0) totalCloudTime / cloudSuccessCount else 0
        val avgLocalTime = if (localSuccessCount > 0) totalLocalTime / localSuccessCount else 0
        val cloudSuccessRate = if (cloudSuccessCount + cloudFailCount > 0) {
            String.format("%.1f%%", cloudSuccessCount.toFloat() / (cloudSuccessCount + cloudFailCount) * 100)
        } else "N/A"
        
        return """
            OCR Manager 状态 (混合模式):
            ═══════════════════════════════
            📡 网络状态: $networkStatus
            🌐 云端优先: ${if (PREFER_CLOUD_OCR) "已启用" else "未启用"}
            📱 离线模式: ${if (USE_OFFLINE_MODE) "已启用" else "未启用"}
            🖼️ 图片预处理: ${if (enableImagePreprocessing) "已启用" else "未启用"}
            🔄 最大重试: $maxRetryCount 次
            📊 置信度阈值: $minConfidenceThreshold
            ═══════════════════════════════
            📈 统计信息:
            - 总识别次数: $totalRecognitions
            - 云端成功: $cloudSuccessCount (成功率: $cloudSuccessRate)
            - 本地成功: $localSuccessCount
            - 云端失败: $cloudFailCount
            - 平均云端耗时: ${avgCloudTime}ms
            - 平均本地耗时: ${avgLocalTime}ms
            ═══════════════════════════════
            💾 缓存状态:
            - 缓存有效: ${cachedResult != null && (System.currentTimeMillis() - cacheTimestamp) < cacheValidDuration}
            - 上次来源: $lastSource
            - 上次置信度: ${cachedResult?.confidence?.let { String.format("%.2f", it) } ?: "N/A"}
        """.trimIndent()
    }
    
    /**
     * 📊 获取统计数据
     */
    fun getStatistics(): OCRStatistics {
        return OCRStatistics(
            totalRecognitions = totalRecognitions,
            cloudSuccessCount = cloudSuccessCount,
            localSuccessCount = localSuccessCount,
            cloudFailCount = cloudFailCount,
            avgCloudTime = if (cloudSuccessCount > 0) totalCloudTime / cloudSuccessCount else 0,
            avgLocalTime = if (localSuccessCount > 0) totalLocalTime / localSuccessCount else 0,
            cloudSuccessRate = if (cloudSuccessCount + cloudFailCount > 0) {
                cloudSuccessCount.toFloat() / (cloudSuccessCount + cloudFailCount)
            } else 0f
        )
    }
    
    /**
     * 📊 OCR 统计数据
     */
    data class OCRStatistics(
        val totalRecognitions: Int,
        val cloudSuccessCount: Int,
        val localSuccessCount: Int,
        val cloudFailCount: Int,
        val avgCloudTime: Long,
        val avgLocalTime: Long,
        val cloudSuccessRate: Float
    )
    
    /**
     * ⚙️ 配置选项
     */
    fun configure(
        maxRetry: Int? = null,
        enablePreprocessing: Boolean? = null,
        minConfidence: Float? = null
    ) {
        maxRetry?.let { 
            maxRetryCount = it.coerceIn(0, 5)
            LogManager.d(TAG, "⚙️ 设置最大重试次数: $maxRetryCount")
        }
        enablePreprocessing?.let { 
            enableImagePreprocessing = it
            LogManager.d(TAG, "⚙️ 图片预处理: ${if (it) "启用" else "禁用"}")
        }
        minConfidence?.let { 
            minConfidenceThreshold = it.coerceIn(0f, 1f)
            LogManager.d(TAG, "⚙️ 设置置信度阈值: $minConfidenceThreshold")
        }
    }
    
    /**
     * 🔄 重置统计数据
     */
    fun resetStatistics() {
        totalRecognitions = 0
        cloudSuccessCount = 0
        localSuccessCount = 0
        cloudFailCount = 0
        totalCloudTime = 0L
        totalLocalTime = 0L
        LogManager.d(TAG, "📊 统计数据已重置")
    }
    
    /**
     * 🔑 设置自定义 OCR.space API Key
     * @param apiKey 自定义 API Key（留空则使用内置 Key）
     */
    fun setCloudApiKey(apiKey: String) {
        if (apiKey.isNotEmpty()) {
            ocrSpaceClient.setApiKey(apiKey)
            LogManager.i(TAG, "🔑 已设置自定义 OCR.space API Key")
        }
    }
    
    /**
     * 📱 强制使用本地 ML Kit 识别（跳过云端）
     */
    suspend fun recognizeTextLocal(
        bitmap: Bitmap,
        preferChinese: Boolean = true
    ): OCRResult {
        return recognizeText(bitmap, preferChinese, forceLocal = true)
    }
    
    /**
     * 🌐 强制使用云端 OCR.space 识别（需要网络）
     * @throws Exception 如果网络不可用或云端识别失败
     */
    suspend fun recognizeTextCloud(
        bitmap: Bitmap,
        preferChinese: Boolean = true
    ): OCRResult = withContext(Dispatchers.Default) {
        val startTime = System.currentTimeMillis()
        
        if (!isNetworkAvailable()) {
            throw Exception("网络不可用，无法使用云端 OCR")
        }
        
        val result = recognizeWithCloud(bitmap, preferChinese, startTime)
            ?: throw Exception("云端 OCR 识别失败")
        
        // 更新缓存
        cachedResult = result
        cacheTimestamp = System.currentTimeMillis()
        
        result
    }
    
    /**
     * 🧹 清理资源
     */
    fun cleanup() {
        try {
            chineseRecognizer.close()
            latinRecognizer.close()
            cachedResult = null
            isInitialized = false
            LogManager.d(TAG, "🧹 OCR 资源已清理")
        } catch (e: Exception) {
            LogManager.e(TAG, "清理 OCR 资源失败", e)
        }
    }
}

/**
 * 🎯 文本匹配结果
 */
data class TextMatchResult(
    val text: String,
    val boundingBox: Rect?,
    val matchType: MatchType,
    val centerX: Int = boundingBox?.centerX() ?: 0,
    val centerY: Int = boundingBox?.centerY() ?: 0,
    val similarity: Float = 1.0f,
    val distance: Int = 0
)

/**
 * 📍 可点击文本
 */
data class ClickableText(
    val text: String,
    val centerX: Int,
    val centerY: Int,
    val boundingBox: Rect
)

/**
 * 🏷️ 匹配类型
 */
enum class MatchType {
    BLOCK,      // 块级匹配
    LINE,       // 行级匹配
    ELEMENT     // 元素级匹配
}
