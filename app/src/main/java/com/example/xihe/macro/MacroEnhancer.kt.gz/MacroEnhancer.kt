package com.example.xihe.macro

import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.gesture.RecordedGesture
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.*

/**
 * 🎬 宏记录器增强版
 * 录制和回放复杂的操作序列
 */
class MacroEnhancer(private val context: Context) {
    
    companion object {
        private const val TAG = "MacroEnhancer"
        private const val MACROS_DIR = "macros"
        private const val MACRO_FILE_EXTENSION = ".macro"
        
        @Volatile
        private var instance: MacroEnhancer? = null
        
        fun getInstance(context: Context): MacroEnhancer {
            return instance ?: synchronized(this) {
                instance ?: MacroEnhancer(context.applicationContext).also { instance = it }
            }
        }
    }
    
    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
    }
    
    private val macrosMap = mutableMapOf<String, Macro>()
    private val _macros = MutableStateFlow<List<Macro>>(emptyList())
    val macros = _macros.asStateFlow()
    
    private val _isRecording = MutableStateFlow(false)
    val isRecording = _isRecording.asStateFlow()
    
    private var currentMacro: Macro? = null
    private val recordedActions = mutableListOf<MacroAction>()
    
    private val macrosDir: File by lazy {
        File(context.filesDir, MACROS_DIR).apply {
            if (!exists()) {
                mkdirs()
            }
        }
    }
    
    init {
        loadMacros()
    }
    
    /**
     * 🎬 开始录制宏
     */
    fun startRecording(name: String, description: String = ""): Boolean {
        return try {
            if (_isRecording.value) {
                LogManager.w(TAG, "⚠️ 已经在录制中")
                return false
            }
            
            currentMacro = Macro(
                id = UUID.randomUUID().toString(),
                name = name,
                description = description,
                actions = emptyList(),
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
            
            recordedActions.clear()
            _isRecording.value = true
            
            LogManager.i(TAG, "🎬 开始录制宏: $name")
            true
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 开始录制失败", e)
            false
        }
    }
    
    /**
     * ⏹️ 停止录制宏
     */
    suspend fun stopRecording(): Macro? {
        return try {
            if (!_isRecording.value) {
                LogManager.w(TAG, "⚠️ 没有在录制中")
                return null
            }
            
            val macro = currentMacro?.copy(
                actions = recordedActions.toList(),
                updatedAt = System.currentTimeMillis()
            )
            
            if (macro != null) {
                saveMacro(macro)
            }
            
            _isRecording.value = false
            currentMacro = null
            recordedActions.clear()
            
            LogManager.i(TAG, "⏹️ 停止录制宏: ${macro?.name}")
            macro
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 停止录制失败", e)
            null
        }
    }
    
    /**
     * 📝 记录动作
     */
    fun recordAction(action: MacroAction) {
        if (_isRecording.value) {
            recordedActions.add(action)
            LogManager.d(TAG, "📝 记录动作: ${action.type}")
        }
    }
    
    /**
     * ▶️ 执行宏
     */
    suspend fun executeMacro(
        macroId: String,
        onProgress: (Int, Int) -> Unit = { _, _ -> },
        onComplete: (Boolean) -> Unit = {}
    ) = withContext(Dispatchers.Main) {
        try {
            val macro = macrosMap[macroId]
            if (macro == null) {
                LogManager.w(TAG, "⚠️ 宏不存在: $macroId")
                onComplete(false)
                return@withContext
            }
            
            LogManager.i(TAG, "▶️ 开始执行宏: ${macro.name}")
            
            for ((index, action) in macro.actions.withIndex()) {
                onProgress(index + 1, macro.actions.size)
                
                when (action.type) {
                    MacroActionType.CLICK -> {
                        // 执行点击
                        delay(action.delay)
                    }
                    MacroActionType.INPUT -> {
                        // 执行输入
                        delay(action.delay)
                    }
                    MacroActionType.WAIT -> {
                        delay(action.parameters["duration"]?.toLongOrNull() ?: 1000L)
                    }
                    MacroActionType.GESTURE -> {
                        // 执行手势
                        delay(action.delay)
                    }
                    MacroActionType.SWIPE -> {
                        // 执行滑动
                        delay(action.delay)
                    }
                    MacroActionType.LONG_CLICK -> {
                        // 执行长按
                        delay(action.delay)
                    }
                    MacroActionType.OPEN_APP -> {
                        // 打开应用
                        delay(action.delay)
                    }
                    MacroActionType.SYSTEM_ACTION -> {
                        // 系统操作
                        delay(action.delay)
                    }
                }
            }
            
            LogManager.i(TAG, "✅ 宏执行完成: ${macro.name}")
            onComplete(true)
        } catch (e: Exception) {
            LogManager.e(TAG, "❌ 执行宏失败", e)
            onComplete(false)
        }
    }
    
    /**
     * 💾 保存宏
     */
    private suspend fun saveMacro(macro: Macro): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val file = File(macrosDir, "${macro.id}$MACRO_FILE_EXTENSION")
                val jsonString = json.encodeToString(macro)
                file.writeText(jsonString)
                
                macrosMap[macro.id] = macro
                updateMacrosList()
                
                LogManager.i(TAG, "💾 宏已保存: ${macro.name}")
                true
            } catch (e: Exception) {
                LogManager.e(TAG, "❌ 保存宏失败", e)
                false
            }
        }
    }
    
    /**
     * 📖 加载所有宏
     */
    private fun loadMacros() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val files = macrosDir.listFiles { file ->
                    file.extension == MACRO_FILE_EXTENSION.removePrefix(".")
                }
                
                files?.forEach { file ->
                    try {
                        val jsonString = file.readText()
                        val macro = json.decodeFromString<Macro>(jsonString)
                        macrosMap[macro.id] = macro
                    } catch (e: Exception) {
                        LogManager.e(TAG, "❌ 加载宏文件失败: ${file.name}", e)
                    }
                }
                
                updateMacrosList()
                LogManager.i(TAG, "📖 已加载 ${macrosMap.size} 个宏")
            } catch (e: Exception) {
                LogManager.e(TAG, "❌ 加载宏失败", e)
            }
        }
    }
    
    /**
     * 🗑️ 删除宏
     */
    suspend fun deleteMacro(macroId: String): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val file = File(macrosDir, "$macroId$MACRO_FILE_EXTENSION")
                val deleted = file.delete()
                
                if (deleted) {
                    macrosMap.remove(macroId)
                    updateMacrosList()
                    LogManager.i(TAG, "🗑️ 宏已删除: $macroId")
                }
                
                deleted
            } catch (e: Exception) {
                LogManager.e(TAG, "❌ 删除宏失败", e)
                false
            }
        }
    }
    
    /**
     * 🔍 根据ID获取宏
     */
    fun getMacroById(id: String): Macro? {
        return macrosMap[id]
    }
    
    /**
     * 🔍 搜索宏
     */
    fun searchMacros(query: String): List<Macro> {
        if (query.isBlank()) return macrosMap.values.toList()
        
        return macrosMap.values.filter { macro ->
            macro.name.contains(query, ignoreCase = true) ||
            macro.description.contains(query, ignoreCase = true) ||
            macro.tags.any { it.contains(query, ignoreCase = true) }
        }
    }
    
    /**
     * 📊 获取宏统计
     */
    fun getMacroStatistics(): MacroStatistics {
        val macros = macrosMap.values
        
        return MacroStatistics(
            totalMacros = macros.size,
            totalActions = macros.sumOf { it.actions.size },
            averageActionsPerMacro = if (macros.isNotEmpty()) 
                macros.sumOf { it.actions.size } / macros.size else 0,
            mostUsedMacro = macros.maxByOrNull { it.executionCount }
        )
    }
    
    /**
     * 🔄 更新宏列表
     */
    private fun updateMacrosList() {
        _macros.value = macrosMap.values
            .sortedByDescending { it.updatedAt }
    }
    
    // ============ 数据类型 ============
    
    /**
     * 🎬 宏
     */
    @Serializable
    data class Macro(
        val id: String,
        val name: String,
        val description: String,
        val actions: List<MacroAction>,
        val tags: List<String> = emptyList(),
        val createdAt: Long,
        val updatedAt: Long,
        val executionCount: Int = 0
    )
    
    /**
     * 🎯 宏动作
     */
    @Serializable
    data class MacroAction(
        val type: MacroActionType,
        val target: String = "",
        val parameters: Map<String, String> = emptyMap(),
        val delay: Long = 0L,
        val timestamp: Long = System.currentTimeMillis()
    )
    
    /**
     * 🏷️ 宏动作类型
     */
    @Serializable
    enum class MacroActionType {
        CLICK,          // 点击
        LONG_CLICK,     // 长按
        INPUT,          // 输入
        SWIPE,          // 滑动
        GESTURE,        // 手势
        WAIT,           // 等待
        OPEN_APP,       // 打开应用
        SYSTEM_ACTION   // 系统操作
    }
    
    /**
     * 📊 宏统计
     */
    data class MacroStatistics(
        val totalMacros: Int,
        val totalActions: Int,
        val averageActionsPerMacro: Int,
        val mostUsedMacro: Macro?
    )
}
