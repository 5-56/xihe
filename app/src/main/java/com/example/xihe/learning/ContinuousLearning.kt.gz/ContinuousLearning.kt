package com.example.xihe.learning

import android.content.Context
import com.example.xihe.utils.LogManager
import kotlinx.coroutines.*
import kotlinx.serialization.Serializable
import java.util.*

/**
 * 🧠 持续学习引擎
 * 让AI不断学习和优化
 */
class ContinuousLearningEngine(private val context: Context) {
    
    companion object {
        private const val TAG = "ContinuousLearning"
        private const val MIN_TRAINING_SAMPLES = 100
        private const val ACCURACY_THRESHOLD = 0.85f
    }
    
    private val userBehaviorDatabase = UserBehaviorDatabase(context)
    private val patternLibrary = mutableMapOf<String, UserPattern>()
    
    /**
     * 📝 记录用户操作
     */
    suspend fun recordUserAction(action: UserAction) {
        withContext(Dispatchers.IO) {
            try {
                // 1. 保存到数据库
                userBehaviorDatabase.insert(action)
                
                // 2. 实时分析模式
                analyzeActionPattern(action)
                
                LogManager.d(TAG, "📝 记录用户操作: ${action.type}")
            } catch (e: Exception) {
                LogManager.e(TAG, "❌ 记录操作失败", e)
            }
        }
    }
    
    /**
     * 🔍 分析用户行为模式
     */
    private suspend fun analyzeActionPattern(action: UserAction) {
        // 1. 提取时间模式
        val calendar = Calendar.getInstance()
        val hourOfDay = calendar.get(Calendar.HOUR_OF_DAY)
        val dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK)
        
        val timePattern = TimePattern(
            hourOfDay = hourOfDay,
            dayOfWeek = dayOfWeek,
            isWeekend = dayOfWeek in listOf(Calendar.SATURDAY, Calendar.SUNDAY)
        )
        
        // 2. 获取最近的操作
        val recentActions = userBehaviorDatabase.getRecentActions(limit = 10)
        
        // 3. 检测模式
        val pattern = detectPattern(recentActions, timePattern)
        
        // 4. 如果发现稳定模式，保存
        if (pattern != null && pattern.confidence > 0.8f) {
            saveUserPattern(pattern)
            LogManager.i(TAG, "🎯 发现用户模式: ${pattern.description}, 置信度: ${pattern.confidence}")
        }
    }
    
    /**
     * 🎯 检测操作模式
     */
    private fun detectPattern(
        actions: List<UserAction>,
        timePattern: TimePattern
    ): UserPattern? {
        if (actions.size < 3) return null
        
        // 检测操作序列
        val sequence = actions.map { it.type }.take(5)
        
        // 查找历史中是否有相似序列
        val similarPatterns = patternLibrary.values.filter { pattern ->
            val similarity = calculateSequenceSimilarity(sequence, pattern.actionSequence)
            similarity > 0.7f
        }
        
        if (similarPatterns.isNotEmpty()) {
            // 更新现有模式的频率
            val pattern = similarPatterns.first()
            return pattern.copy(
                frequency = pattern.frequency + 1,
                lastOccurrence = System.currentTimeMillis()
            )
        }
        
        // 创建新模式
        return UserPattern(
            id = UUID.randomUUID().toString(),
            description = generatePatternDescription(sequence),
            actionSequence = sequence,
            timePattern = timePattern,
            confidence = 0.6f,
            frequency = 1,
            lastOccurrence = System.currentTimeMillis()
        )
    }
    
    /**
     * 📊 计算序列相似度
     */
    private fun calculateSequenceSimilarity(seq1: List<String>, seq2: List<String>): Float {
        if (seq1.isEmpty() || seq2.isEmpty()) return 0f
        
        val minLength = minOf(seq1.size, seq2.size)
        var matchCount = 0
        
        for (i in 0 until minLength) {
            if (seq1[i] == seq2[i]) {
                matchCount++
            }
        }
        
        return matchCount.toFloat() / minLength
    }
    
    /**
     * 💾 保存用户模式
     */
    private fun saveUserPattern(pattern: UserPattern) {
        patternLibrary[pattern.id] = pattern
        LogManager.d(TAG, "💾 保存用户模式: ${pattern.description}")
    }
    
    /**
     * 🎁 获取个性化推荐
     */
    suspend fun getPersonalizedRecommendations(): List<Recommendation> {
        return withContext(Dispatchers.Default) {
            val recommendations = mutableListOf<Recommendation>()
            
            try {
                // 1. 基于时间的推荐
                val timeBasedTasks = findTasksForCurrentTime()
                recommendations.addAll(timeBasedTasks)
                
                // 2. 基于历史的推荐
                val frequentTasks = findFrequentTasks()
                recommendations.addAll(frequentTasks)
                
                // 3. 基于上下文的推荐
                val contextualTasks = findContextualTasks()
                recommendations.addAll(contextualTasks)
                
                // 按相关度排序
                recommendations.sortedByDescending { it.relevance }
            } catch (e: Exception) {
                LogManager.e(TAG, "❌ 生成推荐失败", e)
                emptyList()
            }
        }
    }
    
    /**
     * ⏰ 查找当前时间适合的任务
     */
    private fun findTasksForCurrentTime(): List<Recommendation> {
        val calendar = Calendar.getInstance()
        val hourOfDay = calendar.get(Calendar.HOUR_OF_DAY)
        
        return patternLibrary.values
            .filter { pattern ->
                pattern.timePattern.hourOfDay == hourOfDay
            }
            .map { pattern ->
                Recommendation(
                    task = pattern.description,
                    description = "根据您的习惯，现在可能需要执行此任务",
                    relevance = pattern.confidence * 0.8f,
                    reason = "时间模式匹配"
                )
            }
    }
    
    /**
     * 🔥 查找高频任务
     */
    private fun findFrequentTasks(): List<Recommendation> {
        return patternLibrary.values
            .sortedByDescending { it.frequency }
            .take(3)
            .map { pattern ->
                Recommendation(
                    task = pattern.description,
                    description = "您经常执行此任务",
                    relevance = pattern.frequency.toFloat() / 100f,
                    reason = "高频任务"
                )
            }
    }
    
    /**
     * 📍 查找上下文相关任务
     */
    private fun findContextualTasks(): List<Recommendation> {
        // 简化实现：基于最近操作推荐
        val recentActions = userBehaviorDatabase.getRecentActions(limit = 5)
        if (recentActions.isEmpty()) return emptyList()
        
        val lastAction = recentActions.first()
        
        // 查找经常跟随此操作的任务
        return patternLibrary.values
            .filter { pattern ->
                pattern.actionSequence.firstOrNull() == lastAction.type
            }
            .take(2)
            .map { pattern ->
                Recommendation(
                    task = pattern.description,
                    description = "根据当前操作，推荐执行此任务",
                    relevance = 0.7f,
                    reason = "上下文匹配"
                )
            }
    }
    
    /**
     * 📈 获取学习统计
     */
    fun getLearningStatistics(): LearningStatistics {
        val totalActions = userBehaviorDatabase.getTotalCount()
        val totalPatterns = patternLibrary.size
        val avgConfidence = patternLibrary.values.map { it.confidence }.average().toFloat()
        
        return LearningStatistics(
            totalActionsRecorded = totalActions,
            totalPatternsLearned = totalPatterns,
            averageConfidence = avgConfidence,
            mostFrequentPattern = patternLibrary.values.maxByOrNull { it.frequency }
        )
    }
    
    /**
     * 📝 生成模式描述
     */
    private fun generatePatternDescription(sequence: List<String>): String {
        return sequence.take(3).joinToString(" → ")
    }
    
    /**
     * 用户操作
     */
    @Serializable
    data class UserAction(
        val id: String = UUID.randomUUID().toString(),
        val type: String,
        val target: String,
        val context: Map<String, String> = emptyMap(),
        val timestamp: Long = System.currentTimeMillis(),
        val success: Boolean = true
    )
    
    /**
     * 用户模式
     */
    data class UserPattern(
        val id: String,
        val description: String,
        val actionSequence: List<String>,
        val timePattern: TimePattern,
        val confidence: Float,
        val frequency: Int,
        val lastOccurrence: Long
    )
    
    /**
     * 时间模式
     */
    data class TimePattern(
        val hourOfDay: Int,
        val dayOfWeek: Int,
        val isWeekend: Boolean
    )
    
    /**
     * 推荐
     */
    data class Recommendation(
        val task: String,
        val description: String,
        val relevance: Float,
        val reason: String
    )
    
    /**
     * 学习统计
     */
    data class LearningStatistics(
        val totalActionsRecorded: Int,
        val totalPatternsLearned: Int,
        val averageConfidence: Float,
        val mostFrequentPattern: UserPattern?
    )
}

/**
 * 📊 用户行为数据库（简化实现）
 */
class UserBehaviorDatabase(private val context: Context) {
    
    private val actions = mutableListOf<ContinuousLearningEngine.UserAction>()
    
    fun insert(action: ContinuousLearningEngine.UserAction) {
        actions.add(action)
        
        // 限制存储数量
        if (actions.size > 1000) {
            actions.removeAt(0)
        }
    }
    
    fun getRecentActions(limit: Int): List<ContinuousLearningEngine.UserAction> {
        return actions.takeLast(limit)
    }
    
    fun getTotalCount(): Int {
        return actions.size
    }
}
