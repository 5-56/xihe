package com.example.xihe.learning

import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.core.ContextMemory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

/**
 * 反馈学习系统 (Feedback Learning System)
 * 
 * 从用户行为和反馈中学习，不断改进AI的理解和执行能力
 * 
 * 功能：
 * 1. 执行结果反馈 - 记录成功/失败的操作
 * 2. 用户纠正学习 - 从用户纠正中学习正确理解
 * 3. 偏好学习 - 学习用户的操作偏好
 * 4. 模式识别 - 识别用户的使用模式
 * 5. 自动优化 - 根据学习结果自动优化
 */
object FeedbackLearningSystem {
    
    private const val TAG = "FeedbackLearning"
    private const val FEEDBACK_FILE = "feedback_learning.json"
    private const val MAX_FEEDBACK_RECORDS = 1000
    
    private val scope = CoroutineScope(Dispatchers.IO)
    private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }
    
    // ==================== 数据结构 ====================
    
    @Serializable
    data class FeedbackRecord(
        val id: String = java.util.UUID.randomUUID().toString(),
        val timestamp: Long = System.currentTimeMillis(),
        val userInput: String,
        val recognizedIntent: String,
        val executedAction: String,
        val success: Boolean,
        val userCorrection: String? = null,
        val errorMessage: String? = null,
        val executionTime: Long = 0
    )
    
    @Serializable
    data class IntentCorrection(
        val originalInput: String,
        val wrongIntent: String,
        val correctIntent: String,
        val occurrences: Int = 1
    )
    
    @Serializable
    data class UserPattern(
        val patternType: String,
        val trigger: String,
        val preferredAction: String,
        val confidence: Float,
        val occurrences: Int
    )
    
    @Serializable
    data class LearningData(
        val feedbackRecords: MutableList<FeedbackRecord> = mutableListOf(),
        val intentCorrections: MutableList<IntentCorrection> = mutableListOf(),
        val userPatterns: MutableList<UserPattern> = mutableListOf(),
        val successRate: Float = 0f,
        val totalExecutions: Int = 0,
        val totalSuccesses: Int = 0
    )
    
    private var learningData = LearningData()
    private var isInitialized = false
    
    // ==================== 初始化 ====================
    
    fun init(context: Context) {
        if (isInitialized) return
        loadLearningData(context)
        isInitialized = true
        LogManager.d(TAG, " 学习系统初始化完成！记录数: ${learningData.feedbackRecords.size}")
    }
    
    // ==================== 反馈记录 ====================
    
    /**
     * 记录执行成功
     */
    fun recordSuccess(
        context: Context,
        userInput: String,
        recognizedIntent: String,
        executedAction: String,
        executionTime: Long = 0
    ) {
        LogManager.d(TAG, " 记录成功: $userInput -> $recognizedIntent")
        
        val record = FeedbackRecord(
            userInput = userInput,
            recognizedIntent = recognizedIntent,
            executedAction = executedAction,
            success = true,
            executionTime = executionTime
        )
        
        addFeedbackRecord(context, record)
        updateSuccessRate(true)
        
        // 学习成功模式
        learnSuccessPattern(context, userInput, recognizedIntent)
    }
    
    /**
     * 记录执行失败
     */
    fun recordFailure(
        context: Context,
        userInput: String,
        recognizedIntent: String,
        executedAction: String,
        errorMessage: String
    ) {
        LogManager.d(TAG, " 记录失败: $userInput -> $recognizedIntent, 错误: $errorMessage")
        
        val record = FeedbackRecord(
            userInput = userInput,
            recognizedIntent = recognizedIntent,
            executedAction = executedAction,
            success = false,
            errorMessage = errorMessage
        )
        
        addFeedbackRecord(context, record)
        updateSuccessRate(false)
    }
    
    /**
     * 记录用户纠正（当AI理解错误时）
     */
    fun recordCorrection(
        context: Context,
        userInput: String,
        wrongIntent: String,
        correctIntent: String
    ) {
        LogManager.d(TAG, " 记录纠正: $userInput: $wrongIntent -> $correctIntent")
        
        // 更新纠正记录
        val existing = learningData.intentCorrections.find {
            it.originalInput.equals(userInput, ignoreCase = true) &&
            it.wrongIntent == wrongIntent
        }
        
        if (existing != null) {
            val updated = existing.copy(
                correctIntent = correctIntent,
                occurrences = existing.occurrences + 1
            )
            learningData.intentCorrections.remove(existing)
            learningData.intentCorrections.add(updated)
        } else {
            learningData.intentCorrections.add(IntentCorrection(
                originalInput = userInput,
                wrongIntent = wrongIntent,
                correctIntent = correctIntent
            ))
        }
        
        // 同时更新记忆系统
        ContextMemory.addLongTermMemory(
            context,
            "意图纠正:$userInput",
            "正确意图是$correctIntent，不是$wrongIntent",
            ContextMemory.MemoryCategory.LEARNING
        )
        
        saveLearningData(context)
    }
    
    // ==================== 学习与优化 ====================
    
    /**
     * 学习成功模式
     */
    private fun learnSuccessPattern(context: Context, input: String, intent: String) {
        // 提取关键词
        val keywords = extractKeywords(input)
        
        for (keyword in keywords) {
            val existing = learningData.userPatterns.find {
                it.trigger.equals(keyword, ignoreCase = true) &&
                it.preferredAction == intent
            }
            
            if (existing != null) {
                val updated = existing.copy(
                    occurrences = existing.occurrences + 1,
                    confidence = minOf(0.99f, existing.confidence + 0.05f)
                )
                learningData.userPatterns.remove(existing)
                learningData.userPatterns.add(updated)
            } else {
                learningData.userPatterns.add(UserPattern(
                    patternType = "keyword_intent",
                    trigger = keyword,
                    preferredAction = intent,
                    confidence = 0.5f,
                    occurrences = 1
                ))
            }
        }
        
        // 限制模式数量
        while (learningData.userPatterns.size > 200) {
            val lowest = learningData.userPatterns.minByOrNull { it.confidence * it.occurrences }
            if (lowest != null) {
                learningData.userPatterns.remove(lowest)
            }
        }
        
        saveLearningData(context)
    }
    
    /**
     * 根据学习数据优化意图识别
     */
    fun getLearnedIntentHint(input: String): String? {
        // 检查是否有纠正记录
        val correction = learningData.intentCorrections.find {
            input.lowercase().contains(it.originalInput.lowercase()) &&
            it.occurrences >= 2
        }
        if (correction != null) {
            LogManager.d(TAG, " 从纠正记录中找到提示: ${correction.correctIntent}")
            return correction.correctIntent
        }
        
        // 检查是否有学习到的模式
        val keywords = extractKeywords(input)
        for (keyword in keywords) {
            val pattern = learningData.userPatterns.find {
                it.trigger.equals(keyword, ignoreCase = true) &&
                it.confidence >= 0.7f &&
                it.occurrences >= 3
            }
            if (pattern != null) {
                LogManager.d(TAG, " 从学习模式中找到提示: ${pattern.preferredAction}")
                return pattern.preferredAction
            }
        }
        
        return null
    }
    
    /**
     * 获取操作建议（基于历史成功记录）
     */
    fun getActionSuggestion(intent: String): String? {
        val successfulRecords = learningData.feedbackRecords.filter {
            it.recognizedIntent == intent && it.success
        }
        
        if (successfulRecords.size >= 3) {
            // 找最常用的执行方式
            val actionCounts = successfulRecords.groupingBy { it.executedAction }.eachCount()
            val mostCommon = actionCounts.maxByOrNull { it.value }
            return mostCommon?.key
        }
        
        return null
    }
    
    // ==================== 统计与分析 ====================
    
    /**
     * 获取学习统计
     */
    fun getLearningStats(): LearningStats {
        return LearningStats(
            totalExecutions = learningData.totalExecutions,
            totalSuccesses = learningData.totalSuccesses,
            successRate = learningData.successRate,
            learnedPatterns = learningData.userPatterns.size,
            corrections = learningData.intentCorrections.size,
            feedbackRecords = learningData.feedbackRecords.size
        )
    }
    
    data class LearningStats(
        val totalExecutions: Int,
        val totalSuccesses: Int,
        val successRate: Float,
        val learnedPatterns: Int,
        val corrections: Int,
        val feedbackRecords: Int
    )
    
    /**
     * 获取最常失败的意图
     */
    fun getMostFailedIntents(): List<Pair<String, Int>> {
        return learningData.feedbackRecords
            .filter { !it.success }
            .groupingBy { it.recognizedIntent }
            .eachCount()
            .toList()
            .sortedByDescending { it.second }
            .take(5)
    }
    
    /**
     * 获取用户最常用的操作
     */
    fun getMostUsedActions(): List<Pair<String, Int>> {
        return learningData.feedbackRecords
            .groupingBy { it.recognizedIntent }
            .eachCount()
            .toList()
            .sortedByDescending { it.second }
            .take(10)
    }
    
    // ==================== 辅助方法 ====================
    
    private fun addFeedbackRecord(context: Context, record: FeedbackRecord) {
        learningData.feedbackRecords.add(record)
        
        // 限制记录数量
        while (learningData.feedbackRecords.size > MAX_FEEDBACK_RECORDS) {
            learningData.feedbackRecords.removeAt(0)
        }
        
        saveLearningData(context)
    }
    
    private fun updateSuccessRate(success: Boolean) {
        learningData = learningData.copy(
            totalExecutions = learningData.totalExecutions + 1,
            totalSuccesses = learningData.totalSuccesses + if (success) 1 else 0,
            successRate = (learningData.totalSuccesses + if (success) 1 else 0).toFloat() / 
                         (learningData.totalExecutions + 1)
        )
    }
    
    private fun extractKeywords(input: String): List<String> {
        val stopWords = setOf("我", "你", "的", "了", "吗", "呢", "啊", "是", "在", "有", "和", "与", 
            "帮", "帮我", "请", "可以", "能", "一下", "一个")
        
        return input.split(Regex("[\\s，。！？,.!?]+"))
            .filter { it.length in 2..10 && it !in stopWords }
    }
    
    // ==================== 持久化 ====================
    
    private fun saveLearningData(context: Context) {
        scope.launch {
            try {
                val file = File(context.filesDir, FEEDBACK_FILE)
                file.writeText(json.encodeToString(learningData))
            } catch (e: Exception) {
                LogManager.e(TAG, "保存学习数据失败", e)
            }
        }
    }
    
    private fun loadLearningData(context: Context) {
        try {
            val file = File(context.filesDir, FEEDBACK_FILE)
            if (file.exists()) {
                learningData = json.decodeFromString<LearningData>(file.readText())
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "加载学习数据失败", e)
        }
    }
    
    /**
     * 清除所有学习数据
     */
    fun clearAllData(context: Context) {
        learningData = LearningData()
        saveLearningData(context)
        LogManager.w(TAG, " 已清除所有学习数据")
    }
}
