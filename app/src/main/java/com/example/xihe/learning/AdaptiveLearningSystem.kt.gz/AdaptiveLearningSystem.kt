package com.example.xihe.learning

import android.content.Context
import com.example.xihe.utils.LogManager
import com.example.xihe.ai.IntentClassifier
import com.example.xihe.ai.TaskPlanner
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import java.io.File
import kotlin.math.exp
import kotlin.math.pow

/**
 * 自适应学习系统
 * 通过分析用户行为模式，不断优化AI助手的性能和准确度
 */
class AdaptiveLearningSystem(private val context: Context) {
    
    companion object {
        private const val TAG = "AdaptiveLearning"
        private const val LEARNING_DATA_FILE = "learning_data.json"
        private const val MODEL_FILE = "user_model.json"
        private const val MIN_CONFIDENCE_THRESHOLD = 0.7f
        private const val LEARNING_RATE = 0.1f
    }
    
    /**
     * 用户行为模式
     */
    @Serializable
    data class UserPattern(
        val id: String,
        val action: String,
        val context: Map<String, String>,
        val frequency: Int,
        val successRate: Float,
        val averageTime: Long,
        val lastOccurrence: Long,
        val confidence: Float
    )
    
    /**
     * 用户偏好
     */
    @Serializable
    data class UserPreference(
        val category: String,
        val preference: String,
        val score: Float,
        val sampleCount: Int
    )
    
    /**
     * 学习样本
     */
    @Serializable
    data class LearningSample(
        val timestamp: Long,
        val input: String,
        val expectedOutput: String,
        val actualOutput: String,
        val success: Boolean,
        val executionTime: Long,
        val userFeedback: UserFeedback? = null,
        val context: Map<String, String> = emptyMap()
    )
    
    /**
     * 用户反馈
     */
    @Serializable
    data class UserFeedback(
        val rating: Int,  // 1-5
        val comment: String? = null,
        val isHelpful: Boolean,
        val suggestions: List<String> = emptyList()
    )
    
    /**
     * 用户模型
     */
    @Serializable
    data class UserModel(
        val userId: String,
        val patterns: List<UserPattern>,
        val preferences: List<UserPreference>,
        val dailyUsagePattern: Map<Int, Float>,  // 每小时使用频率
        val frequentApps: Map<String, Int>,
        val commonTasks: List<String>,
        val averageSessionLength: Long,
        val totalInteractions: Int,
        val lastUpdated: Long
    )
    
    /**
     * 预测结果
     */
    data class Prediction(
        val action: String,
        val probability: Float,
        val confidence: Float,
        val reasoning: String
    )
    
    /**
     * 优化建议
     */
    data class Optimization(
        val type: OptimizationType,
        val description: String,
        val expectedImprovement: Float,
        val priority: Int
    )
    
    enum class OptimizationType {
        SHORTCUT,       // 快捷方式
        AUTOMATION,     // 自动化
        PREDICTION,     // 预测优化
        CACHING,        // 缓存优化
        WORKFLOW        // 工作流优化
    }
    
    // 状态管理
    private val _isLearning = MutableStateFlow(false)
    val isLearning = _isLearning.asStateFlow()
    
    private val _currentModel = MutableStateFlow<UserModel?>(null)
    val currentModel = _currentModel.asStateFlow()
    
    // 数据存储
    private val learningData = mutableListOf<LearningSample>()
    private val userPatterns = mutableMapOf<String, UserPattern>()
    private val userPreferences = mutableMapOf<String, UserPreference>()
    
    // 学习参数
    private var learningScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    
    /**
     * 初始化学习系统
     */
    fun initialize() {
        LogManager.d(TAG, "初始化学习系统")
        
        // 加载历史数据
        loadLearningData()
        loadUserModel()
        
        // 开始后台学习
        startBackgroundLearning()
        
        _isLearning.value = true
    }
    
    /**
     * 记录用户行为
     */
    fun recordUserAction(
        input: String,
        action: String,
        result: Boolean,
        executionTime: Long,
        context: Map<String, String> = emptyMap()
    ) {
        val sample = LearningSample(
            timestamp = System.currentTimeMillis(),
            input = input,
            expectedOutput = action,
            actualOutput = action,
            success = result,
            executionTime = executionTime,
            context = context
        )
        
        learningData.add(sample)
        
        // 更新模式
        updatePattern(action, result, executionTime, context)
        
        // 触发增量学习
        triggerIncrementalLearning(sample)
        
        LogManager.d(TAG, "记录用户行为: $action, 成功=$result")
    }
    
    /**
     * 记录用户反馈
     */
    fun recordUserFeedback(
        sampleId: Long,
        rating: Int,
        comment: String? = null,
        isHelpful: Boolean = true
    ) {
        val feedback = UserFeedback(
            rating = rating,
            comment = comment,
            isHelpful = isHelpful
        )
        
        // 找到对应的样本并更新反馈
        learningData.find { it.timestamp == sampleId }?.let { sample ->
            val index = learningData.indexOf(sample)
            learningData[index] = sample.copy(userFeedback = feedback)
            
            // 根据反馈调整模型
            adjustModelBasedOnFeedback(sample, feedback)
        }
        
        LogManager.d(TAG, "记录用户反馈: 评分=$rating")
    }
    
    /**
     * 预测下一步操作
     */
    fun predictNextAction(
        currentContext: Map<String, String>,
        recentActions: List<String> = emptyList()
    ): List<Prediction> {
        val predictions = mutableListOf<Prediction>()
        
        // 基于历史模式预测
        userPatterns.values.forEach { pattern ->
            val probability = calculateProbability(pattern, currentContext, recentActions)
            if (probability > MIN_CONFIDENCE_THRESHOLD) {
                predictions.add(
                    Prediction(
                        action = pattern.action,
                        probability = probability,
                        confidence = pattern.confidence,
                        reasoning = "基于历史使用模式"
                    )
                )
            }
        }
        
        // 基于时间模式预测
        val hourOfDay = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        _currentModel.value?.dailyUsagePattern?.get(hourOfDay)?.let { frequency ->
            if (frequency > 0.5f) {
                // 这个时间段用户活跃，提高预测权重
                predictions.forEach { it.copy(probability = it.probability * 1.2f) }
            }
        }
        
        // 基于序列模式预测
        if (recentActions.size >= 2) {
            val sequencePrediction = predictFromSequence(recentActions)
            sequencePrediction?.let { predictions.add(it) }
        }
        
        // 按概率排序
        predictions.sortByDescending { it.probability }
        
        return predictions.take(5) // 返回前5个预测
    }
    
    /**
     * 生成优化建议
     */
    fun generateOptimizations(): List<Optimization> {
        val optimizations = mutableListOf<Optimization>()
        
        // 分析高频操作，建议快捷方式
        userPatterns.values
            .filter { it.frequency > 10 }
            .forEach { pattern ->
                optimizations.add(
                    Optimization(
                        type = OptimizationType.SHORTCUT,
                        description = "为'${pattern.action}'创建快捷方式",
                        expectedImprovement = 0.3f,
                        priority = pattern.frequency
                    )
                )
            }
        
        // 分析重复序列，建议自动化
        findRepetitiveSequences().forEach { sequence ->
            optimizations.add(
                Optimization(
                    type = OptimizationType.AUTOMATION,
                    description = "自动化操作序列: ${sequence.joinToString(" -> ")}",
                    expectedImprovement = 0.5f,
                    priority = 8
                )
            )
        }
        
        // 分析失败率高的操作，建议优化
        userPatterns.values
            .filter { it.successRate < 0.7f }
            .forEach { pattern ->
                optimizations.add(
                    Optimization(
                        type = OptimizationType.WORKFLOW,
                        description = "优化'${pattern.action}'的执行流程",
                        expectedImprovement = 0.4f,
                        priority = 6
                    )
                )
            }
        
        // 基于使用时间建议缓存
        _currentModel.value?.frequentApps?.entries
            ?.sortedByDescending { it.value }
            ?.take(5)
            ?.forEach { (app, count) ->
                optimizations.add(
                    Optimization(
                        type = OptimizationType.CACHING,
                        description = "预加载应用: $app",
                        expectedImprovement = 0.2f,
                        priority = count / 10
                    )
                )
            }
        
        // 按优先级排序
        optimizations.sortByDescending { it.priority }
        
        return optimizations
    }
    
    /**
     * 个性化调整
     */
    fun personalizeForUser(): PersonalizationSettings {
        val model = _currentModel.value ?: return PersonalizationSettings()
        
        // 根据使用习惯调整设置
        val preferredSpeed = if (model.averageSessionLength < 60000) {
            "fast" // 快速模式
        } else {
            "normal" // 正常模式
        }
        
        // 根据常用任务调整UI
        val suggestedShortcuts = model.commonTasks.take(5)
        
        // 根据使用时间调整通知
        val activeHours = model.dailyUsagePattern
            .filter { it.value > 0.3f }
            .keys.toList()
        
        return PersonalizationSettings(
            interactionSpeed = preferredSpeed,
            shortcuts = suggestedShortcuts,
            activeHours = activeHours,
            preferredApps = model.frequentApps.keys.toList(),
            adaptiveUI = true
        )
    }
    
    /**
     * 个性化设置
     */
    data class PersonalizationSettings(
        val interactionSpeed: String = "normal",
        val shortcuts: List<String> = emptyList(),
        val activeHours: List<Int> = emptyList(),
        val preferredApps: List<String> = emptyList(),
        val adaptiveUI: Boolean = false
    )
    
    // ==================== 私有方法 ====================
    
    /**
     * 更新用户模式
     */
    private fun updatePattern(
        action: String,
        success: Boolean,
        executionTime: Long,
        context: Map<String, String>
    ) {
        val patternId = generatePatternId(action, context)
        val existing = userPatterns[patternId]
        
        if (existing != null) {
            // 更新现有模式
            val newFrequency = existing.frequency + 1
            val newSuccessRate = (existing.successRate * existing.frequency + if (success) 1f else 0f) / newFrequency
            val newAverageTime = (existing.averageTime * existing.frequency + executionTime) / newFrequency
            val newConfidence = calculateConfidence(newSuccessRate, newFrequency)
            
            userPatterns[patternId] = existing.copy(
                frequency = newFrequency,
                successRate = newSuccessRate,
                averageTime = newAverageTime.toLong(),
                lastOccurrence = System.currentTimeMillis(),
                confidence = newConfidence
            )
        } else {
            // 创建新模式
            userPatterns[patternId] = UserPattern(
                id = patternId,
                action = action,
                context = context,
                frequency = 1,
                successRate = if (success) 1f else 0f,
                averageTime = executionTime,
                lastOccurrence = System.currentTimeMillis(),
                confidence = 0.5f
            )
        }
    }
    
    /**
     * 触发增量学习
     */
    private fun triggerIncrementalLearning(sample: LearningSample) {
        learningScope.launch {
            // 简单的在线学习算法
            delay(100) // 避免立即处理
            
            // 更新模型权重
            updateModelWeights(sample)
            
            // 每100个样本触发一次完整学习
            if (learningData.size % 100 == 0) {
                performFullLearning()
            }
        }
    }
    
    /**
     * 更新模型权重
     */
    private fun updateModelWeights(sample: LearningSample) {
        // 使用简单的梯度下降更新权重
        val error = if (sample.success) 0f else 1f
        val adjustment = LEARNING_RATE * error
        
        // 更新相关模式的置信度
        userPatterns.values
            .filter { it.action == sample.expectedOutput }
            .forEach { pattern ->
                val newConfidence = (pattern.confidence * (1 - adjustment)).coerceIn(0f, 1f)
                userPatterns[pattern.id] = pattern.copy(confidence = newConfidence)
            }
    }
    
    /**
     * 执行完整学习
     */
    private suspend fun performFullLearning() {
        withContext(Dispatchers.Default) {
            LogManager.d(TAG, "执行完整学习，样本数: ${learningData.size}")
            
            // 分析所有样本
            val analysisResult = analyzeLearningData()
            
            // 更新用户模型
            updateUserModel(analysisResult)
            
            // 保存学习结果
            saveLearningData()
            saveUserModel()
        }
    }
    
    /**
     * 分析学习数据
     */
    private fun analyzeLearningData(): AnalysisResult {
        // 统计各种指标
        val totalSamples = learningData.size
        val successRate = learningData.count { it.success }.toFloat() / totalSamples
        val averageTime = learningData.map { it.executionTime }.average()
        
        // 提取常用操作
        val actionFrequency = learningData
            .groupingBy { it.expectedOutput }
            .eachCount()
            .toList()
            .sortedByDescending { it.second }
            .take(10)
        
        // 分析时间模式
        val hourlyUsage = IntArray(24)
        learningData.forEach { sample ->
            val hour = java.util.Date(sample.timestamp).hours
            hourlyUsage[hour]++
        }
        
        return AnalysisResult(
            totalSamples = totalSamples,
            successRate = successRate,
            averageTime = averageTime.toLong(),
            topActions = actionFrequency.map { it.first },
            hourlyDistribution = hourlyUsage.map { it.toFloat() / totalSamples }
        )
    }
    
    /**
     * 分析结果
     */
    private data class AnalysisResult(
        val totalSamples: Int,
        val successRate: Float,
        val averageTime: Long,
        val topActions: List<String>,
        val hourlyDistribution: List<Float>
    )
    
    /**
     * 更新用户模型
     */
    private fun updateUserModel(analysis: AnalysisResult) {
        val currentTime = System.currentTimeMillis()
        
        val model = UserModel(
            userId = "user_${context.packageName}",
            patterns = userPatterns.values.toList(),
            preferences = userPreferences.values.toList(),
            dailyUsagePattern = analysis.hourlyDistribution.mapIndexed { hour, freq -> 
                hour to freq 
            }.toMap(),
            frequentApps = extractFrequentApps(),
            commonTasks = analysis.topActions,
            averageSessionLength = analysis.averageTime,
            totalInteractions = analysis.totalSamples,
            lastUpdated = currentTime
        )
        
        _currentModel.value = model
    }
    
    /**
     * 计算概率
     */
    private fun calculateProbability(
        pattern: UserPattern,
        context: Map<String, String>,
        recentActions: List<String>
    ): Float {
        var probability = pattern.confidence
        
        // 上下文匹配度
        val contextMatch = pattern.context.entries.count { (key, value) ->
            context[key] == value
        }.toFloat() / pattern.context.size.coerceAtLeast(1)
        probability *= contextMatch
        
        // 时间衰减
        val timeSinceLastUse = System.currentTimeMillis() - pattern.lastOccurrence
        val daysSinceLastUse = timeSinceLastUse / (24 * 60 * 60 * 1000)
        val timeDecay = exp(-daysSinceLastUse / 7.0).toFloat() // 一周衰减
        probability *= timeDecay
        
        // 序列匹配度
        if (recentActions.isNotEmpty() && pattern.action in recentActions) {
            probability *= 1.5f // 提升最近使用过的操作
        }
        
        return probability.coerceIn(0f, 1f)
    }
    
    /**
     * 基于序列预测
     */
    private fun predictFromSequence(recentActions: List<String>): Prediction? {
        // 查找匹配的序列模式
        val sequence = recentActions.takeLast(3).joinToString(",")
        
        // 在历史数据中查找相似序列
        for (i in 3 until learningData.size) {
            val historicalSequence = learningData
                .subList(i - 3, i)
                .map { it.expectedOutput }
                .joinToString(",")
            
            if (historicalSequence == sequence && i < learningData.size) {
                val nextAction = learningData[i].expectedOutput
                return Prediction(
                    action = nextAction,
                    probability = 0.7f,
                    confidence = 0.6f,
                    reasoning = "基于历史序列模式"
                )
            }
        }
        
        return null
    }
    
    /**
     * 查找重复序列
     */
    private fun findRepetitiveSequences(): List<List<String>> {
        val sequences = mutableListOf<List<String>>()
        val minLength = 3
        val minOccurrences = 3
        
        // 简单的序列挖掘算法
        for (length in minLength..5) {
            val sequenceCount = mutableMapOf<String, Int>()
            
            for (i in 0..learningData.size - length) {
                val sequence = learningData
                    .subList(i, i + length)
                    .map { it.expectedOutput }
                val key = sequence.joinToString(",")
                sequenceCount[key] = (sequenceCount[key] ?: 0) + 1
            }
            
            sequenceCount
                .filter { it.value >= minOccurrences }
                .forEach { (key, _) ->
                    sequences.add(key.split(","))
                }
        }
        
        return sequences
    }
    
    /**
     * 根据反馈调整模型
     */
    private fun adjustModelBasedOnFeedback(sample: LearningSample, feedback: UserFeedback) {
        val adjustment = when (feedback.rating) {
            5 -> 1.2f   // 非常满意，增强
            4 -> 1.1f   // 满意，略微增强
            3 -> 1.0f   // 一般，不调整
            2 -> 0.9f   // 不满意，削弱
            1 -> 0.8f   // 非常不满意，大幅削弱
            else -> 1.0f
        }
        
        // 调整相关模式的置信度
        userPatterns.values
            .filter { it.action == sample.expectedOutput }
            .forEach { pattern ->
                val newConfidence = (pattern.confidence * adjustment).coerceIn(0.1f, 1f)
                userPatterns[pattern.id] = pattern.copy(confidence = newConfidence)
            }
    }
    
    /**
     * 提取常用应用
     */
    private fun extractFrequentApps(): Map<String, Int> {
        return learningData
            .mapNotNull { it.context["app"] }
            .groupingBy { it }
            .eachCount()
            .toList()
            .sortedByDescending { it.second }
            .take(10)
            .toMap()
    }
    
    /**
     * 生成模式ID
     */
    private fun generatePatternId(action: String, context: Map<String, String>): String {
        val contextKey = context.entries
            .sortedBy { it.key }
            .joinToString("_") { "${it.key}:${it.value}" }
        return "${action}_$contextKey".hashCode().toString()
    }
    
    /**
     * 计算置信度
     */
    private fun calculateConfidence(successRate: Float, frequency: Int): Float {
        // 使用贝叶斯方法计算置信度
        val alpha = 1f // 先验成功次数
        val beta = 1f  // 先验失败次数
        
        val successes = (successRate * frequency).toInt()
        val failures = frequency - successes
        
        // Beta分布的期望值
        return (alpha + successes) / (alpha + beta + frequency)
    }
    
    /**
     * 开始后台学习
     */
    private fun startBackgroundLearning() {
        learningScope.launch {
            while (isActive) {
                delay(5 * 60 * 1000) // 每5分钟执行一次
                
                // 定期分析和优化
                if (learningData.size > 50) {
                    performFullLearning()
                }
                
                // 清理过期数据
                cleanOldData()
            }
        }
    }
    
    /**
     * 清理过期数据
     */
    private fun cleanOldData() {
        val thirtyDaysAgo = System.currentTimeMillis() - (30L * 24 * 60 * 60 * 1000)
        learningData.removeAll { it.timestamp < thirtyDaysAgo }
    }
    
    /**
     * 保存学习数据
     */
    private fun saveLearningData() {
        try {
            val file = File(context.filesDir, LEARNING_DATA_FILE)
            val json = Json.encodeToString(learningData.takeLast(1000)) // 只保存最近1000条
            file.writeText(json)
            LogManager.d(TAG, "学习数据已保存")
        } catch (e: Exception) {
            LogManager.e(TAG, "保存学习数据失败", e)
        }
    }
    
    /**
     * 加载学习数据
     */
    private fun loadLearningData() {
        try {
            val file = File(context.filesDir, LEARNING_DATA_FILE)
            if (file.exists()) {
                val json = file.readText()
                val loaded = Json.decodeFromString<List<LearningSample>>(json)
                learningData.clear()
                learningData.addAll(loaded)
                LogManager.d(TAG, "加载了 ${loaded.size} 条学习数据")
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "加载学习数据失败", e)
        }
    }
    
    /**
     * 保存用户模型
     */
    private fun saveUserModel() {
        try {
            _currentModel.value?.let { model ->
                val file = File(context.filesDir, MODEL_FILE)
                val json = Json.encodeToString(model)
                file.writeText(json)
                LogManager.d(TAG, "用户模型已保存")
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "保存用户模型失败", e)
        }
    }
    
    /**
     * 加载用户模型
     */
    private fun loadUserModel() {
        try {
            val file = File(context.filesDir, MODEL_FILE)
            if (file.exists()) {
                val json = file.readText()
                val model = Json.decodeFromString<UserModel>(json)
                _currentModel.value = model
                
                // 恢复模式和偏好
                userPatterns.clear()
                model.patterns.forEach {
                    userPatterns[it.id] = it
                }
                userPreferences.clear()
                model.preferences.forEach {
                    userPreferences[it.category] = it
                }
                
                LogManager.d(TAG, "用户模型已加载")
            }
        } catch (e: Exception) {
            LogManager.e(TAG, "加载用户模型失败", e)
        }
    }
    
    /**
     * 释放资源
     */
    fun release() {
        _isLearning.value = false
        learningScope.cancel()
        saveLearningData()
        saveUserModel()
        LogManager.d(TAG, "学习系统已释放")
    }
}
