# ==================== 羲和 (Xihe) ProGuard 规则 ====================
# 🔒 安全混淆配置

# ==================== 基础配置 ====================
# 保留调试信息用于崩溃分析
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# 保留注解
-keepattributes *Annotation*
-keepattributes Signature
-keepattributes Exceptions

# ==================== Kotlin 相关 ====================
-keep class kotlin.** { *; }
-keep class kotlin.Metadata { *; }
-dontwarn kotlin.**
-keepclassmembers class **$WhenMappings {
    <fields>;
}
-keepclassmembers class kotlin.Metadata {
    public <methods>;
}

# Kotlin Serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.example.xihe.**$$serializer { *; }
-keepclassmembers class com.example.xihe.** {
    *** Companion;
}
-keepclasseswithmembers class com.example.xihe.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# Kotlin Coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembernames class kotlinx.** {
    volatile <fields>;
}

# ==================== Retrofit & OkHttp ====================
-keepattributes RuntimeVisibleAnnotations, RuntimeVisibleParameterAnnotations
-keepclassmembers,allowshrinking,allowobfuscation interface * {
    @retrofit2.http.* <methods>;
}
-dontwarn org.codehaus.mojo.animal_sniffer.IgnoreJRERequirement
-dontwarn javax.annotation.**
-dontwarn kotlin.Unit
-dontwarn retrofit2.KotlinExtensions
-dontwarn retrofit2.KotlinExtensions$*

# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
-keep class okhttp3.** { *; }
-keep interface okhttp3.** { *; }

# Gson
-keepattributes Signature
-keepattributes *Annotation*
-dontwarn sun.misc.**
-keep class com.google.gson.stream.** { *; }
-keep class * extends com.google.gson.TypeAdapter
-keep class * implements com.google.gson.TypeAdapterFactory
-keep class * implements com.google.gson.JsonSerializer
-keep class * implements com.google.gson.JsonDeserializer

# ==================== TensorFlow Lite ====================
-keep class org.tensorflow.** { *; }
-keep class org.tensorflow.lite.** { *; }
-dontwarn org.tensorflow.**

# ==================== ONNX Runtime ====================
-keep class ai.onnxruntime.** { *; }
-dontwarn ai.onnxruntime.**

# ==================== Vosk 语音识别 ====================
-keep class org.vosk.** { *; }
-dontwarn org.vosk.**

# ==================== ML Kit ====================
-keep class com.google.mlkit.** { *; }
-dontwarn com.google.mlkit.**

# ==================== Google Play Services ====================
-keep class com.google.android.gms.** { *; }
-dontwarn com.google.android.gms.**

# ==================== Room 数据库 ====================
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-dontwarn androidx.room.paging.**

# ==================== Compose ====================
-keep class androidx.compose.** { *; }
-dontwarn androidx.compose.**

# ==================== 羲和核心类 ====================
# 保留数据类（序列化需要）
-keep class com.example.xihe.core.ContextMemory$** { *; }
-keep class com.example.xihe.data.** { *; }
-keep class com.example.xihe.training.** { *; }
-keep class com.example.xihe.intelligence.** { *; }
-keep class com.example.xihe.understanding.** { *; }

# 保留枚举类
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# 保留 Parcelable
-keep class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}

# ==================== 📄 文档处理库 (Apache POI & iText) ====================
-keep class org.apache.poi.** { *; }
-keep class org.apache.xmlbeans.** { *; }
-keep class javax.xml.** { *; }
-keep class com.itextpdf.** { *; }
-dontwarn org.apache.poi.**
-dontwarn javax.xml.**
-dontwarn com.itextpdf.**

# ==================== 🛡️ 自定义日志系统优化 ====================
# 在 Release 版本中彻底移除调试和冗余日志
-assumenosideeffects class com.example.xihe.utils.LogManager {
    public static void d(...);
    public static void v(...);
    public static void trace(...);
}

# ==================== 安全优化 ====================
# 移除日志（Release版本）
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int d(...);
    public static int i(...);
}

# 优化
-optimizationpasses 5
-dontusemixedcaseclassnames
-verbose