plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.ksp)
}

ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
}


android {
    namespace = "com.example.xihe"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.xihe"
        minSdk = 26  // Apache POI 需要 26+
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = true          // 🔒 启用代码混淆
            isShrinkResources = true        // 🔒 启用资源压缩
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false         // Debug 不压缩，方便调试
            isDebuggable = true
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
    
    // 启用 JUnit5 支持 (Kotest)
    testOptions {
        unitTests.all {
            it.useJUnitPlatform()
        }
    }
    
    buildFeatures {
        compose = true
        buildConfig = true  // 🆕 启用 BuildConfig 生成
    }

    // 🆕 配置assets打包 - 支持离线OCR模型
    packaging {
        resources {
            // 确保模型文件不被压缩
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }

        // 保留所有assets文件
        jniLibs {
            useLegacyPackaging = true
        }
    }

    // 配置assets文件不压缩（重要：确保ML Kit能正确读取模型）
    androidResources {
        noCompress += listOf(
            "binarypb",  // ML Kit模型文件
            "tflite",    // TensorFlow Lite模型
            "fb",        // FlatBuffers模型
            "pb"         // Protocol Buffers
        )
    }
}

dependencies {
    // ==================== AndroidX Core ====================
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)

    // ==================== Jetpack Compose ====================
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.bundles.compose)
    implementation(libs.androidx.navigation.compose)

    // ==================== Material Design ====================
    implementation(libs.material)

    // ==================== Network ====================
    implementation(libs.bundles.network)
    implementation(libs.kotlinx.serialization.json)

    // ==================== DataStore ====================
    implementation(libs.androidx.datastore.preferences)

    // ==================== Room Database ====================
    implementation(libs.bundles.room)
    ksp(libs.androidx.room.compiler)

    // ==================== WorkManager ====================
    implementation(libs.androidx.work.runtime.ktx)

    // ==================== Coroutines ====================
    implementation(libs.bundles.coroutines)

    // ==================== Image Loading ====================
    implementation(libs.coil.compose)

    // ==================== ONNX Runtime (Supertonic TTS) ====================
    implementation(libs.onnxruntime.android)

    // ==================== Vosk 离线语音识别 ====================
    implementation(libs.vosk.android)

    // ==================== ML Kit OCR 文字识别 ====================
    implementation(libs.bundles.mlkit.ocr)

    // ==================== Google Play Services ====================
    implementation(libs.play.services.location)

    // ==================== TensorFlow Lite (AI模型推理) ====================
    implementation(libs.bundles.tensorflow)

    // ==================== Document Parsing ====================
    // Apache POI - Word/Excel 文档解析（新旧格式）
    implementation(libs.bundles.poi)
    // iTextPDF - PDF 文档解析
    implementation(libs.itext7.core)

    // ==================== Security (Encrypted Storage) ====================
    implementation(libs.androidx.security.crypto)

    // ==================== Testing ====================
    testImplementation(libs.junit)
    testImplementation(libs.bundles.kotest)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.ui.test.junit4)

    // ==================== Debug ====================
    debugImplementation(libs.bundles.compose.debug)
}
