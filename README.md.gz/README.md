# 羲和 (Xihe) - AI 智能助手

<p align="center">
  <img src="app/src/main/res/mipmap-xxxhdpi/ic_launcher.png" width="120" height="120" alt="羲和 Logo"/>
</p>

<p align="center">
  <b>🤖 一款功能强大的 Android AI 助手应用</b>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Android-26%2B-green" alt="API Level"/>
  <img src="https://img.shields.io/badge/Kotlin-2.0.21-blue" alt="Kotlin"/>
  <img src="https://img.shields.io/badge/Jetpack%20Compose-Latest-purple" alt="Compose"/>
</p>

---

## ✨ 功能特性

### 🎯 核心功能

| 功能 | 描述 |
|------|------|
| **🗣️ 智能对话** | 支持多轮对话、上下文理解、意图识别 |
| **📱 手机自动化** | 自动操作手机完成各种任务 |
| **🎮 游戏AI** | 五子棋、斗地主、通用游戏AI |
| **🔍 视觉理解** | 截图分析、OCR识别、界面理解 |
| **🎤 语音交互** | 语音输入、语音唤醒、TTS播报 |
| **📚 自主学习** | 自动搜索教程、学习新技能 |

### 🎬 自动化场景

- **📹 刷视频** - 自动刷抖音、快手、B站等
- **📝 填表单** - 自动填写各种表单
- **🌐 浏览器** - 自动搜索、浏览网页
- **🛒 购物** - 购物比价、自动下单
- **📧 消息** - 自动回复消息

### 🎮 游戏功能

| 游戏 | 支持度 |
|------|--------|
| ⚫⚪ 五子棋 | ✅ Alpha-Beta AI |
| 🃏 斗地主 | ✅ 策略AI + OCR |
| 🎯 通用游戏 | ✅ 视觉AI + 自学习 |

---

## 🚀 快速开始

### 环境要求

- Android Studio Hedgehog 或更高版本
- JDK 11+
- Android SDK 26+ (Android 8.0+)

### 安装步骤

```bash
# 1. 克隆项目
git clone https://github.com/your-repo/xihe.git

# 2. 打开项目
cd xihe
# 用 Android Studio 打开

# 3. 配置 API Key（可选）
# 在应用设置中配置 AI 服务商的 API Key

# 4. 编译运行
./gradlew assembleDebug
```

### 权限配置

应用需要以下权限才能正常工作：

| 权限 | 用途 |
|------|------|
| 无障碍服务 | 自动化操作 |
| 悬浮窗 | 显示AI助手界面 |
| 通知 | 后台任务提醒 |
| 存储 | 保存数据和导出 |

---

## 📁 项目结构

```
xihe/
├── app/src/main/java/com/example/xihe/
│   ├── core/                 # 🔧 核心引擎
│   │   ├── AutomationEngine.kt
│   │   ├── LLMClient.kt
│   │   ├── MessageHandler.kt
│   │   ├── TaskProgressManager.kt
│   │   └── RecordingManager.kt
│   │
│   ├── scenarios/            # 🎬 自动化场景
│   │   ├── ScenarioManager.kt
│   │   ├── ScenarioBase.kt
│   │   └── games/
│   │       ├── GomokuScenario.kt
│   │       ├── DouDiZhuScenario.kt
│   │       ├── GameAIScenario.kt
│   │       └── GameTutorialLearner.kt
│   │
│   ├── ui/                   # 🎨 用户界面
│   │   ├── components/
│   │   ├── screens/
│   │   ├── dialogs/
│   │   └── theme/
│   │
│   ├── ai/                   # 🧠 AI模块
│   │   ├── IntentClassifier.kt
│   │   ├── TaskPlanner.kt
│   │   └── LocalIntentRecognizer.kt
│   │
│   ├── tools/                # 🛠️ 工具集
│   │   ├── ToolRegistry.kt
│   │   └── AutomationTools.kt
│   │
│   ├── data/                 # 📊 数据管理
│   │   └── TrainingDataManager.kt
│   │
│   └── security/             # 🔒 安全模块
│       └── SecurityManager.kt
│
├── build.gradle.kts
└── README.md
```

---

## ⚙️ 配置说明

### AI 服务配置

支持多种 AI 服务提供商：

| 提供商 | 默认模型 | 说明 |
|--------|----------|------|
| OpenAI | gpt-4o-mini | 官方API |
| DeepSeek | deepseek-chat | 国产高性价比 |
| 通义千问 | qwen-turbo | 阿里云 |
| 智谱AI | glm-4 | 智谱清言 |
| 自定义 | 任意 | 兼容OpenAI格式 |

### 配置文件

```kotlin
// 在设置中配置
baseUrl = "https://api.openai.com/v1/"
apiKey = "sk-xxx"
modelName = "gpt-4o-mini"
```

---

## 🔧 开发指南

### 添加新场景

```kotlin
class MyScenario(context: Context) : ScenarioBase(context, "我的场景") {
    
    data class MyConfig(
        val param1: String = ""
    ) : ScenarioConfig()
    
    override suspend fun execute(config: ScenarioConfig): ExecutionResult {
        val myConfig = config as MyConfig
        // 实现逻辑
        return ExecutionResult.success("完成")
    }
}
```

### 添加新工具

```kotlin
ToolRegistry.register(
    ToolDefinition(
        name = "my_tool",
        description = "我的工具",
        category = "自定义",
        handler = { params -> 
            // 处理逻辑
            ToolResult.success("结果")
        }
    )
)
```

---

## 📊 技术栈

| 类别 | 技术 |
|------|------|
| **语言** | Kotlin 2.0.21 |
| **UI框架** | Jetpack Compose + Material3 |
| **异步** | Kotlin Coroutines + Flow |
| **网络** | OkHttp + Retrofit |
| **序列化** | Kotlinx Serialization |
| **OCR** | ML Kit + DeepSeek Vision |
| **TTS/ASR** | 系统TTS + 语音识别 |

---

## 📝 更新日志

### v1.0.0 (2024-12)
- ✨ 初始版本发布
- 🎮 游戏AI功能（五子棋、斗地主）
- 📚 教程自学习功能
- 💾 训练数据保存功能
- 🔧 代码重构优化

---

## 🤝 贡献指南

1. Fork 本仓库
2. 创建功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 提交 Pull Request

---

## 📄 许可证

本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情

---

## 📮 联系方式

- 问题反馈: [Issues](https://github.com/your-repo/xihe/issues)
- 功能建议: [Discussions](https://github.com/your-repo/xihe/discussions)

---

<p align="center">
  Made with ❤️ by Xihe Team
</p>
