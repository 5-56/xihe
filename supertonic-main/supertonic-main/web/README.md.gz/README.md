# Supertonic Web Example

This example demonstrates how to use Supertonic in a web browser using ONNX Runtime Web.

## 📰 Update News

**2024.12.03 Evening** - 🌟 **Phase 3: Waveform, i18n & PWA!**
- 📊 Added **Waveform Visualization** with 3 types (Wave/Frequency/Bars)
- 🌍 Implemented **Multi-language Support** (English/中文)
- 📱 Added **PWA Support** with offline capability
- ⚙️ Created **Advanced Settings Panel**
- 🎨 Enhanced **Top Control Bar** for quick access
- 🔧 Improved **Performance & UX**

**2024.12.03 PM** - 🚀 **Phase 2: Batch Processing & Playlist!**
- ⚡ Added **Batch Processing** with drag & drop file upload
- 📝 Implemented **Audio Playlist** with auto-add and play all
- 📑 Added **Tab Navigation** (Generate / Batch / Playlist)
- 📁 Enhanced **File Upload** with visual feedback
- 📊 Real-time **Progress Tracking** for batch operations
- 📦 **ZIP Download** for batch results (requires JSZip)
- 🎵 **Continuous Playback** for playlist items

**2024.12.03 AM** - 🎉 **Phase 1: Core Features!**
- ✨ Added **Dark Mode** support with auto-detection
- 📜 Implemented **History Manager** with search and export
- ⚡ Added **Parameter Presets** (Natural, Fast, High Quality, Slow & Clear)
- ⌨️ Introduced **Keyboard Shortcuts** (Ctrl+Enter, Ctrl+K, Ctrl+H)
- 🎨 Enhanced UI with modern design and animations
- 🔧 Added ConfigManager for centralized settings
- 📊 IndexedDB integration for persistent storage

**2025.11.23** - Enhanced text preprocessing with comprehensive normalization, emoji removal, symbol replacement, and punctuation handling for improved synthesis quality.

**2025.11.19** - Added speed control slider to adjust speech synthesis speed (default: 1.05, recommended range: 0.9-1.5).

**2025.11.19** - Added automatic text chunking for long-form inference. Long texts are split into chunks and synthesized with natural pauses.

## Features

### Core Features
- 🌐 Runs entirely in the browser (no server required for inference)
- 🚀 WebGPU support with automatic fallback to WebAssembly
- ⚡ Pre-extracted voice styles for instant generation
- 🎨 Modern, responsive UI with dark mode
- 🎭 Multiple voice style presets (2 Male, 2 Female)
- 💾 Download generated audio as WAV files
- 📊 Detailed generation statistics (audio length, generation time)
- ⏱️ Real-time progress tracking

### 🌟 Phase 3 Features (v2024.12.03 Evening)
- 📊 **Waveform Visualization**:
  - Real-time audio waveform display
  - 3 visualization types (Wave/Frequency/Bars)
  - Auto-connect to audio elements
  - Customizable colors and styles
- 🌍 **Multi-language Support**:
  - Full UI translation (EN/ZH)
  - Dynamic language switching
  - Persistent language preference
  - Easy to add new languages
- 📱 **PWA Support**:
  - Install as desktop/mobile app
  - Offline capability with Service Worker
  - Standalone app mode
  - Fast loading and caching
- ⚙️ **Advanced Settings Panel**:
  - Language selector
  - Theme options (Light/Dark/Auto)
  - Visualization toggle
  - Storage management
  - PWA install status
- 🎨 **UI Enhancements**:
  - Top control bar with quick access
  - Waveform canvas with dark theme
  - Settings sidebar panel
  - Improved mobile responsiveness

### 🚀 Phase 2 Features (v2024.12.03 PM)
- 📑 **Tab Navigation**: Switch between Generate, Batch, and Playlist modes
- ⚡ **Batch Processing**:
  - Drag & drop .txt or .csv files
  - Paste multiple lines of text
  - Queue management (add, remove, clear)
  - Real-time progress tracking
  - Status indicators (pending, processing, completed, failed)
  - Download all as ZIP file
  - Pause/resume processing
- 📝 **Audio Playlist**:
  - Auto-add generated audio
  - Display metadata (text, duration, voice style)
  - Continuous playback (Play All)
  - Export playlist as JSON
  - Clear playlist management
- 📁 **Enhanced File Upload**:
  - Visual drag & drop feedback
  - Multi-file upload support
  - Automatic file type detection

### 🎉 Phase 1 Features (v2024.12.03 AM)
- 🌙 **Dark Mode**: Auto-detects system preference, manual toggle available
- 📜 **History Manager**: 
  - Automatic saving of all generated speeches
  - Full-text search across history
  - Export history as JSON
  - Click to reload previous settings
- ⚡ **Parameter Presets**: 4 quick presets for different use cases
  - 🎯 Natural (balanced)
  - ⚡ Fast (quick generation)
  - ✨ High Quality (best quality)
  - 🐢 Slow & Clear (slow pace)
- ⌨️ **Keyboard Shortcuts**:
  - `Ctrl+Enter`: Generate speech
  - `Ctrl+K`: Clear text
  - `Ctrl+H`: Toggle history
  - `Escape`: Close panels
- 🎨 **Enhanced UI**: Smooth animations, modern design, responsive layout

## Requirements

- Node.js (for development server)
- Modern web browser (Chrome, Edge, Firefox, Safari)

## Installation

1. Install dependencies:

```bash
npm install
```

## Running the Demo

Start the development server:

```bash
npm run dev
```

This will start a local development server (usually at http://localhost:3000) and open the demo in your browser.

## Usage

### Basic Workflow
1. **Wait for Models to Load**: The app will automatically load models and the default voice style (M1)
2. **Select Voice Style**: Choose from available voice presets
   - **Male 1 (M1)**: Default male voice
   - **Male 2 (M2)**: Alternative male voice
   - **Female 1 (F1)**: Default female voice
   - **Female 2 (F2)**: Alternative female voice
3. **Enter Text**: Type or paste the text you want to convert to speech
4. **Choose a Preset** (new!):
   - 🎯 **Natural**: Balanced quality and speed
   - ⚡ **Fast**: Quick generation for drafts
   - ✨ **High Quality**: Best quality output
   - 🐢 **Slow & Clear**: Slow-paced, clear speech
5. **Adjust Settings** (optional):
   - **Total Steps**: More steps = better quality but slower
   - **Speed**: Adjust speech rate (0.5-2.0)
6. **Generate Speech**: Click "Generate Speech" or press `Ctrl+Enter`
7. **View Results**: 
   - See the full input text
   - View audio length and generation time statistics
   - Play the generated audio in the browser
   - Download as WAV file
   - Automatically saved to history 📜

### Using History (new!)
1. Click "📜 Show History" to open the history panel
2. Search for previous generations using the search box
3. Click any history item to reload its settings
4. Export history as JSON for backup
5. Clear all history if needed

### Dark Mode (new!)
- Click the 🌙/☀️ button in the top-right corner
- Automatically detects system preference
- Setting is saved for future visits

### Keyboard Shortcuts (new!)
- `Ctrl+Enter`: Generate speech instantly
- `Ctrl+K`: Clear text input
- `Ctrl+H`: Toggle history panel
- `Escape`: Close any open panel

## Technical Details

### Browser Compatibility

This demo uses:
- **ONNX Runtime Web**: For running models in the browser
- **Web Audio API**: For playing generated audio
- **Vite**: For development and bundling

## Project Structure

```
web/
├── index.html              # Main HTML file
├── main.js                 # Main application logic
├── helper.js               # TTS helper functions
├── style.css               # Light mode styles
├── style-dark-mode.css     # Dark mode styles (new!)
├── history-manager.js      # History management (new!)
├── config-manager.js       # Configuration management (new!)
├── batch-processor.js      # Batch processing (planned)
├── package.json            # Dependencies
├── vite.config.js          # Vite configuration
├── README.md               # This file
└── FEATURES.md             # Detailed feature documentation (new!)
```

## Notes

- The ONNX models must be accessible at `assets/onnx/` relative to the web root
- Voice style JSON files must be accessible at `assets/voice_styles/` relative to the web root
- Pre-extracted voice styles enable instant generation without audio processing
- Four voice style presets are provided (M1, M2, F1, F2)
- History is stored in IndexedDB (max 100 items, auto-cleanup)
- Theme preference is saved in localStorage
- No external dependencies required for new features (vanilla JS)

## Troubleshooting

### Models not loading
- Check browser console for errors
- Ensure `assets/onnx/` path is correct and models are accessible
- Check CORS settings if serving from a different domain

### WebGPU not available
- WebGPU is only available in recent Chrome/Edge browsers (version 113+)
- The app will automatically fall back to WebAssembly if WebGPU is not available
- Check the backend badge to see which execution provider is being used

### Out of memory errors
- Try shorter text inputs
- Reduce denoising steps
- Use a browser with more available memory
- Close other tabs to free up memory

### Audio quality issues
- Try different voice style presets
- Increase denoising steps for better quality

### Slow generation
- If using WebAssembly, try a browser that supports WebGPU
- Ensure no other heavy processes are running
- Consider using fewer denoising steps for faster (but lower quality) results
- Try the ⚡ Fast preset for quick generation

### History not saving
- Check if browser has IndexedDB enabled
- Ensure sufficient storage space available
- Check browser console for errors
- Try clearing browser cache and refreshing

### Dark mode not working
- Ensure style-dark-mode.css is loaded
- Check for conflicting browser extensions
- Try manually toggling the theme button
- Clear localStorage and refresh

### Keyboard shortcuts not working
- Ensure page is focused (not address bar)
- Check for conflicting browser shortcuts
- Try clicking on the text input first
- Open console (F12) to see shortcut hints

## Additional Resources

- 📖 [Detailed Feature Documentation](FEATURES.md)
- 🔄 [Changelog](../CHANGELOG.md)
- 📝 [Optimization Guide](../PROJECT_OPTIMIZATION.md)
- 🛠️ [Implementation Guide](../IMPLEMENTATION_GUIDE.md)

## What's Next?

Check out [CHANGELOG.md](../CHANGELOG.md) for planned features in upcoming releases!