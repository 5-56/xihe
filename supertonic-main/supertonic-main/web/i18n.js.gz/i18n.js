/**
 * Internationalization (i18n) Module
 * Supports multiple languages with dynamic switching
 */

export default class I18n {
    constructor(defaultLanguage = 'en') {
        this.currentLanguage = defaultLanguage;
        this.translations = {};
        this.listeners = [];
        
        // Load from localStorage
        const saved = localStorage.getItem('app_language');
        if (saved) {
            this.currentLanguage = saved;
        }
    }
    
    /**
     * Register translations
     */
    register(language, translations) {
        this.translations[language] = translations;
    }
    
    /**
     * Get translation by key
     */
    t(key, params = {}) {
        const keys = key.split('.');
        let value = this.translations[this.currentLanguage];
        
        for (const k of keys) {
            if (value && typeof value === 'object') {
                value = value[k];
            } else {
                // Fallback to English
                value = this.translations['en'];
                for (const k2 of keys) {
                    if (value && typeof value === 'object') {
                        value = value[k2];
                    }
                }
                break;
            }
        }
        
        // Replace parameters
        if (typeof value === 'string') {
            Object.keys(params).forEach(param => {
                value = value.replace(`{${param}}`, params[param]);
            });
        }
        
        return value || key;
    }
    
    /**
     * Set language
     */
    setLanguage(language) {
        if (!this.translations[language]) {
            console.warn(`Language '${language}' not found`);
            return;
        }
        
        this.currentLanguage = language;
        localStorage.setItem('app_language', language);
        
        // Notify listeners
        this.listeners.forEach(callback => callback(language));
        
        // Update DOM
        this.updateDOM();
    }
    
    /**
     * Get current language
     */
    getLanguage() {
        return this.currentLanguage;
    }
    
    /**
     * Get available languages
     */
    getLanguages() {
        return Object.keys(this.translations);
    }
    
    /**
     * Add language change listener
     */
    onChange(callback) {
        this.listeners.push(callback);
    }
    
    /**
     * Update DOM elements with data-i18n attribute
     */
    updateDOM() {
        document.querySelectorAll('[data-i18n]').forEach(element => {
            const key = element.getAttribute('data-i18n');
            const translation = this.t(key);
            
            if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
                element.placeholder = translation;
            } else {
                element.textContent = translation;
            }
        });
        
        // Update data-i18n-title attributes (tooltips)
        document.querySelectorAll('[data-i18n-title]').forEach(element => {
            const key = element.getAttribute('data-i18n-title');
            element.title = this.t(key);
        });
    }
}

// English translations
export const en = {
    app: {
        title: 'Supertonic',
        subtitle: 'Text-to-Speech with ONNX Runtime Web'
    },
    tabs: {
        generate: 'Generate',
        batch: 'Batch',
        playlist: 'Playlist'
    },
    generate: {
        voiceStyle: 'Voice Style',
        text: 'Text to Synthesize',
        textPlaceholder: 'Enter the text you want to convert to speech...',
        totalSteps: 'Total Steps (higher = better quality)',
        speed: 'Speed (0.9-1.5 recommended)',
        generateBtn: 'Generate Speech',
        showHistory: 'Show History'
    },
    presets: {
        title: 'Quick Presets',
        natural: 'Natural',
        fast: 'Fast',
        highQuality: 'High Quality',
        slowClear: 'Slow & Clear'
    },
    batch: {
        title: 'Batch Processing',
        input: 'Input',
        dragDrop: 'Drag & Drop text files here',
        orClick: 'or click to browse',
        pasteText: 'Or paste text (one per line)',
        addToQueue: 'Add to Queue',
        queue: 'Queue',
        items: 'items',
        clear: 'Clear',
        startProcessing: 'Start Processing',
        pause: 'Pause',
        downloadAll: 'Download All (ZIP)',
        processing: 'Processing {current} of {total}...'
    },
    playlist: {
        title: 'Audio Playlist',
        hint: 'Generated audios will appear here for easy playback',
        playAll: 'Play All',
        clearPlaylist: 'Clear Playlist',
        exportPlaylist: 'Export Playlist'
    },
    history: {
        title: 'History',
        search: 'Search history...',
        clearAll: 'Clear All',
        export: 'Export',
        noHistory: 'No history yet',
        generatedSpeeches: 'Generated speeches will appear here'
    },
    status: {
        loadingModels: 'Loading models...',
        loadingVoiceStyle: 'Loading voice style...',
        modelsLoaded: 'Models loaded! You can now generate speech.',
        generatingSpeech: 'Generating speech from text...',
        denoising: 'Denoising ({step}/{total})...',
        creatingAudio: 'Creating audio file...',
        completed: 'Speech synthesis completed successfully!',
        error: 'Error: {message}'
    },
    settings: {
        title: 'Settings',
        theme: 'Theme',
        language: 'Language',
        visualization: 'Waveform Visualization',
        waveformType: 'Visualization Type',
        types: {
            waveform: 'Waveform',
            frequency: 'Frequency',
            bars: 'Bars'
        }
    },
    common: {
        close: 'Close',
        save: 'Save',
        cancel: 'Cancel',
        confirm: 'Confirm',
        download: 'Download',
        loading: 'Loading...',
        male: 'Male',
        female: 'Female'
    }
};

// Chinese translations
export const zh = {
    app: {
        title: 'Supertonic',
        subtitle: '基于 ONNX Runtime Web 的文本转语音'
    },
    tabs: {
        generate: '生成',
        batch: '批量',
        playlist: '播放列表'
    },
    generate: {
        voiceStyle: '语音风格',
        text: '要合成的文本',
        textPlaceholder: '输入您想转换为语音的文本...',
        totalSteps: '总步数（越高质量越好）',
        speed: '语速（建议 0.9-1.5）',
        generateBtn: '生成语音',
        showHistory: '显示历史'
    },
    presets: {
        title: '快速预设',
        natural: '自然',
        fast: '快速',
        highQuality: '高质量',
        slowClear: '慢速清晰'
    },
    batch: {
        title: '批量处理',
        input: '输入',
        dragDrop: '拖拽文本文件到这里',
        orClick: '或点击浏览',
        pasteText: '或粘贴文本（每行一句）',
        addToQueue: '添加到队列',
        queue: '队列',
        items: '项',
        clear: '清空',
        startProcessing: '开始处理',
        pause: '暂停',
        downloadAll: '下载全部（ZIP）',
        processing: '正在处理 {current}/{total}...'
    },
    playlist: {
        title: '音频播放列表',
        hint: '生成的音频将显示在这里以便播放',
        playAll: '播放全部',
        clearPlaylist: '清空播放列表',
        exportPlaylist: '导出播放列表'
    },
    history: {
        title: '历史记录',
        search: '搜索历史...',
        clearAll: '清空全部',
        export: '导出',
        noHistory: '暂无历史记录',
        generatedSpeeches: '生成的语音将显示在这里'
    },
    status: {
        loadingModels: '正在加载模型...',
        loadingVoiceStyle: '正在加载语音风格...',
        modelsLoaded: '模型加载完成！现在可以生成语音了。',
        generatingSpeech: '正在从文本生成语音...',
        denoising: '降噪中（{step}/{total}）...',
        creatingAudio: '正在创建音频文件...',
        completed: '语音合成成功完成！',
        error: '错误：{message}'
    },
    settings: {
        title: '设置',
        theme: '主题',
        language: '语言',
        visualization: '波形可视化',
        waveformType: '可视化类型',
        types: {
            waveform: '波形',
            frequency: '频谱',
            bars: '条形图'
        }
    },
    common: {
        close: '关闭',
        save: '保存',
        cancel: '取消',
        confirm: '确认',
        download: '下载',
        loading: '加载中...',
        male: '男声',
        female: '女声'
    }
};
