/**
 * 配置管理器
 * 管理应用程序的所有配置项
 */

class ConfigManager {
    constructor() {
        this.storageKey = 'supertonic_config';
        this.config = this.loadConfig();
        this.listeners = new Map();
    }

    /**
     * 默认配置
     */
    getDefaultConfig() {
        return {
            // 外观设置
            appearance: {
                theme: 'auto',          // 'light', 'dark', 'auto'
                language: 'en',         // 'en', 'zh', 'ja', etc.
                fontSize: 'medium',     // 'small', 'medium', 'large'
                accentColor: '#667eea'
            },

            // 音频设置
            audio: {
                defaultTotalStep: 5,
                defaultSpeed: 1.05,
                autoPlay: true,
                volumeNormalization: true,
                defaultVoiceStyle: 'assets/voice_styles/M1.json',
                downloadFormat: 'wav'   // 'wav', 'mp3'
            },

            // 高级设置
            advanced: {
                useWebGPU: true,
                modelCaching: true,
                maxHistoryItems: 100,
                batchSize: 10,
                enableAnalytics: false,
                debugMode: false
            },

            // 快捷键设置
            shortcuts: {
                generate: 'Ctrl+Enter',
                newText: 'Ctrl+N',
                clearText: 'Ctrl+K',
                download: 'Ctrl+S',
                toggleHistory: 'Ctrl+H'
            },

            // 参数预设
            presets: {
                natural: {
                    name: 'Natural',
                    totalStep: 5,
                    speed: 1.0
                },
                fast: {
                    name: 'Fast',
                    totalStep: 2,
                    speed: 1.3
                },
                highQuality: {
                    name: 'High Quality',
                    totalStep: 10,
                    speed: 1.0
                },
                slowClear: {
                    name: 'Slow & Clear',
                    totalStep: 5,
                    speed: 0.8
                }
            }
        };
    }

    /**
     * 加载配置
     */
    loadConfig() {
        try {
            const saved = localStorage.getItem(this.storageKey);
            if (saved) {
                const parsed = JSON.parse(saved);
                // 合并默认配置，确保新字段存在
                return this.deepMerge(this.getDefaultConfig(), parsed);
            }
        } catch (error) {
            console.error('Failed to load config:', error);
        }
        return this.getDefaultConfig();
    }

    /**
     * 保存配置
     */
    saveConfig() {
        try {
            localStorage.setItem(this.storageKey, JSON.stringify(this.config));
            this.notifyListeners('*', this.config);
        } catch (error) {
            console.error('Failed to save config:', error);
        }
    }

    /**
     * 获取配置值
     */
    get(path) {
        const keys = path.split('.');
        let value = this.config;
        
        for (const key of keys) {
            if (value === undefined || value === null) {
                return undefined;
            }
            value = value[key];
        }
        
        return value;
    }

    /**
     * 设置配置值
     */
    set(path, value) {
        const keys = path.split('.');
        const lastKey = keys.pop();
        let target = this.config;
        
        for (const key of keys) {
            if (!(key in target)) {
                target[key] = {};
            }
            target = target[key];
        }
        
        target[lastKey] = value;
        this.saveConfig();
        this.notifyListeners(path, value);
    }

    /**
     * 重置为默认配置
     */
    reset() {
        this.config = this.getDefaultConfig();
        this.saveConfig();
    }

    /**
     * 重置特定部分
     */
    resetSection(section) {
        const defaultConfig = this.getDefaultConfig();
        if (section in defaultConfig) {
            this.config[section] = defaultConfig[section];
            this.saveConfig();
        }
    }

    /**
     * 监听配置变化
     */
    on(path, callback) {
        if (!this.listeners.has(path)) {
            this.listeners.set(path, []);
        }
        this.listeners.get(path).push(callback);
    }

    /**
     * 移除监听器
     */
    off(path, callback) {
        if (this.listeners.has(path)) {
            const callbacks = this.listeners.get(path);
            const index = callbacks.indexOf(callback);
            if (index > -1) {
                callbacks.splice(index, 1);
            }
        }
    }

    /**
     * 通知监听器
     */
    notifyListeners(path, value) {
        // 通知特定路径的监听器
        if (this.listeners.has(path)) {
            this.listeners.get(path).forEach(callback => callback(value));
        }

        // 通知通配符监听器
        if (this.listeners.has('*')) {
            this.listeners.get('*').forEach(callback => callback(this.config));
        }
    }

    /**
     * 导出配置
     */
    export() {
        const exportData = {
            version: '1.0',
            exportDate: new Date().toISOString(),
            config: this.config
        };

        const blob = new Blob([JSON.stringify(exportData, null, 2)], {
            type: 'application/json'
        });

        return blob;
    }

    /**
     * 导入配置
     */
    async import(file) {
        try {
            const text = await file.text();
            const data = JSON.parse(text);

            if (data.config) {
                this.config = this.deepMerge(this.getDefaultConfig(), data.config);
                this.saveConfig();
                return true;
            }
            
            throw new Error('Invalid config format');
        } catch (error) {
            console.error('Failed to import config:', error);
            throw error;
        }
    }

    /**
     * 应用主题
     */
    applyTheme() {
        const theme = this.get('appearance.theme');
        const body = document.body;

        if (theme === 'dark') {
            body.classList.add('dark-mode');
        } else if (theme === 'light') {
            body.classList.remove('dark-mode');
        } else if (theme === 'auto') {
            // 根据系统偏好自动设置
            const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            if (prefersDark) {
                body.classList.add('dark-mode');
            } else {
                body.classList.remove('dark-mode');
            }
        }
    }

    /**
     * 应用语言
     */
    applyLanguage() {
        const language = this.get('appearance.language');
        document.documentElement.lang = language;
        // 触发语言切换事件
        window.dispatchEvent(new CustomEvent('languagechange', { 
            detail: { language } 
        }));
    }

    /**
     * 获取快捷键
     */
    getShortcut(action) {
        return this.get(`shortcuts.${action}`);
    }

    /**
     * 设置快捷键
     */
    setShortcut(action, shortcut) {
        this.set(`shortcuts.${action}`, shortcut);
    }

    /**
     * 获取预设
     */
    getPreset(name) {
        return this.get(`presets.${name}`);
    }

    /**
     * 添加预设
     */
    addPreset(name, preset) {
        this.set(`presets.${name}`, preset);
    }

    /**
     * 删除预设
     */
    deletePreset(name) {
        const presets = this.get('presets');
        delete presets[name];
        this.set('presets', presets);
    }

    /**
     * 深度合并对象
     */
    deepMerge(target, source) {
        const result = { ...target };
        
        for (const key in source) {
            if (source[key] instanceof Object && key in target) {
                result[key] = this.deepMerge(target[key], source[key]);
            } else {
                result[key] = source[key];
            }
        }
        
        return result;
    }

    /**
     * 验证配置
     */
    validate() {
        const errors = [];

        // 验证主题
        const validThemes = ['light', 'dark', 'auto'];
        if (!validThemes.includes(this.get('appearance.theme'))) {
            errors.push('Invalid theme value');
        }

        // 验证音频参数
        const totalStep = this.get('audio.defaultTotalStep');
        if (totalStep < 1 || totalStep > 50) {
            errors.push('Total step must be between 1 and 50');
        }

        const speed = this.get('audio.defaultSpeed');
        if (speed < 0.5 || speed > 2.0) {
            errors.push('Speed must be between 0.5 and 2.0');
        }

        return {
            valid: errors.length === 0,
            errors
        };
    }
}

export default ConfigManager;
