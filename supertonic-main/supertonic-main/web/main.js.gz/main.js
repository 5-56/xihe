import {
    loadTextToSpeech,
    loadVoiceStyle,
    writeWavFile
} from './helper.js';
import HistoryManager from './history-manager.js';
import ConfigManager from './config-manager.js';
import BatchProcessor from './batch-processor.js';
import WaveformVisualizer from './waveform-visualizer.js';
import I18n, { en, zh } from './i18n.js';

// Configuration
const DEFAULT_VOICE_STYLE_PATH = 'assets/voice_styles/M1.json';

// Initialize managers
const historyManager = new HistoryManager();
const configManager = new ConfigManager();
let batchProcessor = null;
const playlist = [];

// Initialize i18n
const i18n = new I18n('en');
i18n.register('en', en);
i18n.register('zh', zh);

// Initialize waveform visualizer
let waveformVisualizer = null;

// PWA install prompt
let deferredPrompt = null;

// Parameter presets
const PRESETS = {
    natural: { totalStep: 5, speed: 1.0 },
    fast: { totalStep: 2, speed: 1.3 },
    highQuality: { totalStep: 10, speed: 1.0 },
    slowClear: { totalStep: 5, speed: 0.8 }
};

// Helper function to extract filename from path
function getFilenameFromPath(path) {
    return path.split('/').pop();
}

// Global state
let textToSpeech = null;
let cfgs = null;

// Pre-computed style
let currentStyle = null;
let currentStylePath = DEFAULT_VOICE_STYLE_PATH;

// UI Elements
const textInput = document.getElementById('text');
const voiceStyleSelect = document.getElementById('voiceStyleSelect');
const voiceStyleInfo = document.getElementById('voiceStyleInfo');
const totalStepInput = document.getElementById('totalStep');
const speedInput = document.getElementById('speed');
const generateBtn = document.getElementById('generateBtn');
const statusBox = document.getElementById('statusBox');
const statusText = document.getElementById('statusText');
const backendBadge = document.getElementById('backendBadge');
const resultsContainer = document.getElementById('results');
const errorBox = document.getElementById('error');
const themeToggle = document.getElementById('themeToggle');
const toggleHistoryBtn = document.getElementById('toggleHistoryBtn');
const historyPanel = document.getElementById('historyPanel');
const closeHistoryBtn = document.getElementById('closeHistoryBtn');
const historyList = document.getElementById('historyList');
const historySearch = document.getElementById('historySearch');
const clearHistoryBtn = document.getElementById('clearHistoryBtn');
const exportHistoryBtn = document.getElementById('exportHistoryBtn');

// Tab elements
const tabBtns = document.querySelectorAll('.tab-btn');
const tabPanes = document.querySelectorAll('.tab-pane');

// Batch processing elements
const uploadArea = document.getElementById('uploadArea');
const batchFileInput = document.getElementById('batchFileInput');
const batchTextarea = document.getElementById('batchTextarea');
const addToBatchBtn = document.getElementById('addToBatchBtn');
const batchQueue = document.getElementById('batchQueue');
const queueCount = document.getElementById('queueCount');
const clearQueueBtn = document.getElementById('clearQueueBtn');
const startBatchBtn = document.getElementById('startBatchBtn');
const pauseBatchBtn = document.getElementById('pauseBatchBtn');
const downloadAllBtn = document.getElementById('downloadAllBtn');
const batchProgress = document.getElementById('batchProgress');
const batchProgressBar = document.getElementById('batchProgressBar');
const batchProgressText = document.getElementById('batchProgressText');
const batchProgressPercent = document.getElementById('batchProgressPercent');

// Playlist elements
const playlistItems = document.getElementById('playlistItems');
const playAllBtn = document.getElementById('playAllBtn');
const clearPlaylistBtn = document.getElementById('clearPlaylistBtn');
const exportPlaylistBtn = document.getElementById('exportPlaylistBtn');

// Waveform elements
const waveformCanvas = document.getElementById('waveformCanvas');
const waveformTypeBtns = document.querySelectorAll('.waveform-type-btn');

// Settings elements
const settingsToggle = document.getElementById('settingsToggle');
const settingsPanel = document.getElementById('settingsPanel');
const closeSettingsBtn = document.getElementById('closeSettingsBtn');
const languageSelector = document.getElementById('languageSelector');
const settingsLanguage = document.getElementById('settingsLanguage');
const enableWaveform = document.getElementById('enableWaveform');
const autoPlayCheckbox = document.getElementById('autoPlay');
const clearAllDataBtn = document.getElementById('clearAllDataBtn');
const installPwaBtn = document.getElementById('installPwaBtn');
const pwaStatus = document.getElementById('pwaStatus');
const historyCountSpan = document.getElementById('historyCount');
const playlistCountSpan = document.getElementById('playlistCount');

function showStatus(message, type = 'info') {
    statusText.innerHTML = message;
    statusBox.className = 'status-box';
    if (type === 'success') {
        statusBox.classList.add('success');
    } else if (type === 'error') {
        statusBox.classList.add('error');
    }
}

function showError(message) {
    errorBox.textContent = message;
    errorBox.classList.add('active');
}

function hideError() {
    errorBox.classList.remove('active');
}

function showBackendBadge() {
    backendBadge.classList.add('visible');
}

// Load voice style from JSON
async function loadStyleFromJSON(stylePath) {
    try {
        const style = await loadVoiceStyle([stylePath], true);
        return style;
    } catch (error) {
        console.error('Error loading voice style:', error);
        throw error;
    }
}

// Load models on page load
async function initializeModels() {
    try {
        showStatus('ℹ️ <strong>Loading configuration...</strong>');
        
        const basePath = 'assets/onnx';
        
        // Try WebGPU first, fallback to WASM
        let executionProvider = 'wasm';
        try {
            const result = await loadTextToSpeech(basePath, {
                executionProviders: ['webgpu'],
                graphOptimizationLevel: 'all'
            }, (modelName, current, total) => {
                showStatus(`ℹ️ <strong>Loading ONNX models (${current}/${total}):</strong> ${modelName}...`);
            });
            
            textToSpeech = result.textToSpeech;
            cfgs = result.cfgs;
            
            executionProvider = 'webgpu';
            backendBadge.textContent = 'WebGPU';
            backendBadge.style.background = '#4caf50';
        } catch (webgpuError) {
            console.log('WebGPU not available, falling back to WebAssembly');
            
            const result = await loadTextToSpeech(basePath, {
                executionProviders: ['wasm'],
                graphOptimizationLevel: 'all'
            }, (modelName, current, total) => {
                showStatus(`ℹ️ <strong>Loading ONNX models (${current}/${total}):</strong> ${modelName}...`);
            });
            
            textToSpeech = result.textToSpeech;
            cfgs = result.cfgs;
        }
        
        showStatus('ℹ️ <strong>Loading default voice style...</strong>');
        
        // Load default voice style
        currentStyle = await loadStyleFromJSON(currentStylePath);
        voiceStyleInfo.textContent = `${getFilenameFromPath(currentStylePath)} (default)`;
        
        showStatus(`✅ <strong>Models loaded!</strong> Using ${executionProvider.toUpperCase()}. You can now generate speech.`, 'success');
        showBackendBadge();
        
        generateBtn.disabled = false;
        
        // Initialize history manager
        await historyManager.init();
        await updateHistoryDisplay();
        
        // Initialize batch processor
        batchProcessor = new BatchProcessor(textToSpeech, currentStyle);
        
        // Initialize waveform visualizer
        if (waveformCanvas) {
            waveformVisualizer = new WaveformVisualizer(waveformCanvas, {
                backgroundColor: '#1a1a2e',
                waveColor: '#667eea',
                progressColor: '#764ba2'
            });
        }
        
    } catch (error) {
        console.error('Error loading models:', error);
        showStatus(`❌ <strong>Error loading models:</strong> ${error.message}`, 'error');
    }
}

// Handle voice style selection
voiceStyleSelect.addEventListener('change', async (e) => {
    const selectedValue = e.target.value;
    
    if (!selectedValue) return;
    
    try {
        generateBtn.disabled = true;
        showStatus(`ℹ️ <strong>Loading voice style...</strong>`, 'info');
        
        currentStylePath = selectedValue;
        currentStyle = await loadStyleFromJSON(currentStylePath);
        voiceStyleInfo.textContent = getFilenameFromPath(currentStylePath);
        
        showStatus(`✅ <strong>Voice style loaded:</strong> ${getFilenameFromPath(currentStylePath)}`, 'success');
        generateBtn.disabled = false;
    } catch (error) {
        showError(`Error loading voice style: ${error.message}`);
        
        // Restore default style
        currentStylePath = DEFAULT_VOICE_STYLE_PATH;
        voiceStyleSelect.value = currentStylePath;
        try {
            currentStyle = await loadStyleFromJSON(currentStylePath);
            voiceStyleInfo.textContent = `${getFilenameFromPath(currentStylePath)} (default)`;
        } catch (styleError) {
            console.error('Error restoring default style:', styleError);
        }
        
        generateBtn.disabled = false;
    }
});

// Main synthesis function
async function generateSpeech() {
    const text = textInput.value.trim();
    if (!text) {
        showError('Please enter some text to synthesize.');
        return;
    }
    
    if (!textToSpeech || !cfgs) {
        showError('Models are still loading. Please wait.');
        return;
    }
    
    if (!currentStyle) {
        showError('Voice style is not ready. Please wait.');
        return;
    }
    
    const startTime = Date.now();
    
    try {
        generateBtn.disabled = true;
        hideError();
        
        // Clear results and show placeholder
        resultsContainer.innerHTML = `
            <div class="results-placeholder generating">
                <div class="results-placeholder-icon">⏳</div>
                <p>Generating speech...</p>
            </div>
        `;
        
        const totalStep = parseInt(totalStepInput.value);
        const speed = parseFloat(speedInput.value);
        
        showStatus('ℹ️ <strong>Generating speech from text...</strong>');
        const tic = Date.now();
        
        const { wav, duration } = await textToSpeech.call(
            text, 
            currentStyle, 
            totalStep,
            speed,
            0.3,
            (step, total) => {
                showStatus(`ℹ️ <strong>Denoising (${step}/${total})...</strong>`);
            }
        );
        
        const toc = Date.now();
        console.log(`Text-to-speech synthesis: ${((toc - tic) / 1000).toFixed(2)}s`);
        
        showStatus('ℹ️ <strong>Creating audio file...</strong>');
        const wavLen = Math.floor(textToSpeech.sampleRate * duration[0]);
        const wavOut = wav.slice(0, wavLen);
        
        // Create WAV file
        const wavBuffer = writeWavFile(wavOut, textToSpeech.sampleRate);
        const blob = new Blob([wavBuffer], { type: 'audio/wav' });
        const url = URL.createObjectURL(blob);
        
        // Calculate total time and audio duration
        const endTime = Date.now();
        const totalTimeSec = ((endTime - startTime) / 1000).toFixed(2);
        const audioDurationSec = duration[0].toFixed(2);
        
        // Display result with full text
        resultsContainer.innerHTML = `
            <div class="result-item">
                <div class="result-text-container">
                    <div class="result-text-label">Input Text</div>
                    <div class="result-text">${text}</div>
                </div>
                <div class="result-info">
                    <div class="info-item">
                        <span>📊 Audio Length</span>
                        <strong>${audioDurationSec}s</strong>
                    </div>
                    <div class="info-item">
                        <span>⏱️ Generation Time</span>
                        <strong>${totalTimeSec}s</strong>
                    </div>
                </div>
                <div class="result-player">
                    <audio controls>
                        <source src="${url}" type="audio/wav">
                    </audio>
                </div>
                <div class="result-actions">
                    <button onclick="downloadAudio('${url}', 'synthesized_speech.wav')">
                        <span>⬇️</span>
                        <span>Download WAV</span>
                    </button>
                </div>
            </div>
        `;
        
        showStatus('✅ <strong>Speech synthesis completed successfully!</strong>', 'success');
        
        // Save to history
        await historyManager.add({
            text: text,
            audioUrl: url,
            voiceStyle: getFilenameFromPath(currentStylePath),
            totalStep: totalStep,
            speed: speed,
            duration: parseFloat(audioDurationSec)
        });
        await updateHistoryDisplay();
        
        // Add to playlist
        addToPlaylist({
            text: text,
            audioUrl: url,
            duration: parseFloat(audioDurationSec),
            voiceStyle: getFilenameFromPath(currentStylePath),
            timestamp: Date.now()
        });
        
    } catch (error) {
        console.error('Error during synthesis:', error);
        showStatus(`❌ <strong>Error during synthesis:</strong> ${error.message}`, 'error');
        showError(`Error during synthesis: ${error.message}`);
        
        // Restore placeholder
        resultsContainer.innerHTML = `
            <div class="results-placeholder">
                <div class="results-placeholder-icon">🎤</div>
                <p>Generated speech will appear here</p>
            </div>
        `;
    } finally {
        generateBtn.disabled = false;
    }
}

// Download handler (make it global so it can be called from onclick)
window.downloadAudio = function(url, filename) {
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
};

// Attach generate function to button
generateBtn.addEventListener('click', generateSpeech);

// ==================== Theme Toggle ====================
themeToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
    const isDark = document.body.classList.contains('dark-mode');
    localStorage.setItem('theme', isDark ? 'dark' : 'light');
});

// Initialize theme from storage or system preference
const savedTheme = localStorage.getItem('theme');
const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
if (savedTheme === 'dark' || (!savedTheme && prefersDark)) {
    document.body.classList.add('dark-mode');
}

// ==================== Parameter Presets ====================
document.querySelectorAll('.preset-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        const presetName = btn.dataset.preset;
        const preset = PRESETS[presetName];
        
        if (preset) {
            totalStepInput.value = preset.totalStep;
            speedInput.value = preset.speed;
            
            // Update active state
            document.querySelectorAll('.preset-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
        }
    });
});

// ==================== History Panel ====================
toggleHistoryBtn.addEventListener('click', () => {
    historyPanel.classList.add('open');
});

closeHistoryBtn.addEventListener('click', () => {
    historyPanel.classList.remove('open');
});

// Close history panel when clicking outside
document.addEventListener('click', (e) => {
    if (historyPanel.classList.contains('open') && 
        !historyPanel.contains(e.target) && 
        e.target !== toggleHistoryBtn) {
        historyPanel.classList.remove('open');
    }
});

// History search
historySearch.addEventListener('input', async (e) => {
    const query = e.target.value;
    await updateHistoryDisplay(query);
});

// Clear history
clearHistoryBtn.addEventListener('click', async () => {
    if (confirm('Are you sure you want to clear all history?')) {
        await historyManager.clearAll();
        await updateHistoryDisplay();
    }
});

// Export history
exportHistoryBtn.addEventListener('click', async () => {
    const blob = await historyManager.exportToJSON();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `supertonic_history_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
});

// Update history display
async function updateHistoryDisplay(query = '') {
    const items = query ? await historyManager.search(query) : await historyManager.getAll();
    
    if (items.length === 0) {
        historyList.innerHTML = `
            <div class="history-empty">
                <div class="history-empty-icon">📭</div>
                <p>${query ? 'No results found' : 'No history yet'}</p>
                <p style="font-size: 0.9em; margin-top: 5px;">
                    ${query ? 'Try a different search' : 'Generated speeches will appear here'}
                </p>
            </div>
        `;
        return;
    }
    
    historyList.innerHTML = items.map(item => `
        <div class="history-item" data-id="${item.id}">
            <div class="history-text">${item.text}</div>
            <div class="history-meta">
                <span>🎤 ${item.voiceStyle || 'Unknown'}</span>
                <span>${new Date(item.timestamp).toLocaleDateString()}</span>
            </div>
            <div class="history-meta" style="margin-top: 5px;">
                <span>⏱️ ${item.duration ? item.duration.toFixed(2) + 's' : 'N/A'}</span>
                <span>Steps: ${item.totalStep || 'N/A'}</span>
            </div>
        </div>
    `).join('');
    
    // Add click handlers to history items
    document.querySelectorAll('.history-item').forEach(item => {
        item.addEventListener('click', async () => {
            const id = parseInt(item.dataset.id);
            const historyItem = items.find(h => h.id === id);
            if (historyItem) {
                // Fill in the form with history data
                textInput.value = historyItem.text;
                if (historyItem.totalStep) totalStepInput.value = historyItem.totalStep;
                if (historyItem.speed) speedInput.value = historyItem.speed;
                
                // Close history panel
                historyPanel.classList.remove('open');
                
                // Show notification
                showStatus(`📋 <strong>Loaded from history:</strong> ${historyItem.text.substring(0, 50)}...`, 'success');
            }
        });
    });
}

// ==================== Keyboard Shortcuts ====================
document.addEventListener('keydown', (e) => {
    // Ctrl+Enter: Generate
    if (e.ctrlKey && e.key === 'Enter') {
        e.preventDefault();
        if (!generateBtn.disabled) {
            generateBtn.click();
        }
    }
    
    // Ctrl+K: Clear text
    if (e.ctrlKey && e.key === 'k') {
        e.preventDefault();
        textInput.value = '';
        textInput.focus();
    }
    
    // Ctrl+H: Toggle history
    if (e.ctrlKey && e.key === 'h') {
        e.preventDefault();
        historyPanel.classList.toggle('open');
    }
    
    // Escape: Close history panel
    if (e.key === 'Escape' && historyPanel.classList.contains('open')) {
        historyPanel.classList.remove('open');
    }
});

// Initialize on load
window.addEventListener('load', async () => {
    generateBtn.disabled = true;
    await initializeModels();
    
    // Show keyboard shortcuts hint
    setTimeout(() => {
        console.log('%c⌨️ Keyboard Shortcuts:', 'font-size: 14px; font-weight: bold; color: #667eea;');
        console.log('  Ctrl+Enter: Generate speech');
        console.log('  Ctrl+K: Clear text');
        console.log('  Ctrl+H: Toggle history');
        console.log('  Escape: Close panels');
    }, 2000);
});

// ==================== Tab Navigation ====================
tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        const tabName = btn.dataset.tab;
        
        // Update button states
        tabBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        
        // Show corresponding tab
        tabPanes.forEach(pane => {
            pane.classList.remove('active');
        });
        document.getElementById(`${tabName}Tab`).classList.add('active');
    });
});

// ==================== Batch Processing ====================

// File drag and drop
uploadArea.addEventListener('click', () => {
    batchFileInput.click();
});

uploadArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadArea.classList.add('drag-over');
});

uploadArea.addEventListener('dragleave', () => {
    uploadArea.classList.remove('drag-over');
});

uploadArea.addEventListener('drop', async (e) => {
    e.preventDefault();
    uploadArea.classList.remove('drag-over');
    
    const files = Array.from(e.dataTransfer.files);
    await handleBatchFiles(files);
});

batchFileInput.addEventListener('change', async (e) => {
    const files = Array.from(e.target.files);
    await handleBatchFiles(files);
    e.target.value = ''; // Reset input
});

async function handleBatchFiles(files) {
    for (const file of files) {
        try {
            if (file.name.endsWith('.txt')) {
                await batchProcessor.addFromTextFile(file);
            } else if (file.name.endsWith('.csv')) {
                await batchProcessor.addFromCSV(file);
            }
        } catch (error) {
            console.error('Error reading file:', error);
            showError(`Failed to read file: ${file.name}`);
        }
    }
    updateBatchQueue();
}

// Add from textarea
addToBatchBtn.addEventListener('click', () => {
    const text = batchTextarea.value.trim();
    if (!text) {
        showError('Please enter some text');
        return;
    }
    
    const lines = text.split('\n').filter(line => line.trim());
    batchProcessor.addTexts(lines, {
        totalStep: parseInt(totalStepInput.value),
        speed: parseFloat(speedInput.value),
        voiceStyle: getFilenameFromPath(currentStylePath)
    });
    
    batchTextarea.value = '';
    updateBatchQueue();
});

// Update queue display
function updateBatchQueue() {
    const items = batchProcessor.queue;
    queueCount.textContent = items.length;
    
    if (items.length === 0) {
        batchQueue.innerHTML = `
            <div class="queue-empty">
                <div class="queue-empty-icon">📭</div>
                <p>No items in queue</p>
                <p class="queue-empty-hint">Add items to start batch processing</p>
            </div>
        `;
        startBatchBtn.disabled = true;
        downloadAllBtn.disabled = true;
        return;
    }
    
    startBatchBtn.disabled = false;
    
    batchQueue.innerHTML = items.map((item, index) => `
        <div class="queue-item">
            <div class="queue-item-status ${item.status}">
                ${item.status === 'pending' ? '⏳' : 
                  item.status === 'processing' ? '⚙️' : 
                  item.status === 'completed' ? '✓' : '✗'}
            </div>
            <div class="queue-item-text">${item.text}</div>
            <button class="queue-item-remove" onclick="removeQueueItem('${item.id}')" 
                    ${item.status === 'processing' ? 'disabled' : ''}>
                ×
            </button>
        </div>
    `).join('');
    
    // Enable download if there are completed items
    const hasCompleted = items.some(item => item.status === 'completed');
    downloadAllBtn.disabled = !hasCompleted;
}

// Make removeQueueItem global
window.removeQueueItem = function(id) {
    batchProcessor.removeFromQueue(id);
    updateBatchQueue();
};

// Clear queue
clearQueueBtn.addEventListener('click', () => {
    if (confirm('Clear all items from queue?')) {
        batchProcessor.clearQueue();
        updateBatchQueue();
    }
});

// Start batch processing
startBatchBtn.addEventListener('click', async () => {
    startBatchBtn.disabled = true;
    pauseBatchBtn.disabled = false;
    batchProgress.style.display = 'block';
    
    try {
        await batchProcessor.processQueue(
            // Progress callback
            (progress) => {
                batchProgressBar.style.width = `${progress.percentage}%`;
                batchProgressText.textContent = `Processing ${progress.current} of ${progress.total}...`;
                batchProgressPercent.textContent = `${progress.percentage}%`;
                updateBatchQueue();
            },
            // Item complete callback
            (item) => {
                if (item.status === 'completed') {
                    // Add to playlist
                    addToPlaylist({
                        text: item.text,
                        audioUrl: item.result.url,
                        duration: item.result.duration,
                        voiceStyle: item.options.voiceStyle,
                        timestamp: Date.now()
                    });
                }
            }
        );
        
        showStatus('✅ <strong>Batch processing completed!</strong>', 'success');
        downloadAllBtn.disabled = false;
        
    } catch (error) {
        console.error('Batch processing error:', error);
        showStatus(`❌ <strong>Batch processing failed:</strong> ${error.message}`, 'error');
    } finally {
        startBatchBtn.disabled = false;
        pauseBatchBtn.disabled = true;
    }
});

// Pause batch
pauseBatchBtn.addEventListener('click', () => {
    batchProcessor.pause();
    startBatchBtn.disabled = false;
    pauseBatchBtn.disabled = true;
});

// Download all as ZIP
downloadAllBtn.addEventListener('click', async () => {
    try {
        showStatus('ℹ️ <strong>Creating ZIP file...</strong>');
        await batchProcessor.downloadZip('supertonic_batch.zip');
        showStatus('✅ <strong>ZIP file downloaded!</strong>', 'success');
    } catch (error) {
        console.error('Error creating ZIP:', error);
        showError('Failed to create ZIP file. Please try downloading files individually.');
    }
});

// ==================== Playlist Management ====================

function addToPlaylist(item) {
    playlist.push(item);
    updatePlaylistDisplay();
}

function updatePlaylistDisplay() {
    if (playlist.length === 0) {
        playlistItems.innerHTML = `
            <div class="playlist-empty">
                <div class="playlist-empty-icon">🎵</div>
                <p>No audio files yet</p>
                <p class="playlist-empty-hint">Generate some audio to build your playlist</p>
            </div>
        `;
        playAllBtn.disabled = true;
        clearPlaylistBtn.disabled = true;
        exportPlaylistBtn.disabled = true;
        return;
    }
    
    playAllBtn.disabled = false;
    clearPlaylistBtn.disabled = false;
    exportPlaylistBtn.disabled = false;
    
    playlistItems.innerHTML = playlist.map((item, index) => `
        <div class="playlist-item">
            <div class="playlist-item-header">
                <div class="playlist-item-title">
                    ${index + 1}. ${item.text.substring(0, 50)}${item.text.length > 50 ? '...' : ''}
                </div>
                <div class="playlist-item-meta">
                    🎤 ${item.voiceStyle} • ⏱️ ${item.duration.toFixed(2)}s
                </div>
            </div>
            <audio controls src="${item.audioUrl}"></audio>
        </div>
    `).join('');
}

// Play all
let currentPlayingIndex = -1;
playAllBtn.addEventListener('click', () => {
    if (playlist.length === 0) return;
    
    currentPlayingIndex = 0;
    playNext();
});

function playNext() {
    if (currentPlayingIndex >= playlist.length) {
        currentPlayingIndex = -1;
        showStatus('✅ <strong>Finished playing all audio!</strong>', 'success');
        return;
    }
    
    const audios = playlistItems.querySelectorAll('audio');
    const audio = audios[currentPlayingIndex];
    
    audio.play();
    audio.onended = () => {
        currentPlayingIndex++;
        playNext();
    };
}

// Clear playlist
clearPlaylistBtn.addEventListener('click', () => {
    if (confirm('Clear entire playlist?')) {
        playlist.length = 0;
        updatePlaylistDisplay();
    }
});

// Export playlist
exportPlaylistBtn.addEventListener('click', () => {
    const data = {
        version: '1.0',
        exportDate: new Date().toISOString(),
        items: playlist.map(item => ({
            text: item.text,
            voiceStyle: item.voiceStyle,
            duration: item.duration,
            timestamp: item.timestamp
        }))
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `supertonic_playlist_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
});

// ==================== Waveform Visualization ====================

// Waveform type switching
waveformTypeBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        waveformTypeBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        
        const type = btn.dataset.type;
        if (waveformVisualizer) {
            waveformVisualizer.setVisualizationType(type);
        }
    });
});

// Connect audio elements to waveform
document.addEventListener('play', (e) => {
    if (e.target.tagName === 'AUDIO' && waveformVisualizer && enableWaveform.checked) {
        waveformVisualizer.connectAudio(e.target);
    }
}, true);

document.addEventListener('pause', (e) => {
    if (e.target.tagName === 'AUDIO' && waveformVisualizer) {
        waveformVisualizer.stop();
    }
}, true);

// ==================== Settings Panel ====================

// Open settings
settingsToggle.addEventListener('click', () => {
    settingsPanel.classList.add('open');
    updateSettingsInfo();
});

// Close settings
closeSettingsBtn.addEventListener('click', () => {
    settingsPanel.classList.remove('open');
});

// Close when clicking outside
document.addEventListener('click', (e) => {
    if (settingsPanel.classList.contains('open') && 
        !settingsPanel.contains(e.target) && 
        e.target !== settingsToggle) {
        settingsPanel.classList.remove('open');
    }
});

// Language switching
languageSelector.addEventListener('change', (e) => {
    i18n.setLanguage(e.target.value);
    settingsLanguage.value = e.target.value;
});

settingsLanguage.addEventListener('change', (e) => {
    i18n.setLanguage(e.target.value);
    languageSelector.value = e.target.value;
});

// Theme options
document.querySelectorAll('input[name="theme"]').forEach(radio => {
    radio.addEventListener('change', (e) => {
        const value = e.target.value;
        
        if (value === 'light') {
            document.body.classList.remove('dark-mode');
            localStorage.setItem('theme', 'light');
        } else if (value === 'dark') {
            document.body.classList.add('dark-mode');
            localStorage.setItem('theme', 'dark');
        } else if (value === 'auto') {
            const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            if (prefersDark) {
                document.body.classList.add('dark-mode');
            } else {
                document.body.classList.remove('dark-mode');
            }
            localStorage.setItem('theme', 'auto');
        }
    });
});

// Waveform toggle
enableWaveform.addEventListener('change', (e) => {
    if (!e.target.checked && waveformVisualizer) {
        waveformVisualizer.stop();
    }
});

// Clear all data
clearAllDataBtn.addEventListener('click', async () => {
    if (confirm('This will clear all history, playlist, and settings. Are you sure?')) {
        await historyManager.clearAll();
        playlist.length = 0;
        localStorage.clear();
        updateHistoryDisplay();
        updatePlaylistDisplay();
        updateSettingsInfo();
        showStatus('✅ <strong>All data cleared!</strong>', 'success');
    }
});

// Update settings info
async function updateSettingsInfo() {
    const history = await historyManager.getAll();
    historyCountSpan.textContent = history.length;
    playlistCountSpan.textContent = playlist.length;
}

// ==================== PWA Support ====================

// Register service worker
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
            .then(reg => {
                console.log('✅ Service Worker registered:', reg.scope);
                pwaStatus.textContent = '✅ Enabled';
            })
            .catch(err => {
                console.error('❌ Service Worker registration failed:', err);
            });
    });
}

// Handle install prompt
window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    installPwaBtn.style.display = 'block';
});

// Install PWA button
installPwaBtn.addEventListener('click', async () => {
    if (!deferredPrompt) return;
    
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    
    if (outcome === 'accepted') {
        console.log('✅ PWA installed');
        pwaStatus.textContent = '✅ Installed';
        installPwaBtn.style.display = 'none';
    }
    
    deferredPrompt = null;
});

// Check if already installed
window.addEventListener('appinstalled', () => {
    console.log('✅ PWA installed');
    pwaStatus.textContent = '✅ Installed';
    installPwaBtn.style.display = 'none';
});

// Check if running as PWA
if (window.matchMedia('(display-mode: standalone)').matches) {
    pwaStatus.textContent = '✅ Running as app';
    installPwaBtn.style.display = 'none';
}

// ==================== Initialize ====================

// Set initial language
const savedLanguage = localStorage.getItem('app_language') || 'en';
i18n.setLanguage(savedLanguage);
languageSelector.value = savedLanguage;
settingsLanguage.value = savedLanguage;

// Set initial theme
const savedTheme = localStorage.getItem('theme');
if (savedTheme) {
    const radio = document.querySelector(`input[name="theme"][value="${savedTheme}"]`);
    if (radio) radio.checked = true;
}

console.log('%c🎉 Supertonic v3.0.0 Loaded!', 'font-size: 16px; font-weight: bold; color: #667eea;');
console.log('%c✨ New Features:', 'font-size: 14px; font-weight: bold; color: #764ba2;');
console.log('  📊 Waveform Visualization');
console.log('  🌍 Multi-language Support (EN/ZH)');
console.log('  📱 PWA Support');
console.log('  ⚙️ Advanced Settings Panel');
