/**
 * Audio Waveform Visualizer
 * Provides real-time audio waveform visualization using Canvas API
 */

export default class WaveformVisualizer {
    constructor(canvasId, options = {}) {
        this.canvas = typeof canvasId === 'string' 
            ? document.getElementById(canvasId)
            : canvasId;
            
        if (!this.canvas) {
            throw new Error('Canvas element not found');
        }
        
        this.ctx = this.canvas.getContext('2d');
        this.audioContext = null;
        this.analyser = null;
        this.dataArray = null;
        this.animationId = null;
        
        // Options
        this.options = {
            backgroundColor: options.backgroundColor || '#1a1a2e',
            waveColor: options.waveColor || '#667eea',
            progressColor: options.progressColor || '#764ba2',
            lineWidth: options.lineWidth || 2,
            fftSize: options.fftSize || 2048,
            smoothingTimeConstant: options.smoothingTimeConstant || 0.8,
            visualizationType: options.visualizationType || 'waveform', // 'waveform', 'frequency', 'bars'
            ...options
        };
        
        this.resize();
        window.addEventListener('resize', () => this.resize());
    }
    
    resize() {
        const rect = this.canvas.getBoundingClientRect();
        this.canvas.width = rect.width * window.devicePixelRatio;
        this.canvas.height = rect.height * window.devicePixelRatio;
        this.ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
        this.width = rect.width;
        this.height = rect.height;
    }
    
    /**
     * Connect to an audio element for visualization
     */
    connectAudio(audioElement) {
        if (!this.audioContext) {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
        }
        
        // Create or recreate analyser
        if (!this.analyser) {
            this.analyser = this.audioContext.createAnalyser();
            this.analyser.fftSize = this.options.fftSize;
            this.analyser.smoothingTimeConstant = this.options.smoothingTimeConstant;
            
            const bufferLength = this.analyser.frequencyBinCount;
            this.dataArray = new Uint8Array(bufferLength);
        }
        
        // Connect audio source
        try {
            const source = this.audioContext.createMediaElementSource(audioElement);
            source.connect(this.analyser);
            this.analyser.connect(this.audioContext.destination);
        } catch (error) {
            console.warn('Audio source already connected:', error);
        }
        
        this.startVisualization();
    }
    
    /**
     * Visualize from raw audio data (ArrayBuffer)
     */
    async visualizeAudioData(audioData, sampleRate = 24000) {
        if (!this.audioContext) {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
        }
        
        try {
            // Decode audio data
            const audioBuffer = await this.audioContext.decodeAudioData(audioData);
            
            // Draw static waveform
            this.drawStaticWaveform(audioBuffer);
        } catch (error) {
            console.error('Error visualizing audio data:', error);
        }
    }
    
    /**
     * Draw static waveform from AudioBuffer
     */
    drawStaticWaveform(audioBuffer) {
        const data = audioBuffer.getChannelData(0);
        const step = Math.ceil(data.length / this.width);
        const amp = this.height / 2;
        
        this.ctx.clearRect(0, 0, this.width, this.height);
        this.ctx.fillStyle = this.options.backgroundColor;
        this.ctx.fillRect(0, 0, this.width, this.height);
        
        this.ctx.strokeStyle = this.options.waveColor;
        this.ctx.lineWidth = this.options.lineWidth;
        this.ctx.beginPath();
        
        for (let i = 0; i < this.width; i++) {
            const min = Math.min(...data.slice(i * step, (i + 1) * step));
            const max = Math.max(...data.slice(i * step, (i + 1) * step));
            
            const y1 = (1 + min) * amp;
            const y2 = (1 + max) * amp;
            
            if (i === 0) {
                this.ctx.moveTo(i, y1);
            }
            
            this.ctx.lineTo(i, y1);
            this.ctx.lineTo(i, y2);
        }
        
        this.ctx.stroke();
        
        // Draw center line
        this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
        this.ctx.lineWidth = 1;
        this.ctx.beginPath();
        this.ctx.moveTo(0, this.height / 2);
        this.ctx.lineTo(this.width, this.height / 2);
        this.ctx.stroke();
    }
    
    /**
     * Start real-time visualization
     */
    startVisualization() {
        if (!this.analyser) return;
        
        const draw = () => {
            this.animationId = requestAnimationFrame(draw);
            
            if (this.options.visualizationType === 'waveform') {
                this.drawWaveform();
            } else if (this.options.visualizationType === 'frequency') {
                this.drawFrequency();
            } else if (this.options.visualizationType === 'bars') {
                this.drawBars();
            }
        };
        
        draw();
    }
    
    /**
     * Draw real-time waveform
     */
    drawWaveform() {
        this.analyser.getByteTimeDomainData(this.dataArray);
        
        this.ctx.fillStyle = this.options.backgroundColor;
        this.ctx.fillRect(0, 0, this.width, this.height);
        
        this.ctx.lineWidth = this.options.lineWidth;
        this.ctx.strokeStyle = this.options.waveColor;
        this.ctx.beginPath();
        
        const sliceWidth = this.width / this.dataArray.length;
        let x = 0;
        
        for (let i = 0; i < this.dataArray.length; i++) {
            const v = this.dataArray[i] / 128.0;
            const y = (v * this.height) / 2;
            
            if (i === 0) {
                this.ctx.moveTo(x, y);
            } else {
                this.ctx.lineTo(x, y);
            }
            
            x += sliceWidth;
        }
        
        this.ctx.lineTo(this.width, this.height / 2);
        this.ctx.stroke();
    }
    
    /**
     * Draw frequency spectrum
     */
    drawFrequency() {
        this.analyser.getByteFrequencyData(this.dataArray);
        
        this.ctx.fillStyle = this.options.backgroundColor;
        this.ctx.fillRect(0, 0, this.width, this.height);
        
        const barWidth = this.width / this.dataArray.length * 2.5;
        let x = 0;
        
        for (let i = 0; i < this.dataArray.length; i++) {
            const barHeight = (this.dataArray[i] / 255) * this.height;
            
            // Gradient from bottom to top
            const gradient = this.ctx.createLinearGradient(0, this.height, 0, this.height - barHeight);
            gradient.addColorStop(0, this.options.waveColor);
            gradient.addColorStop(1, this.options.progressColor);
            
            this.ctx.fillStyle = gradient;
            this.ctx.fillRect(x, this.height - barHeight, barWidth, barHeight);
            
            x += barWidth + 1;
        }
    }
    
    /**
     * Draw bar visualization
     */
    drawBars() {
        this.analyser.getByteFrequencyData(this.dataArray);
        
        this.ctx.fillStyle = this.options.backgroundColor;
        this.ctx.fillRect(0, 0, this.width, this.height);
        
        const barCount = 64;
        const barWidth = this.width / barCount;
        const step = Math.floor(this.dataArray.length / barCount);
        
        for (let i = 0; i < barCount; i++) {
            let sum = 0;
            for (let j = 0; j < step; j++) {
                sum += this.dataArray[i * step + j];
            }
            const average = sum / step;
            const barHeight = (average / 255) * this.height;
            
            const hue = (i / barCount) * 360;
            this.ctx.fillStyle = `hsl(${hue}, 70%, 60%)`;
            this.ctx.fillRect(
                i * barWidth,
                this.height - barHeight,
                barWidth - 2,
                barHeight
            );
        }
    }
    
    /**
     * Stop visualization
     */
    stop() {
        if (this.animationId) {
            cancelAnimationFrame(this.animationId);
            this.animationId = null;
        }
        
        // Clear canvas
        this.ctx.fillStyle = this.options.backgroundColor;
        this.ctx.fillRect(0, 0, this.width, this.height);
    }
    
    /**
     * Change visualization type
     */
    setVisualizationType(type) {
        this.options.visualizationType = type;
    }
    
    /**
     * Update colors
     */
    setColors(backgroundColor, waveColor, progressColor) {
        if (backgroundColor) this.options.backgroundColor = backgroundColor;
        if (waveColor) this.options.waveColor = waveColor;
        if (progressColor) this.options.progressColor = progressColor;
    }
    
    /**
     * Cleanup
     */
    destroy() {
        this.stop();
        if (this.audioContext) {
            this.audioContext.close();
        }
        window.removeEventListener('resize', () => this.resize());
    }
}
