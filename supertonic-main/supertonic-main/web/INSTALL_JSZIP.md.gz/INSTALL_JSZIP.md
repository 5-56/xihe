# 📦 安装 JSZip 支持

批量下载功能需要 JSZip 库支持。

## 快速安装

### 方法 1: NPM 安装（推荐）

```bash
cd web
npm install jszip
```

### 方法 2: CDN 引入

在 `index.html` 的 `<head>` 中添加：

```html
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
```

### 方法 3: 本地文件

1. 下载 JSZip: https://github.com/Stuk/jszip/releases
2. 将 `jszip.min.js` 放到 `web/` 目录
3. 在 `index.html` 中引用：

```html
<script src="/jszip.min.js"></script>
```

## 验证安装

打开浏览器控制台，输入：

```javascript
typeof JSZip
```

如果显示 `"function"` 则安装成功。

## 使用

安装后，批量处理的 "Download All (ZIP)" 按钮将可用。

## 可选依赖

如果不需要 ZIP 下载功能，可以跳过安装。用户仍可以：
- 单独下载每个音频文件
- 使用浏览器的批量下载功能

## 故障排除

### 问题：按钮显示但点击无效
**解决**：确保 JSZip 已正确加载，检查浏览器控制台是否有错误。

### 问题：ZIP 文件损坏
**解决**：确保使用最新版本的 JSZip (v3.10.1+)。

### 问题：大文件 ZIP 失败
**解决**：减少批量处理数量，建议每次不超过 50 个文件。
