/**
 * 批量处理器
 * 支持批量文本到语音转换
 */

class BatchProcessor {
    constructor(textToSpeech, style) {
        this.tts = textToSpeech;
        this.style = style;
        this.queue = [];
        this.isProcessing = false;
        this.currentIndex = 0;
        this.results = [];
    }

    /**
     * 从文本数组添加到队列
     */
    addTexts(texts, options = {}) {
        texts.forEach((text, index) => {
            this.queue.push({
                id: `batch_${Date.now()}_${index}`,
                text: text.trim(),
                status: 'pending',
                options: {
                    totalStep: options.totalStep || 5,
                    speed: options.speed || 1.05,
                    voiceStyle: options.voiceStyle || 'default'
                },
                result: null,
                error: null
            });
        });
    }

    /**
     * 从 CSV 文件添加到队列
     */
    async addFromCSV(file) {
        const text = await file.text();
        const lines = text.split('\n').map(line => line.trim()).filter(line => line);
        
        // 假设第一列是文本内容
        const texts = lines.map(line => {
            const columns = line.split(',');
            return columns[0].replace(/^"|"$/g, ''); // 移除引号
        });

        this.addTexts(texts);
        return texts.length;
    }

    /**
     * 从纯文本文件添加到队列（每行一句）
     */
    async addFromTextFile(file) {
        const text = await file.text();
        const lines = text.split('\n')
            .map(line => line.trim())
            .filter(line => line.length > 0);

        this.addTexts(lines);
        return lines.length;
    }

    /**
     * 处理队列
     */
    async processQueue(onProgress, onItemComplete) {
        if (this.isProcessing) {
            throw new Error('Already processing');
        }

        this.isProcessing = true;
        this.currentIndex = 0;
        this.results = [];

        const totalItems = this.queue.length;

        for (let i = 0; i < this.queue.length; i++) {
            const item = this.queue[i];
            this.currentIndex = i;

            item.status = 'processing';
            
            // 更新进度
            if (onProgress) {
                onProgress({
                    current: i + 1,
                    total: totalItems,
                    item: item,
                    percentage: ((i + 1) / totalItems * 100).toFixed(1)
                });
            }

            try {
                // 执行合成
                const { wav, duration } = await this.tts.call(
                    item.text,
                    this.style,
                    item.options.totalStep,
                    item.options.speed
                );

                // 创建音频 blob
                const wavLen = Math.floor(this.tts.sampleRate * duration[0]);
                const wavOut = wav.slice(0, wavLen);
                const wavBuffer = this.writeWavFile(wavOut, this.tts.sampleRate);
                const blob = new Blob([wavBuffer], { type: 'audio/wav' });

                item.result = {
                    wav: wavOut,
                    duration: duration[0],
                    blob: blob,
                    url: URL.createObjectURL(blob)
                };
                item.status = 'completed';

            } catch (error) {
                console.error(`Error processing item ${i}:`, error);
                item.error = error.message;
                item.status = 'failed';
            }

            this.results.push(item);

            // 回调单项完成
            if (onItemComplete) {
                onItemComplete(item, i, totalItems);
            }

            // 添加小延迟避免阻塞 UI
            await this.sleep(10);
        }

        this.isProcessing = false;
        return this.results;
    }

    /**
     * 暂停处理
     */
    pause() {
        this.isProcessing = false;
    }

    /**
     * 恢复处理
     */
    async resume(onProgress, onItemComplete) {
        if (this.currentIndex >= this.queue.length) {
            return this.results;
        }

        // 从当前位置继续处理
        const remainingQueue = this.queue.slice(this.currentIndex);
        this.queue = remainingQueue;
        return await this.processQueue(onProgress, onItemComplete);
    }

    /**
     * 取消处理
     */
    cancel() {
        this.isProcessing = false;
        this.queue = [];
        this.currentIndex = 0;
    }

    /**
     * 移除队列中的项
     */
    removeFromQueue(id) {
        this.queue = this.queue.filter(item => item.id !== id);
    }

    /**
     * 清空队列
     */
    clearQueue() {
        this.queue = [];
        this.currentIndex = 0;
    }

    /**
     * 导出所有结果为 ZIP
     */
    async exportAsZip() {
        // 需要引入 JSZip 库
        if (typeof JSZip === 'undefined') {
            throw new Error('JSZip library not loaded');
        }

        const zip = new JSZip();
        const successResults = this.results.filter(item => item.status === 'completed');

        // 添加音频文件
        successResults.forEach((item, index) => {
            const filename = this.sanitizeFilename(item.text, 30) || `audio_${index + 1}`;
            zip.file(`${filename}.wav`, item.result.blob);
        });

        // 添加元数据文件
        const metadata = {
            generatedAt: new Date().toISOString(),
            totalFiles: successResults.length,
            items: successResults.map((item, index) => ({
                index: index + 1,
                text: item.text,
                duration: item.result.duration,
                options: item.options
            }))
        };
        zip.file('metadata.json', JSON.stringify(metadata, null, 2));

        // 生成 ZIP
        const blob = await zip.generateAsync({ type: 'blob' });
        return blob;
    }

    /**
     * 下载 ZIP 文件
     */
    async downloadZip(filename = 'batch_synthesis.zip') {
        const blob = await this.exportAsZip();
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        a.click();
        
        URL.revokeObjectURL(url);
    }

    /**
     * 获取队列状态
     */
    getStatus() {
        const pending = this.queue.filter(item => item.status === 'pending').length;
        const processing = this.queue.filter(item => item.status === 'processing').length;
        const completed = this.queue.filter(item => item.status === 'completed').length;
        const failed = this.queue.filter(item => item.status === 'failed').length;

        return {
            total: this.queue.length,
            pending,
            processing,
            completed,
            failed,
            isProcessing: this.isProcessing,
            currentIndex: this.currentIndex
        };
    }

    /**
     * 辅助函数：写入 WAV 文件
     */
    writeWavFile(samples, sampleRate) {
        const numChannels = 1;
        const bitsPerSample = 16;
        const bytesPerSample = bitsPerSample / 8;
        const blockAlign = numChannels * bytesPerSample;
        
        const dataLength = samples.length * bytesPerSample;
        const buffer = new ArrayBuffer(44 + dataLength);
        const view = new DataView(buffer);
        
        // WAV header
        this.writeString(view, 0, 'RIFF');
        view.setUint32(4, 36 + dataLength, true);
        this.writeString(view, 8, 'WAVE');
        this.writeString(view, 12, 'fmt ');
        view.setUint32(16, 16, true);
        view.setUint16(20, 1, true);
        view.setUint16(22, numChannels, true);
        view.setUint32(24, sampleRate, true);
        view.setUint32(28, sampleRate * blockAlign, true);
        view.setUint16(32, blockAlign, true);
        view.setUint16(34, bitsPerSample, true);
        this.writeString(view, 36, 'data');
        view.setUint32(40, dataLength, true);
        
        // Audio data
        let offset = 44;
        for (let i = 0; i < samples.length; i++) {
            const sample = Math.max(-1, Math.min(1, samples[i]));
            view.setInt16(offset, sample < 0 ? sample * 0x8000 : sample * 0x7fff, true);
            offset += 2;
        }
        
        return buffer;
    }

    writeString(view, offset, string) {
        for (let i = 0; i < string.length; i++) {
            view.setUint8(offset + i, string.charCodeAt(i));
        }
    }

    /**
     * 辅助函数：清理文件名
     */
    sanitizeFilename(text, maxLength = 50) {
        return text
            .substring(0, maxLength)
            .replace(/[^a-zA-Z0-9_\-\u4e00-\u9fa5]/g, '_')
            .replace(/_+/g, '_')
            .replace(/^_|_$/g, '');
    }

    /**
     * 辅助函数：延迟
     */
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

export default BatchProcessor;
