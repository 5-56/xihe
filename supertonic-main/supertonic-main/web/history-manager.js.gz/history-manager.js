/**
 * 历史记录管理器
 * 使用 IndexedDB 存储生成的语音历史
 */

class HistoryManager {
    constructor() {
        this.dbName = 'SupertonicHistory';
        this.storeName = 'syntheses';
        this.db = null;
        this.maxItems = 100; // 最多保存100条记录
    }

    /**
     * 初始化数据库
     */
    async init() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.dbName, 1);

            request.onerror = () => reject(request.error);
            request.onsuccess = () => {
                this.db = request.result;
                resolve();
            };

            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                
                // 创建对象存储
                if (!db.objectStoreNames.contains(this.storeName)) {
                    const objectStore = db.createObjectStore(this.storeName, { 
                        keyPath: 'id',
                        autoIncrement: true 
                    });
                    
                    // 创建索引
                    objectStore.createIndex('timestamp', 'timestamp', { unique: false });
                    objectStore.createIndex('text', 'text', { unique: false });
                    objectStore.createIndex('voiceStyle', 'voiceStyle', { unique: false });
                }
            };
        });
    }

    /**
     * 添加历史记录
     */
    async add(synthesis) {
        if (!this.db) await this.init();

        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([this.storeName], 'readwrite');
            const objectStore = transaction.objectStore(this.storeName);

            const record = {
                text: synthesis.text,
                audioUrl: synthesis.audioUrl,
                voiceStyle: synthesis.voiceStyle,
                totalStep: synthesis.totalStep,
                speed: synthesis.speed,
                duration: synthesis.duration,
                timestamp: Date.now()
            };

            const request = objectStore.add(record);

            request.onsuccess = async () => {
                // 检查是否超过最大数量限制
                await this.trimHistory();
                resolve(request.result);
            };
            request.onerror = () => reject(request.error);
        });
    }

    /**
     * 获取所有历史记录
     */
    async getAll() {
        if (!this.db) await this.init();

        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([this.storeName], 'readonly');
            const objectStore = transaction.objectStore(this.storeName);
            const request = objectStore.getAll();

            request.onsuccess = () => {
                const items = request.result || [];
                // 按时间倒序排列
                items.sort((a, b) => b.timestamp - a.timestamp);
                resolve(items);
            };
            request.onerror = () => reject(request.error);
        });
    }

    /**
     * 搜索历史记录
     */
    async search(query) {
        const allItems = await this.getAll();
        
        if (!query || query.trim() === '') {
            return allItems;
        }

        const lowerQuery = query.toLowerCase();
        return allItems.filter(item => 
            item.text.toLowerCase().includes(lowerQuery)
        );
    }

    /**
     * 删除单条记录
     */
    async delete(id) {
        if (!this.db) await this.init();

        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([this.storeName], 'readwrite');
            const objectStore = transaction.objectStore(this.storeName);
            const request = objectStore.delete(id);

            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
        });
    }

    /**
     * 清空所有历史记录
     */
    async clearAll() {
        if (!this.db) await this.init();

        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([this.storeName], 'readwrite');
            const objectStore = transaction.objectStore(this.storeName);
            const request = objectStore.clear();

            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
        });
    }

    /**
     * 修剪历史记录，保持在最大数量限制内
     */
    async trimHistory() {
        const allItems = await this.getAll();
        
        if (allItems.length > this.maxItems) {
            // 删除最旧的记录
            const itemsToDelete = allItems.slice(this.maxItems);
            for (const item of itemsToDelete) {
                await this.delete(item.id);
            }
        }
    }

    /**
     * 导出历史记录为 JSON
     */
    async exportToJSON() {
        const allItems = await this.getAll();
        const exportData = {
            version: '1.0',
            exportDate: new Date().toISOString(),
            items: allItems.map(item => ({
                ...item,
                audioUrl: undefined // 不导出 Blob URL
            }))
        };

        const blob = new Blob([JSON.stringify(exportData, null, 2)], {
            type: 'application/json'
        });
        
        return blob;
    }

    /**
     * 从 JSON 导入历史记录
     */
    async importFromJSON(jsonBlob) {
        const text = await jsonBlob.text();
        const data = JSON.parse(text);

        if (!data.items || !Array.isArray(data.items)) {
            throw new Error('Invalid import format');
        }

        for (const item of data.items) {
            await this.add(item);
        }

        return data.items.length;
    }

    /**
     * 获取统计信息
     */
    async getStats() {
        const allItems = await this.getAll();
        
        if (allItems.length === 0) {
            return {
                totalCount: 0,
                totalDuration: 0,
                averageDuration: 0,
                mostUsedVoice: null,
                oldestRecord: null,
                newestRecord: null
            };
        }

        const totalDuration = allItems.reduce((sum, item) => sum + (item.duration || 0), 0);
        
        // 统计最常用的语音风格
        const voiceCounts = {};
        allItems.forEach(item => {
            const voice = item.voiceStyle || 'Unknown';
            voiceCounts[voice] = (voiceCounts[voice] || 0) + 1;
        });
        
        const mostUsedVoice = Object.keys(voiceCounts).reduce((a, b) => 
            voiceCounts[a] > voiceCounts[b] ? a : b
        );

        return {
            totalCount: allItems.length,
            totalDuration: totalDuration,
            averageDuration: totalDuration / allItems.length,
            mostUsedVoice: mostUsedVoice,
            oldestRecord: new Date(allItems[allItems.length - 1].timestamp),
            newestRecord: new Date(allItems[0].timestamp)
        };
    }
}

export default HistoryManager;
